using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Food Size: 1.00", "Settings", "Click to adjust food size.", false, 19, ModType.const_1, false)]
internal class Class128 : MonoBehaviour
{
	public static float float_0;

	public static int int_0;

	private static float[] float_1;

	private static float float_2;

	private static float float_3;

	private static float float_4;

	private static double double_0;

	private static double double_1;

	private static double double_2;

	private static IntPtr[] MessageIdPaddingHelpers;

	private static IntPtr[] SetApartmentStateLongPath;

	private static IntPtr[] getindexComInterfaceType;

	private static IntPtr[] pValueBinaryFormatter;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_048f, IL_04a2, IL_04c1, IL_04d1, IL_04e1, IL_04ee, IL_04fe, IL_050e, IL_051e, IL_052b, IL_053b, IL_054b, IL_055b, IL_0566, IL_0579, IL_0587, IL_0592, IL_05a0, IL_05ae, IL_05bc, IL_05cf, IL_05dd, IL_05eb, IL_0608, IL_0657, IL_0661, IL_068e, IL_06a2, IL_06b2, IL_06bd, IL_06cb, IL_06de, IL_06e9, IL_06fc, IL_070f, IL_0776, IL_0789, IL_0797, IL_07e0, IL_07f4, IL_0807, IL_0815, IL_0820, IL_0865, IL_0873, IL_0881, IL_0894, IL_08a8, IL_092b, IL_093e, IL_094c, IL_095a, IL_0988, IL_0993, IL_09ad, IL_09c0, IL_09ce, IL_09dc, IL_09ea, IL_09f8, IL_0a06, IL_0a14, IL_0a28, IL_0a60, IL_0a73, IL_0a7e, IL_0a89, IL_0ab4, IL_0acd, IL_0ae0, IL_0aee, IL_0af7, IL_0b0a, IL_0b18, IL_0b26, IL_0b40, IL_0b53, IL_0b7c, IL_0b8a, IL_0b9d, IL_0bbb, IL_0bc9, IL_0be5, IL_0c09, IL_0c17, IL_0c2e, IL_0c41, IL_0c81, IL_0c95, IL_0ca8, IL_0cb6, IL_0cc4, IL_0ccd, IL_0ce4, IL_0cf7, IL_0d05, IL_0d18, IL_0d2b, IL_0d3e, IL_0d4c, IL_0d5f, IL_0d81, IL_0dbf, IL_0ddb, IL_0de9, IL_0e0b, IL_0e19, IL_0e30, IL_0e43, IL_0e4e, IL_0e5c, IL_0e74, IL_0ea0, IL_0eae, IL_0ebc, IL_0eca, IL_0ed8, IL_0ee6, IL_0f0f, IL_0f1d, IL_0f30, IL_0f3e, IL_0f6d, IL_0f7b, IL_0fbb, IL_0fcf, IL_0fe2, IL_0ff0, IL_0ffe, IL_101c, IL_102a, IL_103d, IL_104b, IL_1063, IL_1071, IL_1084, IL_1092, IL_10b5, IL_10bf, IL_10cd, IL_10e0, IL_1124, IL_1138, IL_114b, IL_1159, IL_1167, IL_11a7, IL_11bb, IL_11ce, IL_11e7, IL_120b, IL_1223, IL_1236, IL_124a, IL_1266, IL_12b2, IL_12c0, IL_12d3, IL_12e1, IL_12ec, IL_1315, IL_1323, IL_1336, IL_1344, IL_1352, IL_136a, IL_1378, IL_1386, IL_1396, IL_13a1, IL_13ac, IL_13c5, IL_13d0, IL_13db, IL_13f7, IL_140a, IL_1414, IL_1428, IL_1438, IL_1448, IL_1461, IL_1471, IL_1481, IL_1491, IL_14a1, IL_14ac, IL_14bc are reachable both inside and outside the pinned region starting at IL_14d1. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 182;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			int __rxRef40 = default(int);
			ref int reference = ref __rxRef40;
			object[] array8;
			int num8;
			byte* num9;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_14bc:
					num2 = 1;
					while (true)
					{
						IL_14ac:
						num3 = num2 * 4;
						while (true)
						{
							IL_14a1:
							num = 229;
							while (true)
							{
								IL_1491:
								array2 = new byte[4];
								while (true)
								{
									IL_1481:
									array3 = new object[4];
									while (true)
									{
										IL_1471:
										array4 = new int[4];
										while (true)
										{
											IL_1461:
											array5 = new int[6];
											while (true)
											{
												IL_1448:
												array6 = new long[4];
												num = 8;
												while (true)
												{
													IL_1438:
													array7 = new object[13];
													while (true)
													{
														IL_1428:
														array7[0] = this;
														while (true)
														{
															IL_1414:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TplEtwProviderMissingMethodException.SubjectVersioningHelper);
															num = 107;
															while (true)
															{
																IL_140a:
																ptr2 = ptr;
																while (true)
																{
																	if (num4 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_055b:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_054b:
																			ptr2++;
																			while (true)
																			{
																				IL_053b:
																				if (b >= 1)
																				{
																					while (b <= 33)
																					{
																						while (true)
																						{
																							IL_051e:
																							if (17 < b)
																							{
																								while (true)
																								{
																									IL_050e:
																									if (25 < b)
																									{
																										while (true)
																										{
																											IL_04fe:
																											if (29 >= b)
																											{
																												while (true)
																												{
																													IL_04ee:
																													if (29 > b)
																													{
																														while (true)
																														{
																															IL_04e1:
																															if (27 < b)
																															{
																																while (28 >= b)
																																{
																																	while (28 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_04a2:
																																			array2[num5 - 2] = 5;
																																			num = 288;
																																			while (true)
																																			{
																																				if (num != 288)
																																				{
																																					if (num != 1269)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 182:
																																						break;
																																					default:
																																						continue;
																																					case 151:
																																					case 273:
																																						goto IL_04a2;
																																					case 61:
																																						goto IL_04c1;
																																					case 83:
																																						goto IL_04d1;
																																					case 275:
																																						goto IL_04e1;
																																					case 68:
																																						goto IL_04ee;
																																					case 113:
																																						goto IL_04fe;
																																					case 264:
																																						goto IL_050e;
																																					case 173:
																																						goto IL_051e;
																																					case 111:
																																						goto IL_052b;
																																					case 2:
																																						goto IL_053b;
																																					case 139:
																																						goto IL_054b;
																																					case 57:
																																					case 200:
																																						goto IL_055b;
																																					case 63:
																																						goto IL_0566;
																																					case 120:
																																						goto IL_0579;
																																					case 115:
																																						goto IL_0587;
																																					case 9:
																																						goto IL_0592;
																																					case 134:
																																						goto IL_05a0;
																																					case 146:
																																						goto IL_05ae;
																																					case 112:
																																						goto IL_05bc;
																																					case 160:
																																						goto IL_05cf;
																																					case 108:
																																						goto IL_05dd;
																																					case 25:
																																					case 44:
																																						goto IL_05eb;
																																					case 65:
																																						goto IL_06a2;
																																					case 114:
																																						goto IL_06b2;
																																					case 32:
																																						goto IL_06bd;
																																					case 15:
																																						goto IL_06cb;
																																					case 29:
																																						goto IL_06de;
																																					case 24:
																																						goto IL_06e9;
																																					case 171:
																																						goto IL_06fc;
																																					case 36:
																																					case 175:
																																						goto IL_070f;
																																					case 119:
																																					case 178:
																																						goto IL_0776;
																																					case 190:
																																						goto IL_0789;
																																					case 47:
																																					case 48:
																																						goto IL_0797;
																																					case 103:
																																						goto IL_07e0;
																																					case 7:
																																						goto IL_07f4;
																																					case 192:
																																						goto IL_0807;
																																					case 186:
																																						goto IL_0815;
																																					case 45:
																																					case 116:
																																						goto IL_0820;
																																					case 156:
																																						goto IL_0865;
																																					case 199:
																																						goto IL_0881;
																																					case 38:
																																					case 208:
																																						goto IL_0894;
																																					case 39:
																																						goto IL_08a8;
																																					case 220:
																																						goto IL_092b;
																																					case 223:
																																						goto IL_093e;
																																					case 60:
																																						goto IL_094c;
																																					case 100:
																																					case 206:
																																						goto IL_095a;
																																					case 224:
																																						goto IL_0988;
																																					case 72:
																																					case 76:
																																						goto IL_0993;
																																					case 99:
																																						goto IL_09ad;
																																					case 185:
																																						goto IL_09c0;
																																					case 201:
																																						goto IL_09ce;
																																					case 66:
																																						goto IL_09dc;
																																					case 90:
																																						goto IL_09ea;
																																					case 187:
																																						goto IL_09f8;
																																					case 110:
																																						goto IL_0a06;
																																					case 35:
																																					case 97:
																																						goto IL_0a14;
																																					case 105:
																																						goto IL_0a28;
																																					case 50:
																																						goto IL_0a60;
																																					case 80:
																																						goto IL_0a73;
																																					case 6:
																																						goto IL_0a7e;
																																					case 52:
																																					case 218:
																																						goto IL_0a89;
																																					case 126:
																																						goto IL_0ab4;
																																					case 117:
																																						goto IL_0acd;
																																					case 168:
																																						goto IL_0ae0;
																																					case 73:
																																						goto IL_0af7;
																																					case 225:
																																						goto IL_0b0a;
																																					case 155:
																																						goto IL_0b18;
																																					case 195:
																																					case 230:
																																						goto IL_0b26;
																																					case 34:
																																						goto IL_0b40;
																																					case 219:
																																					case 233:
																																						goto IL_0b53;
																																					case 197:
																																						goto IL_0b7c;
																																					case 82:
																																						goto IL_0b8a;
																																					case 12:
																																					case 239:
																																						goto IL_0b9d;
																																					case 179:
																																						goto IL_0bbb;
																																					case 161:
																																						goto IL_0bc9;
																																					case 53:
																																					case 240:
																																						goto IL_0be5;
																																					case 17:
																																						goto IL_0c09;
																																					case 27:
																																						goto IL_0c17;
																																					case 95:
																																						goto IL_0c2e;
																																					case 235:
																																					case 246:
																																						goto IL_0c41;
																																					case 124:
																																						goto IL_0c81;
																																					case 170:
																																						goto IL_0c95;
																																					case 249:
																																						goto IL_0ca8;
																																					case 158:
																																						goto IL_0cb6;
																																					case 79:
																																					case 94:
																																						goto IL_0ccd;
																																					case 231:
																																						goto IL_0ce4;
																																					case 153:
																																						goto IL_0cf7;
																																					case 14:
																																						goto IL_0d05;
																																					case 250:
																																						goto IL_0d18;
																																					case 252:
																																						goto IL_0d2b;
																																					case 254:
																																						goto IL_0d3e;
																																					case 43:
																																						goto IL_0d4c;
																																					case 255:
																																						goto IL_0d5f;
																																					case 91:
																																					case 256:
																																						goto IL_0d81;
																																					case 22:
																																						goto IL_0dbf;
																																					case 261:
																																						goto IL_0ddb;
																																					case 54:
																																					case 125:
																																						goto IL_0de9;
																																					case 70:
																																						goto IL_0e0b;
																																					case 133:
																																						goto IL_0e19;
																																					case 164:
																																						goto IL_0e30;
																																					case 262:
																																						goto IL_0e43;
																																					case 51:
																																						goto IL_0e4e;
																																					case 217:
																																					case 242:
																																						goto IL_0e5c;
																																					case 138:
																																						goto IL_0e74;
																																					case 31:
																																						goto IL_0ea0;
																																					case 129:
																																						goto IL_0eae;
																																					case 263:
																																						goto IL_0eca;
																																					case 205:
																																						goto IL_0ed8;
																																					case 213:
																																					case 227:
																																						goto IL_0ee6;
																																					case 93:
																																						goto IL_0f0f;
																																					case 238:
																																						goto IL_0f1d;
																																					case 266:
																																						goto IL_0f30;
																																					case 142:
																																					case 148:
																																						goto IL_0f3e;
																																					case 267:
																																						goto IL_0f6d;
																																					case 37:
																																					case 157:
																																						goto IL_0f7b;
																																					case 169:
																																						goto IL_0fbb;
																																					case 84:
																																						goto IL_0fcf;
																																					case 268:
																																						goto IL_0fe2;
																																					case 194:
																																						goto IL_0ff0;
																																					case 69:
																																					case 172:
																																						goto IL_0ffe;
																																					case 4:
																																						goto IL_101c;
																																					case 253:
																																						goto IL_102a;
																																					case 214:
																																					case 269:
																																						goto IL_103d;
																																					case 152:
																																						goto IL_104b;
																																					case 166:
																																						goto IL_1063;
																																					case 102:
																																						goto IL_1071;
																																					case 21:
																																					case 270:
																																						goto IL_1084;
																																					case 128:
																																						goto IL_1092;
																																					case 191:
																																						goto IL_10b5;
																																					case 74:
																																						goto IL_10bf;
																																					case 209:
																																						goto IL_10cd;
																																					case 141:
																																					case 274:
																																						goto IL_10e0;
																																					case 140:
																																						goto IL_1124;
																																					case 226:
																																						goto IL_1138;
																																					case 278:
																																						goto IL_114b;
																																					case 56:
																																						goto IL_1159;
																																					case 42:
																																					case 104:
																																						goto IL_1167;
																																					case 147:
																																						goto IL_11a7;
																																					case 143:
																																						goto IL_11bb;
																																					case 279:
																																						goto IL_11ce;
																																					case 280:
																																						goto IL_11e7;
																																					case 247:
																																						goto IL_120b;
																																					case 136:
																																						goto IL_1223;
																																					case 281:
																																						goto IL_1236;
																																					case 81:
																																						goto IL_124a;
																																					case 149:
																																						goto IL_12b2;
																																					case 26:
																																						goto IL_12c0;
																																					case 75:
																																						goto IL_12d3;
																																					case 121:
																																						goto IL_12e1;
																																					case 78:
																																					case 196:
																																						goto IL_12ec;
																																					case 145:
																																						goto IL_1315;
																																					case 241:
																																						goto IL_1323;
																																					case 193:
																																						goto IL_1336;
																																					case 203:
																																						goto IL_1344;
																																					case 58:
																																					case 98:
																																						goto IL_1352;
																																					case 88:
																																						goto IL_136a;
																																					case 176:
																																						goto IL_1378;
																																					case 234:
																																						goto IL_1386;
																																					case 215:
																																						goto IL_1396;
																																					case 167:
																																						goto IL_13a1;
																																					case 0:
																																					case 33:
																																						goto IL_13ac;
																																					case 258:
																																						goto IL_13c5;
																																					case 198:
																																						goto IL_13d0;
																																					case 1:
																																					case 5:
																																					case 11:
																																					case 16:
																																					case 19:
																																					case 23:
																																					case 40:
																																					case 55:
																																					case 62:
																																					case 67:
																																					case 77:
																																					case 85:
																																					case 86:
																																					case 87:
																																					case 92:
																																					case 109:
																																					case 122:
																																					case 127:
																																					case 131:
																																					case 132:
																																					case 135:
																																					case 144:
																																					case 159:
																																					case 162:
																																					case 165:
																																					case 177:
																																					case 183:
																																					case 184:
																																					case 202:
																																					case 210:
																																					case 212:
																																					case 228:
																																					case 232:
																																					case 237:
																																					case 243:
																																					case 271:
																																						goto end_IL_04c1;
																																					case 13:
																																					case 20:
																																					case 28:
																																					case 30:
																																					case 41:
																																					case 46:
																																					case 49:
																																					case 59:
																																					case 64:
																																					case 71:
																																					case 89:
																																					case 96:
																																					case 101:
																																					case 123:
																																					case 130:
																																					case 137:
																																					case 154:
																																					case 163:
																																					case 174:
																																					case 180:
																																					case 188:
																																					case 189:
																																					case 207:
																																					case 211:
																																					case 216:
																																					case 221:
																																					case 222:
																																					case 236:
																																					case 244:
																																					case 245:
																																					case 248:
																																					case 257:
																																					case 259:
																																					case 260:
																																					case 276:
																																					case 277:
																																						goto end_IL_048f;
																																					case 107:
																																						goto IL_140a;
																																					case 150:
																																						goto IL_1414;
																																					case 251:
																																						goto IL_1428;
																																					case 8:
																																						goto IL_1438;
																																					case 265:
																																						goto IL_1448;
																																					case 118:
																																						goto IL_1461;
																																					case 272:
																																						goto IL_1471;
																																					case 106:
																																						goto IL_1481;
																																					case 229:
																																						goto IL_1491;
																																					case 18:
																																						goto IL_14a1;
																																					case 10:
																																						goto IL_14ac;
																																					case 181:
																																						goto IL_14bc;
																																					case 3:
																																					case 204:
																																						return;
																																					}
																																					goto end_IL_13f7;
																																				}
																																				array3[num5 - 2] = ((delegate*<string, string, string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																																				goto IL_12b2;
																																				IL_12b2:
																																				num5--;
																																				goto IL_12c0;
																																				IL_12c0:
																																				ptr2 += 8;
																																				break;
																																				continue;
																																				end_IL_048f:
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_053b;
																																		continue;
																																		end_IL_04c1:
																																		break;
																																		IL_04c1:;
																																	}
																																	break;
																																	IL_04d1:;
																																}
																																break;
																															}
																															goto IL_0566;
																															IL_0cf7:
																															ptr2 += 8;
																															goto IL_0d05;
																															IL_0566:
																															if (27 <= b)
																															{
																																goto IL_0894;
																															}
																															goto IL_0ca8;
																															IL_0894:
																															array2[num5 - 2] = 5;
																															goto IL_08a8;
																															IL_08a8:
																															array3[num5 - 2] = ((delegate*<ref float, string, string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)MessageIdPaddingHelpers[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																															goto IL_0d3e;
																															IL_0d3e:
																															num5--;
																															goto IL_0d4c;
																															IL_0d4c:
																															ptr2 += 8;
																															goto end_IL_053b;
																															IL_0ca8:
																															if (26 < b)
																															{
																																break;
																															}
																															goto IL_0cb6;
																															IL_0cb6:
																															if (26 > b)
																															{
																																break;
																															}
																															num = 94;
																															goto IL_0ccd;
																															IL_0d05:
																															num5++;
																															goto end_IL_053b;
																															IL_0ccd:
																															array2[num5] = 15;
																															num = 231;
																															goto IL_0ce4;
																															IL_0ce4:
																															array4[num5] = *(int*)(ptr2 + num3);
																															goto IL_0cf7;
																														}
																														break;
																													}
																													goto IL_0b53;
																													IL_0b8a:
																													ptr2 += 8;
																													goto end_IL_053b;
																													IL_0b53:
																													((delegate*<string, void>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																													goto IL_0b7c;
																													IL_0b7c:
																													num5--;
																													goto IL_0b8a;
																												}
																												break;
																											}
																											goto IL_12d3;
																											IL_13d0:
																											if (33 <= b)
																											{
																											}
																											break;
																											IL_12d3:
																											if (31 >= b)
																											{
																												goto IL_12e1;
																											}
																											goto IL_1396;
																											IL_12e1:
																											if (31 <= b)
																											{
																												goto IL_12ec;
																											}
																											goto IL_1336;
																											IL_12ec:
																											((delegate*<UnityEngine.Object, void>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((Class128)array3[num5 - 1]);
																											goto IL_1315;
																											IL_1315:
																											num5--;
																											goto IL_1323;
																											IL_1323:
																											ptr2 += 8;
																											goto end_IL_053b;
																											IL_1336:
																											if (30 < b)
																											{
																												break;
																											}
																											goto IL_1344;
																											IL_1344:
																											if (30 > b)
																											{
																												break;
																											}
																											goto IL_1352;
																											IL_1352:
																											array3[num5] = array7[*(int*)(ptr2 + num3)];
																											goto IL_136a;
																											IL_136a:
																											array2[num5] = 5;
																											goto IL_1378;
																											IL_1378:
																											num5++;
																											goto IL_1386;
																											IL_1386:
																											ptr2 += 8;
																											goto end_IL_053b;
																											IL_1396:
																											if (32 >= b)
																											{
																												goto IL_13a1;
																											}
																											goto IL_13c5;
																											IL_13a1:
																											if (32 > b)
																											{
																												break;
																											}
																											goto IL_13ac;
																											IL_13ac:
																											num6 = ptr2;
																											num7 = -200;
																											num4 = 1;
																											ptr2 = num6 + num7;
																											goto end_IL_053b;
																											IL_13c5:
																											if (33 < b)
																											{
																												break;
																											}
																											goto IL_13d0;
																										}
																										break;
																									}
																									goto IL_0988;
																									IL_1124:
																									array2[num5 - 2] = 3;
																									goto IL_1138;
																									IL_0988:
																									if (25 <= b)
																									{
																										goto IL_0993;
																									}
																									goto IL_09c0;
																									IL_0993:
																									float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																									goto IL_09ad;
																									IL_09ad:
																									num5--;
																									goto end_IL_053b;
																									IL_09c0:
																									if (21 >= b)
																									{
																										goto IL_09ce;
																									}
																									goto IL_0a73;
																									IL_09ce:
																									if (21 > b)
																									{
																										goto IL_09dc;
																									}
																									goto IL_0b9d;
																									IL_09dc:
																									if (19 >= b)
																									{
																										goto IL_09ea;
																									}
																									goto IL_0b0a;
																									IL_09ea:
																									if (19 > b)
																									{
																										goto IL_09f8;
																									}
																									goto IL_0be5;
																									IL_09f8:
																									if (18 < b)
																									{
																										break;
																									}
																									goto IL_0a06;
																									IL_0a06:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_0a14;
																									IL_0a14:
																									array2[num5 - 1] = 5;
																									goto IL_0a28;
																									IL_0a28:
																									array3[num5 - 1] = ((delegate*<string[], string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																									goto IL_0a60;
																									IL_0a60:
																									ptr2 += 8;
																									goto end_IL_053b;
																									IL_0be5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])();
																									goto IL_0c09;
																									IL_0c09:
																									array2[num5] = 0;
																									goto IL_0c17;
																									IL_0c17:
																									num5++;
																									num = 95;
																									goto IL_0c2e;
																									IL_0c2e:
																									ptr2 += 8;
																									goto end_IL_053b;
																									IL_0b0a:
																									if (20 < b)
																									{
																										break;
																									}
																									goto IL_0b18;
																									IL_0b18:
																									if (20 > b)
																									{
																										break;
																									}
																									goto IL_0b26;
																									IL_0b26:
																									int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0b40;
																									IL_0b40:
																									num5--;
																									goto end_IL_053b;
																									IL_0b9d:
																									array3[num5] = ((delegate*<float[]>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])();
																									goto IL_0bbb;
																									IL_0bbb:
																									array2[num5] = 5;
																									goto IL_0bc9;
																									IL_0bc9:
																									num5++;
																									num = 250;
																									goto IL_0d18;
																									IL_0d18:
																									ptr2 += 8;
																									goto end_IL_053b;
																									IL_0a73:
																									if (23 >= b)
																									{
																										goto IL_0a7e;
																									}
																									goto IL_0ae0;
																									IL_0a7e:
																									if (23 <= b)
																									{
																										goto IL_0a89;
																									}
																									goto IL_0acd;
																									IL_0a89:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																									goto IL_0ab4;
																									IL_0ab4:
																									array2[num5 - 1] = 0;
																									goto end_IL_053b;
																									IL_0acd:
																									if (22 < b)
																									{
																										break;
																									}
																									goto IL_0f30;
																									IL_0f30:
																									if (22 > b)
																									{
																										break;
																									}
																									goto IL_0f3e;
																									IL_0f3e:
																									*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
																									goto IL_11ce;
																									IL_11ce:
																									array2[num5 - 1] = 2;
																									goto end_IL_053b;
																									IL_0ae0:
																									if (24 < b)
																									{
																										break;
																									}
																									num = 73;
																									goto IL_0af7;
																									IL_1138:
																									num5--;
																									goto end_IL_053b;
																									IL_0af7:
																									if (24 > b)
																									{
																										break;
																									}
																									goto IL_10e0;
																									IL_10e0:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																									goto IL_1124;
																								}
																								break;
																							}
																							goto IL_0579;
																							IL_103d:
																							array2[num5] = 5;
																							goto IL_104b;
																							IL_0579:
																							if (17 > b)
																							{
																								goto IL_0587;
																							}
																							goto IL_0d81;
																							IL_0587:
																							if (8 >= b)
																							{
																								goto IL_0592;
																							}
																							goto IL_05cf;
																							IL_0592:
																							if (8 > b)
																							{
																								goto IL_05a0;
																							}
																							goto IL_0776;
																							IL_05a0:
																							if (4 >= b)
																							{
																								goto IL_05ae;
																							}
																							goto IL_0807;
																							IL_05ae:
																							if (4 > b)
																							{
																								goto IL_05bc;
																							}
																							goto IL_1084;
																							IL_05bc:
																							if (2 >= b)
																							{
																								goto IL_0789;
																							}
																							goto IL_0eca;
																							IL_0789:
																							if (2 <= b)
																							{
																								goto IL_0797;
																							}
																							goto IL_0881;
																							IL_0797:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							num = 103;
																							goto IL_07e0;
																							IL_07e0:
																							array2[num5 - 2] = 0;
																							goto IL_07f4;
																							IL_07f4:
																							num5--;
																							goto end_IL_053b;
																							IL_0881:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0ddb;
																							IL_0ddb:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0de9;
																							IL_0de9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																							num = 70;
																							goto IL_0e0b;
																							IL_0e0b:
																							array2[num5] = 0;
																							goto IL_0e19;
																							IL_0e19:
																							num5++;
																							num = 164;
																							goto IL_0e30;
																							IL_0e30:
																							ptr2 += 8;
																							goto end_IL_053b;
																							IL_0eca:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0ed8;
																							IL_0ed8:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0ee6;
																							IL_0ee6:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0f0f;
																							IL_0f0f:
																							ptr2 += 8;
																							goto IL_0f1d;
																							IL_0f1d:
																							num5--;
																							goto end_IL_053b;
																							IL_1084:
																							array2[num5] = 0;
																							goto IL_1092;
																							IL_1092:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_10b5;
																							IL_10b5:
																							array3[num5] = null;
																							goto IL_10bf;
																							IL_10bf:
																							num5++;
																							goto IL_10cd;
																							IL_10cd:
																							ptr2 += 8;
																							goto end_IL_053b;
																							IL_0807:
																							if (6 >= b)
																							{
																								goto IL_0815;
																							}
																							goto IL_114b;
																							IL_0815:
																							if (6 <= b)
																							{
																								goto IL_0820;
																							}
																							goto IL_0865;
																							IL_0820:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_1236;
																							IL_1236:
																							array2[num5 - 2] = 0;
																							goto IL_124a;
																							IL_124a:
																							num5--;
																							num = 49;
																							goto end_IL_053b;
																							IL_0865:
																							if (5 < b)
																							{
																								break;
																							}
																							num = 267;
																							goto IL_0f6d;
																							IL_104b:
																							array3[num5] = array7[*(int*)(ptr2 + num3)];
																							goto IL_1063;
																							IL_0f6d:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0f7b;
																							IL_0f7b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0fbb;
																							IL_0fbb:
																							array2[num5 - 2] = 0;
																							goto IL_0fcf;
																							IL_0fcf:
																							num5--;
																							goto end_IL_053b;
																							IL_114b:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_1159;
																							IL_1159:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_1167;
																							IL_1167:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_11a7;
																							IL_11a7:
																							array2[num5 - 2] = 0;
																							goto IL_11bb;
																							IL_11bb:
																							num5--;
																							goto end_IL_053b;
																							IL_0776:
																							num5--;
																							goto end_IL_053b;
																							IL_05cf:
																							if (12 >= b)
																							{
																								goto IL_05dd;
																							}
																							goto IL_093e;
																							IL_05dd:
																							if (12 <= b)
																							{
																								goto IL_05eb;
																							}
																							goto IL_06b2;
																							IL_05eb:
																							array8 = array3;
																							num8 = num5;
																							if (array == null)
																							{
																								goto IL_05fa;
																							}
																							num9 = ptr2;
																							byte b2 = *num9;
																							ptr2 = num9 + 4;
																							int num10 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num10;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_06a2;
																							IL_1063:
																							num5++;
																							goto IL_1071;
																							IL_1071:
																							ptr2 += 8;
																							goto end_IL_053b;
																							IL_0d81:
																							((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																							goto IL_0dbf;
																							IL_06a2:
																							array2[num5] = 5;
																							goto IL_06fc;
																							IL_06fc:
																							num5++;
																							goto end_IL_053b;
																							IL_06b2:
																							if (10 < b)
																							{
																								goto IL_06bd;
																							}
																							goto IL_06de;
																							IL_06bd:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_06cb;
																							IL_06cb:
																							if (11 > b)
																							{
																								break;
																							}
																							goto end_IL_053b;
																							IL_06de:
																							if (10 > b)
																							{
																								goto IL_06e9;
																							}
																							goto IL_070f;
																							IL_06e9:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_092b;
																							IL_092b:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0c41;
																							IL_0c41:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0c81;
																							IL_0c81:
																							array2[num5 - 2] = 0;
																							goto IL_0c95;
																							IL_0c95:
																							num5--;
																							goto end_IL_053b;
																							IL_070f:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0d2b;
																							IL_0d2b:
																							num5 -= 2;
																							goto end_IL_053b;
																							IL_093e:
																							if (14 >= b)
																							{
																								goto IL_094c;
																							}
																							goto IL_0e43;
																							IL_094c:
																							if (14 <= b)
																							{
																								goto IL_095a;
																							}
																							goto IL_0fe2;
																							IL_095a:
																							array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																							goto IL_0d5f;
																							IL_0d5f:
																							array2[num5 - 1] = 5;
																							num = 41;
																							goto end_IL_053b;
																							IL_0fe2:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0ff0;
																							IL_0ff0:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0ffe;
																							IL_0ffe:
																							array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																							goto IL_101c;
																							IL_101c:
																							ptr2 += 8;
																							goto IL_102a;
																							IL_102a:
																							num5--;
																							goto end_IL_053b;
																							IL_0e43:
																							if (15 >= b)
																							{
																								goto IL_0e4e;
																							}
																							goto IL_0ea0;
																							IL_0e4e:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0e5c;
																							IL_0e5c:
																							array2[num5] = array2[num5 - 1];
																							goto IL_0e74;
																							IL_0e74:
																							array4[num5 - 0] = array4[num5 - 1];
																							num = 280;
																							goto IL_11e7;
																							IL_11e7:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_120b;
																							IL_120b:
																							array3[num5] = array3[num5 - 1];
																							goto IL_1223;
																							IL_1223:
																							num5++;
																							goto end_IL_053b;
																							IL_0ea0:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0eae;
																							IL_0eae:
																							if (16 > b)
																							{
																								break;
																							}
																							num = 269;
																							goto IL_103d;
																							IL_0dbf:
																							num5 -= 3;
																							num = 189;
																							goto end_IL_053b;
																						}
																						break;
																						IL_052b:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 101;
																				break;
																				continue;
																				end_IL_053b:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_13f7:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_05fa:
			while (true)
			{
				IL_05fa_2:
				array = new byte[4];
				while (true)
				{
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_06a2_2:
						array2[num5] = 5;
						while (true)
						{
							IL_06fc_2:
							num5++;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_055b_2:
									byte b = *ptr2;
									while (true)
									{
										IL_054b_2:
										ptr2++;
										while (true)
										{
											IL_053b_2:
											if (b >= 1)
											{
												while (b <= 33)
												{
													while (true)
													{
														IL_051e_2:
														if (17 < b)
														{
															while (true)
															{
																IL_050e_2:
																if (25 < b)
																{
																	while (true)
																	{
																		IL_04fe_2:
																		if (29 >= b)
																		{
																			while (true)
																			{
																				IL_04ee_2:
																				if (29 > b)
																				{
																					while (true)
																					{
																						IL_04e1_2:
																						if (27 < b)
																						{
																							while (28 >= b)
																							{
																								while (28 <= b)
																								{
																									while (true)
																									{
																										IL_04a2_2:
																										array2[num5 - 2] = 5;
																										num = 288;
																										while (true)
																										{
																											if (num != 288)
																											{
																												if (num != 1269)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 151:
																												case 273:
																													goto IL_04a2_2;
																												case 61:
																													goto IL_04c1_2;
																												case 83:
																													goto IL_04d1_2;
																												case 275:
																													goto IL_04e1_2;
																												case 68:
																													goto IL_04ee_2;
																												case 113:
																													goto IL_04fe_2;
																												case 264:
																													goto IL_050e_2;
																												case 173:
																													goto IL_051e_2;
																												case 111:
																													goto IL_052b_2;
																												case 2:
																													goto IL_053b_2;
																												case 139:
																													goto IL_054b_2;
																												case 57:
																												case 200:
																													goto IL_055b_2;
																												case 63:
																													goto IL_0566_2;
																												case 120:
																													goto IL_0579_2;
																												case 115:
																													goto IL_0587_2;
																												case 9:
																													goto IL_0592_2;
																												case 134:
																													goto IL_05a0_2;
																												case 146:
																													goto IL_05ae_2;
																												case 112:
																													goto IL_05bc_2;
																												case 160:
																													goto IL_05cf_2;
																												case 108:
																													goto IL_05dd_2;
																												case 25:
																												case 44:
																													goto end_IL_13f7_2;
																												case 65:
																													goto IL_06a2_2;
																												case 114:
																													goto IL_06b2_2;
																												case 32:
																													goto IL_06bd_2;
																												case 15:
																													goto IL_06cb_2;
																												case 29:
																													goto IL_06de_2;
																												case 24:
																													goto IL_06e9_2;
																												case 171:
																													goto IL_06fc_2;
																												case 36:
																												case 175:
																													goto IL_070f_2;
																												case 119:
																												case 178:
																													goto IL_0776_2;
																												case 190:
																													goto IL_0789_2;
																												case 47:
																												case 48:
																													goto IL_0797_2;
																												case 103:
																													goto IL_07e0_2;
																												case 7:
																													goto IL_07f4_2;
																												case 192:
																													goto IL_0807_2;
																												case 186:
																													goto IL_0815_2;
																												case 45:
																												case 116:
																													goto IL_0820_2;
																												case 156:
																													goto IL_0865_2;
																												case 199:
																													goto IL_0881_2;
																												case 38:
																												case 208:
																													goto IL_0894_2;
																												case 39:
																													goto IL_08a8_2;
																												case 220:
																													goto IL_092b_2;
																												case 223:
																													goto IL_093e_2;
																												case 60:
																													goto IL_094c_2;
																												case 100:
																												case 206:
																													goto IL_095a_2;
																												case 224:
																													goto IL_0988_2;
																												case 72:
																												case 76:
																													goto IL_0993_2;
																												case 99:
																													goto IL_09ad_2;
																												case 185:
																													goto IL_09c0_2;
																												case 201:
																													goto IL_09ce_2;
																												case 66:
																													goto IL_09dc_2;
																												case 90:
																													goto IL_09ea_2;
																												case 187:
																													goto IL_09f8_2;
																												case 110:
																													goto IL_0a06_2;
																												case 35:
																												case 97:
																													goto IL_0a14_2;
																												case 105:
																													goto IL_0a28_2;
																												case 50:
																													goto IL_0a60_2;
																												case 80:
																													goto IL_0a73_2;
																												case 6:
																													goto IL_0a7e_2;
																												case 52:
																												case 218:
																													goto IL_0a89_2;
																												case 126:
																													goto IL_0ab4_2;
																												case 117:
																													goto IL_0acd_2;
																												case 168:
																													goto IL_0ae0_2;
																												case 73:
																													goto IL_0af7_2;
																												case 225:
																													goto IL_0b0a_2;
																												case 155:
																													goto IL_0b18_2;
																												case 195:
																												case 230:
																													goto IL_0b26_2;
																												case 34:
																													goto IL_0b40_2;
																												case 219:
																												case 233:
																													goto IL_0b53_2;
																												case 197:
																													goto IL_0b7c_2;
																												case 82:
																													goto IL_0b8a_2;
																												case 12:
																												case 239:
																													goto IL_0b9d_2;
																												case 179:
																													goto IL_0bbb_2;
																												case 161:
																													goto IL_0bc9_2;
																												case 53:
																												case 240:
																													goto IL_0be5_2;
																												case 17:
																													goto IL_0c09_2;
																												case 27:
																													goto IL_0c17_2;
																												case 95:
																													goto IL_0c2e_2;
																												case 235:
																												case 246:
																													goto IL_0c41_2;
																												case 124:
																													goto IL_0c81_2;
																												case 170:
																													goto IL_0c95_2;
																												case 249:
																													goto IL_0ca8_2;
																												case 158:
																													goto IL_0cb6_2;
																												case 79:
																												case 94:
																													goto IL_0ccd_2;
																												case 231:
																													goto IL_0ce4_2;
																												case 153:
																													goto IL_0cf7_2;
																												case 14:
																													goto IL_0d05_2;
																												case 250:
																													goto IL_0d18_2;
																												case 252:
																													goto IL_0d2b_2;
																												case 254:
																													goto IL_0d3e_2;
																												case 43:
																													goto IL_0d4c_2;
																												case 255:
																													goto IL_0d5f_2;
																												case 91:
																												case 256:
																													goto IL_0d81_2;
																												case 22:
																													goto IL_0dbf_2;
																												case 261:
																													goto IL_0ddb_2;
																												case 54:
																												case 125:
																													goto IL_0de9_2;
																												case 70:
																													goto IL_0e0b_2;
																												case 133:
																													goto IL_0e19_2;
																												case 164:
																													goto IL_0e30_2;
																												case 262:
																													goto IL_0e43_2;
																												case 51:
																													goto IL_0e4e_2;
																												case 217:
																												case 242:
																													goto IL_0e5c_2;
																												case 138:
																													goto IL_0e74_2;
																												case 31:
																													goto IL_0ea0_2;
																												case 129:
																													goto IL_0eae_2;
																												case 263:
																													goto IL_0eca_2;
																												case 205:
																													goto IL_0ed8_2;
																												case 213:
																												case 227:
																													goto IL_0ee6_2;
																												case 93:
																													goto IL_0f0f_2;
																												case 238:
																													goto IL_0f1d_2;
																												case 266:
																													goto IL_0f30_2;
																												case 142:
																												case 148:
																													goto IL_0f3e_2;
																												case 267:
																													goto IL_0f6d_2;
																												case 37:
																												case 157:
																													goto IL_0f7b_2;
																												case 169:
																													goto IL_0fbb_2;
																												case 84:
																													goto IL_0fcf_2;
																												case 268:
																													goto IL_0fe2_2;
																												case 194:
																													goto IL_0ff0_2;
																												case 69:
																												case 172:
																													goto IL_0ffe_2;
																												case 4:
																													goto IL_101c_2;
																												case 253:
																													goto IL_102a_2;
																												case 214:
																												case 269:
																													goto IL_103d_2;
																												case 152:
																													goto IL_104b_2;
																												case 166:
																													goto IL_1063_2;
																												case 102:
																													goto IL_1071_2;
																												case 21:
																												case 270:
																													goto IL_1084_2;
																												case 128:
																													goto IL_1092_2;
																												case 191:
																													goto IL_10b5_2;
																												case 74:
																													goto IL_10bf_2;
																												case 209:
																													goto IL_10cd_2;
																												case 141:
																												case 274:
																													goto IL_10e0_2;
																												case 140:
																													goto IL_1124_2;
																												case 226:
																													goto IL_1138_2;
																												case 278:
																													goto IL_114b_2;
																												case 56:
																													goto IL_1159_2;
																												case 42:
																												case 104:
																													goto IL_1167_2;
																												case 147:
																													goto IL_11a7_2;
																												case 143:
																													goto IL_11bb_2;
																												case 279:
																													goto IL_11ce_2;
																												case 280:
																													goto IL_11e7_2;
																												case 247:
																													goto IL_120b_2;
																												case 136:
																													goto IL_1223_2;
																												case 281:
																													goto IL_1236_2;
																												case 81:
																													goto IL_124a_2;
																												case 149:
																													goto IL_12b2_2;
																												case 26:
																													goto IL_12c0_2;
																												case 75:
																													goto IL_12d3_2;
																												case 121:
																													goto IL_12e1_2;
																												case 78:
																												case 196:
																													goto IL_12ec_2;
																												case 145:
																													goto IL_1315_2;
																												case 241:
																													goto IL_1323_2;
																												case 193:
																													goto IL_1336_2;
																												case 203:
																													goto IL_1344_2;
																												case 58:
																												case 98:
																													goto IL_1352_2;
																												case 88:
																													goto IL_136a_2;
																												case 176:
																													goto IL_1378_2;
																												case 234:
																													goto IL_1386_2;
																												case 215:
																													goto IL_1396_2;
																												case 167:
																													goto IL_13a1_2;
																												case 0:
																												case 33:
																													goto IL_13ac_2;
																												case 258:
																													goto IL_13c5_2;
																												case 198:
																													goto IL_13d0_2;
																												case 1:
																												case 5:
																												case 11:
																												case 16:
																												case 19:
																												case 23:
																												case 40:
																												case 55:
																												case 62:
																												case 67:
																												case 77:
																												case 85:
																												case 86:
																												case 87:
																												case 92:
																												case 109:
																												case 122:
																												case 127:
																												case 131:
																												case 132:
																												case 135:
																												case 144:
																												case 159:
																												case 162:
																												case 165:
																												case 177:
																												case 183:
																												case 184:
																												case 202:
																												case 210:
																												case 212:
																												case 228:
																												case 232:
																												case 237:
																												case 243:
																												case 271:
																													goto end_IL_04c1_2;
																												case 13:
																												case 20:
																												case 28:
																												case 30:
																												case 41:
																												case 46:
																												case 49:
																												case 59:
																												case 64:
																												case 71:
																												case 89:
																												case 96:
																												case 101:
																												case 123:
																												case 130:
																												case 137:
																												case 154:
																												case 163:
																												case 174:
																												case 180:
																												case 188:
																												case 189:
																												case 207:
																												case 211:
																												case 216:
																												case 221:
																												case 222:
																												case 236:
																												case 244:
																												case 245:
																												case 248:
																												case 257:
																												case 259:
																												case 260:
																												case 276:
																												case 277:
																													goto end_IL_048f_2;
																												case 107:
																													ptr2 = ptr;
																													goto end_IL_048f_2;
																												case 150:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TplEtwProviderMissingMethodException.SubjectVersioningHelper);
																													num = 107;
																													goto case 107;
																												case 251:
																													array7[0] = this;
																													goto case 150;
																												case 8:
																													array7 = new object[13];
																													goto case 251;
																												case 265:
																													array6 = new long[4];
																													num = 8;
																													goto case 8;
																												case 118:
																													array5 = new int[6];
																													goto case 265;
																												case 272:
																													array4 = new int[4];
																													goto case 118;
																												case 106:
																													array3 = new object[4];
																													goto case 272;
																												case 229:
																													array2 = new byte[4];
																													goto case 106;
																												case 18:
																													num = 229;
																													goto case 229;
																												case 10:
																													num3 = num2 * 4;
																													goto case 18;
																												case 181:
																													num2 = 1;
																													goto case 10;
																												case 182:
																													goto end_IL_0608;
																												case 3:
																												case 204:
																													return;
																												}
																												continue;
																											}
																											array3[num5 - 2] = ((delegate*<string, string, string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																											goto IL_12b2_2;
																											IL_12b2_2:
																											num5--;
																											goto IL_12c0_2;
																											IL_12c0_2:
																											ptr2 += 8;
																											break;
																											continue;
																											end_IL_048f_2:
																											break;
																										}
																										break;
																									}
																									goto end_IL_053b_2;
																									continue;
																									end_IL_04c1_2:
																									break;
																									IL_04c1_2:;
																								}
																								break;
																								IL_04d1_2:;
																							}
																							break;
																						}
																						goto IL_0566_2;
																						IL_0cf7_2:
																						ptr2 += 8;
																						goto IL_0d05_2;
																						IL_0566_2:
																						if (27 <= b)
																						{
																							goto IL_0894_2;
																						}
																						goto IL_0ca8_2;
																						IL_0894_2:
																						array2[num5 - 2] = 5;
																						goto IL_08a8_2;
																						IL_08a8_2:
																						array3[num5 - 2] = ((delegate*<ref float, string, string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)MessageIdPaddingHelpers[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																						goto IL_0d3e_2;
																						IL_0d3e_2:
																						num5--;
																						goto IL_0d4c_2;
																						IL_0d4c_2:
																						ptr2 += 8;
																						goto end_IL_053b_2;
																						IL_0ca8_2:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0cb6_2;
																						IL_0cb6_2:
																						if (26 > b)
																						{
																							break;
																						}
																						num = 94;
																						goto IL_0ccd_2;
																						IL_0d05_2:
																						num5++;
																						goto end_IL_053b_2;
																						IL_0ccd_2:
																						array2[num5] = 15;
																						num = 231;
																						goto IL_0ce4_2;
																						IL_0ce4_2:
																						array4[num5] = *(int*)(ptr2 + num3);
																						goto IL_0cf7_2;
																					}
																					break;
																				}
																				goto IL_0b53_2;
																				IL_0b8a_2:
																				ptr2 += 8;
																				goto end_IL_053b_2;
																				IL_0b53_2:
																				((delegate*<string, void>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																				goto IL_0b7c_2;
																				IL_0b7c_2:
																				num5--;
																				goto IL_0b8a_2;
																			}
																			break;
																		}
																		goto IL_12d3_2;
																		IL_13d0_2:
																		if (33 <= b)
																		{
																		}
																		break;
																		IL_12d3_2:
																		if (31 >= b)
																		{
																			goto IL_12e1_2;
																		}
																		goto IL_1396_2;
																		IL_12e1_2:
																		if (31 <= b)
																		{
																			goto IL_12ec_2;
																		}
																		goto IL_1336_2;
																		IL_12ec_2:
																		((delegate*<UnityEngine.Object, void>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((Class128)array3[num5 - 1]);
																		goto IL_1315_2;
																		IL_1315_2:
																		num5--;
																		goto IL_1323_2;
																		IL_1323_2:
																		ptr2 += 8;
																		goto end_IL_053b_2;
																		IL_1336_2:
																		if (30 < b)
																		{
																			break;
																		}
																		goto IL_1344_2;
																		IL_1344_2:
																		if (30 > b)
																		{
																			break;
																		}
																		goto IL_1352_2;
																		IL_1352_2:
																		array3[num5] = array7[*(int*)(ptr2 + num3)];
																		goto IL_136a_2;
																		IL_136a_2:
																		array2[num5] = 5;
																		goto IL_1378_2;
																		IL_1378_2:
																		num5++;
																		goto IL_1386_2;
																		IL_1386_2:
																		ptr2 += 8;
																		goto end_IL_053b_2;
																		IL_1396_2:
																		if (32 >= b)
																		{
																			goto IL_13a1_2;
																		}
																		goto IL_13c5_2;
																		IL_13a1_2:
																		if (32 > b)
																		{
																			break;
																		}
																		goto IL_13ac_2;
																		IL_13ac_2:
																		num6 = ptr2;
																		num7 = -200;
																		num4 = 1;
																		ptr2 = num6 + num7;
																		goto end_IL_053b_2;
																		IL_13c5_2:
																		if (33 < b)
																		{
																			break;
																		}
																		goto IL_13d0_2;
																	}
																	break;
																}
																goto IL_0988_2;
																IL_1124_2:
																array2[num5 - 2] = 3;
																goto IL_1138_2;
																IL_0988_2:
																if (25 <= b)
																{
																	goto IL_0993_2;
																}
																goto IL_09c0_2;
																IL_0993_2:
																float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_09ad_2;
																IL_09ad_2:
																num5--;
																goto end_IL_053b_2;
																IL_09c0_2:
																if (21 >= b)
																{
																	goto IL_09ce_2;
																}
																goto IL_0a73_2;
																IL_09ce_2:
																if (21 > b)
																{
																	goto IL_09dc_2;
																}
																goto IL_0b9d_2;
																IL_09dc_2:
																if (19 >= b)
																{
																	goto IL_09ea_2;
																}
																goto IL_0b0a_2;
																IL_09ea_2:
																if (19 > b)
																{
																	goto IL_09f8_2;
																}
																goto IL_0be5_2;
																IL_09f8_2:
																if (18 < b)
																{
																	break;
																}
																goto IL_0a06_2;
																IL_0a06_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_0a14_2;
																IL_0a14_2:
																array2[num5 - 1] = 5;
																goto IL_0a28_2;
																IL_0a28_2:
																array3[num5 - 1] = ((delegate*<string[], string>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																goto IL_0a60_2;
																IL_0a60_2:
																ptr2 += 8;
																goto end_IL_053b_2;
																IL_0be5_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])();
																goto IL_0c09_2;
																IL_0c09_2:
																array2[num5] = 0;
																goto IL_0c17_2;
																IL_0c17_2:
																num5++;
																num = 95;
																goto IL_0c2e_2;
																IL_0c2e_2:
																ptr2 += 8;
																goto end_IL_053b_2;
																IL_0b0a_2:
																if (20 < b)
																{
																	break;
																}
																goto IL_0b18_2;
																IL_0b18_2:
																if (20 > b)
																{
																	break;
																}
																goto IL_0b26_2;
																IL_0b26_2:
																int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0b40_2;
																IL_0b40_2:
																num5--;
																goto end_IL_053b_2;
																IL_0b9d_2:
																array3[num5] = ((delegate*<float[]>)MessageIdPaddingHelpers[*(int*)(ptr2 + num3)])();
																goto IL_0bbb_2;
																IL_0bbb_2:
																array2[num5] = 5;
																goto IL_0bc9_2;
																IL_0bc9_2:
																num5++;
																num = 250;
																goto IL_0d18_2;
																IL_0d18_2:
																ptr2 += 8;
																goto end_IL_053b_2;
																IL_0a73_2:
																if (23 >= b)
																{
																	goto IL_0a7e_2;
																}
																goto IL_0ae0_2;
																IL_0a7e_2:
																if (23 <= b)
																{
																	goto IL_0a89_2;
																}
																goto IL_0acd_2;
																IL_0a89_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_0ab4_2;
																IL_0ab4_2:
																array2[num5 - 1] = 0;
																goto end_IL_053b_2;
																IL_0acd_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_0f30_2;
																IL_0f30_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_0f3e_2;
																IL_0f3e_2:
																*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
																goto IL_11ce_2;
																IL_11ce_2:
																array2[num5 - 1] = 2;
																goto end_IL_053b_2;
																IL_0ae0_2:
																if (24 < b)
																{
																	break;
																}
																num = 73;
																goto IL_0af7_2;
																IL_1138_2:
																num5--;
																goto end_IL_053b_2;
																IL_0af7_2:
																if (24 > b)
																{
																	break;
																}
																goto IL_10e0_2;
																IL_10e0_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																goto IL_1124_2;
															}
															break;
														}
														goto IL_0579_2;
														IL_1071_2:
														ptr2 += 8;
														goto end_IL_053b_2;
														IL_0579_2:
														if (17 > b)
														{
															goto IL_0587_2;
														}
														goto IL_0d81_2;
														IL_0587_2:
														if (8 >= b)
														{
															goto IL_0592_2;
														}
														goto IL_05cf_2;
														IL_0592_2:
														if (8 > b)
														{
															goto IL_05a0_2;
														}
														goto IL_0776_2;
														IL_05a0_2:
														if (4 >= b)
														{
															goto IL_05ae_2;
														}
														goto IL_0807_2;
														IL_05ae_2:
														if (4 > b)
														{
															goto IL_05bc_2;
														}
														goto IL_1084_2;
														IL_05bc_2:
														if (2 >= b)
														{
															goto IL_0789_2;
														}
														goto IL_0eca_2;
														IL_0789_2:
														if (2 <= b)
														{
															goto IL_0797_2;
														}
														goto IL_0881_2;
														IL_0797_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 103;
														goto IL_07e0_2;
														IL_07e0_2:
														array2[num5 - 2] = 0;
														goto IL_07f4_2;
														IL_07f4_2:
														num5--;
														goto end_IL_053b_2;
														IL_0881_2:
														if (1 < b)
														{
															break;
														}
														goto IL_0ddb_2;
														IL_0ddb_2:
														if (1 > b)
														{
															break;
														}
														goto IL_0de9_2;
														IL_0de9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
														num = 70;
														goto IL_0e0b_2;
														IL_0e0b_2:
														array2[num5] = 0;
														goto IL_0e19_2;
														IL_0e19_2:
														num5++;
														num = 164;
														goto IL_0e30_2;
														IL_0e30_2:
														ptr2 += 8;
														goto end_IL_053b_2;
														IL_0eca_2:
														if (3 < b)
														{
															break;
														}
														goto IL_0ed8_2;
														IL_0ed8_2:
														if (3 > b)
														{
															break;
														}
														goto IL_0ee6_2;
														IL_0ee6_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0f0f_2;
														IL_0f0f_2:
														ptr2 += 8;
														goto IL_0f1d_2;
														IL_0f1d_2:
														num5--;
														goto end_IL_053b_2;
														IL_1084_2:
														array2[num5] = 0;
														goto IL_1092_2;
														IL_1092_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
														goto IL_10b5_2;
														IL_10b5_2:
														array3[num5] = null;
														goto IL_10bf_2;
														IL_10bf_2:
														num5++;
														goto IL_10cd_2;
														IL_10cd_2:
														ptr2 += 8;
														goto end_IL_053b_2;
														IL_0807_2:
														if (6 >= b)
														{
															goto IL_0815_2;
														}
														goto IL_114b_2;
														IL_0815_2:
														if (6 <= b)
														{
															goto IL_0820_2;
														}
														goto IL_0865_2;
														IL_0820_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_1236_2;
														IL_1236_2:
														array2[num5 - 2] = 0;
														goto IL_124a_2;
														IL_124a_2:
														num5--;
														num = 49;
														goto end_IL_053b_2;
														IL_0865_2:
														if (5 < b)
														{
															break;
														}
														num = 267;
														goto IL_0f6d_2;
														IL_0d81_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														goto IL_0dbf_2;
														IL_0f6d_2:
														if (5 > b)
														{
															break;
														}
														goto IL_0f7b_2;
														IL_0f7b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0fbb_2;
														IL_0fbb_2:
														array2[num5 - 2] = 0;
														goto IL_0fcf_2;
														IL_0fcf_2:
														num5--;
														goto end_IL_053b_2;
														IL_114b_2:
														if (7 < b)
														{
															break;
														}
														goto IL_1159_2;
														IL_1159_2:
														if (7 > b)
														{
															break;
														}
														goto IL_1167_2;
														IL_1167_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_11a7_2;
														IL_11a7_2:
														array2[num5 - 2] = 0;
														goto IL_11bb_2;
														IL_11bb_2:
														num5--;
														goto end_IL_053b_2;
														IL_0776_2:
														num5--;
														goto end_IL_053b_2;
														IL_05cf_2:
														if (12 >= b)
														{
															goto IL_05dd_2;
														}
														goto IL_093e_2;
														IL_05dd_2:
														if (12 <= b)
														{
															goto end_IL_13f7_2;
														}
														goto IL_06b2_2;
														IL_06b2_2:
														if (10 < b)
														{
															goto IL_06bd_2;
														}
														goto IL_06de_2;
														IL_06bd_2:
														if (11 < b)
														{
															break;
														}
														goto IL_06cb_2;
														IL_06cb_2:
														if (11 > b)
														{
															break;
														}
														goto end_IL_053b_2;
														IL_06de_2:
														if (10 > b)
														{
															goto IL_06e9_2;
														}
														goto IL_070f_2;
														IL_06e9_2:
														if (9 < b)
														{
															break;
														}
														goto IL_092b_2;
														IL_092b_2:
														if (9 > b)
														{
															break;
														}
														goto IL_0c41_2;
														IL_0c41_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0c81_2;
														IL_0c81_2:
														array2[num5 - 2] = 0;
														goto IL_0c95_2;
														IL_0c95_2:
														num5--;
														goto end_IL_053b_2;
														IL_070f_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0d2b_2;
														IL_0d2b_2:
														num5 -= 2;
														goto end_IL_053b_2;
														IL_093e_2:
														if (14 >= b)
														{
															goto IL_094c_2;
														}
														goto IL_0e43_2;
														IL_094c_2:
														if (14 <= b)
														{
															goto IL_095a_2;
														}
														goto IL_0fe2_2;
														IL_095a_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0d5f_2;
														IL_0d5f_2:
														array2[num5 - 1] = 5;
														num = 41;
														goto end_IL_053b_2;
														IL_0fe2_2:
														if (13 < b)
														{
															break;
														}
														goto IL_0ff0_2;
														IL_0ff0_2:
														if (13 > b)
														{
															break;
														}
														goto IL_0ffe_2;
														IL_0ffe_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_101c_2;
														IL_101c_2:
														ptr2 += 8;
														goto IL_102a_2;
														IL_102a_2:
														num5--;
														goto end_IL_053b_2;
														IL_0e43_2:
														if (15 >= b)
														{
															goto IL_0e4e_2;
														}
														goto IL_0ea0_2;
														IL_0e4e_2:
														if (15 > b)
														{
															break;
														}
														goto IL_0e5c_2;
														IL_0e5c_2:
														array2[num5] = array2[num5 - 1];
														goto IL_0e74_2;
														IL_0e74_2:
														array4[num5 - 0] = array4[num5 - 1];
														num = 280;
														goto IL_11e7_2;
														IL_11e7_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_120b_2;
														IL_120b_2:
														array3[num5] = array3[num5 - 1];
														goto IL_1223_2;
														IL_1223_2:
														num5++;
														goto end_IL_053b_2;
														IL_0ea0_2:
														if (16 < b)
														{
															break;
														}
														goto IL_0eae_2;
														IL_0eae_2:
														if (16 > b)
														{
															break;
														}
														num = 269;
														goto IL_103d_2;
														IL_0dbf_2:
														num5 -= 3;
														num = 189;
														goto end_IL_053b_2;
														IL_103d_2:
														array2[num5] = 5;
														goto IL_104b_2;
														IL_104b_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_1063_2;
														IL_1063_2:
														num5++;
														goto IL_1071_2;
													}
													break;
													IL_052b_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											num = 101;
											break;
											continue;
											end_IL_053b_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_13f7_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num8 = num5;
					if (array == null)
					{
						goto IL_05fa_2;
					}
					continue;
					end_IL_0608:
					break;
				}
				break;
			}
		}
	}

	public Class128()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class128()
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2 = 1;
					num = 101;
					while (true)
					{
						int num3 = num2 * 4;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[3];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSurrogateSelectorStlocS.getIsMailNewsSaveBoxed);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02c2:
																if (b >= 1)
																{
																	num = 97;
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02a2:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0295:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0285:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0275:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_0265:
																											if (5 > b)
																											{
																												while (4 >= b)
																												{
																													while (4 <= b)
																													{
																														num = 129;
																														while (true)
																														{
																															if (num != 129)
																															{
																																if (num != 1110)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 55:
																																	goto IL_0242;
																																case 45:
																																	goto IL_0255;
																																case 113:
																																	goto IL_0265;
																																case 79:
																																	goto IL_0275;
																																case 6:
																																	goto IL_0285;
																																case 111:
																																	goto IL_0295;
																																case 34:
																																	goto IL_02a2;
																																case 97:
																																	goto IL_02b2;
																																case 24:
																																	goto IL_02c2;
																																case 51:
																																	goto end_IL_02c2;
																																case 15:
																																case 88:
																																	goto end_IL_02d5;
																																case 11:
																																case 12:
																																	goto IL_02f0;
																																case 26:
																																	goto IL_0332;
																																case 8:
																																	goto IL_0340;
																																case 29:
																																	goto IL_0359;
																																case 9:
																																case 41:
																																	goto IL_0372;
																																case 57:
																																	goto IL_038b;
																																case 31:
																																	goto IL_0399;
																																case 72:
																																	goto IL_03ac;
																																case 32:
																																case 77:
																																	goto IL_03b9;
																																case 4:
																																case 81:
																																	goto IL_03d5;
																																case 90:
																																	goto IL_03f4;
																																case 91:
																																	goto IL_0407;
																																case 93:
																																	goto IL_041a;
																																case 42:
																																	goto IL_0425;
																																case 65:
																																	goto end_IL_022f;
																																case 64:
																																	goto IL_0446;
																																case 35:
																																case 83:
																																	goto IL_0454;
																																case 74:
																																	goto IL_0472;
																																case 95:
																																	goto IL_0485;
																																case 16:
																																	goto IL_0493;
																																case 54:
																																	goto IL_04a1;
																																case 112:
																																	goto IL_04b4;
																																case 19:
																																	goto IL_04c7;
																																case 5:
																																	goto IL_04e1;
																																case 7:
																																	goto IL_04f4;
																																case 40:
																																	goto IL_0502;
																																case 20:
																																	goto IL_0510;
																																case 37:
																																case 76:
																																	goto IL_051b;
																																case 106:
																																	goto IL_0534;
																																case 115:
																																	goto IL_0547;
																																case 119:
																																	goto IL_055e;
																																case 69:
																																case 82:
																																	goto IL_056c;
																																case 78:
																																	goto IL_05a9;
																																case 100:
																																	goto IL_05b7;
																																case 60:
																																	goto IL_05d3;
																																case 62:
																																	goto IL_05e1;
																																case 22:
																																case 98:
																																	goto IL_05ef;
																																case 116:
																																	goto IL_0614;
																																case 80:
																																	goto IL_0622;
																																case 49:
																																	goto IL_062d;
																																case 30:
																																case 117:
																																	goto IL_063b;
																																case 23:
																																	goto IL_0664;
																																case 18:
																																	goto IL_067d;
																																case 108:
																																	goto IL_068b;
																																case 89:
																																case 118:
																																	goto IL_0699;
																																case 48:
																																	goto IL_06b1;
																																case 14:
																																	goto IL_06cf;
																																case 109:
																																	goto IL_06f3;
																																case 27:
																																	goto IL_070b;
																																case 2:
																																case 120:
																																	goto IL_071b;
																																case 47:
																																	goto IL_072e;
																																case 3:
																																	goto IL_0745;
																																case 0:
																																case 10:
																																case 25:
																																case 28:
																																case 46:
																																case 56:
																																case 58:
																																case 63:
																																case 66:
																																case 68:
																																case 73:
																																case 75:
																																case 84:
																																case 87:
																																case 102:
																																case 122:
																																	goto end_IL_0242;
																																case 110:
																																	goto IL_076a;
																																case 17:
																																case 33:
																																case 43:
																																case 50:
																																case 59:
																																case 61:
																																case 67:
																																case 70:
																																case 85:
																																case 94:
																																case 103:
																																case 104:
																																case 105:
																																case 114:
																																case 121:
																																	goto end_IL_02e5;
																																case 71:
																																	goto end_IL_0778;
																																case 52:
																																	goto end_IL_078b;
																																case 53:
																																	goto end_IL_0795;
																																case 13:
																																	goto end_IL_07a0;
																																case 99:
																																	goto end_IL_07b0;
																																case 21:
																																case 107:
																																	goto end_IL_07c0;
																																case 101:
																																	goto end_IL_07d0;
																																case 36:
																																case 44:
																																case 86:
																																case 92:
																																	goto end_IL_07e0;
																																case 38:
																																	goto end_IL_07f0;
																																case 39:
																																	goto end_IL_080d;
																																case 1:
																																case 96:
																																	return;
																																}
																																continue;
																															}
																															goto IL_04c7;
																															IL_04c7:
																															float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																															goto IL_04e1;
																															IL_04e1:
																															num5--;
																															goto end_IL_02e5;
																															continue;
																															end_IL_022f:
																															break;
																														}
																														goto IL_0438;
																														continue;
																														end_IL_0242:
																														break;
																														IL_0242:;
																													}
																													break;
																													IL_0255:;
																												}
																												break;
																											}
																											goto IL_0372;
																											IL_04b4:
																											ptr2 += 8;
																											goto end_IL_02e5;
																											IL_0372:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_038b;
																											IL_038b:
																											array[num5] = 0;
																											goto IL_0399;
																											IL_0399:
																											num5++;
																											goto IL_04b4;
																										}
																										break;
																									}
																									goto IL_0332;
																									IL_03b9:
																									int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03f4;
																									IL_0332:
																									if (6 < b)
																									{
																										break;
																									}
																									goto IL_0340;
																									IL_0340:
																									if (6 > b)
																									{
																										break;
																									}
																									num = 77;
																									goto IL_03b9;
																									IL_03f4:
																									num5--;
																									goto end_IL_02e5;
																								}
																								break;
																							}
																							goto IL_03ac;
																							IL_0472:
																							ptr2 += 8;
																							goto end_IL_02e5;
																							IL_03ac:
																							if (3 <= b)
																							{
																								goto IL_03d5;
																							}
																							goto IL_041a;
																							IL_03d5:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																							goto IL_0485;
																							IL_0485:
																							array[num5] = 3;
																							goto IL_0493;
																							IL_0493:
																							num5++;
																							goto IL_04a1;
																							IL_04a1:
																							ptr2 += 8;
																							goto end_IL_02e5;
																							IL_041a:
																							if (1 >= b)
																							{
																								goto IL_0425;
																							}
																							goto IL_0438;
																							IL_0425:
																							if (1 > b)
																							{
																							}
																							break;
																							IL_0438:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0446;
																							IL_0446:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0454;
																							IL_0454:
																							((delegate*<void>)SetApartmentStateLongPath[*(int*)(ptr2 + num3)])();
																							num = 74;
																							goto IL_0472;
																						}
																						break;
																					}
																					goto IL_02f0;
																					IL_0407:
																					num5--;
																					goto end_IL_02e5;
																					IL_02f0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0359;
																					IL_0359:
																					array[num5 - 2] = 0;
																					goto IL_0407;
																				}
																				break;
																			}
																			goto IL_04f4;
																			IL_071b:
																			array2[num5] = default(RuntimeFieldHandle);
																			goto IL_072e;
																			IL_04f4:
																			if (10 < b)
																			{
																				goto IL_0502;
																			}
																			num = 116;
																			goto IL_0614;
																			IL_0502:
																			if (12 >= b)
																			{
																				goto IL_0510;
																			}
																			goto IL_05d3;
																			IL_0510:
																			if (12 <= b)
																			{
																				goto IL_051b;
																			}
																			goto IL_0547;
																			IL_051b:
																			float_1 = (float[])array2[num5 - 1];
																			goto IL_0534;
																			IL_0534:
																			num5--;
																			goto end_IL_02e5;
																			IL_0547:
																			if (11 < b)
																			{
																				break;
																			}
																			num = 119;
																			goto IL_055e;
																			IL_0745:
																			num5++;
																			goto end_IL_02e5;
																			IL_055e:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_056c;
																			IL_056c:
																			((delegate*<Array, RuntimeFieldHandle, void>)SetApartmentStateLongPath[*(int*)(ptr2 + num3)])((float[])array2[num5 - 2], (RuntimeFieldHandle)array2[num5 - 1]);
																			goto IL_05a9;
																			IL_05a9:
																			num5 -= 2;
																			goto IL_05b7;
																			IL_05b7:
																			ptr2 += 8;
																			num = 114;
																			goto end_IL_02e5;
																			IL_05d3:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_05e1;
																			IL_05e1:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_05ef;
																			IL_05ef:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02e5;
																			IL_072e:
																			array[num5] = 4;
																			num = 3;
																			goto IL_0745;
																			IL_0614:
																			if (10 > b)
																			{
																				goto IL_0622;
																			}
																			goto IL_071b;
																			IL_0622:
																			if (8 >= b)
																			{
																				goto IL_062d;
																			}
																			goto IL_067d;
																			IL_062d:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_063b;
																			IL_063b:
																			array2[num5 - 1] = new float[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0664;
																			IL_0664:
																			array[num5 - 1] = 5;
																			goto end_IL_02e5;
																			IL_067d:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_068b;
																			IL_068b:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0699;
																			IL_0699:
																			array[num5] = array[num5 - 1];
																			goto IL_06b1;
																			IL_06b1:
																			array3[num5 - 0] = array3[num5 - 1];
																			goto IL_06cf;
																			IL_06cf:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06f3;
																			IL_06f3:
																			array2[num5] = array2[num5 - 1];
																			goto IL_070b;
																			IL_070b:
																			num5++;
																			goto end_IL_02e5;
																		}
																		break;
																		IL_02b2:;
																	}
																}
																((delegate*<void>)SetApartmentStateLongPath[*(int*)(ptr2 + num3)])();
																goto IL_076a;
																IL_076a:
																ptr2 += 8;
																goto end_IL_02e5;
																continue;
																end_IL_02c2:
																break;
															}
															continue;
															end_IL_02d5:
															break;
														}
														continue;
														end_IL_02e5:
														break;
													}
													continue;
													end_IL_0778:
													break;
												}
												continue;
												end_IL_078b:
												break;
											}
											continue;
											end_IL_0795:
											break;
										}
										continue;
										end_IL_07a0:
										break;
									}
									continue;
									end_IL_07b0:
									break;
								}
								continue;
								end_IL_07c0:
								break;
							}
							continue;
							end_IL_07d0:
							break;
						}
						continue;
						end_IL_07e0:
						break;
					}
					continue;
					end_IL_07f0:
					break;
				}
				continue;
				end_IL_080d:
				break;
			}
		}
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 65;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 117;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDirectoryNameReverse.GetConnectionPointContainerGetHostSuppliedAppDomainEvidenceTypes);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02b9:
														byte b = *ptr2;
														while (true)
														{
															IL_02a9:
															ptr2++;
															while (true)
															{
																IL_0299:
																if (b >= 1)
																{
																	while (b <= 12)
																	{
																		while (true)
																		{
																			IL_027c:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_026c:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_025c:
																							if (11 >= b)
																							{
																								while (true)
																								{
																									IL_024c:
																									if (11 <= b)
																									{
																										while (true)
																										{
																											IL_022a:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											num = 130;
																											while (num != 130)
																											{
																												if (num != 1111)
																												{
																													goto IL_05ec;
																												}
																												switch (num)
																												{
																												case 3:
																												case 11:
																													goto IL_022a;
																												case 74:
																													goto IL_024c;
																												case 5:
																												case 31:
																													goto IL_025c;
																												case 113:
																													goto IL_026c;
																												case 44:
																													goto IL_027c;
																												case 39:
																													goto IL_0289;
																												case 70:
																													goto IL_0299;
																												case 75:
																													goto IL_02a9;
																												case 71:
																												case 119:
																													goto IL_02b9;
																												case 50:
																													goto IL_02c4;
																												case 6:
																													goto IL_02cf;
																												case 15:
																													goto IL_02da;
																												case 28:
																												case 45:
																													goto IL_0301;
																												case 58:
																													goto IL_0343;
																												case 77:
																													goto IL_0353;
																												case 2:
																												case 83:
																													goto IL_036c;
																												case 84:
																													goto IL_0384;
																												case 60:
																													goto IL_0392;
																												case 10:
																												case 55:
																													goto IL_03a0;
																												case 61:
																													goto IL_03ae;
																												case 16:
																												case 87:
																													goto IL_03dc;
																												case 20:
																													goto IL_03ea;
																												case 97:
																													goto IL_03fd;
																												case 99:
																													goto IL_0407;
																												case 67:
																													goto IL_0415;
																												case 66:
																												case 100:
																													goto IL_0428;
																												case 7:
																												case 9:
																													goto IL_0433;
																												case 93:
																													goto IL_0441;
																												case 37:
																												case 79:
																													goto IL_044f;
																												case 103:
																													goto IL_047a;
																												case 35:
																												case 59:
																													goto IL_0488;
																												case 17:
																													goto IL_04a1;
																												case 33:
																													goto IL_04af;
																												case 81:
																													goto IL_04bd;
																												case 107:
																													goto IL_04d0;
																												case 109:
																													goto IL_04de;
																												case 111:
																													goto IL_04f1;
																												case 19:
																												case 121:
																													goto IL_0504;
																												case 123:
																													goto IL_0517;
																												case 108:
																													goto IL_052a;
																												case 30:
																													goto IL_0538;
																												case 105:
																													goto IL_0554;
																												case 106:
																												case 120:
																													goto IL_0562;
																												case 82:
																													goto IL_056d;
																												case 73:
																												case 114:
																													goto IL_057b;
																												case 122:
																													goto IL_059e;
																												case 91:
																													goto IL_05ac;
																												case 12:
																													goto IL_05ba;
																												case 25:
																												case 110:
																													goto IL_05d6;
																												case 68:
																													goto IL_05e1;
																												case 56:
																												case 72:
																													goto IL_05ec;
																												case 104:
																													goto IL_064e;
																												case 0:
																												case 1:
																												case 13:
																												case 21:
																												case 23:
																												case 24:
																												case 32:
																												case 40:
																												case 46:
																												case 47:
																												case 52:
																												case 53:
																												case 62:
																												case 63:
																												case 69:
																												case 80:
																												case 88:
																												case 89:
																												case 90:
																												case 95:
																												case 96:
																												case 102:
																												case 116:
																												case 118:
																													goto end_IL_0289;
																												case 14:
																												case 76:
																													goto IL_067c;
																												case 57:
																													goto IL_0693;
																												case 38:
																													goto IL_06b7;
																												case 36:
																													goto IL_06c5;
																												case 4:
																												case 27:
																												case 29:
																												case 41:
																												case 42:
																												case 49:
																												case 54:
																												case 78:
																												case 86:
																												case 94:
																												case 98:
																												case 101:
																												case 112:
																												case 115:
																													goto end_IL_0217;
																												case 18:
																													goto end_IL_06dc;
																												case 26:
																													goto end_IL_06ef;
																												case 8:
																													goto end_IL_06f9;
																												case 117:
																													goto end_IL_0704;
																												case 22:
																												case 51:
																													goto end_IL_0719;
																												case 48:
																													goto end_IL_0729;
																												case 43:
																												case 85:
																													goto end_IL_0742;
																												case 64:
																													goto end_IL_0752;
																												case 65:
																													goto end_IL_0762;
																												case 34:
																												case 92:
																													goto IL_077d;
																												}
																												continue;
																												end_IL_0217:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03dc;
																									IL_0504:
																									num6--;
																									break;
																									IL_03dc:
																									if (10 < b)
																									{
																										goto end_IL_0289;
																									}
																									goto IL_03ea;
																									IL_03ea:
																									if (10 > b)
																									{
																										goto end_IL_0289;
																									}
																									goto IL_0504;
																								}
																								break;
																							}
																							goto IL_052a;
																							IL_0538:
																							if (12 > b)
																							{
																								num = 118;
																							}
																							goto end_IL_0289;
																							IL_052a:
																							if (12 < b)
																							{
																								goto end_IL_0289;
																							}
																							goto IL_0538;
																						}
																						break;
																					}
																					goto IL_0554;
																					IL_06b7:
																					num6++;
																					goto IL_06c5;
																					IL_0554:
																					if (9 > b)
																					{
																						goto IL_0562;
																					}
																					goto IL_067c;
																					IL_0562:
																					if (7 >= b)
																					{
																						goto IL_056d;
																					}
																					num = 110;
																					goto IL_05d6;
																					IL_056d:
																					if (7 > b)
																					{
																						goto end_IL_0289;
																					}
																					goto IL_057b;
																					IL_057b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_059e;
																					IL_059e:
																					array[num6] = 0;
																					goto IL_05ac;
																					IL_05ac:
																					num6++;
																					goto IL_05ba;
																					IL_05ba:
																					ptr2 += 8;
																					break;
																					IL_06c5:
																					ptr2 += 8;
																					num = 98;
																					break;
																					IL_05d6:
																					if (8 < b)
																					{
																						goto end_IL_0289;
																					}
																					goto IL_05e1;
																					IL_05e1:
																					if (8 > b)
																					{
																						goto end_IL_0289;
																					}
																					goto IL_05ec;
																					IL_05ec:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_064e;
																					IL_064e:
																					num6 -= 2;
																					break;
																					IL_067c:
																					array[num6] = 0;
																					num = 57;
																					goto IL_0693;
																					IL_0693:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getindexComInterfaceType[*(int*)(ptr2 + num3)])();
																					goto IL_06b7;
																				}
																				break;
																			}
																			goto IL_02c4;
																			IL_0301:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0353;
																			IL_02c4:
																			if (6 > b)
																			{
																				goto IL_02cf;
																			}
																			num = 45;
																			goto IL_0301;
																			IL_02cf:
																			if (3 < b)
																			{
																				goto IL_02da;
																			}
																			num = 58;
																			goto IL_0343;
																			IL_02da:
																			if (4 < b)
																			{
																				goto IL_0384;
																			}
																			goto IL_0517;
																			IL_0517:
																			if (4 > b)
																			{
																				goto end_IL_0289;
																			}
																			break;
																			IL_0384:
																			if (5 < b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_0392;
																			IL_0392:
																			if (5 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_03a0;
																			IL_03a0:
																			array[num6] = 0;
																			goto IL_03ae;
																			IL_03ae:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			num = 97;
																			goto IL_03fd;
																			IL_03fd:
																			array2[num6] = null;
																			goto IL_0407;
																			IL_0407:
																			num6++;
																			goto IL_0415;
																			IL_0415:
																			ptr2 += 8;
																			break;
																			IL_04f1:
																			num6--;
																			break;
																			IL_0343:
																			if (3 <= b)
																			{
																				goto IL_036c;
																			}
																			goto IL_0428;
																			IL_0428:
																			if (1 < b)
																			{
																				goto IL_0433;
																			}
																			goto IL_047a;
																			IL_0433:
																			if (2 < b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_0441;
																			IL_0441:
																			if (2 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_044f;
																			IL_044f:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_04d0;
																			IL_04d0:
																			ptr2 += 8;
																			goto IL_04de;
																			IL_04de:
																			num6--;
																			break;
																			IL_047a:
																			if (1 > b)
																			{
																				goto end_IL_0289;
																			}
																			goto IL_0488;
																			IL_0488:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_04a1;
																			IL_04a1:
																			array[num6] = 0;
																			goto IL_04af;
																			IL_04af:
																			num6++;
																			goto IL_04bd;
																			IL_04bd:
																			ptr2 += 8;
																			break;
																			IL_036c:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0353:
																			array[num6 - 2] = 0;
																			goto IL_04f1;
																		}
																		goto end_IL_0299;
																		continue;
																		end_IL_0289:
																		break;
																		IL_0289:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 101;
																break;
																continue;
																end_IL_0299:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_077d;
												IL_077d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_06dc:
												break;
											}
											continue;
											end_IL_06ef:
											break;
										}
										continue;
										end_IL_06f9:
										break;
									}
									continue;
									end_IL_0704:
									break;
								}
								continue;
								end_IL_0719:
								break;
							}
							continue;
							end_IL_0729:
							break;
						}
						continue;
						end_IL_0742:
						break;
					}
					continue;
					end_IL_0752:
					break;
				}
				continue;
				end_IL_0762:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 141;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 75;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentCultureConcurrentSet.GenericTypeParameterBuilderIV);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f8:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				if (8 >= b)
																				{
																					while (true)
																					{
																						if (8 > b)
																						{
																							while (true)
																							{
																								if (4 >= b)
																								{
																									while (true)
																									{
																										if (4 > b)
																										{
																											while (true)
																											{
																												if (2 >= b)
																												{
																													while (true)
																													{
																														if (2 > b)
																														{
																															num = 150;
																															while (true)
																															{
																																if (num == 150)
																																{
																																	goto IL_04f2;
																																}
																																if (num != 1131)
																																{
																																	goto IL_050b;
																																}
																																switch (num)
																																{
																																case 93:
																																	goto end_IL_0275;
																																case 51:
																																case 54:
																																	goto end_IL_0288;
																																case 5:
																																	goto end_IL_029b;
																																case 28:
																																	goto end_IL_02ab;
																																case 117:
																																	goto end_IL_02bb;
																																case 100:
																																	goto end_IL_02cb;
																																case 124:
																																	goto end_IL_02d8;
																																case 136:
																																	goto IL_02f8;
																																case 25:
																																	goto end_IL_02f8;
																																case 52:
																																case 102:
																																	goto end_IL_0308;
																																case 30:
																																case 40:
																																	goto IL_0323;
																																case 9:
																																case 42:
																																	goto IL_033b;
																																case 58:
																																case 113:
																																	goto IL_034e;
																																case 90:
																																	goto IL_0362;
																																case 57:
																																	goto IL_0370;
																																case 112:
																																	goto IL_037e;
																																case 19:
																																	goto IL_0391;
																																case 118:
																																	goto IL_039f;
																																case 43:
																																case 86:
																																	goto IL_03ad;
																																case 67:
																																	goto IL_03d6;
																																case 41:
																																	goto IL_03e4;
																																case 122:
																																	goto IL_03f7;
																																case 46:
																																case 71:
																																	goto IL_0405;
																																case 1:
																																	goto IL_042e;
																																case 120:
																																case 127:
																																	goto IL_0447;
																																case 31:
																																	goto IL_0455;
																																case 79:
																																	goto IL_046d;
																																case 108:
																																	goto IL_047b;
																																case 47:
																																case 130:
																																	goto IL_0497;
																																case 33:
																																	goto IL_04df;
																																case 24:
																																	goto IL_04f2;
																																case 78:
																																	goto IL_04fd;
																																case 101:
																																case 138:
																																	goto IL_050b;
																																case 53:
																																	goto IL_052d;
																																case 48:
																																	goto IL_053b;
																																case 99:
																																	goto IL_0549;
																																case 65:
																																case 132:
																																	goto IL_056a;
																																case 134:
																																	goto IL_05aa;
																																case 23:
																																	goto IL_05be;
																																case 39:
																																case 133:
																																	goto IL_05d1;
																																case 18:
																																	goto IL_05ef;
																																case 66:
																																	goto IL_05fd;
																																case 7:
																																	goto IL_0610;
																																case 88:
																																	goto IL_061e;
																																case 49:
																																case 87:
																																	goto IL_0629;
																																case 35:
																																	goto IL_0637;
																																case 85:
																																	goto IL_064a;
																																case 3:
																																case 96:
																																	goto IL_0655;
																																case 73:
																																	goto IL_0671;
																																case 139:
																																	goto IL_067f;
																																case 15:
																																case 109:
																																	goto IL_068d;
																																case 64:
																																	goto IL_06f8;
																																case 34:
																																	goto IL_070b;
																																case 14:
																																case 111:
																																	goto IL_0722;
																																case 94:
																																	goto IL_0730;
																																case 37:
																																case 55:
																																	goto IL_073b;
																																case 123:
																																	goto IL_0749;
																																case 129:
																																	goto IL_076c;
																																case 17:
																																	goto IL_0776;
																																case 106:
																																	goto IL_0784;
																																case 29:
																																	goto IL_0797;
																																case 2:
																																	goto IL_07a5;
																																case 72:
																																	goto IL_07b8;
																																case 63:
																																	goto IL_07c6;
																																case 27:
																																case 84:
																																	goto IL_07d4;
																																case 95:
																																	goto IL_0818;
																																case 16:
																																	goto IL_082c;
																																case 32:
																																case 143:
																																	goto IL_083f;
																																case 36:
																																	goto IL_087f;
																																case 114:
																																	goto IL_0893;
																																case 11:
																																case 12:
																																case 13:
																																case 20:
																																case 26:
																																case 38:
																																case 44:
																																case 45:
																																case 56:
																																case 59:
																																case 60:
																																case 61:
																																case 62:
																																case 74:
																																case 76:
																																case 89:
																																case 97:
																																case 110:
																																case 119:
																																case 121:
																																case 125:
																																case 128:
																																case 131:
																																case 137:
																																	goto end_IL_02e8;
																																case 4:
																																case 6:
																																case 8:
																																case 10:
																																case 50:
																																case 68:
																																case 69:
																																case 70:
																																case 80:
																																case 81:
																																case 82:
																																case 92:
																																case 105:
																																case 107:
																																case 115:
																																case 116:
																																case 126:
																																case 142:
																																	goto end_IL_0318;
																																case 22:
																																	goto end_IL_08bf;
																																case 135:
																																	goto end_IL_08d2;
																																case 98:
																																	goto end_IL_08dc;
																																case 104:
																																	goto end_IL_08e7;
																																case 75:
																																	goto end_IL_08f7;
																																case 103:
																																	goto end_IL_0907;
																																case 21:
																																	goto end_IL_0917;
																																case 0:
																																case 91:
																																	goto end_IL_0922;
																																case 140:
																																	goto end_IL_0932;
																																case 141:
																																	goto end_IL_0942;
																																case 77:
																																case 83:
																																	goto IL_095d;
																																}
																																continue;
																																IL_053b:
																																num5++;
																																goto IL_0549;
																																IL_0549:
																																ptr2 += 8;
																																goto end_IL_0318;
																																IL_04f2:
																																if (1 < b)
																																{
																																	num = 131;
																																	goto end_IL_02e8;
																																}
																																goto IL_04fd;
																																IL_04fd:
																																if (1 > b)
																																{
																																	goto end_IL_02e8;
																																}
																																goto IL_050b;
																																IL_050b:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																num = 53;
																																goto IL_052d;
																																IL_052d:
																																array[num5] = 0;
																																goto IL_053b;
																																continue;
																																end_IL_0275:
																																break;
																															}
																															continue;
																														}
																														goto IL_056a;
																														IL_05aa:
																														array[num5 - 2] = 0;
																														goto IL_05be;
																														IL_05be:
																														num5--;
																														goto end_IL_0318;
																														IL_056a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_05aa;
																														continue;
																														end_IL_0288:
																														break;
																													}
																													continue;
																												}
																												goto IL_033b;
																												IL_042e:
																												array[num5 - 1] = 5;
																												goto end_IL_0318;
																												IL_033b:
																												if (3 < b)
																												{
																													goto end_IL_02e8;
																												}
																												goto IL_03f7;
																												IL_03f7:
																												if (3 > b)
																												{
																													goto end_IL_02e8;
																												}
																												goto IL_0405;
																												IL_0405:
																												array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																												goto IL_042e;
																												continue;
																												end_IL_029b:
																												break;
																											}
																											continue;
																										}
																										goto IL_05d1;
																										IL_05fd:
																										num5--;
																										goto end_IL_0318;
																										IL_05d1:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_05ef;
																										IL_05ef:
																										ptr2 += 8;
																										goto IL_05fd;
																										continue;
																										end_IL_02ab:
																										break;
																									}
																									continue;
																								}
																								goto IL_034e;
																								IL_03d6:
																								ptr2 += 8;
																								goto IL_03e4;
																								IL_034e:
																								if (6 >= b)
																								{
																									num = 90;
																									goto IL_0362;
																								}
																								goto IL_0391;
																								IL_03e4:
																								num5--;
																								goto end_IL_0318;
																								IL_0362:
																								if (6 > b)
																								{
																									goto IL_0370;
																								}
																								goto IL_0497;
																								IL_0370:
																								if (5 < b)
																								{
																									goto end_IL_02e8;
																								}
																								goto IL_037e;
																								IL_037e:
																								if (5 > b)
																								{
																									goto end_IL_02e8;
																								}
																								goto IL_0447;
																								IL_0447:
																								array[num5] = 5;
																								goto IL_0455;
																								IL_0455:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_046d;
																								IL_046d:
																								num5++;
																								goto IL_047b;
																								IL_047b:
																								ptr2 += 8;
																								num = 80;
																								goto end_IL_0318;
																								IL_0497:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 33;
																								goto IL_04df;
																								IL_04df:
																								num5 -= 3;
																								goto end_IL_0318;
																								IL_0391:
																								if (7 < b)
																								{
																									goto end_IL_02e8;
																								}
																								goto IL_039f;
																								IL_039f:
																								if (7 > b)
																								{
																									goto end_IL_02e8;
																								}
																								goto IL_03ad;
																								IL_03ad:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03d6;
																								continue;
																								end_IL_02bb:
																								break;
																							}
																							continue;
																						}
																						goto IL_0323;
																						IL_0323:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0318;
																						continue;
																						end_IL_02cb:
																						break;
																					}
																					continue;
																				}
																				goto IL_0610;
																				IL_087f:
																				array[num5 - 2] = 0;
																				goto IL_0893;
																				IL_0610:
																				if (12 < b)
																				{
																					goto IL_061e;
																				}
																				goto IL_070b;
																				IL_061e:
																				if (14 < b)
																				{
																					goto IL_0629;
																				}
																				goto IL_064a;
																				IL_0629:
																				if (15 < b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_0637;
																				IL_0637:
																				if (15 <= b)
																				{
																				}
																				goto end_IL_02e8;
																				IL_064a:
																				if (14 <= b)
																				{
																					goto IL_0655;
																				}
																				goto IL_0671;
																				IL_0655:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0318;
																				IL_0671:
																				if (13 < b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_067f;
																				IL_067f:
																				if (13 > b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_068d;
																				IL_068d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 64;
																				goto IL_06f8;
																				IL_06f8:
																				num5 -= 2;
																				goto end_IL_0318;
																				IL_070b:
																				if (12 > b)
																				{
																					num = 111;
																					goto IL_0722;
																				}
																				goto IL_083f;
																				IL_0893:
																				num5--;
																				num = 6;
																				goto end_IL_0318;
																				IL_0722:
																				if (10 >= b)
																				{
																					goto IL_0730;
																				}
																				goto IL_07b8;
																				IL_0730:
																				if (10 <= b)
																				{
																					goto IL_073b;
																				}
																				goto IL_0797;
																				IL_073b:
																				array[num5] = 0;
																				goto IL_0749;
																				IL_0749:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_076c;
																				IL_076c:
																				array2[num5] = null;
																				goto IL_0776;
																				IL_0776:
																				num5++;
																				goto IL_0784;
																				IL_0784:
																				ptr2 += 8;
																				goto end_IL_0318;
																				IL_0797:
																				if (9 < b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_07a5;
																				IL_07a5:
																				if (9 > b)
																				{
																					goto end_IL_02e8;
																				}
																				goto end_IL_0318;
																				IL_07b8:
																				if (11 < b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_07c6;
																				IL_07c6:
																				if (11 > b)
																				{
																					goto end_IL_02e8;
																				}
																				goto IL_07d4;
																				IL_07d4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0818;
																				IL_0818:
																				array[num5 - 2] = 0;
																				goto IL_082c;
																				IL_082c:
																				num5--;
																				goto end_IL_0318;
																				IL_083f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_087f;
																				continue;
																				end_IL_02d8:
																				break;
																			}
																			continue;
																			end_IL_02e8:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0318;
																	continue;
																	end_IL_02f8:
																	break;
																}
																continue;
																end_IL_0308:
																break;
															}
															continue;
															end_IL_0318:
															break;
														}
														continue;
													}
													goto IL_095d;
													IL_095d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08bf:
													break;
												}
												continue;
												end_IL_08d2:
												break;
											}
											continue;
											end_IL_08dc:
											break;
										}
										continue;
										end_IL_08e7:
										break;
									}
									continue;
									end_IL_08f7:
									break;
								}
								continue;
								end_IL_0907:
								break;
							}
							continue;
							end_IL_0917:
							break;
						}
						continue;
						end_IL_0922:
						break;
					}
					continue;
					end_IL_0932:
					break;
				}
				continue;
				end_IL_0942:
				break;
			}
		}
	}

	private static int smethod_2(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										num = 7;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumResultEventDataAttribute.BgeUnGetObjectParam);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 118;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0292:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0265:
																						if (6 <= b)
																						{
																							while (true)
																							{
																								IL_021a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 126;
																								while (true)
																								{
																									if (num != 126)
																									{
																										if (num != 1107)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 5:
																										case 91:
																											goto IL_021a;
																										case 116:
																											goto IL_0265;
																										case 32:
																											goto end_IL_0265;
																										case 71:
																											goto end_IL_0275;
																										case 89:
																											goto IL_0292;
																										case 70:
																											goto end_IL_0292;
																										case 3:
																										case 81:
																											goto end_IL_02a2;
																										case 6:
																										case 10:
																											goto IL_02bd;
																										case 51:
																											goto IL_02c8;
																										case 63:
																											goto IL_02d6;
																										case 27:
																											goto IL_02e4;
																										case 84:
																											goto IL_02f7;
																										case 44:
																										case 60:
																											goto IL_0302;
																										case 55:
																											goto IL_0310;
																										case 0:
																											goto IL_0334;
																										case 80:
																											goto IL_0342;
																										case 14:
																										case 95:
																											goto IL_0355;
																										case 33:
																											goto IL_0363;
																										case 97:
																											goto IL_0376;
																										case 39:
																										case 54:
																											goto IL_0384;
																										case 25:
																										case 99:
																											goto IL_0397;
																										case 102:
																											goto IL_03b3;
																										case 69:
																										case 88:
																											goto IL_03be;
																										case 100:
																											goto IL_03c9;
																										case 29:
																											goto IL_03dc;
																										case 72:
																											goto IL_03ea;
																										case 52:
																										case 56:
																											goto IL_03f8;
																										case 13:
																											goto IL_0406;
																										case 58:
																											goto IL_042e;
																										case 48:
																										case 101:
																											goto IL_0439;
																										case 15:
																										case 40:
																											goto IL_0444;
																										case 4:
																											goto IL_0452;
																										case 2:
																											goto IL_0465;
																										case 22:
																										case 28:
																											goto IL_0478;
																										case 59:
																											goto IL_04a1;
																										case 34:
																											goto IL_04af;
																										case 98:
																										case 106:
																											goto IL_04c2;
																										case 50:
																											goto IL_04db;
																										case 67:
																											goto IL_04e9;
																										case 53:
																											goto IL_04f7;
																										case 73:
																										case 110:
																											goto end_IL_0207;
																										case 19:
																											goto IL_054a;
																										case 42:
																											goto IL_055e;
																										case 104:
																										case 115:
																											goto IL_0571;
																										case 105:
																											goto IL_057f;
																										case 31:
																										case 61:
																											goto IL_058d;
																										case 23:
																											goto IL_05cd;
																										case 107:
																											goto IL_05ea;
																										case 43:
																										case 117:
																											goto IL_05fd;
																										case 114:
																											goto IL_063d;
																										case 24:
																											goto IL_0651;
																										case 119:
																											goto IL_0664;
																										case 35:
																											goto IL_066e;
																										case 94:
																											goto IL_067c;
																										case 76:
																											goto IL_06ac;
																										case 12:
																										case 20:
																										case 21:
																										case 26:
																										case 30:
																										case 41:
																										case 45:
																										case 46:
																										case 57:
																										case 62:
																										case 65:
																										case 68:
																										case 74:
																										case 75:
																										case 83:
																										case 85:
																										case 86:
																										case 103:
																											goto end_IL_0282;
																										case 16:
																											goto IL_06e8;
																										case 37:
																											goto IL_06f6;
																										case 79:
																											goto IL_070d;
																										case 1:
																										case 8:
																										case 9:
																										case 11:
																										case 49:
																										case 64:
																										case 66:
																										case 87:
																										case 90:
																										case 96:
																										case 109:
																										case 112:
																										case 118:
																											goto end_IL_02b2;
																										case 77:
																											goto end_IL_071b;
																										case 7:
																											goto end_IL_072e;
																										case 78:
																											goto end_IL_0741;
																										case 38:
																											goto end_IL_074c;
																										case 108:
																											goto end_IL_076a;
																										case 92:
																										case 111:
																											goto end_IL_077f;
																										case 47:
																											goto end_IL_078f;
																										case 82:
																										case 113:
																											goto end_IL_079f;
																										case 17:
																											goto end_IL_07af;
																										case 18:
																											goto end_IL_07bf;
																										case 36:
																										case 93:
																											goto IL_07da;
																										}
																										continue;
																									}
																									array[num5 - 2] = 0;
																									num = 76;
																									goto IL_06ac;
																									IL_06ac:
																									num5--;
																									goto end_IL_02b2;
																									continue;
																									end_IL_0207:
																									break;
																								}
																								break;
																							}
																							goto IL_050a;
																						}
																						goto IL_03b3;
																						IL_04af:
																						num5--;
																						goto end_IL_02b2;
																						IL_03b3:
																						if (3 < b)
																						{
																							goto IL_03be;
																						}
																						goto IL_042e;
																						IL_03be:
																						if (4 >= b)
																						{
																							goto IL_03c9;
																						}
																						goto IL_03dc;
																						IL_03c9:
																						if (4 > b)
																						{
																							goto end_IL_0282;
																						}
																						goto IL_05fd;
																						IL_05fd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_063d;
																						IL_063d:
																						array[num5 - 2] = 0;
																						goto IL_0651;
																						IL_0651:
																						num5--;
																						goto end_IL_02b2;
																						IL_03dc:
																						if (5 < b)
																						{
																							goto end_IL_0282;
																						}
																						goto IL_03ea;
																						IL_03ea:
																						if (5 > b)
																						{
																							goto end_IL_0282;
																						}
																						goto IL_03f8;
																						IL_03f8:
																						array[num5] = 0;
																						goto IL_0406;
																						IL_0406:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0664;
																						IL_0664:
																						array2[num5] = null;
																						goto IL_066e;
																						IL_066e:
																						num5++;
																						goto IL_067c;
																						IL_067c:
																						ptr2 += 8;
																						goto end_IL_02b2;
																						IL_042e:
																						if (3 > b)
																						{
																							goto IL_0439;
																						}
																						goto IL_0478;
																						IL_0439:
																						if (1 < b)
																						{
																							goto IL_0444;
																						}
																						goto IL_0465;
																						IL_0444:
																						if (2 < b)
																						{
																							goto end_IL_0282;
																						}
																						goto IL_0452;
																						IL_0452:
																						if (2 > b)
																						{
																							goto end_IL_0282;
																						}
																						goto IL_050a;
																						IL_050a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_054a;
																						IL_054a:
																						array[num5 - 2] = 0;
																						goto IL_055e;
																						IL_055e:
																						num5--;
																						goto end_IL_02b2;
																						IL_0465:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0282;
																						IL_0478:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04a1;
																						IL_04a1:
																						ptr2 += 8;
																						goto IL_04af;
																						continue;
																						end_IL_0265:
																						break;
																					}
																					continue;
																				}
																				goto IL_02bd;
																				IL_05ea:
																				num5--;
																				goto end_IL_02b2;
																				IL_02bd:
																				if (9 < b)
																				{
																					goto IL_02c8;
																				}
																				goto IL_02f7;
																				IL_02c8:
																				if (10 < b)
																				{
																					goto IL_02d6;
																				}
																				goto IL_0376;
																				IL_02d6:
																				if (11 < b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_02e4;
																				IL_02e4:
																				if (11 > b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_0397;
																				IL_0397:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b2;
																				IL_0376:
																				if (10 > b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_0384;
																				IL_0384:
																				num5--;
																				goto end_IL_02b2;
																				IL_02f7:
																				if (9 <= b)
																				{
																					goto IL_0302;
																				}
																				goto IL_0355;
																				IL_0302:
																				array[num5] = 0;
																				goto IL_0310;
																				IL_0310:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)pValueBinaryFormatter[*(int*)(ptr2 + num3)])();
																				goto IL_0334;
																				IL_0334:
																				num5++;
																				goto IL_0342;
																				IL_0342:
																				ptr2 += 8;
																				goto end_IL_02b2;
																				IL_0355:
																				if (7 >= b)
																				{
																					goto IL_0363;
																				}
																				goto IL_0571;
																				IL_0363:
																				if (7 > b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_04c2;
																				IL_04c2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04db;
																				IL_04db:
																				array[num5] = 0;
																				goto IL_04e9;
																				IL_04e9:
																				num5++;
																				goto IL_04f7;
																				IL_04f7:
																				ptr2 += 8;
																				goto end_IL_02b2;
																				IL_0571:
																				if (8 < b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_057f;
																				IL_057f:
																				if (8 > b)
																				{
																					goto end_IL_0282;
																				}
																				goto IL_058d;
																				IL_058d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05cd;
																				IL_05cd:
																				array[num5 - 2] = 0;
																				num = 107;
																				goto IL_05ea;
																				continue;
																				end_IL_0275:
																				break;
																			}
																			continue;
																			end_IL_0282:
																			break;
																		}
																	}
																	else
																	{
																		num = 45;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e8;
																	IL_06f6:
																	num5++;
																	num = 79;
																	goto IL_070d;
																	IL_070d:
																	ptr2 += 8;
																	goto end_IL_02b2;
																	IL_06e8:
																	array[num5] = 0;
																	goto IL_06f6;
																	continue;
																	end_IL_0292:
																	break;
																}
																continue;
																end_IL_02a2:
																break;
															}
															continue;
															end_IL_02b2:
															break;
														}
														continue;
													}
													goto IL_07da;
													IL_07da:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071b:
													break;
												}
												continue;
												end_IL_072e:
												break;
											}
											continue;
											end_IL_0741:
											break;
										}
										continue;
										end_IL_074c:
										break;
									}
									continue;
									end_IL_076a:
									break;
								}
								continue;
								end_IL_077f:
								break;
							}
							continue;
							end_IL_078f:
							break;
						}
						continue;
						end_IL_079f:
						break;
					}
					continue;
					end_IL_07af:
					break;
				}
				continue;
				end_IL_07bf:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 101;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LoggerIdgetIsImpersonating.IgnoreSymbolsRefanytype);
											num = 56;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0247:
															num = 51;
															while (true)
															{
																IL_023c:
																byte b = *ptr2;
																while (true)
																{
																	IL_022c:
																	ptr2++;
																	while (true)
																	{
																		IL_021c:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_01fc:
																					if (5 >= b)
																					{
																						num = 115;
																						while (true)
																						{
																							if (num != 115)
																							{
																								if (num != 1096)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 67:
																									goto IL_01fc;
																								case 4:
																									goto IL_020c;
																								case 105:
																									goto IL_021c;
																								case 6:
																									goto IL_022c;
																								case 51:
																									goto IL_023c;
																								case 102:
																									goto IL_0247;
																								case 84:
																									goto IL_0252;
																								case 38:
																								case 83:
																									goto IL_025d;
																								case 36:
																									goto IL_026b;
																								case 63:
																									goto IL_0279;
																								case 14:
																								case 16:
																									goto IL_0290;
																								case 43:
																									goto IL_02ac;
																								case 60:
																									goto IL_02b7;
																								case 7:
																									goto IL_02c5;
																								case 33:
																								case 64:
																									goto IL_02de;
																								case 34:
																								case 90:
																									goto IL_02fc;
																								case 42:
																									goto IL_033c;
																								case 29:
																									goto IL_0350;
																								case 96:
																									goto IL_0363;
																								case 44:
																								case 47:
																									goto IL_0371;
																								case 81:
																									goto IL_03b1;
																								case 15:
																									goto IL_03c5;
																								case 107:
																									goto IL_03d8;
																								case 100:
																									goto IL_03e6;
																								case 72:
																									goto IL_03f4;
																								case 41:
																								case 104:
																									goto IL_0415;
																								case 23:
																								case 78:
																									goto IL_0423;
																								case 53:
																								case 97:
																									goto IL_0431;
																								case 57:
																									goto IL_043f;
																								case 58:
																								case 93:
																									goto IL_044d;
																								case 26:
																									goto IL_0496;
																								case 10:
																									goto IL_04aa;
																								case 45:
																									goto IL_04bd;
																								case 22:
																								case 32:
																									goto IL_04cb;
																								case 12:
																									goto IL_04fd;
																								case 18:
																									goto IL_050b;
																								case 95:
																									goto IL_051e;
																								case 39:
																									goto IL_0529;
																								case 68:
																									goto IL_0537;
																								case 55:
																								case 79:
																									goto IL_054a;
																								case 108:
																									goto IL_058a;
																								case 92:
																									goto IL_059e;
																								case 20:
																								case 21:
																									goto IL_05b1;
																								case 74:
																									goto IL_05bf;
																								case 31:
																									goto IL_05e2;
																								case 17:
																									goto IL_05f5;
																								case 52:
																									goto IL_0603;
																								case 0:
																								case 1:
																								case 5:
																								case 8:
																								case 19:
																								case 25:
																								case 27:
																								case 37:
																								case 48:
																								case 54:
																								case 62:
																								case 65:
																								case 69:
																								case 70:
																								case 71:
																								case 76:
																								case 80:
																								case 85:
																								case 91:
																								case 98:
																								case 99:
																								case 106:
																									goto end_IL_020c;
																								case 94:
																									goto IL_0636;
																								case 87:
																									goto IL_064d;
																								case 82:
																									goto IL_065b;
																								case 2:
																								case 3:
																								case 13:
																								case 30:
																								case 35:
																								case 40:
																								case 46:
																								case 49:
																								case 61:
																								case 75:
																								case 86:
																									goto end_IL_01e9;
																								case 56:
																									goto end_IL_0669;
																								case 103:
																									goto end_IL_067c;
																								case 28:
																									goto end_IL_0686;
																								case 59:
																									goto end_IL_069a;
																								case 66:
																									goto end_IL_06af;
																								case 77:
																								case 101:
																									goto end_IL_06c4;
																								case 73:
																									goto end_IL_06d4;
																								case 9:
																								case 24:
																									goto end_IL_06e4;
																								case 88:
																									goto end_IL_06fd;
																								case 89:
																									goto end_IL_070d;
																								case 11:
																								case 50:
																									goto IL_0728;
																								}
																								continue;
																							}
																							if (5 > b)
																							{
																								goto IL_0415;
																							}
																							goto IL_05b1;
																							IL_05e2:
																							array2[num5] = null;
																							num = 17;
																							goto IL_05f5;
																							IL_0603:
																							ptr2 += 8;
																							break;
																							IL_05f5:
																							num5++;
																							goto IL_0603;
																							IL_0415:
																							if (2 < b)
																							{
																								goto IL_0423;
																							}
																							goto IL_051e;
																							IL_0423:
																							if (3 < b)
																							{
																								goto IL_0431;
																							}
																							goto IL_04bd;
																							IL_0431:
																							if (4 < b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_043f;
																							IL_043f:
																							if (4 > b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_044d;
																							IL_044d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 26;
																							goto IL_0496;
																							IL_0496:
																							array[num5 - 2] = 0;
																							goto IL_04aa;
																							IL_04aa:
																							num5--;
																							break;
																							IL_04bd:
																							if (3 > b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_04cb;
																							IL_04cb:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 12;
																							goto IL_04fd;
																							IL_04fd:
																							ptr2 += 8;
																							goto IL_050b;
																							IL_050b:
																							num5--;
																							break;
																							IL_051e:
																							if (2 > b)
																							{
																								goto IL_0529;
																							}
																							goto IL_054a;
																							IL_0529:
																							if (1 < b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_0537;
																							IL_0537:
																							if (1 <= b)
																							{
																							}
																							goto end_IL_020c;
																							IL_054a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_058a;
																							IL_058a:
																							array[num5 - 2] = 0;
																							goto IL_059e;
																							IL_059e:
																							num5--;
																							break;
																							IL_05b1:
																							array[num5] = 0;
																							goto IL_05bf;
																							IL_05bf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05e2;
																							continue;
																							end_IL_01e9:
																							break;
																						}
																						break;
																					}
																					goto IL_0252;
																					IL_02de:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_03d8;
																					IL_03d8:
																					array[num5] = 0;
																					goto IL_03e6;
																					IL_0252:
																					if (7 < b)
																					{
																						goto IL_025d;
																					}
																					goto IL_02ac;
																					IL_025d:
																					if (8 < b)
																					{
																						goto IL_026b;
																					}
																					goto IL_0363;
																					IL_026b:
																					if (9 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_0279;
																					IL_0279:
																					if (9 > b)
																					{
																						goto end_IL_020c;
																					}
																					num = 16;
																					goto IL_0290;
																					IL_03e6:
																					num5++;
																					goto IL_03f4;
																					IL_0290:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0363:
																					if (8 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_0371;
																					IL_0371:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03b1;
																					IL_03b1:
																					array[num5 - 2] = 0;
																					goto IL_03c5;
																					IL_03c5:
																					num5--;
																					break;
																					IL_02ac:
																					if (7 > b)
																					{
																						goto IL_02b7;
																					}
																					num = 33;
																					goto IL_02de;
																					IL_02b7:
																					if (6 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_02c5;
																					IL_02c5:
																					if (6 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_02fc;
																					IL_02fc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_033c;
																					IL_033c:
																					array[num5 - 2] = 0;
																					goto IL_0350;
																					IL_0350:
																					num5--;
																					break;
																					IL_03f4:
																					ptr2 += 8;
																					break;
																				}
																				goto end_IL_021c;
																				continue;
																				end_IL_020c:
																				break;
																				IL_020c:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0636;
																		IL_065b:
																		ptr2 += 8;
																		break;
																		IL_064d:
																		num5++;
																		goto IL_065b;
																		IL_0636:
																		array[num5] = 0;
																		num = 87;
																		goto IL_064d;
																		continue;
																		end_IL_021c:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0728;
													IL_0728:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0669:
													break;
												}
												continue;
												end_IL_067c:
												break;
											}
											continue;
											end_IL_0686:
											break;
										}
										continue;
										end_IL_069a:
										break;
									}
									continue;
									end_IL_06af:
									break;
								}
								continue;
								end_IL_06c4:
								break;
							}
							continue;
							end_IL_06d4:
							break;
						}
						continue;
						end_IL_06e4:
						break;
					}
					continue;
					end_IL_06fd:
					break;
				}
				continue;
				end_IL_070d:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 43;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 38;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NVTraceIGetSequencePoints.NoValuePropHasId);
											num = 92;
											while (true)
											{
												byte* ptr2 = ptr;
												num = 91;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0278:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0258:
																				if (5 >= b)
																				{
																					goto IL_0418;
																				}
																				while (true)
																				{
																					IL_0248:
																					if (7 >= b)
																					{
																						num = 74;
																						while (true)
																						{
																							IL_0238:
																							if (7 <= b)
																							{
																								while (true)
																								{
																									IL_021d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									while (true)
																									{
																										IL_020d:
																										array[num5] = 0;
																										while (true)
																										{
																											IL_01f4:
																											num5++;
																											num = 113;
																											while (true)
																											{
																												if (num != 113)
																												{
																													if (num != 1094)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 88:
																														goto IL_01f4;
																													case 95:
																														goto IL_020d;
																													case 61:
																													case 106:
																														goto IL_021d;
																													case 74:
																														goto IL_0238;
																													case 16:
																													case 72:
																														goto IL_0248;
																													case 89:
																														goto IL_0258;
																													case 79:
																														goto end_IL_0258;
																													case 100:
																														goto IL_0278;
																													case 78:
																														goto end_IL_0278;
																													case 21:
																													case 81:
																														goto end_IL_0288;
																													case 1:
																														goto IL_02a3;
																													case 13:
																													case 28:
																														goto IL_02ae;
																													case 59:
																														goto IL_02be;
																													case 65:
																														goto IL_02d1;
																													case 71:
																														goto IL_02e4;
																													case 40:
																														goto IL_02f2;
																													case 44:
																													case 62:
																														goto IL_0300;
																													case 54:
																														goto IL_0340;
																													case 66:
																														goto IL_0354;
																													case 67:
																													case 97:
																														goto IL_0367;
																													case 24:
																													case 98:
																														goto IL_038c;
																													case 5:
																														goto IL_03cc;
																													case 36:
																														goto IL_03e0;
																													case 75:
																														goto IL_0418;
																													case 35:
																													case 86:
																														goto IL_0426;
																													case 0:
																													case 70:
																														goto IL_0434;
																													case 47:
																														goto IL_043f;
																													case 8:
																													case 52:
																														goto IL_044d;
																													case 12:
																														goto IL_0476;
																													case 85:
																														goto IL_0484;
																													case 18:
																													case 63:
																														goto IL_0497;
																													case 27:
																														goto IL_04a5;
																													case 29:
																													case 105:
																														goto IL_04b3;
																													case 31:
																														goto end_IL_01e1;
																													case 57:
																														goto IL_0507;
																													case 10:
																														goto IL_051a;
																													case 20:
																													case 84:
																														goto IL_0525;
																													case 56:
																														goto IL_0565;
																													case 104:
																														goto IL_0579;
																													case 58:
																													case 103:
																														goto IL_058c;
																													case 50:
																														goto IL_0597;
																													case 7:
																													case 45:
																														goto IL_05a4;
																													case 17:
																														goto IL_05bb;
																													case 14:
																														goto IL_05de;
																													case 96:
																														goto IL_05e8;
																													case 23:
																														goto IL_05f6;
																													case 4:
																													case 9:
																													case 19:
																													case 22:
																													case 26:
																													case 37:
																													case 48:
																													case 60:
																													case 64:
																													case 69:
																													case 80:
																													case 82:
																													case 83:
																													case 87:
																													case 93:
																													case 99:
																													case 101:
																													case 102:
																														goto end_IL_0268;
																													case 53:
																														goto IL_0629;
																													case 51:
																														goto IL_0637;
																													case 32:
																														goto IL_0645;
																													case 6:
																													case 15:
																													case 25:
																													case 33:
																													case 41:
																													case 49:
																													case 55:
																													case 73:
																													case 76:
																													case 77:
																													case 91:
																														goto end_IL_0298;
																													case 92:
																														goto end_IL_0653;
																													case 34:
																														goto end_IL_0666;
																													case 11:
																														goto end_IL_0679;
																													case 2:
																														goto end_IL_068d;
																													case 90:
																														goto end_IL_06a2;
																													case 3:
																													case 38:
																														goto end_IL_06b7;
																													case 46:
																														goto end_IL_06c7;
																													case 39:
																													case 94:
																														goto end_IL_06d7;
																													case 42:
																														goto end_IL_06f0;
																													case 43:
																														goto end_IL_0700;
																													case 30:
																													case 68:
																														goto IL_071b;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												num = 33;
																												goto end_IL_0298;
																												continue;
																												end_IL_01e1:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02e4;
																							IL_0354:
																							num5--;
																							goto end_IL_0298;
																							IL_02e4:
																							if (6 < b)
																							{
																								goto end_IL_0268;
																							}
																							goto IL_02f2;
																							IL_02f2:
																							if (6 > b)
																							{
																								goto end_IL_0268;
																							}
																							goto IL_0300;
																							IL_0300:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0340;
																							IL_0340:
																							array[num5 - 2] = 0;
																							goto IL_0354;
																						}
																						break;
																					}
																					goto IL_02a3;
																					IL_03cc:
																					array[num5 - 2] = 0;
																					goto IL_03e0;
																					IL_03e0:
																					num5--;
																					num = 25;
																					goto end_IL_0298;
																					IL_02a3:
																					if (8 < b)
																					{
																						goto IL_02ae;
																					}
																					goto IL_02be;
																					IL_02ae:
																					if (9 < b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_02d1;
																					IL_02d1:
																					if (9 > b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_0367;
																					IL_0367:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 76;
																					goto end_IL_0298;
																					IL_02be:
																					if (8 > b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_038c;
																					IL_038c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03cc;
																				}
																				goto IL_04f3;
																				IL_05f6:
																				ptr2 += 8;
																				goto end_IL_0298;
																				IL_0418:
																				if (5 > b)
																				{
																					goto IL_0426;
																				}
																				goto IL_05a4;
																				IL_0426:
																				if (2 < b)
																				{
																					goto IL_0434;
																				}
																				goto IL_051a;
																				IL_0434:
																				if (3 >= b)
																				{
																					goto IL_043f;
																				}
																				goto IL_0497;
																				IL_043f:
																				if (3 > b)
																				{
																					goto end_IL_0268;
																				}
																				goto IL_044d;
																				IL_044d:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0476;
																				IL_0476:
																				ptr2 += 8;
																				goto IL_0484;
																				IL_0484:
																				num5--;
																				goto end_IL_0298;
																				IL_0497:
																				if (4 < b)
																				{
																					goto end_IL_0268;
																				}
																				goto IL_04a5;
																				IL_04a5:
																				if (4 > b)
																				{
																					goto end_IL_0268;
																				}
																				goto IL_04b3;
																				IL_04b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f3;
																				IL_04f3:
																				array[num5 - 2] = 0;
																				goto IL_0507;
																				IL_0507:
																				num5--;
																				goto end_IL_0298;
																				IL_051a:
																				if (2 <= b)
																				{
																					goto IL_0525;
																				}
																				goto IL_058c;
																				IL_0525:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0565;
																				IL_0565:
																				array[num5 - 2] = 0;
																				goto IL_0579;
																				IL_0579:
																				num5--;
																				goto end_IL_0298;
																				IL_058c:
																				if (1 < b)
																				{
																					goto end_IL_0268;
																				}
																				goto IL_0597;
																				IL_0597:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0268;
																				IL_05a4:
																				array[num5] = 0;
																				num = 17;
																				goto IL_05bb;
																				IL_05bb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05de;
																				IL_05de:
																				array2[num5] = null;
																				goto IL_05e8;
																				IL_05e8:
																				num5++;
																				goto IL_05f6;
																				continue;
																				end_IL_0258:
																				break;
																			}
																			continue;
																			end_IL_0268:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0629;
																	IL_0645:
																	ptr2 += 8;
																	goto end_IL_0298;
																	IL_0637:
																	num5++;
																	goto IL_0645;
																	IL_0629:
																	array[num5] = 0;
																	goto IL_0637;
																	continue;
																	end_IL_0278:
																	break;
																}
																continue;
																end_IL_0288:
																break;
															}
															continue;
															end_IL_0298:
															break;
														}
														continue;
													}
													goto IL_071b;
													IL_071b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0653:
													break;
												}
												continue;
												end_IL_0666:
												break;
											}
											continue;
											end_IL_0679:
											break;
										}
										continue;
										end_IL_068d:
										break;
									}
									continue;
									end_IL_06a2:
									break;
								}
								continue;
								end_IL_06b7:
								break;
							}
							continue;
							end_IL_06c7:
							break;
						}
						continue;
						end_IL_06d7:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 102;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsTypeSpecThumbprint.getExternalProcessMgmtVARFLAGFUIDEFAULT);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 79;
															while (true)
															{
																IL_027e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0261:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0251:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0241:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0231:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_01d6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 109;
																												while (true)
																												{
																													if (num != 109)
																													{
																														if (num != 1090)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 35:
																														case 53:
																															goto IL_01d6;
																														case 73:
																															goto IL_0221;
																														case 42:
																														case 63:
																															goto IL_0231;
																														case 44:
																															goto IL_0241;
																														case 99:
																															goto IL_0251;
																														case 85:
																															goto IL_0261;
																														case 83:
																															goto IL_026e;
																														case 79:
																															goto IL_027e;
																														case 49:
																															goto end_IL_027e;
																														case 22:
																														case 23:
																															goto end_IL_028e;
																														case 9:
																															goto IL_02b2;
																														case 6:
																														case 62:
																															goto IL_02bd;
																														case 13:
																															goto IL_02c8;
																														case 4:
																															goto IL_02db;
																														case 12:
																															goto IL_02e6;
																														case 10:
																															goto IL_02f9;
																														case 14:
																														case 71:
																															goto IL_030c;
																														case 27:
																															goto IL_031a;
																														case 8:
																															goto IL_033d;
																														case 34:
																															goto IL_0347;
																														case 20:
																															goto IL_0355;
																														case 68:
																														case 81:
																															goto IL_0371;
																														case 30:
																														case 51:
																															goto IL_037c;
																														case 7:
																															goto IL_038a;
																														case 41:
																															goto IL_039d;
																														case 15:
																														case 86:
																															goto IL_03b0;
																														case 2:
																															goto IL_03d9;
																														case 66:
																														case 89:
																															goto IL_03ec;
																														case 93:
																															goto IL_0404;
																														case 61:
																															goto IL_0412;
																														case 43:
																														case 64:
																															goto IL_0420;
																														case 38:
																															goto IL_0439;
																														case 76:
																															goto IL_0447;
																														case 21:
																														case 95:
																															goto IL_0457;
																														case 97:
																															goto IL_0473;
																														case 98:
																															goto IL_0486;
																														case 100:
																															goto IL_0499;
																														case 33:
																															goto IL_04c0;
																														case 67:
																															goto IL_04d3;
																														case 5:
																															goto IL_04e1;
																														case 0:
																														case 40:
																															goto IL_04ef;
																														case 55:
																															goto IL_0512;
																														case 69:
																															goto IL_0520;
																														case 77:
																															goto IL_052e;
																														case 45:
																														case 60:
																															goto IL_0541;
																														case 74:
																															goto IL_05a3;
																														case 3:
																														case 16:
																														case 18:
																														case 19:
																														case 25:
																														case 26:
																														case 29:
																														case 36:
																														case 48:
																														case 52:
																														case 56:
																														case 58:
																														case 72:
																														case 78:
																														case 80:
																														case 82:
																														case 87:
																														case 94:
																															goto end_IL_01c3;
																														case 11:
																														case 28:
																														case 31:
																														case 39:
																														case 46:
																														case 47:
																														case 54:
																														case 57:
																														case 59:
																														case 88:
																														case 90:
																														case 91:
																														case 96:
																															goto end_IL_02a7;
																														case 70:
																															goto end_IL_05c6;
																														case 65:
																															goto end_IL_05d9;
																														case 17:
																															goto end_IL_05e3;
																														case 84:
																															goto end_IL_05ee;
																														case 1:
																														case 75:
																															goto end_IL_0603;
																														case 92:
																															goto end_IL_0613;
																														case 32:
																														case 50:
																															goto end_IL_0623;
																														case 101:
																															goto end_IL_0633;
																														case 102:
																															goto end_IL_0643;
																														case 24:
																														case 37:
																															goto IL_065e;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													goto IL_04c0;
																													IL_04c0:
																													num5--;
																													goto end_IL_02a7;
																													continue;
																													end_IL_01c3:
																													break;
																												}
																												break;
																											}
																											break;
																											IL_0221:;
																										}
																										break;
																									}
																									goto IL_04d3;
																									IL_052e:
																									ptr2 += 8;
																									goto end_IL_02a7;
																									IL_04d3:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_04e1;
																									IL_04e1:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_04ef;
																									IL_04ef:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0512;
																									IL_0512:
																									array[num5] = 0;
																									goto IL_0520;
																									IL_0520:
																									num5++;
																									goto IL_052e;
																								}
																								break;
																							}
																							goto IL_0541;
																							IL_05a3:
																							num5 -= 2;
																							goto end_IL_02a7;
																							IL_0541:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05a3;
																						}
																						break;
																					}
																					goto IL_0371;
																					IL_0457:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a7;
																					IL_0371:
																					if (9 < b)
																					{
																						goto IL_037c;
																					}
																					goto IL_039d;
																					IL_037c:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_038a;
																					IL_038a:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_039d:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0457;
																				}
																				break;
																			}
																			goto IL_02b2;
																			IL_0355:
																			ptr2 += 8;
																			num = 39;
																			goto end_IL_02a7;
																			IL_02b2:
																			if (5 > b)
																			{
																				goto IL_02bd;
																			}
																			goto IL_030c;
																			IL_02bd:
																			if (2 >= b)
																			{
																				goto IL_02c8;
																			}
																			goto IL_02db;
																			IL_02c8:
																			if (2 <= b)
																			{
																				goto IL_03b0;
																			}
																			goto IL_0404;
																			IL_03b0:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03d9;
																			IL_03d9:
																			ptr2 += 8;
																			goto IL_0473;
																			IL_0473:
																			num5--;
																			goto end_IL_02a7;
																			IL_0404:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0412;
																			IL_0412:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0420;
																			IL_0420:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0439;
																			IL_0439:
																			array[num5] = 0;
																			goto IL_0447;
																			IL_0447:
																			num5++;
																			goto IL_0486;
																			IL_0486:
																			ptr2 += 8;
																			goto end_IL_02a7;
																			IL_02db:
																			if (3 >= b)
																			{
																				goto IL_02e6;
																			}
																			goto IL_02f9;
																			IL_02e6:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_03ec;
																			IL_03ec:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02a7;
																			IL_02f9:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0499;
																			IL_0499:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02a7;
																			IL_030c:
																			array[num5] = 0;
																			goto IL_031a;
																			IL_031a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_033d;
																			IL_033d:
																			array2[num5] = null;
																			goto IL_0347;
																			IL_0347:
																			num5++;
																			goto IL_0355;
																		}
																		break;
																		IL_026e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a7;
																continue;
																end_IL_027e:
																break;
															}
															continue;
															end_IL_028e:
															break;
														}
														continue;
														end_IL_02a7:
														break;
													}
													continue;
												}
												goto IL_065e;
												IL_065e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c6:
												break;
											}
											continue;
											end_IL_05d9:
											break;
										}
										continue;
										end_IL_05e3:
										break;
									}
									continue;
									end_IL_05ee:
									break;
								}
								continue;
								end_IL_0603:
								break;
							}
							continue;
							end_IL_0613:
							break;
						}
						continue;
						end_IL_0623:
						break;
					}
					continue;
					end_IL_0633:
					break;
				}
				continue;
				end_IL_0643:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getVolumeLabelIsDirty.ResumedParamNames);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_028b:
														byte b = *ptr2;
														while (true)
														{
															IL_027b:
															ptr2++;
															while (true)
															{
																IL_026b:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024e:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_023e:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_022e:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_021e:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												while (true)
																												{
																													IL_01da:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													num = 110;
																													while (true)
																													{
																														if (num != 110)
																														{
																															if (num != 1091)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 25:
																															case 74:
																																goto IL_01da;
																															case 78:
																																goto IL_01fe;
																															case 65:
																																goto IL_020e;
																															case 77:
																																goto IL_021e;
																															case 59:
																																goto IL_022e;
																															case 47:
																																goto IL_023e;
																															case 12:
																																goto IL_024e;
																															case 98:
																																goto IL_025b;
																															case 8:
																																goto IL_026b;
																															case 11:
																																goto IL_027b;
																															case 49:
																															case 97:
																																goto IL_028b;
																															case 37:
																															case 68:
																																goto IL_0296;
																															case 5:
																																goto IL_02a1;
																															case 4:
																																goto IL_02ac;
																															case 53:
																																goto IL_02ba;
																															case 31:
																																goto IL_02c8;
																															case 45:
																																goto IL_02db;
																															case 0:
																																goto IL_02e6;
																															case 64:
																															case 75:
																																goto IL_0307;
																															case 61:
																																goto IL_0369;
																															case 87:
																																goto IL_037c;
																															case 17:
																															case 72:
																																goto IL_038a;
																															case 58:
																															case 90:
																																goto IL_03cc;
																															case 30:
																																goto IL_03f5;
																															case 21:
																																goto IL_0403;
																															case 94:
																																goto IL_0416;
																															case 62:
																																goto IL_042a;
																															case 66:
																															case 95:
																																goto IL_043d;
																															case 38:
																															case 99:
																																goto IL_0459;
																															case 13:
																																goto IL_047c;
																															case 35:
																																goto IL_048a;
																															case 36:
																																goto IL_0498;
																															case 51:
																															case 103:
																																goto IL_04ab;
																															case 28:
																																goto IL_04b9;
																															case 1:
																																goto IL_04da;
																															case 7:
																																goto IL_04e8;
																															case 27:
																																goto IL_04fb;
																															case 82:
																																goto IL_0506;
																															case 50:
																															case 88:
																																goto IL_0514;
																															case 85:
																																goto IL_052c;
																															case 10:
																																goto IL_0537;
																															case 9:
																															case 43:
																																goto IL_054d;
																															case 6:
																																goto IL_055b;
																															case 44:
																																goto IL_057e;
																															case 22:
																																goto IL_0588;
																															case 79:
																																goto IL_0596;
																															case 15:
																															case 18:
																															case 20:
																															case 23:
																															case 29:
																															case 34:
																															case 39:
																															case 42:
																															case 48:
																															case 52:
																															case 55:
																															case 56:
																															case 63:
																															case 70:
																															case 81:
																															case 83:
																															case 84:
																															case 89:
																															case 92:
																															case 93:
																															case 102:
																																goto end_IL_01fe;
																															case 2:
																															case 3:
																															case 14:
																															case 19:
																															case 24:
																															case 26:
																															case 54:
																															case 60:
																															case 69:
																															case 73:
																															case 80:
																															case 100:
																															case 101:
																																goto end_IL_01c7;
																															case 96:
																																goto end_IL_05b9;
																															case 71:
																																goto end_IL_05cc;
																															case 57:
																																goto end_IL_05d6;
																															case 32:
																																goto end_IL_05e1;
																															case 33:
																															case 86:
																																goto end_IL_05f6;
																															case 67:
																																goto end_IL_0606;
																															case 16:
																															case 76:
																																goto end_IL_0616;
																															case 40:
																																goto end_IL_0626;
																															case 41:
																																goto end_IL_0636;
																															case 46:
																															case 91:
																																goto IL_0651;
																															}
																															continue;
																														}
																														array[num5] = 0;
																														goto IL_04da;
																														IL_04da:
																														num5++;
																														goto IL_04e8;
																														IL_04e8:
																														ptr2 += 8;
																														break;
																														continue;
																														end_IL_01c7:
																														break;
																													}
																													break;
																												}
																												goto end_IL_026b;
																												continue;
																												end_IL_01fe:
																												break;
																												IL_01fe:;
																											}
																											break;
																											IL_020e:;
																										}
																										break;
																									}
																									goto IL_03cc;
																									IL_0403:
																									num5--;
																									goto end_IL_026b;
																									IL_03cc:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03f5;
																									IL_03f5:
																									ptr2 += 8;
																									goto IL_0403;
																								}
																								break;
																							}
																							goto IL_04fb;
																							IL_0537:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_026b;
																							IL_04fb:
																							if (3 >= b)
																							{
																								goto IL_0506;
																							}
																							goto IL_052c;
																							IL_0506:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0514;
																							IL_0514:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_026b;
																							IL_052c:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0537;
																						}
																						break;
																					}
																					num = 9;
																					goto IL_054d;
																					IL_0588:
																					num5++;
																					goto IL_0596;
																					IL_0596:
																					ptr2 += 8;
																					goto end_IL_026b;
																					IL_054d:
																					array[num5] = 0;
																					goto IL_055b;
																					IL_055b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_057e;
																					IL_057e:
																					array2[num5] = null;
																					goto IL_0588;
																				}
																				break;
																			}
																			goto IL_0296;
																			IL_04ab:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_04b9;
																			IL_0296:
																			if (8 >= b)
																			{
																				goto IL_02a1;
																			}
																			goto IL_02db;
																			IL_02a1:
																			if (8 > b)
																			{
																				goto IL_02ac;
																			}
																			goto IL_0307;
																			IL_02ac:
																			if (6 < b)
																			{
																				goto IL_02ba;
																			}
																			goto IL_037c;
																			IL_02ba:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_02c8;
																			IL_02c8:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0459;
																			IL_0459:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_047c;
																			IL_047c:
																			array[num5] = 0;
																			goto IL_048a;
																			IL_048a:
																			num5++;
																			goto IL_0498;
																			IL_0498:
																			ptr2 += 8;
																			goto end_IL_026b;
																			IL_037c:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_038a;
																			IL_038a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0416;
																			IL_0416:
																			array[num5 - 2] = 0;
																			goto IL_042a;
																			IL_042a:
																			num5--;
																			goto end_IL_026b;
																			IL_0307:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0369;
																			IL_0369:
																			num5 -= 2;
																			goto end_IL_026b;
																			IL_02db:
																			if (9 >= b)
																			{
																				goto IL_02e6;
																			}
																			num = 51;
																			goto IL_04ab;
																			IL_02e6:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_043d;
																			IL_043d:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_026b;
																			IL_04b9:
																			if (10 > b)
																			{
																			}
																			break;
																		}
																		break;
																		IL_025b:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_026b:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0651;
												IL_0651:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b9:
												break;
											}
											continue;
											end_IL_05cc:
											break;
										}
										continue;
										end_IL_05d6:
										break;
									}
									continue;
									end_IL_05e1:
									break;
								}
								continue;
								end_IL_05f6:
								break;
							}
							continue;
							end_IL_0606:
							break;
						}
						continue;
						end_IL_0616:
						break;
					}
					continue;
					end_IL_0626:
					break;
				}
				continue;
				end_IL_0636:
				break;
			}
		}
	}
}
