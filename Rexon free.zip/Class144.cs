using System;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

[HarmonyPatch(typeof(VRRig), "GrabbedByPlayer")]
internal class Class144
{
	private static double double_0;

	private static int int_0;

	private static int int_1;

	private static bool bool_0;

	private static int int_2;

	private static IntPtr[] GetCustomAttributesDataPERSIAN;

	private static IntPtr[] CreationTimeUtcWindowClassHostDll;

	private static IntPtr[] AreTextualReferencesEqualRegisterChannel;

	private unsafe static bool Prefix(VRRig grabbedByRig, bool grabbedWithLeftHand)
	{
		int num = 129;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							sbyte[] array3 = new sbyte[1];
							while (true)
							{
								int[] array4 = new int[6];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[1];
										while (true)
										{
											array3[0] = (grabbedWithLeftHand ? ((sbyte)1) : ((sbyte)0));
											while (true)
											{
												array6[0] = grabbedByRig;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgumentInvalidRegistryKeyPermissionCheckEBCDICCodePage.MAJORVERSIONgetInArgs);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	IL_0530:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0520:
																		ptr2++;
																		while (true)
																		{
																			IL_0510:
																			if (b >= 1)
																			{
																				while (b <= 33)
																				{
																					while (true)
																					{
																						IL_04f0:
																						if (17 >= b)
																						{
																							while (true)
																							{
																								IL_04e3:
																								if (17 > b)
																								{
																									while (true)
																									{
																										IL_04d3:
																										if (8 >= b)
																										{
																											while (true)
																											{
																												IL_04c3:
																												if (8 <= b)
																												{
																													while (true)
																													{
																														IL_04aa:
																														num5--;
																														num = 290;
																														while (num != 290)
																														{
																															if (num != 1271)
																															{
																																goto IL_0fa6;
																															}
																															switch (num)
																															{
																															case 61:
																															case 255:
																																goto IL_04aa;
																															case 189:
																																goto IL_04c3;
																															case 180:
																																goto IL_04d3;
																															case 115:
																																goto IL_04e3;
																															case 233:
																																goto IL_04f0;
																															case 168:
																																goto IL_0500;
																															case 195:
																																goto IL_0510;
																															case 247:
																																goto IL_0520;
																															case 23:
																															case 68:
																																goto IL_0530;
																															case 30:
																															case 44:
																																goto IL_053b;
																															case 142:
																																goto IL_0549;
																															case 271:
																																goto IL_0567;
																															case 116:
																																goto IL_0575;
																															case 207:
																																goto IL_0588;
																															case 167:
																																goto IL_0596;
																															case 52:
																															case 108:
																																goto IL_05a1;
																															case 91:
																																goto IL_05af;
																															case 212:
																																goto IL_05d2;
																															case 162:
																																goto IL_05dc;
																															case 188:
																																goto IL_05ea;
																															case 163:
																																goto IL_05fd;
																															case 120:
																																goto IL_060b;
																															case 203:
																																goto IL_0616;
																															case 22:
																																goto IL_0624;
																															case 181:
																															case 213:
																																goto IL_0632;
																															case 174:
																																goto IL_064b;
																															case 1:
																																goto IL_0659;
																															case 33:
																																goto IL_0667;
																															case 161:
																															case 258:
																																goto IL_067a;
																															case 230:
																																goto IL_06ba;
																															case 13:
																																goto IL_06ce;
																															case 28:
																																goto IL_06e1;
																															case 85:
																																goto IL_06ef;
																															case 107:
																															case 208:
																																goto IL_0706;
																															case 31:
																																goto IL_072f;
																															case 113:
																																goto IL_073d;
																															case 210:
																																goto IL_0750;
																															case 27:
																																goto IL_075e;
																															case 75:
																															case 187:
																																goto IL_0769;
																															case 145:
																																goto IL_07a9;
																															case 70:
																																goto IL_07bd;
																															case 194:
																																goto IL_07d0;
																															case 220:
																																goto IL_07de;
																															case 4:
																															case 179:
																																goto IL_07ec;
																															case 223:
																																goto IL_0835;
																															case 242:
																																goto IL_0852;
																															case 57:
																																goto IL_0865;
																															case 191:
																																goto IL_0873;
																															case 47:
																															case 69:
																																goto IL_0881;
																															case 134:
																																goto IL_08c1;
																															case 90:
																																goto IL_08d5;
																															case 240:
																																goto IL_08e8;
																															case 135:
																																goto IL_08f6;
																															case 266:
																																goto IL_0904;
																															case 21:
																															case 215:
																																goto IL_090f;
																															case 11:
																																goto IL_096d;
																															case 130:
																																goto IL_0980;
																															case 40:
																																goto IL_098e;
																															case 66:
																															case 82:
																																goto IL_099c;
																															case 119:
																																goto IL_09c0;
																															case 281:
																																goto IL_09ce;
																															case 65:
																																goto IL_09dc;
																															case 222:
																																goto IL_09ef;
																															case 2:
																																goto IL_09fa;
																															case 63:
																															case 106:
																																goto IL_0a08;
																															case 256:
																																goto IL_0a24;
																															case 282:
																																goto IL_0a32;
																															case 202:
																															case 277:
																																goto IL_0a40;
																															case 200:
																																goto IL_0a61;
																															case 201:
																																goto IL_0a6f;
																															case 280:
																																goto IL_0a7d;
																															case 270:
																																goto IL_0a90;
																															case 118:
																																goto IL_0a9e;
																															case 182:
																																goto IL_0aac;
																															case 117:
																																goto IL_0aba;
																															case 43:
																															case 51:
																																goto IL_0ac8;
																															case 123:
																																goto IL_0ae5;
																															case 73:
																																goto IL_0b24;
																															case 169:
																																goto IL_0b37;
																															case 99:
																															case 110:
																																goto IL_0b42;
																															case 93:
																																goto IL_0ba4;
																															case 131:
																																goto IL_0bc0;
																															case 219:
																																goto IL_0bce;
																															case 97:
																															case 149:
																																goto IL_0bdc;
																															case 95:
																																goto IL_0c1c;
																															case 132:
																																goto IL_0c30;
																															case 153:
																																goto IL_0c43;
																															case 45:
																																goto IL_0c51;
																															case 175:
																																goto IL_0c5f;
																															case 39:
																																goto IL_0c6d;
																															case 3:
																															case 164:
																																goto IL_0c78;
																															case 138:
																																goto IL_0c9b;
																															case 241:
																																goto IL_0ca9;
																															case 196:
																																goto IL_0cb7;
																															case 19:
																																goto IL_0cd3;
																															case 228:
																																goto IL_0ce1;
																															case 261:
																																goto IL_0cef;
																															case 101:
																																goto IL_0d06;
																															case 235:
																															case 245:
																																goto IL_0d14;
																															case 243:
																																goto IL_0d4c;
																															case 133:
																																goto IL_0d60;
																															case 214:
																															case 217:
																																goto IL_0d7c;
																															case 139:
																																goto IL_0d90;
																															case 64:
																																goto IL_0de2;
																															case 140:
																																goto IL_0df0;
																															case 239:
																																goto IL_0e03;
																															case 231:
																																goto IL_0e11;
																															case 0:
																															case 105:
																																goto IL_0e1f;
																															case 38:
																																goto IL_0e71;
																															case 7:
																																goto IL_0e84;
																															case 177:
																																goto IL_0e92;
																															case 224:
																															case 244:
																																goto IL_0e9d;
																															case 238:
																																goto IL_0eb1;
																															case 104:
																																goto IL_0eee;
																															case 209:
																																goto IL_0f01;
																															case 32:
																																goto IL_0f0f;
																															case 80:
																															case 158:
																																goto IL_0f1d;
																															case 72:
																																goto IL_0f31;
																															case 279:
																																goto IL_0f69;
																															case 100:
																																goto IL_0f7c;
																															case 178:
																																goto IL_0f8a;
																															case 20:
																															case 236:
																																goto IL_0f98;
																															case 154:
																																goto IL_0fa6;
																															case 225:
																																goto IL_0fcd;
																															case 111:
																																goto IL_0fdb;
																															case 151:
																															case 283:
																																goto IL_0fee;
																															case 152:
																																goto IL_1026;
																															case 62:
																																goto IL_103a;
																															case 54:
																																goto IL_104d;
																															case 55:
																																goto IL_105b;
																															case 109:
																																goto IL_1069;
																															case 218:
																																goto IL_1077;
																															case 125:
																																goto IL_1085;
																															case 170:
																																goto IL_1093;
																															case 74:
																															case 124:
																																goto IL_10a1;
																															case 126:
																																goto IL_10b5;
																															case 264:
																																goto IL_10f2;
																															case 114:
																															case 263:
																																goto IL_1105;
																															case 146:
																																goto IL_1119;
																															case 46:
																																goto IL_116b;
																															case 88:
																																goto IL_1179;
																															case 155:
																																goto IL_118c;
																															case 252:
																																goto IL_119a;
																															case 56:
																															case 79:
																																goto IL_11a8;
																															case 102:
																															case 206:
																																goto IL_11c0;
																															case 276:
																																goto IL_1201;
																															case 275:
																																goto IL_121e;
																															case 211:
																																goto IL_1231;
																															case 84:
																																goto IL_123f;
																															case 17:
																																goto IL_124a;
																															case 12:
																																goto IL_1261;
																															case 26:
																															case 58:
																																goto IL_126f;
																															case 257:
																																goto IL_1289;
																															case 160:
																																goto IL_1297;
																															case 227:
																																goto IL_12a5;
																															case 77:
																															case 127:
																																goto IL_12c1;
																															case 232:
																																goto IL_1302;
																															case 148:
																																goto IL_1316;
																															case 35:
																																goto IL_1329;
																															case 37:
																																goto IL_1334;
																															case 10:
																															case 216:
																																goto IL_133f;
																															case 278:
																																goto IL_1380;
																															case 50:
																																goto IL_1394;
																															case 122:
																																goto IL_13a4;
																															case 24:
																																goto IL_13af;
																															case 8:
																															case 16:
																															case 18:
																															case 25:
																															case 34:
																															case 53:
																															case 67:
																															case 76:
																															case 81:
																															case 83:
																															case 86:
																															case 87:
																															case 94:
																															case 96:
																															case 98:
																															case 112:
																															case 141:
																															case 150:
																															case 156:
																															case 157:
																															case 165:
																															case 185:
																															case 190:
																															case 197:
																															case 198:
																															case 226:
																															case 246:
																															case 249:
																															case 250:
																															case 251:
																															case 260:
																															case 267:
																															case 269:
																															case 272:
																															case 273:
																															case 274:
																																goto end_IL_0500;
																															case 5:
																															case 6:
																															case 9:
																															case 14:
																															case 29:
																															case 36:
																															case 41:
																															case 49:
																															case 59:
																															case 60:
																															case 71:
																															case 78:
																															case 89:
																															case 92:
																															case 103:
																															case 121:
																															case 137:
																															case 143:
																															case 144:
																															case 159:
																															case 166:
																															case 171:
																															case 176:
																															case 183:
																															case 184:
																															case 192:
																															case 204:
																															case 205:
																															case 229:
																															case 234:
																															case 237:
																															case 253:
																															case 254:
																															case 259:
																															case 265:
																																goto end_IL_0497;
																															case 268:
																																goto end_IL_13cd;
																															case 221:
																																goto end_IL_13e0;
																															case 42:
																																goto end_IL_13ea;
																															case 172:
																																goto end_IL_13f5;
																															case 15:
																																goto end_IL_1405;
																															case 193:
																																goto end_IL_141a;
																															case 147:
																																goto end_IL_142a;
																															case 173:
																															case 248:
																																goto end_IL_143a;
																															case 186:
																																goto end_IL_144a;
																															case 48:
																															case 136:
																																goto end_IL_145a;
																															case 128:
																																goto end_IL_146a;
																															case 129:
																																goto end_IL_147a;
																															case 199:
																															case 262:
																																goto IL_1495;
																															}
																															continue;
																															end_IL_0497:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0588;
																												IL_08c1:
																												array[num5 - 2] = 0;
																												goto IL_08d5;
																												IL_0588:
																												if (4 >= b)
																												{
																													goto IL_0596;
																												}
																												goto IL_0750;
																												IL_0596:
																												if (4 <= b)
																												{
																													goto IL_05a1;
																												}
																												goto IL_05fd;
																												IL_05a1:
																												array[num5] = 0;
																												goto IL_05af;
																												IL_05af:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																												goto IL_05d2;
																												IL_05d2:
																												array2[num5] = null;
																												goto IL_05dc;
																												IL_05dc:
																												num5++;
																												goto IL_05ea;
																												IL_05ea:
																												ptr2 += 8;
																												break;
																												IL_05fd:
																												if (2 >= b)
																												{
																													goto IL_060b;
																												}
																												goto IL_06e1;
																												IL_060b:
																												if (2 > b)
																												{
																													goto IL_0616;
																												}
																												goto IL_067a;
																												IL_0616:
																												if (1 < b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_0624;
																												IL_0624:
																												if (1 > b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_0632;
																												IL_0632:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																												goto IL_064b;
																												IL_064b:
																												array[num5] = 0;
																												goto IL_0659;
																												IL_0659:
																												num5++;
																												goto IL_0667;
																												IL_0667:
																												ptr2 += 8;
																												break;
																												IL_067a:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																												goto IL_06ba;
																												IL_06ba:
																												array[num5 - 2] = 0;
																												goto IL_06ce;
																												IL_06ce:
																												num5--;
																												break;
																												IL_06e1:
																												if (3 < b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_06ef;
																												IL_06ef:
																												if (3 > b)
																												{
																													goto end_IL_0500;
																												}
																												num = 107;
																												goto IL_0706;
																												IL_08d5:
																												num5--;
																												break;
																												IL_0706:
																												ref int reference = ref array4[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																												goto IL_072f;
																												IL_072f:
																												ptr2 += 8;
																												goto IL_073d;
																												IL_073d:
																												num5--;
																												break;
																												IL_0750:
																												if (6 >= b)
																												{
																													goto IL_075e;
																												}
																												goto IL_0865;
																												IL_075e:
																												if (6 <= b)
																												{
																													goto IL_0769;
																												}
																												goto IL_07d0;
																												IL_0769:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																												goto IL_07a9;
																												IL_07a9:
																												array[num5 - 2] = 0;
																												goto IL_07bd;
																												IL_07bd:
																												num5--;
																												break;
																												IL_07d0:
																												if (5 < b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_07de;
																												IL_07de:
																												if (5 > b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_07ec;
																												IL_07ec:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																												num = 223;
																												goto IL_0835;
																												IL_0835:
																												array[num5 - 2] = 0;
																												num = 242;
																												goto IL_0852;
																												IL_0852:
																												num5--;
																												break;
																												IL_0865:
																												if (7 < b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_0873;
																												IL_0873:
																												if (7 > b)
																												{
																													goto end_IL_0500;
																												}
																												goto IL_0881;
																												IL_0881:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																												goto IL_08c1;
																											}
																											break;
																										}
																										goto IL_08e8;
																										IL_0c30:
																										num5--;
																										break;
																										IL_08e8:
																										if (12 < b)
																										{
																											goto IL_08f6;
																										}
																										goto IL_0a90;
																										IL_08f6:
																										if (14 >= b)
																										{
																											goto IL_0904;
																										}
																										goto IL_09ef;
																										IL_0904:
																										if (14 <= b)
																										{
																											goto IL_090f;
																										}
																										goto IL_0980;
																										IL_090f:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_096d;
																										IL_096d:
																										num5--;
																										break;
																										IL_0980:
																										if (13 < b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_098e;
																										IL_098e:
																										if (13 > b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_099c;
																										IL_099c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])() ? 1 : 0);
																										goto IL_09c0;
																										IL_09c0:
																										array[num5] = 0;
																										goto IL_09ce;
																										IL_09ce:
																										num5++;
																										goto IL_09dc;
																										IL_09dc:
																										ptr2 += 8;
																										break;
																										IL_09ef:
																										if (15 >= b)
																										{
																											goto IL_09fa;
																										}
																										goto IL_0a24;
																										IL_09fa:
																										if (15 > b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0a08;
																										IL_0a08:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										break;
																										IL_0a24:
																										if (16 < b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0a32;
																										IL_0a32:
																										if (16 > b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0a40;
																										IL_0a40:
																										array2[num5] = array6[*(int*)(ptr2 + num3)];
																										num = 200;
																										goto IL_0a61;
																										IL_0a61:
																										array[num5] = 5;
																										goto IL_0a6f;
																										IL_0a6f:
																										num5++;
																										goto IL_0a7d;
																										IL_0a7d:
																										ptr2 += 8;
																										break;
																										IL_0a90:
																										if (12 <= b)
																										{
																											break;
																										}
																										goto IL_0a9e;
																										IL_0a9e:
																										if (10 < b)
																										{
																											goto IL_0aac;
																										}
																										goto IL_0b37;
																										IL_0aac:
																										if (11 < b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0aba;
																										IL_0aba:
																										if (11 > b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0ac8;
																										IL_0ac8:
																										array[num5 - 1] = 0;
																										num = 123;
																										goto IL_0ae5;
																										IL_0ae5:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = ((delegate*<int, int>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																										goto IL_0b24;
																										IL_0b24:
																										ptr2 += 8;
																										break;
																										IL_0b37:
																										if (10 <= b)
																										{
																											goto IL_0b42;
																										}
																										goto IL_0bc0;
																										IL_0b42:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0ba4;
																										IL_0ba4:
																										num5 -= 2;
																										num = 144;
																										break;
																										IL_0bc0:
																										if (9 < b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0bce;
																										IL_0bce:
																										if (9 > b)
																										{
																											goto end_IL_0500;
																										}
																										goto IL_0bdc;
																										IL_0bdc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																										goto IL_0c1c;
																										IL_0c1c:
																										array[num5 - 2] = 0;
																										goto IL_0c30;
																									}
																									break;
																								}
																								goto IL_053b;
																								IL_0575:
																								ptr2 += 8;
																								break;
																								IL_053b:
																								array[num5] = 5;
																								goto IL_0549;
																								IL_0549:
																								array2[num5] = ((delegate*<GorillaTagger>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])();
																								goto IL_0567;
																								IL_0567:
																								num5++;
																								goto IL_0575;
																							}
																							break;
																						}
																						goto IL_0c43;
																						IL_133f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0);
																						goto IL_1380;
																						IL_0c43:
																						if (25 >= b)
																						{
																							goto IL_0c51;
																						}
																						goto IL_104d;
																						IL_0c51:
																						if (25 > b)
																						{
																							goto IL_0c5f;
																						}
																						goto IL_0fee;
																						IL_0c5f:
																						if (21 >= b)
																						{
																							goto IL_0c6d;
																						}
																						goto IL_0e84;
																						IL_0c6d:
																						if (21 <= b)
																						{
																							goto IL_0c78;
																						}
																						goto IL_0cd3;
																						IL_0c78:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0c9b;
																						IL_0c9b:
																						array[num5] = 0;
																						goto IL_0ca9;
																						IL_0ca9:
																						num5++;
																						goto IL_0cb7;
																						IL_0cb7:
																						ptr2 += 8;
																						num = 205;
																						break;
																						IL_0cd3:
																						if (19 >= b)
																						{
																							goto IL_0ce1;
																						}
																						goto IL_0e03;
																						IL_0ce1:
																						if (19 > b)
																						{
																							goto IL_0cef;
																						}
																						num = 217;
																						goto IL_0d7c;
																						IL_0cef:
																						if (18 < b)
																						{
																							goto end_IL_0500;
																						}
																						num = 101;
																						goto IL_0d06;
																						IL_1394:
																						num5--;
																						break;
																						IL_0d06:
																						if (18 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0d14;
																						IL_0d14:
																						array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																						goto IL_0d4c;
																						IL_0d4c:
																						array[num5 - 1] = 5;
																						goto IL_0d60;
																						IL_0d60:
																						ptr2 += 8;
																						break;
																						IL_1380:
																						array[num5 - 2] = 0;
																						goto IL_1394;
																						IL_0d7c:
																						array[num5 - 2] = 0;
																						goto IL_0d90;
																						IL_0d90:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (VRRig)array2[num5 - 1]) ? 1 : 0);
																						goto IL_0de2;
																						IL_0de2:
																						num5--;
																						goto IL_0df0;
																						IL_0df0:
																						ptr2 += 8;
																						break;
																						IL_0e03:
																						if (20 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0e11;
																						IL_0e11:
																						if (20 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0e1f;
																						IL_0e1f:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0e71;
																						IL_0e71:
																						num5--;
																						break;
																						IL_0e84:
																						if (23 >= b)
																						{
																							goto IL_0e92;
																						}
																						goto IL_0f7c;
																						IL_0e92:
																						if (23 <= b)
																						{
																							goto IL_0e9d;
																						}
																						goto IL_0f01;
																						IL_0e9d:
																						array[num5 - 1] = 4;
																						goto IL_0eb1;
																						IL_0eb1:
																						array2[num5 - 1] = ((delegate*<Transform, Vector3>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																						goto IL_0eee;
																						IL_0eee:
																						ptr2 += 8;
																						break;
																						IL_0f01:
																						if (22 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0f0f;
																						IL_0f0f:
																						if (22 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0f1d;
																						IL_0f1d:
																						array[num5 - 1] = 5;
																						goto IL_0f31;
																						IL_0f31:
																						array2[num5 - 1] = ((delegate*<Component, Transform>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																						goto IL_0f69;
																						IL_0f69:
																						ptr2 += 8;
																						break;
																						IL_0f7c:
																						if (24 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0f8a;
																						IL_0f8a:
																						if (24 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_0f98;
																						IL_0f98:
																						array[num5] = 5;
																						goto IL_0fa6;
																						IL_0fa6:
																						array2[num5] = ((delegate*<GorillaTagger>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])();
																						num = 225;
																						goto IL_0fcd;
																						IL_0fcd:
																						num5++;
																						goto IL_0fdb;
																						IL_0fdb:
																						ptr2 += 8;
																						break;
																						IL_0fee:
																						array2[num5 - 1] = ((delegate*<VRRig, Transform>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																						goto IL_1026;
																						IL_1026:
																						array[num5 - 1] = 5;
																						goto IL_103a;
																						IL_103a:
																						ptr2 += 8;
																						break;
																						IL_104d:
																						if (29 >= b)
																						{
																							goto IL_105b;
																						}
																						goto IL_1231;
																						IL_105b:
																						if (29 > b)
																						{
																							goto IL_1069;
																						}
																						goto IL_11c0;
																						IL_1069:
																						if (27 >= b)
																						{
																							goto IL_1077;
																						}
																						goto IL_118c;
																						IL_1077:
																						if (27 > b)
																						{
																							goto IL_1085;
																						}
																						goto IL_1105;
																						IL_1085:
																						if (26 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_1093;
																						IL_1093:
																						if (26 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_10a1;
																						IL_10a1:
																						array[num5 - 1] = 4;
																						goto IL_10b5;
																						IL_10b5:
																						array2[num5 - 1] = ((delegate*<Transform, Vector3>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																						goto IL_10f2;
																						IL_10f2:
																						ptr2 += 8;
																						break;
																						IL_1105:
																						array[num5 - 2] = 3;
																						goto IL_1119;
																						IL_1119:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Vector3, Vector3, float>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																						goto IL_116b;
																						IL_116b:
																						num5--;
																						goto IL_1179;
																						IL_1179:
																						ptr2 += 8;
																						break;
																						IL_118c:
																						if (28 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_119a;
																						IL_119a:
																						if (28 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_11a8;
																						IL_11a8:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_11c0:
																						array2[num5 - 1] = ((delegate*<VRRig, Transform>)GetCustomAttributesDataPERSIAN[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																						num = 276;
																						goto IL_1201;
																						IL_1201:
																						array[num5 - 1] = 5;
																						num = 275;
																						goto IL_121e;
																						IL_121e:
																						ptr2 += 8;
																						break;
																						IL_1231:
																						if (31 >= b)
																						{
																							goto IL_123f;
																						}
																						goto IL_1329;
																						IL_123f:
																						if (31 > b)
																						{
																							goto IL_124a;
																						}
																						num = 77;
																						goto IL_12c1;
																						IL_124a:
																						if (30 < b)
																						{
																							goto end_IL_0500;
																						}
																						num = 12;
																						goto IL_1261;
																						IL_13af:
																						if (33 <= b)
																						{
																						}
																						goto end_IL_0500;
																						IL_1261:
																						if (30 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_126f;
																						IL_126f:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																						goto IL_1289;
																						IL_1289:
																						array[num5] = 3;
																						goto IL_1297;
																						IL_1297:
																						num5++;
																						goto IL_12a5;
																						IL_12a5:
																						ptr2 += 8;
																						break;
																						IL_13a4:
																						if (33 < b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_13af;
																						IL_12c1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]))) ? 1 : 0);
																						goto IL_1302;
																						IL_1302:
																						array[num5 - 2] = 0;
																						goto IL_1316;
																						IL_1316:
																						num5--;
																						break;
																						IL_1329:
																						if (32 >= b)
																						{
																							goto IL_1334;
																						}
																						goto IL_13a4;
																						IL_1334:
																						if (32 > b)
																						{
																							goto end_IL_0500;
																						}
																						goto IL_133f;
																					}
																					goto end_IL_0510;
																					continue;
																					end_IL_0500:
																					break;
																					IL_0500:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_0510:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
															}
															goto IL_1495;
															IL_1495:
															return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0;
															continue;
															end_IL_13cd:
															break;
														}
														continue;
														end_IL_13e0:
														break;
													}
													continue;
													end_IL_13ea:
													break;
												}
												continue;
												end_IL_13f5:
												break;
											}
											continue;
											end_IL_1405:
											break;
										}
										continue;
										end_IL_141a:
										break;
									}
									continue;
									end_IL_142a:
									break;
								}
								continue;
								end_IL_143a:
								break;
							}
							continue;
							end_IL_144a:
							break;
						}
						continue;
						end_IL_145a:
						break;
					}
					continue;
					end_IL_146a:
					break;
				}
				continue;
				end_IL_147a:
				break;
			}
		}
	}

	public Class144()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num6;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_3;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 506;
		num6 = 11;
		num4 = 46;
		num6 = 286;
		num6 = 22;
		int num7 = smethod_5(46, 22);
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_1(int int_3, int int_4)
	{
		int num = 82;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 81;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRuntimeInterfaceAsIntPtrContract.IIDIDefinitionIdentityCachePathValue);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02bc:
															byte b = *ptr2;
															num = 4;
															while (true)
															{
																IL_02ac:
																ptr2++;
																while (true)
																{
																	IL_029c:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_027c:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_025c:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_024c:
																									if (3 <= b)
																									{
																										num = 135;
																										while (true)
																										{
																											if (num != 135)
																											{
																												if (num != 1116)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 1:
																													goto IL_024c;
																												case 60:
																												case 94:
																													goto IL_025c;
																												case 17:
																													goto IL_026c;
																												case 124:
																													goto IL_027c;
																												case 6:
																													goto IL_028c;
																												case 40:
																													goto IL_029c;
																												case 4:
																													goto IL_02ac;
																												case 51:
																												case 63:
																													goto IL_02bc;
																												case 16:
																													goto IL_02d0;
																												case 110:
																													goto IL_02db;
																												case 75:
																												case 127:
																													goto IL_02ee;
																												case 83:
																													goto IL_02fc;
																												case 18:
																												case 114:
																													goto IL_030a;
																												case 38:
																													goto IL_0378;
																												case 47:
																													goto IL_038b;
																												case 74:
																													goto IL_03cb;
																												case 34:
																													goto IL_03df;
																												case 23:
																												case 85:
																													goto IL_03fb;
																												case 24:
																												case 72:
																													goto IL_0406;
																												case 101:
																													goto IL_0414;
																												case 103:
																												case 109:
																													goto IL_0422;
																												case 97:
																													goto IL_043a;
																												case 31:
																												case 66:
																													goto IL_0448;
																												case 68:
																													goto IL_0471;
																												case 22:
																													goto IL_047f;
																												case 99:
																													goto IL_0492;
																												case 52:
																												case 122:
																													goto IL_04a0;
																												case 15:
																												case 86:
																													goto IL_04ab;
																												case 50:
																													goto IL_04b9;
																												case 35:
																												case 84:
																													goto IL_04c7;
																												case 20:
																													goto IL_04e3;
																												case 37:
																												case 61:
																													goto IL_04ee;
																												case 33:
																													goto IL_0501;
																												case 119:
																													goto IL_050f;
																												case 59:
																												case 78:
																													goto IL_051d;
																												case 36:
																													goto IL_0531;
																												case 29:
																													goto IL_0570;
																												case 111:
																													goto IL_0583;
																												case 2:
																												case 108:
																													goto IL_0591;
																												case 9:
																												case 65:
																													goto IL_059c;
																												case 5:
																													goto IL_05aa;
																												case 19:
																												case 105:
																													goto IL_05b8;
																												case 11:
																													goto IL_05d1;
																												case 87:
																													goto IL_05df;
																												case 7:
																													goto IL_05ed;
																												case 56:
																													goto IL_0600;
																												case 54:
																												case 100:
																													goto IL_060b;
																												case 48:
																													goto IL_0619;
																												case 102:
																													goto IL_063c;
																												case 92:
																													goto IL_0646;
																												case 93:
																													goto IL_0654;
																												case 10:
																												case 12:
																												case 13:
																												case 26:
																												case 28:
																												case 32:
																												case 43:
																												case 46:
																												case 55:
																												case 57:
																												case 62:
																												case 64:
																												case 70:
																												case 76:
																												case 77:
																												case 79:
																												case 80:
																												case 91:
																												case 104:
																												case 113:
																												case 115:
																												case 116:
																												case 117:
																												case 123:
																												case 128:
																													goto end_IL_028c;
																												case 96:
																													goto IL_0693;
																												case 25:
																													goto IL_06a1;
																												case 107:
																													goto IL_06af;
																												case 41:
																												case 73:
																													goto end_IL_0239;
																												case 90:
																													goto IL_0708;
																												case 95:
																													goto IL_071c;
																												case 0:
																												case 14:
																												case 21:
																												case 27:
																												case 42:
																												case 44:
																												case 45:
																												case 49:
																												case 53:
																												case 58:
																												case 67:
																												case 89:
																												case 112:
																												case 118:
																												case 125:
																													goto end_IL_026c;
																												case 30:
																													goto end_IL_0733;
																												case 121:
																													goto end_IL_0746;
																												case 69:
																													goto end_IL_0750;
																												case 106:
																													goto end_IL_075b;
																												case 8:
																													goto end_IL_0770;
																												case 98:
																												case 126:
																													goto end_IL_0785;
																												case 88:
																													goto end_IL_0795;
																												case 3:
																												case 39:
																													goto end_IL_07a5;
																												case 81:
																													goto end_IL_07b5;
																												case 82:
																													goto end_IL_07c5;
																												case 71:
																												case 120:
																													goto IL_07e9;
																												}
																												continue;
																											}
																											goto IL_038b;
																											IL_03cb:
																											array[num5 - 2] = 0;
																											goto IL_03df;
																											IL_03df:
																											num5--;
																											goto end_IL_026c;
																											IL_038b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03cb;
																											continue;
																											end_IL_0239:
																											break;
																										}
																										break;
																									}
																									goto IL_02d0;
																									IL_030a:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0378;
																									IL_0378:
																									num5 -= 2;
																									goto end_IL_026c;
																									IL_02d0:
																									if (1 >= b)
																									{
																										goto IL_02db;
																									}
																									goto IL_02ee;
																									IL_02db:
																									if (1 > b)
																									{
																									}
																									goto end_IL_028c;
																									IL_02ee:
																									if (2 < b)
																									{
																										goto end_IL_028c;
																									}
																									goto IL_02fc;
																									IL_02fc:
																									if (2 > b)
																									{
																										goto end_IL_028c;
																									}
																									goto IL_030a;
																								}
																								break;
																							}
																							num = 85;
																							goto IL_03fb;
																							IL_0471:
																							ptr2 += 8;
																							goto IL_047f;
																							IL_047f:
																							num5--;
																							goto end_IL_026c;
																							IL_03fb:
																							if (4 < b)
																							{
																								goto IL_0406;
																							}
																							goto IL_043a;
																							IL_0406:
																							if (5 < b)
																							{
																								goto end_IL_028c;
																							}
																							goto IL_0414;
																							IL_0414:
																							if (5 > b)
																							{
																								goto end_IL_028c;
																							}
																							goto IL_0422;
																							IL_0422:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_026c;
																							IL_043a:
																							if (4 > b)
																							{
																								goto end_IL_028c;
																							}
																							goto IL_0448;
																							IL_0448:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0471;
																						}
																						goto IL_06bf;
																						continue;
																						end_IL_026c:
																						break;
																						IL_026c:;
																					}
																					break;
																				}
																				goto IL_0492;
																				IL_0708:
																				array[num5 - 2] = 0;
																				goto IL_071c;
																				IL_0492:
																				if (9 < b)
																				{
																					goto IL_04a0;
																				}
																				goto IL_0583;
																				IL_04a0:
																				if (11 < b)
																				{
																					goto IL_04ab;
																				}
																				goto IL_04e3;
																				IL_04ab:
																				if (12 < b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_04b9;
																				IL_04b9:
																				if (12 > b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_04c7;
																				IL_04c7:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_04e3:
																				if (11 <= b)
																				{
																					goto IL_04ee;
																				}
																				goto IL_0501;
																				IL_04ee:
																				num5--;
																				break;
																				IL_0501:
																				if (10 < b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_050f;
																				IL_050f:
																				if (10 > b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_051d;
																				IL_051d:
																				array[num5 - 1] = 0;
																				goto IL_0531;
																				IL_0531:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CreationTimeUtcWindowClassHostDll[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0570;
																				IL_0570:
																				ptr2 += 8;
																				break;
																				IL_0583:
																				if (9 > b)
																				{
																					goto IL_0591;
																				}
																				goto IL_06bf;
																				IL_0591:
																				if (7 < b)
																				{
																					goto IL_059c;
																				}
																				goto IL_0600;
																				IL_059c:
																				if (8 < b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_05aa;
																				IL_05aa:
																				if (8 > b)
																				{
																					goto end_IL_028c;
																				}
																				goto IL_05b8;
																				IL_05b8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05d1;
																				IL_05d1:
																				array[num5] = 0;
																				goto IL_05df;
																				IL_05df:
																				num5++;
																				goto IL_05ed;
																				IL_05ed:
																				ptr2 += 8;
																				break;
																				IL_0600:
																				if (7 > b)
																				{
																					num = 13;
																					goto end_IL_028c;
																				}
																				goto IL_060b;
																				IL_060b:
																				array[num5] = 0;
																				goto IL_0619;
																				IL_0619:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_063c;
																				IL_063c:
																				array2[num5] = null;
																				goto IL_0646;
																				IL_0646:
																				num5++;
																				goto IL_0654;
																				IL_0654:
																				ptr2 += 8;
																				break;
																				IL_071c:
																				num5--;
																				num = 49;
																				break;
																				IL_06bf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 90;
																				goto IL_0708;
																			}
																			goto end_IL_029c;
																			continue;
																			end_IL_028c:
																			break;
																			IL_028c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0693;
																	IL_06af:
																	ptr2 += 8;
																	break;
																	IL_06a1:
																	num5++;
																	goto IL_06af;
																	IL_0693:
																	array[num5] = 0;
																	goto IL_06a1;
																	continue;
																	end_IL_029c:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07e9;
													IL_07e9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0733:
													break;
												}
												continue;
												end_IL_0746:
												break;
											}
											continue;
											end_IL_0750:
											break;
										}
										continue;
										end_IL_075b:
										break;
									}
									continue;
									end_IL_0770:
									break;
								}
								continue;
								end_IL_0785:
								break;
							}
							continue;
							end_IL_0795:
							break;
						}
						continue;
						end_IL_07a5:
						break;
					}
					continue;
					end_IL_07b5:
					break;
				}
				continue;
				end_IL_07c5:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 67;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCheckSumAlgorithmIdIsLetterOrDigit.getScheduledExclusiveAssemblyReferenceDependentAssemblyDescription);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d0:
														byte b = *ptr2;
														while (true)
														{
															IL_02c0:
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0290:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0280:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0270:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0260:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0230:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0202:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 120;
																														while (true)
																														{
																															if (num != 120)
																															{
																																if (num != 1101)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 49:
																																	goto IL_0202;
																																case 70:
																																case 91:
																																	goto IL_0230;
																																case 77:
																																	goto IL_0240;
																																case 29:
																																case 80:
																																	goto IL_0250;
																																case 31:
																																	goto IL_0260;
																																case 71:
																																case 111:
																																	goto IL_0270;
																																case 25:
																																	goto IL_0280;
																																case 85:
																																	goto IL_0290;
																																case 96:
																																	goto IL_02a0;
																																case 107:
																																	goto IL_02b0;
																																case 81:
																																	goto IL_02c0;
																																case 1:
																																case 97:
																																	goto IL_02d0;
																																case 13:
																																	goto IL_02e5;
																																case 5:
																																	goto IL_02f3;
																																case 55:
																																	goto IL_0306;
																																case 76:
																																	goto IL_0319;
																																case 50:
																																case 108:
																																	goto IL_0324;
																																case 86:
																																	goto IL_033c;
																																case 36:
																																case 38:
																																	goto IL_0347;
																																case 19:
																																	goto IL_0355;
																																case 48:
																																case 106:
																																	goto IL_0363;
																																case 0:
																																	goto IL_038c;
																																case 34:
																																	goto IL_039a;
																																case 40:
																																	goto IL_03ad;
																																case 37:
																																case 72:
																																	goto IL_03bb;
																																case 95:
																																	goto IL_03dd;
																																case 100:
																																	goto IL_03eb;
																																case 66:
																																	goto IL_03f9;
																																case 12:
																																case 109:
																																	goto IL_040c;
																																case 101:
																																	goto IL_044c;
																																case 33:
																																	goto IL_0460;
																																case 4:
																																	goto IL_047c;
																																case 83:
																																case 84:
																																	goto IL_0487;
																																case 2:
																																case 39:
																																	goto IL_0492;
																																case 60:
																																	goto IL_04a0;
																																case 30:
																																	goto IL_04b3;
																																case 75:
																																case 110:
																																	goto IL_04c1;
																																case 63:
																																	goto IL_04dd;
																																case 51:
																																case 82:
																																	goto IL_04e8;
																																case 61:
																																	goto IL_054a;
																																case 58:
																																	goto IL_055d;
																																case 8:
																																	goto IL_0568;
																																case 57:
																																case 79:
																																	goto IL_0576;
																																case 113:
																																	goto IL_05b6;
																																case 88:
																																	goto IL_05ca;
																																case 104:
																																	goto IL_05da;
																																case 28:
																																	goto IL_05e5;
																																case 15:
																																case 64:
																																	goto IL_05f0;
																																case 56:
																																	goto IL_0613;
																																case 47:
																																	goto IL_0621;
																																case 54:
																																	goto IL_062f;
																																case 6:
																																case 7:
																																case 14:
																																case 17:
																																case 18:
																																case 20:
																																case 22:
																																case 27:
																																case 32:
																																case 43:
																																case 45:
																																case 46:
																																case 62:
																																case 65:
																																case 78:
																																case 89:
																																case 92:
																																case 98:
																																case 99:
																																case 103:
																																case 105:
																																	goto end_IL_0240;
																																case 3:
																																case 9:
																																case 10:
																																case 11:
																																case 16:
																																case 21:
																																case 26:
																																case 52:
																																case 69:
																																case 73:
																																case 87:
																																case 93:
																																case 94:
																																case 112:
																																	goto end_IL_01ef;
																																case 44:
																																	goto end_IL_0652;
																																case 67:
																																	goto end_IL_0665;
																																case 24:
																																	goto end_IL_066f;
																																case 59:
																																	goto end_IL_067a;
																																case 53:
																																case 68:
																																	goto end_IL_0698;
																																case 74:
																																	goto end_IL_06a8;
																																case 35:
																																case 90:
																																	goto end_IL_06b8;
																																case 41:
																																	goto end_IL_06c8;
																																case 42:
																																	goto end_IL_06d8;
																																case 23:
																																case 102:
																																	goto IL_06f3;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_02e5;
																															IL_02e5:
																															num5++;
																															goto IL_02f3;
																															IL_02f3:
																															ptr2 += 8;
																															break;
																															continue;
																															end_IL_01ef:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02b0;
																												continue;
																												end_IL_0240:
																												break;
																												IL_0240:;
																											}
																											break;
																											IL_0250:;
																										}
																										break;
																									}
																									goto IL_0306;
																									IL_0306:
																									if (4 <= b)
																									{
																										goto end_IL_02b0;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0319;
																							IL_03f9:
																							ptr2 += 8;
																							goto end_IL_02b0;
																							IL_0319:
																							if (3 <= b)
																							{
																								goto IL_0324;
																							}
																							goto IL_033c;
																							IL_0324:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02b0;
																							IL_033c:
																							if (1 < b)
																							{
																								goto IL_0347;
																							}
																							goto IL_03ad;
																							IL_0347:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0355;
																							IL_0355:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0363;
																							IL_0363:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_038c;
																							IL_038c:
																							ptr2 += 8;
																							goto IL_039a;
																							IL_039a:
																							num5--;
																							goto end_IL_02b0;
																							IL_03ad:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_03bb;
																							IL_03bb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 95;
																							goto IL_03dd;
																							IL_03dd:
																							array[num5] = 0;
																							goto IL_03eb;
																							IL_03eb:
																							num5++;
																							goto IL_03f9;
																						}
																						break;
																					}
																					goto IL_040c;
																					IL_0460:
																					num5--;
																					num = 94;
																					goto end_IL_02b0;
																					IL_040c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_044c;
																					IL_044c:
																					array[num5 - 2] = 0;
																					goto IL_0460;
																				}
																				break;
																			}
																			goto IL_047c;
																			IL_062f:
																			ptr2 += 8;
																			goto end_IL_02b0;
																			IL_047c:
																			if (9 < b)
																			{
																				goto IL_0487;
																			}
																			goto IL_04dd;
																			IL_0487:
																			if (10 < b)
																			{
																				goto IL_0492;
																			}
																			goto IL_04b3;
																			IL_0492:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04a0;
																			IL_04a0:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_04b3:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04c1;
																			IL_04c1:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02b0;
																			IL_04dd:
																			if (9 <= b)
																			{
																				goto IL_04e8;
																			}
																			goto IL_055d;
																			IL_04e8:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_054a;
																			IL_054a:
																			num5 -= 2;
																			goto end_IL_02b0;
																			IL_055d:
																			if (7 >= b)
																			{
																				goto IL_0568;
																			}
																			goto IL_05da;
																			IL_0568:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0576;
																			IL_0576:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05b6;
																			IL_05b6:
																			array[num5 - 2] = 0;
																			goto IL_05ca;
																			IL_05ca:
																			num5--;
																			goto end_IL_02b0;
																			IL_05da:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_05e5;
																			IL_05e5:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05f0;
																			IL_05f0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0613;
																			IL_0613:
																			array[num5] = 0;
																			goto IL_0621;
																			IL_0621:
																			num5++;
																			goto IL_062f;
																		}
																		break;
																		IL_02a0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02b0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06f3;
												IL_06f3:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0652:
												break;
											}
											continue;
											end_IL_0665:
											break;
										}
										continue;
										end_IL_066f:
										break;
									}
									continue;
									end_IL_067a:
									break;
								}
								continue;
								end_IL_0698:
								break;
							}
							continue;
							end_IL_06a8:
							break;
						}
						continue;
						end_IL_06b8:
						break;
					}
					continue;
					end_IL_06c8:
					break;
				}
				continue;
				end_IL_06d8:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ShrUnKeyPair.getPercentDecimalDigitsscode);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_026d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 33;
																		while (true)
																		{
																			if (6 >= b)
																			{
																				while (true)
																				{
																					if (6 > b)
																					{
																						while (true)
																						{
																							if (3 >= b)
																							{
																								while (true)
																								{
																									if (3 > b)
																									{
																										num = 119;
																										while (true)
																										{
																											if (num == 119)
																											{
																												goto IL_0528;
																											}
																											if (num != 1100)
																											{
																												goto IL_056e;
																											}
																											switch (num)
																											{
																											case 97:
																												goto end_IL_0207;
																											case 107:
																												goto end_IL_021a;
																											case 111:
																												goto end_IL_022d;
																											case 33:
																												goto end_IL_023a;
																											case 24:
																												goto end_IL_024a;
																											case 29:
																												goto IL_026d;
																											case 65:
																												goto end_IL_026d;
																											case 66:
																											case 100:
																												goto end_IL_027d;
																											case 49:
																											case 81:
																												goto IL_0298;
																											case 4:
																											case 7:
																												goto IL_02a3;
																											case 56:
																												goto IL_02b1;
																											case 25:
																											case 47:
																												goto IL_02bf;
																											case 22:
																												goto IL_02cd;
																											case 60:
																												goto IL_02f0;
																											case 61:
																												goto IL_02fa;
																											case 27:
																												goto IL_030d;
																											case 78:
																											case 83:
																												goto IL_0320;
																											case 92:
																											case 106:
																												goto IL_0338;
																											case 48:
																											case 85:
																												goto IL_0343;
																											case 77:
																												goto IL_034e;
																											case 11:
																											case 55:
																												goto IL_035c;
																											case 62:
																												goto IL_0378;
																											case 103:
																												goto IL_0386;
																											case 35:
																												goto IL_03a2;
																											case 44:
																											case 105:
																												goto IL_03ad;
																											case 45:
																												goto IL_040f;
																											case 18:
																												goto IL_0422;
																											case 46:
																												goto IL_042d;
																											case 10:
																											case 26:
																												goto IL_043b;
																											case 53:
																												goto IL_0480;
																											case 70:
																												goto IL_048e;
																											case 8:
																											case 51:
																												goto IL_049c;
																											case 80:
																												goto IL_04bf;
																											case 95:
																												goto IL_04cd;
																											case 74:
																												goto IL_04db;
																											case 108:
																												goto IL_04ee;
																											case 109:
																												goto IL_0501;
																											case 91:
																												goto IL_0515;
																											case 90:
																												goto IL_0528;
																											case 63:
																												goto IL_0533;
																											case 0:
																											case 54:
																												goto IL_054c;
																											case 2:
																												goto IL_056e;
																											case 19:
																												goto IL_057c;
																											case 12:
																												goto IL_058a;
																											case 86:
																												goto IL_059d;
																											case 42:
																												goto IL_05ab;
																											case 50:
																											case 88:
																												goto IL_05b9;
																											case 28:
																												goto IL_05eb;
																											case 23:
																												goto IL_05f9;
																											case 102:
																											case 112:
																												goto IL_060c;
																											case 59:
																												goto IL_064c;
																											case 5:
																												goto IL_0660;
																											case 1:
																											case 3:
																											case 6:
																											case 15:
																											case 17:
																											case 32:
																											case 64:
																											case 71:
																											case 73:
																											case 75:
																											case 76:
																											case 79:
																											case 93:
																											case 94:
																											case 96:
																											case 98:
																											case 99:
																											case 101:
																											case 104:
																											case 110:
																												goto end_IL_025a;
																											case 9:
																											case 16:
																											case 20:
																											case 21:
																											case 30:
																											case 34:
																											case 38:
																											case 39:
																											case 57:
																											case 58:
																											case 68:
																											case 69:
																											case 72:
																											case 87:
																												goto end_IL_028d;
																											case 14:
																												goto end_IL_068c;
																											case 82:
																												goto end_IL_069f;
																											case 36:
																												goto end_IL_06a9;
																											case 31:
																												goto end_IL_06b4;
																											case 37:
																											case 84:
																												goto end_IL_06c9;
																											case 43:
																												goto end_IL_06d9;
																											case 52:
																											case 67:
																												goto end_IL_06e9;
																											case 40:
																												goto end_IL_06f9;
																											case 41:
																												goto end_IL_0709;
																											case 13:
																											case 89:
																												goto IL_0724;
																											}
																											continue;
																											IL_05b9:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 28;
																											goto IL_05eb;
																											IL_05eb:
																											ptr2 += 8;
																											goto IL_05f9;
																											IL_0528:
																											if (1 >= b)
																											{
																												goto IL_0533;
																											}
																											goto IL_059d;
																											IL_0533:
																											if (1 > b)
																											{
																												num = 98;
																												goto end_IL_025a;
																											}
																											goto IL_054c;
																											IL_05f9:
																											num5--;
																											goto end_IL_028d;
																											IL_054c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 2;
																											goto IL_056e;
																											IL_056e:
																											array[num5] = 0;
																											goto IL_057c;
																											IL_057c:
																											num5++;
																											goto IL_058a;
																											IL_058a:
																											ptr2 += 8;
																											goto end_IL_028d;
																											IL_059d:
																											if (2 < b)
																											{
																												goto end_IL_025a;
																											}
																											goto IL_05ab;
																											IL_05ab:
																											if (2 > b)
																											{
																												goto end_IL_025a;
																											}
																											goto IL_05b9;
																											continue;
																											end_IL_0207:
																											break;
																										}
																										continue;
																									}
																									goto IL_0320;
																									IL_0320:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_028d;
																									continue;
																									end_IL_021a:
																									break;
																								}
																								continue;
																							}
																							goto IL_0298;
																							IL_030d:
																							if (4 > b)
																							{
																								goto end_IL_025a;
																							}
																							goto end_IL_028d;
																							IL_0298:
																							if (4 < b)
																							{
																								goto IL_02a3;
																							}
																							goto IL_030d;
																							IL_02a3:
																							if (5 < b)
																							{
																								goto end_IL_025a;
																							}
																							goto IL_02b1;
																							IL_02b1:
																							if (5 > b)
																							{
																								goto end_IL_025a;
																							}
																							goto IL_02bf;
																							IL_02bf:
																							array[num5] = 0;
																							goto IL_02cd;
																							IL_02cd:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_02f0;
																							IL_02f0:
																							array2[num5] = null;
																							goto IL_02fa;
																							IL_02fa:
																							num5++;
																							goto IL_04ee;
																							IL_04ee:
																							ptr2 += 8;
																							goto end_IL_028d;
																							continue;
																							end_IL_022d:
																							break;
																						}
																						continue;
																					}
																					goto IL_060c;
																					IL_0660:
																					num5--;
																					goto end_IL_028d;
																					IL_060c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_064c;
																					IL_064c:
																					array[num5 - 2] = 0;
																					goto IL_0660;
																					continue;
																					end_IL_023a:
																					break;
																				}
																				continue;
																			}
																			goto IL_0338;
																			IL_04cd:
																			num5++;
																			goto IL_04db;
																			IL_0338:
																			if (9 < b)
																			{
																				goto IL_0343;
																			}
																			goto IL_03a2;
																			IL_0343:
																			if (10 >= b)
																			{
																				goto IL_034e;
																			}
																			goto IL_0378;
																			IL_034e:
																			if (10 > b)
																			{
																				goto end_IL_025a;
																			}
																			goto IL_035c;
																			IL_035c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_028d;
																			IL_0378:
																			if (11 < b)
																			{
																				goto end_IL_025a;
																			}
																			goto IL_0386;
																			IL_0386:
																			if (11 > b)
																			{
																				num = 79;
																			}
																			goto end_IL_025a;
																			IL_04db:
																			ptr2 += 8;
																			goto end_IL_028d;
																			IL_03a2:
																			if (9 <= b)
																			{
																				goto IL_03ad;
																			}
																			goto IL_0422;
																			IL_03ad:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_040f;
																			IL_040f:
																			num5 -= 2;
																			goto end_IL_028d;
																			IL_0422:
																			if (7 >= b)
																			{
																				goto IL_042d;
																			}
																			goto IL_0480;
																			IL_042d:
																			if (7 > b)
																			{
																				goto end_IL_025a;
																			}
																			goto IL_043b;
																			IL_043b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0501;
																			IL_0501:
																			array[num5 - 2] = 0;
																			goto IL_0515;
																			IL_0515:
																			num5--;
																			goto end_IL_028d;
																			IL_0480:
																			if (8 < b)
																			{
																				goto end_IL_025a;
																			}
																			goto IL_048e;
																			IL_048e:
																			if (8 > b)
																			{
																				goto end_IL_025a;
																			}
																			goto IL_049c;
																			IL_049c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04bf;
																			IL_04bf:
																			array[num5] = 0;
																			goto IL_04cd;
																			continue;
																			end_IL_024a:
																			break;
																		}
																		continue;
																		end_IL_025a:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 30;
																goto end_IL_028d;
																continue;
																end_IL_026d:
																break;
															}
															continue;
															end_IL_027d:
															break;
														}
														continue;
														end_IL_028d:
														break;
													}
													continue;
												}
												goto IL_0724;
												IL_0724:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068c:
												break;
											}
											continue;
											end_IL_069f:
											break;
										}
										continue;
										end_IL_06a9:
										break;
									}
									continue;
									end_IL_06b4:
									break;
								}
								continue;
								end_IL_06c9:
								break;
							}
							continue;
							end_IL_06d9:
							break;
						}
						continue;
						end_IL_06e9:
						break;
					}
					continue;
					end_IL_06f9:
					break;
				}
				continue;
				end_IL_0709:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetArgNameoptions.EmptyStructParent);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_027e:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_025e:
																			if (6 < b)
																			{
																				goto IL_0467;
																			}
																			while (true)
																			{
																				IL_0251:
																				if (6 <= b)
																				{
																					while (true)
																					{
																						IL_0206:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 121;
																						while (true)
																						{
																							if (num != 121)
																							{
																								if (num != 1102)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 75:
																								case 77:
																									goto IL_0206;
																								case 17:
																									goto IL_0251;
																								case 88:
																									goto IL_025e;
																								case 91:
																									goto end_IL_025e;
																								case 55:
																									goto IL_027e;
																								case 20:
																									goto end_IL_027e;
																								case 3:
																								case 78:
																									goto end_IL_028e;
																								case 32:
																								case 66:
																									goto IL_02a9;
																								case 64:
																									goto IL_02b7;
																								case 47:
																									goto IL_02c2;
																								case 76:
																									goto IL_02d5;
																								case 7:
																									goto IL_02e3;
																								case 21:
																								case 73:
																									goto IL_02f1;
																								case 46:
																									goto IL_02ff;
																								case 39:
																									goto IL_0322;
																								case 53:
																									goto IL_032c;
																								case 57:
																									goto IL_033a;
																								case 104:
																									goto IL_034d;
																								case 61:
																								case 93:
																									goto IL_0358;
																								case 9:
																								case 26:
																									goto IL_0370;
																								case 30:
																								case 44:
																									goto IL_037b;
																								case 29:
																									goto IL_0389;
																								case 18:
																								case 68:
																									goto IL_0397;
																								case 22:
																									goto IL_03c0;
																								case 63:
																									goto IL_03ce;
																								case 19:
																									goto IL_03e1;
																								case 16:
																								case 38:
																									goto IL_03ef;
																								case 109:
																									goto IL_0408;
																								case 25:
																									goto IL_041f;
																								case 80:
																									goto IL_042d;
																								case 89:
																									goto IL_0454;
																								case 84:
																									goto IL_0467;
																								case 102:
																									goto IL_0475;
																								case 111:
																								case 112:
																									goto IL_0480;
																								case 56:
																									goto IL_04e2;
																								case 2:
																								case 79:
																									goto end_IL_01f3;
																								case 51:
																								case 74:
																									goto IL_0509;
																								case 71:
																									goto IL_0517;
																								case 36:
																								case 42:
																									goto IL_0525;
																								case 6:
																									goto IL_0548;
																								case 95:
																									goto IL_0556;
																								case 54:
																									goto IL_0564;
																								case 58:
																									goto IL_0577;
																								case 49:
																								case 86:
																									goto IL_0585;
																								case 108:
																									goto IL_05c5;
																								case 67:
																									goto IL_05d9;
																								case 52:
																								case 114:
																									goto IL_05e9;
																								case 101:
																									goto IL_05f4;
																								case 24:
																								case 85:
																									goto IL_0608;
																								case 23:
																									goto IL_0621;
																								case 40:
																									goto IL_062c;
																								case 1:
																								case 5:
																								case 8:
																								case 10:
																								case 11:
																								case 33:
																								case 41:
																								case 43:
																								case 45:
																								case 48:
																								case 50:
																								case 59:
																								case 62:
																								case 65:
																								case 70:
																								case 82:
																								case 87:
																								case 92:
																								case 94:
																								case 99:
																								case 103:
																									goto end_IL_026e;
																								case 0:
																								case 4:
																								case 13:
																								case 14:
																								case 27:
																								case 34:
																								case 35:
																								case 37:
																								case 69:
																								case 72:
																								case 81:
																								case 83:
																								case 90:
																								case 105:
																									goto end_IL_029e;
																								case 31:
																									goto end_IL_064a;
																								case 100:
																									goto end_IL_065d;
																								case 28:
																									goto end_IL_0667;
																								case 113:
																									goto end_IL_0672;
																								case 97:
																								case 110:
																									goto end_IL_0687;
																								case 98:
																									goto end_IL_0697;
																								case 15:
																								case 96:
																									goto end_IL_06a7;
																								case 106:
																									goto end_IL_06b7;
																								case 107:
																									goto end_IL_06c7;
																								case 12:
																								case 60:
																									goto IL_06e2;
																								}
																								continue;
																							}
																							array[num5 - 2] = 0;
																							goto IL_0454;
																							IL_0454:
																							num5--;
																							goto end_IL_029e;
																							continue;
																							end_IL_01f3:
																							break;
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_02a9;
																				IL_042d:
																				ptr2 += 8;
																				goto end_IL_029e;
																				IL_02a9:
																				if (3 < b)
																				{
																					goto IL_02b7;
																				}
																				goto IL_034d;
																				IL_02b7:
																				if (4 >= b)
																				{
																					goto IL_02c2;
																				}
																				goto IL_02d5;
																				IL_02c2:
																				if (4 <= b)
																				{
																					goto end_IL_029e;
																				}
																				goto end_IL_026e;
																				IL_02d5:
																				if (5 < b)
																				{
																					goto end_IL_026e;
																				}
																				goto IL_02e3;
																				IL_02e3:
																				if (5 > b)
																				{
																					goto end_IL_026e;
																				}
																				goto IL_02f1;
																				IL_02f1:
																				array[num5] = 0;
																				goto IL_02ff;
																				IL_02ff:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0322;
																				IL_0322:
																				array2[num5] = null;
																				goto IL_032c;
																				IL_032c:
																				num5++;
																				goto IL_033a;
																				IL_033a:
																				ptr2 += 8;
																				goto end_IL_029e;
																				IL_034d:
																				if (3 <= b)
																				{
																					goto IL_0358;
																				}
																				goto IL_0370;
																				IL_0358:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_029e;
																				IL_0370:
																				if (1 < b)
																				{
																					goto IL_037b;
																				}
																				goto IL_03e1;
																				IL_037b:
																				if (2 < b)
																				{
																					goto end_IL_026e;
																				}
																				goto IL_0389;
																				IL_0389:
																				if (2 > b)
																				{
																					goto end_IL_026e;
																				}
																				goto IL_0397;
																				IL_0397:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c0;
																				IL_03c0:
																				ptr2 += 8;
																				goto IL_03ce;
																				IL_03ce:
																				num5--;
																				goto end_IL_029e;
																				IL_03e1:
																				if (1 > b)
																				{
																					goto end_IL_026e;
																				}
																				goto IL_03ef;
																				IL_03ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0408;
																				IL_0408:
																				array[num5] = 0;
																				num = 25;
																				goto IL_041f;
																				IL_041f:
																				num5++;
																				goto IL_042d;
																			}
																			goto IL_04fe;
																			IL_0608:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_029e;
																			IL_0467:
																			if (9 >= b)
																			{
																				goto IL_0475;
																			}
																			goto IL_05e9;
																			IL_0475:
																			if (9 <= b)
																			{
																				goto IL_0480;
																			}
																			num = 2;
																			goto IL_04fe;
																			IL_0480:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04e2;
																			IL_04e2:
																			num5 -= 2;
																			goto end_IL_029e;
																			IL_0621:
																			if (11 < b)
																			{
																				goto end_IL_026e;
																			}
																			goto IL_062c;
																			IL_04fe:
																			if (7 < b)
																			{
																				goto IL_0509;
																			}
																			goto IL_0577;
																			IL_0509:
																			if (8 < b)
																			{
																				goto end_IL_026e;
																			}
																			goto IL_0517;
																			IL_0517:
																			if (8 > b)
																			{
																				goto end_IL_026e;
																			}
																			goto IL_0525;
																			IL_0525:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0548;
																			IL_0548:
																			array[num5] = 0;
																			goto IL_0556;
																			IL_0556:
																			num5++;
																			goto IL_0564;
																			IL_0564:
																			ptr2 += 8;
																			goto end_IL_029e;
																			IL_0577:
																			if (7 > b)
																			{
																				goto end_IL_026e;
																			}
																			goto IL_0585;
																			IL_0585:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05c5;
																			IL_05c5:
																			array[num5 - 2] = 0;
																			goto IL_05d9;
																			IL_05d9:
																			num5--;
																			goto end_IL_029e;
																			IL_05e9:
																			if (10 >= b)
																			{
																				goto IL_05f4;
																			}
																			goto IL_0621;
																			IL_05f4:
																			if (10 > b)
																			{
																				goto end_IL_026e;
																			}
																			num = 85;
																			goto IL_0608;
																			IL_062c:
																			if (11 > b)
																			{
																			}
																			goto end_IL_026e;
																			continue;
																			end_IL_025e:
																			break;
																		}
																		continue;
																		end_IL_026e:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_029e;
																continue;
																end_IL_027e:
																break;
															}
															continue;
															end_IL_028e:
															break;
														}
														continue;
														end_IL_029e:
														break;
													}
													continue;
												}
												goto IL_06e2;
												IL_06e2:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_064a:
												break;
											}
											continue;
											end_IL_065d:
											break;
										}
										continue;
										end_IL_0667:
										break;
									}
									continue;
									end_IL_0672:
									break;
								}
								continue;
								end_IL_0687:
								break;
							}
							continue;
							end_IL_0697:
							break;
						}
						continue;
						end_IL_06a7:
						break;
					}
					continue;
					end_IL_06b7:
					break;
				}
				continue;
				end_IL_06c7:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3, int int_4)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 52;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AssemblyAttributesGoHereSEventSourceOptions.getApplicationActivatorsetDiscretionaryAcl);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0305:
															byte b = *ptr2;
															while (true)
															{
																IL_02f5:
																ptr2++;
																while (true)
																{
																	IL_02e5:
																	if (b >= 1)
																	{
																		goto IL_01d7;
																	}
																	goto IL_02bd;
																	IL_02bd:
																	while (true)
																	{
																		IL_02bd_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01c7:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_01b7:
																				num5++;
																				while (true)
																				{
																					IL_019e:
																					ptr2 += 8;
																					num = 95;
																					while (num != 95)
																					{
																						if (num != 1076)
																						{
																							goto IL_01d7;
																						}
																						switch (num)
																						{
																						case 56:
																							goto IL_019e;
																						case 26:
																							goto IL_01b7;
																						case 10:
																							goto IL_01c7;
																						case 29:
																							goto IL_01d7;
																						case 74:
																							goto IL_01e5;
																						case 28:
																						case 36:
																							goto IL_01f0;
																						case 5:
																							goto IL_01fe;
																						case 1:
																							goto IL_020c;
																						case 15:
																							goto IL_021a;
																						case 11:
																							goto IL_022d;
																						case 50:
																							goto IL_023b;
																						case 18:
																							goto IL_0246;
																						case 19:
																							goto IL_0256;
																						case 58:
																							goto IL_0261;
																						case 4:
																						case 86:
																							goto IL_0271;
																						case 65:
																							goto IL_027c;
																						case 12:
																						case 88:
																							goto IL_0289;
																						case 14:
																						case 17:
																							goto IL_0294;
																						case 53:
																							goto IL_029f;
																						case 55:
																							goto IL_02af;
																						case 21:
																						case 24:
																						case 31:
																						case 34:
																						case 37:
																						case 43:
																						case 44:
																						case 62:
																						case 66:
																						case 67:
																						case 68:
																						case 70:
																						case 77:
																						case 79:
																						case 83:
																						case 84:
																							goto IL_02bd_2;
																						case 27:
																							goto IL_02e5;
																						case 39:
																							goto IL_02f5;
																						case 6:
																						case 82:
																							goto IL_0305;
																						case 30:
																						case 54:
																							goto IL_0310;
																						case 8:
																						case 45:
																							goto IL_0328;
																						case 41:
																							goto IL_0351;
																						case 46:
																							goto IL_035f;
																						case 22:
																						case 51:
																							goto IL_0372;
																						case 23:
																							goto IL_03e0;
																						case 20:
																						case 42:
																							goto IL_03f3;
																						case 76:
																							goto IL_0433;
																						case 2:
																							goto IL_0447;
																						case 25:
																						case 71:
																							goto IL_0457;
																						case 7:
																						case 60:
																							goto IL_0470;
																						case 72:
																							goto IL_047e;
																						case 9:
																							goto IL_04a1;
																						case 59:
																							goto IL_04ab;
																						case 49:
																							goto IL_04b9;
																						case 0:
																						case 3:
																						case 35:
																						case 38:
																						case 47:
																						case 61:
																						case 64:
																						case 69:
																						case 73:
																						case 87:
																							goto end_IL_018b;
																						case 16:
																							goto end_IL_04c7;
																						case 63:
																							goto end_IL_04da;
																						case 13:
																							goto end_IL_04e4;
																						case 52:
																							goto end_IL_04ef;
																						case 57:
																							goto end_IL_0504;
																						case 78:
																						case 85:
																							goto end_IL_0519;
																						case 40:
																							goto end_IL_0532;
																						case 33:
																						case 48:
																							goto end_IL_0542;
																						case 80:
																							goto end_IL_0552;
																						case 81:
																							goto end_IL_0562;
																						case 32:
																						case 75:
																							goto IL_057d;
																						}
																						continue;
																						end_IL_018b:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																	IL_01d7:
																	if (b <= 8)
																	{
																		goto IL_01e5;
																	}
																	goto IL_02bd;
																	IL_01e5:
																	if (4 < b)
																	{
																		goto IL_01f0;
																	}
																	goto IL_022d;
																	IL_01f0:
																	if (6 >= b)
																	{
																		goto IL_01fe;
																	}
																	goto IL_0289;
																	IL_01fe:
																	if (6 <= b)
																	{
																		break;
																	}
																	goto IL_020c;
																	IL_020c:
																	if (5 >= b)
																	{
																		goto IL_021a;
																	}
																	goto IL_02bd;
																	IL_021a:
																	if (5 > b)
																	{
																		goto IL_02bd;
																	}
																	goto IL_0310;
																	IL_0310:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_0289:
																	if (7 < b)
																	{
																		goto IL_0294;
																	}
																	goto IL_02af;
																	IL_0294:
																	if (8 >= b)
																	{
																		goto IL_029f;
																	}
																	goto IL_02bd;
																	IL_029f:
																	if (8 > b)
																	{
																		goto IL_02bd;
																	}
																	goto IL_0457;
																	IL_0457:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_02af:
																	if (7 > b)
																	{
																		goto IL_02bd;
																	}
																	goto IL_0470;
																	IL_0470:
																	array[num5] = 0;
																	goto IL_047e;
																	IL_047e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a1;
																	IL_04a1:
																	array2[num5] = null;
																	goto IL_04ab;
																	IL_04ab:
																	num5++;
																	goto IL_04b9;
																	IL_04b9:
																	ptr2 += 8;
																	break;
																	IL_022d:
																	if (4 > b)
																	{
																		goto IL_023b;
																	}
																	goto IL_0328;
																	IL_023b:
																	if (2 >= b)
																	{
																		goto IL_0246;
																	}
																	goto IL_0256;
																	IL_0246:
																	if (2 > b)
																	{
																		goto IL_0271;
																	}
																	goto IL_0372;
																	IL_0271:
																	if (1 >= b)
																	{
																		goto IL_027c;
																	}
																	goto IL_02bd;
																	IL_027c:
																	if (1 <= b)
																	{
																	}
																	goto IL_02bd;
																	IL_0372:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_03e0;
																	IL_03e0:
																	num5 -= 2;
																	break;
																	IL_0256:
																	if (3 >= b)
																	{
																		goto IL_0261;
																	}
																	goto IL_02bd;
																	IL_0261:
																	if (3 > b)
																	{
																		goto IL_02bd;
																	}
																	goto IL_03f3;
																	IL_03f3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0433;
																	IL_0433:
																	array[num5 - 2] = 0;
																	goto IL_0447;
																	IL_0447:
																	num5--;
																	break;
																	IL_0328:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0351;
																	IL_0351:
																	ptr2 += 8;
																	goto IL_035f;
																	IL_035f:
																	num5--;
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_057d;
													IL_057d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04c7:
													break;
												}
												continue;
												end_IL_04da:
												break;
											}
											continue;
											end_IL_04e4:
											break;
										}
										continue;
										end_IL_04ef:
										break;
									}
									continue;
									end_IL_0504:
									break;
								}
								continue;
								end_IL_0519:
								break;
							}
							continue;
							end_IL_0532:
							break;
						}
						continue;
						end_IL_0542:
						break;
					}
					continue;
					end_IL_0552:
					break;
				}
				continue;
				end_IL_0562:
				break;
			}
		}
	}

	private static int smethod_6(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		if (num <= num2)
		{
			num = int_4;
			num2 = int_3;
			return num - num2;
		}
		num = int_3;
		num2 = int_4;
		return num - num2;
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContractFailedEventArgsDefaultContext.ComImportAttributegetSupportsDaylightSavingTime);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_027d:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_025d:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0250:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_0240:
																								if (10 >= b)
																								{
																									while (true)
																									{
																										IL_0230:
																										if (10 > b)
																										{
																											num = 128;
																											while (num != 128)
																											{
																												if (num != 1109)
																												{
																													goto IL_0487;
																												}
																												switch (num)
																												{
																												case 17:
																													goto IL_0230;
																												case 67:
																												case 74:
																													goto IL_0240;
																												case 31:
																													goto IL_0250;
																												case 83:
																													goto IL_025d;
																												case 1:
																													goto IL_026d;
																												case 40:
																													goto IL_027d;
																												case 23:
																													goto end_IL_027d;
																												case 6:
																												case 94:
																													goto end_IL_028a;
																												case 8:
																												case 57:
																													goto IL_02b3;
																												case 71:
																													goto IL_02c6;
																												case 50:
																												case 60:
																													goto IL_02d1;
																												case 68:
																													goto IL_02e5;
																												case 32:
																													goto IL_033b;
																												case 79:
																													goto IL_034b;
																												case 13:
																												case 34:
																													goto IL_0359;
																												case 5:
																													goto IL_0399;
																												case 81:
																													goto IL_03b2;
																												case 89:
																													goto IL_03c2;
																												case 62:
																													goto IL_03d0;
																												case 59:
																												case 85:
																													goto IL_03de;
																												case 72:
																													goto IL_041e;
																												case 92:
																													goto IL_0437;
																												case 3:
																												case 98:
																													goto IL_044a;
																												case 53:
																													goto IL_0461;
																												case 99:
																													goto IL_0474;
																												case 105:
																													goto IL_0487;
																												case 93:
																													goto IL_0492;
																												case 37:
																													goto IL_04a0;
																												case 38:
																												case 70:
																													goto IL_04ae;
																												case 12:
																													goto IL_04f3;
																												case 49:
																												case 102:
																													goto IL_0501;
																												case 48:
																													goto IL_050c;
																												case 96:
																													goto IL_051f;
																												case 95:
																													goto IL_052a;
																												case 64:
																												case 75:
																													goto IL_0538;
																												case 33:
																													goto IL_0578;
																												case 97:
																													goto IL_058c;
																												case 22:
																												case 43:
																													goto IL_05ad;
																												case 80:
																													goto IL_05d6;
																												case 63:
																													goto IL_05ed;
																												case 109:
																													goto IL_0600;
																												case 110:
																													goto IL_0610;
																												case 112:
																													goto IL_0623;
																												case 66:
																													goto IL_0637;
																												case 24:
																												case 115:
																													goto IL_064a;
																												case 76:
																													goto IL_066c;
																												case 82:
																													goto IL_067a;
																												case 84:
																													goto IL_0688;
																												case 26:
																												case 116:
																													goto IL_069b;
																												case 58:
																													goto IL_06a6;
																												case 46:
																												case 119:
																													goto IL_06b1;
																												case 86:
																													goto IL_06bf;
																												case 27:
																													goto IL_06e2;
																												case 47:
																													goto IL_06ec;
																												case 35:
																													goto IL_06fa;
																												case 42:
																												case 121:
																													goto IL_070a;
																												case 0:
																												case 4:
																												case 16:
																												case 18:
																												case 20:
																												case 25:
																												case 28:
																												case 44:
																												case 51:
																												case 56:
																												case 61:
																												case 69:
																												case 77:
																												case 88:
																												case 90:
																												case 91:
																												case 100:
																												case 106:
																												case 114:
																												case 117:
																												case 120:
																													goto end_IL_021d;
																												case 36:
																													goto IL_0746;
																												case 39:
																													goto IL_0754;
																												case 55:
																													goto IL_0762;
																												case 2:
																												case 9:
																												case 11:
																												case 14:
																												case 15:
																												case 19:
																												case 21:
																												case 45:
																												case 52:
																												case 65:
																												case 103:
																												case 108:
																												case 118:
																													goto end_IL_029a;
																												case 113:
																													goto end_IL_0779;
																												case 7:
																													goto end_IL_078c;
																												case 54:
																													goto end_IL_0796;
																												case 111:
																													goto end_IL_07a1;
																												case 87:
																													goto end_IL_07b6;
																												case 10:
																												case 73:
																													goto end_IL_07cb;
																												case 41:
																													goto end_IL_07db;
																												case 78:
																												case 107:
																													goto end_IL_07eb;
																												case 29:
																													goto end_IL_07fb;
																												case 30:
																													goto end_IL_080b;
																												case 101:
																												case 104:
																													goto IL_0826;
																												}
																												continue;
																												end_IL_021d:
																												break;
																											}
																											break;
																										}
																										goto IL_02b3;
																										IL_02b3:
																										num5--;
																										goto end_IL_029a;
																									}
																									break;
																								}
																								goto IL_044a;
																								IL_0461:
																								if (11 > b)
																								{
																									break;
																								}
																								goto IL_070a;
																								IL_044a:
																								if (11 < b)
																								{
																									break;
																								}
																								num = 53;
																								goto IL_0461;
																								IL_070a:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_029a;
																							}
																							break;
																						}
																						goto IL_02c6;
																						IL_0610:
																						num5--;
																						goto end_IL_029a;
																						IL_02c6:
																						if (9 <= b)
																						{
																							goto IL_02d1;
																						}
																						goto IL_033b;
																						IL_02d1:
																						array[num5 - 2] = 0;
																						goto IL_02e5;
																						IL_02e5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AreTextualReferencesEqualRegisterChannel[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_03b2;
																						IL_03b2:
																						num5--;
																						goto IL_0437;
																						IL_0437:
																						ptr2 += 8;
																						goto end_IL_029a;
																						IL_033b:
																						if (7 < b)
																						{
																							goto IL_03c2;
																						}
																						goto IL_0600;
																						IL_0600:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_064a;
																						IL_064a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						num = 76;
																						goto IL_066c;
																						IL_066c:
																						array[num5] = 0;
																						goto IL_067a;
																						IL_067a:
																						num5++;
																						goto IL_0688;
																						IL_0688:
																						ptr2 += 8;
																						goto end_IL_029a;
																						IL_03c2:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_03d0;
																						IL_03d0:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_03de;
																						IL_03de:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_041e;
																						IL_041e:
																						array[num5 - 2] = 0;
																						goto IL_0610;
																					}
																					break;
																				}
																				goto IL_034b;
																				IL_05d6:
																				ptr2 += 8;
																				num = 63;
																				goto IL_05ed;
																				IL_034b:
																				if (6 <= b)
																				{
																					goto IL_0359;
																				}
																				goto IL_0487;
																				IL_0359:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0399;
																				IL_0399:
																				array[num5 - 2] = 0;
																				goto IL_0474;
																				IL_0474:
																				num5--;
																				goto end_IL_029a;
																				IL_0487:
																				if (3 < b)
																				{
																					goto IL_0492;
																				}
																				goto IL_04f3;
																				IL_0492:
																				if (4 >= b)
																				{
																					goto IL_04a0;
																				}
																				goto IL_069b;
																				IL_04a0:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_04ae;
																				IL_04ae:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0623;
																				IL_0623:
																				array[num5 - 2] = 0;
																				goto IL_0637;
																				IL_0637:
																				num5--;
																				goto end_IL_029a;
																				IL_069b:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_06a6;
																				IL_06a6:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_06b1;
																				IL_06b1:
																				array[num5] = 0;
																				goto IL_06bf;
																				IL_06bf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06e2;
																				IL_06e2:
																				array2[num5] = null;
																				goto IL_06ec;
																				IL_06ec:
																				num5++;
																				goto IL_06fa;
																				IL_06fa:
																				ptr2 += 8;
																				goto end_IL_029a;
																				IL_04f3:
																				if (3 > b)
																				{
																					goto IL_0501;
																				}
																				goto IL_05ad;
																				IL_0501:
																				if (1 >= b)
																				{
																					goto IL_050c;
																				}
																				goto IL_051f;
																				IL_050c:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_051f:
																				if (2 < b)
																				{
																					num = 18;
																					break;
																				}
																				goto IL_052a;
																				IL_052a:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0538;
																				IL_0538:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0578;
																				IL_0578:
																				array[num5 - 2] = 0;
																				goto IL_058c;
																				IL_058c:
																				num5--;
																				goto end_IL_029a;
																				IL_05ed:
																				num5--;
																				goto end_IL_029a;
																				IL_05ad:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d6;
																			}
																			break;
																			IL_026d:;
																		}
																	}
																	else
																	{
																		num = 106;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0746;
																	IL_0754:
																	num5++;
																	goto IL_0762;
																	IL_0762:
																	ptr2 += 8;
																	num = 103;
																	goto end_IL_029a;
																	IL_0746:
																	array[num5] = 0;
																	goto IL_0754;
																	continue;
																	end_IL_027d:
																	break;
																}
																continue;
																end_IL_028a:
																break;
															}
															continue;
															end_IL_029a:
															break;
														}
														continue;
													}
													goto IL_0826;
													IL_0826:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0779:
													break;
												}
												continue;
												end_IL_078c:
												break;
											}
											continue;
											end_IL_0796:
											break;
										}
										continue;
										end_IL_07a1:
										break;
									}
									continue;
									end_IL_07b6:
									break;
								}
								continue;
								end_IL_07cb:
								break;
							}
							continue;
							end_IL_07db:
							break;
						}
						continue;
						end_IL_07eb:
						break;
					}
					continue;
					end_IL_07fb:
					break;
				}
				continue;
				end_IL_080b:
				break;
			}
		}
	}

	static Class144()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_004a:
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 3:
							case 4:
								goto IL_004a;
							case 5:
								goto end_IL_003d;
							case 6:
								goto end_IL_005f;
							case 2:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}
}
