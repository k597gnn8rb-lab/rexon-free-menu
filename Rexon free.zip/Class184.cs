using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Invis", "Rig", "Right secondary to go invisible.", false, 2, ModType.const_0, false)]
internal class Class184 : MonoBehaviour
{
	private static bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private Vector3 vector3_0;

	private GameObject gameObject_0;

	private GameObject gameObject_1;

	private float float_0;

	private bool bool_3;

	private float float_1;

	private static bool bool_4;

	private static bool bool_5;

	private static int int_0;

	private static bool bool_6;

	private static IntPtr[] fromInclusiveRemotingConfigHandler;

	private static IntPtr[] getPercentGroupSizesgetClipboard;

	private static IntPtr[] StackBehaviourPopArgRegSetStrArrNull;

	private static IntPtr[] InsufficientExecutionStackExceptionMapViewToReadOnlyCollectionAdapter;

	private static IntPtr[] CompilerGlobalScopeAttributeNullStream;

	private static IntPtr[] CopyrightsetAsUint;

	private static IntPtr[] UtcTicksCalendarHijri;

	private static IntPtr[] StoreLocationMemoryFailPoint;

	private static IntPtr[] MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct;

	private static IntPtr[] getInheritanceFlagsGetUninitializedObject;

	private static IntPtr[] destinationgetPlatform;

	public unsafe static bool InvisActive
	{
		get
		{
			int num = 67;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ETWgetException.TimeZoneSerTrace);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															IL_03b0:
															byte b = *ptr2;
															while (true)
															{
																IL_03a0:
																ptr2++;
																while (true)
																{
																	IL_0390:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_0370:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0360:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0353:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_0340:
																										if (4 > b)
																										{
																											num = 135;
																											while (true)
																											{
																												IL_0330:
																												if (2 < b)
																												{
																													while (3 >= b)
																													{
																														while (3 <= b)
																														{
																															while (true)
																															{
																																IL_02e5:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																while (true)
																																{
																																	IL_02d5:
																																	ptr2 += 8;
																																	while (true)
																																	{
																																		IL_02bc:
																																		num6--;
																																		num = 163;
																																		while (num != 163)
																																		{
																																			if (num != 1144)
																																			{
																																				goto end_IL_0310;
																																			}
																																			switch (num)
																																			{
																																			case 99:
																																				goto IL_02bc;
																																			case 131:
																																				goto IL_02d5;
																																			case 110:
																																			case 124:
																																				goto IL_02e5;
																																			case 39:
																																				goto IL_0310;
																																			case 77:
																																			case 154:
																																				goto IL_0320;
																																			case 71:
																																			case 135:
																																				goto IL_0330;
																																			case 151:
																																				goto IL_0340;
																																			case 55:
																																				goto IL_0353;
																																			case 63:
																																				goto IL_0360;
																																			case 141:
																																				goto IL_0370;
																																			case 15:
																																				goto IL_0380;
																																			case 101:
																																				goto IL_0390;
																																			case 137:
																																				goto IL_03a0;
																																			case 4:
																																			case 156:
																																				goto IL_03b0;
																																			case 80:
																																				goto IL_03bb;
																																			case 88:
																																				goto IL_03c9;
																																			case 17:
																																			case 24:
																																				goto IL_03d4;
																																			case 7:
																																				goto IL_0416;
																																			case 11:
																																				goto IL_0424;
																																			case 90:
																																			case 94:
																																				goto IL_0437;
																																			case 45:
																																				goto IL_0445;
																																			case 0:
																																				goto IL_0453;
																																			case 30:
																																				goto IL_045e;
																																			case 98:
																																				goto IL_047c;
																																			case 23:
																																				goto IL_0490;
																																			case 102:
																																				goto IL_04a3;
																																			case 32:
																																			case 57:
																																				goto IL_04b1;
																																			case 100:
																																			case 103:
																																				goto IL_04ca;
																																			case 40:
																																			case 104:
																																				goto IL_050c;
																																			case 1:
																																			case 108:
																																				goto IL_051f;
																																			case 52:
																																				goto IL_052d;
																																			case 60:
																																				goto IL_0550;
																																			case 31:
																																				goto IL_055a;
																																			case 28:
																																				goto IL_0568;
																																			case 114:
																																				goto IL_057b;
																																			case 16:
																																				goto IL_058f;
																																			case 116:
																																				goto IL_05a2;
																																			case 35:
																																				goto IL_05b0;
																																			case 75:
																																			case 127:
																																				goto IL_05c7;
																																			case 69:
																																				goto IL_0607;
																																			case 25:
																																				goto IL_061b;
																																			case 132:
																																				goto IL_062e;
																																			case 84:
																																				goto IL_063c;
																																			case 136:
																																				goto IL_064a;
																																			case 85:
																																			case 95:
																																				goto IL_0658;
																																			case 70:
																																				goto IL_0698;
																																			case 123:
																																				goto IL_06ac;
																																			case 144:
																																			case 145:
																																				goto IL_06bf;
																																			case 48:
																																				goto IL_0721;
																																			case 140:
																																			case 148:
																																				goto IL_0734;
																																			case 3:
																																				goto IL_0742;
																																			case 9:
																																			case 47:
																																				goto IL_074d;
																																			case 128:
																																				goto IL_075b;
																																			case 22:
																																			case 139:
																																				goto IL_0769;
																																			case 74:
																																				goto IL_0782;
																																			case 58:
																																				goto IL_0790;
																																			case 8:
																																				goto IL_079e;
																																			case 41:
																																			case 51:
																																				goto IL_07b1;
																																			case 54:
																																				goto IL_07c9;
																																			case 119:
																																				goto IL_07d4;
																																			case 87:
																																			case 109:
																																				goto IL_07e2;
																																			case 46:
																																				goto IL_0806;
																																			case 36:
																																				goto IL_0814;
																																			case 5:
																																				goto IL_0822;
																																			case 64:
																																			case 149:
																																				goto IL_0835;
																																			case 93:
																																				goto IL_0843;
																																			case 65:
																																			case 105:
																																				goto IL_085a;
																																			case 155:
																																				goto IL_0876;
																																			case 21:
																																				goto IL_08ca;
																																			case 129:
																																				goto IL_08d8;
																																			case 72:
																																				goto IL_08eb;
																																			case 96:
																																				goto IL_08f6;
																																			case 12:
																																				goto IL_0901;
																																			case 6:
																																			case 14:
																																			case 18:
																																			case 19:
																																			case 20:
																																			case 26:
																																			case 29:
																																			case 33:
																																			case 37:
																																			case 42:
																																			case 43:
																																			case 59:
																																			case 62:
																																			case 73:
																																			case 76:
																																			case 81:
																																			case 82:
																																			case 92:
																																			case 112:
																																			case 118:
																																			case 121:
																																			case 122:
																																			case 126:
																																			case 130:
																																			case 142:
																																			case 143:
																																			case 146:
																																				goto end_IL_0310;
																																			case 10:
																																				goto IL_0925;
																																			case 68:
																																				goto IL_0933;
																																			case 106:
																																				goto IL_0941;
																																			case 83:
																																			case 125:
																																				goto IL_095a;
																																			case 44:
																																				goto IL_099a;
																																			case 153:
																																				goto IL_09ae;
																																			case 2:
																																			case 34:
																																			case 38:
																																			case 49:
																																			case 50:
																																			case 53:
																																			case 56:
																																			case 61:
																																			case 78:
																																			case 86:
																																			case 89:
																																			case 97:
																																			case 113:
																																			case 117:
																																			case 120:
																																			case 134:
																																			case 147:
																																			case 152:
																																				goto end_IL_02a9;
																																			case 138:
																																				goto end_IL_09c5;
																																			case 91:
																																				goto end_IL_09d8;
																																			case 150:
																																				goto end_IL_09e2;
																																			case 107:
																																			case 115:
																																				goto end_IL_09ed;
																																			case 111:
																																				goto end_IL_09fd;
																																			case 13:
																																				goto end_IL_0a0d;
																																			case 133:
																																				goto end_IL_0a1d;
																																			case 66:
																																				goto end_IL_0a2d;
																																			case 67:
																																				goto end_IL_0a3d;
																																			case 27:
																																			case 79:
																																				goto IL_0a58;
																																			}
																																			continue;
																																			end_IL_02a9:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_0390;
																															continue;
																															end_IL_0310:
																															break;
																															IL_0310:;
																														}
																														break;
																														IL_0320:;
																													}
																													break;
																												}
																												goto IL_08eb;
																												IL_099a:
																												array[num6 - 2] = 0;
																												goto IL_09ae;
																												IL_08eb:
																												if (2 > b)
																												{
																													goto IL_08f6;
																												}
																												num = 83;
																												goto IL_095a;
																												IL_08f6:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_0901;
																												IL_0901:
																												if (1 <= b)
																												{
																												}
																												break;
																												IL_09ae:
																												num6--;
																												num = 78;
																												goto end_IL_0390;
																												IL_095a:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_099a;
																											}
																											break;
																										}
																										goto IL_051f;
																										IL_055a:
																										num6++;
																										goto IL_0568;
																										IL_0568:
																										ptr2 += 8;
																										goto end_IL_0390;
																										IL_051f:
																										array[num6] = 0;
																										goto IL_052d;
																										IL_052d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0550;
																										IL_0550:
																										array2[num6] = null;
																										goto IL_055a;
																									}
																									break;
																								}
																								goto IL_03bb;
																								IL_0607:
																								array[num6 - 2] = 0;
																								goto IL_061b;
																								IL_03bb:
																								if (6 >= b)
																								{
																									goto IL_03c9;
																								}
																								goto IL_05a2;
																								IL_03c9:
																								if (6 <= b)
																								{
																									goto IL_03d4;
																								}
																								goto IL_0416;
																								IL_03d4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_047c;
																								IL_047c:
																								array[num6 - 2] = 0;
																								goto IL_0490;
																								IL_0490:
																								num6--;
																								goto end_IL_0390;
																								IL_0416:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0424;
																								IL_0424:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_04ca;
																								IL_04ca:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_057b;
																								IL_057b:
																								array[num6 - 2] = 0;
																								goto IL_058f;
																								IL_058f:
																								num6--;
																								goto end_IL_0390;
																								IL_05a2:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_05b0;
																								IL_05b0:
																								if (7 > b)
																								{
																									break;
																								}
																								num = 127;
																								goto IL_05c7;
																								IL_061b:
																								num6--;
																								goto end_IL_0390;
																								IL_05c7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0607;
																							}
																							break;
																						}
																						goto IL_050c;
																						IL_050c:
																						num6--;
																						goto end_IL_0390;
																					}
																					break;
																				}
																				goto IL_0437;
																				IL_0843:
																				if (16 > b)
																				{
																					break;
																				}
																				num = 65;
																				goto IL_085a;
																				IL_0437:
																				if (12 >= b)
																				{
																					goto IL_0445;
																				}
																				goto IL_0734;
																				IL_0445:
																				if (12 <= b)
																				{
																					goto end_IL_0390;
																				}
																				goto IL_0453;
																				IL_0453:
																				if (10 < b)
																				{
																					goto IL_045e;
																				}
																				num = 132;
																				goto IL_062e;
																				IL_045e:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_04a3;
																				IL_04a3:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_04b1;
																				IL_04b1:
																				array[num6 - 2] = 0;
																				goto IL_0876;
																				IL_0876:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)fromInclusiveRemotingConfigHandler[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_08ca;
																				IL_08ca:
																				num6--;
																				goto IL_08d8;
																				IL_08d8:
																				ptr2 += 8;
																				goto end_IL_0390;
																				IL_085a:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0390;
																				IL_062e:
																				if (10 > b)
																				{
																					goto IL_063c;
																				}
																				goto IL_06bf;
																				IL_063c:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_064a;
																				IL_064a:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0658;
																				IL_0658:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0698;
																				IL_0698:
																				array[num6 - 2] = 0;
																				goto IL_06ac;
																				IL_06ac:
																				num6--;
																				goto end_IL_0390;
																				IL_06bf:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0721;
																				IL_0721:
																				num6 -= 2;
																				goto end_IL_0390;
																				IL_0734:
																				if (14 >= b)
																				{
																					goto IL_0742;
																				}
																				goto IL_07c9;
																				IL_0742:
																				if (14 > b)
																				{
																					goto IL_074d;
																				}
																				goto IL_07b1;
																				IL_074d:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_075b;
																				IL_075b:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0769;
																				IL_0769:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0782;
																				IL_0782:
																				array[num6] = 1;
																				goto IL_0790;
																				IL_0790:
																				num6++;
																				goto IL_079e;
																				IL_079e:
																				ptr2 += 16;
																				goto end_IL_0390;
																				IL_07b1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0390;
																				IL_07c9:
																				if (15 >= b)
																				{
																					goto IL_07d4;
																				}
																				goto IL_0835;
																				IL_07d4:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_07e2;
																				IL_07e2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)fromInclusiveRemotingConfigHandler[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_0806;
																				IL_0806:
																				array[num6] = 0;
																				goto IL_0814;
																				IL_0814:
																				num6++;
																				goto IL_0822;
																				IL_0822:
																				ptr2 += 8;
																				goto end_IL_0390;
																				IL_0835:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_0843;
																			}
																			break;
																			IL_0380:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0925;
																	IL_0941:
																	ptr2 += 8;
																	break;
																	IL_0933:
																	num6++;
																	goto IL_0941;
																	IL_0925:
																	array[num6] = 0;
																	goto IL_0933;
																	continue;
																	end_IL_0390:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0a58;
													IL_0a58:
													return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
													continue;
													end_IL_09c5:
													break;
												}
												continue;
												end_IL_09d8:
												break;
											}
											continue;
											end_IL_09e2:
											break;
										}
										continue;
										end_IL_09ed:
										break;
									}
									continue;
									end_IL_09fd:
									break;
								}
								continue;
								end_IL_0a0d:
								break;
							}
							continue;
							end_IL_0a1d:
							break;
						}
						continue;
						end_IL_0a2d:
						break;
					}
					continue;
					end_IL_0a3d:
					break;
				}
			}
		}
		private set
		{
			int num = 73;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				num = 72;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						num = 131;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									sbyte[] array3 = new sbyte[1];
									while (true)
									{
										int[] array4 = new int[6];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getHelpLinkAddOrUpdate.CategoryopEquality);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																IL_03ae:
																byte b = *ptr2;
																while (true)
																{
																	IL_039e:
																	ptr2++;
																	while (true)
																	{
																		IL_038e:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_0381:
																				if (b <= 17)
																				{
																					while (true)
																					{
																						IL_0371:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0361:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0354:
																										if (4 < b)
																										{
																											while (true)
																											{
																												IL_0341:
																												if (6 < b)
																												{
																													num = 90;
																													while (true)
																													{
																														IL_0331:
																														if (7 < b)
																														{
																															while (8 >= b)
																															{
																																while (8 <= b)
																																{
																																	while (true)
																																	{
																																		IL_02f8:
																																		num6--;
																																		num = 178;
																																		while (num != 178)
																																		{
																																			if (num != 1159)
																																			{
																																				goto IL_08dd;
																																			}
																																			switch (num)
																																			{
																																			case 78:
																																			case 82:
																																				goto IL_02f8;
																																			case 14:
																																				goto IL_0311;
																																			case 160:
																																			case 165:
																																				goto IL_0321;
																																			case 90:
																																			case 115:
																																				goto IL_0331;
																																			case 148:
																																				goto IL_0341;
																																			case 79:
																																			case 118:
																																				goto IL_0354;
																																			case 81:
																																				goto IL_0361;
																																			case 120:
																																				goto IL_0371;
																																			case 13:
																																				goto IL_0381;
																																			case 127:
																																				goto IL_038e;
																																			case 157:
																																				goto IL_039e;
																																			case 0:
																																			case 53:
																																				goto IL_03ae;
																																			case 107:
																																				goto IL_03c7;
																																			case 40:
																																			case 141:
																																				goto IL_03d5;
																																			case 43:
																																				goto IL_03e3;
																																			case 18:
																																			case 105:
																																				goto IL_03ee;
																																			case 15:
																																				goto IL_042e;
																																			case 42:
																																				goto IL_0442;
																																			case 91:
																																			case 99:
																																				goto IL_0455;
																																			case 92:
																																				goto IL_0463;
																																			case 60:
																																				goto IL_0476;
																																			case 64:
																																				goto IL_0484;
																																			case 2:
																																			case 129:
																																				goto IL_048f;
																																			case 97:
																																				goto IL_04b8;
																																			case 67:
																																				goto IL_04c6;
																																			case 152:
																																				goto IL_04e7;
																																			case 103:
																																			case 137:
																																				goto IL_04fe;
																																			case 37:
																																				goto IL_053e;
																																			case 59:
																																				goto IL_0552;
																																			case 77:
																																			case 154:
																																				goto IL_0565;
																																			case 32:
																																				goto IL_0573;
																																			case 24:
																																				goto IL_0596;
																																			case 117:
																																				goto IL_05a0;
																																			case 153:
																																				goto IL_05ae;
																																			case 156:
																																				goto IL_05c1;
																																			case 41:
																																				goto IL_05cc;
																																			case 22:
																																			case 109:
																																				goto IL_05da;
																																			case 106:
																																				goto IL_061a;
																																			case 144:
																																				goto IL_062e;
																																			case 167:
																																				goto IL_0658;
																																			case 30:
																																			case 93:
																																				goto IL_0666;
																																			case 62:
																																				goto IL_06a6;
																																			case 125:
																																				goto IL_06ba;
																																			case 28:
																																			case 108:
																																				goto IL_06cd;
																																			case 51:
																																				goto IL_070d;
																																			case 139:
																																				goto IL_0721;
																																			case 171:
																																				goto IL_0734;
																																			case 38:
																																			case 96:
																																				goto IL_0742;
																																			case 128:
																																				goto IL_0750;
																																			case 20:
																																			case 57:
																																				goto IL_075b;
																																			case 149:
																																				goto IL_0769;
																																			case 31:
																																			case 63:
																																				goto IL_0777;
																																			case 27:
																																			case 29:
																																				goto IL_078f;
																																			case 116:
																																				goto IL_07b2;
																																			case 111:
																																				goto IL_07c0;
																																			case 151:
																																				goto IL_07ce;
																																			case 133:
																																				goto IL_07e1;
																																			case 52:
																																				goto IL_07ec;
																																			case 68:
																																			case 100:
																																				goto IL_0803;
																																			case 159:
																																				goto IL_081d;
																																			case 166:
																																				goto IL_0830;
																																			case 33:
																																				goto IL_083e;
																																			case 26:
																																			case 136:
																																				goto IL_084c;
																																			case 12:
																																				goto IL_0868;
																																			case 17:
																																			case 66:
																																				goto IL_0873;
																																			case 44:
																																				goto IL_088c;
																																			case 70:
																																				goto IL_08a3;
																																			case 119:
																																				goto IL_08b1;
																																			case 101:
																																				goto IL_08c4;
																																			case 46:
																																			case 124:
																																				goto IL_08cf;
																																			case 89:
																																				goto IL_08dd;
																																			case 85:
																																				goto IL_08f0;
																																			case 10:
																																			case 87:
																																				goto IL_08fe;
																																			case 7:
																																				goto IL_0912;
																																			case 146:
																																				goto IL_0966;
																																			case 61:
																																				goto IL_0974;
																																			case 4:
																																				goto IL_0987;
																																			case 170:
																																				goto IL_0992;
																																			case 54:
																																			case 155:
																																				goto IL_099d;
																																			case 168:
																																				goto IL_09ff;
																																			case 1:
																																			case 6:
																																			case 11:
																																			case 16:
																																			case 19:
																																			case 21:
																																			case 25:
																																			case 36:
																																			case 48:
																																			case 50:
																																			case 55:
																																			case 56:
																																			case 58:
																																			case 65:
																																			case 75:
																																			case 80:
																																			case 84:
																																			case 102:
																																			case 104:
																																			case 123:
																																			case 126:
																																			case 130:
																																			case 132:
																																			case 135:
																																			case 138:
																																			case 140:
																																			case 142:
																																			case 143:
																																			case 145:
																																			case 158:
																																			case 163:
																																			case 164:
																																				goto end_IL_0311;
																																			case 150:
																																				goto IL_0a28;
																																			case 113:
																																				goto IL_0a36;
																																			case 71:
																																				goto IL_0a44;
																																			case 3:
																																			case 5:
																																			case 9:
																																			case 35:
																																			case 45:
																																			case 47:
																																			case 49:
																																			case 69:
																																			case 86:
																																			case 88:
																																			case 94:
																																			case 110:
																																			case 112:
																																			case 114:
																																			case 121:
																																			case 122:
																																			case 147:
																																			case 162:
																																			case 169:
																																				goto end_IL_02e5;
																																			case 8:
																																				goto end_IL_0a52;
																																			case 134:
																																				goto end_IL_0a65;
																																			case 161:
																																				goto end_IL_0a6f;
																																			case 74:
																																				goto end_IL_0a7a;
																																			case 98:
																																				goto end_IL_0a8f;
																																			case 23:
																																			case 76:
																																				goto end_IL_0a9f;
																																			case 34:
																																				goto end_IL_0aaf;
																																			case 131:
																																				goto end_IL_0abf;
																																			case 83:
																																				goto end_IL_0acf;
																																			case 72:
																																				goto end_IL_0adf;
																																			case 73:
																																				goto end_IL_0af8;
																																			case 39:
																																			case 95:
																																				return;
																																			}
																																			continue;
																																			end_IL_02e5:
																																			break;
																																		}
																																		break;
																																	}
																																	goto end_IL_038e;
																																	continue;
																																	end_IL_0311:
																																	break;
																																	IL_0311:;
																																}
																																break;
																																IL_0321:;
																															}
																															break;
																														}
																														goto IL_0658;
																														IL_06ba:
																														num6--;
																														goto end_IL_038e;
																														IL_0658:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_0666;
																														IL_0666:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_06a6;
																														IL_06a6:
																														array[num6 - 2] = 0;
																														goto IL_06ba;
																													}
																													break;
																												}
																												goto IL_04e7;
																												IL_05da:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_061a;
																												IL_061a:
																												array[num6 - 2] = 0;
																												goto IL_062e;
																												IL_04e7:
																												if (6 <= b)
																												{
																													num = 137;
																													goto IL_04fe;
																												}
																												goto IL_05c1;
																												IL_062e:
																												num6--;
																												num = 94;
																												goto end_IL_038e;
																												IL_04fe:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_053e;
																												IL_053e:
																												array[num6 - 2] = 0;
																												goto IL_0552;
																												IL_0552:
																												num6--;
																												goto end_IL_038e;
																												IL_05c1:
																												if (5 < b)
																												{
																													num = 123;
																													break;
																												}
																												goto IL_05cc;
																												IL_05cc:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_05da;
																											}
																											break;
																										}
																										goto IL_03c7;
																										IL_05a0:
																										num6++;
																										goto IL_05ae;
																										IL_03c7:
																										if (4 > b)
																										{
																											goto IL_03d5;
																										}
																										goto IL_0565;
																										IL_03d5:
																										if (2 >= b)
																										{
																											goto IL_03e3;
																										}
																										goto IL_0476;
																										IL_03e3:
																										if (2 <= b)
																										{
																											goto IL_03ee;
																										}
																										goto IL_0455;
																										IL_03ee:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_042e;
																										IL_042e:
																										array[num6 - 2] = 0;
																										goto IL_0442;
																										IL_0442:
																										num6--;
																										goto end_IL_038e;
																										IL_0455:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_0463;
																										IL_0463:
																										if (1 <= b)
																										{
																										}
																										break;
																										IL_0476:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_0484;
																										IL_0484:
																										if (3 > b)
																										{
																											num = 48;
																											break;
																										}
																										goto IL_048f;
																										IL_048f:
																										ref int reference = ref array4[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_04b8;
																										IL_04b8:
																										ptr2 += 8;
																										goto IL_04c6;
																										IL_04c6:
																										num6--;
																										goto end_IL_038e;
																										IL_05ae:
																										ptr2 += 8;
																										goto end_IL_038e;
																										IL_0565:
																										array[num6] = 0;
																										goto IL_0573;
																										IL_0573:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																										goto IL_0596;
																										IL_0596:
																										array2[num6] = null;
																										goto IL_05a0;
																									}
																									break;
																								}
																								goto IL_06cd;
																								IL_0721:
																								num6--;
																								goto end_IL_038e;
																								IL_06cd:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_070d;
																								IL_070d:
																								array[num6 - 2] = 0;
																								goto IL_0721;
																							}
																							break;
																						}
																						goto IL_0734;
																						IL_099d:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_09ff;
																						IL_0734:
																						if (13 < b)
																						{
																							goto IL_0742;
																						}
																						goto IL_0868;
																						IL_0742:
																						if (15 >= b)
																						{
																							goto IL_0750;
																						}
																						goto IL_07e1;
																						IL_0750:
																						if (15 > b)
																						{
																							goto IL_075b;
																						}
																						goto IL_078f;
																						IL_075b:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_0769;
																						IL_0769:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0777;
																						IL_0777:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_038e;
																						IL_078f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_07b2;
																						IL_07b2:
																						array[num6] = 0;
																						goto IL_07c0;
																						IL_07c0:
																						num6++;
																						goto IL_07ce;
																						IL_07ce:
																						ptr2 += 8;
																						goto end_IL_038e;
																						IL_07e1:
																						if (16 >= b)
																						{
																							goto IL_07ec;
																						}
																						goto IL_0830;
																						IL_07ec:
																						if (16 > b)
																						{
																							break;
																						}
																						num = 68;
																						goto IL_0803;
																						IL_09ff:
																						num6 -= 2;
																						goto end_IL_038e;
																						IL_0803:
																						bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																						goto IL_081d;
																						IL_081d:
																						num6--;
																						goto end_IL_038e;
																						IL_0830:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_083e;
																						IL_083e:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_084c;
																						IL_084c:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_038e;
																						IL_0868:
																						if (13 <= b)
																						{
																							goto IL_0873;
																						}
																						goto IL_08c4;
																						IL_0873:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																						goto IL_088c;
																						IL_088c:
																						array[num6] = 1;
																						num = 70;
																						goto IL_08a3;
																						IL_08a3:
																						num6++;
																						goto IL_08b1;
																						IL_08b1:
																						ptr2 += 16;
																						goto end_IL_038e;
																						IL_08c4:
																						if (11 < b)
																						{
																							goto IL_08cf;
																						}
																						goto IL_08f0;
																						IL_08cf:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_08dd;
																						IL_08dd:
																						if (12 <= b)
																						{
																							goto end_IL_038e;
																						}
																						break;
																						IL_08f0:
																						if (11 <= b)
																						{
																							goto IL_08fe;
																						}
																						goto IL_0987;
																						IL_08fe:
																						array[num6 - 2] = 0;
																						goto IL_0912;
																						IL_0912:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)getPercentGroupSizesgetClipboard[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																						goto IL_0966;
																						IL_0966:
																						num6--;
																						goto IL_0974;
																						IL_0974:
																						ptr2 += 8;
																						goto end_IL_038e;
																						IL_0987:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0992;
																						IL_0992:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_099d;
																					}
																				}
																				else
																				{
																					num = 158;
																				}
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a28;
																		IL_0a44:
																		ptr2 += 8;
																		break;
																		IL_0a36:
																		num6++;
																		goto IL_0a44;
																		IL_0a28:
																		array[num6] = 0;
																		goto IL_0a36;
																		continue;
																		end_IL_038e:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_0a52:
															break;
														}
														continue;
														end_IL_0a65:
														break;
													}
													continue;
													end_IL_0a6f:
													break;
												}
												continue;
												end_IL_0a7a:
												break;
											}
											continue;
											end_IL_0a8f:
											break;
										}
										continue;
										end_IL_0a9f:
										break;
									}
									continue;
									end_IL_0aaf:
									break;
								}
								continue;
								end_IL_0abf:
								break;
							}
							continue;
							end_IL_0acf:
							break;
						}
						continue;
						end_IL_0adf:
						break;
					}
					continue;
					end_IL_0af8:
					break;
				}
			}
		}
	}

	private static bool getCOMRedirectionSectionAuditSuccess(Behaviour behaviour_0)
	{
		return behaviour_0.enabled;
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 24;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 28;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setPartialTrustVisibleAssembliesObjectEnd.LogonIdsSidsetNamespace);
										num = 89;
										while (true)
										{
											byte* ptr2 = ptr;
											num = 111;
											while (true)
											{
												if (num == 111)
												{
													goto IL_027e;
												}
												if (num != 1092)
												{
													goto IL_04cf;
												}
												switch (num)
												{
												case 89:
													goto end_IL_01cb;
												case 96:
													goto end_IL_01de;
												case 50:
													goto end_IL_01f1;
												case 28:
													goto end_IL_0205;
												case 38:
												case 88:
													goto end_IL_021a;
												case 66:
													goto end_IL_022a;
												case 26:
												case 65:
													goto end_IL_0243;
												case 23:
													goto end_IL_0253;
												case 24:
													goto end_IL_0263;
												case 12:
												case 15:
												case 18:
												case 19:
												case 34:
												case 37:
												case 48:
												case 76:
												case 85:
												case 86:
												case 94:
												case 104:
													goto IL_027e;
												case 3:
												case 16:
													goto IL_028e;
												case 80:
													goto IL_0297;
												case 39:
													goto IL_02a5;
												case 1:
													goto IL_02b3;
												case 59:
													goto IL_02ca;
												case 42:
													goto IL_02d8;
												case 93:
													goto IL_02e6;
												case 27:
												case 31:
													goto IL_02f1;
												case 10:
													goto IL_0353;
												case 41:
													goto IL_0366;
												case 91:
													goto IL_0371;
												case 0:
												case 58:
													goto IL_037f;
												case 49:
													goto IL_03bf;
												case 68:
													goto IL_03d3;
												case 70:
													goto IL_03e6;
												case 30:
													goto IL_03f4;
												case 47:
												case 56:
													goto IL_0402;
												case 25:
													goto IL_0425;
												case 21:
													goto IL_0433;
												case 75:
													goto IL_0441;
												case 62:
													goto IL_0454;
												case 8:
												case 71:
													goto IL_045f;
												case 61:
													goto IL_046d;
												case 55:
													goto IL_0480;
												case 44:
												case 79:
													goto IL_048e;
												case 92:
													goto IL_04b3;
												case 7:
												case 20:
													goto IL_04c1;
												case 87:
													goto IL_04cf;
												case 4:
												case 54:
													goto IL_04da;
												case 13:
													goto IL_0503;
												case 57:
													goto IL_0511;
												case 82:
												case 90:
													goto IL_0524;
												case 77:
													goto IL_0532;
												case 35:
												case 99:
													goto IL_0540;
												case 73:
													goto IL_0559;
												case 51:
													goto IL_0567;
												case 74:
													goto IL_0575;
												case 52:
													goto IL_0588;
												case 11:
												case 81:
													goto IL_0593;
												case 6:
													goto IL_05a1;
												case 60:
													goto IL_05b4;
												case 5:
												case 29:
													goto IL_05cb;
												case 22:
												case 84:
													goto IL_05e3;
												case 101:
													goto IL_05f1;
												case 95:
													goto IL_0614;
												case 14:
													goto IL_061e;
												case 46:
													goto IL_0635;
												case 2:
												case 9:
												case 17:
												case 32:
												case 33:
												case 36:
												case 40:
												case 43:
												case 45:
												case 53:
												case 63:
												case 64:
												case 67:
												case 78:
												case 83:
												case 97:
												case 98:
												case 100:
												case 102:
												case 103:
													goto IL_0648;
												case 69:
												case 72:
													goto IL_0660;
												}
												continue;
												IL_0614:
												array2[num4] = null;
												goto IL_061e;
												IL_061e:
												num4++;
												num = 46;
												goto IL_0635;
												IL_027e:
												if (num5 != 1)
												{
													goto IL_028e;
												}
												goto IL_0660;
												IL_0660:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_028e:
												b = *ptr2;
												goto IL_0297;
												IL_0297:
												ptr2++;
												goto IL_02a5;
												IL_02a5:
												if (b >= 1)
												{
													goto IL_02b3;
												}
												goto IL_0648;
												IL_02b3:
												if (b <= 10)
												{
													num = 59;
													goto IL_02ca;
												}
												goto IL_0648;
												IL_0635:
												ptr2 += 8;
												goto IL_027e;
												IL_02ca:
												if (5 < b)
												{
													goto IL_02d8;
												}
												goto IL_04b3;
												IL_02d8:
												if (8 >= b)
												{
													goto IL_02e6;
												}
												goto IL_0454;
												IL_02e6:
												if (8 <= b)
												{
													goto IL_02f1;
												}
												goto IL_0366;
												IL_02f1:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0353;
												IL_0353:
												num4 -= 2;
												goto IL_027e;
												IL_0366:
												if (6 >= b)
												{
													goto IL_0371;
												}
												goto IL_03e6;
												IL_0371:
												if (6 <= b)
												{
													goto IL_037f;
												}
												goto IL_0648;
												IL_037f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_03bf;
												IL_03bf:
												array[num4 - 2] = 0;
												goto IL_03d3;
												IL_03d3:
												num4--;
												goto IL_027e;
												IL_03e6:
												if (7 >= b)
												{
													goto IL_03f4;
												}
												goto IL_0648;
												IL_03f4:
												if (7 <= b)
												{
													goto IL_0402;
												}
												goto IL_0648;
												IL_0402:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0425;
												IL_0425:
												array[num4] = 0;
												goto IL_0433;
												IL_0433:
												num4++;
												goto IL_0441;
												IL_0441:
												ptr2 += 8;
												goto IL_027e;
												IL_0454:
												if (9 < b)
												{
													goto IL_045f;
												}
												goto IL_0480;
												IL_045f:
												if (10 >= b)
												{
													goto IL_046d;
												}
												goto IL_0648;
												IL_046d:
												if (10 > b)
												{
												}
												goto IL_0648;
												IL_0480:
												if (9 <= b)
												{
													goto IL_048e;
												}
												goto IL_0648;
												IL_048e:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												num = 37;
												goto IL_027e;
												IL_04b3:
												if (5 > b)
												{
													goto IL_04c1;
												}
												goto IL_05e3;
												IL_04c1:
												if (2 >= b)
												{
													goto IL_04cf;
												}
												goto IL_0588;
												IL_04cf:
												if (2 <= b)
												{
													goto IL_04da;
												}
												goto IL_0524;
												IL_04da:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0503;
												IL_0503:
												ptr2 += 8;
												goto IL_0511;
												IL_0511:
												num4--;
												goto IL_027e;
												IL_0524:
												if (1 >= b)
												{
													goto IL_0532;
												}
												goto IL_0648;
												IL_0532:
												if (1 <= b)
												{
													goto IL_0540;
												}
												goto IL_0648;
												IL_0540:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_0559;
												IL_0559:
												array[num4] = 0;
												goto IL_0567;
												IL_0567:
												num4++;
												goto IL_0575;
												IL_0575:
												ptr2 += 8;
												goto IL_027e;
												IL_0588:
												if (3 < b)
												{
													goto IL_0593;
												}
												goto IL_05b4;
												IL_0593:
												if (4 >= b)
												{
													goto IL_05a1;
												}
												goto IL_0648;
												IL_05a1:
												if (4 <= b)
												{
													goto IL_027e;
												}
												goto IL_0648;
												IL_05b4:
												if (3 <= b)
												{
													num = 29;
													goto IL_05cb;
												}
												goto IL_0648;
												IL_0648:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_027e;
												IL_05cb:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_027e;
												IL_05e3:
												array[num4] = 0;
												goto IL_05f1;
												IL_05f1:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0614;
												continue;
												end_IL_01cb:
												break;
											}
											continue;
											end_IL_01de:
											break;
										}
										continue;
										end_IL_01f1:
										break;
									}
									continue;
									end_IL_0205:
									break;
								}
								continue;
								end_IL_021a:
								break;
							}
							continue;
							end_IL_022a:
							break;
						}
						continue;
						end_IL_0243:
						break;
					}
					continue;
					end_IL_0253:
					break;
				}
				continue;
				end_IL_0263:
				break;
			}
		}
	}

	private static void OtherArrayDomainMask(int int_1)
	{
		Class9.smethod_89(int_1);
	}

	private unsafe void method_0()
	{
		int num = 423;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NaNIsStopped.GetVariablesSin);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_08b4:
																	if (b >= 1)
																	{
																		while (b <= 61)
																		{
																			while (true)
																			{
																				IL_0897:
																				if (31 >= b)
																				{
																					while (true)
																					{
																						IL_0887:
																						if (31 > b)
																						{
																							while (true)
																							{
																								IL_0877:
																								if (15 < b)
																								{
																									while (true)
																									{
																										IL_0867:
																										if (23 < b)
																										{
																											while (true)
																											{
																												IL_0857:
																												if (27 < b)
																												{
																													while (true)
																													{
																														IL_0847:
																														if (29 >= b)
																														{
																															while (true)
																															{
																																IL_0834:
																																if (29 <= b)
																																{
																																	num = 513;
																																	while (true)
																																	{
																																		if (num != 513)
																																		{
																																			if (num != 1494)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 155:
																																				goto IL_0834;
																																			case 262:
																																				goto IL_0847;
																																			case 170:
																																				goto IL_0857;
																																			case 44:
																																				goto IL_0867;
																																			case 437:
																																				goto IL_0877;
																																			case 480:
																																				goto IL_0887;
																																			case 147:
																																				goto IL_0897;
																																			case 269:
																																				goto end_IL_0897;
																																			case 328:
																																				goto IL_08b4;
																																			case 463:
																																				goto end_IL_08b4;
																																			case 98:
																																			case 100:
																																				goto end_IL_08c4;
																																			case 61:
																																				goto IL_08df;
																																			case 25:
																																				goto IL_08ea;
																																			case 88:
																																				goto IL_08fa;
																																			case 118:
																																				goto IL_090d;
																																			case 73:
																																				goto IL_091b;
																																			case 224:
																																				goto IL_0929;
																																			case 4:
																																				goto IL_0937;
																																			case 30:
																																				goto IL_0945;
																																			case 99:
																																				goto IL_0953;
																																			case 233:
																																				goto IL_0966;
																																			case 255:
																																				goto IL_0982;
																																			case 247:
																																				goto IL_0990;
																																			case 12:
																																				goto IL_099e;
																																			case 2:
																																				goto IL_09ac;
																																			case 210:
																																				goto IL_09ba;
																																			case 92:
																																			case 259:
																																				goto IL_09cd;
																																			case 267:
																																				goto IL_09e9;
																																			case 187:
																																				goto IL_09f7;
																																			case 313:
																																				goto IL_0a0a;
																																			case 322:
																																				goto IL_0a1a;
																																			case 7:
																																				goto IL_0a25;
																																			case 10:
																																				goto IL_0a33;
																																			case 306:
																																				goto IL_0a41;
																																			case 294:
																																				goto IL_0a4f;
																																			case 327:
																																				goto IL_0a62;
																																			case 75:
																																			case 333:
																																				goto IL_0a7e;
																																			case 197:
																																				goto IL_0a97;
																																			case 271:
																																				goto IL_0aa5;
																																			case 37:
																																				goto IL_0ab3;
																																			case 345:
																																				goto IL_0ac6;
																																			case 119:
																																				goto IL_0ad4;
																																			case 171:
																																				goto IL_0adf;
																																			case 129:
																																			case 140:
																																				goto IL_0af6;
																																			case 311:
																																				goto IL_0b0f;
																																			case 62:
																																				goto IL_0b1a;
																																			case 144:
																																				goto IL_0b28;
																																			case 241:
																																				goto IL_0b36;
																																			case 175:
																																			case 242:
																																				goto IL_0b44;
																																			case 323:
																																				goto IL_0b52;
																																			case 165:
																																				goto IL_0b75;
																																			case 163:
																																				goto IL_0b83;
																																			case 142:
																																				goto IL_0b96;
																																			case 351:
																																				goto IL_0ba9;
																																			case 227:
																																				goto IL_0bb4;
																																			case 102:
																																				goto IL_0bc2;
																																			case 150:
																																				goto IL_0bd5;
																																			case 64:
																																			case 289:
																																				goto IL_0be0;
																																			case 212:
																																				goto IL_0bf9;
																																			case 54:
																																				goto IL_0c0c;
																																			case 6:
																																				goto end_IL_0821;
																																			case 57:
																																			case 355:
																																				goto IL_0c2d;
																																			case 58:
																																				goto IL_0c65;
																																			case 230:
																																				goto IL_0c79;
																																			case 359:
																																				goto IL_0c8c;
																																			case 196:
																																				goto IL_0c9a;
																																			case 185:
																																				goto IL_0ca8;
																																			case 80:
																																			case 348:
																																				goto IL_0cbf;
																																			case 82:
																																				goto IL_0cea;
																																			case 365:
																																				goto IL_0d03;
																																			case 173:
																																				goto IL_0d0e;
																																			case 336:
																																				goto IL_0d1c;
																																			case 17:
																																			case 192:
																																				goto IL_0d35;
																																			case 180:
																																			case 369:
																																				goto IL_0d4d;
																																			case 35:
																																				goto IL_0d6f;
																																			case 109:
																																				goto IL_0d7d;
																																			case 270:
																																				goto IL_0d8b;
																																			case 375:
																																				goto IL_0d9e;
																																			case 178:
																																				goto IL_0dac;
																																			case 141:
																																			case 379:
																																				goto IL_0dbf;
																																			case 240:
																																				goto IL_0dd3;
																																			case 95:
																																				goto IL_0e19;
																																			case 258:
																																			case 399:
																																				goto IL_0e2c;
																																			case 281:
																																				goto IL_0e6c;
																																			case 179:
																																				goto IL_0e80;
																																			case 408:
																																				goto IL_0e93;
																																			case 160:
																																			case 339:
																																				goto IL_0ea1;
																																			case 77:
																																				goto IL_0eaf;
																																			case 308:
																																			case 409:
																																				goto IL_0ee1;
																																			case 23:
																																				goto IL_0f33;
																																			case 107:
																																			case 418:
																																				goto IL_0f46;
																																			case 307:
																																				goto IL_0f83;
																																			case 410:
																																				goto IL_0f91;
																																			case 407:
																																			case 424:
																																				goto IL_0fa4;
																																			case 368:
																																				goto IL_0fe4;
																																			case 211:
																																				goto IL_0ff8;
																																			case 427:
																																				goto IL_100b;
																																			case 394:
																																				goto IL_1019;
																																			case 218:
																																				goto IL_1027;
																																			case 1:
																																			case 135:
																																				goto IL_1035;
																																			case 228:
																																				goto IL_1052;
																																			case 367:
																																				goto IL_1091;
																																			case 27:
																																			case 176:
																																				goto IL_10ad;
																																			case 433:
																																				goto IL_10df;
																																			case 405:
																																				goto IL_10ed;
																																			case 299:
																																			case 439:
																																				goto IL_1100;
																																			case 31:
																																				goto IL_111a;
																																			case 56:
																																				goto IL_1128;
																																			case 309:
																																				goto IL_1136;
																																			case 71:
																																			case 442:
																																				goto IL_1149;
																																			case 234:
																																				goto IL_1181;
																																			case 435:
																																				goto IL_1195;
																																			case 446:
																																				goto IL_11a8;
																																			case 145:
																																				goto IL_11b6;
																																			case 108:
																																			case 132:
																																				goto IL_11c1;
																																			case 36:
																																				goto IL_1206;
																																			case 264:
																																				goto IL_1211;
																																			case 128:
																																			case 273:
																																				goto IL_121f;
																																			case 34:
																																				goto IL_1229;
																																			case 349:
																																				goto IL_1237;
																																			case 251:
																																				goto IL_124a;
																																			case 231:
																																				goto IL_1258;
																																			case 79:
																																				goto IL_126b;
																																			case 440:
																																				goto IL_1276;
																																			case 184:
																																				goto IL_1284;
																																			case 143:
																																				goto IL_12a0;
																																			case 134:
																																			case 221:
																																				goto IL_12ab;
																																			case 417:
																																				goto IL_12bf;
																																			case 195:
																																				goto IL_12fe;
																																			case 358:
																																				goto IL_1311;
																																			case 325:
																																				goto IL_131f;
																																			case 26:
																																			case 396:
																																				goto IL_132d;
																																			case 5:
																																				goto IL_1344;
																																			case 455:
																																				goto IL_136d;
																																			case 20:
																																				goto IL_1381;
																																			case 458:
																																				goto IL_1394;
																																			case 161:
																																			case 326:
																																				goto IL_13a2;
																																			case 387:
																																				goto IL_13b6;
																																			case 445:
																																				goto IL_1408;
																																			case 8:
																																				goto IL_1416;
																																			case 461:
																																				goto IL_1429;
																																			case 372:
																																				goto IL_1437;
																																			case 97:
																																			case 464:
																																				goto IL_144a;
																																			case 384:
																																				goto IL_145e;
																																			case 310:
																																				goto IL_14ab;
																																			case 72:
																																				goto IL_14b9;
																																			case 465:
																																				goto IL_14cc;
																																			case 257:
																																				goto IL_1504;
																																			case 467:
																																				goto IL_1517;
																																			case 127:
																																				goto IL_1525;
																																			case 266:
																																			case 287:
																																				goto IL_1530;
																																			case 370:
																																				goto IL_1544;
																																			case 149:
																																				goto IL_157c;
																																			case 420:
																																				goto IL_158f;
																																			case 415:
																																				goto IL_159d;
																																			case 340:
																																			case 354:
																																				goto IL_15ab;
																																			case 398:
																																				goto IL_15bf;
																																			case 166:
																																				goto IL_1603;
																																			case 280:
																																				goto IL_1611;
																																			case 68:
																																			case 274:
																																				goto IL_161f;
																																			case 381:
																																				goto IL_1642;
																																			case 239:
																																				goto IL_1650;
																																			case 189:
																																				goto IL_165e;
																																			case 469:
																																				goto IL_1671;
																																			case 286:
																																			case 321:
																																				goto IL_167f;
																																			case 425:
																																			case 470:
																																				goto IL_1692;
																																			case 85:
																																				goto IL_16a6;
																																			case 474:
																																				goto IL_16ea;
																																			case 476:
																																				goto IL_16fd;
																																			case 279:
																																			case 483:
																																				goto IL_1710;
																																			case 105:
																																				goto IL_1739;
																																			case 181:
																																				goto IL_1747;
																																			case 484:
																																				goto IL_175a;
																																			case 376:
																																				goto IL_1768;
																																			case 113:
																																			case 400:
																																				goto IL_1776;
																																			case 331:
																																				goto IL_17d8;
																																			case 486:
																																				goto IL_17eb;
																																			case 217:
																																			case 235:
																																				goto IL_17f9;
																																			case 366:
																																				goto IL_183f;
																																			case 243:
																																				goto IL_184d;
																																			case 490:
																																				goto IL_1860;
																																			case 319:
																																				goto IL_186e;
																																			case 204:
																																				goto IL_187c;
																																			case 304:
																																			case 406:
																																				goto IL_1893;
																																			case 19:
																																				goto IL_18d3;
																																			case 347:
																																				goto IL_18e7;
																																			case 253:
																																				goto IL_1903;
																																			case 298:
																																			case 428:
																																				goto IL_1911;
																																			case 421:
																																				goto IL_195a;
																																			case 96:
																																				goto IL_1977;
																																			case 188:
																																				goto IL_1993;
																																			case 55:
																																				goto IL_19a1;
																																			case 193:
																																			case 492:
																																				goto IL_19b4;
																																			case 302:
																																				goto IL_19f4;
																																			case 305:
																																				goto IL_1a08;
																																			case 203:
																																			case 494:
																																				goto IL_1a1b;
																																			case 205:
																																				goto IL_1a5c;
																																			case 284:
																																				goto IL_1a70;
																																			case 495:
																																				goto IL_1a83;
																																			case 47:
																																				goto IL_1a9a;
																																			case 103:
																																			case 497:
																																				goto IL_1ab6;
																																			case 245:
																																				goto IL_1ac4;
																																			case 324:
																																				goto IL_1ae8;
																																			case 191:
																																				goto IL_1af6;
																																			case 453:
																																			case 499:
																																				goto IL_1b09;
																																			case 29:
																																				goto IL_1b46;
																																			case 295:
																																				goto IL_1b54;
																																			case 500:
																																				goto IL_1b67;
																																			case 121:
																																				goto IL_1b75;
																																			case 478:
																																			case 482:
																																				goto IL_1b83;
																																			case 115:
																																				goto IL_1b97;
																																			case 429:
																																				goto IL_1bd4;
																																			case 11:
																																			case 501:
																																				goto IL_1be7;
																																			case 130:
																																				goto IL_1bf5;
																																			case 297:
																																				goto IL_1c18;
																																			case 332:
																																				goto IL_1c22;
																																			case 123:
																																				goto IL_1c30;
																																			case 502:
																																				goto IL_1c43;
																																			case 477:
																																				goto IL_1c51;
																																			case 186:
																																				goto IL_1c5f;
																																			case 89:
																																				goto IL_1c6d;
																																			case 70:
																																			case 190:
																																				goto IL_1c7b;
																																			case 395:
																																				goto IL_1cbb;
																																			case 292:
																																				goto IL_1ccf;
																																			case 220:
																																			case 466:
																																				goto IL_1ce2;
																																			case 363:
																																				goto IL_1cff;
																																			case 451:
																																				goto IL_1d3e;
																																			case 356:
																																				goto IL_1d51;
																																			case 496:
																																				goto IL_1d5f;
																																			case 341:
																																			case 378:
																																				goto IL_1d76;
																																			case 65:
																																				goto IL_1d84;
																																			case 491:
																																				goto IL_1da2;
																																			case 401:
																																				goto IL_1db0;
																																			case 506:
																																				goto IL_1dc3;
																																			case 488:
																																				goto IL_1ddf;
																																			case 290:
																																				goto IL_1df3;
																																			case 505:
																																				goto IL_1e2b;
																																			case 472:
																																				goto IL_1e3e;
																																			case 291:
																																				goto IL_1e4c;
																																			case 16:
																																			case 382:
																																				goto IL_1e5a;
																																			case 393:
																																				goto IL_1e92;
																																			case 15:
																																				goto IL_1ea6;
																																			case 244:
																																				goto IL_1eb9;
																																			case 151:
																																				goto IL_1ec7;
																																			case 125:
																																			case 350:
																																				goto IL_1ed5;
																																			case 402:
																																				goto IL_1f1c;
																																			case 454:
																																				goto IL_1f2a;
																																			case 457:
																																				goto IL_1f46;
																																			case 248:
																																			case 282:
																																				goto IL_1f51;
																																			case 249:
																																				goto IL_1f91;
																																			case 214:
																																				goto IL_1fa5;
																																			case 232:
																																				goto IL_1fb8;
																																			case 344:
																																				goto IL_1fc6;
																																			case 74:
																																			case 317:
																																				goto IL_1fd1;
																																			case 260:
																																				goto IL_1ffe;
																																			case 43:
																																				goto IL_2011;
																																			case 200:
																																				goto IL_2028;
																																			case 206:
																																			case 357:
																																				goto IL_203f;
																																			case 32:
																																				goto IL_2053;
																																			case 288:
																																				goto IL_208c;
																																			case 276:
																																				goto IL_209f;
																																			case 329:
																																				goto IL_20ad;
																																			case 177:
																																			case 334:
																																				goto IL_20bb;
																																			case 94:
																																				goto IL_20d8;
																																			case 90:
																																				goto IL_2117;
																																			case 104:
																																				goto IL_212a;
																																			case 182:
																																			case 444:
																																				goto IL_2135;
																																			case 78:
																																				goto IL_2149;
																																			case 338:
																																				goto IL_2191;
																																			case 202:
																																				goto IL_21a4;
																																			case 159:
																																				goto IL_21b2;
																																			case 371:
																																			case 426:
																																				goto IL_21bd;
																																			case 63:
																																				goto IL_21e6;
																																			case 153:
																																				goto IL_21f4;
																																			case 209:
																																				goto IL_2207;
																																			case 169:
																																				goto IL_2215;
																																			case 13:
																																				goto IL_222c;
																																			case 148:
																																			case 198:
																																				goto IL_223a;
																																			case 268:
																																				goto IL_2257;
																																			case 383:
																																				goto IL_228f;
																																			case 459:
																																				goto IL_22a2;
																																			case 361:
																																				goto IL_22ad;
																																			case 38:
																																				goto IL_22bb;
																																			case 14:
																																			case 154:
																																				goto IL_22c9;
																																			case 448:
																																				goto IL_22e1;
																																			case 112:
																																				goto IL_22ef;
																																			case 278:
																																				goto IL_22fd;
																																			case 21:
																																			case 460:
																																				goto IL_2310;
																																			case 487:
																																				goto IL_2348;
																																			case 397:
																																				goto IL_235c;
																																			case 385:
																																				goto IL_236f;
																																			case 330:
																																				goto IL_237d;
																																			case 3:
																																			case 272:
																																				goto IL_2388;
																																			case 106:
																																				goto IL_239c;
																																			case 316:
																																				goto IL_23db;
																																			case 296:
																																				goto IL_23ee;
																																			case 46:
																																				goto IL_2405;
																																			case 40:
																																			case 320:
																																				goto IL_2413;
																																			case 263:
																																				goto IL_242c;
																																			case 360:
																																				goto IL_2443;
																																			case 117:
																																				goto IL_2451;
																																			case 256:
																																				goto IL_246d;
																																			case 164:
																																				goto IL_2484;
																																			case 261:
																																			case 493:
																																				goto IL_248f;
																																			case 114:
																																				goto IL_24cf;
																																			case 194:
																																				goto IL_24ec;
																																			case 9:
																																			case 18:
																																			case 22:
																																			case 24:
																																			case 28:
																																			case 33:
																																			case 39:
																																			case 41:
																																			case 45:
																																			case 48:
																																			case 60:
																																			case 67:
																																			case 69:
																																			case 84:
																																			case 86:
																																			case 87:
																																			case 110:
																																			case 120:
																																			case 126:
																																			case 133:
																																			case 136:
																																			case 138:
																																			case 146:
																																			case 152:
																																			case 162:
																																			case 167:
																																			case 172:
																																			case 199:
																																			case 201:
																																			case 213:
																																			case 215:
																																			case 216:
																																			case 222:
																																			case 229:
																																			case 236:
																																			case 252:
																																			case 254:
																																			case 275:
																																			case 283:
																																			case 285:
																																			case 303:
																																			case 315:
																																			case 337:
																																			case 342:
																																			case 353:
																																			case 362:
																																			case 364:
																																			case 374:
																																			case 386:
																																			case 389:
																																			case 392:
																																			case 404:
																																			case 412:
																																			case 416:
																																			case 430:
																																			case 432:
																																			case 438:
																																			case 443:
																																			case 447:
																																			case 473:
																																			case 475:
																																			case 479:
																																			case 485:
																																			case 489:
																																				goto end_IL_08a4;
																																			case 0:
																																			case 42:
																																			case 49:
																																			case 50:
																																			case 51:
																																			case 52:
																																			case 53:
																																			case 59:
																																			case 76:
																																			case 81:
																																			case 93:
																																			case 101:
																																			case 111:
																																			case 116:
																																			case 122:
																																			case 124:
																																			case 131:
																																			case 137:
																																			case 139:
																																			case 158:
																																			case 168:
																																			case 174:
																																			case 183:
																																			case 207:
																																			case 208:
																																			case 219:
																																			case 223:
																																			case 225:
																																			case 226:
																																			case 237:
																																			case 238:
																																			case 246:
																																			case 250:
																																			case 265:
																																			case 277:
																																			case 293:
																																			case 300:
																																			case 301:
																																			case 312:
																																			case 318:
																																			case 335:
																																			case 343:
																																			case 346:
																																			case 352:
																																			case 373:
																																			case 377:
																																			case 380:
																																			case 388:
																																			case 390:
																																			case 391:
																																			case 411:
																																			case 413:
																																			case 419:
																																			case 431:
																																			case 434:
																																			case 436:
																																			case 449:
																																			case 456:
																																			case 462:
																																			case 468:
																																			case 471:
																																			case 481:
																																			case 498:
																																			case 503:
																																				goto end_IL_08d4;
																																			case 157:
																																				goto end_IL_250f;
																																			case 452:
																																				goto end_IL_2522;
																																			case 441:
																																				goto end_IL_252c;
																																			case 156:
																																				goto end_IL_2537;
																																			case 403:
																																				goto end_IL_2547;
																																			case 91:
																																			case 314:
																																				goto end_IL_2557;
																																			case 504:
																																				goto end_IL_2567;
																																			case 66:
																																				goto end_IL_2577;
																																			case 83:
																																				goto end_IL_2587;
																																			case 422:
																																				goto end_IL_2597;
																																			case 423:
																																				goto end_IL_25a7;
																																			case 414:
																																			case 450:
																																				return;
																																			}
																																			continue;
																																		}
																																		goto IL_1ddf;
																																		IL_1df3:
																																		array2[num6 - 1] = ((delegate*<GameObject, Renderer>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																																		goto IL_1e2b;
																																		IL_1e2b:
																																		ptr2 += 8;
																																		goto end_IL_08d4;
																																		IL_1ddf:
																																		array[num6 - 1] = 5;
																																		goto IL_1df3;
																																		continue;
																																		end_IL_0821:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_1e3e;
																																IL_1e92:
																																array[num6 - 1] = 5;
																																goto IL_1ea6;
																																IL_1ea6:
																																ptr2 += 8;
																																goto end_IL_08d4;
																																IL_1e3e:
																																if (28 < b)
																																{
																																	goto end_IL_08a4;
																																}
																																goto IL_1e4c;
																																IL_1e4c:
																																if (28 > b)
																																{
																																	goto end_IL_08a4;
																																}
																																goto IL_1e5a;
																																IL_1e5a:
																																array2[num6 - 1] = ((delegate*<Class184, GameObject>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																																goto IL_1e92;
																															}
																															break;
																														}
																														goto IL_1eb9;
																														IL_1f2a:
																														ptr2 += 8;
																														num = 391;
																														goto end_IL_08d4;
																														IL_1eb9:
																														if (30 < b)
																														{
																															goto end_IL_08a4;
																														}
																														goto IL_1ec7;
																														IL_1ec7:
																														if (30 > b)
																														{
																															goto end_IL_08a4;
																														}
																														goto IL_1ed5;
																														IL_1ed5:
																														((delegate*<Renderer, bool, void>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Renderer)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																														num = 402;
																														goto IL_1f1c;
																														IL_1f1c:
																														num6 -= 2;
																														goto IL_1f2a;
																													}
																													break;
																												}
																												goto IL_1f46;
																												IL_20bb:
																												array[num6 - 1] = 3;
																												num = 94;
																												goto IL_20d8;
																												IL_1f46:
																												if (27 <= b)
																												{
																													goto IL_1f51;
																												}
																												goto IL_1fb8;
																												IL_1f51:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_1f91;
																												IL_1f91:
																												array[num6 - 2] = 3;
																												goto IL_1fa5;
																												IL_1fa5:
																												num6--;
																												goto end_IL_08d4;
																												IL_1fb8:
																												if (25 >= b)
																												{
																													goto IL_1fc6;
																												}
																												goto IL_209f;
																												IL_1fc6:
																												if (25 <= b)
																												{
																													goto IL_1fd1;
																												}
																												goto IL_2011;
																												IL_1fd1:
																												((Class184)array2[num6 - 2]).gameObject_0 = (GameObject)array2[num6 - 1];
																												goto IL_1ffe;
																												IL_1ffe:
																												num6 -= 2;
																												goto end_IL_08d4;
																												IL_2011:
																												if (24 < b)
																												{
																													goto end_IL_08a4;
																												}
																												num = 200;
																												goto IL_2028;
																												IL_20d8:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_2117;
																												IL_2028:
																												if (24 > b)
																												{
																													goto end_IL_08a4;
																												}
																												num = 357;
																												goto IL_203f;
																												IL_2117:
																												ptr2 += 8;
																												goto end_IL_08d4;
																												IL_203f:
																												array[num6 - 1] = 5;
																												goto IL_2053;
																												IL_2053:
																												array2[num6 - 1] = ((delegate*<PrimitiveType, GameObject>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(PrimitiveType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_208c;
																												IL_208c:
																												ptr2 += 8;
																												goto end_IL_08d4;
																												IL_209f:
																												if (26 < b)
																												{
																													goto end_IL_08a4;
																												}
																												goto IL_20ad;
																												IL_20ad:
																												if (26 > b)
																												{
																													goto end_IL_08a4;
																												}
																												goto IL_20bb;
																											}
																											break;
																										}
																										goto IL_212a;
																										IL_2484:
																										if (22 > b)
																										{
																											goto end_IL_08a4;
																										}
																										goto IL_248f;
																										IL_212a:
																										if (23 <= b)
																										{
																											goto IL_2135;
																										}
																										goto IL_21a4;
																										IL_2135:
																										array[num6 - 1] = 0;
																										goto IL_2149;
																										IL_2149:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										num = 338;
																										goto IL_2191;
																										IL_2191:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_21a4:
																										if (19 >= b)
																										{
																											goto IL_21b2;
																										}
																										goto IL_236f;
																										IL_21b2:
																										if (19 <= b)
																										{
																											goto IL_21bd;
																										}
																										goto IL_2207;
																										IL_21bd:
																										((delegate*<UnityEngine.Object, void>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Collider)array2[num6 - 1]);
																										goto IL_21e6;
																										IL_21e6:
																										num6--;
																										goto IL_21f4;
																										IL_21f4:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_2207:
																										if (17 < b)
																										{
																											goto IL_2215;
																										}
																										goto IL_22a2;
																										IL_2215:
																										if (18 < b)
																										{
																											goto end_IL_08a4;
																										}
																										num = 13;
																										goto IL_222c;
																										IL_248f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_24cf;
																										IL_222c:
																										if (18 > b)
																										{
																											goto end_IL_08a4;
																										}
																										goto IL_223a;
																										IL_223a:
																										array[num6 - 1] = 5;
																										num = 268;
																										goto IL_2257;
																										IL_2257:
																										array2[num6 - 1] = ((delegate*<GameObject, Collider>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																										goto IL_228f;
																										IL_228f:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_22a2:
																										if (17 > b)
																										{
																											goto IL_22ad;
																										}
																										goto IL_2310;
																										IL_22ad:
																										if (16 < b)
																										{
																											goto end_IL_08a4;
																										}
																										goto IL_22bb;
																										IL_22bb:
																										if (16 > b)
																										{
																											goto end_IL_08a4;
																										}
																										goto IL_22c9;
																										IL_22c9:
																										array2[num6] = array5[*(int*)(ptr2 + num3)];
																										goto IL_22e1;
																										IL_22e1:
																										array[num6] = 5;
																										goto IL_22ef;
																										IL_22ef:
																										num6++;
																										goto IL_22fd;
																										IL_22fd:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_2310:
																										array2[num6 - 1] = ((delegate*<Class184, GameObject>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																										goto IL_2348;
																										IL_2348:
																										array[num6 - 1] = 5;
																										goto IL_235c;
																										IL_235c:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_236f:
																										if (21 >= b)
																										{
																											goto IL_237d;
																										}
																										goto IL_246d;
																										IL_237d:
																										if (21 <= b)
																										{
																											goto IL_2388;
																										}
																										goto IL_23ee;
																										IL_2388:
																										array[num6 - 1] = 3;
																										goto IL_239c;
																										IL_239c:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_23db;
																										IL_23db:
																										ptr2 += 8;
																										goto end_IL_08d4;
																										IL_23ee:
																										if (20 < b)
																										{
																											goto end_IL_08a4;
																										}
																										num = 46;
																										goto IL_2405;
																										IL_24cf:
																										array[num6 - 2] = 3;
																										num = 194;
																										goto IL_24ec;
																										IL_2405:
																										if (20 > b)
																										{
																											goto end_IL_08a4;
																										}
																										goto IL_2413;
																										IL_2413:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_242c;
																										IL_242c:
																										array[num6] = 3;
																										num = 360;
																										goto IL_2443;
																										IL_2443:
																										num6++;
																										goto IL_2451;
																										IL_2451:
																										ptr2 += 16;
																										num = 137;
																										goto end_IL_08d4;
																										IL_246d:
																										if (22 < b)
																										{
																											goto end_IL_08a4;
																										}
																										num = 164;
																										goto IL_2484;
																										IL_24ec:
																										num6--;
																										goto end_IL_08d4;
																									}
																									break;
																								}
																								goto IL_090d;
																								IL_1a1b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																								goto IL_1a5c;
																								IL_090d:
																								if (15 > b)
																								{
																									goto IL_091b;
																								}
																								goto IL_0ee1;
																								IL_091b:
																								if (7 >= b)
																								{
																									goto IL_0929;
																								}
																								goto IL_0a1a;
																								IL_0929:
																								if (7 > b)
																								{
																									goto IL_0937;
																								}
																								goto IL_0e2c;
																								IL_0937:
																								if (3 >= b)
																								{
																									goto IL_0945;
																								}
																								goto IL_1860;
																								IL_0945:
																								if (3 > b)
																								{
																									goto IL_0953;
																								}
																								goto IL_1710;
																								IL_0953:
																								if (1 < b)
																								{
																									goto IL_09e9;
																								}
																								goto IL_0a0a;
																								IL_0a0a:
																								if (1 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_0a7e;
																								IL_0a7e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0a97;
																								IL_0a97:
																								array[num6] = 0;
																								goto IL_0aa5;
																								IL_0aa5:
																								num6++;
																								goto IL_0ab3;
																								IL_0ab3:
																								ptr2 += 8;
																								goto end_IL_08d4;
																								IL_09e9:
																								if (2 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_09f7;
																								IL_09f7:
																								if (2 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_0fa4;
																								IL_0fa4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0fe4;
																								IL_0fe4:
																								array[num6 - 2] = 0;
																								goto IL_0ff8;
																								IL_0ff8:
																								num6--;
																								goto end_IL_08d4;
																								IL_1710:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_1739;
																								IL_1739:
																								ptr2 += 8;
																								goto IL_1747;
																								IL_1747:
																								num6--;
																								goto end_IL_08d4;
																								IL_1860:
																								if (5 < b)
																								{
																									goto IL_186e;
																								}
																								num = 253;
																								goto IL_1903;
																								IL_186e:
																								if (6 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_187c;
																								IL_187c:
																								if (6 > b)
																								{
																									goto end_IL_08a4;
																								}
																								num = 406;
																								goto IL_1893;
																								IL_1a70:
																								num6--;
																								goto end_IL_08d4;
																								IL_1893:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_18d3;
																								IL_18d3:
																								array[num6 - 2] = 0;
																								goto IL_18e7;
																								IL_18e7:
																								num6--;
																								goto end_IL_08d4;
																								IL_1a5c:
																								array[num6 - 2] = 0;
																								goto IL_1a70;
																								IL_1903:
																								if (5 <= b)
																								{
																									goto IL_1911;
																								}
																								goto IL_1993;
																								IL_1911:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								num = 421;
																								goto IL_195a;
																								IL_195a:
																								array[num6 - 2] = 0;
																								num = 96;
																								goto IL_1977;
																								IL_1977:
																								num6--;
																								num = 419;
																								goto end_IL_08d4;
																								IL_1993:
																								if (4 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_19a1;
																								IL_19a1:
																								if (4 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_1be7;
																								IL_1be7:
																								array[num6] = 0;
																								goto IL_1bf5;
																								IL_1bf5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_1c18;
																								IL_1c18:
																								array2[num6] = null;
																								goto IL_1c22;
																								IL_1c22:
																								num6++;
																								goto IL_1c30;
																								IL_1c30:
																								ptr2 += 8;
																								goto end_IL_08d4;
																								IL_0e2c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0e6c;
																								IL_0e6c:
																								array[num6 - 2] = 0;
																								goto IL_0e80;
																								IL_0e80:
																								num6--;
																								goto end_IL_08d4;
																								IL_0a1a:
																								if (11 >= b)
																								{
																									goto IL_0a25;
																								}
																								goto IL_0a62;
																								IL_0a25:
																								if (11 <= b)
																								{
																									goto end_IL_08d4;
																								}
																								goto IL_0a33;
																								IL_0a33:
																								if (9 >= b)
																								{
																									goto IL_0a41;
																								}
																								goto IL_175a;
																								IL_0a41:
																								if (9 > b)
																								{
																									goto IL_0a4f;
																								}
																								goto IL_19b4;
																								IL_0a4f:
																								if (8 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_1671;
																								IL_1671:
																								if (8 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_167f;
																								IL_167f:
																								num6--;
																								goto end_IL_08d4;
																								IL_19b4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_19f4;
																								IL_19f4:
																								array[num6 - 2] = 0;
																								goto IL_1a08;
																								IL_1a08:
																								num6--;
																								goto end_IL_08d4;
																								IL_175a:
																								if (10 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_1768;
																								IL_1768:
																								if (10 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_1776;
																								IL_1776:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_17d8;
																								IL_17d8:
																								num6 -= 2;
																								goto end_IL_08d4;
																								IL_0a62:
																								if (13 >= b)
																								{
																									num = 365;
																									goto IL_0d03;
																								}
																								goto IL_0d9e;
																								IL_0ee1:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0f33;
																								IL_0d03:
																								if (13 > b)
																								{
																									goto IL_0d0e;
																								}
																								num = 17;
																								goto IL_0d35;
																								IL_0d0e:
																								if (12 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_0d1c;
																								IL_0d1c:
																								if (12 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_0d4d;
																								IL_0d4d:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																								num = 35;
																								goto IL_0d6f;
																								IL_0d6f:
																								array[num6] = 1;
																								goto IL_0d7d;
																								IL_0d7d:
																								num6++;
																								goto IL_0d8b;
																								IL_0d8b:
																								ptr2 += 16;
																								goto end_IL_08d4;
																								IL_0f33:
																								num6--;
																								goto end_IL_08d4;
																								IL_0d35:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_08d4;
																								IL_0d9e:
																								if (14 < b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_0dac;
																								IL_0dac:
																								if (14 > b)
																								{
																									goto end_IL_08a4;
																								}
																								goto IL_1a1b;
																							}
																							break;
																						}
																						goto IL_09cd;
																						IL_09cd:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_08d4;
																					}
																					goto IL_0c1a;
																				}
																				goto IL_08df;
																				IL_12fe:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_08df:
																				if (46 < b)
																				{
																					goto IL_08ea;
																				}
																				goto IL_08fa;
																				IL_08ea:
																				if (54 >= b)
																				{
																					goto IL_0966;
																				}
																				goto IL_0982;
																				IL_0966:
																				if (54 <= b)
																				{
																					num = 71;
																					goto IL_1149;
																				}
																				goto IL_1429;
																				IL_1311:
																				if (35 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_131f;
																				IL_1149:
																				array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																				goto IL_1181;
																				IL_1181:
																				array[num6 - 1] = 5;
																				goto IL_1195;
																				IL_1195:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1429:
																				if (50 >= b)
																				{
																					goto IL_1437;
																				}
																				goto IL_1c43;
																				IL_1437:
																				if (50 > b)
																				{
																					goto IL_1517;
																				}
																				goto IL_1b09;
																				IL_1b09:
																				((delegate*<Material, Color, void>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Material)array2[num6 - 2], (Color)array2[num6 - 1]);
																				goto IL_1b46;
																				IL_1b46:
																				num6 -= 2;
																				goto IL_1b54;
																				IL_1b54:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1517:
																				if (48 >= b)
																				{
																					goto IL_1525;
																				}
																				goto IL_1603;
																				IL_1525:
																				if (48 <= b)
																				{
																					goto IL_1530;
																				}
																				goto IL_158f;
																				IL_1530:
																				array[num6 - 1] = 5;
																				goto IL_1544;
																				IL_1544:
																				array2[num6 - 1] = ((delegate*<Renderer, Material>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Renderer)array2[num6 - 1]);
																				goto IL_157c;
																				IL_157c:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_158f:
																				if (47 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_159d;
																				IL_159d:
																				if (47 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_15ab;
																				IL_15ab:
																				array[num6 - 1] = 3;
																				goto IL_15bf;
																				IL_15bf:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_16ea;
																				IL_16ea:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1603:
																				if (49 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1611;
																				IL_1611:
																				if (49 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_161f;
																				IL_161f:
																				array2[num6] = ((delegate*<Color>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])();
																				goto IL_1642;
																				IL_1642:
																				array[num6] = 4;
																				goto IL_1650;
																				IL_1650:
																				num6++;
																				goto IL_165e;
																				IL_165e:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1c43:
																				if (52 >= b)
																				{
																					goto IL_1c51;
																				}
																				goto IL_1d51;
																				IL_1c51:
																				if (52 > b)
																				{
																					goto IL_1c5f;
																				}
																				goto IL_1ce2;
																				IL_1c5f:
																				if (51 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1c6d;
																				IL_1c6d:
																				if (51 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1c7b;
																				IL_1c7b:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1cbb;
																				IL_1cbb:
																				array[num6 - 2] = 3;
																				goto IL_1ccf;
																				IL_1ccf:
																				num6--;
																				goto end_IL_08d4;
																				IL_1ce2:
																				array[num6 - 1] = 3;
																				num = 363;
																				goto IL_1cff;
																				IL_1cff:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1d3e;
																				IL_1d3e:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1d51:
																				if (53 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1d5f;
																				IL_1d5f:
																				if (53 > b)
																				{
																					goto end_IL_08a4;
																				}
																				num = 341;
																				goto IL_1d76;
																				IL_131f:
																				if (35 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_132d;
																				IL_1d76:
																				array[num6] = 5;
																				goto IL_1d84;
																				IL_1d84:
																				array2[num6] = ((delegate*<GorillaTagger>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])();
																				goto IL_1da2;
																				IL_1da2:
																				num6++;
																				goto IL_1db0;
																				IL_1db0:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_0982:
																				if (58 >= b)
																				{
																					goto IL_0990;
																				}
																				goto IL_0ba9;
																				IL_0990:
																				if (58 > b)
																				{
																					goto IL_099e;
																				}
																				goto IL_1692;
																				IL_099e:
																				if (56 < b)
																				{
																					goto IL_09ac;
																				}
																				goto IL_17eb;
																				IL_09ac:
																				if (57 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_09ba;
																				IL_09ba:
																				if (57 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0c2d;
																				IL_0c2d:
																				array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																				goto IL_0c65;
																				IL_0c65:
																				array[num6 - 1] = 5;
																				goto IL_0c79;
																				IL_0c79:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_17eb:
																				if (56 <= b)
																				{
																					goto IL_17f9;
																				}
																				goto IL_1b67;
																				IL_17f9:
																				((delegate*<Transform, Vector3, void>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																				num = 366;
																				goto IL_183f;
																				IL_183f:
																				num6 -= 2;
																				goto IL_184d;
																				IL_184d:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1b67:
																				if (55 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1b75;
																				IL_1b75:
																				if (55 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1b83;
																				IL_1b83:
																				array[num6 - 1] = 4;
																				goto IL_1b97;
																				IL_1b97:
																				array2[num6 - 1] = ((delegate*<Transform, Vector3>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																				goto IL_1bd4;
																				IL_1bd4:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1692:
																				array[num6 - 1] = 3;
																				goto IL_16a6;
																				IL_16a6:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1dc3;
																				IL_1dc3:
																				ptr2 += 8;
																				num = 223;
																				goto end_IL_08d4;
																				IL_0ba9:
																				if (60 < b)
																				{
																					goto IL_0bb4;
																				}
																				goto IL_0bd5;
																				IL_0bb4:
																				if (61 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0bc2;
																				IL_0bc2:
																				if (61 > b)
																				{
																				}
																				goto end_IL_08a4;
																				IL_0bd5:
																				if (60 <= b)
																				{
																					goto IL_0be0;
																				}
																				goto IL_0c0c;
																				IL_0be0:
																				global::_003CModule_003E.color_16 = (Color)array2[num6 - 1];
																				goto IL_0bf9;
																				IL_0bf9:
																				num6--;
																				goto end_IL_08d4;
																				IL_0c0c:
																				if (59 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0c1a;
																				IL_0c1a:
																				if (59 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0dbf;
																				IL_0dbf:
																				array[num6 - 1] = 4;
																				goto IL_0dd3;
																				IL_0dd3:
																				array2[num6 - 1] = ((delegate*<Class184, Color>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																				num = 95;
																				goto IL_0e19;
																				IL_0e19:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_08fa:
																				if (46 > b)
																				{
																					goto IL_0ac6;
																				}
																				goto IL_0f46;
																				IL_0f46:
																				((delegate*<Transform, Vector3, void>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																				goto IL_0f83;
																				IL_0f83:
																				num6 -= 2;
																				goto IL_0f91;
																				IL_0f91:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_0ac6:
																				if (38 < b)
																				{
																					goto IL_0ad4;
																				}
																				goto IL_0e93;
																				IL_0ad4:
																				if (42 >= b)
																				{
																					goto IL_0adf;
																				}
																				goto IL_0b0f;
																				IL_0adf:
																				if (42 <= b)
																				{
																					num = 140;
																					goto IL_0af6;
																				}
																				goto IL_0c8c;
																				IL_132d:
																				array[num6] = 0;
																				num = 5;
																				goto IL_1344;
																				IL_0af6:
																				array[num6 - 1] = 5;
																				goto IL_14cc;
																				IL_14cc:
																				array2[num6 - 1] = ((delegate*<GameObject, Transform>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																				goto IL_1504;
																				IL_1504:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_0c8c:
																				if (40 < b)
																				{
																					goto IL_0c9a;
																				}
																				goto IL_100b;
																				IL_0c9a:
																				if (41 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0ca8;
																				IL_0ca8:
																				if (41 > b)
																				{
																					goto end_IL_08a4;
																				}
																				num = 80;
																				goto IL_0cbf;
																				IL_1344:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_1a83;
																				IL_0cbf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0cea;
																				IL_0cea:
																				array[num6 - 1] = 0;
																				goto end_IL_08d4;
																				IL_100b:
																				if (40 > b)
																				{
																					goto IL_1019;
																				}
																				num = 176;
																				goto IL_10ad;
																				IL_1019:
																				if (39 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1027;
																				IL_1027:
																				if (39 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1035;
																				IL_1035:
																				array[num6 - 1] = 3;
																				num = 228;
																				goto IL_1052;
																				IL_1052:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1091;
																				IL_1091:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1a83:
																				num6++;
																				num = 47;
																				goto IL_1a9a;
																				IL_10ad:
																				((Class184)array2[num6 - 2]).gameObject_1 = (GameObject)array2[num6 - 1];
																				goto IL_16fd;
																				IL_16fd:
																				num6 -= 2;
																				goto end_IL_08d4;
																				IL_0b0f:
																				if (44 >= b)
																				{
																					goto IL_0b1a;
																				}
																				goto IL_0b96;
																				IL_0b1a:
																				if (44 > b)
																				{
																					goto IL_0b28;
																				}
																				goto IL_1100;
																				IL_0b28:
																				if (43 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0b36;
																				IL_0b36:
																				if (43 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_0b44;
																				IL_0b44:
																				array[num6] = 4;
																				goto IL_0b52;
																				IL_0b52:
																				array2[num6] = ((delegate*<Vector3>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])();
																				goto IL_0b75;
																				IL_0b75:
																				num6++;
																				goto IL_0b83;
																				IL_0b83:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1100:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																				goto IL_111a;
																				IL_111a:
																				array[num6] = 3;
																				goto IL_1128;
																				IL_1128:
																				num6++;
																				goto IL_1136;
																				IL_1136:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_0b96:
																				if (45 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1394;
																				IL_1394:
																				if (45 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_13a2;
																				IL_13a2:
																				array[num6 - 2] = 4;
																				goto IL_13b6;
																				IL_13b6:
																				array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																				goto IL_1408;
																				IL_1408:
																				num6--;
																				goto IL_1416;
																				IL_1416:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_0e93:
																				if (38 <= b)
																				{
																					goto IL_0ea1;
																				}
																				goto IL_11a8;
																				IL_0ea1:
																				array[num6] = 0;
																				goto IL_0eaf;
																				IL_0eaf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				num = 433;
																				goto IL_10df;
																				IL_10df:
																				num6++;
																				goto IL_10ed;
																				IL_10ed:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_11a8:
																				if (34 >= b)
																				{
																					goto IL_11b6;
																				}
																				goto IL_126b;
																				IL_11b6:
																				if (34 <= b)
																				{
																					goto IL_11c1;
																				}
																				goto IL_1206;
																				IL_11c1:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_136d;
																				IL_136d:
																				array[num6 - 2] = 3;
																				goto IL_1381;
																				IL_1381:
																				num6--;
																				goto end_IL_08d4;
																				IL_1206:
																				if (32 >= b)
																				{
																					goto IL_1211;
																				}
																				goto IL_124a;
																				IL_1211:
																				if (32 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_121f;
																				IL_121f:
																				array2[num6] = null;
																				goto IL_1229;
																				IL_1229:
																				array[num6] = 5;
																				goto IL_1237;
																				IL_1237:
																				num6++;
																				goto end_IL_08d4;
																				IL_124a:
																				if (33 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1258;
																				IL_1258:
																				if (33 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_144a;
																				IL_144a:
																				array[num6 - 2] = 0;
																				goto IL_145e;
																				IL_145e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_14ab;
																				IL_14ab:
																				num6--;
																				goto IL_14b9;
																				IL_14b9:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_126b:
																				if (36 < b)
																				{
																					goto IL_1276;
																				}
																				num = 143;
																				goto IL_12a0;
																				IL_1276:
																				if (37 < b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1284;
																				IL_1284:
																				if (37 > b)
																				{
																					goto end_IL_08a4;
																				}
																				goto IL_1ab6;
																				IL_1ab6:
																				array[num6] = 0;
																				goto IL_1ac4;
																				IL_1ac4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_1ae8;
																				IL_1ae8:
																				num6++;
																				goto IL_1af6;
																				IL_1af6:
																				ptr2 += 8;
																				goto end_IL_08d4;
																				IL_1a9a:
																				ptr2 += 8;
																				num = 250;
																				goto end_IL_08d4;
																				IL_12a0:
																				if (36 <= b)
																				{
																					goto IL_12ab;
																				}
																				goto IL_1311;
																				IL_12ab:
																				array[num6 - 1] = 3;
																				goto IL_12bf;
																				IL_12bf:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)CompilerGlobalScopeAttributeNullStream[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_12fe;
																				continue;
																				end_IL_0897:
																				break;
																			}
																			continue;
																			end_IL_08a4:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_08d4;
																	continue;
																	end_IL_08b4:
																	break;
																}
																continue;
																end_IL_08c4:
																break;
															}
															continue;
															end_IL_08d4:
															break;
														}
														continue;
														end_IL_250f:
														break;
													}
													continue;
													end_IL_2522:
													break;
												}
												continue;
												end_IL_252c:
												break;
											}
											continue;
											end_IL_2537:
											break;
										}
										continue;
										end_IL_2547:
										break;
									}
									continue;
									end_IL_2557:
									break;
								}
								continue;
								end_IL_2567:
								break;
							}
							continue;
							end_IL_2577:
							break;
						}
						continue;
						end_IL_2587:
						break;
					}
					continue;
					end_IL_2597:
					break;
				}
				continue;
				end_IL_25a7:
				break;
			}
		}
	}

	private static bool IsCallbackDefinitionIdentity(Vector3 vector3_1, Vector3 vector3_2)
	{
		return vector3_1 != vector3_2;
	}

	private static float CheckTypeSecuritygetPermissionType()
	{
		return Time.time;
	}

	private unsafe void OnDisable()
	{
		int num = 242;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 263;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_14a1:
						object[] array2 = new object[3];
						while (true)
						{
							IL_1491:
							int[] array3 = new int[6];
							while (true)
							{
								IL_1481:
								long[] array4 = new long[3];
								while (true)
								{
									IL_1471:
									object[] array5 = new object[1];
									while (true)
									{
										IL_1458:
										array5[0] = this;
										num = 108;
										while (true)
										{
											IL_144d:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContainssetUseAttribute.APPXFLAGSGetEncodings);
											while (true)
											{
												IL_1443:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_1430:
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_062a:
														byte b = *ptr2;
														while (true)
														{
															IL_061a:
															ptr2++;
															while (true)
															{
																IL_060a:
																if (b >= 1)
																{
																	while (b <= 33)
																	{
																		while (true)
																		{
																			IL_05ea:
																			if (17 < b)
																			{
																				while (true)
																				{
																					IL_05da:
																					if (25 >= b)
																					{
																						while (true)
																						{
																							IL_05ca:
																							if (25 > b)
																							{
																								while (true)
																								{
																									IL_05ba:
																									if (21 >= b)
																									{
																										num = 16;
																										while (true)
																										{
																											IL_05aa:
																											if (21 <= b)
																											{
																												while (true)
																												{
																													IL_056b:
																													array2[num5 - 1] = ((delegate*<Class184, Vector3>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((Class184)array2[num5 - 1]);
																													while (true)
																													{
																														IL_054c:
																														array[num5 - 1] = 4;
																														num = 327;
																														while (true)
																														{
																															if (num != 327)
																															{
																																if (num != 1308)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 48:
																																	goto IL_054c;
																																case 154:
																																case 277:
																																	goto IL_056b;
																																case 16:
																																	goto IL_05aa;
																																case 62:
																																	goto IL_05ba;
																																case 214:
																																	goto IL_05ca;
																																case 65:
																																	goto IL_05da;
																																case 46:
																																	goto IL_05ea;
																																case 90:
																																	goto IL_05fa;
																																case 121:
																																	goto IL_060a;
																																case 115:
																																	goto IL_061a;
																																case 30:
																																case 104:
																																	goto IL_062a;
																																case 83:
																																	goto IL_0635;
																																case 288:
																																	goto IL_0643;
																																case 97:
																																case 149:
																																	goto IL_0651;
																																case 203:
																																	goto IL_0665;
																																case 191:
																																	goto IL_06b7;
																																case 35:
																																	goto IL_06c5;
																																case 196:
																																	goto IL_06d8;
																																case 95:
																																	goto IL_06e6;
																																case 192:
																																case 302:
																																	goto IL_06f6;
																																case 176:
																																	goto IL_0704;
																																case 13:
																																case 222:
																																	goto IL_0712;
																																case 297:
																																	goto IL_0726;
																																case 94:
																																case 306:
																																	goto IL_0763;
																																case 280:
																																	goto IL_0771;
																																case 243:
																																	goto IL_0794;
																																case 69:
																																case 308:
																																	goto IL_07a7;
																																case 17:
																																	goto IL_07b5;
																																case 106:
																																	goto IL_07c3;
																																case 304:
																																	goto IL_07d1;
																																case 171:
																																case 272:
																																	goto IL_07dc;
																																case 174:
																																	goto IL_083a;
																																case 153:
																																	goto IL_0856;
																																case 32:
																																	goto IL_0864;
																																case 187:
																																case 286:
																																	goto IL_0872;
																																case 34:
																																	goto IL_0880;
																																case 0:
																																	goto IL_08a4;
																																case 301:
																																	goto IL_08b2;
																																case 44:
																																	goto IL_08c5;
																																case 101:
																																	goto IL_08d3;
																																case 64:
																																case 133:
																																	goto IL_08e1;
																																case 53:
																																	goto IL_091f;
																																case 20:
																																	goto IL_092d;
																																case 105:
																																case 303:
																																	goto IL_0940;
																																case 255:
																																	goto IL_094e;
																																case 140:
																																	goto IL_0971;
																																case 27:
																																	goto IL_097f;
																																case 128:
																																	goto IL_0992;
																																case 72:
																																case 137:
																																	goto IL_099d;
																																case 177:
																																	goto IL_09ab;
																																case 246:
																																case 284:
																																	goto IL_09b9;
																																case 52:
																																	goto IL_09d5;
																																case 131:
																																case 159:
																																	goto IL_09e0;
																																case 28:
																																	goto IL_09ee;
																																case 212:
																																case 213:
																																	goto IL_09fc;
																																case 201:
																																	goto IL_0a29;
																																case 200:
																																case 221:
																																	goto IL_0a3c;
																																case 178:
																																	goto IL_0a65;
																																case 267:
																																	goto IL_0a7c;
																																case 317:
																																	goto IL_0a8f;
																																case 318:
																																	goto IL_0aa2;
																																case 319:
																																	goto IL_0ab5;
																																case 206:
																																	goto IL_0ac3;
																																case 29:
																																	goto IL_0ae9;
																																case 161:
																																case 279:
																																	goto IL_0af7;
																																case 60:
																																	goto IL_0b05;
																																case 61:
																																case 251:
																																	goto IL_0b13;
																																case 180:
																																	goto IL_0b27;
																																case 283:
																																	goto IL_0b74;
																																case 295:
																																	goto IL_0b82;
																																case 194:
																																	goto IL_0b95;
																																case 73:
																																case 238:
																																	goto IL_0ba3;
																																case 240:
																																	goto IL_0bb1;
																																case 102:
																																case 152:
																																	goto IL_0bbf;
																																case 63:
																																	goto IL_0c11;
																																case 50:
																																case 107:
																																	goto IL_0c24;
																																case 77:
																																	goto IL_0c5c;
																																case 120:
																																	goto IL_0c70;
																																case 6:
																																case 55:
																																	goto IL_0c83;
																																case 237:
																																	goto IL_0cc0;
																																case 210:
																																	goto IL_0cce;
																																case 127:
																																	goto IL_0ce1;
																																case 124:
																																case 125:
																																	goto IL_0cef;
																																case 36:
																																	goto IL_0cfd;
																																case 150:
																																case 220:
																																	goto IL_0d0b;
																																case 82:
																																case 211:
																																	goto IL_0d19;
																																case 87:
																																case 219:
																																	goto IL_0d27;
																																case 117:
																																	goto IL_0d35;
																																case 68:
																																case 189:
																																	goto IL_0d43;
																																case 135:
																																	goto IL_0d83;
																																case 155:
																																	goto IL_0d97;
																																case 109:
																																	goto IL_0daa;
																																case 59:
																																case 183:
																																	goto IL_0db8;
																																case 173:
																																	goto IL_0dc6;
																																case 156:
																																case 265:
																																	goto IL_0ddd;
																																case 226:
																																	goto IL_0e1d;
																																case 75:
																																	goto IL_0e31;
																																case 67:
																																case 202:
																																	goto IL_0e44;
																																case 266:
																																	goto IL_0e84;
																																case 287:
																																	goto IL_0e98;
																																case 58:
																																	goto IL_0eab;
																																case 25:
																																case 40:
																																	goto IL_0ebf;
																																case 165:
																																	goto IL_0ecd;
																																case 258:
																																	goto IL_0ef0;
																																case 39:
																																	goto IL_0efa;
																																case 54:
																																	goto IL_0f08;
																																case 188:
																																	goto IL_0f1b;
																																case 225:
																																	goto IL_0f29;
																																case 37:
																																case 146:
																																	goto IL_0f34;
																																case 103:
																																	goto IL_0f74;
																																case 111:
																																	goto IL_0f88;
																																case 269:
																																	goto IL_0f9b;
																																case 85:
																																	goto IL_0fa9;
																																case 227:
																																case 296:
																																	goto IL_0fb7;
																																case 143:
																																	goto IL_0fd0;
																																case 23:
																																	goto IL_0fde;
																																case 43:
																																	goto IL_0fec;
																																case 168:
																																	goto IL_0fff;
																																case 158:
																																	goto IL_100d;
																																case 114:
																																case 231:
																																	goto IL_1024;
																																case 92:
																																	goto IL_104d;
																																case 275:
																																	goto IL_105b;
																																case 245:
																																case 271:
																																	goto IL_106e;
																																case 45:
																																	goto IL_1081;
																																case 217:
																																	goto IL_108f;
																																case 88:
																																	goto IL_109d;
																																case 254:
																																case 293:
																																	goto IL_10a8;
																																case 215:
																																	goto IL_10b6;
																																case 190:
																																	goto IL_10d2;
																																case 182:
																																case 315:
																																	goto IL_10dd;
																																case 14:
																																	goto IL_113f;
																																case 298:
																																	goto IL_1152;
																																case 307:
																																	goto IL_116b;
																																case 70:
																																case 76:
																																	goto IL_1179;
																																case 80:
																																	goto IL_11b9;
																																case 81:
																																	goto IL_11cd;
																																case 141:
																																case 252:
																																	goto IL_11e0;
																																case 91:
																																	goto IL_11f8;
																																case 57:
																																	goto IL_120f;
																																case 264:
																																	goto IL_121d;
																																case 148:
																																	goto IL_1230;
																																case 3:
																																	goto IL_123e;
																																case 110:
																																case 112:
																																	goto IL_1249;
																																case 197:
																																	goto IL_1273;
																																case 138:
																																	goto IL_1281;
																																case 10:
																																	goto IL_1294;
																																case 185:
																																	goto IL_12a2;
																																case 223:
																																case 311:
																																	goto IL_12b0;
																																case 257:
																																	goto IL_12de;
																																case 309:
																																	goto IL_12f1;
																																case 270:
																																case 274:
																																	goto IL_12fc;
																																case 21:
																																	goto IL_130a;
																																case 8:
																																case 216:
																																	goto IL_1318;
																																case 172:
																																	goto IL_1322;
																																case 313:
																																	goto IL_1330;
																																case 86:
																																	goto IL_1343;
																																case 166:
																																case 169:
																																	goto IL_1351;
																																case 244:
																																	goto IL_135f;
																																case 294:
																																	goto IL_137d;
																																case 129:
																																	goto IL_138b;
																																case 123:
																																case 289:
																																	goto IL_139e;
																																case 184:
																																	goto IL_13b2;
																																case 281:
																																	goto IL_13ff;
																																case 273:
																																	goto IL_140d;
																																case 1:
																																case 2:
																																case 4:
																																case 5:
																																case 7:
																																case 11:
																																case 12:
																																case 15:
																																case 19:
																																case 22:
																																case 26:
																																case 33:
																																case 41:
																																case 47:
																																case 49:
																																case 56:
																																case 66:
																																case 71:
																																case 78:
																																case 89:
																																case 93:
																																case 98:
																																case 100:
																																case 113:
																																case 116:
																																case 119:
																																case 130:
																																case 132:
																																case 134:
																																case 136:
																																case 139:
																																case 151:
																																case 160:
																																case 163:
																																case 179:
																																case 181:
																																case 186:
																																case 195:
																																case 198:
																																case 199:
																																case 207:
																																case 208:
																																case 224:
																																case 228:
																																case 229:
																																case 232:
																																case 235:
																																case 248:
																																case 249:
																																case 260:
																																case 261:
																																case 262:
																																case 276:
																																case 278:
																																case 282:
																																case 285:
																																case 290:
																																case 305:
																																case 310:
																																case 312:
																																case 316:
																																case 320:
																																	goto end_IL_05fa;
																																case 9:
																																case 18:
																																case 24:
																																case 31:
																																case 38:
																																case 42:
																																case 51:
																																case 74:
																																case 99:
																																case 118:
																																case 122:
																																case 126:
																																case 142:
																																case 144:
																																case 145:
																																case 147:
																																case 157:
																																case 162:
																																case 164:
																																case 167:
																																case 170:
																																case 175:
																																case 204:
																																case 209:
																																case 218:
																																case 230:
																																case 234:
																																case 236:
																																case 239:
																																case 253:
																																case 256:
																																case 268:
																																case 291:
																																case 292:
																																case 299:
																																case 314:
																																	goto IL_1430;
																																case 205:
																																	goto IL_1443;
																																case 108:
																																	goto IL_144d;
																																case 96:
																																	goto IL_1458;
																																case 233:
																																	goto IL_1471;
																																case 193:
																																	goto IL_1481;
																																case 84:
																																case 300:
																																	goto IL_1491;
																																case 247:
																																	goto IL_14a1;
																																case 79:
																																case 263:
																																	goto end_IL_0539;
																																case 241:
																																	goto end_IL_14b1;
																																case 242:
																																	goto end_IL_14c1;
																																case 250:
																																case 259:
																																	return;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto IL_1430;
																															continue;
																															end_IL_0539:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0ae9;
																											IL_0c70:
																											ptr2 += 8;
																											goto IL_1430;
																											IL_0ae9:
																											if (19 < b)
																											{
																												goto IL_0af7;
																											}
																											goto IL_0b95;
																											IL_0af7:
																											if (20 < b)
																											{
																												goto end_IL_05fa;
																											}
																											goto IL_0b05;
																											IL_0b05:
																											if (20 > b)
																											{
																												goto end_IL_05fa;
																											}
																											goto IL_0b13;
																											IL_0b13:
																											array[num5 - 2] = 0;
																											goto IL_0b27;
																											IL_0b27:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																											goto IL_0b74;
																											IL_0b74:
																											num5--;
																											goto IL_0b82;
																											IL_0b82:
																											ptr2 += 8;
																											goto IL_1430;
																											IL_0b95:
																											if (19 > b)
																											{
																												goto IL_0ba3;
																											}
																											goto IL_0c24;
																											IL_0ba3:
																											if (18 < b)
																											{
																												goto end_IL_05fa;
																											}
																											goto IL_0bb1;
																											IL_0bb1:
																											if (18 > b)
																											{
																												goto end_IL_05fa;
																											}
																											goto IL_0bbf;
																											IL_0bbf:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0c11;
																											IL_0c11:
																											num5--;
																											goto IL_1430;
																											IL_0c24:
																											array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																											goto IL_0c5c;
																											IL_0c5c:
																											array[num5 - 1] = 5;
																											goto IL_0c70;
																										}
																										break;
																									}
																									goto IL_0635;
																									IL_0726:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																									goto IL_0aa2;
																									IL_0aa2:
																									ptr2 += 8;
																									goto IL_1430;
																									IL_0635:
																									if (23 >= b)
																									{
																										goto IL_0643;
																									}
																									goto IL_06f6;
																									IL_0643:
																									if (23 <= b)
																									{
																										goto IL_0651;
																									}
																									goto IL_06d8;
																									IL_0651:
																									array[num5 - 2] = 0;
																									goto IL_0665;
																									IL_0665:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<Vector3, Vector3, bool>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]) ? 1 : 0);
																									goto IL_06b7;
																									IL_06b7:
																									num5--;
																									goto IL_06c5;
																									IL_06c5:
																									ptr2 += 8;
																									goto IL_1430;
																									IL_06d8:
																									if (22 < b)
																									{
																										goto end_IL_05fa;
																									}
																									goto IL_06e6;
																									IL_06e6:
																									if (22 > b)
																									{
																										goto end_IL_05fa;
																									}
																									goto IL_0763;
																									IL_0763:
																									array[num5] = 4;
																									goto IL_0771;
																									IL_0771:
																									array2[num5] = ((delegate*<Vector3>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])();
																									goto IL_0794;
																									IL_0794:
																									num5++;
																									goto IL_0a8f;
																									IL_0a8f:
																									ptr2 += 8;
																									goto IL_1430;
																									IL_06f6:
																									if (24 < b)
																									{
																										goto end_IL_05fa;
																									}
																									goto IL_0704;
																									IL_0704:
																									if (24 > b)
																									{
																										goto end_IL_05fa;
																									}
																									goto IL_0712;
																									IL_0712:
																									array[num5 - 1] = 5;
																									goto IL_0726;
																								}
																								break;
																							}
																							goto IL_0c83;
																							IL_0cce:
																							ptr2 += 8;
																							goto IL_1430;
																							IL_0c83:
																							((delegate*<Transform, Vector3, void>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																							goto IL_0cc0;
																							IL_0cc0:
																							num5 -= 2;
																							goto IL_0cce;
																						}
																						break;
																					}
																					goto IL_07a7;
																					IL_0a7c:
																					ptr2 += 8;
																					goto IL_1430;
																					IL_07a7:
																					if (29 >= b)
																					{
																						goto IL_07b5;
																					}
																					goto IL_0992;
																					IL_07b5:
																					if (29 > b)
																					{
																						goto IL_07c3;
																					}
																					goto IL_0940;
																					IL_07c3:
																					if (27 >= b)
																					{
																						goto IL_07d1;
																					}
																					goto IL_08c5;
																					IL_07d1:
																					if (27 <= b)
																					{
																						goto IL_07dc;
																					}
																					goto IL_0856;
																					IL_07dc:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_083a;
																					IL_083a:
																					num5--;
																					num = 18;
																					goto IL_1430;
																					IL_0856:
																					if (26 < b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_0864;
																					IL_0864:
																					if (26 > b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_0872;
																					IL_0872:
																					array[num5] = 0;
																					goto IL_0880;
																					IL_0880:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])() ? 1 : 0);
																					goto IL_08a4;
																					IL_08a4:
																					num5++;
																					goto IL_08b2;
																					IL_08b2:
																					ptr2 += 8;
																					goto IL_1430;
																					IL_08c5:
																					if (28 < b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_08d3;
																					IL_08d3:
																					if (28 > b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_08e1;
																					IL_08e1:
																					((delegate*<Behaviour, bool, void>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																					goto IL_091f;
																					IL_091f:
																					num5 -= 2;
																					goto IL_092d;
																					IL_092d:
																					ptr2 += 8;
																					goto IL_1430;
																					IL_0940:
																					array[num5] = 4;
																					goto IL_094e;
																					IL_094e:
																					array2[num5] = ((delegate*<Vector3>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])();
																					goto IL_0971;
																					IL_0971:
																					num5++;
																					goto IL_097f;
																					IL_097f:
																					ptr2 += 8;
																					goto IL_1430;
																					IL_0992:
																					if (31 < b)
																					{
																						goto IL_099d;
																					}
																					goto IL_09d5;
																					IL_099d:
																					if (32 >= b)
																					{
																						goto IL_09ab;
																					}
																					goto IL_0ab5;
																					IL_09ab:
																					if (32 > b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_09b9;
																					IL_09b9:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_1430;
																					IL_0ab5:
																					if (33 < b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_0ac3;
																					IL_0ac3:
																					if (33 > b)
																					{
																					}
																					goto end_IL_05fa;
																					IL_09d5:
																					if (31 > b)
																					{
																						goto IL_09e0;
																					}
																					goto IL_0a3c;
																					IL_09e0:
																					if (30 < b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_09ee;
																					IL_09ee:
																					if (30 > b)
																					{
																						goto end_IL_05fa;
																					}
																					goto IL_09fc;
																					IL_09fc:
																					((Class184)array2[num5 - 2]).vector3_0 = (Vector3)array2[num5 - 1];
																					goto IL_0a29;
																					IL_0a29:
																					num5 -= 2;
																					goto IL_1430;
																					IL_0a3c:
																					((delegate*<Class184, void>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((Class184)array2[num5 - 1]);
																					goto IL_0a65;
																					IL_0a65:
																					num5--;
																					num = 267;
																					goto IL_0a7c;
																				}
																				break;
																			}
																			goto IL_0ce1;
																			IL_137d:
																			num5++;
																			goto IL_138b;
																			IL_0ce1:
																			if (17 > b)
																			{
																				goto IL_0cef;
																			}
																			goto IL_139e;
																			IL_0cef:
																			if (8 >= b)
																			{
																				goto IL_0cfd;
																			}
																			goto IL_1081;
																			IL_0cfd:
																			if (8 > b)
																			{
																				goto IL_0d0b;
																			}
																			goto IL_106e;
																			IL_0d0b:
																			if (4 < b)
																			{
																				goto IL_0d19;
																			}
																			goto IL_0eab;
																			IL_0d19:
																			if (6 < b)
																			{
																				goto IL_0d27;
																			}
																			goto IL_0daa;
																			IL_0d27:
																			if (7 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_0d35;
																			IL_0d35:
																			if (7 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_0d43;
																			IL_0d43:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0d83;
																			IL_0d83:
																			array[num5 - 2] = 0;
																			goto IL_0d97;
																			IL_0d97:
																			num5--;
																			goto IL_1430;
																			IL_0daa:
																			if (6 > b)
																			{
																				goto IL_0db8;
																			}
																			goto IL_0e44;
																			IL_0db8:
																			if (5 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_0dc6;
																			IL_0dc6:
																			if (5 > b)
																			{
																				goto end_IL_05fa;
																			}
																			num = 156;
																			goto IL_0ddd;
																			IL_138b:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_0ddd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0e1d;
																			IL_0e1d:
																			array[num5 - 2] = 0;
																			goto IL_0e31;
																			IL_0e31:
																			num5--;
																			goto IL_1430;
																			IL_0e44:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0e84;
																			IL_0e84:
																			array[num5 - 2] = 0;
																			goto IL_0e98;
																			IL_0e98:
																			num5--;
																			goto IL_1430;
																			IL_0eab:
																			if (4 <= b)
																			{
																				num = 25;
																				goto IL_0ebf;
																			}
																			goto IL_0f1b;
																			IL_139e:
																			array[num5 - 2] = 0;
																			goto IL_13b2;
																			IL_0ebf:
																			array[num5] = 0;
																			goto IL_0ecd;
																			IL_0ecd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0ef0;
																			IL_0ef0:
																			array2[num5] = null;
																			goto IL_0efa;
																			IL_0efa:
																			num5++;
																			goto IL_0f08;
																			IL_0f08:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_0f1b:
																			if (2 >= b)
																			{
																				goto IL_0f29;
																			}
																			goto IL_0fff;
																			IL_0f29:
																			if (2 <= b)
																			{
																				goto IL_0f34;
																			}
																			goto IL_0f9b;
																			IL_0f34:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0f74;
																			IL_0f74:
																			array[num5 - 2] = 0;
																			goto IL_0f88;
																			IL_0f88:
																			num5--;
																			goto IL_1430;
																			IL_0f9b:
																			if (1 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_0fa9;
																			IL_0fa9:
																			if (1 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_0fb7;
																			IL_0fb7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0fd0;
																			IL_0fd0:
																			array[num5] = 0;
																			goto IL_0fde;
																			IL_0fde:
																			num5++;
																			goto IL_0fec;
																			IL_0fec:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_0fff:
																			if (3 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_100d;
																			IL_100d:
																			if (3 > b)
																			{
																				goto end_IL_05fa;
																			}
																			num = 114;
																			goto IL_1024;
																			IL_13b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																			goto IL_13ff;
																			IL_1024:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_104d;
																			IL_104d:
																			ptr2 += 8;
																			goto IL_105b;
																			IL_105b:
																			num5--;
																			goto IL_1430;
																			IL_106e:
																			num5--;
																			goto IL_1430;
																			IL_1081:
																			if (12 >= b)
																			{
																				goto IL_108f;
																			}
																			goto IL_1230;
																			IL_108f:
																			if (12 > b)
																			{
																				goto IL_109d;
																			}
																			goto IL_11e0;
																			IL_109d:
																			if (10 < b)
																			{
																				goto IL_10a8;
																			}
																			goto IL_10d2;
																			IL_10a8:
																			if (11 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_10b6;
																			IL_10b6:
																			if (11 > b)
																			{
																				num = 33;
																				goto end_IL_05fa;
																			}
																			goto IL_1430;
																			IL_13ff:
																			num5--;
																			goto IL_140d;
																			IL_10d2:
																			if (10 <= b)
																			{
																				goto IL_10dd;
																			}
																			goto IL_1152;
																			IL_10dd:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_113f;
																			IL_113f:
																			num5 -= 2;
																			goto IL_1430;
																			IL_1152:
																			if (9 < b)
																			{
																				num = 12;
																				goto end_IL_05fa;
																			}
																			goto IL_116b;
																			IL_140d:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_116b:
																			if (9 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_1179;
																			IL_1179:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_11b9;
																			IL_11b9:
																			array[num5 - 2] = 0;
																			goto IL_11cd;
																			IL_11cd:
																			num5--;
																			goto IL_1430;
																			IL_11e0:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_11f8;
																			IL_11f8:
																			array[num5] = 5;
																			num = 57;
																			goto IL_120f;
																			IL_120f:
																			num5++;
																			goto IL_121d;
																			IL_121d:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_1230:
																			if (14 >= b)
																			{
																				goto IL_123e;
																			}
																			goto IL_12f1;
																			IL_123e:
																			if (14 <= b)
																			{
																				goto IL_1249;
																			}
																			goto IL_1294;
																			IL_1249:
																			((delegate*<bool, void>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																			goto IL_1273;
																			IL_1273:
																			num5--;
																			goto IL_1281;
																			IL_1281:
																			ptr2 += 8;
																			goto IL_1430;
																			IL_1294:
																			if (13 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_12a2;
																			IL_12a2:
																			if (13 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_12b0;
																			IL_12b0:
																			((Class184)array2[num5 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_12de;
																			IL_12de:
																			num5 -= 2;
																			goto IL_1430;
																			IL_12f1:
																			if (15 < b)
																			{
																				goto IL_12fc;
																			}
																			goto IL_1343;
																			IL_12fc:
																			if (16 < b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_130a;
																			IL_130a:
																			if (16 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_1318;
																			IL_1318:
																			array2[num5] = null;
																			goto IL_1322;
																			IL_1322:
																			array[num5] = 5;
																			goto IL_1330;
																			IL_1330:
																			num5++;
																			goto IL_1430;
																			IL_1343:
																			if (15 > b)
																			{
																				goto end_IL_05fa;
																			}
																			goto IL_1351;
																			IL_1351:
																			array[num5] = 5;
																			goto IL_135f;
																			IL_135f:
																			array2[num5] = ((delegate*<GorillaTagger>)StoreLocationMemoryFailPoint[*(int*)(ptr2 + num3)])();
																			goto IL_137d;
																		}
																		goto end_IL_060a;
																		continue;
																		end_IL_05fa:
																		break;
																		IL_05fa:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_1430;
																continue;
																end_IL_060a:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_14b1:
					break;
				}
				continue;
				end_IL_14c1:
				break;
			}
		}
	}

	private static void NativeRegisterStackAssemblyFullName()
	{
		Class9.smethod_20();
	}

	private static bool smethod_1()
	{
		return Class179.IsActive;
	}

	private static VRRig getContextWorkStealingQueue(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	private static int smethod_2(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			return num - num2;
		}
		num = int_1;
		num2 = int_2;
		return num - num2;
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 93;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								IL_0889:
								long[] array4 = new long[3];
								while (true)
								{
									IL_0874:
									array3[0] = int_1;
									while (true)
									{
										IL_0860:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getActivityOptionsC.IsWellKnownEqualityComparerIComparable);
										num = 96;
										while (true)
										{
											IL_0856:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0843:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f2:
														byte b = *ptr2;
														while (true)
														{
															IL_02e2:
															ptr2++;
															while (true)
															{
																IL_02d2:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02b2:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02a5:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0295:
																							if (3 >= b)
																							{
																								num = 79;
																								while (true)
																								{
																									IL_0282:
																									if (3 > b)
																									{
																										num = 145;
																										while (true)
																										{
																											if (num != 145)
																											{
																												if (num != 1126)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 79:
																													goto IL_0282;
																												case 97:
																													goto IL_0295;
																												case 110:
																													goto IL_02a5;
																												case 118:
																													goto IL_02b2;
																												case 108:
																													goto IL_02c2;
																												case 85:
																													goto IL_02d2;
																												case 102:
																													goto IL_02e2;
																												case 35:
																												case 123:
																													goto IL_02f2;
																												case 4:
																													goto IL_02fd;
																												case 13:
																													goto IL_030b;
																												case 39:
																												case 51:
																													goto IL_031e;
																												case 30:
																													goto IL_035e;
																												case 18:
																													goto IL_037b;
																												case 64:
																													goto IL_038e;
																												case 70:
																													goto IL_03aa;
																												case 60:
																													goto IL_03b8;
																												case 11:
																												case 82:
																													goto IL_03cb;
																												case 43:
																													goto IL_03d9;
																												case 66:
																													goto IL_03fc;
																												case 17:
																													goto IL_0406;
																												case 76:
																													goto IL_0414;
																												case 32:
																												case 89:
																													goto IL_0427;
																												case 42:
																													goto IL_0435;
																												case 33:
																												case 58:
																													goto IL_0440;
																												case 81:
																													goto IL_044e;
																												case 107:
																													goto IL_0461;
																												case 109:
																													goto IL_046c;
																												case 100:
																													goto IL_047a;
																												case 22:
																												case 88:
																													goto IL_0488;
																												case 121:
																													goto IL_049b;
																												case 83:
																												case 124:
																													goto IL_04ae;
																												case 131:
																													goto IL_04ca;
																												case 21:
																													goto IL_04d8;
																												case 101:
																													goto IL_04e6;
																												case 56:
																													goto IL_04f1;
																												case 57:
																													goto IL_04ff;
																												case 40:
																												case 112:
																													goto IL_050d;
																												case 106:
																													goto IL_0530;
																												case 73:
																													goto IL_053e;
																												case 111:
																													goto IL_054c;
																												case 27:
																												case 36:
																													goto IL_055f;
																												case 12:
																													goto IL_05c1;
																												case 63:
																												case 103:
																													goto IL_05dd;
																												case 80:
																													goto IL_05fa;
																												case 28:
																													goto IL_0642;
																												case 114:
																												case 136:
																													goto IL_0655;
																												case 54:
																													goto IL_0663;
																												case 24:
																												case 69:
																													goto IL_0671;
																												case 41:
																													goto IL_06b1;
																												case 68:
																													goto IL_06c5;
																												case 119:
																												case 138:
																													goto IL_06d8;
																												case 122:
																													goto IL_0718;
																												case 26:
																													goto IL_072c;
																												case 116:
																													goto IL_073f;
																												case 0:
																												case 31:
																													goto IL_074a;
																												case 52:
																													goto IL_0758;
																												case 16:
																												case 45:
																													goto IL_0766;
																												case 3:
																													goto IL_0798;
																												case 75:
																													goto IL_07a6;
																												case 115:
																													goto IL_07b9;
																												case 65:
																												case 91:
																													goto IL_07c4;
																												case 55:
																													goto IL_07e6;
																												case 59:
																													goto IL_07f4;
																												case 25:
																													goto IL_0802;
																												case 117:
																												case 120:
																													goto IL_0812;
																												case 6:
																												case 7:
																												case 9:
																												case 14:
																												case 20:
																												case 29:
																												case 34:
																												case 37:
																												case 44:
																												case 46:
																												case 47:
																												case 49:
																												case 50:
																												case 53:
																												case 61:
																												case 62:
																												case 67:
																												case 77:
																												case 84:
																												case 87:
																												case 90:
																												case 99:
																												case 104:
																												case 105:
																												case 125:
																												case 128:
																												case 129:
																													goto end_IL_02c2;
																												case 1:
																												case 2:
																												case 8:
																												case 15:
																												case 19:
																												case 23:
																												case 38:
																												case 48:
																												case 71:
																												case 72:
																												case 74:
																												case 78:
																												case 86:
																												case 98:
																												case 113:
																												case 126:
																												case 134:
																													goto IL_0843;
																												case 96:
																													goto IL_0856;
																												case 132:
																													goto IL_0860;
																												case 137:
																													goto IL_0874;
																												case 10:
																													goto IL_0889;
																												case 5:
																												case 130:
																													goto end_IL_026f;
																												case 94:
																													goto end_IL_0899;
																												case 127:
																												case 133:
																													goto end_IL_08a9;
																												case 92:
																													goto end_IL_08b9;
																												case 93:
																													goto end_IL_08c9;
																												case 95:
																												case 135:
																													goto IL_08e4;
																												}
																												continue;
																											}
																											goto IL_073f;
																											IL_07f4:
																											num5++;
																											goto IL_0802;
																											IL_0802:
																											ptr2 += 8;
																											goto IL_0843;
																											IL_073f:
																											if (1 < b)
																											{
																												goto IL_074a;
																											}
																											goto IL_07b9;
																											IL_074a:
																											if (2 < b)
																											{
																												goto end_IL_02c2;
																											}
																											goto IL_0758;
																											IL_0758:
																											if (2 > b)
																											{
																												goto end_IL_02c2;
																											}
																											goto IL_0766;
																											IL_0766:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 3;
																											goto IL_0798;
																											IL_0798:
																											ptr2 += 8;
																											goto IL_07a6;
																											IL_07a6:
																											num5--;
																											goto IL_0843;
																											IL_07b9:
																											if (1 > b)
																											{
																												goto end_IL_02c2;
																											}
																											goto IL_07c4;
																											IL_07c4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 55;
																											goto IL_07e6;
																											IL_07e6:
																											array[num5] = 0;
																											goto IL_07f4;
																											continue;
																											end_IL_026f:
																											break;
																										}
																										break;
																									}
																									goto IL_0812;
																									IL_0812:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0843;
																								}
																								break;
																							}
																							goto IL_02fd;
																							IL_06d8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0718;
																							IL_0718:
																							array[num5 - 2] = 0;
																							goto IL_072c;
																							IL_02fd:
																							if (5 >= b)
																							{
																								goto IL_030b;
																							}
																							goto IL_038e;
																							IL_030b:
																							if (5 > b)
																							{
																								goto IL_03aa;
																							}
																							goto IL_03cb;
																							IL_03cb:
																							array[num5] = 0;
																							goto IL_03d9;
																							IL_03d9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03fc;
																							IL_03fc:
																							array2[num5] = null;
																							goto IL_0406;
																							IL_0406:
																							num5++;
																							goto IL_0414;
																							IL_0414:
																							ptr2 += 8;
																							goto IL_0843;
																							IL_03aa:
																							if (4 < b)
																							{
																								goto end_IL_02c2;
																							}
																							goto IL_03b8;
																							IL_03b8:
																							if (4 > b)
																							{
																								goto end_IL_02c2;
																							}
																							goto IL_0843;
																							IL_038e:
																							if (6 < b)
																							{
																								num = 14;
																								goto end_IL_02c2;
																							}
																							goto IL_049b;
																							IL_072c:
																							num5--;
																							goto IL_0843;
																							IL_049b:
																							if (6 > b)
																							{
																								goto end_IL_02c2;
																							}
																							goto IL_06d8;
																						}
																						break;
																					}
																					goto IL_031e;
																					IL_037b:
																					num5--;
																					goto IL_0843;
																					IL_031e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_035e;
																					IL_035e:
																					array[num5 - 2] = 0;
																					num = 18;
																					goto IL_037b;
																				}
																				break;
																			}
																			goto IL_0427;
																			IL_0642:
																			ptr2 += 8;
																			goto IL_0843;
																			IL_0427:
																			if (11 < b)
																			{
																				goto IL_0435;
																			}
																			goto IL_04ca;
																			IL_0435:
																			if (13 < b)
																			{
																				goto IL_0440;
																			}
																			goto IL_0461;
																			IL_0440:
																			if (14 < b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_044e;
																			IL_044e:
																			if (14 > b)
																			{
																			}
																			goto end_IL_02c2;
																			IL_0461:
																			if (13 > b)
																			{
																				goto IL_046c;
																			}
																			goto IL_04ae;
																			IL_046c:
																			if (12 < b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_047a;
																			IL_047a:
																			if (12 > b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_0488;
																			IL_0488:
																			num5--;
																			goto IL_0843;
																			IL_04ae:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0843;
																			IL_04ca:
																			if (11 > b)
																			{
																				goto IL_04d8;
																			}
																			goto IL_05dd;
																			IL_04d8:
																			if (9 >= b)
																			{
																				goto IL_04e6;
																			}
																			goto IL_0655;
																			IL_04e6:
																			if (9 > b)
																			{
																				goto IL_04f1;
																			}
																			goto IL_055f;
																			IL_04f1:
																			if (8 < b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_04ff;
																			IL_04ff:
																			if (8 > b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_050d;
																			IL_050d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0530;
																			IL_0530:
																			array[num5] = 0;
																			goto IL_053e;
																			IL_053e:
																			num5++;
																			goto IL_054c;
																			IL_054c:
																			ptr2 += 8;
																			goto IL_0843;
																			IL_055f:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05c1;
																			IL_05c1:
																			num5 -= 2;
																			num = 71;
																			goto IL_0843;
																			IL_0655:
																			if (10 < b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_0663;
																			IL_0663:
																			if (10 > b)
																			{
																				goto end_IL_02c2;
																			}
																			goto IL_0671;
																			IL_0671:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06b1;
																			IL_06b1:
																			array[num5 - 2] = 0;
																			goto IL_06c5;
																			IL_06c5:
																			num5--;
																			goto IL_0843;
																			IL_05dd:
																			array[num5 - 1] = 0;
																			num = 80;
																			goto IL_05fa;
																			IL_05fa:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)destinationgetPlatform[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			num = 28;
																			goto IL_0642;
																		}
																		goto end_IL_02d2;
																		continue;
																		end_IL_02c2:
																		break;
																		IL_02c2:;
																	}
																}
																else
																{
																	num = 20;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0843;
																continue;
																end_IL_02d2:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_08e4;
												IL_08e4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_0899:
							break;
						}
						continue;
						end_IL_08a9:
						break;
					}
					continue;
					end_IL_08b9:
					break;
				}
				continue;
				end_IL_08c9:
				break;
			}
		}
	}

	private static Transform RequireParenthesisHMACSHA(Component component_0)
	{
		return component_0.transform;
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 52;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TodayDefaultNameClaimType.NullTypeInfoOnSerializingAttribute);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 78;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_01d0:
																byte b = *ptr2;
																while (true)
																{
																	IL_01c0:
																	ptr2++;
																	while (true)
																	{
																		IL_01b0:
																		if (b >= 1)
																		{
																			goto IL_01db;
																		}
																		num = 96;
																		while (num != 96)
																		{
																			if (num != 1077)
																			{
																				goto end_IL_01b0;
																			}
																			switch (num)
																			{
																			case 57:
																				goto IL_01b0;
																			case 18:
																				goto IL_01c0;
																			case 4:
																			case 53:
																				goto IL_01d0;
																			case 83:
																				goto IL_01db;
																			case 72:
																				goto IL_01e9;
																			case 60:
																				goto IL_01f7;
																			case 3:
																			case 63:
																				goto IL_0205;
																			case 11:
																			case 37:
																				goto IL_0213;
																			case 17:
																				goto IL_0221;
																			case 45:
																			case 87:
																				goto IL_022f;
																			case 85:
																				goto IL_026f;
																			case 69:
																				goto IL_0283;
																			case 16:
																				goto IL_0296;
																			case 22:
																			case 29:
																				goto IL_02a4;
																			case 42:
																				goto IL_0312;
																			case 14:
																				goto IL_0325;
																			case 33:
																				goto IL_0333;
																			case 47:
																			case 88:
																				goto IL_0346;
																			case 12:
																				goto IL_036f;
																			case 49:
																				goto IL_037d;
																			case 44:
																				goto IL_0390;
																			case 1:
																			case 82:
																				goto IL_039e;
																			case 39:
																				goto IL_03a9;
																			case 19:
																			case 31:
																				goto IL_03b7;
																			case 36:
																				goto IL_03c5;
																			case 89:
																				goto IL_03e8;
																			case 70:
																				goto IL_03fb;
																			case 81:
																				goto IL_0409;
																			case 0:
																			case 54:
																				goto IL_0425;
																			case 43:
																				goto IL_0430;
																			case 9:
																			case 64:
																				goto IL_0444;
																			case 13:
																				goto IL_0460;
																			case 35:
																				goto IL_046b;
																			case 20:
																				goto IL_0476;
																			case 23:
																			case 86:
																				goto IL_0481;
																			case 5:
																			case 7:
																			case 15:
																			case 21:
																			case 26:
																			case 32:
																			case 34:
																			case 38:
																			case 65:
																			case 67:
																			case 68:
																			case 71:
																			case 76:
																			case 77:
																			case 79:
																			case 80:
																				goto end_IL_019d;
																			case 59:
																				goto IL_04c4;
																			case 2:
																				goto IL_04d2;
																			case 24:
																				goto IL_04e0;
																			case 10:
																			case 30:
																			case 41:
																			case 46:
																			case 48:
																			case 55:
																			case 56:
																			case 73:
																			case 78:
																			case 84:
																				goto end_IL_01b0;
																			case 62:
																				goto end_IL_04ee;
																			case 40:
																				goto end_IL_0501;
																			case 58:
																				goto end_IL_050c;
																			case 74:
																				goto end_IL_0516;
																			case 61:
																				goto end_IL_0521;
																			case 6:
																				goto end_IL_0536;
																			case 27:
																			case 50:
																				goto end_IL_054b;
																			case 28:
																				goto end_IL_055b;
																			case 8:
																			case 75:
																				goto end_IL_056b;
																			case 51:
																				goto end_IL_057b;
																			case 52:
																				goto end_IL_058b;
																			case 25:
																			case 66:
																				goto IL_05a6;
																			}
																			continue;
																			end_IL_019d:
																			break;
																		}
																		goto IL_04a1;
																		IL_04e0:
																		ptr2 += 8;
																		break;
																		IL_04a1:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04c4;
																		IL_01db:
																		if (b <= 8)
																		{
																			goto IL_01e9;
																		}
																		goto IL_04a1;
																		IL_01e9:
																		if (4 >= b)
																		{
																			goto IL_01f7;
																		}
																		goto IL_0390;
																		IL_01f7:
																		if (4 > b)
																		{
																			goto IL_0205;
																		}
																		goto IL_0346;
																		IL_0205:
																		if (2 < b)
																		{
																			goto IL_0213;
																		}
																		goto IL_0296;
																		IL_0213:
																		if (3 >= b)
																		{
																			goto IL_0221;
																		}
																		goto IL_04a1;
																		IL_0221:
																		if (3 <= b)
																		{
																			goto IL_022f;
																		}
																		goto IL_04a1;
																		IL_022f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_026f;
																		IL_026f:
																		array[num5 - 2] = 0;
																		goto IL_0283;
																		IL_0283:
																		num5--;
																		break;
																		IL_0296:
																		if (2 <= b)
																		{
																			goto IL_02a4;
																		}
																		goto IL_0325;
																		IL_02a4:
																		ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0312;
																		IL_0312:
																		num5 -= 2;
																		break;
																		IL_0325:
																		if (1 >= b)
																		{
																			goto IL_0333;
																		}
																		goto IL_04a1;
																		IL_0333:
																		if (1 <= b)
																		{
																		}
																		goto IL_04a1;
																		IL_0346:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_036f;
																		IL_036f:
																		ptr2 += 8;
																		goto IL_037d;
																		IL_037d:
																		num5--;
																		break;
																		IL_0390:
																		if (6 < b)
																		{
																			goto IL_039e;
																		}
																		goto IL_0460;
																		IL_039e:
																		if (7 >= b)
																		{
																			goto IL_03a9;
																		}
																		num = 54;
																		goto IL_0425;
																		IL_03a9:
																		if (7 <= b)
																		{
																			goto IL_03b7;
																		}
																		goto IL_04a1;
																		IL_03b7:
																		array[num5] = 0;
																		goto IL_03c5;
																		IL_03c5:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_03e8;
																		IL_03e8:
																		array2[num5] = null;
																		num = 70;
																		goto IL_03fb;
																		IL_03fb:
																		num5++;
																		goto IL_0409;
																		IL_0409:
																		ptr2 += 8;
																		break;
																		IL_04c4:
																		array[num5] = 0;
																		goto IL_04d2;
																		IL_0425:
																		if (8 >= b)
																		{
																			goto IL_0430;
																		}
																		goto IL_04a1;
																		IL_0430:
																		if (8 <= b)
																		{
																			num = 9;
																			goto IL_0444;
																		}
																		goto IL_04a1;
																		IL_04d2:
																		num5++;
																		goto IL_04e0;
																		IL_0444:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		break;
																		IL_0460:
																		if (6 <= b)
																		{
																			num = 48;
																			break;
																		}
																		goto IL_046b;
																		IL_046b:
																		if (5 >= b)
																		{
																			goto IL_0476;
																		}
																		goto IL_04a1;
																		IL_0476:
																		if (5 <= b)
																		{
																			goto IL_0481;
																		}
																		goto IL_04a1;
																		IL_0481:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_01b0:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_05a6;
														IL_05a6:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04ee:
														break;
													}
													continue;
													end_IL_0501:
													break;
												}
												continue;
												end_IL_050c:
												break;
											}
											continue;
											end_IL_0516:
											break;
										}
										continue;
										end_IL_0521:
										break;
									}
									continue;
									end_IL_0536:
									break;
								}
								continue;
								end_IL_054b:
								break;
							}
							continue;
							end_IL_055b:
							break;
						}
						continue;
						end_IL_056b:
						break;
					}
					continue;
					end_IL_057b:
					break;
				}
				continue;
				end_IL_058b:
				break;
			}
		}
	}

	private static int setDeformatterAlgorithmCanSkipCSEvaluation(double double_0)
	{
		return Convert.ToInt32(double_0);
	}

	private static int smethod_5(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		int num3;
		if (num <= num2)
		{
			num = int_2;
			num2 = int_1;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_1;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 148;
		num2 = 37;
		int num4 = smethod_2(37, 46);
		num2 = num4;
		return num;
	}

	private static Vector3 setLastWriteTimeUtcGetAllDateTimePatterns(Class184 class184_1)
	{
		return class184_1.vector3_0;
	}

	private static Vector3 ConstructionCallUserInteractive(Vector3 vector3_1, Vector3 vector3_2)
	{
		return vector3_1 - vector3_2;
	}

	private static bool IClientChannelSinkStackgetResourceFallbackCulture(Class184 class184_1)
	{
		return class184_1.bool_3;
	}

	private unsafe void method_1()
	{
		int num = 198;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										num = 51;
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetFilenameUserProfile.ReturnNoArgs);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															num = 178;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0560:
																	if (b >= 1)
																	{
																		while (b <= 33)
																		{
																			while (true)
																			{
																				if (17 >= b)
																				{
																					while (true)
																					{
																						if (17 > b)
																						{
																							while (true)
																							{
																								IL_0520:
																								if (8 < b)
																								{
																									while (true)
																									{
																										IL_0510:
																										if (12 < b)
																										{
																											while (true)
																											{
																												IL_0500:
																												if (14 >= b)
																												{
																													while (true)
																													{
																														IL_04f0:
																														if (14 <= b)
																														{
																															while (true)
																															{
																																IL_04ad:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																																while (true)
																																{
																																	IL_048e:
																																	array[num6 - 2] = 0;
																																	num = 283;
																																	while (true)
																																	{
																																		if (num != 283)
																																		{
																																			if (num != 1264)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 179:
																																				goto IL_048e;
																																			case 168:
																																			case 231:
																																				goto IL_04ad;
																																			case 142:
																																				goto IL_04f0;
																																			case 120:
																																				goto IL_0500;
																																			case 207:
																																				goto IL_0510;
																																			case 256:
																																				goto IL_0520;
																																			case 165:
																																				goto end_IL_0520;
																																			case 11:
																																				goto end_IL_0530;
																																			case 119:
																																				goto end_IL_0540;
																																			case 43:
																																				goto IL_0560;
																																			case 178:
																																				goto end_IL_0560;
																																			case 58:
																																			case 61:
																																				goto end_IL_0570;
																																			case 62:
																																				goto IL_0594;
																																			case 40:
																																				goto IL_05ab;
																																			case 87:
																																				goto IL_05be;
																																			case 126:
																																				goto IL_05ce;
																																			case 159:
																																				goto IL_05d9;
																																			case 141:
																																				goto IL_05e7;
																																			case 67:
																																			case 164:
																																				goto IL_05fa;
																																			case 136:
																																			case 169:
																																				goto IL_060d;
																																			case 5:
																																				goto IL_0626;
																																			case 84:
																																			case 186:
																																				goto IL_0636;
																																			case 145:
																																				goto IL_066e;
																																			case 193:
																																				goto IL_0682;
																																			case 217:
																																				goto IL_0695;
																																			case 224:
																																				goto IL_06a8;
																																			case 190:
																																				goto IL_06b6;
																																			case 213:
																																				goto IL_06c4;
																																			case 110:
																																			case 181:
																																				goto IL_06d2;
																																			case 184:
																																				goto IL_0712;
																																			case 17:
																																				goto IL_0726;
																																			case 230:
																																				goto IL_0739;
																																			case 246:
																																				goto IL_074c;
																																			case 37:
																																				goto IL_075a;
																																			case 7:
																																				goto IL_0765;
																																			case 38:
																																			case 171:
																																				goto IL_0773;
																																			case 65:
																																				goto IL_07b3;
																																			case 214:
																																				goto IL_07c7;
																																			case 104:
																																				goto IL_07da;
																																			case 14:
																																				goto IL_07e8;
																																			case 9:
																																			case 160:
																																				goto IL_0804;
																																			case 29:
																																				goto IL_0812;
																																			case 216:
																																				goto IL_0835;
																																			case 8:
																																				goto IL_083f;
																																			case 200:
																																				goto IL_084d;
																																			case 249:
																																				goto IL_0860;
																																			case 147:
																																				goto IL_086e;
																																			case 80:
																																			case 157:
																																				goto IL_087c;
																																			case 112:
																																				goto IL_08bc;
																																			case 194:
																																			case 252:
																																				goto IL_08d5;
																																			case 102:
																																				goto IL_08fe;
																																			case 55:
																																				goto IL_090c;
																																			case 253:
																																				goto IL_091f;
																																			case 173:
																																				goto IL_092a;
																																			case 167:
																																				goto IL_093d;
																																			case 114:
																																				goto IL_094b;
																																			case 257:
																																				goto IL_095e;
																																			case 189:
																																				goto IL_096c;
																																			case 2:
																																				goto IL_097a;
																																			case 77:
																																				goto IL_0988;
																																			case 236:
																																			case 245:
																																				goto IL_0996;
																																			case 106:
																																				goto IL_09d6;
																																			case 24:
																																				goto IL_09ea;
																																			case 118:
																																			case 243:
																																				goto IL_09fd;
																																			case 151:
																																				goto IL_0a64;
																																			case 10:
																																				goto IL_0a72;
																																			case 192:
																																			case 260:
																																				goto IL_0a85;
																																			case 204:
																																			case 262:
																																				goto IL_0a9d;
																																			case 170:
																																				goto IL_0add;
																																			case 241:
																																				goto IL_0af1;
																																			case 22:
																																			case 266:
																																				goto IL_0b04;
																																			case 180:
																																				goto IL_0b1c;
																																			case 255:
																																				goto IL_0b2a;
																																			case 162:
																																				goto IL_0b38;
																																			case 268:
																																				goto IL_0b4b;
																																			case 30:
																																				goto IL_0b59;
																																			case 122:
																																			case 210:
																																				goto IL_0b70;
																																			case 199:
																																				goto IL_0b89;
																																			case 4:
																																				goto IL_0b97;
																																			case 269:
																																				goto end_IL_047b;
																																			case 176:
																																			case 270:
																																				goto IL_0bba;
																																			case 3:
																																				goto IL_0c0c;
																																			case 271:
																																				goto IL_0c1f;
																																			case 274:
																																				goto IL_0c32;
																																			case 206:
																																				goto IL_0c61;
																																			case 227:
																																				goto IL_0c6f;
																																			case 123:
																																			case 158:
																																				goto IL_0c7a;
																																			case 54:
																																				goto IL_0cba;
																																			case 134:
																																				goto IL_0cce;
																																			case 222:
																																				goto IL_0cea;
																																			case 232:
																																				goto IL_0cf8;
																																			case 18:
																																			case 116:
																																				goto IL_0d03;
																																			case 99:
																																				goto IL_0d43;
																																			case 265:
																																				goto IL_0d57;
																																			case 101:
																																				goto IL_0d6a;
																																			case 89:
																																				goto IL_0d75;
																																			case 212:
																																				goto IL_0d83;
																																			case 33:
																																			case 163:
																																				goto IL_0d91;
																																			case 91:
																																				goto IL_0daa;
																																			case 273:
																																				goto IL_0db8;
																																			case 149:
																																				goto IL_0dc6;
																																			case 221:
																																				goto IL_0deb;
																																			case 27:
																																			case 108:
																																				goto IL_0df9;
																																			case 247:
																																				goto IL_0e0d;
																																			case 25:
																																				goto IL_0e5a;
																																			case 70:
																																				goto IL_0e68;
																																			case 1:
																																				goto IL_0e7b;
																																			case 64:
																																				goto IL_0e89;
																																			case 143:
																																			case 228:
																																				goto IL_0ea0;
																																			case 177:
																																				goto IL_0eaa;
																																			case 46:
																																				goto IL_0eb8;
																																			case 95:
																																				goto IL_0ecb;
																																			case 196:
																																				goto IL_0ed9;
																																			case 128:
																																			case 161:
																																				goto IL_0ee4;
																																			case 44:
																																				goto IL_0f0c;
																																			case 121:
																																				goto IL_0f28;
																																			case 229:
																																				goto IL_0f36;
																																			case 35:
																																			case 47:
																																				goto IL_0f44;
																																			case 208:
																																				goto IL_0f58;
																																			case 32:
																																				goto IL_0f97;
																																			case 215:
																																				goto IL_0faa;
																																			case 26:
																																				goto IL_0fb8;
																																			case 244:
																																			case 275:
																																				goto IL_0fc6;
																																			case 78:
																																				goto IL_0fda;
																																			case 109:
																																				goto IL_1019;
																																			case 240:
																																				goto IL_102c;
																																			case 225:
																																				goto IL_103a;
																																			case 94:
																																			case 209:
																																				goto IL_1045;
																																			case 50:
																																				goto IL_1085;
																																			case 117:
																																				goto IL_1099;
																																			case 251:
																																				goto IL_10ac;
																																			case 31:
																																				goto IL_10ba;
																																			case 6:
																																			case 23:
																																				goto IL_10c5;
																																			case 156:
																																				goto IL_10d9;
																																			case 148:
																																				goto IL_1118;
																																			case 21:
																																				goto IL_112b;
																																			case 226:
																																				goto IL_1139;
																																			case 16:
																																			case 66:
																																				goto IL_1147;
																																			case 93:
																																				goto IL_117f;
																																			case 135:
																																				goto IL_1193;
																																			case 254:
																																				goto IL_11a6;
																																			case 90:
																																				goto IL_11bd;
																																			case 127:
																																			case 175:
																																				goto IL_11cb;
																																			case 218:
																																				goto IL_11f4;
																																			case 183:
																																				goto IL_1202;
																																			case 100:
																																				goto IL_1215;
																																			case 13:
																																				goto IL_1220;
																																			case 49:
																																				goto IL_122b;
																																			case 107:
																																			case 195:
																																				goto IL_1239;
																																			case 60:
																																				goto IL_1255;
																																			case 69:
																																				goto IL_1263;
																																			case 72:
																																				goto IL_127f;
																																			case 187:
																																			case 233:
																																				goto IL_128a;
																																			case 48:
																																				goto IL_12b2;
																																			case 242:
																																				goto IL_12c5;
																																			case 103:
																																				goto IL_12d0;
																																			case 97:
																																			case 250:
																																				goto IL_12db;
																																			case 238:
																																				goto IL_131b;
																																			case 185:
																																				goto IL_132f;
																																			case 0:
																																			case 20:
																																			case 34:
																																			case 41:
																																			case 52:
																																			case 56:
																																			case 73:
																																			case 75:
																																			case 82:
																																			case 86:
																																			case 88:
																																			case 96:
																																			case 105:
																																			case 115:
																																			case 124:
																																			case 129:
																																			case 132:
																																			case 138:
																																			case 144:
																																			case 146:
																																			case 152:
																																			case 154:
																																			case 174:
																																			case 182:
																																			case 201:
																																			case 202:
																																			case 205:
																																			case 234:
																																			case 237:
																																			case 239:
																																			case 258:
																																			case 259:
																																			case 261:
																																			case 263:
																																			case 264:
																																			case 276:
																																				goto end_IL_0550;
																																			case 28:
																																			case 36:
																																			case 39:
																																			case 42:
																																			case 45:
																																			case 53:
																																			case 57:
																																			case 63:
																																			case 71:
																																			case 74:
																																			case 76:
																																			case 79:
																																			case 81:
																																			case 83:
																																			case 92:
																																			case 111:
																																			case 125:
																																			case 130:
																																			case 133:
																																			case 137:
																																			case 139:
																																			case 140:
																																			case 150:
																																			case 153:
																																			case 155:
																																			case 166:
																																			case 172:
																																			case 188:
																																			case 191:
																																			case 203:
																																			case 211:
																																			case 219:
																																			case 220:
																																			case 223:
																																			case 235:
																																			case 272:
																																				goto end_IL_0580;
																																			case 12:
																																				goto end_IL_1352;
																																			case 98:
																																				goto end_IL_1365;
																																			case 51:
																																				goto end_IL_136f;
																																			case 85:
																																				goto end_IL_137a;
																																			case 15:
																																				goto end_IL_138a;
																																			case 68:
																																			case 248:
																																				goto end_IL_13a3;
																																			case 19:
																																				goto end_IL_13b3;
																																			case 267:
																																				goto end_IL_13c3;
																																			case 59:
																																				goto end_IL_13d3;
																																			case 197:
																																				goto end_IL_13e3;
																																			case 198:
																																				goto end_IL_13f3;
																																			case 113:
																																			case 131:
																																				return;
																																			}
																																			continue;
																																		}
																																		num6--;
																																		num = 28;
																																		goto end_IL_0580;
																																		continue;
																																		end_IL_047b:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0594;
																														IL_05ab:
																														if (13 > b)
																														{
																															goto end_IL_0550;
																														}
																														goto IL_0a85;
																														IL_0594:
																														if (13 < b)
																														{
																															goto end_IL_0550;
																														}
																														num = 40;
																														goto IL_05ab;
																														IL_0a85:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														goto end_IL_0580;
																													}
																													break;
																												}
																												goto IL_091f;
																												IL_0b38:
																												ptr2 += 8;
																												goto end_IL_0580;
																												IL_091f:
																												if (15 >= b)
																												{
																													goto IL_092a;
																												}
																												goto IL_093d;
																												IL_092a:
																												if (15 > b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_0bba;
																												IL_0bba:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0c0c;
																												IL_0c0c:
																												num6--;
																												goto end_IL_0580;
																												IL_093d:
																												if (16 < b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_094b;
																												IL_094b:
																												if (16 > b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_0b04;
																												IL_0b04:
																												array2[num6] = array5[*(int*)(ptr2 + num3)];
																												goto IL_0b1c;
																												IL_0b1c:
																												array[num6] = 5;
																												goto IL_0b2a;
																												IL_0b2a:
																												num6++;
																												goto IL_0b38;
																											}
																											break;
																										}
																										goto IL_05be;
																										IL_0a72:
																										if (11 > b)
																										{
																											goto end_IL_0550;
																										}
																										goto end_IL_0580;
																										IL_05be:
																										if (12 <= b)
																										{
																											goto IL_060d;
																										}
																										goto IL_095e;
																										IL_060d:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0626;
																										IL_0626:
																										array[num6] = 1;
																										goto IL_0695;
																										IL_0695:
																										num6++;
																										goto IL_0739;
																										IL_0739:
																										ptr2 += 16;
																										goto end_IL_0580;
																										IL_095e:
																										if (10 >= b)
																										{
																											goto IL_096c;
																										}
																										goto IL_0a64;
																										IL_096c:
																										if (10 > b)
																										{
																											goto IL_097a;
																										}
																										goto IL_09fd;
																										IL_097a:
																										if (9 < b)
																										{
																											goto end_IL_0550;
																										}
																										goto IL_0988;
																										IL_0988:
																										if (9 > b)
																										{
																											goto end_IL_0550;
																										}
																										goto IL_0996;
																										IL_0996:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_09d6;
																										IL_09d6:
																										array[num6 - 2] = 0;
																										goto IL_09ea;
																										IL_09ea:
																										num6--;
																										goto end_IL_0580;
																										IL_09fd:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0c32;
																										IL_0c32:
																										num6 -= 2;
																										goto end_IL_0580;
																										IL_0a64:
																										if (11 < b)
																										{
																											goto end_IL_0550;
																										}
																										goto IL_0a72;
																									}
																									goto IL_0ba7;
																								}
																								goto IL_05ce;
																								IL_083f:
																								num6++;
																								goto IL_084d;
																								IL_05ce:
																								if (8 > b)
																								{
																									goto IL_05d9;
																								}
																								goto IL_05fa;
																								IL_05d9:
																								if (4 < b)
																								{
																									goto IL_05e7;
																								}
																								goto IL_074c;
																								IL_05e7:
																								if (6 >= b)
																								{
																									goto IL_06a8;
																								}
																								goto IL_0860;
																								IL_06a8:
																								if (6 > b)
																								{
																									goto IL_06b6;
																								}
																								goto IL_0a9d;
																								IL_06b6:
																								if (5 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_06c4;
																								IL_06c4:
																								if (5 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_06d2;
																								IL_06d2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0712;
																								IL_0712:
																								array[num6 - 2] = 0;
																								goto IL_0726;
																								IL_0726:
																								num6--;
																								goto end_IL_0580;
																								IL_0a9d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0add;
																								IL_0add:
																								array[num6 - 2] = 0;
																								goto IL_0af1;
																								IL_0af1:
																								num6--;
																								goto end_IL_0580;
																								IL_0860:
																								if (7 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_086e;
																								IL_086e:
																								if (7 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_087c;
																								IL_087c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_08bc;
																								IL_08bc:
																								array[num6 - 2] = 0;
																								goto IL_0ba7;
																								IL_0ba7:
																								num6--;
																								goto end_IL_0580;
																								IL_074c:
																								if (4 > b)
																								{
																									goto IL_075a;
																								}
																								num = 160;
																								goto IL_0804;
																								IL_075a:
																								if (2 >= b)
																								{
																									goto IL_0765;
																								}
																								goto IL_07da;
																								IL_0765:
																								if (2 <= b)
																								{
																									goto IL_0773;
																								}
																								goto IL_0b4b;
																								IL_0773:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_07b3;
																								IL_07b3:
																								array[num6 - 2] = 0;
																								goto IL_07c7;
																								IL_07c7:
																								num6--;
																								goto end_IL_0580;
																								IL_0b4b:
																								if (1 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_0b59;
																								IL_0b59:
																								if (1 > b)
																								{
																									goto end_IL_0550;
																								}
																								num = 122;
																								goto IL_0b70;
																								IL_05fa:
																								num6--;
																								goto end_IL_0580;
																								IL_0b70:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0b89;
																								IL_0b89:
																								array[num6] = 0;
																								goto IL_0b97;
																								IL_0b97:
																								num6++;
																								goto IL_0c1f;
																								IL_0c1f:
																								ptr2 += 8;
																								goto end_IL_0580;
																								IL_07da:
																								if (3 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_07e8;
																								IL_07e8:
																								if (3 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_08d5;
																								IL_08d5:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_08fe;
																								IL_08fe:
																								ptr2 += 8;
																								goto IL_090c;
																								IL_090c:
																								num6--;
																								goto end_IL_0580;
																								IL_084d:
																								ptr2 += 8;
																								goto end_IL_0580;
																								IL_0804:
																								array[num6] = 0;
																								goto IL_0812;
																								IL_0812:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0835;
																								IL_0835:
																								array2[num6] = null;
																								goto IL_083f;
																								continue;
																								end_IL_0520:
																								break;
																							}
																							continue;
																						}
																						goto IL_0636;
																						IL_0682:
																						ptr2 += 8;
																						goto end_IL_0580;
																						IL_0636:
																						array2[num6 - 1] = ((delegate*<Class184, GameObject>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																						goto IL_066e;
																						IL_066e:
																						array[num6 - 1] = 5;
																						goto IL_0682;
																						continue;
																						end_IL_0530:
																						break;
																					}
																					continue;
																				}
																				goto IL_0c61;
																				IL_12c5:
																				if (30 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_12d0;
																				IL_0c61:
																				if (25 >= b)
																				{
																					goto IL_0c6f;
																				}
																				goto IL_102c;
																				IL_0c6f:
																				if (25 <= b)
																				{
																					goto IL_0c7a;
																				}
																				goto IL_0cea;
																				IL_0c7a:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0cba;
																				IL_0cba:
																				array[num6 - 2] = 3;
																				goto IL_0cce;
																				IL_0cce:
																				num6--;
																				num = 140;
																				goto end_IL_0580;
																				IL_0cea:
																				if (21 >= b)
																				{
																					goto IL_0cf8;
																				}
																				goto IL_0ecb;
																				IL_0cf8:
																				if (21 <= b)
																				{
																					goto IL_0d03;
																				}
																				goto IL_0d6a;
																				IL_0d03:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0d43;
																				IL_0d43:
																				array[num6 - 2] = 3;
																				goto IL_0d57;
																				IL_0d57:
																				num6--;
																				goto end_IL_0580;
																				IL_0d6a:
																				if (19 < b)
																				{
																					goto IL_0d75;
																				}
																				num = 221;
																				goto IL_0deb;
																				IL_0d75:
																				if (20 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0d83;
																				IL_0d83:
																				if (20 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0d91;
																				IL_0d91:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_0daa;
																				IL_0daa:
																				array[num6] = 3;
																				goto IL_0db8;
																				IL_0db8:
																				num6++;
																				goto IL_0dc6;
																				IL_0dc6:
																				ptr2 += 16;
																				num = 71;
																				goto end_IL_0580;
																				IL_12d0:
																				if (30 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_12db;
																				IL_0deb:
																				if (19 <= b)
																				{
																					goto IL_0df9;
																				}
																				goto IL_0e7b;
																				IL_0df9:
																				array[num6 - 2] = 0;
																				goto IL_0e0d;
																				IL_0e0d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_0e5a;
																				IL_0e5a:
																				num6--;
																				goto IL_0e68;
																				IL_0e68:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_0e7b:
																				if (18 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0e89;
																				IL_0e89:
																				if (18 > b)
																				{
																					goto end_IL_0550;
																				}
																				num = 143;
																				goto IL_0ea0;
																				IL_12db:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_131b;
																				IL_0ea0:
																				array2[num6] = null;
																				goto IL_0eaa;
																				IL_0eaa:
																				array[num6] = 5;
																				goto IL_0eb8;
																				IL_0eb8:
																				num6++;
																				goto end_IL_0580;
																				IL_0ecb:
																				if (23 >= b)
																				{
																					goto IL_0ed9;
																				}
																				goto IL_0faa;
																				IL_0ed9:
																				if (23 <= b)
																				{
																					goto IL_0ee4;
																				}
																				goto IL_0f28;
																				IL_0ee4:
																				((Class184)array2[num6 - 2]).gameObject_0 = (GameObject)array2[num6 - 1];
																				goto IL_0f0c;
																				IL_0f0c:
																				num6 -= 2;
																				num = 166;
																				goto end_IL_0580;
																				IL_0f28:
																				if (22 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0f36;
																				IL_0f36:
																				if (22 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0f44;
																				IL_0f44:
																				array[num6 - 1] = 0;
																				goto IL_0f58;
																				IL_0f58:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0f97;
																				IL_0f97:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_0faa:
																				if (24 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0fb8;
																				IL_0fb8:
																				if (24 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_0fc6;
																				IL_0fc6:
																				array[num6 - 1] = 3;
																				goto IL_0fda;
																				IL_0fda:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1019;
																				IL_1019:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_102c:
																				if (29 >= b)
																				{
																					goto IL_103a;
																				}
																				goto IL_1215;
																				IL_103a:
																				if (29 <= b)
																				{
																					goto IL_1045;
																				}
																				goto IL_10ac;
																				IL_1045:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1085;
																				IL_1085:
																				array[num6 - 2] = 3;
																				goto IL_1099;
																				IL_1099:
																				num6--;
																				goto end_IL_0580;
																				IL_10ac:
																				if (27 >= b)
																				{
																					goto IL_10ba;
																				}
																				goto IL_11a6;
																				IL_10ba:
																				if (27 <= b)
																				{
																					goto IL_10c5;
																				}
																				goto IL_112b;
																				IL_10c5:
																				array[num6 - 1] = 3;
																				goto IL_10d9;
																				IL_10d9:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1118;
																				IL_1118:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_112b:
																				if (26 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_1139;
																				IL_1139:
																				if (26 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_1147;
																				IL_1147:
																				array2[num6 - 1] = ((delegate*<Class184, GameObject>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																				goto IL_117f;
																				IL_117f:
																				array[num6 - 1] = 5;
																				goto IL_1193;
																				IL_1193:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_11a6:
																				if (28 < b)
																				{
																					goto end_IL_0550;
																				}
																				num = 90;
																				goto IL_11bd;
																				IL_131b:
																				array[num6 - 2] = 3;
																				goto IL_132f;
																				IL_11bd:
																				if (28 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_11cb;
																				IL_11cb:
																				((delegate*<UnityEngine.Object, void>)UtcTicksCalendarHijri[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																				goto IL_11f4;
																				IL_11f4:
																				num6--;
																				goto IL_1202;
																				IL_1202:
																				ptr2 += 8;
																				goto end_IL_0580;
																				IL_1215:
																				if (31 < b)
																				{
																					goto IL_1220;
																				}
																				num = 72;
																				goto IL_127f;
																				IL_1220:
																				if (32 >= b)
																				{
																					goto IL_122b;
																				}
																				goto IL_1255;
																				IL_122b:
																				if (32 > b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_1239;
																				IL_1239:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0580;
																				IL_1255:
																				if (33 < b)
																				{
																					goto end_IL_0550;
																				}
																				goto IL_1263;
																				IL_1263:
																				if (33 > b)
																				{
																				}
																				goto end_IL_0550;
																				IL_132f:
																				num6--;
																				goto end_IL_0580;
																				IL_127f:
																				if (31 <= b)
																				{
																					goto IL_128a;
																				}
																				goto IL_12c5;
																				IL_128a:
																				((Class184)array2[num6 - 2]).gameObject_1 = (GameObject)array2[num6 - 1];
																				goto IL_12b2;
																				IL_12b2:
																				num6 -= 2;
																				goto end_IL_0580;
																				continue;
																				end_IL_0540:
																				break;
																			}
																			continue;
																			end_IL_0550:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0580;
																	continue;
																	end_IL_0560:
																	break;
																}
																continue;
																end_IL_0570:
																break;
															}
															continue;
															end_IL_0580:
															break;
														}
														continue;
														end_IL_1352:
														break;
													}
													continue;
													end_IL_1365:
													break;
												}
												continue;
												end_IL_136f:
												break;
											}
											continue;
											end_IL_137a:
											break;
										}
										continue;
										end_IL_138a:
										break;
									}
									continue;
									end_IL_13a3:
									break;
								}
								continue;
								end_IL_13b3:
								break;
							}
							continue;
							end_IL_13c3:
							break;
						}
						continue;
						end_IL_13d3:
						break;
					}
					continue;
					end_IL_13e3:
					break;
				}
				continue;
				end_IL_13f3:
				break;
			}
		}
	}

	private static float FindLastgetTypeName(Class184 class184_1)
	{
		return class184_1.float_0;
	}

	private static Vector3 getUniversalSortableDateTimePatternGetFunctionPointerForDelegate()
	{
		return Vector3.zero;
	}

	private static GorillaTagger getNumberLockEnableActivateAsActivator()
	{
		return GorillaTagger.Instance;
	}

	private static double IWellKnownStringEqualityComparerGetPointArray(double double_0)
	{
		return Math.Log(double_0);
	}

	private static object PersistKeySetGetResult(float float_2, float float_3, float float_4)
	{
		return new Vector3(float_2, float_3, float_4);
	}

	private static Vector3 getProgIdRaiseDeserializationEvent(Transform transform_0)
	{
		return transform_0.position;
	}

	private unsafe void method_2()
	{
		int num = 173;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 6;
								while (true)
								{
									long[] array4 = new long[3];
									num = 132;
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getThreadContextChangedCommonNumberSeparator.FUNCSTATICVTHRESULT);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0728:
																	if (b >= 1)
																	{
																		while (b <= 47)
																		{
																			while (true)
																			{
																				IL_0708:
																				if (24 < b)
																				{
																					while (true)
																					{
																						IL_06f8:
																						if (36 >= b)
																						{
																							while (true)
																							{
																								IL_06e8:
																								if (36 > b)
																								{
																									while (true)
																									{
																										IL_06d8:
																										if (30 < b)
																										{
																											while (true)
																											{
																												IL_06c8:
																												if (33 < b)
																												{
																													while (true)
																													{
																														IL_06b8:
																														if (34 < b)
																														{
																															while (35 >= b)
																															{
																																num = 114;
																																while (35 <= b)
																																{
																																	while (true)
																																	{
																																		IL_0689:
																																		array2[num6] = null;
																																		while (true)
																																		{
																																			IL_0670:
																																			array[num6] = 5;
																																			num = 400;
																																			while (true)
																																			{
																																				if (num != 400)
																																				{
																																					if (num != 1381)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 33:
																																						goto IL_0670;
																																					case 161:
																																					case 167:
																																						goto IL_0689;
																																					case 114:
																																						goto end_IL_065d;
																																					case 39:
																																						goto IL_06a5;
																																					case 84:
																																						goto IL_06b8;
																																					case 323:
																																						goto IL_06c8;
																																					case 262:
																																						goto IL_06d8;
																																					case 196:
																																						goto IL_06e8;
																																					case 107:
																																						goto IL_06f8;
																																					case 49:
																																						goto IL_0708;
																																					case 309:
																																						goto IL_0718;
																																					case 299:
																																						goto IL_0728;
																																					case 198:
																																						goto end_IL_0728;
																																					case 12:
																																					case 221:
																																						goto end_IL_0738;
																																					case 148:
																																						goto IL_0753;
																																					case 36:
																																					case 38:
																																						goto IL_076a;
																																					case 175:
																																						goto IL_07b1;
																																					case 24:
																																						goto IL_07bf;
																																					case 351:
																																						goto IL_07d2;
																																					case 57:
																																						goto IL_07e0;
																																					case 261:
																																						goto IL_07ee;
																																					case 112:
																																						goto IL_07fc;
																																					case 75:
																																						goto IL_0807;
																																					case 259:
																																					case 285:
																																						goto IL_0815;
																																					case 325:
																																						goto IL_0829;
																																					case 293:
																																						goto IL_0868;
																																					case 22:
																																						goto IL_087b;
																																					case 200:
																																						goto IL_0889;
																																					case 170:
																																					case 315:
																																						goto IL_0897;
																																					case 18:
																																						goto IL_08a5;
																																					case 338:
																																						goto IL_08c3;
																																					case 206:
																																					case 354:
																																						goto IL_08d6;
																																					case 131:
																																						goto IL_0913;
																																					case 251:
																																						goto IL_0921;
																																					case 87:
																																					case 379:
																																						goto IL_0934;
																																					case 81:
																																						goto IL_096c;
																																					case 29:
																																						goto IL_0980;
																																					case 380:
																																						goto IL_0993;
																																					case 158:
																																						goto IL_099e;
																																					case 44:
																																					case 270:
																																						goto IL_09ac;
																																					case 23:
																																						goto IL_09c0;
																																					case 367:
																																						goto IL_09f8;
																																					case 277:
																																						goto IL_0a0b;
																																					case 239:
																																						goto IL_0a22;
																																					case 46:
																																					case 374:
																																						goto IL_0a30;
																																					case 260:
																																						goto IL_0a6d;
																																					case 229:
																																						goto IL_0a81;
																																					case 384:
																																						goto IL_0a94;
																																					case 98:
																																						goto IL_0ac3;
																																					case 245:
																																					case 307:
																																						goto IL_0ace;
																																					case 45:
																																						goto IL_0af8;
																																					case 375:
																																						goto IL_0b06;
																																					case 347:
																																						goto IL_0b19;
																																					case 126:
																																						goto IL_0b27;
																																					case 13:
																																					case 130:
																																						goto IL_0b3e;
																																					case 7:
																																						goto IL_0b52;
																																					case 52:
																																						goto IL_0b91;
																																					case 104:
																																						goto IL_0bad;
																																					case 121:
																																						goto IL_0bbb;
																																					case 310:
																																					case 357:
																																						goto IL_0bc9;
																																					case 60:
																																						goto IL_0c09;
																																					case 199:
																																						goto IL_0c1d;
																																					case 156:
																																					case 253:
																																						goto IL_0c30;
																																					case 124:
																																						goto IL_0c44;
																																					case 142:
																																						goto IL_0c91;
																																					case 93:
																																						goto IL_0c9f;
																																					case 79:
																																						goto IL_0cb2;
																																					case 178:
																																						goto IL_0cc0;
																																					case 9:
																																					case 295:
																																						goto IL_0ccb;
																																					case 368:
																																						goto IL_0cf9;
																																					case 88:
																																						goto IL_0d0c;
																																					case 241:
																																						goto IL_0d1a;
																																					case 59:
																																						goto IL_0d28;
																																					case 305:
																																					case 364:
																																						goto IL_0d36;
																																					case 127:
																																						goto IL_0d4a;
																																					case 336:
																																						goto IL_0d97;
																																					case 68:
																																						goto IL_0da5;
																																					case 188:
																																						goto IL_0db8;
																																					case 362:
																																						goto IL_0dc6;
																																					case 176:
																																					case 376:
																																						goto IL_0dd4;
																																					case 180:
																																						goto IL_0de8;
																																					case 110:
																																						goto IL_0e27;
																																					case 50:
																																						goto IL_0e43;
																																					case 116:
																																					case 183:
																																						goto IL_0e51;
																																					case 232:
																																						goto IL_0e65;
																																					case 218:
																																						goto IL_0eb7;
																																					case 353:
																																						goto IL_0ec5;
																																					case 267:
																																						goto IL_0ed8;
																																					case 215:
																																						goto IL_0ee3;
																																					case 2:
																																					case 209:
																																						goto IL_0ef1;
																																					case 248:
																																						goto IL_0f1c;
																																					case 340:
																																						goto IL_0f35;
																																					case 140:
																																						goto IL_0f43;
																																					case 141:
																																					case 318:
																																						goto IL_0f51;
																																					case 139:
																																						goto IL_0f5f;
																																					case 11:
																																						goto IL_0f82;
																																					case 83:
																																						goto IL_0f90;
																																					case 80:
																																						goto IL_0fa3;
																																					case 118:
																																						goto IL_0fb1;
																																					case 70:
																																					case 283:
																																						goto IL_0fbc;
																																					case 311:
																																						goto IL_0fd0;
																																					case 102:
																																						goto IL_100f;
																																					case 297:
																																						goto IL_1022;
																																					case 197:
																																						goto IL_102d;
																																					case 65:
																																					case 189:
																																						goto IL_1044;
																																					case 332:
																																						goto IL_1052;
																																					case 392:
																																						goto IL_1075;
																																					case 149:
																																						goto IL_1083;
																																					case 64:
																																						goto IL_1096;
																																					case 177:
																																						goto IL_10a4;
																																					case 128:
																																					case 202:
																																						goto IL_10b2;
																																					case 210:
																																						goto IL_10df;
																																					case 280:
																																						goto IL_10f2;
																																					case 138:
																																						goto IL_10fd;
																																					case 266:
																																					case 287:
																																						goto IL_110b;
																																					case 304:
																																						goto IL_1127;
																																					case 331:
																																						goto IL_1135;
																																					case 187:
																																						goto IL_1151;
																																					case 344:
																																					case 391:
																																						goto IL_115c;
																																					case 393:
																																						goto IL_1185;
																																					case 106:
																																						goto IL_1193;
																																					case 348:
																																						goto IL_11a6;
																																					case 327:
																																						goto IL_11b4;
																																					case 217:
																																						goto IL_11c2;
																																					case 233:
																																						goto IL_11d0;
																																					case 335:
																																						goto IL_11de;
																																					case 14:
																																						goto IL_11ec;
																																					case 143:
																																					case 330:
																																						goto IL_11f7;
																																					case 321:
																																						goto IL_1220;
																																					case 296:
																																						goto IL_122e;
																																					case 43:
																																						goto IL_1241;
																																					case 231:
																																						goto IL_124c;
																																					case 62:
																																					case 203:
																																						goto IL_125a;
																																					case 179:
																																						goto IL_1273;
																																					case 51:
																																						goto IL_1281;
																																					case 28:
																																						goto IL_128f;
																																					case 290:
																																						goto IL_12a2;
																																					case 208:
																																						goto IL_12b0;
																																					case 355:
																																					case 389:
																																						goto IL_12be;
																																					case 313:
																																						goto IL_12fe;
																																					case 164:
																																						goto IL_1312;
																																					case 388:
																																						goto IL_1325;
																																					case 32:
																																						goto IL_1330;
																																					case 16:
																																					case 372:
																																						goto IL_133e;
																																					case 21:
																																						goto IL_134c;
																																					case 26:
																																						goto IL_136f;
																																					case 111:
																																						goto IL_1379;
																																					case 269:
																																						goto IL_1387;
																																					case 382:
																																						goto IL_139a;
																																					case 157:
																																						goto IL_13a8;
																																					case 85:
																																					case 135:
																																						goto IL_13b6;
																																					case 337:
																																						goto IL_13f6;
																																					case 150:
																																						goto IL_140a;
																																					case 73:
																																					case 352:
																																						goto IL_141d;
																																					case 381:
																																						goto IL_145d;
																																					case 278:
																																						goto IL_1471;
																																					case 238:
																																						goto IL_148d;
																																					case 152:
																																						goto IL_149b;
																																					case 101:
																																						goto IL_14a9;
																																					case 205:
																																						goto IL_14b4;
																																					case 74:
																																						goto IL_14c2;
																																					case 96:
																																					case 322:
																																						goto IL_14d0;
																																					case 366:
																																						goto IL_14ec;
																																					case 185:
																																					case 342:
																																						goto IL_14fa;
																																					case 54:
																																						goto IL_153a;
																																					case 244:
																																						goto IL_154e;
																																					case 227:
																																					case 240:
																																						goto IL_1561;
																																					case 263:
																																						goto IL_15aa;
																																					case 151:
																																						goto IL_15be;
																																					case 55:
																																						goto IL_15d1;
																																					case 358:
																																						goto IL_15df;
																																					case 5:
																																					case 281:
																																						goto IL_15ed;
																																					case 237:
																																						goto IL_164f;
																																					case 95:
																																						goto IL_1662;
																																					case 343:
																																						goto IL_1670;
																																					case 214:
																																					case 370:
																																						goto IL_167e;
																																					case 72:
																																						goto IL_1692;
																																					case 254:
																																						goto IL_16e6;
																																					case 78:
																																						goto IL_16f4;
																																					case 99:
																																						goto IL_1707;
																																					case 328:
																																						goto IL_1715;
																																					case 284:
																																					case 333:
																																						goto IL_1720;
																																					case 194:
																																						goto IL_1787;
																																					case 41:
																																						goto IL_179a;
																																					case 92:
																																						goto IL_17a8;
																																					case 122:
																																						goto IL_17b3;
																																					case 66:
																																					case 314:
																																						goto IL_17c1;
																																					case 8:
																																						goto IL_1813;
																																					case 265:
																																						goto IL_1826;
																																					case 193:
																																						goto IL_1834;
																																					case 182:
																																					case 274:
																																						goto IL_1842;
																																					case 303:
																																						goto IL_1850;
																																					case 174:
																																						goto IL_1874;
																																					case 268:
																																						goto IL_188b;
																																					case 117:
																																						goto IL_18a7;
																																					case 359:
																																					case 360:
																																						goto IL_18b2;
																																					case 226:
																																						goto IL_18f3;
																																					case 317:
																																						goto IL_1907;
																																					case 119:
																																						goto IL_191a;
																																					case 236:
																																						goto IL_1925;
																																					case 71:
																																					case 356:
																																						goto IL_1933;
																																					case 316:
																																						goto IL_1955;
																																					case 144:
																																						goto IL_1963;
																																					case 27:
																																						goto IL_1971;
																																					case 192:
																																						goto IL_1984;
																																					case 345:
																																						goto IL_1992;
																																					case 109:
																																					case 184:
																																						goto IL_19a0;
																																					case 361:
																																						goto IL_19b8;
																																					case 249:
																																						goto IL_19c6;
																																					case 134:
																																					case 298:
																																						goto IL_19d1;
																																					case 30:
																																						goto IL_1a11;
																																					case 0:
																																						goto IL_1a25;
																																					case 181:
																																						goto IL_1a38;
																																					case 387:
																																						goto IL_1a43;
																																					case 234:
																																					case 385:
																																						goto IL_1a51;
																																					case 246:
																																						goto IL_1a73;
																																					case 17:
																																						goto IL_1a81;
																																					case 289:
																																						goto IL_1a8f;
																																					case 47:
																																						goto IL_1aa2;
																																					case 1:
																																						goto IL_1ab0;
																																					case 100:
																																					case 252:
																																						goto IL_1abe;
																																					case 228:
																																						goto IL_1adb;
																																					case 308:
																																						goto IL_1b1a;
																																					case 320:
																																						goto IL_1b2d;
																																					case 257:
																																						goto IL_1b38;
																																					case 10:
																																					case 160:
																																						goto IL_1b46;
																																					case 363:
																																						goto IL_1b5a;
																																					case 250:
																																						goto IL_1b99;
																																					case 108:
																																						goto IL_1ba9;
																																					case 288:
																																						goto IL_1bb4;
																																					case 63:
																																					case 216:
																																						goto IL_1bbf;
																																					case 247:
																																						goto IL_1bd7;
																																					case 219:
																																						goto IL_1be5;
																																					case 346:
																																						goto IL_1bf3;
																																					case 31:
																																					case 37:
																																					case 40:
																																					case 42:
																																					case 61:
																																					case 69:
																																					case 76:
																																					case 77:
																																					case 82:
																																					case 86:
																																					case 89:
																																					case 94:
																																					case 97:
																																					case 129:
																																					case 133:
																																					case 137:
																																					case 147:
																																					case 155:
																																					case 163:
																																					case 168:
																																					case 169:
																																					case 171:
																																					case 186:
																																					case 190:
																																					case 191:
																																					case 201:
																																					case 204:
																																					case 207:
																																					case 213:
																																					case 225:
																																					case 235:
																																					case 255:
																																					case 256:
																																					case 258:
																																					case 264:
																																					case 272:
																																					case 276:
																																					case 291:
																																					case 294:
																																					case 302:
																																					case 306:
																																					case 319:
																																					case 324:
																																					case 339:
																																					case 341:
																																					case 349:
																																					case 373:
																																					case 378:
																																					case 383:
																																					case 390:
																																						goto end_IL_0695;
																																					case 4:
																																					case 15:
																																					case 19:
																																					case 20:
																																					case 25:
																																					case 34:
																																					case 35:
																																					case 48:
																																					case 53:
																																					case 67:
																																					case 90:
																																					case 91:
																																					case 103:
																																					case 105:
																																					case 113:
																																					case 115:
																																					case 120:
																																					case 123:
																																					case 125:
																																					case 136:
																																					case 145:
																																					case 146:
																																					case 153:
																																					case 159:
																																					case 162:
																																					case 165:
																																					case 166:
																																					case 195:
																																					case 211:
																																					case 222:
																																					case 224:
																																					case 230:
																																					case 242:
																																					case 271:
																																					case 273:
																																					case 275:
																																					case 279:
																																					case 282:
																																					case 286:
																																					case 292:
																																					case 300:
																																					case 301:
																																					case 312:
																																					case 329:
																																					case 350:
																																					case 365:
																																					case 369:
																																					case 371:
																																					case 377:
																																					case 386:
																																						goto end_IL_0748;
																																					case 326:
																																						goto end_IL_1c16;
																																					case 154:
																																						goto end_IL_1c29;
																																					case 220:
																																						goto end_IL_1c33;
																																					case 132:
																																						goto end_IL_1c3e;
																																					case 6:
																																						goto end_IL_1c4e;
																																					case 223:
																																					case 334:
																																						goto end_IL_1c5e;
																																					case 243:
																																						goto end_IL_1c77;
																																					case 212:
																																						goto end_IL_1c90;
																																					case 58:
																																						goto end_IL_1ca0;
																																					case 172:
																																						goto end_IL_1cb0;
																																					case 173:
																																						goto end_IL_1cc0;
																																					case 3:
																																					case 56:
																																						return;
																																					}
																																					continue;
																																				}
																																				num6++;
																																				goto end_IL_0748;
																																				continue;
																																				end_IL_065d:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	continue;
																																	end_IL_0695:
																																	break;
																																}
																																break;
																																IL_06a5:;
																															}
																															break;
																														}
																														goto IL_0753;
																														IL_07b1:
																														num6 -= 2;
																														goto IL_07bf;
																														IL_0753:
																														if (34 > b)
																														{
																															break;
																														}
																														num = 38;
																														goto IL_076a;
																														IL_07bf:
																														ptr2 += 8;
																														goto end_IL_0748;
																														IL_076a:
																														((delegate*<Behaviour, bool, void>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																														num = 175;
																														goto IL_07b1;
																													}
																													break;
																												}
																												num = 98;
																												goto IL_0ac3;
																												IL_0bc9:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0c09;
																												IL_0c09:
																												array[num6 - 2] = 3;
																												goto IL_0c1d;
																												IL_0ac3:
																												if (33 <= b)
																												{
																													goto IL_0ace;
																												}
																												goto IL_0b19;
																												IL_0ace:
																												((delegate*<bool, void>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																												goto IL_0af8;
																												IL_0af8:
																												num6--;
																												goto IL_0b06;
																												IL_0b06:
																												ptr2 += 8;
																												goto end_IL_0748;
																												IL_0b19:
																												if (31 >= b)
																												{
																													goto IL_0b27;
																												}
																												goto IL_0bad;
																												IL_0b27:
																												if (31 > b)
																												{
																													break;
																												}
																												num = 130;
																												goto IL_0b3e;
																												IL_0c1d:
																												num6--;
																												goto end_IL_0748;
																												IL_0b3e:
																												array[num6 - 1] = 3;
																												goto IL_0b52;
																												IL_0b52:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																												goto IL_0b91;
																												IL_0b91:
																												ptr2 += 8;
																												num = 136;
																												goto end_IL_0748;
																												IL_0bad:
																												if (32 < b)
																												{
																													break;
																												}
																												goto IL_0bbb;
																												IL_0bbb:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_0bc9;
																											}
																											break;
																										}
																										goto IL_07d2;
																										IL_0913:
																										num6 -= 2;
																										goto IL_0921;
																										IL_07d2:
																										if (30 > b)
																										{
																											goto IL_07e0;
																										}
																										goto IL_08d6;
																										IL_07e0:
																										if (27 >= b)
																										{
																											goto IL_07ee;
																										}
																										goto IL_0993;
																										IL_07ee:
																										if (27 > b)
																										{
																											goto IL_07fc;
																										}
																										goto IL_0934;
																										IL_07fc:
																										if (25 >= b)
																										{
																											goto IL_0807;
																										}
																										goto IL_087b;
																										IL_0807:
																										if (25 > b)
																										{
																											break;
																										}
																										goto IL_0815;
																										IL_0815:
																										array[num6 - 1] = 3;
																										goto IL_0829;
																										IL_0829:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_0868;
																										IL_0868:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_087b:
																										if (26 < b)
																										{
																											break;
																										}
																										goto IL_0889;
																										IL_0889:
																										if (26 > b)
																										{
																											break;
																										}
																										goto IL_0897;
																										IL_0897:
																										array[num6] = 5;
																										goto IL_08a5;
																										IL_08a5:
																										array2[num6] = ((delegate*<GorillaTagger>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])();
																										goto IL_08c3;
																										IL_08c3:
																										num6++;
																										goto IL_0a94;
																										IL_0a94:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_0934:
																										array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																										goto IL_096c;
																										IL_096c:
																										array[num6 - 1] = 5;
																										goto IL_0980;
																										IL_0980:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_0993:
																										if (28 >= b)
																										{
																											goto IL_099e;
																										}
																										goto IL_0a0b;
																										IL_099e:
																										if (28 > b)
																										{
																											break;
																										}
																										goto IL_09ac;
																										IL_09ac:
																										array[num6 - 1] = 5;
																										goto IL_09c0;
																										IL_09c0:
																										array2[num6 - 1] = ((delegate*<Component, Transform>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																										goto IL_09f8;
																										IL_09f8:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_0a0b:
																										if (29 < b)
																										{
																											break;
																										}
																										num = 239;
																										goto IL_0a22;
																										IL_0921:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_0a22:
																										if (29 > b)
																										{
																											break;
																										}
																										goto IL_0a30;
																										IL_0a30:
																										array2[num6 - 1] = ((delegate*<Class184, Vector3>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																										goto IL_0a6d;
																										IL_0a6d:
																										array[num6 - 1] = 4;
																										goto IL_0a81;
																										IL_0a81:
																										ptr2 += 8;
																										goto end_IL_0748;
																										IL_08d6:
																										((delegate*<Transform, Vector3, void>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																										goto IL_0913;
																									}
																									break;
																								}
																								goto IL_0c30;
																								IL_0c9f:
																								ptr2 += 8;
																								goto end_IL_0748;
																								IL_0c30:
																								array[num6 - 2] = 0;
																								goto IL_0c44;
																								IL_0c44:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																								goto IL_0c91;
																								IL_0c91:
																								num6--;
																								goto IL_0c9f;
																							}
																							break;
																						}
																						goto IL_0cb2;
																						IL_110b:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_0748;
																						IL_0cb2:
																						if (42 >= b)
																						{
																							goto IL_0cc0;
																						}
																						goto IL_0fa3;
																						IL_0cc0:
																						if (42 <= b)
																						{
																							goto IL_0ccb;
																						}
																						goto IL_0d0c;
																						IL_0ccb:
																						((Class184)array2[num6 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																						goto IL_0cf9;
																						IL_0cf9:
																						num6 -= 2;
																						goto end_IL_0748;
																						IL_0d0c:
																						if (39 < b)
																						{
																							goto IL_0d1a;
																						}
																						num = 50;
																						goto IL_0e43;
																						IL_0d1a:
																						if (40 >= b)
																						{
																							goto IL_0d28;
																						}
																						goto IL_0db8;
																						IL_0d28:
																						if (40 > b)
																						{
																							break;
																						}
																						goto IL_0d36;
																						IL_0d36:
																						array[num6 - 2] = 0;
																						goto IL_0d4a;
																						IL_0d4a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																						goto IL_0d97;
																						IL_0d97:
																						num6--;
																						goto IL_0da5;
																						IL_0da5:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_0db8:
																						if (41 < b)
																						{
																							break;
																						}
																						goto IL_0dc6;
																						IL_0dc6:
																						if (41 > b)
																						{
																							break;
																						}
																						goto IL_0dd4;
																						IL_0dd4:
																						array[num6 - 1] = 3;
																						goto IL_0de8;
																						IL_0de8:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0e27;
																						IL_0e27:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_1127:
																						if (47 < b)
																						{
																							break;
																						}
																						goto IL_1135;
																						IL_0e43:
																						if (39 <= b)
																						{
																							goto IL_0e51;
																						}
																						goto IL_0ed8;
																						IL_0e51:
																						array[num6 - 2] = 0;
																						goto IL_0e65;
																						IL_0e65:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<Vector3, Vector3, bool>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]) ? 1 : 0);
																						goto IL_0eb7;
																						IL_0eb7:
																						num6--;
																						goto IL_0ec5;
																						IL_0ec5:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_0ed8:
																						if (37 >= b)
																						{
																							goto IL_0ee3;
																						}
																						goto IL_0f35;
																						IL_0ee3:
																						if (37 > b)
																						{
																							break;
																						}
																						goto IL_0ef1;
																						IL_0ef1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0f1c;
																						IL_0f1c:
																						array[num6 - 1] = 0;
																						goto end_IL_0748;
																						IL_0f35:
																						if (38 < b)
																						{
																							break;
																						}
																						goto IL_0f43;
																						IL_0f43:
																						if (38 > b)
																						{
																							break;
																						}
																						goto IL_0f51;
																						IL_0f51:
																						array[num6] = 4;
																						goto IL_0f5f;
																						IL_0f5f:
																						array2[num6] = ((delegate*<Vector3>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])();
																						goto IL_0f82;
																						IL_0f82:
																						num6++;
																						goto IL_0f90;
																						IL_0f90:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_0fa3:
																						if (45 >= b)
																						{
																							goto IL_0fb1;
																						}
																						goto IL_10f2;
																						IL_0fb1:
																						if (45 <= b)
																						{
																							goto IL_0fbc;
																						}
																						goto IL_1022;
																						IL_0fbc:
																						array[num6 - 1] = 3;
																						goto IL_0fd0;
																						IL_0fd0:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_100f;
																						IL_100f:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_1022:
																						if (43 >= b)
																						{
																							goto IL_102d;
																						}
																						goto IL_1096;
																						IL_102d:
																						if (43 > b)
																						{
																							break;
																						}
																						num = 189;
																						goto IL_1044;
																						IL_1135:
																						if (47 > b)
																						{
																						}
																						break;
																						IL_1044:
																						array[num6] = 4;
																						goto IL_1052;
																						IL_1052:
																						array2[num6] = ((delegate*<Vector3>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])();
																						goto IL_1075;
																						IL_1075:
																						num6++;
																						goto IL_1083;
																						IL_1083:
																						ptr2 += 8;
																						goto end_IL_0748;
																						IL_1096:
																						if (44 < b)
																						{
																							break;
																						}
																						goto IL_10a4;
																						IL_10a4:
																						if (44 > b)
																						{
																							break;
																						}
																						goto IL_10b2;
																						IL_10b2:
																						((Class184)array2[num6 - 2]).vector3_0 = (Vector3)array2[num6 - 1];
																						goto IL_10df;
																						IL_10df:
																						num6 -= 2;
																						goto end_IL_0748;
																						IL_10f2:
																						if (46 >= b)
																						{
																							goto IL_10fd;
																						}
																						goto IL_1127;
																						IL_10fd:
																						if (46 > b)
																						{
																							break;
																						}
																						goto IL_110b;
																					}
																					break;
																				}
																				num = 187;
																				goto IL_1151;
																				IL_1bbf:
																				array2[num6] = array5[*(int*)(ptr2 + num3)];
																				goto IL_1bd7;
																				IL_1bd7:
																				array[num6] = 5;
																				goto IL_1be5;
																				IL_1151:
																				if (24 <= b)
																				{
																					goto IL_115c;
																				}
																				goto IL_11a6;
																				IL_115c:
																				((delegate*<Class184, void>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])((Class184)array2[num6 - 1]);
																				goto IL_1185;
																				IL_1185:
																				num6--;
																				goto IL_1193;
																				IL_1193:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_11a6:
																				if (12 >= b)
																				{
																					goto IL_11b4;
																				}
																				goto IL_1707;
																				IL_11b4:
																				if (12 <= b)
																				{
																					goto end_IL_0748;
																				}
																				goto IL_11c2;
																				IL_11c2:
																				if (6 >= b)
																				{
																					goto IL_11d0;
																				}
																				goto IL_148d;
																				IL_11d0:
																				if (6 > b)
																				{
																					goto IL_11de;
																				}
																				goto IL_141d;
																				IL_11de:
																				if (3 >= b)
																				{
																					goto IL_11ec;
																				}
																				goto IL_1325;
																				IL_11ec:
																				if (3 <= b)
																				{
																					goto IL_11f7;
																				}
																				goto IL_1241;
																				IL_11f7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1220;
																				IL_1220:
																				ptr2 += 8;
																				goto IL_122e;
																				IL_122e:
																				num6--;
																				goto end_IL_0748;
																				IL_1241:
																				if (1 >= b)
																				{
																					goto IL_124c;
																				}
																				goto IL_12a2;
																				IL_124c:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_125a;
																				IL_125a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_1273;
																				IL_1273:
																				array[num6] = 0;
																				goto IL_1281;
																				IL_1281:
																				num6++;
																				goto IL_128f;
																				IL_128f:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_12a2:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_12b0;
																				IL_12b0:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_12be;
																				IL_12be:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_12fe;
																				IL_12fe:
																				array[num6 - 2] = 0;
																				goto IL_1312;
																				IL_1312:
																				num6--;
																				goto end_IL_0748;
																				IL_1325:
																				if (4 >= b)
																				{
																					goto IL_1330;
																				}
																				goto IL_139a;
																				IL_1330:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_133e;
																				IL_133e:
																				array[num6] = 0;
																				goto IL_134c;
																				IL_134c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_136f;
																				IL_136f:
																				array2[num6] = null;
																				goto IL_1379;
																				IL_1379:
																				num6++;
																				goto IL_1387;
																				IL_1387:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_139a:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_13a8;
																				IL_13a8:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_13b6;
																				IL_13b6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_13f6;
																				IL_13f6:
																				array[num6 - 2] = 0;
																				goto IL_140a;
																				IL_140a:
																				num6--;
																				goto end_IL_0748;
																				IL_141d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_145d;
																				IL_145d:
																				array[num6 - 2] = 0;
																				goto IL_1471;
																				IL_1471:
																				num6--;
																				num = 329;
																				goto end_IL_0748;
																				IL_148d:
																				if (9 >= b)
																				{
																					goto IL_149b;
																				}
																				goto IL_15d1;
																				IL_149b:
																				if (9 > b)
																				{
																					goto IL_14a9;
																				}
																				goto IL_1561;
																				IL_14a9:
																				if (7 < b)
																				{
																					goto IL_14b4;
																				}
																				num = 366;
																				goto IL_14ec;
																				IL_14b4:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_14c2;
																				IL_14c2:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_14d0;
																				IL_14d0:
																				num6--;
																				goto end_IL_0748;
																				IL_1be5:
																				num6++;
																				goto IL_1bf3;
																				IL_14ec:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_14fa;
																				IL_14fa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_153a;
																				IL_153a:
																				array[num6 - 2] = 0;
																				goto IL_154e;
																				IL_154e:
																				num6--;
																				goto end_IL_0748;
																				IL_1561:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 263;
																				goto IL_15aa;
																				IL_15aa:
																				array[num6 - 2] = 0;
																				goto IL_15be;
																				IL_15be:
																				num6--;
																				goto end_IL_0748;
																				IL_15d1:
																				if (10 >= b)
																				{
																					goto IL_15df;
																				}
																				goto IL_1662;
																				IL_15df:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_15ed;
																				IL_15ed:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_164f;
																				IL_164f:
																				num6 -= 2;
																				goto end_IL_0748;
																				IL_1662:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_1670;
																				IL_1670:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_167e;
																				IL_167e:
																				array[num6 - 2] = 0;
																				goto IL_1692;
																				IL_1692:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_16e6;
																				IL_16e6:
																				num6--;
																				goto IL_16f4;
																				IL_16f4:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_1707:
																				if (18 >= b)
																				{
																					goto IL_1715;
																				}
																				goto IL_19b8;
																				IL_1715:
																				if (18 <= b)
																				{
																					goto IL_1720;
																				}
																				goto IL_179a;
																				IL_1720:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 194;
																				goto IL_1787;
																				IL_1787:
																				num6--;
																				goto end_IL_0748;
																				IL_179a:
																				if (15 < b)
																				{
																					goto IL_17a8;
																				}
																				num = 117;
																				goto IL_18a7;
																				IL_17a8:
																				if (16 >= b)
																				{
																					goto IL_17b3;
																				}
																				goto IL_1826;
																				IL_17b3:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_17c1;
																				IL_17c1:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_1813;
																				IL_1813:
																				num6--;
																				goto end_IL_0748;
																				IL_1826:
																				if (17 < b)
																				{
																					break;
																				}
																				goto IL_1834;
																				IL_1834:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_1842;
																				IL_1842:
																				array[num6] = 0;
																				goto IL_1850;
																				IL_1850:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_1874;
																				IL_1874:
																				num6++;
																				num = 268;
																				goto IL_188b;
																				IL_188b:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_1bf3:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_18a7:
																				if (15 <= b)
																				{
																					goto IL_18b2;
																				}
																				goto IL_191a;
																				IL_18b2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_18f3;
																				IL_18f3:
																				array[num6 - 2] = 0;
																				goto IL_1907;
																				IL_1907:
																				num6--;
																				goto end_IL_0748;
																				IL_191a:
																				if (13 >= b)
																				{
																					goto IL_1925;
																				}
																				goto IL_1984;
																				IL_1925:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_1933;
																				IL_1933:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				num = 316;
																				goto IL_1955;
																				IL_1955:
																				array[num6] = 1;
																				goto IL_1963;
																				IL_1963:
																				num6++;
																				goto IL_1971;
																				IL_1971:
																				ptr2 += 16;
																				goto end_IL_0748;
																				IL_1984:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_1992;
																				IL_1992:
																				if (14 > b)
																				{
																					break;
																				}
																				goto IL_19a0;
																				IL_19a0:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0748;
																				IL_19b8:
																				if (21 >= b)
																				{
																					goto IL_19c6;
																				}
																				goto IL_1b2d;
																				IL_19c6:
																				if (21 <= b)
																				{
																					goto IL_19d1;
																				}
																				goto IL_1a38;
																				IL_19d1:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1a11;
																				IL_1a11:
																				array[num6 - 2] = 3;
																				goto IL_1a25;
																				IL_1a25:
																				num6--;
																				goto end_IL_0748;
																				IL_1a38:
																				if (19 >= b)
																				{
																					goto IL_1a43;
																				}
																				goto IL_1aa2;
																				IL_1a43:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_1a51;
																				IL_1a51:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				num = 246;
																				goto IL_1a73;
																				IL_1a73:
																				array[num6] = 3;
																				goto IL_1a81;
																				IL_1a81:
																				num6++;
																				goto IL_1a8f;
																				IL_1a8f:
																				ptr2 += 16;
																				goto end_IL_0748;
																				IL_1aa2:
																				if (20 < b)
																				{
																					break;
																				}
																				goto IL_1ab0;
																				IL_1ab0:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_1abe;
																				IL_1abe:
																				array[num6 - 1] = 3;
																				num = 228;
																				goto IL_1adb;
																				IL_1adb:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1b1a;
																				IL_1b1a:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_1b2d:
																				if (22 >= b)
																				{
																					goto IL_1b38;
																				}
																				goto IL_1ba9;
																				IL_1b38:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_1b46;
																				IL_1b46:
																				array[num6 - 1] = 0;
																				goto IL_1b5a;
																				IL_1b5a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)MuiResourceMapResourceTypeIdIntSizeDaylightTimeStruct[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1b99;
																				IL_1b99:
																				ptr2 += 8;
																				goto end_IL_0748;
																				IL_1ba9:
																				if (23 < b)
																				{
																					break;
																				}
																				goto IL_1bb4;
																				IL_1bb4:
																				if (23 > b)
																				{
																					break;
																				}
																				goto IL_1bbf;
																			}
																			break;
																			IL_0718:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0748;
																	continue;
																	end_IL_0728:
																	break;
																}
																continue;
																end_IL_0738:
																break;
															}
															continue;
															end_IL_0748:
															break;
														}
														continue;
														end_IL_1c16:
														break;
													}
													continue;
													end_IL_1c29:
													break;
												}
												continue;
												end_IL_1c33:
												break;
											}
											continue;
											end_IL_1c3e:
											break;
										}
										continue;
										end_IL_1c4e:
										break;
									}
									continue;
									end_IL_1c5e:
									break;
								}
								continue;
								end_IL_1c77:
								break;
							}
							continue;
							end_IL_1c90:
							break;
						}
						continue;
						end_IL_1ca0:
						break;
					}
					continue;
					end_IL_1cb0:
					break;
				}
				continue;
				end_IL_1cc0:
				break;
			}
		}
	}

	private static double StaticArrayInitTypeSizewFuncFlags(double double_0)
	{
		return Math.Tan(double_0);
	}

	private static bool OidGroupMemberName(Class184 class184_1)
	{
		return class184_1.bool_2;
	}

	public unsafe static Color smethod_6()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0759, IL_076c, IL_078b, IL_079b, IL_07ae, IL_07be, IL_07ce, IL_07de, IL_07ee, IL_07fe, IL_080e, IL_081e, IL_082e, IL_083e, IL_084e, IL_0862, IL_0872, IL_0885, IL_08b0, IL_08c9, IL_08e4, IL_08ef, IL_0902, IL_0920, IL_092e, IL_0947, IL_095a, IL_096d, IL_0978, IL_0994, IL_09a2, IL_09b0, IL_09be, IL_09c9, IL_09d7, IL_09ea, IL_09f3, IL_09fe, IL_0a09, IL_0a17, IL_0a2a, IL_0a38, IL_0a46, IL_0a54, IL_0a5d, IL_0abf, IL_0ad2, IL_0add, IL_0b1d, IL_0b31, IL_0b44, IL_0b52, IL_0b5d, IL_0b86, IL_0b94, IL_0ba7, IL_0bb2, IL_0bc5, IL_0bd8, IL_0be6, IL_0bf1, IL_0c31, IL_0c45, IL_0c61, IL_0c6f, IL_0c7d, IL_0c8b, IL_0cae, IL_0cb8, IL_0cd4, IL_0ce2, IL_0cf5, IL_0d03, IL_0d0e, IL_0d26, IL_0d34, IL_0d42, IL_0d50, IL_0d5e, IL_0d6c, IL_0db3, IL_0dc6, IL_0dd4, IL_0de2, IL_0dfb, IL_0e12, IL_0e20, IL_0e33, IL_0e3c, IL_0e4a, IL_0e55, IL_0e63, IL_0e8c, IL_0ea5, IL_0eb3, IL_0ec1, IL_0ecf, IL_0edd, IL_0eeb, IL_0ef9, IL_0f0d, IL_0f61, IL_0f74, IL_0f87, IL_0f95, IL_0fa3, IL_0fc7, IL_0fde, IL_0ff1, IL_100a, IL_1022, IL_1040, IL_1064, IL_108a, IL_1098, IL_10b0, IL_10be, IL_10d1, IL_10e5, IL_111d, IL_1130, IL_1170, IL_1189, IL_119c, IL_11aa, IL_11b8, IL_11c6, IL_11d4, IL_11dd, IL_11eb, IL_120e, IL_121c, IL_122f, IL_1238, IL_1243, IL_1251, IL_126f, IL_127d, IL_1290, IL_129b, IL_12a9, IL_12b2, IL_12f3, IL_1307, IL_131a, IL_132d, IL_1349, IL_1362, IL_1370, IL_137e, IL_1391, IL_139c, IL_13d0, IL_13e9, IL_13f7, IL_1405, IL_1419, IL_146b, IL_1479, IL_148c, IL_14cb, IL_14de, IL_14fc, IL_1513, IL_1526, IL_1534, IL_1574, IL_1588, IL_159b, IL_15a9, IL_15fb, IL_1617, IL_1657, IL_166b, IL_167e, IL_168c, IL_16a9, IL_16f8, IL_1702, IL_172f, IL_1743, IL_1753, IL_1766, IL_1774, IL_1782, IL_178b, IL_17b5, IL_17ce, IL_17ea, IL_1829, IL_183c, IL_184a, IL_1855, IL_186f, IL_1882, IL_188d, IL_189b, IL_18db, IL_18ef, IL_1902, IL_1910, IL_191e, IL_1932, IL_199b, IL_19a9, IL_19bc, IL_19ca, IL_19d5, IL_19e3, IL_19ec, IL_19fa, IL_1a1e, IL_1a2c, IL_1a3a, IL_1a4d, IL_1a8a, IL_1a9e, IL_1ab1, IL_1abf, IL_1ad2, IL_1adb, IL_1ae6, IL_1afa, IL_1b39, IL_1b4c, IL_1b5a, IL_1b65, IL_1ba7, IL_1bba, IL_1bc8, IL_1bd3, IL_1be7, IL_1c26, IL_1c39, IL_1c44, IL_1c52, IL_1c6b, IL_1c79, IL_1c87, IL_1c9a, IL_1ca8, IL_1cb6, IL_1cf6, IL_1d0a, IL_1d1d, IL_1d2b, IL_1d39, IL_1d47, IL_1d5b, IL_1dd3, IL_1dea, IL_1dfd, IL_1e06, IL_1e11, IL_1e2b, IL_1e39, IL_1e47, IL_1e5a, IL_1e68, IL_1e76, IL_1e7f, IL_1ea8, IL_1ec1, IL_1ecf, IL_1eda, IL_1eee, IL_1f2d, IL_1f40, IL_1f4b, IL_1f59, IL_1f6d, IL_1fac, IL_1fbf, IL_1fcd, IL_1fdb, IL_201b, IL_202f, IL_2042, IL_2050, IL_205b, IL_209b, IL_20af, IL_20c2, IL_20d0, IL_20de, IL_20fb, IL_2143, IL_2156, IL_2161, IL_216c, IL_2180, IL_21bf, IL_21cf, IL_21e2, IL_21f5, IL_21ff, IL_220a, IL_221a, IL_2233, IL_2243, IL_2253, IL_2263, IL_2273, IL_2283, IL_2293, IL_22ae are reachable both inside and outside the pinned region starting at IL_22a8. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 289;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef85 = default(int);
			ref int reference = ref __rxRef85;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2293:
					num2 = 1;
					while (true)
					{
						IL_2283:
						num3 = num2 * 4;
						while (true)
						{
							IL_2273:
							num4 = num2 * 8;
							while (true)
							{
								IL_2263:
								array2 = new byte[7];
								while (true)
								{
									IL_2253:
									array3 = new object[7];
									while (true)
									{
										IL_2243:
										array4 = new int[7];
										while (true)
										{
											IL_2233:
											array5 = new int[7];
											while (true)
											{
												IL_221a:
												array6 = new long[7];
												num = 409;
												while (true)
												{
													IL_220a:
													array7 = new object[8];
													while (true)
													{
														IL_21ff:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExecuteAssemblyByNamegetRegisteredChannels.getInformationalVersiongetStackBehaviourPush);
														while (true)
														{
															IL_21f5:
															ptr2 = ptr;
															while (true)
															{
																IL_21e2:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_084e:
																		byte b = *ptr2;
																		num = 179;
																		while (true)
																		{
																			IL_083e:
																			ptr2++;
																			while (true)
																			{
																				IL_082e:
																				if (b >= 1)
																				{
																					while (b <= 55)
																					{
																						while (true)
																						{
																							IL_080e:
																							if (28 < b)
																							{
																								while (true)
																								{
																									IL_07fe:
																									if (42 < b)
																									{
																										while (true)
																										{
																											IL_07ee:
																											if (49 >= b)
																											{
																												while (true)
																												{
																													IL_07de:
																													if (49 > b)
																													{
																														while (true)
																														{
																															IL_07ce:
																															if (45 >= b)
																															{
																																while (true)
																																{
																																	IL_07be:
																																	if (45 > b)
																																	{
																																		while (true)
																																		{
																																			IL_07ae:
																																			if (43 < b)
																																			{
																																				while (44 >= b)
																																				{
																																					num = 145;
																																					while (44 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_076c:
																																							array2[num6 - 1] = 3;
																																							num = 463;
																																							while (true)
																																							{
																																								if (num != 463)
																																								{
																																									if (num != 1444)
																																									{
																																										break;
																																									}
																																									switch (num)
																																									{
																																									case 289:
																																										break;
																																									default:
																																										continue;
																																									case 185:
																																									case 222:
																																										goto IL_076c;
																																									case 145:
																																										goto IL_078b;
																																									case 430:
																																										goto IL_079b;
																																									case 374:
																																										goto IL_07ae;
																																									case 358:
																																										goto IL_07be;
																																									case 189:
																																										goto IL_07ce;
																																									case 5:
																																										goto IL_07de;
																																									case 234:
																																										goto IL_07ee;
																																									case 26:
																																										goto IL_07fe;
																																									case 335:
																																										goto IL_080e;
																																									case 338:
																																										goto IL_081e;
																																									case 177:
																																										goto IL_082e;
																																									case 179:
																																										goto IL_083e;
																																									case 55:
																																									case 159:
																																										goto IL_084e;
																																									case 35:
																																										goto IL_0862;
																																									case 41:
																																										goto IL_0872;
																																									case 3:
																																									case 124:
																																										goto IL_0885;
																																									case 112:
																																										goto end_IL_0759;
																																									case 110:
																																									case 287:
																																										goto IL_08c9;
																																									case 310:
																																										goto IL_08e4;
																																									case 244:
																																										goto IL_08ef;
																																									case 94:
																																									case 128:
																																										goto IL_0902;
																																									case 251:
																																										goto IL_0920;
																																									case 78:
																																										goto IL_092e;
																																									case 317:
																																										goto IL_0947;
																																									case 385:
																																										goto IL_095a;
																																									case 386:
																																										goto IL_096d;
																																									case 186:
																																									case 306:
																																										goto IL_0978;
																																									case 368:
																																										goto IL_0994;
																																									case 190:
																																										goto IL_09a2;
																																									case 246:
																																										goto IL_09b0;
																																									case 275:
																																										goto IL_09be;
																																									case 380:
																																										goto IL_09c9;
																																									case 221:
																																										goto IL_09d7;
																																									case 42:
																																										goto IL_09f3;
																																									case 27:
																																										goto IL_09fe;
																																									case 211:
																																										goto IL_0a09;
																																									case 111:
																																									case 199:
																																										goto IL_0a17;
																																									case 134:
																																										goto IL_0a2a;
																																									case 23:
																																										goto IL_0a38;
																																									case 68:
																																									case 106:
																																										goto IL_0a5d;
																																									case 92:
																																										goto IL_0abf;
																																									case 344:
																																										goto IL_0ad2;
																																									case 155:
																																									case 334:
																																										goto IL_0add;
																																									case 96:
																																										goto IL_0b1d;
																																									case 24:
																																										goto IL_0b31;
																																									case 7:
																																										goto IL_0b44;
																																									case 204:
																																										goto IL_0b52;
																																									case 12:
																																									case 17:
																																										goto IL_0b5d;
																																									case 103:
																																										goto IL_0b86;
																																									case 1:
																																										goto IL_0b94;
																																									case 71:
																																										goto IL_0ba7;
																																									case 238:
																																										goto IL_0bb2;
																																									case 62:
																																										goto IL_0bc5;
																																									case 268:
																																										goto IL_0bd8;
																																									case 20:
																																										goto IL_0be6;
																																									case 56:
																																									case 174:
																																										goto IL_0bf1;
																																									case 333:
																																										goto IL_0c31;
																																									case 278:
																																										goto IL_0c45;
																																									case 217:
																																										goto IL_0c61;
																																									case 281:
																																										goto IL_0c6f;
																																									case 13:
																																									case 203:
																																										goto IL_0c7d;
																																									case 270:
																																										goto IL_0c8b;
																																									case 115:
																																										goto IL_0cae;
																																									case 171:
																																										goto IL_0cb8;
																																									case 375:
																																										goto IL_0cd4;
																																									case 259:
																																										goto IL_0ce2;
																																									case 307:
																																										goto IL_0cf5;
																																									case 79:
																																										goto IL_0d03;
																																									case 265:
																																									case 295:
																																										goto IL_0d0e;
																																									case 320:
																																										goto IL_0d26;
																																									case 351:
																																										goto IL_0d34;
																																									case 85:
																																										goto IL_0d42;
																																									case 73:
																																										goto IL_0d50;
																																									case 345:
																																										goto IL_0d5e;
																																									case 346:
																																									case 362:
																																										goto IL_0d6c;
																																									case 118:
																																										goto IL_0db3;
																																									case 286:
																																										goto IL_0dc6;
																																									case 329:
																																										goto IL_0dd4;
																																									case 163:
																																									case 277:
																																										goto IL_0de2;
																																									case 384:
																																										goto IL_0dfb;
																																									case 352:
																																										goto IL_0e12;
																																									case 140:
																																										goto IL_0e20;
																																									case 47:
																																										goto IL_0e3c;
																																									case 267:
																																										goto IL_0e4a;
																																									case 80:
																																										goto IL_0e55;
																																									case 214:
																																									case 292:
																																										goto IL_0e63;
																																									case 34:
																																										goto IL_0e8c;
																																									case 77:
																																										goto IL_0ea5;
																																									case 18:
																																										goto IL_0eb3;
																																									case 388:
																																										goto IL_0ecf;
																																									case 90:
																																										goto IL_0edd;
																																									case 152:
																																										goto IL_0eeb;
																																									case 36:
																																									case 285:
																																										goto IL_0ef9;
																																									case 31:
																																										goto IL_0f0d;
																																									case 294:
																																										goto IL_0f61;
																																									case 394:
																																										goto IL_0f74;
																																									case 395:
																																										goto IL_0f87;
																																									case 207:
																																									case 212:
																																										goto IL_0f95;
																																									case 247:
																																										goto IL_0fa3;
																																									case 148:
																																										goto IL_0fc7;
																																									case 383:
																																										goto IL_0fde;
																																									case 170:
																																									case 399:
																																										goto IL_0ff1;
																																									case 61:
																																									case 407:
																																										goto IL_100a;
																																									case 74:
																																										goto IL_1022;
																																									case 236:
																																										goto IL_1040;
																																									case 260:
																																										goto IL_1064;
																																									case 354:
																																									case 414:
																																										goto IL_108a;
																																									case 254:
																																										goto IL_1098;
																																									case 122:
																																										goto IL_10b0;
																																									case 39:
																																										goto IL_10be;
																																									case 187:
																																									case 423:
																																										goto IL_10d1;
																																									case 200:
																																										goto IL_10e5;
																																									case 105:
																																										goto IL_111d;
																																									case 257:
																																									case 425:
																																										goto IL_1130;
																																									case 406:
																																										goto IL_1170;
																																									case 426:
																																										goto IL_1189;
																																									case 429:
																																										goto IL_119c;
																																									case 160:
																																										goto IL_11aa;
																																									case 225:
																																										goto IL_11b8;
																																									case 398:
																																										goto IL_11c6;
																																									case 40:
																																									case 402:
																																										goto IL_11dd;
																																									case 411:
																																										goto IL_11eb;
																																									case 72:
																																										goto IL_120e;
																																									case 209:
																																										goto IL_121c;
																																									case 311:
																																										goto IL_1238;
																																									case 226:
																																									case 282:
																																										goto IL_1243;
																																									case 162:
																																										goto IL_1251;
																																									case 396:
																																										goto IL_126f;
																																									case 250:
																																										goto IL_127d;
																																									case 325:
																																										goto IL_1290;
																																									case 298:
																																										goto IL_129b;
																																									case 176:
																																									case 210:
																																										goto IL_12b2;
																																									case 173:
																																										goto IL_12f3;
																																									case 192:
																																										goto IL_1307;
																																									case 413:
																																										goto IL_131a;
																																									case 431:
																																										goto IL_132d;
																																									case 420:
																																									case 434:
																																										goto IL_1349;
																																									case 326:
																																										goto IL_1362;
																																									case 146:
																																										goto IL_1370;
																																									case 378:
																																										goto IL_137e;
																																									case 435:
																																										goto IL_1391;
																																									case 10:
																																									case 366:
																																										goto IL_139c;
																																									case 392:
																																										goto IL_13d0;
																																									case 229:
																																										goto IL_13e9;
																																									case 340:
																																										goto IL_13f7;
																																									case 167:
																																									case 206:
																																										goto IL_1405;
																																									case 154:
																																										goto IL_1419;
																																									case 116:
																																										goto IL_146b;
																																									case 6:
																																										goto IL_1479;
																																									case 440:
																																										goto IL_148c;
																																									case 57:
																																										goto IL_14cb;
																																									case 274:
																																									case 441:
																																										goto IL_14de;
																																									case 29:
																																										goto IL_14fc;
																																									case 51:
																																										goto IL_1513;
																																									case 442:
																																										goto IL_1526;
																																									case 64:
																																									case 87:
																																										goto IL_1534;
																																									case 347:
																																										goto IL_1574;
																																									case 213:
																																										goto IL_1588;
																																									case 443:
																																										goto IL_159b;
																																									case 339:
																																									case 432:
																																										goto IL_15a9;
																																									case 258:
																																										goto IL_15fb;
																																									case 44:
																																									case 444:
																																										goto IL_1617;
																																									case 166:
																																										goto IL_1657;
																																									case 360:
																																										goto IL_166b;
																																									case 445:
																																										goto IL_167e;
																																									case 125:
																																									case 180:
																																										goto IL_168c;
																																									case 45:
																																										goto IL_1743;
																																									case 446:
																																										goto IL_1753;
																																									case 450:
																																										goto IL_1766;
																																									case 315:
																																										goto IL_1774;
																																									case 14:
																																									case 309:
																																										goto IL_178b;
																																									case 299:
																																										goto IL_17b5;
																																									case 456:
																																										goto IL_17ce;
																																									case 357:
																																										goto IL_1829;
																																									case 218:
																																										goto IL_183c;
																																									case 53:
																																										goto IL_184a;
																																									case 48:
																																									case 280:
																																										goto IL_1855;
																																									case 237:
																																										goto IL_186f;
																																									case 319:
																																										goto IL_1882;
																																									case 389:
																																										goto IL_188d;
																																									case 220:
																																									case 343:
																																										goto IL_189b;
																																									case 438:
																																										goto IL_18db;
																																									case 58:
																																										goto IL_18ef;
																																									case 453:
																																										goto IL_1902;
																																									case 447:
																																										goto IL_1910;
																																									case 67:
																																									case 424:
																																										goto IL_191e;
																																									case 364:
																																										goto IL_1932;
																																									case 256:
																																										goto IL_199b;
																																									case 355:
																																										goto IL_19a9;
																																									case 69:
																																										goto IL_19bc;
																																									case 165:
																																										goto IL_19ca;
																																									case 183:
																																										goto IL_19d5;
																																									case 215:
																																										goto IL_19ec;
																																									case 114:
																																									case 372:
																																										goto IL_19fa;
																																									case 419:
																																										goto IL_1a1e;
																																									case 367:
																																										goto IL_1a2c;
																																									case 158:
																																										goto IL_1a3a;
																																									case 33:
																																									case 410:
																																										goto IL_1a4d;
																																									case 276:
																																										goto IL_1a8a;
																																									case 273:
																																										goto IL_1a9e;
																																									case 81:
																																										goto IL_1ab1;
																																									case 290:
																																										goto IL_1abf;
																																									case 401:
																																										goto IL_1adb;
																																									case 181:
																																									case 283:
																																										goto IL_1ae6;
																																									case 50:
																																										goto IL_1afa;
																																									case 427:
																																										goto IL_1b39;
																																									case 143:
																																										goto IL_1b4c;
																																									case 363:
																																										goto IL_1b5a;
																																									case 243:
																																									case 322:
																																										goto IL_1b65;
																																									case 208:
																																										goto IL_1ba7;
																																									case 98:
																																										goto IL_1bba;
																																									case 108:
																																										goto IL_1bc8;
																																									case 22:
																																									case 308:
																																										goto IL_1bd3;
																																									case 245:
																																										goto IL_1be7;
																																									case 404:
																																										goto IL_1c26;
																																									case 342:
																																										goto IL_1c39;
																																									case 266:
																																										goto IL_1c44;
																																									case 52:
																																									case 328:
																																										goto IL_1c52;
																																									case 188:
																																										goto IL_1c6b;
																																									case 377:
																																										goto IL_1c79;
																																									case 119:
																																										goto IL_1c87;
																																									case 437:
																																										goto IL_1c9a;
																																									case 365:
																																										goto IL_1ca8;
																																									case 132:
																																									case 387:
																																										goto IL_1cb6;
																																									case 449:
																																										goto IL_1cf6;
																																									case 231:
																																										goto IL_1d0a;
																																									case 337:
																																										goto IL_1d1d;
																																									case 138:
																																										goto IL_1d2b;
																																									case 369:
																																										goto IL_1d39;
																																									case 84:
																																									case 233:
																																										goto IL_1d47;
																																									case 262:
																																										goto IL_1d5b;
																																									case 100:
																																										goto IL_1dd3;
																																									case 448:
																																										goto IL_1dea;
																																									case 21:
																																										goto IL_1e06;
																																									case 219:
																																									case 417:
																																										goto IL_1e11;
																																									case 264:
																																										goto IL_1e2b;
																																									case 416:
																																										goto IL_1e39;
																																									case 75:
																																										goto IL_1e47;
																																									case 25:
																																										goto IL_1e5a;
																																									case 153:
																																										goto IL_1e68;
																																									case 232:
																																									case 412:
																																										goto IL_1e7f;
																																									case 117:
																																										goto IL_1ea8;
																																									case 318:
																																										goto IL_1ec1;
																																									case 255:
																																										goto IL_1ecf;
																																									case 205:
																																									case 439:
																																										goto IL_1eda;
																																									case 303:
																																										goto IL_1eee;
																																									case 161:
																																										goto IL_1f2d;
																																									case 230:
																																										goto IL_1f40;
																																									case 151:
																																										goto IL_1f4b;
																																									case 43:
																																									case 381:
																																										goto IL_1f59;
																																									case 164:
																																										goto IL_1f6d;
																																									case 253:
																																										goto IL_1fac;
																																									case 88:
																																										goto IL_1fbf;
																																									case 66:
																																										goto IL_1fcd;
																																									case 91:
																																									case 373:
																																										goto IL_1fdb;
																																									case 228:
																																										goto IL_201b;
																																									case 97:
																																										goto IL_202f;
																																									case 305:
																																										goto IL_2042;
																																									case 291:
																																										goto IL_2050;
																																									case 235:
																																									case 240:
																																										goto IL_205b;
																																									case 379:
																																										goto IL_209b;
																																									case 86:
																																										goto IL_20af;
																																									case 269:
																																										goto IL_20c2;
																																									case 15:
																																										goto IL_20d0;
																																									case 65:
																																									case 261:
																																										goto IL_20de;
																																									case 293:
																																										goto IL_20fb;
																																									case 324:
																																										goto IL_2143;
																																									case 321:
																																										goto IL_2156;
																																									case 147:
																																										goto IL_2161;
																																									case 38:
																																									case 137:
																																										goto IL_216c;
																																									case 300:
																																										goto IL_2180;
																																									case 390:
																																										goto IL_21bf;
																																									case 2:
																																									case 4:
																																									case 11:
																																									case 37:
																																									case 59:
																																									case 70:
																																									case 82:
																																									case 89:
																																									case 95:
																																									case 109:
																																									case 120:
																																									case 121:
																																									case 123:
																																									case 127:
																																									case 131:
																																									case 135:
																																									case 136:
																																									case 142:
																																									case 150:
																																									case 157:
																																									case 169:
																																									case 184:
																																									case 193:
																																									case 194:
																																									case 196:
																																									case 227:
																																									case 239:
																																									case 241:
																																									case 242:
																																									case 248:
																																									case 252:
																																									case 263:
																																									case 272:
																																									case 296:
																																									case 297:
																																									case 302:
																																									case 312:
																																									case 313:
																																									case 314:
																																									case 316:
																																									case 323:
																																									case 327:
																																									case 330:
																																									case 348:
																																									case 349:
																																									case 356:
																																									case 359:
																																									case 371:
																																									case 376:
																																									case 382:
																																									case 397:
																																									case 400:
																																									case 403:
																																									case 418:
																																									case 428:
																																									case 433:
																																									case 436:
																																									case 452:
																																										goto end_IL_078b;
																																									case 0:
																																									case 8:
																																									case 9:
																																									case 16:
																																									case 28:
																																									case 30:
																																									case 32:
																																									case 46:
																																									case 49:
																																									case 54:
																																									case 63:
																																									case 76:
																																									case 83:
																																									case 93:
																																									case 101:
																																									case 102:
																																									case 104:
																																									case 107:
																																									case 113:
																																									case 126:
																																									case 129:
																																									case 130:
																																									case 139:
																																									case 141:
																																									case 144:
																																									case 149:
																																									case 156:
																																									case 168:
																																									case 172:
																																									case 175:
																																									case 178:
																																									case 182:
																																									case 197:
																																									case 198:
																																									case 202:
																																									case 216:
																																									case 223:
																																									case 224:
																																									case 249:
																																									case 271:
																																									case 279:
																																									case 284:
																																									case 301:
																																									case 332:
																																									case 341:
																																									case 350:
																																									case 353:
																																									case 361:
																																									case 370:
																																									case 391:
																																									case 393:
																																									case 405:
																																									case 408:
																																									case 415:
																																									case 421:
																																									case 422:
																																									case 451:
																																									case 455:
																																										goto IL_21e2;
																																									case 133:
																																										goto IL_21f5;
																																									case 195:
																																										goto IL_21ff;
																																									case 409:
																																										goto IL_220a;
																																									case 304:
																																										goto IL_221a;
																																									case 336:
																																										goto IL_2233;
																																									case 201:
																																										goto IL_2243;
																																									case 191:
																																										goto IL_2253;
																																									case 19:
																																										goto IL_2263;
																																									case 331:
																																										goto IL_2273;
																																									case 60:
																																										goto IL_2283;
																																									case 288:
																																										goto IL_2293;
																																									case 99:
																																									case 454:
																																										goto IL_22ae;
																																									}
																																									goto end_IL_082e;
																																								}
																																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																								goto IL_1829;
																																								IL_1829:
																																								ptr2 += 8;
																																								goto IL_21e2;
																																								continue;
																																								end_IL_0759:
																																								break;
																																							}
																																							break;
																																						}
																																						goto IL_08b0;
																																						continue;
																																						end_IL_078b:
																																						break;
																																						IL_078b:;
																																					}
																																					break;
																																					IL_079b:;
																																				}
																																				break;
																																			}
																																			goto IL_0872;
																																			IL_14cb:
																																			ptr2 += 8;
																																			goto IL_21e2;
																																			IL_0872:
																																			if (43 > b)
																																			{
																																				break;
																																			}
																																			goto IL_0ff1;
																																			IL_0ff1:
																																			array2[num6 - 1] = 3;
																																			goto IL_148c;
																																			IL_148c:
																																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																			goto IL_14cb;
																																		}
																																		break;
																																	}
																																	goto IL_08c9;
																																	IL_0947:
																																	num6--;
																																	goto IL_21e2;
																																	IL_08c9:
																																	global::_003CModule_003E.color_15 = (Color[])array3[num6 - 1];
																																	goto IL_0947;
																																}
																																break;
																															}
																															goto IL_0862;
																															IL_178b:
																															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((Color[])array3[num6 - 1]).LongLength;
																															goto IL_17b5;
																															IL_0862:
																															if (47 >= b)
																															{
																																goto IL_08e4;
																															}
																															goto IL_1766;
																															IL_08e4:
																															if (47 > b)
																															{
																																goto IL_08ef;
																															}
																															goto IL_0902;
																															IL_08ef:
																															if (46 < b)
																															{
																																break;
																															}
																															goto IL_0f87;
																															IL_0f87:
																															if (46 > b)
																															{
																																break;
																															}
																															goto IL_0f95;
																															IL_0f95:
																															array2[num6] = 0;
																															goto IL_0fa3;
																															IL_0fa3:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																															goto IL_0fc7;
																															IL_0fc7:
																															num6++;
																															num = 383;
																															goto IL_0fde;
																															IL_0fde:
																															ptr2 += 8;
																															goto IL_21e2;
																															IL_0902:
																															array3[num6] = ((delegate*<Color[]>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																															goto IL_0920;
																															IL_0920:
																															array2[num6] = 5;
																															goto IL_092e;
																															IL_092e:
																															num6++;
																															num = 385;
																															goto IL_095a;
																															IL_095a:
																															ptr2 += 8;
																															goto IL_21e2;
																															IL_1766:
																															if (48 < b)
																															{
																																break;
																															}
																															goto IL_1774;
																															IL_1774:
																															if (48 > b)
																															{
																																break;
																															}
																															num = 309;
																															goto IL_178b;
																															IL_17b5:
																															array2[num6 - 1] = 2;
																															goto IL_21e2;
																														}
																														break;
																													}
																													goto IL_0885;
																													IL_08b0:
																													array2[num6 - 1] = 0;
																													goto IL_21e2;
																													IL_0885:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_08b0;
																												}
																												break;
																											}
																											goto IL_183c;
																											IL_1ab1:
																											if (55 < b)
																											{
																												break;
																											}
																											goto IL_1abf;
																											IL_183c:
																											if (52 >= b)
																											{
																												goto IL_184a;
																											}
																											goto IL_19bc;
																											IL_184a:
																											if (52 <= b)
																											{
																												goto IL_1855;
																											}
																											goto IL_1882;
																											IL_1855:
																											global::_003CModule_003E.int_212 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_186f;
																											IL_186f:
																											num6--;
																											goto IL_21e2;
																											IL_1882:
																											if (50 >= b)
																											{
																												goto IL_188d;
																											}
																											goto IL_1902;
																											IL_188d:
																											if (50 > b)
																											{
																												break;
																											}
																											goto IL_189b;
																											IL_189b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_18db;
																											IL_18db:
																											array2[num6 - 2] = 0;
																											goto IL_18ef;
																											IL_18ef:
																											num6--;
																											goto IL_21e2;
																											IL_1902:
																											if (51 < b)
																											{
																												break;
																											}
																											goto IL_1910;
																											IL_1910:
																											if (51 > b)
																											{
																												break;
																											}
																											goto IL_191e;
																											IL_191e:
																											array2[num6 - 3] = 0;
																											goto IL_1932;
																											IL_1932:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]) = ((delegate*<int, int, int, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_199b;
																											IL_199b:
																											num6 -= 2;
																											goto IL_19a9;
																											IL_19a9:
																											ptr2 += 8;
																											goto IL_21e2;
																											IL_19bc:
																											if (54 >= b)
																											{
																												goto IL_19ca;
																											}
																											goto IL_1ab1;
																											IL_19ca:
																											if (54 > b)
																											{
																												goto IL_19d5;
																											}
																											goto IL_1a4d;
																											IL_19d5:
																											if (53 < b)
																											{
																												break;
																											}
																											num = 215;
																											goto IL_19ec;
																											IL_1abf:
																											if (55 > b)
																											{
																											}
																											break;
																											IL_19ec:
																											if (53 > b)
																											{
																												break;
																											}
																											goto IL_19fa;
																											IL_19fa:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																											goto IL_1a1e;
																											IL_1a1e:
																											array2[num6] = 0;
																											goto IL_1a2c;
																											IL_1a2c:
																											num6++;
																											goto IL_1a3a;
																											IL_1a3a:
																											ptr2 += 8;
																											goto IL_21e2;
																											IL_1a4d:
																											array3[num6 - 2] = ((Color[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																											goto IL_1a8a;
																											IL_1a8a:
																											array2[num6 - 2] = 4;
																											goto IL_1a9e;
																											IL_1a9e:
																											num6--;
																											goto IL_21e2;
																										}
																										break;
																									}
																									num = 401;
																									goto IL_1adb;
																									IL_2161:
																									if (41 > b)
																									{
																										break;
																									}
																									goto IL_216c;
																									IL_216c:
																									array2[num6 - 1] = 3;
																									goto IL_2180;
																									IL_1adb:
																									if (42 <= b)
																									{
																										goto IL_1ae6;
																									}
																									goto IL_1b4c;
																									IL_1ae6:
																									array2[num6 - 1] = 3;
																									goto IL_1afa;
																									IL_1afa:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1b39;
																									IL_1b39:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1b4c:
																									if (35 >= b)
																									{
																										goto IL_1b5a;
																									}
																									goto IL_1ec1;
																									IL_1b5a:
																									if (35 <= b)
																									{
																										goto IL_1b65;
																									}
																									goto IL_1bba;
																									IL_1b65:
																									((Color[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (Color)array3[num6 - 1];
																									goto IL_1ba7;
																									IL_1ba7:
																									num6 -= 3;
																									goto IL_21e2;
																									IL_1bba:
																									if (31 >= b)
																									{
																										goto IL_1bc8;
																									}
																									goto IL_1d1d;
																									IL_1bc8:
																									if (31 <= b)
																									{
																										goto IL_1bd3;
																									}
																									goto IL_1c39;
																									IL_1bd3:
																									array2[num6 - 1] = 0;
																									goto IL_1be7;
																									IL_1be7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1c26;
																									IL_1c26:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1c39:
																									if (29 >= b)
																									{
																										goto IL_1c44;
																									}
																									goto IL_1c9a;
																									IL_1c44:
																									if (29 > b)
																									{
																										break;
																									}
																									goto IL_1c52;
																									IL_1c52:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																									goto IL_1c6b;
																									IL_1c6b:
																									array2[num6] = 3;
																									goto IL_1c79;
																									IL_1c79:
																									num6++;
																									goto IL_1c87;
																									IL_1c87:
																									ptr2 += 16;
																									goto IL_21e2;
																									IL_1c9a:
																									if (30 < b)
																									{
																										break;
																									}
																									goto IL_1ca8;
																									IL_1ca8:
																									if (30 > b)
																									{
																										break;
																									}
																									goto IL_1cb6;
																									IL_1cb6:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_1cf6;
																									IL_1cf6:
																									array2[num6 - 2] = 3;
																									goto IL_1d0a;
																									IL_1d0a:
																									num6--;
																									goto IL_21e2;
																									IL_1d1d:
																									if (33 < b)
																									{
																										goto IL_1d2b;
																									}
																									num = 21;
																									goto IL_1e06;
																									IL_1d2b:
																									if (34 < b)
																									{
																										break;
																									}
																									goto IL_1d39;
																									IL_1d39:
																									if (34 > b)
																									{
																										break;
																									}
																									goto IL_1d47;
																									IL_1d47:
																									array2[num6 - 4] = 5;
																									goto IL_1d5b;
																									IL_1d5b:
																									array3[num6 - 4] = ((delegate*<float, float, float, float, object>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																									goto IL_1dd3;
																									IL_1dd3:
																									num6 -= 3;
																									num = 448;
																									goto IL_1dea;
																									IL_1dea:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_2180:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_21bf;
																									IL_1e06:
																									if (33 <= b)
																									{
																										goto IL_1e11;
																									}
																									goto IL_1e5a;
																									IL_1e11:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																									goto IL_1e2b;
																									IL_1e2b:
																									array2[num6] = 3;
																									goto IL_1e39;
																									IL_1e39:
																									num6++;
																									goto IL_1e47;
																									IL_1e47:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1e5a:
																									if (32 < b)
																									{
																										break;
																									}
																									goto IL_1e68;
																									IL_1e68:
																									if (32 > b)
																									{
																										break;
																									}
																									num = 412;
																									goto IL_1e7f;
																									IL_21bf:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1e7f:
																									array3[num6 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_1ea8;
																									IL_1ea8:
																									array2[num6 - 1] = 5;
																									goto IL_21e2;
																									IL_1ec1:
																									if (38 >= b)
																									{
																										goto IL_1ecf;
																									}
																									goto IL_2042;
																									IL_1ecf:
																									if (38 <= b)
																									{
																										goto IL_1eda;
																									}
																									goto IL_1f40;
																									IL_1eda:
																									array2[num6 - 1] = 0;
																									goto IL_1eee;
																									IL_1eee:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1f2d;
																									IL_1f2d:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1f40:
																									if (36 >= b)
																									{
																										goto IL_1f4b;
																									}
																									goto IL_1fbf;
																									IL_1f4b:
																									if (36 > b)
																									{
																										break;
																									}
																									goto IL_1f59;
																									IL_1f59:
																									array2[num6 - 1] = 3;
																									goto IL_1f6d;
																									IL_1f6d:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_1fac;
																									IL_1fac:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_1fbf:
																									if (37 < b)
																									{
																										break;
																									}
																									goto IL_1fcd;
																									IL_1fcd:
																									if (37 > b)
																									{
																										break;
																									}
																									goto IL_1fdb;
																									IL_1fdb:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_201b;
																									IL_201b:
																									array2[num6 - 2] = 3;
																									goto IL_202f;
																									IL_202f:
																									num6--;
																									goto IL_21e2;
																									IL_2042:
																									if (40 >= b)
																									{
																										goto IL_2050;
																									}
																									goto IL_2156;
																									IL_2050:
																									if (40 <= b)
																									{
																										goto IL_205b;
																									}
																									goto IL_20c2;
																									IL_205b:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_209b;
																									IL_209b:
																									array2[num6 - 2] = 3;
																									goto IL_20af;
																									IL_20af:
																									num6--;
																									goto IL_21e2;
																									IL_20c2:
																									if (39 < b)
																									{
																										break;
																									}
																									goto IL_20d0;
																									IL_20d0:
																									if (39 > b)
																									{
																										break;
																									}
																									goto IL_20de;
																									IL_20de:
																									array2[num6 - 1] = 3;
																									num = 293;
																									goto IL_20fb;
																									IL_20fb:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									num = 324;
																									goto IL_2143;
																									IL_2143:
																									ptr2 += 8;
																									goto IL_21e2;
																									IL_2156:
																									if (41 < b)
																									{
																										break;
																									}
																									goto IL_2161;
																								}
																								break;
																							}
																							goto IL_096d;
																							IL_126f:
																							num6++;
																							goto IL_127d;
																							IL_096d:
																							if (28 <= b)
																							{
																								goto IL_0978;
																							}
																							goto IL_0994;
																							IL_0978:
																							num7 = ptr2;
																							num8 = -200;
																							num5 = 1;
																							ptr2 = num7 + num8;
																							goto IL_21e2;
																							IL_0994:
																							if (14 >= b)
																							{
																								goto IL_09a2;
																							}
																							goto IL_0cf5;
																							IL_09a2:
																							if (14 > b)
																							{
																								goto IL_09b0;
																							}
																							goto IL_14de;
																							IL_09b0:
																							if (7 < b)
																							{
																								goto IL_09be;
																							}
																							goto IL_0ad2;
																							IL_09be:
																							if (10 < b)
																							{
																								goto IL_09c9;
																							}
																							num = 42;
																							goto IL_09f3;
																							IL_09c9:
																							if (12 < b)
																							{
																								goto IL_09d7;
																							}
																							goto IL_0ecf;
																							IL_09d7:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_167e;
																							IL_167e:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_168c;
																							IL_168c:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_169b;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_1743;
																							IL_1290:
																							if (22 >= b)
																							{
																								goto IL_129b;
																							}
																							goto IL_131a;
																							IL_129b:
																							if (22 > b)
																							{
																								break;
																							}
																							num = 210;
																							goto IL_12b2;
																							IL_15fb:
																							num6--;
																							num = 104;
																							goto IL_21e2;
																							IL_1743:
																							array2[num6] = 5;
																							goto IL_17ce;
																							IL_17ce:
																							num6++;
																							num = 76;
																							goto IL_21e2;
																							IL_0ecf:
																							if (12 <= b)
																							{
																								goto IL_21e2;
																							}
																							goto IL_0edd;
																							IL_0edd:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0eeb;
																							IL_0eeb:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_0ef9;
																							IL_0ef9:
																							array2[num6 - 2] = 0;
																							goto IL_0f0d;
																							IL_0f0d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0f61;
																							IL_0f61:
																							num6--;
																							goto IL_1189;
																							IL_1189:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_127d:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_09f3:
																							if (10 > b)
																							{
																								goto IL_09fe;
																							}
																							num = 68;
																							goto IL_0a5d;
																							IL_09fe:
																							if (8 >= b)
																							{
																								goto IL_0a09;
																							}
																							goto IL_0a2a;
																							IL_0a09:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0a17;
																							IL_0a17:
																							num6--;
																							goto IL_21e2;
																							IL_0a2a:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_0a38;
																							IL_0a38:
																							if (9 > b)
																							{
																								break;
																							}
																							num = 425;
																							goto IL_1130;
																							IL_12f3:
																							array2[num6 - 2] = 0;
																							goto IL_1307;
																							IL_1130:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1170;
																							IL_1170:
																							array2[num6 - 2] = 0;
																							goto IL_132d;
																							IL_132d:
																							num6--;
																							num = 130;
																							goto IL_21e2;
																							IL_12b2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_12f3;
																							IL_0a5d:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0abf;
																							IL_0abf:
																							num6 -= 2;
																							goto IL_21e2;
																							IL_0ad2:
																							if (7 <= b)
																							{
																								goto IL_0add;
																							}
																							goto IL_0b44;
																							IL_0add:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0b1d;
																							IL_0b1d:
																							array2[num6 - 2] = 0;
																							goto IL_0b31;
																							IL_0b31:
																							num6--;
																							goto IL_21e2;
																							IL_0b44:
																							if (3 >= b)
																							{
																								goto IL_0b52;
																							}
																							goto IL_0bd8;
																							IL_0b52:
																							if (3 <= b)
																							{
																								goto IL_0b5d;
																							}
																							goto IL_0ba7;
																							IL_0b5d:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0b86;
																							IL_0b86:
																							ptr2 += 8;
																							goto IL_0b94;
																							IL_0b94:
																							num6--;
																							goto IL_21e2;
																							IL_0ba7:
																							if (1 >= b)
																							{
																								goto IL_0bb2;
																							}
																							goto IL_0bc5;
																							IL_0bb2:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_1349;
																							IL_1349:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_1362;
																							IL_1362:
																							array2[num6] = 0;
																							goto IL_1370;
																							IL_1370:
																							num6++;
																							goto IL_137e;
																							IL_137e:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_0bc5:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_1526;
																							IL_1526:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_1534;
																							IL_1534:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1574;
																							IL_1574:
																							array2[num6 - 2] = 0;
																							goto IL_1588;
																							IL_1588:
																							num6--;
																							goto IL_21e2;
																							IL_0bd8:
																							if (5 >= b)
																							{
																								goto IL_0be6;
																							}
																							goto IL_0cd4;
																							IL_0be6:
																							if (5 <= b)
																							{
																								goto IL_0bf1;
																							}
																							goto IL_0c61;
																							IL_0bf1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0c31;
																							IL_0c31:
																							array2[num6 - 2] = 0;
																							goto IL_0c45;
																							IL_0c45:
																							num6--;
																							num = 361;
																							goto IL_21e2;
																							IL_0c61:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0c6f;
																							IL_0c6f:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0c7d;
																							IL_0c7d:
																							array2[num6] = 0;
																							goto IL_0c8b;
																							IL_0c8b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0cae;
																							IL_0cae:
																							array3[num6] = null;
																							goto IL_0cb8;
																							IL_0cb8:
																							num6++;
																							num = 394;
																							goto IL_0f74;
																							IL_0f74:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_0cd4:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0ce2;
																							IL_0ce2:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_1617;
																							IL_1617:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1657;
																							IL_1657:
																							array2[num6 - 2] = 0;
																							goto IL_166b;
																							IL_166b:
																							num6--;
																							goto IL_21e2;
																							IL_14de:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_14fc;
																							IL_14fc:
																							ptr2 += 8;
																							num = 51;
																							goto IL_1513;
																							IL_1513:
																							num6--;
																							goto IL_21e2;
																							IL_0cf5:
																							if (21 >= b)
																							{
																								goto IL_0d03;
																							}
																							goto IL_119c;
																							IL_0d03:
																							if (21 <= b)
																							{
																								goto IL_0d0e;
																							}
																							goto IL_0d26;
																							IL_0d0e:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_21e2;
																							IL_0d26:
																							if (17 < b)
																							{
																								goto IL_0d34;
																							}
																							num = 47;
																							goto IL_0e3c;
																							IL_0d34:
																							if (19 >= b)
																							{
																								goto IL_0d42;
																							}
																							goto IL_0dc6;
																							IL_0d42:
																							if (19 > b)
																							{
																								goto IL_0d50;
																							}
																							goto IL_10d1;
																							IL_0d50:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_0d5e;
																							IL_0d5e:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0d6c;
																							IL_0d6c:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							num = 118;
																							goto IL_0db3;
																							IL_0db3:
																							num6 -= 3;
																							goto IL_21e2;
																							IL_10d1:
																							array2[num6 - 1] = 5;
																							goto IL_10e5;
																							IL_10e5:
																							array3[num6 - 1] = ((delegate*<string[], string>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_111d;
																							IL_111d:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_0dc6:
																							if (20 < b)
																							{
																								break;
																							}
																							goto IL_0dd4;
																							IL_0dd4:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_0de2;
																							IL_0de2:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0dfb;
																							IL_0dfb:
																							array2[num6] = 1;
																							num = 352;
																							goto IL_0e12;
																							IL_0e12:
																							num6++;
																							goto IL_0e20;
																							IL_0e20:
																							ptr2 += 16;
																							goto IL_21e2;
																							IL_1307:
																							num6--;
																							goto IL_21e2;
																							IL_0e3c:
																							if (17 > b)
																							{
																								goto IL_0e4a;
																							}
																							goto IL_108a;
																							IL_0e4a:
																							if (15 >= b)
																							{
																								goto IL_0e55;
																							}
																							goto IL_0ea5;
																							IL_0e55:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0e63;
																							IL_0e63:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0e8c;
																							IL_0e8c:
																							array2[num6 - 1] = 5;
																							goto IL_21e2;
																							IL_0ea5:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0eb3;
																							IL_0eb3:
																							if (16 > b)
																							{
																								break;
																							}
																							num = 407;
																							goto IL_100a;
																							IL_131a:
																							if (23 < b)
																							{
																								break;
																							}
																							goto IL_159b;
																							IL_100a:
																							array2[num6] = array2[num6 - 1];
																							goto IL_1022;
																							IL_1022:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_1040;
																							IL_1040:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1064;
																							IL_1064:
																							array3[num6] = array3[num6 - 1];
																							num = 446;
																							goto IL_1753;
																							IL_1753:
																							num6++;
																							goto IL_21e2;
																							IL_108a:
																							array2[num6] = 5;
																							goto IL_1098;
																							IL_1098:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_10b0;
																							IL_10b0:
																							num6++;
																							goto IL_10be;
																							IL_10be:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_119c:
																							if (24 < b)
																							{
																								goto IL_11aa;
																							}
																							num = 311;
																							goto IL_1238;
																							IL_11aa:
																							if (26 < b)
																							{
																								goto IL_11b8;
																							}
																							goto IL_1391;
																							IL_11b8:
																							if (27 < b)
																							{
																								break;
																							}
																							goto IL_11c6;
																							IL_11c6:
																							if (27 > b)
																							{
																								break;
																							}
																							num = 402;
																							goto IL_11dd;
																							IL_15a9:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_15fb;
																							IL_11dd:
																							array2[num6] = 4;
																							goto IL_11eb;
																							IL_11eb:
																							array3[num6] = ((delegate*<Color>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																							goto IL_120e;
																							IL_120e:
																							num6++;
																							goto IL_121c;
																							IL_121c:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_1391:
																							if (26 <= b)
																							{
																								goto IL_139c;
																							}
																							goto IL_13e9;
																							IL_139c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 392;
																							goto IL_13d0;
																							IL_13d0:
																							array2[num6 - 1] = 0;
																							goto IL_21e2;
																							IL_13e9:
																							if (25 < b)
																							{
																								break;
																							}
																							goto IL_13f7;
																							IL_13f7:
																							if (25 > b)
																							{
																								break;
																							}
																							goto IL_1405;
																							IL_1405:
																							array2[num6 - 2] = 0;
																							goto IL_1419;
																							IL_1419:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																							goto IL_146b;
																							IL_146b:
																							num6--;
																							goto IL_1479;
																							IL_1479:
																							ptr2 += 8;
																							goto IL_21e2;
																							IL_159b:
																							if (23 > b)
																							{
																								break;
																							}
																							goto IL_15a9;
																							IL_1238:
																							if (24 <= b)
																							{
																								goto IL_1243;
																							}
																							goto IL_1290;
																							IL_1243:
																							array2[num6] = 5;
																							goto IL_1251;
																							IL_1251:
																							array3[num6] = ((delegate*<string>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																							goto IL_126f;
																						}
																						break;
																						IL_081e:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_21e2;
																				continue;
																				end_IL_082e:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_22ae;
																IL_22ae:
																return (Color)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_169b:
			while (true)
			{
				IL_169b_2:
				array = new byte[4];
				while (true)
				{
					IL_16a9:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_17ce_2:
							num6++;
							num = 76;
							while (true)
							{
								IL_21e2_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										num = 179;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_082e_2:
												if (b >= 1)
												{
													while (b <= 55)
													{
														while (true)
														{
															IL_080e_2:
															if (28 < b)
															{
																while (true)
																{
																	IL_07fe_2:
																	if (42 < b)
																	{
																		while (true)
																		{
																			IL_07ee_2:
																			if (49 >= b)
																			{
																				while (true)
																				{
																					IL_07de_2:
																					if (49 > b)
																					{
																						while (true)
																						{
																							IL_07ce_2:
																							if (45 >= b)
																							{
																								while (true)
																								{
																									IL_07be_2:
																									if (45 > b)
																									{
																										while (true)
																										{
																											IL_07ae_2:
																											if (43 < b)
																											{
																												while (44 >= b)
																												{
																													num = 145;
																													while (44 <= b)
																													{
																														while (true)
																														{
																															IL_076c_2:
																															array2[num6 - 1] = 3;
																															num = 463;
																															while (true)
																															{
																																if (num != 463)
																																{
																																	if (num != 1444)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 185:
																																	case 222:
																																		goto IL_076c_2;
																																	case 145:
																																		goto IL_078b_2;
																																	case 430:
																																		goto IL_079b_2;
																																	case 374:
																																		goto IL_07ae_2;
																																	case 358:
																																		goto IL_07be_2;
																																	case 189:
																																		goto IL_07ce_2;
																																	case 5:
																																		goto IL_07de_2;
																																	case 234:
																																		goto IL_07ee_2;
																																	case 26:
																																		goto IL_07fe_2;
																																	case 335:
																																		goto IL_080e_2;
																																	case 338:
																																		goto IL_081e_2;
																																	case 177:
																																		goto IL_082e_2;
																																	case 179:
																																		goto end_IL_082e_2;
																																	case 55:
																																	case 159:
																																		goto end_IL_083e;
																																	case 35:
																																		goto IL_0862_2;
																																	case 41:
																																		goto IL_0872_2;
																																	case 3:
																																	case 124:
																																		goto IL_0885_2;
																																	case 112:
																																		goto end_IL_0759_2;
																																	case 110:
																																	case 287:
																																		goto IL_08c9_2;
																																	case 310:
																																		goto IL_08e4_2;
																																	case 244:
																																		goto IL_08ef_2;
																																	case 94:
																																	case 128:
																																		goto IL_0902_2;
																																	case 251:
																																		goto IL_0920_2;
																																	case 78:
																																		goto IL_092e_2;
																																	case 317:
																																		goto IL_0947_2;
																																	case 385:
																																		goto IL_095a_2;
																																	case 386:
																																		goto IL_096d_2;
																																	case 186:
																																	case 306:
																																		goto IL_0978_2;
																																	case 368:
																																		goto IL_0994_2;
																																	case 190:
																																		goto IL_09a2_2;
																																	case 246:
																																		goto IL_09b0_2;
																																	case 275:
																																		goto IL_09be_2;
																																	case 380:
																																		goto IL_09c9_2;
																																	case 221:
																																		goto IL_09d7_2;
																																	case 42:
																																		goto IL_09f3_2;
																																	case 27:
																																		goto IL_09fe_2;
																																	case 211:
																																		goto IL_0a09_2;
																																	case 111:
																																	case 199:
																																		goto IL_0a17_2;
																																	case 134:
																																		goto IL_0a2a_2;
																																	case 23:
																																		goto IL_0a38_2;
																																	case 68:
																																	case 106:
																																		goto IL_0a5d_2;
																																	case 92:
																																		goto IL_0abf_2;
																																	case 344:
																																		goto IL_0ad2_2;
																																	case 155:
																																	case 334:
																																		goto IL_0add_2;
																																	case 96:
																																		goto IL_0b1d_2;
																																	case 24:
																																		goto IL_0b31_2;
																																	case 7:
																																		goto IL_0b44_2;
																																	case 204:
																																		goto IL_0b52_2;
																																	case 12:
																																	case 17:
																																		goto IL_0b5d_2;
																																	case 103:
																																		goto IL_0b86_2;
																																	case 1:
																																		goto IL_0b94_2;
																																	case 71:
																																		goto IL_0ba7_2;
																																	case 238:
																																		goto IL_0bb2_2;
																																	case 62:
																																		goto IL_0bc5_2;
																																	case 268:
																																		goto IL_0bd8_2;
																																	case 20:
																																		goto IL_0be6_2;
																																	case 56:
																																	case 174:
																																		goto IL_0bf1_2;
																																	case 333:
																																		goto IL_0c31_2;
																																	case 278:
																																		goto IL_0c45_2;
																																	case 217:
																																		goto IL_0c61_2;
																																	case 281:
																																		goto IL_0c6f_2;
																																	case 13:
																																	case 203:
																																		goto IL_0c7d_2;
																																	case 270:
																																		goto IL_0c8b_2;
																																	case 115:
																																		goto IL_0cae_2;
																																	case 171:
																																		goto IL_0cb8_2;
																																	case 375:
																																		goto IL_0cd4_2;
																																	case 259:
																																		goto IL_0ce2_2;
																																	case 307:
																																		goto IL_0cf5_2;
																																	case 79:
																																		goto IL_0d03_2;
																																	case 265:
																																	case 295:
																																		goto IL_0d0e_2;
																																	case 320:
																																		goto IL_0d26_2;
																																	case 351:
																																		goto IL_0d34_2;
																																	case 85:
																																		goto IL_0d42_2;
																																	case 73:
																																		goto IL_0d50_2;
																																	case 345:
																																		goto IL_0d5e_2;
																																	case 346:
																																	case 362:
																																		goto IL_0d6c_2;
																																	case 118:
																																		goto IL_0db3_2;
																																	case 286:
																																		goto IL_0dc6_2;
																																	case 329:
																																		goto IL_0dd4_2;
																																	case 163:
																																	case 277:
																																		goto IL_0de2_2;
																																	case 384:
																																		goto IL_0dfb_2;
																																	case 352:
																																		goto IL_0e12_2;
																																	case 140:
																																		goto IL_0e20_2;
																																	case 47:
																																		goto IL_0e3c_2;
																																	case 267:
																																		goto IL_0e4a_2;
																																	case 80:
																																		goto IL_0e55_2;
																																	case 214:
																																	case 292:
																																		goto IL_0e63_2;
																																	case 34:
																																		goto IL_0e8c_2;
																																	case 77:
																																		goto IL_0ea5_2;
																																	case 18:
																																		goto IL_0eb3_2;
																																	case 388:
																																		goto IL_0ecf_2;
																																	case 90:
																																		goto IL_0edd_2;
																																	case 152:
																																		goto IL_0eeb_2;
																																	case 36:
																																	case 285:
																																		goto IL_0ef9_2;
																																	case 31:
																																		goto IL_0f0d_2;
																																	case 294:
																																		goto IL_0f61_2;
																																	case 394:
																																		goto IL_0f74_2;
																																	case 395:
																																		goto IL_0f87_2;
																																	case 207:
																																	case 212:
																																		goto IL_0f95_2;
																																	case 247:
																																		goto IL_0fa3_2;
																																	case 148:
																																		goto IL_0fc7_2;
																																	case 383:
																																		goto IL_0fde_2;
																																	case 170:
																																	case 399:
																																		goto IL_0ff1_2;
																																	case 61:
																																	case 407:
																																		goto IL_100a_2;
																																	case 74:
																																		goto IL_1022_2;
																																	case 236:
																																		goto IL_1040_2;
																																	case 260:
																																		goto IL_1064_2;
																																	case 354:
																																	case 414:
																																		goto IL_108a_2;
																																	case 254:
																																		goto IL_1098_2;
																																	case 122:
																																		goto IL_10b0_2;
																																	case 39:
																																		goto IL_10be_2;
																																	case 187:
																																	case 423:
																																		goto IL_10d1_2;
																																	case 200:
																																		goto IL_10e5_2;
																																	case 105:
																																		goto IL_111d_2;
																																	case 257:
																																	case 425:
																																		goto IL_1130_2;
																																	case 406:
																																		goto IL_1170_2;
																																	case 426:
																																		goto IL_1189_2;
																																	case 429:
																																		goto IL_119c_2;
																																	case 160:
																																		goto IL_11aa_2;
																																	case 225:
																																		goto IL_11b8_2;
																																	case 398:
																																		goto IL_11c6_2;
																																	case 40:
																																	case 402:
																																		goto IL_11dd_2;
																																	case 411:
																																		goto IL_11eb_2;
																																	case 72:
																																		goto IL_120e_2;
																																	case 209:
																																		goto IL_121c_2;
																																	case 311:
																																		goto IL_1238_2;
																																	case 226:
																																	case 282:
																																		goto IL_1243_2;
																																	case 162:
																																		goto IL_1251_2;
																																	case 396:
																																		goto IL_126f_2;
																																	case 250:
																																		goto IL_127d_2;
																																	case 325:
																																		goto IL_1290_2;
																																	case 298:
																																		goto IL_129b_2;
																																	case 176:
																																	case 210:
																																		goto IL_12b2_2;
																																	case 173:
																																		goto IL_12f3_2;
																																	case 192:
																																		goto IL_1307_2;
																																	case 413:
																																		goto IL_131a_2;
																																	case 431:
																																		goto IL_132d_2;
																																	case 420:
																																	case 434:
																																		goto IL_1349_2;
																																	case 326:
																																		goto IL_1362_2;
																																	case 146:
																																		goto IL_1370_2;
																																	case 378:
																																		goto IL_137e_2;
																																	case 435:
																																		goto IL_1391_2;
																																	case 10:
																																	case 366:
																																		goto IL_139c_2;
																																	case 392:
																																		goto IL_13d0_2;
																																	case 229:
																																		goto IL_13e9_2;
																																	case 340:
																																		goto IL_13f7_2;
																																	case 167:
																																	case 206:
																																		goto IL_1405_2;
																																	case 154:
																																		goto IL_1419_2;
																																	case 116:
																																		goto IL_146b_2;
																																	case 6:
																																		goto IL_1479_2;
																																	case 440:
																																		goto IL_148c_2;
																																	case 57:
																																		goto IL_14cb_2;
																																	case 274:
																																	case 441:
																																		goto IL_14de_2;
																																	case 29:
																																		goto IL_14fc_2;
																																	case 51:
																																		goto IL_1513_2;
																																	case 442:
																																		goto IL_1526_2;
																																	case 64:
																																	case 87:
																																		goto IL_1534_2;
																																	case 347:
																																		goto IL_1574_2;
																																	case 213:
																																		goto IL_1588_2;
																																	case 443:
																																		goto IL_159b_2;
																																	case 339:
																																	case 432:
																																		goto IL_15a9_2;
																																	case 258:
																																		goto IL_15fb_2;
																																	case 44:
																																	case 444:
																																		goto IL_1617_2;
																																	case 166:
																																		goto IL_1657_2;
																																	case 360:
																																		goto IL_166b_2;
																																	case 445:
																																		goto IL_167e_2;
																																	case 125:
																																	case 180:
																																		goto IL_168c_2;
																																	case 45:
																																		goto end_IL_084e;
																																	case 446:
																																		goto IL_1753_2;
																																	case 450:
																																		goto IL_1766_2;
																																	case 315:
																																		goto IL_1774_2;
																																	case 14:
																																	case 309:
																																		goto IL_178b_2;
																																	case 299:
																																		goto IL_17b5_2;
																																	case 456:
																																		goto IL_17ce_2;
																																	case 357:
																																		goto IL_1829_2;
																																	case 218:
																																		goto IL_183c_2;
																																	case 53:
																																		goto IL_184a_2;
																																	case 48:
																																	case 280:
																																		goto IL_1855_2;
																																	case 237:
																																		goto IL_186f_2;
																																	case 319:
																																		goto IL_1882_2;
																																	case 389:
																																		goto IL_188d_2;
																																	case 220:
																																	case 343:
																																		goto IL_189b_2;
																																	case 438:
																																		goto IL_18db_2;
																																	case 58:
																																		goto IL_18ef_2;
																																	case 453:
																																		goto IL_1902_2;
																																	case 447:
																																		goto IL_1910_2;
																																	case 67:
																																	case 424:
																																		goto IL_191e_2;
																																	case 364:
																																		goto IL_1932_2;
																																	case 256:
																																		goto IL_199b_2;
																																	case 355:
																																		goto IL_19a9_2;
																																	case 69:
																																		goto IL_19bc_2;
																																	case 165:
																																		goto IL_19ca_2;
																																	case 183:
																																		goto IL_19d5_2;
																																	case 215:
																																		goto IL_19ec_2;
																																	case 114:
																																	case 372:
																																		goto IL_19fa_2;
																																	case 419:
																																		goto IL_1a1e_2;
																																	case 367:
																																		goto IL_1a2c_2;
																																	case 158:
																																		goto IL_1a3a_2;
																																	case 33:
																																	case 410:
																																		goto IL_1a4d_2;
																																	case 276:
																																		goto IL_1a8a_2;
																																	case 273:
																																		goto IL_1a9e_2;
																																	case 81:
																																		goto IL_1ab1_2;
																																	case 290:
																																		goto IL_1abf_2;
																																	case 401:
																																		goto IL_1adb_2;
																																	case 181:
																																	case 283:
																																		goto IL_1ae6_2;
																																	case 50:
																																		goto IL_1afa_2;
																																	case 427:
																																		goto IL_1b39_2;
																																	case 143:
																																		goto IL_1b4c_2;
																																	case 363:
																																		goto IL_1b5a_2;
																																	case 243:
																																	case 322:
																																		goto IL_1b65_2;
																																	case 208:
																																		goto IL_1ba7_2;
																																	case 98:
																																		goto IL_1bba_2;
																																	case 108:
																																		goto IL_1bc8_2;
																																	case 22:
																																	case 308:
																																		goto IL_1bd3_2;
																																	case 245:
																																		goto IL_1be7_2;
																																	case 404:
																																		goto IL_1c26_2;
																																	case 342:
																																		goto IL_1c39_2;
																																	case 266:
																																		goto IL_1c44_2;
																																	case 52:
																																	case 328:
																																		goto IL_1c52_2;
																																	case 188:
																																		goto IL_1c6b_2;
																																	case 377:
																																		goto IL_1c79_2;
																																	case 119:
																																		goto IL_1c87_2;
																																	case 437:
																																		goto IL_1c9a_2;
																																	case 365:
																																		goto IL_1ca8_2;
																																	case 132:
																																	case 387:
																																		goto IL_1cb6_2;
																																	case 449:
																																		goto IL_1cf6_2;
																																	case 231:
																																		goto IL_1d0a_2;
																																	case 337:
																																		goto IL_1d1d_2;
																																	case 138:
																																		goto IL_1d2b_2;
																																	case 369:
																																		goto IL_1d39_2;
																																	case 84:
																																	case 233:
																																		goto IL_1d47_2;
																																	case 262:
																																		goto IL_1d5b_2;
																																	case 100:
																																		goto IL_1dd3_2;
																																	case 448:
																																		goto IL_1dea_2;
																																	case 21:
																																		goto IL_1e06_2;
																																	case 219:
																																	case 417:
																																		goto IL_1e11_2;
																																	case 264:
																																		goto IL_1e2b_2;
																																	case 416:
																																		goto IL_1e39_2;
																																	case 75:
																																		goto IL_1e47_2;
																																	case 25:
																																		goto IL_1e5a_2;
																																	case 153:
																																		goto IL_1e68_2;
																																	case 232:
																																	case 412:
																																		goto IL_1e7f_2;
																																	case 117:
																																		goto IL_1ea8_2;
																																	case 318:
																																		goto IL_1ec1_2;
																																	case 255:
																																		goto IL_1ecf_2;
																																	case 205:
																																	case 439:
																																		goto IL_1eda_2;
																																	case 303:
																																		goto IL_1eee_2;
																																	case 161:
																																		goto IL_1f2d_2;
																																	case 230:
																																		goto IL_1f40_2;
																																	case 151:
																																		goto IL_1f4b_2;
																																	case 43:
																																	case 381:
																																		goto IL_1f59_2;
																																	case 164:
																																		goto IL_1f6d_2;
																																	case 253:
																																		goto IL_1fac_2;
																																	case 88:
																																		goto IL_1fbf_2;
																																	case 66:
																																		goto IL_1fcd_2;
																																	case 91:
																																	case 373:
																																		goto IL_1fdb_2;
																																	case 228:
																																		goto IL_201b_2;
																																	case 97:
																																		goto IL_202f_2;
																																	case 305:
																																		goto IL_2042_2;
																																	case 291:
																																		goto IL_2050_2;
																																	case 235:
																																	case 240:
																																		goto IL_205b_2;
																																	case 379:
																																		goto IL_209b_2;
																																	case 86:
																																		goto IL_20af_2;
																																	case 269:
																																		goto IL_20c2_2;
																																	case 15:
																																		goto IL_20d0_2;
																																	case 65:
																																	case 261:
																																		goto IL_20de_2;
																																	case 293:
																																		goto IL_20fb_2;
																																	case 324:
																																		goto IL_2143_2;
																																	case 321:
																																		goto IL_2156_2;
																																	case 147:
																																		goto IL_2161_2;
																																	case 38:
																																	case 137:
																																		goto IL_216c_2;
																																	case 300:
																																		goto IL_2180_2;
																																	case 390:
																																		goto IL_21bf_2;
																																	case 2:
																																	case 4:
																																	case 11:
																																	case 37:
																																	case 59:
																																	case 70:
																																	case 82:
																																	case 89:
																																	case 95:
																																	case 109:
																																	case 120:
																																	case 121:
																																	case 123:
																																	case 127:
																																	case 131:
																																	case 135:
																																	case 136:
																																	case 142:
																																	case 150:
																																	case 157:
																																	case 169:
																																	case 184:
																																	case 193:
																																	case 194:
																																	case 196:
																																	case 227:
																																	case 239:
																																	case 241:
																																	case 242:
																																	case 248:
																																	case 252:
																																	case 263:
																																	case 272:
																																	case 296:
																																	case 297:
																																	case 302:
																																	case 312:
																																	case 313:
																																	case 314:
																																	case 316:
																																	case 323:
																																	case 327:
																																	case 330:
																																	case 348:
																																	case 349:
																																	case 356:
																																	case 359:
																																	case 371:
																																	case 376:
																																	case 382:
																																	case 397:
																																	case 400:
																																	case 403:
																																	case 418:
																																	case 428:
																																	case 433:
																																	case 436:
																																	case 452:
																																		goto end_IL_078b_2;
																																	case 0:
																																	case 8:
																																	case 9:
																																	case 16:
																																	case 28:
																																	case 30:
																																	case 32:
																																	case 46:
																																	case 49:
																																	case 54:
																																	case 63:
																																	case 76:
																																	case 83:
																																	case 93:
																																	case 101:
																																	case 102:
																																	case 104:
																																	case 107:
																																	case 113:
																																	case 126:
																																	case 129:
																																	case 130:
																																	case 139:
																																	case 141:
																																	case 144:
																																	case 149:
																																	case 156:
																																	case 168:
																																	case 172:
																																	case 175:
																																	case 178:
																																	case 182:
																																	case 197:
																																	case 198:
																																	case 202:
																																	case 216:
																																	case 223:
																																	case 224:
																																	case 249:
																																	case 271:
																																	case 279:
																																	case 284:
																																	case 301:
																																	case 332:
																																	case 341:
																																	case 350:
																																	case 353:
																																	case 361:
																																	case 370:
																																	case 391:
																																	case 393:
																																	case 405:
																																	case 408:
																																	case 415:
																																	case 421:
																																	case 422:
																																	case 451:
																																	case 455:
																																		goto IL_21e2_2;
																																	case 133:
																																		ptr2 = ptr;
																																		goto IL_21e2_2;
																																	case 195:
																																		ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExecuteAssemblyByNamegetRegisteredChannels.getInformationalVersiongetStackBehaviourPush);
																																		goto case 133;
																																	case 409:
																																		array7 = new object[8];
																																		goto case 195;
																																	case 304:
																																		array6 = new long[7];
																																		num = 409;
																																		goto case 409;
																																	case 336:
																																		array5 = new int[7];
																																		goto case 304;
																																	case 201:
																																		array4 = new int[7];
																																		goto case 336;
																																	case 191:
																																		array3 = new object[7];
																																		goto case 201;
																																	case 19:
																																		array2 = new byte[7];
																																		goto case 191;
																																	case 331:
																																		num4 = num2 * 8;
																																		goto case 19;
																																	case 60:
																																		num3 = num2 * 4;
																																		goto case 331;
																																	case 288:
																																		num2 = 1;
																																		goto case 60;
																																	case 289:
																																		goto end_IL_1743;
																																	case 99:
																																	case 454:
																																		goto IL_22ae_2;
																																	}
																																	continue;
																																}
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																goto IL_1829_2;
																																IL_1829_2:
																																ptr2 += 8;
																																goto IL_21e2_2;
																																continue;
																																end_IL_0759_2:
																																break;
																															}
																															break;
																														}
																														goto IL_08b0_2;
																														continue;
																														end_IL_078b_2:
																														break;
																														IL_078b_2:;
																													}
																													break;
																													IL_079b_2:;
																												}
																												break;
																											}
																											goto IL_0872_2;
																											IL_14cb_2:
																											ptr2 += 8;
																											goto IL_21e2_2;
																											IL_0872_2:
																											if (43 > b)
																											{
																												break;
																											}
																											goto IL_0ff1_2;
																											IL_0ff1_2:
																											array2[num6 - 1] = 3;
																											goto IL_148c_2;
																											IL_148c_2:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_14cb_2;
																										}
																										break;
																									}
																									goto IL_08c9_2;
																									IL_0947_2:
																									num6--;
																									goto IL_21e2_2;
																									IL_08c9_2:
																									global::_003CModule_003E.color_15 = (Color[])array3[num6 - 1];
																									goto IL_0947_2;
																								}
																								break;
																							}
																							goto IL_0862_2;
																							IL_178b_2:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((Color[])array3[num6 - 1]).LongLength;
																							goto IL_17b5_2;
																							IL_0862_2:
																							if (47 >= b)
																							{
																								goto IL_08e4_2;
																							}
																							goto IL_1766_2;
																							IL_08e4_2:
																							if (47 > b)
																							{
																								goto IL_08ef_2;
																							}
																							goto IL_0902_2;
																							IL_08ef_2:
																							if (46 < b)
																							{
																								break;
																							}
																							goto IL_0f87_2;
																							IL_0f87_2:
																							if (46 > b)
																							{
																								break;
																							}
																							goto IL_0f95_2;
																							IL_0f95_2:
																							array2[num6] = 0;
																							goto IL_0fa3_2;
																							IL_0fa3_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																							goto IL_0fc7_2;
																							IL_0fc7_2:
																							num6++;
																							num = 383;
																							goto IL_0fde_2;
																							IL_0fde_2:
																							ptr2 += 8;
																							goto IL_21e2_2;
																							IL_0902_2:
																							array3[num6] = ((delegate*<Color[]>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																							goto IL_0920_2;
																							IL_0920_2:
																							array2[num6] = 5;
																							goto IL_092e_2;
																							IL_092e_2:
																							num6++;
																							num = 385;
																							goto IL_095a_2;
																							IL_095a_2:
																							ptr2 += 8;
																							goto IL_21e2_2;
																							IL_1766_2:
																							if (48 < b)
																							{
																								break;
																							}
																							goto IL_1774_2;
																							IL_1774_2:
																							if (48 > b)
																							{
																								break;
																							}
																							num = 309;
																							goto IL_178b_2;
																							IL_17b5_2:
																							array2[num6 - 1] = 2;
																							goto IL_21e2_2;
																						}
																						break;
																					}
																					goto IL_0885_2;
																					IL_08b0_2:
																					array2[num6 - 1] = 0;
																					goto IL_21e2_2;
																					IL_0885_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																					goto IL_08b0_2;
																				}
																				break;
																			}
																			goto IL_183c_2;
																			IL_1ab1_2:
																			if (55 < b)
																			{
																				break;
																			}
																			goto IL_1abf_2;
																			IL_183c_2:
																			if (52 >= b)
																			{
																				goto IL_184a_2;
																			}
																			goto IL_19bc_2;
																			IL_184a_2:
																			if (52 <= b)
																			{
																				goto IL_1855_2;
																			}
																			goto IL_1882_2;
																			IL_1855_2:
																			global::_003CModule_003E.int_212 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_186f_2;
																			IL_186f_2:
																			num6--;
																			goto IL_21e2_2;
																			IL_1882_2:
																			if (50 >= b)
																			{
																				goto IL_188d_2;
																			}
																			goto IL_1902_2;
																			IL_188d_2:
																			if (50 > b)
																			{
																				break;
																			}
																			goto IL_189b_2;
																			IL_189b_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_18db_2;
																			IL_18db_2:
																			array2[num6 - 2] = 0;
																			goto IL_18ef_2;
																			IL_18ef_2:
																			num6--;
																			goto IL_21e2_2;
																			IL_1902_2:
																			if (51 < b)
																			{
																				break;
																			}
																			goto IL_1910_2;
																			IL_1910_2:
																			if (51 > b)
																			{
																				break;
																			}
																			goto IL_191e_2;
																			IL_191e_2:
																			array2[num6 - 3] = 0;
																			goto IL_1932_2;
																			IL_1932_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]) = ((delegate*<int, int, int, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_199b_2;
																			IL_199b_2:
																			num6 -= 2;
																			goto IL_19a9_2;
																			IL_19a9_2:
																			ptr2 += 8;
																			goto IL_21e2_2;
																			IL_19bc_2:
																			if (54 >= b)
																			{
																				goto IL_19ca_2;
																			}
																			goto IL_1ab1_2;
																			IL_19ca_2:
																			if (54 > b)
																			{
																				goto IL_19d5_2;
																			}
																			goto IL_1a4d_2;
																			IL_19d5_2:
																			if (53 < b)
																			{
																				break;
																			}
																			num = 215;
																			goto IL_19ec_2;
																			IL_1abf_2:
																			if (55 > b)
																			{
																			}
																			break;
																			IL_19ec_2:
																			if (53 > b)
																			{
																				break;
																			}
																			goto IL_19fa_2;
																			IL_19fa_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
																			goto IL_1a1e_2;
																			IL_1a1e_2:
																			array2[num6] = 0;
																			goto IL_1a2c_2;
																			IL_1a2c_2:
																			num6++;
																			goto IL_1a3a_2;
																			IL_1a3a_2:
																			ptr2 += 8;
																			goto IL_21e2_2;
																			IL_1a4d_2:
																			array3[num6 - 2] = ((Color[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																			goto IL_1a8a_2;
																			IL_1a8a_2:
																			array2[num6 - 2] = 4;
																			goto IL_1a9e_2;
																			IL_1a9e_2:
																			num6--;
																			goto IL_21e2_2;
																		}
																		break;
																	}
																	num = 401;
																	goto IL_1adb_2;
																	IL_2161_2:
																	if (41 > b)
																	{
																		break;
																	}
																	goto IL_216c_2;
																	IL_216c_2:
																	array2[num6 - 1] = 3;
																	goto IL_2180_2;
																	IL_1adb_2:
																	if (42 <= b)
																	{
																		goto IL_1ae6_2;
																	}
																	goto IL_1b4c_2;
																	IL_1ae6_2:
																	array2[num6 - 1] = 3;
																	goto IL_1afa_2;
																	IL_1afa_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1b39_2;
																	IL_1b39_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1b4c_2:
																	if (35 >= b)
																	{
																		goto IL_1b5a_2;
																	}
																	goto IL_1ec1_2;
																	IL_1b5a_2:
																	if (35 <= b)
																	{
																		goto IL_1b65_2;
																	}
																	goto IL_1bba_2;
																	IL_1b65_2:
																	((Color[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (Color)array3[num6 - 1];
																	goto IL_1ba7_2;
																	IL_1ba7_2:
																	num6 -= 3;
																	goto IL_21e2_2;
																	IL_1bba_2:
																	if (31 >= b)
																	{
																		goto IL_1bc8_2;
																	}
																	goto IL_1d1d_2;
																	IL_1bc8_2:
																	if (31 <= b)
																	{
																		goto IL_1bd3_2;
																	}
																	goto IL_1c39_2;
																	IL_1bd3_2:
																	array2[num6 - 1] = 0;
																	goto IL_1be7_2;
																	IL_1be7_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1c26_2;
																	IL_1c26_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1c39_2:
																	if (29 >= b)
																	{
																		goto IL_1c44_2;
																	}
																	goto IL_1c9a_2;
																	IL_1c44_2:
																	if (29 > b)
																	{
																		break;
																	}
																	goto IL_1c52_2;
																	IL_1c52_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																	goto IL_1c6b_2;
																	IL_1c6b_2:
																	array2[num6] = 3;
																	goto IL_1c79_2;
																	IL_1c79_2:
																	num6++;
																	goto IL_1c87_2;
																	IL_1c87_2:
																	ptr2 += 16;
																	goto IL_21e2_2;
																	IL_1c9a_2:
																	if (30 < b)
																	{
																		break;
																	}
																	goto IL_1ca8_2;
																	IL_1ca8_2:
																	if (30 > b)
																	{
																		break;
																	}
																	goto IL_1cb6_2;
																	IL_1cb6_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_1cf6_2;
																	IL_1cf6_2:
																	array2[num6 - 2] = 3;
																	goto IL_1d0a_2;
																	IL_1d0a_2:
																	num6--;
																	goto IL_21e2_2;
																	IL_1d1d_2:
																	if (33 < b)
																	{
																		goto IL_1d2b_2;
																	}
																	num = 21;
																	goto IL_1e06_2;
																	IL_1d2b_2:
																	if (34 < b)
																	{
																		break;
																	}
																	goto IL_1d39_2;
																	IL_1d39_2:
																	if (34 > b)
																	{
																		break;
																	}
																	goto IL_1d47_2;
																	IL_1d47_2:
																	array2[num6 - 4] = 5;
																	goto IL_1d5b_2;
																	IL_1d5b_2:
																	array3[num6 - 4] = ((delegate*<float, float, float, float, object>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																	goto IL_1dd3_2;
																	IL_1dd3_2:
																	num6 -= 3;
																	num = 448;
																	goto IL_1dea_2;
																	IL_1dea_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_2180_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_21bf_2;
																	IL_1e06_2:
																	if (33 <= b)
																	{
																		goto IL_1e11_2;
																	}
																	goto IL_1e5a_2;
																	IL_1e11_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																	goto IL_1e2b_2;
																	IL_1e2b_2:
																	array2[num6] = 3;
																	goto IL_1e39_2;
																	IL_1e39_2:
																	num6++;
																	goto IL_1e47_2;
																	IL_1e47_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1e5a_2:
																	if (32 < b)
																	{
																		break;
																	}
																	goto IL_1e68_2;
																	IL_1e68_2:
																	if (32 > b)
																	{
																		break;
																	}
																	num = 412;
																	goto IL_1e7f_2;
																	IL_21bf_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1e7f_2:
																	array3[num6 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_1ea8_2;
																	IL_1ea8_2:
																	array2[num6 - 1] = 5;
																	goto IL_21e2_2;
																	IL_1ec1_2:
																	if (38 >= b)
																	{
																		goto IL_1ecf_2;
																	}
																	goto IL_2042_2;
																	IL_1ecf_2:
																	if (38 <= b)
																	{
																		goto IL_1eda_2;
																	}
																	goto IL_1f40_2;
																	IL_1eda_2:
																	array2[num6 - 1] = 0;
																	goto IL_1eee_2;
																	IL_1eee_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1f2d_2;
																	IL_1f2d_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1f40_2:
																	if (36 >= b)
																	{
																		goto IL_1f4b_2;
																	}
																	goto IL_1fbf_2;
																	IL_1f4b_2:
																	if (36 > b)
																	{
																		break;
																	}
																	goto IL_1f59_2;
																	IL_1f59_2:
																	array2[num6 - 1] = 3;
																	goto IL_1f6d_2;
																	IL_1f6d_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_1fac_2;
																	IL_1fac_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_1fbf_2:
																	if (37 < b)
																	{
																		break;
																	}
																	goto IL_1fcd_2;
																	IL_1fcd_2:
																	if (37 > b)
																	{
																		break;
																	}
																	goto IL_1fdb_2;
																	IL_1fdb_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_201b_2;
																	IL_201b_2:
																	array2[num6 - 2] = 3;
																	goto IL_202f_2;
																	IL_202f_2:
																	num6--;
																	goto IL_21e2_2;
																	IL_2042_2:
																	if (40 >= b)
																	{
																		goto IL_2050_2;
																	}
																	goto IL_2156_2;
																	IL_2050_2:
																	if (40 <= b)
																	{
																		goto IL_205b_2;
																	}
																	goto IL_20c2_2;
																	IL_205b_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_209b_2;
																	IL_209b_2:
																	array2[num6 - 2] = 3;
																	goto IL_20af_2;
																	IL_20af_2:
																	num6--;
																	goto IL_21e2_2;
																	IL_20c2_2:
																	if (39 < b)
																	{
																		break;
																	}
																	goto IL_20d0_2;
																	IL_20d0_2:
																	if (39 > b)
																	{
																		break;
																	}
																	goto IL_20de_2;
																	IL_20de_2:
																	array2[num6 - 1] = 3;
																	num = 293;
																	goto IL_20fb_2;
																	IL_20fb_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	num = 324;
																	goto IL_2143_2;
																	IL_2143_2:
																	ptr2 += 8;
																	goto IL_21e2_2;
																	IL_2156_2:
																	if (41 < b)
																	{
																		break;
																	}
																	goto IL_2161_2;
																}
																break;
															}
															goto IL_096d_2;
															IL_129b_2:
															if (22 > b)
															{
																break;
															}
															num = 210;
															goto IL_12b2_2;
															IL_096d_2:
															if (28 <= b)
															{
																goto IL_0978_2;
															}
															goto IL_0994_2;
															IL_0978_2:
															num7 = ptr2;
															num8 = -200;
															num5 = 1;
															ptr2 = num7 + num8;
															goto IL_21e2_2;
															IL_0994_2:
															if (14 >= b)
															{
																goto IL_09a2_2;
															}
															goto IL_0cf5_2;
															IL_09a2_2:
															if (14 > b)
															{
																goto IL_09b0_2;
															}
															goto IL_14de_2;
															IL_09b0_2:
															if (7 < b)
															{
																goto IL_09be_2;
															}
															goto IL_0ad2_2;
															IL_09be_2:
															if (10 < b)
															{
																goto IL_09c9_2;
															}
															num = 42;
															goto IL_09f3_2;
															IL_09c9_2:
															if (12 < b)
															{
																goto IL_09d7_2;
															}
															goto IL_0ecf_2;
															IL_09d7_2:
															if (13 < b)
															{
																break;
															}
															goto IL_167e_2;
															IL_167e_2:
															if (13 > b)
															{
																break;
															}
															goto IL_168c_2;
															IL_168c_2:
															array8 = array3;
															num9 = num6;
															if (array == null)
															{
																goto IL_169b_2;
															}
															goto IL_16a9;
															IL_0ecf_2:
															if (12 <= b)
															{
																goto IL_21e2_2;
															}
															goto IL_0edd_2;
															IL_0edd_2:
															if (11 < b)
															{
																break;
															}
															goto IL_0eeb_2;
															IL_0eeb_2:
															if (11 > b)
															{
																break;
															}
															goto IL_0ef9_2;
															IL_0ef9_2:
															array2[num6 - 2] = 0;
															goto IL_0f0d_2;
															IL_0f0d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0f61_2;
															IL_0f61_2:
															num6--;
															goto IL_1189_2;
															IL_1189_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_15fb_2:
															num6--;
															num = 104;
															goto IL_21e2_2;
															IL_09f3_2:
															if (10 > b)
															{
																goto IL_09fe_2;
															}
															num = 68;
															goto IL_0a5d_2;
															IL_09fe_2:
															if (8 >= b)
															{
																goto IL_0a09_2;
															}
															goto IL_0a2a_2;
															IL_0a09_2:
															if (8 > b)
															{
																break;
															}
															goto IL_0a17_2;
															IL_0a17_2:
															num6--;
															goto IL_21e2_2;
															IL_0a2a_2:
															if (9 < b)
															{
																break;
															}
															goto IL_0a38_2;
															IL_0a38_2:
															if (9 > b)
															{
																break;
															}
															num = 425;
															goto IL_1130_2;
															IL_12f3_2:
															array2[num6 - 2] = 0;
															goto IL_1307_2;
															IL_1130_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1170_2;
															IL_1170_2:
															array2[num6 - 2] = 0;
															goto IL_132d_2;
															IL_132d_2:
															num6--;
															num = 130;
															goto IL_21e2_2;
															IL_12b2_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_12f3_2;
															IL_0a5d_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0abf_2;
															IL_0abf_2:
															num6 -= 2;
															goto IL_21e2_2;
															IL_0ad2_2:
															if (7 <= b)
															{
																goto IL_0add_2;
															}
															goto IL_0b44_2;
															IL_0add_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0b1d_2;
															IL_0b1d_2:
															array2[num6 - 2] = 0;
															goto IL_0b31_2;
															IL_0b31_2:
															num6--;
															goto IL_21e2_2;
															IL_0b44_2:
															if (3 >= b)
															{
																goto IL_0b52_2;
															}
															goto IL_0bd8_2;
															IL_0b52_2:
															if (3 <= b)
															{
																goto IL_0b5d_2;
															}
															goto IL_0ba7_2;
															IL_0b5d_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0b86_2;
															IL_0b86_2:
															ptr2 += 8;
															goto IL_0b94_2;
															IL_0b94_2:
															num6--;
															goto IL_21e2_2;
															IL_0ba7_2:
															if (1 >= b)
															{
																goto IL_0bb2_2;
															}
															goto IL_0bc5_2;
															IL_0bb2_2:
															if (1 > b)
															{
																break;
															}
															goto IL_1349_2;
															IL_1349_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_1362_2;
															IL_1362_2:
															array2[num6] = 0;
															goto IL_1370_2;
															IL_1370_2:
															num6++;
															goto IL_137e_2;
															IL_137e_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_0bc5_2:
															if (2 < b)
															{
																break;
															}
															goto IL_1526_2;
															IL_1526_2:
															if (2 > b)
															{
																break;
															}
															goto IL_1534_2;
															IL_1534_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1574_2;
															IL_1574_2:
															array2[num6 - 2] = 0;
															goto IL_1588_2;
															IL_1588_2:
															num6--;
															goto IL_21e2_2;
															IL_0bd8_2:
															if (5 >= b)
															{
																goto IL_0be6_2;
															}
															goto IL_0cd4_2;
															IL_0be6_2:
															if (5 <= b)
															{
																goto IL_0bf1_2;
															}
															goto IL_0c61_2;
															IL_0bf1_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0c31_2;
															IL_0c31_2:
															array2[num6 - 2] = 0;
															goto IL_0c45_2;
															IL_0c45_2:
															num6--;
															num = 361;
															goto IL_21e2_2;
															IL_0c61_2:
															if (4 < b)
															{
																break;
															}
															goto IL_0c6f_2;
															IL_0c6f_2:
															if (4 > b)
															{
																break;
															}
															goto IL_0c7d_2;
															IL_0c7d_2:
															array2[num6] = 0;
															goto IL_0c8b_2;
															IL_0c8b_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0cae_2;
															IL_0cae_2:
															array3[num6] = null;
															goto IL_0cb8_2;
															IL_0cb8_2:
															num6++;
															num = 394;
															goto IL_0f74_2;
															IL_0f74_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_0cd4_2:
															if (6 < b)
															{
																break;
															}
															goto IL_0ce2_2;
															IL_0ce2_2:
															if (6 > b)
															{
																break;
															}
															goto IL_1617_2;
															IL_1617_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1657_2;
															IL_1657_2:
															array2[num6 - 2] = 0;
															goto IL_166b_2;
															IL_166b_2:
															num6--;
															goto IL_21e2_2;
															IL_14de_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_14fc_2;
															IL_14fc_2:
															ptr2 += 8;
															num = 51;
															goto IL_1513_2;
															IL_1513_2:
															num6--;
															goto IL_21e2_2;
															IL_0cf5_2:
															if (21 >= b)
															{
																goto IL_0d03_2;
															}
															goto IL_119c_2;
															IL_0d03_2:
															if (21 <= b)
															{
																goto IL_0d0e_2;
															}
															goto IL_0d26_2;
															IL_0d0e_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_21e2_2;
															IL_0d26_2:
															if (17 < b)
															{
																goto IL_0d34_2;
															}
															num = 47;
															goto IL_0e3c_2;
															IL_0d34_2:
															if (19 >= b)
															{
																goto IL_0d42_2;
															}
															goto IL_0dc6_2;
															IL_0d42_2:
															if (19 > b)
															{
																goto IL_0d50_2;
															}
															goto IL_10d1_2;
															IL_0d50_2:
															if (18 < b)
															{
																break;
															}
															goto IL_0d5e_2;
															IL_0d5e_2:
															if (18 > b)
															{
																break;
															}
															goto IL_0d6c_2;
															IL_0d6c_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															num = 118;
															goto IL_0db3_2;
															IL_0db3_2:
															num6 -= 3;
															goto IL_21e2_2;
															IL_10d1_2:
															array2[num6 - 1] = 5;
															goto IL_10e5_2;
															IL_10e5_2:
															array3[num6 - 1] = ((delegate*<string[], string>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															goto IL_111d_2;
															IL_111d_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_0dc6_2:
															if (20 < b)
															{
																break;
															}
															goto IL_0dd4_2;
															IL_0dd4_2:
															if (20 > b)
															{
																break;
															}
															goto IL_0de2_2;
															IL_0de2_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_0dfb_2;
															IL_0dfb_2:
															array2[num6] = 1;
															num = 352;
															goto IL_0e12_2;
															IL_0e12_2:
															num6++;
															goto IL_0e20_2;
															IL_0e20_2:
															ptr2 += 16;
															goto IL_21e2_2;
															IL_1307_2:
															num6--;
															goto IL_21e2_2;
															IL_0e3c_2:
															if (17 > b)
															{
																goto IL_0e4a_2;
															}
															goto IL_108a_2;
															IL_0e4a_2:
															if (15 >= b)
															{
																goto IL_0e55_2;
															}
															goto IL_0ea5_2;
															IL_0e55_2:
															if (15 > b)
															{
																break;
															}
															goto IL_0e63_2;
															IL_0e63_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_0e8c_2;
															IL_0e8c_2:
															array2[num6 - 1] = 5;
															goto IL_21e2_2;
															IL_0ea5_2:
															if (16 < b)
															{
																break;
															}
															goto IL_0eb3_2;
															IL_0eb3_2:
															if (16 > b)
															{
																break;
															}
															num = 407;
															goto IL_100a_2;
															IL_131a_2:
															if (23 < b)
															{
																break;
															}
															goto IL_159b_2;
															IL_100a_2:
															array2[num6] = array2[num6 - 1];
															goto IL_1022_2;
															IL_1022_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_1040_2;
															IL_1040_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1064_2;
															IL_1064_2:
															array3[num6] = array3[num6 - 1];
															num = 446;
															goto IL_1753_2;
															IL_1753_2:
															num6++;
															goto IL_21e2_2;
															IL_108a_2:
															array2[num6] = 5;
															goto IL_1098_2;
															IL_1098_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_10b0_2;
															IL_10b0_2:
															num6++;
															goto IL_10be_2;
															IL_10be_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_119c_2:
															if (24 < b)
															{
																goto IL_11aa_2;
															}
															num = 311;
															goto IL_1238_2;
															IL_11aa_2:
															if (26 < b)
															{
																goto IL_11b8_2;
															}
															goto IL_1391_2;
															IL_11b8_2:
															if (27 < b)
															{
																break;
															}
															goto IL_11c6_2;
															IL_11c6_2:
															if (27 > b)
															{
																break;
															}
															num = 402;
															goto IL_11dd_2;
															IL_15a9_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_15fb_2;
															IL_11dd_2:
															array2[num6] = 4;
															goto IL_11eb_2;
															IL_11eb_2:
															array3[num6] = ((delegate*<Color>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
															goto IL_120e_2;
															IL_120e_2:
															num6++;
															goto IL_121c_2;
															IL_121c_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_1391_2:
															if (26 <= b)
															{
																goto IL_139c_2;
															}
															goto IL_13e9_2;
															IL_139c_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 392;
															goto IL_13d0_2;
															IL_13d0_2:
															array2[num6 - 1] = 0;
															goto IL_21e2_2;
															IL_13e9_2:
															if (25 < b)
															{
																break;
															}
															goto IL_13f7_2;
															IL_13f7_2:
															if (25 > b)
															{
																break;
															}
															goto IL_1405_2;
															IL_1405_2:
															array2[num6 - 2] = 0;
															goto IL_1419_2;
															IL_1419_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
															goto IL_146b_2;
															IL_146b_2:
															num6--;
															goto IL_1479_2;
															IL_1479_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_159b_2:
															if (23 > b)
															{
																break;
															}
															goto IL_15a9_2;
															IL_1238_2:
															if (24 <= b)
															{
																goto IL_1243_2;
															}
															goto IL_1290_2;
															IL_1243_2:
															array2[num6] = 5;
															goto IL_1251_2;
															IL_1251_2:
															array3[num6] = ((delegate*<string>)StackBehaviourPopArgRegSetStrArrNull[*(int*)(ptr2 + num3)])();
															goto IL_126f_2;
															IL_126f_2:
															num6++;
															goto IL_127d_2;
															IL_127d_2:
															ptr2 += 8;
															goto IL_21e2_2;
															IL_1290_2:
															if (22 >= b)
															{
																goto IL_129b_2;
															}
															goto IL_131a_2;
														}
														break;
														IL_081e_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_21e2_2;
												continue;
												end_IL_082e_2:
												break;
											}
											continue;
											end_IL_083e:
											break;
										}
										continue;
										end_IL_084e:
										break;
									}
									break;
								}
								goto IL_22ae_2;
								IL_22ae_2:
								return (Color)array3[num6 - 1];
							}
							break;
						}
						continue;
						end_IL_1743:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static ControllerInputPoller CookiePathIsImpersonating()
	{
		return ControllerInputPoller.instance;
	}

	private static float YeartoRuntimeReflectionExtensions()
	{
		return Time.time;
	}

	private static double IsFamilyOrAssemblyFamORAssem(double double_0)
	{
		return Math.Floor(double_0);
	}

	private static void XmlEntryNeverExpires(Class184 class184_1)
	{
		class184_1.method_0();
	}

	private static Vector3 TargetSchedulerSetData()
	{
		return Vector3.zero;
	}

	private static double StructIContextProperty(double double_0)
	{
		return Math.Sqrt(double_0);
	}

	private static double MaxBinaryLengthSeconds(double double_0)
	{
		return Math.Log10(double_0);
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 44;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenRestrictedDeviceClaimAttributesDuplicateEvidenceAction.LeftAltPressedGetHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c1:
															byte b = *ptr2;
															while (true)
															{
																IL_02a8:
																ptr2++;
																num = 30;
																while (true)
																{
																	IL_0298:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0278:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_026b:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_025b:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_024b:
																										if (11 <= b)
																										{
																											while (true)
																											{
																												IL_0232:
																												num5--;
																												num = 132;
																												while (num != 132 && num == 1113)
																												{
																													switch (num)
																													{
																													case 21:
																													case 99:
																														goto IL_0232;
																													case 69:
																														goto IL_024b;
																													case 77:
																														goto IL_025b;
																													case 2:
																													case 70:
																														goto IL_026b;
																													case 100:
																														goto IL_0278;
																													case 113:
																														goto IL_0288;
																													case 30:
																														goto IL_0298;
																													case 50:
																														goto IL_02a8;
																													case 105:
																													case 110:
																														goto IL_02c1;
																													case 12:
																														goto IL_02d5;
																													case 48:
																														goto IL_02e8;
																													case 65:
																														goto IL_02f6;
																													case 61:
																													case 89:
																														goto IL_0304;
																													case 23:
																														goto IL_0318;
																													case 76:
																														goto IL_036c;
																													case 83:
																													case 93:
																														goto IL_037f;
																													case 59:
																														goto IL_038a;
																													case 96:
																														goto IL_039d;
																													case 9:
																														goto IL_03ab;
																													case 52:
																													case 108:
																														goto IL_03b9;
																													case 49:
																														goto IL_03d2;
																													case 43:
																														goto IL_03e0;
																													case 68:
																														goto IL_03ee;
																													case 111:
																													case 117:
																														goto IL_0401;
																													case 87:
																														goto IL_0441;
																													case 120:
																														goto IL_0457;
																													case 85:
																													case 124:
																														goto IL_046a;
																													case 3:
																														goto IL_0478;
																													case 39:
																														goto IL_04a4;
																													case 10:
																														goto IL_04ae;
																													case 24:
																														goto IL_04bc;
																													case 125:
																														goto IL_04cf;
																													case 97:
																														goto IL_04e2;
																													case 90:
																														goto IL_04f0;
																													case 7:
																													case 71:
																														goto IL_04fe;
																													case 64:
																														goto IL_051a;
																													case 16:
																													case 82:
																														goto IL_0528;
																													case 53:
																														goto IL_0536;
																													case 4:
																													case 103:
																														goto IL_0544;
																													case 31:
																														goto IL_054f;
																													case 45:
																														goto IL_0562;
																													case 29:
																														goto IL_0570;
																													case 54:
																													case 116:
																														goto IL_057e;
																													case 55:
																														goto IL_05ec;
																													case 25:
																													case 81:
																														goto IL_05ff;
																													case 114:
																														goto IL_063f;
																													case 35:
																														goto IL_0653;
																													case 37:
																													case 91:
																														goto IL_0666;
																													case 94:
																														goto IL_0671;
																													case 95:
																													case 122:
																														goto IL_067c;
																													case 47:
																														goto IL_06a5;
																													case 14:
																														goto IL_06b3;
																													case 66:
																														goto IL_06c3;
																													case 72:
																														goto IL_06ce;
																													case 28:
																													case 118:
																														goto IL_06d9;
																													case 5:
																													case 8:
																													case 11:
																													case 13:
																													case 15:
																													case 17:
																													case 19:
																													case 22:
																													case 26:
																													case 32:
																													case 34:
																													case 36:
																													case 38:
																													case 58:
																													case 60:
																													case 78:
																													case 79:
																													case 84:
																													case 92:
																													case 104:
																													case 106:
																													case 112:
																													case 119:
																													case 123:
																														goto end_IL_0288;
																													case 56:
																														goto IL_0711;
																													case 18:
																														goto IL_071f;
																													case 0:
																														goto IL_072d;
																													case 6:
																													case 33:
																													case 42:
																													case 51:
																													case 57:
																													case 67:
																													case 73:
																													case 74:
																													case 88:
																													case 102:
																													case 107:
																													case 109:
																													case 115:
																													case 121:
																														goto end_IL_021f;
																													case 63:
																														goto end_IL_073b;
																													case 46:
																														goto end_IL_074e;
																													case 98:
																														goto end_IL_0758;
																													case 62:
																														goto end_IL_0763;
																													case 75:
																														goto end_IL_0778;
																													case 44:
																													case 101:
																														goto end_IL_078d;
																													case 86:
																														goto end_IL_079d;
																													case 27:
																													case 80:
																														goto end_IL_07ad;
																													case 40:
																														goto end_IL_07c6;
																													case 41:
																														goto end_IL_07d6;
																													case 1:
																													case 20:
																														goto IL_07f1;
																													}
																													continue;
																													end_IL_021f:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02e8;
																										IL_0457:
																										ptr2 += 8;
																										break;
																										IL_02e8:
																										if (10 < b)
																										{
																											goto end_IL_0288;
																										}
																										goto IL_02f6;
																										IL_02f6:
																										if (10 > b)
																										{
																											goto end_IL_0288;
																										}
																										goto IL_0304;
																										IL_0304:
																										array[num5 - 2] = 0;
																										goto IL_0318;
																										IL_0318:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getInheritanceFlagsGetUninitializedObject[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										goto IL_036c;
																										IL_036c:
																										num5--;
																										goto IL_0457;
																									}
																									break;
																								}
																								goto IL_04e2;
																								IL_04fe:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								break;
																								IL_04e2:
																								if (12 < b)
																								{
																									goto end_IL_0288;
																								}
																								goto IL_04f0;
																								IL_04f0:
																								if (12 > b)
																								{
																									goto end_IL_0288;
																								}
																								goto IL_04fe;
																							}
																							break;
																						}
																						num = 12;
																						goto IL_02d5;
																						IL_0441:
																						array[num5 - 2] = 0;
																						goto IL_04cf;
																						IL_04cf:
																						num5--;
																						break;
																						IL_02d5:
																						if (9 > b)
																						{
																							goto IL_037f;
																						}
																						goto IL_0401;
																						IL_037f:
																						if (7 >= b)
																						{
																							goto IL_038a;
																						}
																						goto IL_039d;
																						IL_038a:
																						if (7 > b)
																						{
																							goto end_IL_0288;
																						}
																						goto IL_046a;
																						IL_046a:
																						array[num5] = 0;
																						goto IL_0478;
																						IL_0478:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						num = 39;
																						goto IL_04a4;
																						IL_04a4:
																						array2[num5] = null;
																						goto IL_04ae;
																						IL_04ae:
																						num5++;
																						goto IL_04bc;
																						IL_04bc:
																						ptr2 += 8;
																						break;
																						IL_039d:
																						if (8 < b)
																						{
																							goto end_IL_0288;
																						}
																						goto IL_03ab;
																						IL_03ab:
																						if (8 > b)
																						{
																							goto end_IL_0288;
																						}
																						goto IL_03b9;
																						IL_03b9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_03d2;
																						IL_03d2:
																						array[num5] = 0;
																						goto IL_03e0;
																						IL_03e0:
																						num5++;
																						goto IL_03ee;
																						IL_03ee:
																						ptr2 += 8;
																						break;
																						IL_0401:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0441;
																					}
																					break;
																				}
																				goto IL_051a;
																				IL_06d9:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_051a:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_0528;
																				IL_0528:
																				if (3 >= b)
																				{
																					goto IL_0536;
																				}
																				goto IL_0666;
																				IL_0536:
																				if (3 > b)
																				{
																					goto IL_0544;
																				}
																				goto IL_05ff;
																				IL_0544:
																				if (1 >= b)
																				{
																					goto IL_054f;
																				}
																				goto IL_0562;
																				IL_054f:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0288;
																				IL_0562:
																				if (2 < b)
																				{
																					goto end_IL_0288;
																				}
																				goto IL_0570;
																				IL_0570:
																				if (2 > b)
																				{
																					goto end_IL_0288;
																				}
																				goto IL_057e;
																				IL_057e:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05ec;
																				IL_05ec:
																				num5 -= 2;
																				break;
																				IL_05ff:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_063f;
																				IL_063f:
																				array[num5 - 2] = 0;
																				goto IL_0653;
																				IL_0653:
																				num5--;
																				break;
																				IL_0666:
																				if (4 >= b)
																				{
																					goto IL_0671;
																				}
																				goto IL_06c3;
																				IL_0671:
																				if (4 > b)
																				{
																					goto end_IL_0288;
																				}
																				goto IL_067c;
																				IL_067c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06a5;
																				IL_06a5:
																				ptr2 += 8;
																				goto IL_06b3;
																				IL_06b3:
																				num5--;
																				break;
																				IL_06c3:
																				if (5 < b)
																				{
																					goto end_IL_0288;
																				}
																				goto IL_06ce;
																				IL_06ce:
																				if (5 > b)
																				{
																					goto end_IL_0288;
																				}
																				goto IL_06d9;
																			}
																			goto end_IL_0298;
																			continue;
																			end_IL_0288:
																			break;
																			IL_0288:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0711;
																	IL_072d:
																	ptr2 += 8;
																	break;
																	IL_071f:
																	num5++;
																	goto IL_072d;
																	IL_0711:
																	array[num5] = 0;
																	goto IL_071f;
																	continue;
																	end_IL_0298:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07f1;
													IL_07f1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_073b:
													break;
												}
												continue;
												end_IL_074e:
												break;
											}
											continue;
											end_IL_0758:
											break;
										}
										continue;
										end_IL_0763:
										break;
									}
									continue;
									end_IL_0778:
									break;
								}
								continue;
								end_IL_078d:
								break;
							}
							continue;
							end_IL_079d:
							break;
						}
						continue;
						end_IL_07ad:
						break;
					}
					continue;
					end_IL_07c6:
					break;
				}
				continue;
				end_IL_07d6:
				break;
			}
		}
	}

	private static double sourceGuidgetClsid(double double_0)
	{
		return Math.Truncate(double_0);
	}

	private static void ResourceReadersetBinder(Transform transform_0, Vector3 vector3_1)
	{
		transform_0.position = vector3_1;
	}

	private static double FileNameWindowsOnlyCultures(double double_0)
	{
		return Math.Ceiling(double_0);
	}

	private unsafe void Update()
	{
		int num = 2;
		int num3 = default(int);
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			num = 14;
			while (true)
			{
				if (num != 14)
				{
					if (num != 995)
					{
						return;
					}
					switch (num)
					{
					case 2:
						goto end_IL_0041;
					case 5:
						goto IL_005f;
					case 0:
						goto IL_0064;
					case 1:
					case 7:
						goto IL_0086;
					case 6:
						goto IL_008c;
					case 3:
					case 4:
						return;
					}
					continue;
				}
				num3 = 0;
				goto IL_005f;
				IL_0086:
				if (num3 != 81)
				{
					goto IL_0064;
				}
				goto IL_008c;
				IL_0064:
				((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class184, void>)InsufficientExecutionStackExceptionMapViewToReadOnlyCollectionAdapter[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
				goto IL_0086;
				IL_008c:
				num3 = 0;
				return;
				IL_005f:
				num3 = 0;
				goto IL_0086;
				continue;
				end_IL_0041:
				break;
			}
		}
	}

	private static double TypeLibTypeFlagsgetPathDiscovery(double double_0)
	{
		return Math.Tanh(double_0);
	}

	private unsafe Color method_3()
	{
		//The blocks IL_000e, IL_001e, IL_0593, IL_05a6, IL_05c5, IL_05d5, IL_05e5, IL_05f2, IL_0602, IL_0612, IL_0622, IL_062f, IL_063f, IL_064f, IL_065f, IL_066a, IL_069a, IL_06a8, IL_06b3, IL_06c1, IL_06d4, IL_06e2, IL_06f0, IL_06fe, IL_0711, IL_071f, IL_074d, IL_0760, IL_07c2, IL_07d5, IL_07e0, IL_0820, IL_0834, IL_0847, IL_0852, IL_0860, IL_086e, IL_08a5, IL_08b3, IL_08c1, IL_08cc, IL_08e0, IL_091f, IL_0932, IL_0940, IL_0953, IL_0961, IL_096f, IL_09dd, IL_09f0, IL_09fe, IL_0a0c, IL_0a4c, IL_0a60, IL_0a73, IL_0a7e, IL_0abe, IL_0ad7, IL_0ae5, IL_0af8, IL_0b0b, IL_0b19, IL_0b27, IL_0b3a, IL_0b48, IL_0b5b, IL_0b69, IL_0b7d, IL_0bbc, IL_0bcf, IL_0c10, IL_0c24, IL_0c37, IL_0c45, IL_0c58, IL_0c75, IL_0c92, IL_0ce1, IL_0ceb, IL_0d18, IL_0d2c, IL_0d3a, IL_0d4d, IL_0d6b, IL_0d8f, IL_0da7, IL_0dba, IL_0dc8, IL_0dd6, IL_0de1, IL_0df4, IL_0e02, IL_0e10, IL_0e5c, IL_0e70, IL_0ea8, IL_0ec4, IL_0ecf, IL_0edd, IL_0ee6, IL_0ef9, IL_0f07, IL_0f25, IL_0f3e, IL_0f4c, IL_0f5a, IL_0f6d, IL_0f8b, IL_0f99, IL_0fac, IL_0fec, IL_1000, IL_1013, IL_102c, IL_1055, IL_106e, IL_107c, IL_108a, IL_1098, IL_10a6, IL_10e6, IL_1103, IL_1116, IL_1121, IL_112f, IL_1142, IL_1150, IL_115e, IL_11a0, IL_11b8, IL_11c6, IL_11e9, IL_11f3, IL_120a, IL_121d, IL_1231, IL_1244, IL_1284, IL_1298, IL_12ab, IL_12b9, IL_12d1, IL_12df, IL_12f2, IL_1300, IL_130e, IL_1322, IL_138a, IL_1398, IL_13ab, IL_13b9, IL_13c4, IL_13dc, IL_13ea, IL_13f8, IL_140b, IL_1419, IL_1427, IL_1479, IL_148c, IL_1497, IL_14a5, IL_14b3, IL_14cd, IL_14db, IL_14e9, IL_14fc, IL_1505, IL_1513, IL_1551, IL_1565, IL_1578, IL_1586, IL_1591, IL_159f, IL_15bd, IL_15cb, IL_15de, IL_15ec, IL_15fa, IL_1616, IL_1624, IL_1632, IL_164f, IL_16a1, IL_16af, IL_16c2, IL_16d2, IL_16e5, IL_16f3, IL_170c, IL_171a, IL_1728, IL_173b, IL_1749, IL_1757, IL_176a, IL_177d, IL_178b, IL_179e, IL_17dd, IL_17f0, IL_17fe, IL_180c, IL_1823, IL_1847, IL_1855, IL_1868, IL_1873, IL_187e, IL_188c, IL_18b8, IL_18c6, IL_18d6, IL_18e1, IL_18ec, IL_18ff, IL_1912, IL_191c, IL_1927, IL_1937, IL_1947, IL_1957, IL_1967, IL_1977, IL_1987, IL_1997, IL_19a7, IL_19c0, IL_19db are reachable both inside and outside the pinned region starting at IL_19d5. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 129;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef86 = default(int);
			ref int reference = ref __rxRef86;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_19c0:
					num2 = 1;
					while (true)
					{
						IL_19a7:
						num3 = num2 * 4;
						num = 200;
						while (true)
						{
							IL_1997:
							num4 = num2 * 8;
							while (true)
							{
								IL_1987:
								array2 = new byte[4];
								while (true)
								{
									IL_1977:
									array3 = new object[4];
									while (true)
									{
										IL_1967:
										array4 = new int[4];
										while (true)
										{
											IL_1957:
											array5 = new int[7];
											while (true)
											{
												IL_1947:
												array6 = new long[4];
												while (true)
												{
													IL_1937:
													array7 = new object[9];
													while (true)
													{
														IL_1927:
														array7[0] = this;
														while (true)
														{
															IL_191c:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DayTypeForwardedFromAttribute.LdelemRHashElementTransformMetadata);
															while (true)
															{
																IL_1912:
																ptr2 = ptr;
																while (true)
																{
																	IL_18ff:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_065f:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_064f:
																				ptr2++;
																				while (true)
																				{
																					IL_063f:
																					if (b >= 1)
																					{
																						while (b <= 41)
																						{
																							while (true)
																							{
																								IL_0622:
																								if (21 < b)
																								{
																									while (true)
																									{
																										IL_0612:
																										if (31 < b)
																										{
																											while (true)
																											{
																												IL_0602:
																												if (36 < b)
																												{
																													while (true)
																													{
																														IL_05f2:
																														if (39 >= b)
																														{
																															while (true)
																															{
																																IL_05e5:
																																if (39 > b)
																																{
																																	while (true)
																																	{
																																		IL_05d5:
																																		if (37 >= b)
																																		{
																																			while (37 <= b)
																																			{
																																				while (true)
																																				{
																																					IL_05a6:
																																					array2[num6 - 1] = 3;
																																					num = 353;
																																					while (true)
																																					{
																																						if (num != 353)
																																						{
																																							if (num != 1334)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 129:
																																								break;
																																							default:
																																								continue;
																																							case 198:
																																							case 271:
																																								goto IL_05a6;
																																							case 66:
																																								goto IL_05c5;
																																							case 331:
																																								goto IL_05d5;
																																							case 199:
																																								goto IL_05e5;
																																							case 337:
																																								goto IL_05f2;
																																							case 299:
																																								goto IL_0602;
																																							case 183:
																																								goto IL_0612;
																																							case 285:
																																								goto IL_0622;
																																							case 240:
																																								goto IL_062f;
																																							case 60:
																																								goto IL_063f;
																																							case 132:
																																								goto IL_064f;
																																							case 15:
																																							case 88:
																																								goto IL_065f;
																																							case 156:
																																							case 188:
																																								goto IL_066a;
																																							case 214:
																																								goto IL_069a;
																																							case 171:
																																								goto IL_06a8;
																																							case 125:
																																								goto IL_06b3;
																																							case 35:
																																								goto IL_06c1;
																																							case 17:
																																								goto IL_06d4;
																																							case 210:
																																								goto IL_06e2;
																																							case 3:
																																								goto IL_06f0;
																																							case 108:
																																								goto IL_06fe;
																																							case 221:
																																								goto IL_0711;
																																							case 163:
																																							case 197:
																																								goto IL_071f;
																																							case 159:
																																								goto IL_074d;
																																							case 43:
																																							case 229:
																																								goto IL_0760;
																																							case 64:
																																								goto IL_07c2;
																																							case 255:
																																								goto IL_07d5;
																																							case 140:
																																							case 241:
																																								goto IL_07e0;
																																							case 24:
																																								goto IL_0820;
																																							case 1:
																																								goto IL_0834;
																																							case 201:
																																								goto IL_0847;
																																							case 202:
																																								goto IL_0852;
																																							case 107:
																																								goto IL_0860;
																																							case 28:
																																							case 78:
																																								goto IL_086e;
																																							case 259:
																																								goto IL_08b3;
																																							case 234:
																																								goto IL_08c1;
																																							case 212:
																																							case 239:
																																								goto IL_08cc;
																																							case 158:
																																								goto IL_08e0;
																																							case 144:
																																								goto IL_091f;
																																							case 191:
																																								goto IL_0932;
																																							case 250:
																																								goto IL_0940;
																																							case 127:
																																								goto IL_0953;
																																							case 217:
																																								goto IL_0961;
																																							case 134:
																																							case 244:
																																								goto IL_096f;
																																							case 74:
																																								goto IL_09dd;
																																							case 75:
																																								goto IL_09f0;
																																							case 106:
																																								goto IL_09fe;
																																							case 29:
																																							case 36:
																																								goto IL_0a0c;
																																							case 26:
																																								goto IL_0a4c;
																																							case 61:
																																								goto IL_0a60;
																																							case 261:
																																								goto IL_0a73;
																																							case 42:
																																							case 178:
																																								goto IL_0a7e;
																																							case 7:
																																								goto IL_0abe;
																																							case 157:
																																								goto IL_0ad7;
																																							case 25:
																																								goto IL_0ae5;
																																							case 279:
																																								goto IL_0af8;
																																							case 281:
																																								goto IL_0b0b;
																																							case 114:
																																								goto IL_0b19;
																																							case 176:
																																								goto IL_0b27;
																																							case 282:
																																								goto IL_0b3a;
																																							case 99:
																																								goto IL_0b48;
																																							case 286:
																																								goto IL_0b5b;
																																							case 18:
																																							case 133:
																																								goto IL_0b69;
																																							case 235:
																																								goto IL_0b7d;
																																							case 30:
																																								goto IL_0bbc;
																																							case 194:
																																							case 291:
																																								goto IL_0bcf;
																																							case 182:
																																								goto IL_0c10;
																																							case 252:
																																								goto IL_0c24;
																																							case 302:
																																								goto IL_0c37;
																																							case 54:
																																								goto IL_0c45;
																																							case 91:
																																							case 303:
																																								goto IL_0c58;
																																							case 55:
																																							case 306:
																																								goto IL_0c75;
																																							case 146:
																																								goto IL_0d2c;
																																							case 131:
																																								goto IL_0d3a;
																																							case 310:
																																								goto IL_0d4d;
																																							case 71:
																																								goto IL_0d6b;
																																							case 19:
																																								goto IL_0d8f;
																																							case 276:
																																								goto IL_0da7;
																																							case 314:
																																								goto IL_0dba;
																																							case 270:
																																								goto IL_0dc8;
																																							case 82:
																																								goto IL_0dd6;
																																							case 265:
																																								goto IL_0de1;
																																							case 189:
																																								goto IL_0df4;
																																							case 196:
																																								goto IL_0e02;
																																							case 247:
																																							case 248:
																																								goto IL_0e10;
																																							case 56:
																																							case 305:
																																								goto IL_0e5c;
																																							case 226:
																																								goto IL_0e70;
																																							case 86:
																																								goto IL_0ea8;
																																							case 34:
																																								goto IL_0ec4;
																																							case 151:
																																								goto IL_0ecf;
																																							case 50:
																																								goto IL_0ee6;
																																							case 69:
																																								goto IL_0ef9;
																																							case 2:
																																							case 262:
																																								goto IL_0f07;
																																							case 206:
																																							case 315:
																																								goto IL_0f25;
																																							case 89:
																																								goto IL_0f3e;
																																							case 65:
																																								goto IL_0f4c;
																																							case 20:
																																								goto IL_0f5a;
																																							case 222:
																																							case 317:
																																								goto IL_0f6d;
																																							case 268:
																																								goto end_IL_0593;
																																							case 177:
																																								goto IL_0f99;
																																							case 111:
																																							case 319:
																																								goto IL_0fac;
																																							case 192:
																																								goto IL_0fec;
																																							case 81:
																																								goto IL_1000;
																																							case 321:
																																								goto IL_1013;
																																							case 225:
																																							case 322:
																																								goto IL_102c;
																																							case 33:
																																								goto IL_1055;
																																							case 323:
																																								goto IL_106e;
																																							case 236:
																																								goto IL_107c;
																																							case 245:
																																								goto IL_108a;
																																							case 149:
																																								goto IL_1098;
																																							case 52:
																																							case 287:
																																								goto IL_10a6;
																																							case 266:
																																								goto IL_10e6;
																																							case 122:
																																								goto IL_1103;
																																							case 284:
																																								goto IL_1116;
																																							case 160:
																																								goto IL_1121;
																																							case 58:
																																							case 243:
																																								goto IL_112f;
																																							case 216:
																																								goto IL_1142;
																																							case 260:
																																								goto IL_1150;
																																							case 21:
																																							case 44:
																																								goto IL_115e;
																																							case 118:
																																							case 328:
																																								goto IL_11a0;
																																							case 115:
																																							case 332:
																																								goto IL_11b8;
																																							case 263:
																																								goto IL_11c6;
																																							case 120:
																																								goto IL_11e9;
																																							case 5:
																																								goto IL_11f3;
																																							case 85:
																																								goto IL_120a;
																																							case 333:
																																								goto IL_121d;
																																							case 211:
																																								goto IL_1231;
																																							case 22:
																																							case 334:
																																								goto IL_1244;
																																							case 228:
																																								goto IL_1284;
																																							case 48:
																																								goto IL_1298;
																																							case 290:
																																							case 338:
																																								goto IL_12ab;
																																							case 220:
																																								goto IL_12b9;
																																							case 37:
																																								goto IL_12d1;
																																							case 153:
																																								goto IL_12df;
																																							case 339:
																																								goto IL_12f2;
																																							case 193:
																																								goto IL_1300;
																																							case 103:
																																							case 254:
																																								goto IL_130e;
																																							case 162:
																																								goto IL_1322;
																																							case 330:
																																								goto IL_138a;
																																							case 170:
																																								goto IL_1398;
																																							case 312:
																																								goto IL_13ab;
																																							case 219:
																																								goto IL_13b9;
																																							case 113:
																																							case 152:
																																								goto IL_13c4;
																																							case 98:
																																								goto IL_13dc;
																																							case 298:
																																								goto IL_13ea;
																																							case 51:
																																								goto IL_13f8;
																																							case 283:
																																								goto IL_140b;
																																							case 87:
																																								goto IL_1419;
																																							case 208:
																																							case 232:
																																								goto IL_1427;
																																							case 207:
																																								goto IL_1479;
																																							case 47:
																																								goto IL_148c;
																																							case 325:
																																								goto IL_1497;
																																							case 167:
																																								goto IL_14a5;
																																							case 72:
																																							case 256:
																																								goto IL_14b3;
																																							case 164:
																																								goto IL_14cd;
																																							case 100:
																																								goto IL_14db;
																																							case 275:
																																								goto IL_14e9;
																																							case 195:
																																								goto IL_1505;
																																							case 4:
																																							case 213:
																																								goto IL_1513;
																																							case 267:
																																								goto IL_1551;
																																							case 292:
																																								goto IL_1565;
																																							case 318:
																																								goto IL_1578;
																																							case 304:
																																								goto IL_1586;
																																							case 41:
																																							case 324:
																																								goto IL_1591;
																																							case 215:
																																								goto IL_159f;
																																							case 336:
																																								goto IL_15bd;
																																							case 92:
																																								goto IL_15cb;
																																							case 59:
																																								goto IL_15de;
																																							case 117:
																																								goto IL_15ec;
																																							case 93:
																																							case 130:
																																								goto IL_15fa;
																																							case 104:
																																								goto IL_1616;
																																							case 185:
																																								goto IL_1624;
																																							case 173:
																																							case 238:
																																								goto IL_1632;
																																							case 83:
																																								goto IL_164f;
																																							case 273:
																																								goto IL_16a1;
																																							case 46:
																																								goto IL_16af;
																																							case 145:
																																								goto IL_16c2;
																																							case 341:
																																								goto IL_16d2;
																																							case 343:
																																								goto IL_16e5;
																																							case 27:
																																							case 308:
																																								goto IL_16f3;
																																							case 11:
																																								goto IL_170c;
																																							case 184:
																																								goto IL_171a;
																																							case 179:
																																								goto IL_1728;
																																							case 344:
																																								goto IL_173b;
																																							case 142:
																																								goto IL_1749;
																																							case 231:
																																								goto IL_1757;
																																							case 345:
																																								goto IL_176a;
																																							case 346:
																																								goto IL_177d;
																																							case 294:
																																								goto IL_178b;
																																							case 277:
																																								goto IL_17dd;
																																							case 0:
																																								goto IL_17f0;
																																							case 301:
																																								goto IL_17fe;
																																							case 143:
																																							case 237:
																																								goto IL_180c;
																																							case 79:
																																								goto IL_1823;
																																							case 289:
																																								goto IL_1847;
																																							case 109:
																																								goto IL_1855;
																																							case 136:
																																								goto IL_1868;
																																							case 68:
																																								goto IL_1873;
																																							case 8:
																																							case 269:
																																								goto IL_187e;
																																							case 126:
																																								goto IL_188c;
																																							case 180:
																																								goto IL_18b8;
																																							case 223:
																																								goto IL_18c6;
																																							case 13:
																																								goto IL_18d6;
																																							case 9:
																																								goto IL_18e1;
																																							case 10:
																																							case 14:
																																							case 16:
																																							case 38:
																																							case 49:
																																							case 57:
																																							case 70:
																																							case 73:
																																							case 80:
																																							case 90:
																																							case 94:
																																							case 95:
																																							case 97:
																																							case 101:
																																							case 102:
																																							case 121:
																																							case 124:
																																							case 139:
																																							case 148:
																																							case 150:
																																							case 154:
																																							case 165:
																																							case 168:
																																							case 169:
																																							case 172:
																																							case 174:
																																							case 181:
																																							case 205:
																																							case 209:
																																							case 218:
																																							case 224:
																																							case 227:
																																							case 246:
																																							case 249:
																																							case 251:
																																							case 264:
																																							case 272:
																																							case 278:
																																							case 300:
																																							case 309:
																																							case 320:
																																							case 327:
																																							case 335:
																																							case 342:
																																								goto end_IL_05c5;
																																							case 6:
																																							case 12:
																																							case 23:
																																							case 32:
																																							case 40:
																																							case 53:
																																							case 63:
																																							case 67:
																																							case 77:
																																							case 84:
																																							case 96:
																																							case 105:
																																							case 112:
																																							case 116:
																																							case 119:
																																							case 123:
																																							case 135:
																																							case 137:
																																							case 138:
																																							case 155:
																																							case 161:
																																							case 166:
																																							case 175:
																																							case 186:
																																							case 187:
																																							case 190:
																																							case 203:
																																							case 204:
																																							case 230:
																																							case 253:
																																							case 257:
																																							case 258:
																																							case 274:
																																							case 280:
																																							case 288:
																																							case 293:
																																							case 295:
																																							case 296:
																																							case 297:
																																							case 311:
																																							case 313:
																																							case 316:
																																							case 326:
																																							case 340:
																																								goto IL_18ff;
																																							case 242:
																																								goto IL_1912;
																																							case 110:
																																								goto IL_191c;
																																							case 307:
																																								goto IL_1927;
																																							case 141:
																																								goto IL_1937;
																																							case 76:
																																								goto IL_1947;
																																							case 45:
																																								goto IL_1957;
																																							case 62:
																																								goto IL_1967;
																																							case 233:
																																								goto IL_1977;
																																							case 329:
																																								goto IL_1987;
																																							case 200:
																																								goto IL_1997;
																																							case 39:
																																								goto IL_19a7;
																																							case 128:
																																								goto IL_19c0;
																																							case 31:
																																							case 147:
																																								goto IL_19db;
																																							}
																																							goto end_IL_063f;
																																						}
																																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																						goto IL_17dd;
																																						IL_17dd:
																																						ptr2 += 8;
																																						goto IL_18ff;
																																						continue;
																																						end_IL_0593:
																																						break;
																																					}
																																					break;
																																				}
																																				goto IL_0f8b;
																																				continue;
																																				end_IL_05c5:
																																				break;
																																				IL_05c5:;
																																			}
																																			break;
																																		}
																																		goto IL_17f0;
																																		IL_1855:
																																		ptr2 += 8;
																																		goto IL_18ff;
																																		IL_17f0:
																																		if (38 < b)
																																		{
																																			break;
																																		}
																																		goto IL_17fe;
																																		IL_17fe:
																																		if (38 > b)
																																		{
																																			break;
																																		}
																																		goto IL_180c;
																																		IL_180c:
																																		array2[num6] = 3;
																																		num = 79;
																																		goto IL_1823;
																																		IL_1823:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																																		goto IL_1847;
																																		IL_1847:
																																		num6++;
																																		goto IL_1855;
																																	}
																																	break;
																																}
																																goto IL_066a;
																																IL_1013:
																																array2[num6 - 1] = 0;
																																goto IL_18ff;
																																IL_066a:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_1013;
																															}
																															break;
																														}
																														goto IL_1868;
																														IL_18e1:
																														if (41 <= b)
																														{
																														}
																														break;
																														IL_1868:
																														if (40 >= b)
																														{
																															goto IL_1873;
																														}
																														goto IL_18d6;
																														IL_1873:
																														if (40 > b)
																														{
																															break;
																														}
																														goto IL_187e;
																														IL_187e:
																														array2[num6] = 4;
																														goto IL_188c;
																														IL_188c:
																														array3[num6] = ((delegate*<Color>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																														num = 180;
																														goto IL_18b8;
																														IL_18b8:
																														num6++;
																														goto IL_18c6;
																														IL_18c6:
																														ptr2 += 8;
																														goto IL_18ff;
																														IL_18d6:
																														if (41 < b)
																														{
																															break;
																														}
																														goto IL_18e1;
																													}
																													break;
																												}
																												goto IL_0711;
																												IL_0a60:
																												num6--;
																												goto IL_18ff;
																												IL_0711:
																												if (36 <= b)
																												{
																													goto IL_071f;
																												}
																												goto IL_08b3;
																												IL_071f:
																												((Class184)array3[num6 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_074d;
																												IL_074d:
																												num6 -= 2;
																												goto IL_18ff;
																												IL_08b3:
																												if (33 >= b)
																												{
																													goto IL_08c1;
																												}
																												goto IL_0953;
																												IL_08c1:
																												if (33 <= b)
																												{
																													goto IL_08cc;
																												}
																												goto IL_0932;
																												IL_08cc:
																												array2[num6 - 1] = 0;
																												goto IL_08e0;
																												IL_08e0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_091f;
																												IL_091f:
																												ptr2 += 8;
																												goto IL_18ff;
																												IL_0932:
																												if (32 < b)
																												{
																													break;
																												}
																												goto IL_0940;
																												IL_0940:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_0fac;
																												IL_0fac:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0fec;
																												IL_0fec:
																												array2[num6 - 2] = 3;
																												goto IL_1000;
																												IL_1000:
																												num6--;
																												goto IL_18ff;
																												IL_0953:
																												if (34 >= b)
																												{
																													goto IL_0961;
																												}
																												goto IL_09f0;
																												IL_0961:
																												if (34 > b)
																												{
																													break;
																												}
																												goto IL_096f;
																												IL_096f:
																												ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_09dd;
																												IL_09dd:
																												num6 -= 2;
																												goto IL_18ff;
																												IL_09f0:
																												if (35 < b)
																												{
																													break;
																												}
																												goto IL_09fe;
																												IL_09fe:
																												if (35 > b)
																												{
																													break;
																												}
																												goto IL_0a0c;
																												IL_0a0c:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0a4c;
																												IL_0a4c:
																												array2[num6 - 2] = 3;
																												goto IL_0a60;
																											}
																											break;
																										}
																										goto IL_0b5b;
																										IL_171a:
																										num6++;
																										goto IL_1728;
																										IL_0b5b:
																										if (31 <= b)
																										{
																											goto IL_0b69;
																										}
																										goto IL_12f2;
																										IL_0b69:
																										array2[num6 - 1] = 3;
																										goto IL_0b7d;
																										IL_0b7d:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0bbc;
																										IL_0bbc:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_12f2:
																										if (26 >= b)
																										{
																											goto IL_1300;
																										}
																										goto IL_1578;
																										IL_1300:
																										if (26 <= b)
																										{
																											goto IL_130e;
																										}
																										goto IL_13ab;
																										IL_130e:
																										array2[num6 - 3] = 4;
																										goto IL_1322;
																										IL_1322:
																										array3[num6 - 3] = ((delegate*<float, float, float, Color>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																										goto IL_138a;
																										IL_138a:
																										num6 -= 2;
																										goto IL_1398;
																										IL_1398:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_13ab:
																										if (23 >= b)
																										{
																											goto IL_13b9;
																										}
																										goto IL_148c;
																										IL_13b9:
																										if (23 <= b)
																										{
																											goto IL_13c4;
																										}
																										goto IL_140b;
																										IL_13c4:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_13dc;
																										IL_13dc:
																										array2[num6] = 5;
																										goto IL_13ea;
																										IL_13ea:
																										num6++;
																										goto IL_13f8;
																										IL_13f8:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_140b:
																										if (22 < b)
																										{
																											break;
																										}
																										goto IL_1419;
																										IL_1419:
																										if (22 > b)
																										{
																											break;
																										}
																										goto IL_1427;
																										IL_1427:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_1479;
																										IL_1479:
																										num6--;
																										goto IL_18ff;
																										IL_148c:
																										if (24 < b)
																										{
																											goto IL_1497;
																										}
																										num = 195;
																										goto IL_1505;
																										IL_1497:
																										if (25 < b)
																										{
																											break;
																										}
																										goto IL_14a5;
																										IL_14a5:
																										if (25 > b)
																										{
																											break;
																										}
																										goto IL_14b3;
																										IL_14b3:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																										goto IL_14cd;
																										IL_14cd:
																										array2[num6] = 3;
																										goto IL_14db;
																										IL_14db:
																										num6++;
																										goto IL_14e9;
																										IL_14e9:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_1728:
																										ptr2 += 16;
																										goto IL_18ff;
																										IL_1505:
																										if (24 > b)
																										{
																											break;
																										}
																										goto IL_1513;
																										IL_1513:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class184, float>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((Class184)array3[num6 - 1]);
																										goto IL_1551;
																										IL_1551:
																										array2[num6 - 1] = 3;
																										goto IL_1565;
																										IL_1565:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_1578:
																										if (28 >= b)
																										{
																											goto IL_1586;
																										}
																										goto IL_1616;
																										IL_1586:
																										if (28 <= b)
																										{
																											goto IL_1591;
																										}
																										goto IL_15de;
																										IL_1591:
																										array2[num6] = 5;
																										goto IL_159f;
																										IL_159f:
																										array3[num6] = ((delegate*<string>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																										goto IL_15bd;
																										IL_15bd:
																										num6++;
																										goto IL_15cb;
																										IL_15cb:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_15de:
																										if (27 < b)
																										{
																											break;
																										}
																										goto IL_15ec;
																										IL_15ec:
																										if (27 > b)
																										{
																											break;
																										}
																										goto IL_15fa;
																										IL_15fa:
																										num7 = ptr2;
																										num8 = -200;
																										num5 = 1;
																										ptr2 = num7 + num8;
																										goto IL_18ff;
																										IL_1616:
																										if (29 >= b)
																										{
																											goto IL_1624;
																										}
																										goto IL_16c2;
																										IL_1624:
																										if (29 > b)
																										{
																											break;
																										}
																										goto IL_1632;
																										IL_1632:
																										array2[num6 - 2] = 0;
																										num = 83;
																										goto IL_164f;
																										IL_164f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																										goto IL_16a1;
																										IL_16a1:
																										num6--;
																										goto IL_16af;
																										IL_16af:
																										ptr2 += 8;
																										goto IL_18ff;
																										IL_16c2:
																										if (30 < b)
																										{
																											break;
																										}
																										goto IL_16e5;
																										IL_16e5:
																										if (30 > b)
																										{
																											break;
																										}
																										goto IL_16f3;
																										IL_16f3:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																										goto IL_170c;
																										IL_170c:
																										array2[num6] = 3;
																										goto IL_171a;
																									}
																									break;
																								}
																								goto IL_069a;
																								IL_173b:
																								array2[num6] = 1;
																								goto IL_1749;
																								IL_069a:
																								if (21 > b)
																								{
																									goto IL_06a8;
																								}
																								goto IL_0bcf;
																								IL_06a8:
																								if (10 >= b)
																								{
																									goto IL_06b3;
																								}
																								goto IL_06d4;
																								IL_06b3:
																								if (10 > b)
																								{
																									goto IL_06c1;
																								}
																								goto IL_0760;
																								IL_06c1:
																								if (5 >= b)
																								{
																									goto IL_07d5;
																								}
																								goto IL_106e;
																								IL_07d5:
																								if (5 <= b)
																								{
																									goto IL_07e0;
																								}
																								goto IL_0847;
																								IL_07e0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0820;
																								IL_0820:
																								array2[num6 - 2] = 0;
																								goto IL_0834;
																								IL_0834:
																								num6--;
																								goto IL_18ff;
																								IL_0847:
																								if (2 < b)
																								{
																									goto IL_0852;
																								}
																								num = 261;
																								goto IL_0a73;
																								IL_0852:
																								if (3 >= b)
																								{
																									goto IL_0860;
																								}
																								goto IL_0b3a;
																								IL_0860:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_086e;
																								IL_086e:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 346;
																								goto IL_177d;
																								IL_177d:
																								ptr2 += 8;
																								goto IL_178b;
																								IL_178b:
																								num6--;
																								goto IL_18ff;
																								IL_0b3a:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0b48;
																								IL_0b48:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_11b8;
																								IL_11b8:
																								array2[num6] = 0;
																								goto IL_11c6;
																								IL_11c6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_11e9;
																								IL_11e9:
																								array3[num6] = null;
																								goto IL_11f3;
																								IL_11f3:
																								num6++;
																								num = 85;
																								goto IL_120a;
																								IL_120a:
																								ptr2 += 8;
																								goto IL_18ff;
																								IL_1749:
																								num6++;
																								goto IL_1757;
																								IL_0a73:
																								if (2 <= b)
																								{
																									goto IL_0a7e;
																								}
																								goto IL_0ad7;
																								IL_0a7e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0abe;
																								IL_0abe:
																								array2[num6 - 2] = 0;
																								goto IL_16d2;
																								IL_16d2:
																								num6--;
																								goto IL_18ff;
																								IL_0ad7:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0ae5;
																								IL_0ae5:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0f25;
																								IL_0f25:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0f3e;
																								IL_0f3e:
																								array2[num6] = 0;
																								goto IL_0f4c;
																								IL_0f4c:
																								num6++;
																								goto IL_0f5a;
																								IL_0f5a:
																								ptr2 += 8;
																								goto IL_18ff;
																								IL_106e:
																								if (7 >= b)
																								{
																									goto IL_107c;
																								}
																								goto IL_1116;
																								IL_107c:
																								if (7 > b)
																								{
																									goto IL_108a;
																								}
																								goto IL_1244;
																								IL_108a:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_1098;
																								IL_1098:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_10a6;
																								IL_10a6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_10e6;
																								IL_10e6:
																								array2[num6 - 2] = 0;
																								num = 122;
																								goto IL_1103;
																								IL_1103:
																								num6--;
																								goto IL_18ff;
																								IL_1244:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1284;
																								IL_1284:
																								array2[num6 - 2] = 0;
																								goto IL_1298;
																								IL_1298:
																								num6--;
																								goto IL_18ff;
																								IL_1116:
																								if (8 >= b)
																								{
																									goto IL_1121;
																								}
																								goto IL_1142;
																								IL_1121:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_112f;
																								IL_112f:
																								num6--;
																								goto IL_18ff;
																								IL_1142:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_1150;
																								IL_1150:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_115e;
																								IL_115e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_121d;
																								IL_121d:
																								array2[num6 - 2] = 0;
																								goto IL_1231;
																								IL_1231:
																								num6--;
																								goto IL_18ff;
																								IL_0760:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_07c2;
																								IL_07c2:
																								num6 -= 2;
																								goto IL_18ff;
																								IL_06d4:
																								if (15 >= b)
																								{
																									goto IL_06e2;
																								}
																								goto IL_0dba;
																								IL_06e2:
																								if (15 > b)
																								{
																									goto IL_06f0;
																								}
																								goto IL_0c58;
																								IL_06f0:
																								if (12 < b)
																								{
																									goto IL_06fe;
																								}
																								goto IL_0b0b;
																								IL_06fe:
																								if (13 >= b)
																								{
																									goto IL_0af8;
																								}
																								goto IL_0c37;
																								IL_0af8:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_0f6d;
																								IL_0f6d:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0f8b;
																								IL_0f8b:
																								ptr2 += 8;
																								goto IL_0f99;
																								IL_0f99:
																								num6--;
																								goto IL_18ff;
																								IL_0c37:
																								if (14 < b)
																								{
																									break;
																								}
																								goto IL_0c45;
																								IL_0c45:
																								if (14 > b)
																								{
																									break;
																								}
																								goto IL_102c;
																								IL_102c:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_1055;
																								IL_1055:
																								array2[num6 - 1] = 5;
																								goto IL_18ff;
																								IL_0b0b:
																								if (12 > b)
																								{
																									goto IL_0b19;
																								}
																								goto IL_0c75;
																								IL_0b19:
																								if (11 < b)
																								{
																									break;
																								}
																								goto IL_0b27;
																								IL_0b27:
																								if (11 > b)
																								{
																									break;
																								}
																								goto IL_18ff;
																								IL_0c75:
																								array8 = array3;
																								num9 = num6;
																								if (array == null)
																								{
																									goto IL_0c84;
																								}
																								num10 = ptr2;
																								byte b2 = *num10;
																								ptr2 = num10 + 4;
																								int num11 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num11;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0d2c;
																								IL_1757:
																								ptr2 += 16;
																								goto IL_18ff;
																								IL_0bcf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																								goto IL_0c10;
																								IL_0c10:
																								array2[num6 - 2] = 0;
																								goto IL_0c24;
																								IL_0d2c:
																								array2[num6] = 5;
																								goto IL_0d3a;
																								IL_0d3a:
																								num6++;
																								goto IL_18ff;
																								IL_0c58:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0d4d;
																								IL_0d4d:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0d6b;
																								IL_0d6b:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0d8f;
																								IL_0d8f:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0da7;
																								IL_0da7:
																								num6++;
																								goto IL_18ff;
																								IL_0dba:
																								if (18 >= b)
																								{
																									goto IL_0dc8;
																								}
																								goto IL_0ec4;
																								IL_0dc8:
																								if (18 > b)
																								{
																									goto IL_0dd6;
																								}
																								goto IL_0e5c;
																								IL_0dd6:
																								if (16 >= b)
																								{
																									goto IL_0de1;
																								}
																								goto IL_0df4;
																								IL_0de1:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_12ab;
																								IL_12ab:
																								array2[num6] = 5;
																								goto IL_12b9;
																								IL_12b9:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_12d1;
																								IL_12d1:
																								num6++;
																								goto IL_12df;
																								IL_12df:
																								ptr2 += 8;
																								goto IL_18ff;
																								IL_0df4:
																								if (17 < b)
																								{
																									break;
																								}
																								goto IL_0e02;
																								IL_0e02:
																								if (17 > b)
																								{
																									break;
																								}
																								goto IL_0e10;
																								IL_0e10:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								num = 345;
																								goto IL_176a;
																								IL_176a:
																								num6 -= 3;
																								goto IL_18ff;
																								IL_0e5c:
																								array2[num6 - 1] = 5;
																								goto IL_0e70;
																								IL_0e70:
																								array3[num6 - 1] = ((delegate*<string[], string>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0ea8;
																								IL_0ea8:
																								ptr2 += 8;
																								num = 40;
																								goto IL_18ff;
																								IL_0ec4:
																								if (19 < b)
																								{
																									goto IL_0ecf;
																								}
																								goto IL_0ef9;
																								IL_0ecf:
																								if (20 < b)
																								{
																									break;
																								}
																								num = 50;
																								goto IL_0ee6;
																								IL_0c24:
																								num6--;
																								goto IL_18ff;
																								IL_0ee6:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_11a0;
																								IL_11a0:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_18ff;
																								IL_0ef9:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_0f07;
																								IL_0f07:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_173b;
																							}
																							break;
																							IL_062f:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_18ff;
																					continue;
																					end_IL_063f:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_19db;
																	IL_19db:
																	return (Color)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0c84:
			while (true)
			{
				IL_0c84_2:
				array = new byte[4];
				while (true)
				{
					IL_0c92:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0d3a_2:
							num6++;
							while (true)
							{
								IL_18ff_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_063f_2:
												if (b >= 1)
												{
													while (b <= 41)
													{
														while (true)
														{
															IL_0622_2:
															if (21 < b)
															{
																while (true)
																{
																	IL_0612_2:
																	if (31 < b)
																	{
																		while (true)
																		{
																			IL_0602_2:
																			if (36 < b)
																			{
																				while (true)
																				{
																					IL_05f2_2:
																					if (39 >= b)
																					{
																						while (true)
																						{
																							IL_05e5_2:
																							if (39 > b)
																							{
																								while (true)
																								{
																									IL_05d5_2:
																									if (37 >= b)
																									{
																										while (37 <= b)
																										{
																											while (true)
																											{
																												IL_05a6_2:
																												array2[num6 - 1] = 3;
																												num = 353;
																												while (true)
																												{
																													if (num != 353)
																													{
																														if (num != 1334)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 198:
																														case 271:
																															goto IL_05a6_2;
																														case 66:
																															goto IL_05c5_2;
																														case 331:
																															goto IL_05d5_2;
																														case 199:
																															goto IL_05e5_2;
																														case 337:
																															goto IL_05f2_2;
																														case 299:
																															goto IL_0602_2;
																														case 183:
																															goto IL_0612_2;
																														case 285:
																															goto IL_0622_2;
																														case 240:
																															goto IL_062f_2;
																														case 60:
																															goto IL_063f_2;
																														case 132:
																															goto end_IL_063f_2;
																														case 15:
																														case 88:
																															goto end_IL_064f;
																														case 156:
																														case 188:
																															goto IL_066a_2;
																														case 214:
																															goto IL_069a_2;
																														case 171:
																															goto IL_06a8_2;
																														case 125:
																															goto IL_06b3_2;
																														case 35:
																															goto IL_06c1_2;
																														case 17:
																															goto IL_06d4_2;
																														case 210:
																															goto IL_06e2_2;
																														case 3:
																															goto IL_06f0_2;
																														case 108:
																															goto IL_06fe_2;
																														case 221:
																															goto IL_0711_2;
																														case 163:
																														case 197:
																															goto IL_071f_2;
																														case 159:
																															goto IL_074d_2;
																														case 43:
																														case 229:
																															goto IL_0760_2;
																														case 64:
																															goto IL_07c2_2;
																														case 255:
																															goto IL_07d5_2;
																														case 140:
																														case 241:
																															goto IL_07e0_2;
																														case 24:
																															goto IL_0820_2;
																														case 1:
																															goto IL_0834_2;
																														case 201:
																															goto IL_0847_2;
																														case 202:
																															goto IL_0852_2;
																														case 107:
																															goto IL_0860_2;
																														case 28:
																														case 78:
																															goto IL_086e_2;
																														case 259:
																															goto IL_08b3_2;
																														case 234:
																															goto IL_08c1_2;
																														case 212:
																														case 239:
																															goto IL_08cc_2;
																														case 158:
																															goto IL_08e0_2;
																														case 144:
																															goto IL_091f_2;
																														case 191:
																															goto IL_0932_2;
																														case 250:
																															goto IL_0940_2;
																														case 127:
																															goto IL_0953_2;
																														case 217:
																															goto IL_0961_2;
																														case 134:
																														case 244:
																															goto IL_096f_2;
																														case 74:
																															goto IL_09dd_2;
																														case 75:
																															goto IL_09f0_2;
																														case 106:
																															goto IL_09fe_2;
																														case 29:
																														case 36:
																															goto IL_0a0c_2;
																														case 26:
																															goto IL_0a4c_2;
																														case 61:
																															goto IL_0a60_2;
																														case 261:
																															goto IL_0a73_2;
																														case 42:
																														case 178:
																															goto IL_0a7e_2;
																														case 7:
																															goto IL_0abe_2;
																														case 157:
																															goto IL_0ad7_2;
																														case 25:
																															goto IL_0ae5_2;
																														case 279:
																															goto IL_0af8_2;
																														case 281:
																															goto IL_0b0b_2;
																														case 114:
																															goto IL_0b19_2;
																														case 176:
																															goto IL_0b27_2;
																														case 282:
																															goto IL_0b3a_2;
																														case 99:
																															goto IL_0b48_2;
																														case 286:
																															goto IL_0b5b_2;
																														case 18:
																														case 133:
																															goto IL_0b69_2;
																														case 235:
																															goto IL_0b7d_2;
																														case 30:
																															goto IL_0bbc_2;
																														case 194:
																														case 291:
																															goto IL_0bcf_2;
																														case 182:
																															goto IL_0c10_2;
																														case 252:
																															goto IL_0c24_2;
																														case 302:
																															goto IL_0c37_2;
																														case 54:
																															goto IL_0c45_2;
																														case 91:
																														case 303:
																															goto IL_0c58_2;
																														case 55:
																														case 306:
																															goto IL_0c75_2;
																														case 146:
																															goto end_IL_065f;
																														case 131:
																															goto IL_0d3a_2;
																														case 310:
																															goto IL_0d4d_2;
																														case 71:
																															goto IL_0d6b_2;
																														case 19:
																															goto IL_0d8f_2;
																														case 276:
																															goto IL_0da7_2;
																														case 314:
																															goto IL_0dba_2;
																														case 270:
																															goto IL_0dc8_2;
																														case 82:
																															goto IL_0dd6_2;
																														case 265:
																															goto IL_0de1_2;
																														case 189:
																															goto IL_0df4_2;
																														case 196:
																															goto IL_0e02_2;
																														case 247:
																														case 248:
																															goto IL_0e10_2;
																														case 56:
																														case 305:
																															goto IL_0e5c_2;
																														case 226:
																															goto IL_0e70_2;
																														case 86:
																															goto IL_0ea8_2;
																														case 34:
																															goto IL_0ec4_2;
																														case 151:
																															goto IL_0ecf_2;
																														case 50:
																															goto IL_0ee6_2;
																														case 69:
																															goto IL_0ef9_2;
																														case 2:
																														case 262:
																															goto IL_0f07_2;
																														case 206:
																														case 315:
																															goto IL_0f25_2;
																														case 89:
																															goto IL_0f3e_2;
																														case 65:
																															goto IL_0f4c_2;
																														case 20:
																															goto IL_0f5a_2;
																														case 222:
																														case 317:
																															goto IL_0f6d_2;
																														case 268:
																															goto end_IL_0593_2;
																														case 177:
																															goto IL_0f99_2;
																														case 111:
																														case 319:
																															goto IL_0fac_2;
																														case 192:
																															goto IL_0fec_2;
																														case 81:
																															goto IL_1000_2;
																														case 321:
																															goto IL_1013_2;
																														case 225:
																														case 322:
																															goto IL_102c_2;
																														case 33:
																															goto IL_1055_2;
																														case 323:
																															goto IL_106e_2;
																														case 236:
																															goto IL_107c_2;
																														case 245:
																															goto IL_108a_2;
																														case 149:
																															goto IL_1098_2;
																														case 52:
																														case 287:
																															goto IL_10a6_2;
																														case 266:
																															goto IL_10e6_2;
																														case 122:
																															goto IL_1103_2;
																														case 284:
																															goto IL_1116_2;
																														case 160:
																															goto IL_1121_2;
																														case 58:
																														case 243:
																															goto IL_112f_2;
																														case 216:
																															goto IL_1142_2;
																														case 260:
																															goto IL_1150_2;
																														case 21:
																														case 44:
																															goto IL_115e_2;
																														case 118:
																														case 328:
																															goto IL_11a0_2;
																														case 115:
																														case 332:
																															goto IL_11b8_2;
																														case 263:
																															goto IL_11c6_2;
																														case 120:
																															goto IL_11e9_2;
																														case 5:
																															goto IL_11f3_2;
																														case 85:
																															goto IL_120a_2;
																														case 333:
																															goto IL_121d_2;
																														case 211:
																															goto IL_1231_2;
																														case 22:
																														case 334:
																															goto IL_1244_2;
																														case 228:
																															goto IL_1284_2;
																														case 48:
																															goto IL_1298_2;
																														case 290:
																														case 338:
																															goto IL_12ab_2;
																														case 220:
																															goto IL_12b9_2;
																														case 37:
																															goto IL_12d1_2;
																														case 153:
																															goto IL_12df_2;
																														case 339:
																															goto IL_12f2_2;
																														case 193:
																															goto IL_1300_2;
																														case 103:
																														case 254:
																															goto IL_130e_2;
																														case 162:
																															goto IL_1322_2;
																														case 330:
																															goto IL_138a_2;
																														case 170:
																															goto IL_1398_2;
																														case 312:
																															goto IL_13ab_2;
																														case 219:
																															goto IL_13b9_2;
																														case 113:
																														case 152:
																															goto IL_13c4_2;
																														case 98:
																															goto IL_13dc_2;
																														case 298:
																															goto IL_13ea_2;
																														case 51:
																															goto IL_13f8_2;
																														case 283:
																															goto IL_140b_2;
																														case 87:
																															goto IL_1419_2;
																														case 208:
																														case 232:
																															goto IL_1427_2;
																														case 207:
																															goto IL_1479_2;
																														case 47:
																															goto IL_148c_2;
																														case 325:
																															goto IL_1497_2;
																														case 167:
																															goto IL_14a5_2;
																														case 72:
																														case 256:
																															goto IL_14b3_2;
																														case 164:
																															goto IL_14cd_2;
																														case 100:
																															goto IL_14db_2;
																														case 275:
																															goto IL_14e9_2;
																														case 195:
																															goto IL_1505_2;
																														case 4:
																														case 213:
																															goto IL_1513_2;
																														case 267:
																															goto IL_1551_2;
																														case 292:
																															goto IL_1565_2;
																														case 318:
																															goto IL_1578_2;
																														case 304:
																															goto IL_1586_2;
																														case 41:
																														case 324:
																															goto IL_1591_2;
																														case 215:
																															goto IL_159f_2;
																														case 336:
																															goto IL_15bd_2;
																														case 92:
																															goto IL_15cb_2;
																														case 59:
																															goto IL_15de_2;
																														case 117:
																															goto IL_15ec_2;
																														case 93:
																														case 130:
																															goto IL_15fa_2;
																														case 104:
																															goto IL_1616_2;
																														case 185:
																															goto IL_1624_2;
																														case 173:
																														case 238:
																															goto IL_1632_2;
																														case 83:
																															goto IL_164f_2;
																														case 273:
																															goto IL_16a1_2;
																														case 46:
																															goto IL_16af_2;
																														case 145:
																															goto IL_16c2_2;
																														case 341:
																															goto IL_16d2_2;
																														case 343:
																															goto IL_16e5_2;
																														case 27:
																														case 308:
																															goto IL_16f3_2;
																														case 11:
																															goto IL_170c_2;
																														case 184:
																															goto IL_171a_2;
																														case 179:
																															goto IL_1728_2;
																														case 344:
																															goto IL_173b_2;
																														case 142:
																															goto IL_1749_2;
																														case 231:
																															goto IL_1757_2;
																														case 345:
																															goto IL_176a_2;
																														case 346:
																															goto IL_177d_2;
																														case 294:
																															goto IL_178b_2;
																														case 277:
																															goto IL_17dd_2;
																														case 0:
																															goto IL_17f0_2;
																														case 301:
																															goto IL_17fe_2;
																														case 143:
																														case 237:
																															goto IL_180c_2;
																														case 79:
																															goto IL_1823_2;
																														case 289:
																															goto IL_1847_2;
																														case 109:
																															goto IL_1855_2;
																														case 136:
																															goto IL_1868_2;
																														case 68:
																															goto IL_1873_2;
																														case 8:
																														case 269:
																															goto IL_187e_2;
																														case 126:
																															goto IL_188c_2;
																														case 180:
																															goto IL_18b8_2;
																														case 223:
																															goto IL_18c6_2;
																														case 13:
																															goto IL_18d6_2;
																														case 9:
																															goto IL_18e1_2;
																														case 10:
																														case 14:
																														case 16:
																														case 38:
																														case 49:
																														case 57:
																														case 70:
																														case 73:
																														case 80:
																														case 90:
																														case 94:
																														case 95:
																														case 97:
																														case 101:
																														case 102:
																														case 121:
																														case 124:
																														case 139:
																														case 148:
																														case 150:
																														case 154:
																														case 165:
																														case 168:
																														case 169:
																														case 172:
																														case 174:
																														case 181:
																														case 205:
																														case 209:
																														case 218:
																														case 224:
																														case 227:
																														case 246:
																														case 249:
																														case 251:
																														case 264:
																														case 272:
																														case 278:
																														case 300:
																														case 309:
																														case 320:
																														case 327:
																														case 335:
																														case 342:
																															goto end_IL_05c5_2;
																														case 6:
																														case 12:
																														case 23:
																														case 32:
																														case 40:
																														case 53:
																														case 63:
																														case 67:
																														case 77:
																														case 84:
																														case 96:
																														case 105:
																														case 112:
																														case 116:
																														case 119:
																														case 123:
																														case 135:
																														case 137:
																														case 138:
																														case 155:
																														case 161:
																														case 166:
																														case 175:
																														case 186:
																														case 187:
																														case 190:
																														case 203:
																														case 204:
																														case 230:
																														case 253:
																														case 257:
																														case 258:
																														case 274:
																														case 280:
																														case 288:
																														case 293:
																														case 295:
																														case 296:
																														case 297:
																														case 311:
																														case 313:
																														case 316:
																														case 326:
																														case 340:
																															goto IL_18ff_2;
																														case 242:
																															ptr2 = ptr;
																															goto IL_18ff_2;
																														case 110:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DayTypeForwardedFromAttribute.LdelemRHashElementTransformMetadata);
																															goto case 242;
																														case 307:
																															array7[0] = this;
																															goto case 110;
																														case 141:
																															array7 = new object[9];
																															goto case 307;
																														case 76:
																															array6 = new long[4];
																															goto case 141;
																														case 45:
																															array5 = new int[7];
																															goto case 76;
																														case 62:
																															array4 = new int[4];
																															goto case 45;
																														case 233:
																															array3 = new object[4];
																															goto case 62;
																														case 329:
																															array2 = new byte[4];
																															goto case 233;
																														case 200:
																															num4 = num2 * 8;
																															goto case 329;
																														case 39:
																															num3 = num2 * 4;
																															num = 200;
																															goto case 200;
																														case 128:
																															num2 = 1;
																															goto case 39;
																														case 129:
																															goto end_IL_0d2c;
																														case 31:
																														case 147:
																															goto IL_19db_2;
																														}
																														continue;
																													}
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_17dd_2;
																													IL_17dd_2:
																													ptr2 += 8;
																													goto IL_18ff_2;
																													continue;
																													end_IL_0593_2:
																													break;
																												}
																												break;
																											}
																											goto IL_0f8b_2;
																											continue;
																											end_IL_05c5_2:
																											break;
																											IL_05c5_2:;
																										}
																										break;
																									}
																									goto IL_17f0_2;
																									IL_1855_2:
																									ptr2 += 8;
																									goto IL_18ff_2;
																									IL_17f0_2:
																									if (38 < b)
																									{
																										break;
																									}
																									goto IL_17fe_2;
																									IL_17fe_2:
																									if (38 > b)
																									{
																										break;
																									}
																									goto IL_180c_2;
																									IL_180c_2:
																									array2[num6] = 3;
																									num = 79;
																									goto IL_1823_2;
																									IL_1823_2:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																									goto IL_1847_2;
																									IL_1847_2:
																									num6++;
																									goto IL_1855_2;
																								}
																								break;
																							}
																							goto IL_066a_2;
																							IL_1013_2:
																							array2[num6 - 1] = 0;
																							goto IL_18ff_2;
																							IL_066a_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1013_2;
																						}
																						break;
																					}
																					goto IL_1868_2;
																					IL_18e1_2:
																					if (41 <= b)
																					{
																					}
																					break;
																					IL_1868_2:
																					if (40 >= b)
																					{
																						goto IL_1873_2;
																					}
																					goto IL_18d6_2;
																					IL_1873_2:
																					if (40 > b)
																					{
																						break;
																					}
																					goto IL_187e_2;
																					IL_187e_2:
																					array2[num6] = 4;
																					goto IL_188c_2;
																					IL_188c_2:
																					array3[num6] = ((delegate*<Color>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																					num = 180;
																					goto IL_18b8_2;
																					IL_18b8_2:
																					num6++;
																					goto IL_18c6_2;
																					IL_18c6_2:
																					ptr2 += 8;
																					goto IL_18ff_2;
																					IL_18d6_2:
																					if (41 < b)
																					{
																						break;
																					}
																					goto IL_18e1_2;
																				}
																				break;
																			}
																			goto IL_0711_2;
																			IL_0a60_2:
																			num6--;
																			goto IL_18ff_2;
																			IL_0711_2:
																			if (36 <= b)
																			{
																				goto IL_071f_2;
																			}
																			goto IL_08b3_2;
																			IL_071f_2:
																			((Class184)array3[num6 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_074d_2;
																			IL_074d_2:
																			num6 -= 2;
																			goto IL_18ff_2;
																			IL_08b3_2:
																			if (33 >= b)
																			{
																				goto IL_08c1_2;
																			}
																			goto IL_0953_2;
																			IL_08c1_2:
																			if (33 <= b)
																			{
																				goto IL_08cc_2;
																			}
																			goto IL_0932_2;
																			IL_08cc_2:
																			array2[num6 - 1] = 0;
																			goto IL_08e0_2;
																			IL_08e0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_091f_2;
																			IL_091f_2:
																			ptr2 += 8;
																			goto IL_18ff_2;
																			IL_0932_2:
																			if (32 < b)
																			{
																				break;
																			}
																			goto IL_0940_2;
																			IL_0940_2:
																			if (32 > b)
																			{
																				break;
																			}
																			goto IL_0fac_2;
																			IL_0fac_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0fec_2;
																			IL_0fec_2:
																			array2[num6 - 2] = 3;
																			goto IL_1000_2;
																			IL_1000_2:
																			num6--;
																			goto IL_18ff_2;
																			IL_0953_2:
																			if (34 >= b)
																			{
																				goto IL_0961_2;
																			}
																			goto IL_09f0_2;
																			IL_0961_2:
																			if (34 > b)
																			{
																				break;
																			}
																			goto IL_096f_2;
																			IL_096f_2:
																			ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_09dd_2;
																			IL_09dd_2:
																			num6 -= 2;
																			goto IL_18ff_2;
																			IL_09f0_2:
																			if (35 < b)
																			{
																				break;
																			}
																			goto IL_09fe_2;
																			IL_09fe_2:
																			if (35 > b)
																			{
																				break;
																			}
																			goto IL_0a0c_2;
																			IL_0a0c_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0a4c_2;
																			IL_0a4c_2:
																			array2[num6 - 2] = 3;
																			goto IL_0a60_2;
																		}
																		break;
																	}
																	goto IL_0b5b_2;
																	IL_171a_2:
																	num6++;
																	goto IL_1728_2;
																	IL_0b5b_2:
																	if (31 <= b)
																	{
																		goto IL_0b69_2;
																	}
																	goto IL_12f2_2;
																	IL_0b69_2:
																	array2[num6 - 1] = 3;
																	goto IL_0b7d_2;
																	IL_0b7d_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_0bbc_2;
																	IL_0bbc_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_12f2_2:
																	if (26 >= b)
																	{
																		goto IL_1300_2;
																	}
																	goto IL_1578_2;
																	IL_1300_2:
																	if (26 <= b)
																	{
																		goto IL_130e_2;
																	}
																	goto IL_13ab_2;
																	IL_130e_2:
																	array2[num6 - 3] = 4;
																	goto IL_1322_2;
																	IL_1322_2:
																	array3[num6 - 3] = ((delegate*<float, float, float, Color>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																	goto IL_138a_2;
																	IL_138a_2:
																	num6 -= 2;
																	goto IL_1398_2;
																	IL_1398_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_13ab_2:
																	if (23 >= b)
																	{
																		goto IL_13b9_2;
																	}
																	goto IL_148c_2;
																	IL_13b9_2:
																	if (23 <= b)
																	{
																		goto IL_13c4_2;
																	}
																	goto IL_140b_2;
																	IL_13c4_2:
																	array3[num6] = array7[*(int*)(ptr2 + num3)];
																	goto IL_13dc_2;
																	IL_13dc_2:
																	array2[num6] = 5;
																	goto IL_13ea_2;
																	IL_13ea_2:
																	num6++;
																	goto IL_13f8_2;
																	IL_13f8_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_140b_2:
																	if (22 < b)
																	{
																		break;
																	}
																	goto IL_1419_2;
																	IL_1419_2:
																	if (22 > b)
																	{
																		break;
																	}
																	goto IL_1427_2;
																	IL_1427_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_1479_2;
																	IL_1479_2:
																	num6--;
																	goto IL_18ff_2;
																	IL_148c_2:
																	if (24 < b)
																	{
																		goto IL_1497_2;
																	}
																	num = 195;
																	goto IL_1505_2;
																	IL_1497_2:
																	if (25 < b)
																	{
																		break;
																	}
																	goto IL_14a5_2;
																	IL_14a5_2:
																	if (25 > b)
																	{
																		break;
																	}
																	goto IL_14b3_2;
																	IL_14b3_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																	goto IL_14cd_2;
																	IL_14cd_2:
																	array2[num6] = 3;
																	goto IL_14db_2;
																	IL_14db_2:
																	num6++;
																	goto IL_14e9_2;
																	IL_14e9_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_1728_2:
																	ptr2 += 16;
																	goto IL_18ff_2;
																	IL_1505_2:
																	if (24 > b)
																	{
																		break;
																	}
																	goto IL_1513_2;
																	IL_1513_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class184, float>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((Class184)array3[num6 - 1]);
																	goto IL_1551_2;
																	IL_1551_2:
																	array2[num6 - 1] = 3;
																	goto IL_1565_2;
																	IL_1565_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_1578_2:
																	if (28 >= b)
																	{
																		goto IL_1586_2;
																	}
																	goto IL_1616_2;
																	IL_1586_2:
																	if (28 <= b)
																	{
																		goto IL_1591_2;
																	}
																	goto IL_15de_2;
																	IL_1591_2:
																	array2[num6] = 5;
																	goto IL_159f_2;
																	IL_159f_2:
																	array3[num6] = ((delegate*<string>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])();
																	goto IL_15bd_2;
																	IL_15bd_2:
																	num6++;
																	goto IL_15cb_2;
																	IL_15cb_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_15de_2:
																	if (27 < b)
																	{
																		break;
																	}
																	goto IL_15ec_2;
																	IL_15ec_2:
																	if (27 > b)
																	{
																		break;
																	}
																	goto IL_15fa_2;
																	IL_15fa_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto IL_18ff_2;
																	IL_1616_2:
																	if (29 >= b)
																	{
																		goto IL_1624_2;
																	}
																	goto IL_16c2_2;
																	IL_1624_2:
																	if (29 > b)
																	{
																		break;
																	}
																	goto IL_1632_2;
																	IL_1632_2:
																	array2[num6 - 2] = 0;
																	num = 83;
																	goto IL_164f_2;
																	IL_164f_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																	goto IL_16a1_2;
																	IL_16a1_2:
																	num6--;
																	goto IL_16af_2;
																	IL_16af_2:
																	ptr2 += 8;
																	goto IL_18ff_2;
																	IL_16c2_2:
																	if (30 < b)
																	{
																		break;
																	}
																	goto IL_16e5_2;
																	IL_16e5_2:
																	if (30 > b)
																	{
																		break;
																	}
																	goto IL_16f3_2;
																	IL_16f3_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																	goto IL_170c_2;
																	IL_170c_2:
																	array2[num6] = 3;
																	goto IL_171a_2;
																}
																break;
															}
															goto IL_069a_2;
															IL_0bcf_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_0c10_2;
															IL_069a_2:
															if (21 > b)
															{
																goto IL_06a8_2;
															}
															goto IL_0bcf_2;
															IL_06a8_2:
															if (10 >= b)
															{
																goto IL_06b3_2;
															}
															goto IL_06d4_2;
															IL_06b3_2:
															if (10 > b)
															{
																goto IL_06c1_2;
															}
															goto IL_0760_2;
															IL_06c1_2:
															if (5 >= b)
															{
																goto IL_07d5_2;
															}
															goto IL_106e_2;
															IL_07d5_2:
															if (5 <= b)
															{
																goto IL_07e0_2;
															}
															goto IL_0847_2;
															IL_07e0_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0820_2;
															IL_0820_2:
															array2[num6 - 2] = 0;
															goto IL_0834_2;
															IL_0834_2:
															num6--;
															goto IL_18ff_2;
															IL_0847_2:
															if (2 < b)
															{
																goto IL_0852_2;
															}
															num = 261;
															goto IL_0a73_2;
															IL_0852_2:
															if (3 >= b)
															{
																goto IL_0860_2;
															}
															goto IL_0b3a_2;
															IL_0860_2:
															if (3 > b)
															{
																break;
															}
															goto IL_086e_2;
															IL_086e_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 346;
															goto IL_177d_2;
															IL_177d_2:
															ptr2 += 8;
															goto IL_178b_2;
															IL_178b_2:
															num6--;
															goto IL_18ff_2;
															IL_0b3a_2:
															if (4 < b)
															{
																break;
															}
															goto IL_0b48_2;
															IL_0b48_2:
															if (4 > b)
															{
																break;
															}
															goto IL_11b8_2;
															IL_11b8_2:
															array2[num6] = 0;
															goto IL_11c6_2;
															IL_11c6_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
															goto IL_11e9_2;
															IL_11e9_2:
															array3[num6] = null;
															goto IL_11f3_2;
															IL_11f3_2:
															num6++;
															num = 85;
															goto IL_120a_2;
															IL_120a_2:
															ptr2 += 8;
															goto IL_18ff_2;
															IL_0c10_2:
															array2[num6 - 2] = 0;
															goto IL_0c24_2;
															IL_0a73_2:
															if (2 <= b)
															{
																goto IL_0a7e_2;
															}
															goto IL_0ad7_2;
															IL_0a7e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0abe_2;
															IL_0abe_2:
															array2[num6 - 2] = 0;
															goto IL_16d2_2;
															IL_16d2_2:
															num6--;
															goto IL_18ff_2;
															IL_0ad7_2:
															if (1 < b)
															{
																break;
															}
															goto IL_0ae5_2;
															IL_0ae5_2:
															if (1 > b)
															{
																break;
															}
															goto IL_0f25_2;
															IL_0f25_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
															goto IL_0f3e_2;
															IL_0f3e_2:
															array2[num6] = 0;
															goto IL_0f4c_2;
															IL_0f4c_2:
															num6++;
															goto IL_0f5a_2;
															IL_0f5a_2:
															ptr2 += 8;
															goto IL_18ff_2;
															IL_106e_2:
															if (7 >= b)
															{
																goto IL_107c_2;
															}
															goto IL_1116_2;
															IL_107c_2:
															if (7 > b)
															{
																goto IL_108a_2;
															}
															goto IL_1244_2;
															IL_108a_2:
															if (6 < b)
															{
																break;
															}
															goto IL_1098_2;
															IL_1098_2:
															if (6 > b)
															{
																break;
															}
															goto IL_10a6_2;
															IL_10a6_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_10e6_2;
															IL_10e6_2:
															array2[num6 - 2] = 0;
															num = 122;
															goto IL_1103_2;
															IL_1103_2:
															num6--;
															goto IL_18ff_2;
															IL_1244_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1284_2;
															IL_1284_2:
															array2[num6 - 2] = 0;
															goto IL_1298_2;
															IL_1298_2:
															num6--;
															goto IL_18ff_2;
															IL_1116_2:
															if (8 >= b)
															{
																goto IL_1121_2;
															}
															goto IL_1142_2;
															IL_1121_2:
															if (8 > b)
															{
																break;
															}
															goto IL_112f_2;
															IL_112f_2:
															num6--;
															goto IL_18ff_2;
															IL_1142_2:
															if (9 < b)
															{
																break;
															}
															goto IL_1150_2;
															IL_1150_2:
															if (9 > b)
															{
																break;
															}
															goto IL_115e_2;
															IL_115e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_121d_2;
															IL_121d_2:
															array2[num6 - 2] = 0;
															goto IL_1231_2;
															IL_1231_2:
															num6--;
															goto IL_18ff_2;
															IL_0760_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_07c2_2;
															IL_07c2_2:
															num6 -= 2;
															goto IL_18ff_2;
															IL_06d4_2:
															if (15 >= b)
															{
																goto IL_06e2_2;
															}
															goto IL_0dba_2;
															IL_06e2_2:
															if (15 > b)
															{
																goto IL_06f0_2;
															}
															goto IL_0c58_2;
															IL_06f0_2:
															if (12 < b)
															{
																goto IL_06fe_2;
															}
															goto IL_0b0b_2;
															IL_06fe_2:
															if (13 >= b)
															{
																goto IL_0af8_2;
															}
															goto IL_0c37_2;
															IL_0af8_2:
															if (13 > b)
															{
																break;
															}
															goto IL_0f6d_2;
															IL_0f6d_2:
															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
															goto IL_0f8b_2;
															IL_0f8b_2:
															ptr2 += 8;
															goto IL_0f99_2;
															IL_0f99_2:
															num6--;
															goto IL_18ff_2;
															IL_0c37_2:
															if (14 < b)
															{
																break;
															}
															goto IL_0c45_2;
															IL_0c45_2:
															if (14 > b)
															{
																break;
															}
															goto IL_102c_2;
															IL_102c_2:
															array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_1055_2;
															IL_1055_2:
															array2[num6 - 1] = 5;
															goto IL_18ff_2;
															IL_0b0b_2:
															if (12 > b)
															{
																goto IL_0b19_2;
															}
															goto IL_0c75_2;
															IL_0b19_2:
															if (11 < b)
															{
																break;
															}
															goto IL_0b27_2;
															IL_0b27_2:
															if (11 > b)
															{
																break;
															}
															goto IL_18ff_2;
															IL_0c75_2:
															array8 = array3;
															num9 = num6;
															if (array == null)
															{
																goto IL_0c84_2;
															}
															goto IL_0c92;
															IL_0c58_2:
															array2[num6] = array2[num6 - 1];
															goto IL_0d4d_2;
															IL_0d4d_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_0d6b_2;
															IL_0d6b_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0d8f_2;
															IL_0d8f_2:
															array3[num6] = array3[num6 - 1];
															goto IL_0da7_2;
															IL_0da7_2:
															num6++;
															goto IL_18ff_2;
															IL_0dba_2:
															if (18 >= b)
															{
																goto IL_0dc8_2;
															}
															goto IL_0ec4_2;
															IL_0dc8_2:
															if (18 > b)
															{
																goto IL_0dd6_2;
															}
															goto IL_0e5c_2;
															IL_0dd6_2:
															if (16 >= b)
															{
																goto IL_0de1_2;
															}
															goto IL_0df4_2;
															IL_0de1_2:
															if (16 > b)
															{
																break;
															}
															goto IL_12ab_2;
															IL_12ab_2:
															array2[num6] = 5;
															goto IL_12b9_2;
															IL_12b9_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_12d1_2;
															IL_12d1_2:
															num6++;
															goto IL_12df_2;
															IL_12df_2:
															ptr2 += 8;
															goto IL_18ff_2;
															IL_0df4_2:
															if (17 < b)
															{
																break;
															}
															goto IL_0e02_2;
															IL_0e02_2:
															if (17 > b)
															{
																break;
															}
															goto IL_0e10_2;
															IL_0e10_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															num = 345;
															goto IL_176a_2;
															IL_176a_2:
															num6 -= 3;
															goto IL_18ff_2;
															IL_0e5c_2:
															array2[num6 - 1] = 5;
															goto IL_0e70_2;
															IL_0e70_2:
															array3[num6 - 1] = ((delegate*<string[], string>)CopyrightsetAsUint[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															goto IL_0ea8_2;
															IL_0ea8_2:
															ptr2 += 8;
															num = 40;
															goto IL_18ff_2;
															IL_0ec4_2:
															if (19 < b)
															{
																goto IL_0ecf_2;
															}
															goto IL_0ef9_2;
															IL_0ecf_2:
															if (20 < b)
															{
																break;
															}
															num = 50;
															goto IL_0ee6_2;
															IL_0c24_2:
															num6--;
															goto IL_18ff_2;
															IL_0ee6_2:
															if (20 > b)
															{
																break;
															}
															goto IL_11a0_2;
															IL_11a0_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_18ff_2;
															IL_0ef9_2:
															if (19 > b)
															{
																break;
															}
															goto IL_0f07_2;
															IL_0f07_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_173b_2;
															IL_173b_2:
															array2[num6] = 1;
															goto IL_1749_2;
															IL_1749_2:
															num6++;
															goto IL_1757_2;
															IL_1757_2:
															ptr2 += 16;
															goto IL_18ff_2;
														}
														break;
														IL_062f_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_18ff_2;
												continue;
												end_IL_063f_2:
												break;
											}
											continue;
											end_IL_064f:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									break;
								}
								goto IL_19db_2;
								IL_19db_2:
								return (Color)array3[num6 - 1];
							}
							break;
						}
						continue;
						end_IL_0d2c:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static void getIsErrorRedirectedReadTimeout()
	{
		Class179.smethod_11();
	}

	private static void PlusDiscretionaryAclDefaulted(Class184 class184_1)
	{
		class184_1.method_1();
	}

	private static GorillaTagger MinorPolicyRights()
	{
		return GorillaTagger.Instance;
	}

	private unsafe static int smethod_8(int int_1)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 36;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetNativeOffsetsetFilter.setPositionPointerPrepareForExecution);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025c:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_023f:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_022f:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (9 > b)
																							{
																								num = 123;
																								while (true)
																								{
																									if (num != 123)
																									{
																										if (num != 1104)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 28:
																											goto IL_021c;
																										case 6:
																										case 73:
																											goto IL_022f;
																										case 8:
																											goto IL_023f;
																										case 107:
																											goto end_IL_023f;
																										case 65:
																											goto IL_025c;
																										case 63:
																											goto end_IL_025c;
																										case 18:
																										case 68:
																											goto end_IL_026c;
																										case 30:
																											goto IL_0287;
																										case 23:
																										case 40:
																											goto IL_0295;
																										case 52:
																											goto IL_02d5;
																										case 64:
																											goto IL_02e9;
																										case 57:
																										case 81:
																											goto IL_02fc;
																										case 55:
																											goto IL_035e;
																										case 85:
																										case 93:
																											goto IL_0371;
																										case 48:
																											goto IL_037f;
																										case 74:
																											goto IL_038a;
																										case 46:
																										case 86:
																											goto IL_0395;
																										case 11:
																											goto IL_03a3;
																										case 19:
																											goto IL_03b3;
																										case 47:
																										case 98:
																											goto IL_03c1;
																										case 95:
																											goto IL_03da;
																										case 89:
																										case 100:
																											goto IL_03ea;
																										case 62:
																										case 102:
																											goto end_IL_0209;
																										case 79:
																											goto IL_042b;
																										case 94:
																											goto IL_0439;
																										case 109:
																											goto IL_044c;
																										case 72:
																											goto IL_045a;
																										case 51:
																										case 111:
																											goto IL_046d;
																										case 43:
																										case 59:
																											goto IL_0478;
																										case 84:
																											goto IL_0486;
																										case 66:
																										case 101:
																											goto IL_0494;
																										case 25:
																											goto IL_04a2;
																										case 5:
																											goto IL_04c5;
																										case 39:
																											goto IL_04cf;
																										case 42:
																											goto IL_04dd;
																										case 56:
																											goto IL_04f0;
																										case 13:
																										case 112:
																											goto IL_0503;
																										case 17:
																										case 29:
																											goto IL_050e;
																										case 27:
																											goto IL_051c;
																										case 82:
																											goto IL_052f;
																										case 45:
																										case 80:
																											goto IL_053d;
																										case 14:
																											goto IL_0559;
																										case 7:
																											goto IL_0564;
																										case 54:
																										case 113:
																											goto IL_0572;
																										case 50:
																											goto IL_05b2;
																										case 92:
																											goto IL_05c6;
																										case 21:
																											goto IL_05d6;
																										case 88:
																											goto IL_05e1;
																										case 1:
																										case 116:
																											goto IL_05ec;
																										case 67:
																											goto IL_060f;
																										case 91:
																											goto IL_061d;
																										case 58:
																											goto IL_062b;
																										case 9:
																										case 15:
																										case 20:
																										case 24:
																										case 32:
																										case 34:
																										case 44:
																										case 49:
																										case 53:
																										case 61:
																										case 69:
																										case 70:
																										case 71:
																										case 78:
																										case 87:
																										case 96:
																										case 103:
																										case 104:
																										case 106:
																										case 108:
																										case 114:
																											goto end_IL_024c;
																										case 0:
																										case 16:
																										case 22:
																										case 26:
																										case 31:
																										case 33:
																										case 37:
																										case 38:
																										case 41:
																										case 60:
																										case 76:
																										case 90:
																										case 99:
																										case 105:
																											goto end_IL_027c;
																										case 35:
																											goto end_IL_064e;
																										case 36:
																											goto end_IL_0661;
																										case 115:
																											goto end_IL_066b;
																										case 77:
																											goto end_IL_0676;
																										case 12:
																										case 75:
																											goto end_IL_0694;
																										case 97:
																											goto end_IL_06a4;
																										case 4:
																										case 110:
																											goto end_IL_06b4;
																										case 2:
																											goto end_IL_06c4;
																										case 3:
																											goto end_IL_06d4;
																										case 10:
																										case 83:
																											goto IL_06ef;
																										}
																										continue;
																									}
																									goto IL_0559;
																									IL_061d:
																									num5++;
																									goto IL_062b;
																									IL_062b:
																									ptr2 += 8;
																									goto end_IL_027c;
																									IL_0559:
																									if (7 >= b)
																									{
																										goto IL_0564;
																									}
																									goto IL_05d6;
																									IL_0564:
																									if (7 > b)
																									{
																										goto end_IL_024c;
																									}
																									goto IL_0572;
																									IL_0572:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05b2;
																									IL_05b2:
																									array[num5 - 2] = 0;
																									goto IL_05c6;
																									IL_05c6:
																									num5--;
																									goto end_IL_027c;
																									IL_05d6:
																									if (8 < b)
																									{
																										goto end_IL_024c;
																									}
																									goto IL_05e1;
																									IL_05e1:
																									if (8 > b)
																									{
																										goto end_IL_024c;
																									}
																									goto IL_05ec;
																									IL_05ec:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_060f;
																									IL_060f:
																									array[num5] = 0;
																									goto IL_061d;
																									continue;
																									end_IL_0209:
																									break;
																								}
																								break;
																							}
																							goto IL_02fc;
																							IL_02fc:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_035e;
																							IL_035e:
																							num5 -= 2;
																							goto end_IL_027c;
																						}
																						break;
																					}
																					goto IL_0503;
																					IL_053d:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_027c;
																					IL_0503:
																					if (10 < b)
																					{
																						goto IL_050e;
																					}
																					goto IL_052f;
																					IL_050e:
																					if (11 < b)
																					{
																						goto end_IL_024c;
																					}
																					goto IL_051c;
																					IL_051c:
																					if (11 <= b)
																					{
																					}
																					goto end_IL_024c;
																					IL_052f:
																					if (10 > b)
																					{
																						goto end_IL_024c;
																					}
																					goto IL_053d;
																				}
																				goto IL_0402;
																			}
																			goto IL_0287;
																			IL_04f0:
																			if (4 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto end_IL_027c;
																			IL_0287:
																			if (6 <= b)
																			{
																				goto IL_0295;
																			}
																			goto IL_0371;
																			IL_0295:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_02d5;
																			IL_02d5:
																			array[num5 - 2] = 0;
																			goto IL_02e9;
																			IL_02e9:
																			num5--;
																			goto end_IL_027c;
																			IL_0371:
																			if (3 >= b)
																			{
																				goto IL_037f;
																			}
																			goto IL_046d;
																			IL_037f:
																			if (3 > b)
																			{
																				goto IL_038a;
																			}
																			goto IL_03ea;
																			IL_038a:
																			if (1 < b)
																			{
																				goto IL_0395;
																			}
																			goto IL_03b3;
																			IL_0395:
																			if (2 < b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_03a3;
																			IL_03a3:
																			if (2 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_0402;
																			IL_0402:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_042b;
																			IL_042b:
																			ptr2 += 8;
																			goto IL_0439;
																			IL_0439:
																			num5--;
																			goto end_IL_027c;
																			IL_03b3:
																			if (1 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_03c1;
																			IL_03c1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_03da;
																			IL_03da:
																			array[num5] = 0;
																			goto IL_044c;
																			IL_044c:
																			num5++;
																			goto IL_045a;
																			IL_045a:
																			ptr2 += 8;
																			goto end_IL_027c;
																			IL_03ea:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_027c;
																			IL_046d:
																			if (4 < b)
																			{
																				goto IL_0478;
																			}
																			goto IL_04f0;
																			IL_0478:
																			if (5 < b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_0486;
																			IL_0486:
																			if (5 > b)
																			{
																				goto end_IL_024c;
																			}
																			goto IL_0494;
																			IL_0494:
																			array[num5] = 0;
																			goto IL_04a2;
																			IL_04a2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04c5;
																			IL_04c5:
																			array2[num5] = null;
																			goto IL_04cf;
																			IL_04cf:
																			num5++;
																			goto IL_04dd;
																			IL_04dd:
																			ptr2 += 8;
																			goto end_IL_027c;
																			continue;
																			end_IL_023f:
																			break;
																		}
																		continue;
																		end_IL_024c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_027c;
																continue;
																end_IL_025c:
																break;
															}
															continue;
															end_IL_026c:
															break;
														}
														continue;
														end_IL_027c:
														break;
													}
													continue;
												}
												goto IL_06ef;
												IL_06ef:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_064e:
												break;
											}
											continue;
											end_IL_0661:
											break;
										}
										continue;
										end_IL_066b:
										break;
									}
									continue;
									end_IL_0676:
									break;
								}
								continue;
								end_IL_0694:
								break;
							}
							continue;
							end_IL_06a4:
							break;
						}
						continue;
						end_IL_06b4:
						break;
					}
					continue;
					end_IL_06c4:
					break;
				}
				continue;
				end_IL_06d4:
				break;
			}
		}
	}

	public Class184()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static Transform getAppDomainInitializerArgumentsIMPLTYPEFLAGFDEFAULTVTABLE(Component component_0)
	{
		return component_0.transform;
	}

	private unsafe static int smethod_9(int int_1)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 44;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSSECTIONIDPERMISSIONSETSECTIONWaitingToRun.GCCMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTION);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f5:
														byte b = *ptr2;
														while (true)
														{
															IL_02e5:
															ptr2++;
															while (true)
															{
																IL_02d5:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02b8:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02a8:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0298:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0288:
																									if (4 < b)
																									{
																										while (true)
																										{
																											IL_0278:
																											if (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0258:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_0233:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_0227:
																																array2[num5] = null;
																																while (true)
																																{
																																	IL_0217:
																																	num5++;
																																	while (true)
																																	{
																																		IL_01fe:
																																		ptr2 += 8;
																																		num = 119;
																																		while (num != 119)
																																		{
																																			if (num != 1100)
																																			{
																																				goto IL_061b;
																																			}
																																			switch (num)
																																			{
																																			case 53:
																																				goto IL_01fe;
																																			case 66:
																																				goto IL_0217;
																																			case 100:
																																				goto IL_0227;
																																			case 15:
																																				goto IL_0233;
																																			case 5:
																																			case 47:
																																				goto IL_0258;
																																			case 16:
																																				goto IL_0268;
																																			case 31:
																																			case 60:
																																				goto IL_0278;
																																			case 11:
																																			case 28:
																																				goto IL_0288;
																																			case 41:
																																				goto IL_0298;
																																			case 70:
																																				goto IL_02a8;
																																			case 54:
																																				goto IL_02b8;
																																			case 42:
																																				goto IL_02c5;
																																			case 27:
																																				goto IL_02d5;
																																			case 112:
																																				goto IL_02e5;
																																			case 45:
																																			case 93:
																																				goto IL_02f5;
																																			case 19:
																																			case 25:
																																				goto IL_0300;
																																			case 14:
																																				goto IL_030b;
																																			case 12:
																																				goto IL_031e;
																																			case 51:
																																				goto IL_0329;
																																			case 6:
																																				goto IL_0337;
																																			case 72:
																																				goto IL_034a;
																																			case 43:
																																			case 73:
																																				goto IL_035a;
																																			case 59:
																																				goto IL_039a;
																																			case 75:
																																			case 76:
																																				goto IL_03b3;
																																			case 78:
																																				goto IL_03cf;
																																			case 7:
																																				goto IL_03da;
																																			case 22:
																																			case 56:
																																				goto IL_03e8;
																																			case 2:
																																				goto IL_0436;
																																			case 74:
																																				goto IL_0444;
																																			case 48:
																																			case 84:
																																				goto IL_0452;
																																			case 46:
																																				goto IL_0475;
																																			case 0:
																																				goto IL_0483;
																																			case 9:
																																				goto IL_0491;
																																			case 8:
																																			case 88:
																																				goto IL_04a4;
																																			case 103:
																																				goto IL_0508;
																																			case 106:
																																				goto IL_051b;
																																			case 111:
																																				goto IL_052e;
																																			case 52:
																																				goto IL_0542;
																																			case 80:
																																				goto IL_0563;
																																			case 38:
																																				goto IL_0576;
																																			case 99:
																																			case 102:
																																				goto IL_0581;
																																			case 91:
																																				goto IL_0599;
																																			case 30:
																																			case 40:
																																				goto IL_05a4;
																																			case 105:
																																				goto IL_05b2;
																																			case 81:
																																			case 101:
																																				goto IL_05c0;
																																			case 77:
																																				goto IL_05f2;
																																			case 97:
																																				goto IL_0600;
																																			case 83:
																																				goto IL_0610;
																																			case 57:
																																			case 86:
																																				goto IL_061b;
																																			case 89:
																																				goto IL_063d;
																																			case 13:
																																				goto IL_064b;
																																			case 49:
																																				goto IL_0659;
																																			case 4:
																																			case 10:
																																			case 17:
																																			case 18:
																																			case 24:
																																			case 39:
																																			case 50:
																																			case 55:
																																			case 58:
																																			case 61:
																																			case 63:
																																			case 64:
																																			case 65:
																																			case 67:
																																			case 71:
																																			case 79:
																																			case 82:
																																			case 85:
																																			case 87:
																																			case 92:
																																			case 108:
																																				goto end_IL_0268;
																																			case 1:
																																			case 3:
																																			case 29:
																																			case 32:
																																			case 34:
																																			case 35:
																																			case 62:
																																			case 69:
																																			case 90:
																																			case 95:
																																			case 98:
																																			case 109:
																																			case 110:
																																				goto end_IL_01eb;
																																			case 26:
																																				goto end_IL_067c;
																																			case 23:
																																				goto end_IL_068f;
																																			case 44:
																																				goto end_IL_0699;
																																			case 68:
																																				goto end_IL_06a4;
																																			case 33:
																																			case 94:
																																				goto end_IL_06b9;
																																			case 37:
																																				goto end_IL_06d2;
																																			case 96:
																																			case 104:
																																				goto end_IL_06e2;
																																			case 20:
																																				goto end_IL_06f2;
																																			case 21:
																																				goto end_IL_0702;
																																			case 36:
																																			case 107:
																																				goto IL_071d;
																																			}
																																			continue;
																																			end_IL_01eb:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02d5;
																													continue;
																													end_IL_0268:
																													break;
																													IL_0268:;
																												}
																											}
																											else
																											{
																												num = 79;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0563;
																									IL_0563:
																									if (4 <= b)
																									{
																										goto end_IL_02d5;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0576;
																							IL_0659:
																							ptr2 += 8;
																							goto end_IL_02d5;
																							IL_0576:
																							if (3 <= b)
																							{
																								goto IL_0581;
																							}
																							goto IL_0599;
																							IL_0581:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02d5;
																							IL_0599:
																							if (1 < b)
																							{
																								goto IL_05a4;
																							}
																							goto IL_0610;
																							IL_05a4:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_05b2;
																							IL_05b2:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_05c0;
																							IL_05c0:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 77;
																							goto IL_05f2;
																							IL_05f2:
																							ptr2 += 8;
																							goto IL_0600;
																							IL_0600:
																							num5--;
																							goto end_IL_02d5;
																							IL_0610:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_061b;
																							IL_061b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 89;
																							goto IL_063d;
																							IL_063d:
																							array[num5] = 0;
																							goto IL_064b;
																							IL_064b:
																							num5++;
																							goto IL_0659;
																						}
																						break;
																					}
																					goto IL_035a;
																					IL_0508:
																					num5--;
																					goto end_IL_02d5;
																					IL_035a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_039a;
																					IL_039a:
																					array[num5 - 2] = 0;
																					goto IL_0508;
																				}
																				break;
																			}
																			goto IL_0300;
																			IL_03b3:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d5;
																			IL_0300:
																			if (9 >= b)
																			{
																				goto IL_030b;
																			}
																			goto IL_031e;
																			IL_030b:
																			if (9 > b)
																			{
																				goto IL_03cf;
																			}
																			goto IL_04a4;
																			IL_04a4:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_051b;
																			IL_051b:
																			num5 -= 2;
																			goto end_IL_02d5;
																			IL_03cf:
																			if (7 >= b)
																			{
																				goto IL_03da;
																			}
																			goto IL_0436;
																			IL_03da:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_03e8;
																			IL_03e8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 111;
																			goto IL_052e;
																			IL_052e:
																			array[num5 - 2] = 0;
																			goto IL_0542;
																			IL_0542:
																			num5--;
																			goto end_IL_02d5;
																			IL_0436:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0444;
																			IL_0444:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0452;
																			IL_0452:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0475;
																			IL_0475:
																			array[num5] = 0;
																			goto IL_0483;
																			IL_0483:
																			num5++;
																			goto IL_0491;
																			IL_0491:
																			ptr2 += 8;
																			goto end_IL_02d5;
																			IL_031e:
																			if (10 < b)
																			{
																				goto IL_0329;
																			}
																			goto IL_034a;
																			IL_0329:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0337;
																			IL_0337:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_034a:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_03b3;
																		}
																		break;
																		IL_02c5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d5:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_071d;
												IL_071d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067c:
												break;
											}
											continue;
											end_IL_068f:
											break;
										}
										continue;
										end_IL_0699:
										break;
									}
									continue;
									end_IL_06a4:
									break;
								}
								continue;
								end_IL_06b9:
								break;
							}
							continue;
							end_IL_06d2:
							break;
						}
						continue;
						end_IL_06e2:
						break;
					}
					continue;
					end_IL_06f2:
					break;
				}
				continue;
				end_IL_0702:
				break;
			}
		}
	}

	private static void DelayLoadClientChannelEntryBinaryLength(bool bool_7)
	{
		InvisActive = bool_7;
	}

	private static int CreateWrapperOfTypeLockRecursionException(int int_1)
	{
		return smethod_9(int_1);
	}

	private static bool IComparerAny(Class184 class184_1)
	{
		return class184_1.bool_1;
	}

	private void OnEnable()
	{
		int num = 92;
		int num2 = 4;
		num = 23;
		num = 121;
		num2 = 11;
		num = 11;
		num = 23;
		num2 = 11;
		num = 28;
		num2 = 23;
		num2 = 3;
		num = 31;
		num = 31;
		num = 196;
		num2 = 4;
		num = 49;
		num = 165;
		num2 = 5;
		num = 33;
		num = 49;
		num2 = 33;
		num = 82;
		num2 = 49;
		num2 = 1617;
		num = 1539;
		num = 1539;
		num2 = 31;
		num = 1570;
		num = 561;
		num2 = 3;
		num = 187;
		num2 = 4147;
		num2 = 319;
		object obj = this;
		num2 = (XRSettings.isDeviceActive ? 1 : 0);
		num2 = ((num2 == 0) ? 1 : 0);
		((Class184)obj).bool_3 = (byte)num2 != 0;
		obj = this;
		if (((Class184)obj).bool_3)
		{
			obj = this;
			num2 = 1;
			((Class184)obj).bool_1 = true;
			obj = this;
			GorillaTagger instance = GorillaTagger.Instance;
			object obj2 = instance;
			obj2 = ((GorillaTagger)obj2).offlineVRRig;
			Transform transform = ((VRRig)obj2).transform;
			obj2 = transform;
			Vector3 position = ((Transform)obj2).position;
			obj2 = position;
			((Class184)obj).vector3_0 = (Vector3)obj2;
			obj = this;
			float time = Time.time;
			double num3 = time;
			((Class184)obj).float_0 = (float)num3;
		}
	}

	static Class184()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 9;
					while (true)
					{
						num = 22;
						while (true)
						{
							if (num != 22)
							{
								if (num != 1003)
								{
									return;
								}
								switch (num)
								{
								case 9:
									goto end_IL_0067;
								case 3:
								case 7:
								case 8:
								case 11:
								case 12:
								case 13:
									goto end_IL_0074;
								case 1:
									goto end_IL_0080;
								case 2:
									goto end_IL_009b;
								case 10:
								case 14:
								case 15:
									goto IL_00ac;
								case 0:
									return;
								case 4:
									return;
								case 5:
									return;
								case 6:
									return;
								}
								continue;
							}
							goto IL_00ac;
							IL_00ac:
							num = 6;
							return;
							continue;
							end_IL_0067:
							break;
						}
						continue;
						end_IL_0074:
						break;
					}
					continue;
					end_IL_0080:
					break;
				}
				continue;
				end_IL_009b:
				break;
			}
		}
	}

	private static bool EnsureSufficientExecutionStackFormatSerialization(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerSecondaryButton;
	}

	private static void JulianCenturiessetPermissionType(Behaviour behaviour_0, bool bool_7)
	{
		behaviour_0.enabled = bool_7;
	}

	private static double InternalCodePageDataItemIChannel(double double_0)
	{
		return Math.Sin(double_0);
	}

	private static double AceEnumeratorBinaryArray(double double_0)
	{
		return Math.Cos(double_0);
	}
}
