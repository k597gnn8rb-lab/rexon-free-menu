using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti RPC Ban", "Safety", "Prevents disconnects from using too many mods.", false, 15, ModType.const_0, false)]
internal class Class151 : MonoBehaviour
{
	private float float_0;

	private static bool bool_0;

	private static bool bool_1;

	private static float float_1;

	private static int int_0;

	private static float float_2;

	private static int int_1;

	private static float float_3;

	private static IntPtr[] AutoLayoutGetTypeInfoOfGuid;

	private static IntPtr[] GetRuntimeMethodssetRefusedSet;

	private void Update()
	{
		int num = 392;
		int num2 = 7;
		num = 56;
		num = 253;
		num2 = 11;
		num = 23;
		num = 56;
		num2 = 23;
		num = 47;
		num2 = 56;
		int num3 = 23;
		num2 = 16;
		num = 63;
		num = 63;
		num = 160;
		num2 = 4;
		num = 40;
		num = 252;
		num2 = 7;
		num = 36;
		num = 40;
		num2 = 36;
		num = 76;
		num2 = 40;
		num3 = 36;
		num2 = 1440;
		num = 1516;
		num = 1516;
		num2 = 63;
		num = 1579;
		num = 540;
		num2 = 5;
		num = 108;
		num2 = 876;
		num3 = 4;
		num2 = 219;
		if (!PhotonNetwork.InRoom)
		{
			return;
		}
		float time = Time.time;
		double num4 = time;
		object obj = this;
		double num5 = ((Class151)obj).float_0;
		double num6 = 0.699999988079071;
		num5 += num6;
		if (!(num4 >= num5))
		{
			return;
		}
		object obj2 = this;
		float time2 = Time.time;
		num5 = time2;
		((Class151)obj2).float_0 = (float)num5;
		try
		{
			MonkeAgent[] array = UnityEngine.Object.FindObjectsOfType<MonkeAgent>();
			obj2 = array;
			global::_003CModule_003E.monkeAgent_0 = (MonkeAgent[])obj2;
			num = 0;
			global::_003CModule_003E.nogAwTbakx = 0;
			while (true)
			{
				num = global::_003CModule_003E.nogAwTbakx;
				obj = global::_003CModule_003E.monkeAgent_0;
				IntPtr intPtr = (nint)((MonkeAgent[])obj).LongLength;
				num2 = (int)(nint)intPtr;
				if (num < num2)
				{
					obj2 = global::_003CModule_003E.monkeAgent_0;
					num2 = global::_003CModule_003E.nogAwTbakx;
					obj2 = ((MonkeAgent[])obj2)[num2];
					obj = obj2;
					num3 = int.MaxValue;
					((MonkeAgent)obj).rpcErrorMax = int.MaxValue;
					obj = obj2;
					num6 = 3221225470.0;
					double d = 1073741823.5;
					double num7 = Math.Floor(d);
					d = num7;
					num6 -= d;
					int num8 = Convert.ToInt32(num6);
					num3 = num8;
					((MonkeAgent)obj).logErrorMax = num3;
					num5 = 0.0;
					((MonkeAgent)obj2).lastCheck = (float)num5;
					num = global::_003CModule_003E.nogAwTbakx;
					num2 = 1;
					num++;
					global::_003CModule_003E.nogAwTbakx = num;
					continue;
				}
				break;
			}
		}
		catch
		{
		}
		Class9.smethod_82();
	}

	public Class151()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 90;
		int[] array3 = default(int[]);
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		long[] array4 = default(long[]);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 121;
							while (true)
							{
								if (num != 121)
								{
									if (num != 1102)
									{
										goto IL_0462;
									}
									switch (num)
									{
									case 94:
										goto end_IL_01f3;
									case 54:
										goto end_IL_0203;
									case 24:
									case 102:
										goto end_IL_020e;
									case 89:
										goto end_IL_021e;
									case 90:
										goto end_IL_022e;
									case 64:
										goto IL_0257;
									case 112:
										goto IL_0265;
									case 50:
										goto IL_0278;
									case 58:
										goto IL_0281;
									case 18:
									case 31:
									case 36:
									case 43:
									case 47:
									case 63:
									case 65:
									case 70:
									case 76:
									case 96:
									case 99:
									case 106:
									case 107:
									case 114:
										goto IL_0289;
									case 85:
										goto IL_0299;
									case 46:
										goto IL_02a2;
									case 26:
										goto IL_02ab;
									case 37:
										goto IL_02b9;
									case 25:
										goto IL_02c7;
									case 30:
										goto IL_02d5;
									case 19:
									case 68:
										goto IL_02e3;
									case 22:
										goto IL_02f1;
									case 28:
									case 101:
										goto IL_02ff;
									case 10:
										goto IL_030a;
									case 38:
									case 51:
										goto IL_0318;
									case 80:
										goto IL_0358;
									case 109:
										goto IL_036c;
									case 8:
										goto IL_037f;
									case 5:
										goto IL_038d;
									case 61:
									case 98:
										goto IL_039b;
									case 69:
										goto IL_03be;
									case 110:
										goto IL_03cc;
									case 93:
										goto IL_03da;
									case 11:
									case 84:
										goto IL_03ed;
									case 20:
										goto IL_044f;
									case 95:
										goto IL_0462;
									case 55:
										goto IL_046d;
									case 9:
									case 29:
										goto IL_047b;
									case 86:
										goto IL_0497;
									case 113:
										goto IL_04a5;
									case 41:
										goto IL_04b8;
									case 71:
									case 97:
										goto IL_04c3;
									case 49:
										goto IL_0503;
									case 53:
										goto IL_0517;
									case 3:
										goto IL_052a;
									case 39:
										goto IL_0538;
									case 4:
									case 14:
										goto IL_0543;
									case 73:
										goto IL_055b;
									case 74:
									case 78:
										goto IL_0566;
									case 72:
										goto IL_0574;
									case 75:
									case 105:
										goto IL_0582;
									case 100:
										goto IL_05ab;
									case 1:
										goto IL_05b9;
									case 60:
										goto IL_05cc;
									case 13:
									case 45:
										goto IL_05da;
									case 104:
										goto IL_05f3;
									case 91:
										goto IL_0601;
									case 21:
										goto IL_060f;
									case 40:
										goto IL_0622;
									case 32:
										goto IL_062d;
									case 59:
										goto IL_063d;
									case 16:
										goto IL_0648;
									case 17:
									case 77:
										goto IL_0653;
									case 56:
										goto IL_0661;
									case 42:
										goto IL_0684;
									case 12:
										goto IL_068e;
									case 27:
										goto IL_069c;
									case 0:
									case 2:
									case 7:
									case 15:
									case 23:
									case 33:
									case 34:
									case 35:
									case 44:
									case 48:
									case 52:
									case 57:
									case 62:
									case 66:
									case 67:
									case 79:
									case 81:
									case 82:
									case 83:
									case 87:
									case 88:
									case 92:
									case 103:
									case 108:
										goto IL_06af;
									case 6:
									case 111:
										goto IL_06c7;
									}
									continue;
								}
								array3 = new int[4];
								goto IL_0257;
								IL_068e:
								num4++;
								goto IL_069c;
								IL_06af:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_0289;
								IL_069c:
								ptr += 8;
								goto IL_0289;
								IL_0257:
								array4 = new long[3];
								goto IL_0265;
								IL_0265:
								array3[0] = int_2;
								goto IL_0278;
								IL_0278:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DependentOSMetadataEntryFieldIdElement.UserNameSizeArray);
								goto IL_0281;
								IL_0281:
								ptr = ptr2;
								goto IL_0289;
								IL_0289:
								if (num5 != 1)
								{
									goto IL_0299;
								}
								goto IL_06c7;
								IL_06c7:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								IL_0299:
								num = 46;
								goto IL_02a2;
								IL_02a2:
								b = *ptr;
								goto IL_02ab;
								IL_02ab:
								ptr++;
								goto IL_02b9;
								IL_02b9:
								if (b >= 1)
								{
									goto IL_02c7;
								}
								goto IL_06af;
								IL_02c7:
								if (b <= 11)
								{
									goto IL_02d5;
								}
								goto IL_06af;
								IL_02d5:
								if (6 < b)
								{
									goto IL_02e3;
								}
								goto IL_04b8;
								IL_02e3:
								if (9 >= b)
								{
									goto IL_02f1;
								}
								goto IL_0462;
								IL_02f1:
								if (9 > b)
								{
									goto IL_02ff;
								}
								goto IL_03ed;
								IL_02ff:
								if (7 >= b)
								{
									goto IL_030a;
								}
								goto IL_037f;
								IL_030a:
								if (7 <= b)
								{
									goto IL_0318;
								}
								goto IL_06af;
								IL_0318:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0358;
								IL_0358:
								array[num4 - 2] = 0;
								goto IL_036c;
								IL_036c:
								num4--;
								goto IL_0289;
								IL_037f:
								if (8 >= b)
								{
									goto IL_038d;
								}
								goto IL_06af;
								IL_038d:
								if (8 <= b)
								{
									goto IL_039b;
								}
								goto IL_06af;
								IL_039b:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_03be;
								IL_03be:
								array[num4] = 0;
								goto IL_03cc;
								IL_03cc:
								num4++;
								goto IL_03da;
								IL_03da:
								ptr += 8;
								goto IL_0289;
								IL_03ed:
								ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_044f;
								IL_044f:
								num4 -= 2;
								goto IL_0289;
								IL_0462:
								if (10 >= b)
								{
									goto IL_046d;
								}
								goto IL_0497;
								IL_046d:
								if (10 <= b)
								{
									goto IL_047b;
								}
								goto IL_06af;
								IL_047b:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0289;
								IL_0497:
								if (11 >= b)
								{
									goto IL_04a5;
								}
								goto IL_06af;
								IL_04a5:
								if (11 <= b)
								{
								}
								goto IL_06af;
								IL_04b8:
								if (6 <= b)
								{
									goto IL_04c3;
								}
								goto IL_052a;
								IL_04c3:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0503;
								IL_0503:
								array[num4 - 2] = 0;
								goto IL_0517;
								IL_0517:
								num4--;
								goto IL_0289;
								IL_052a:
								if (3 >= b)
								{
									goto IL_0538;
								}
								goto IL_0622;
								IL_0538:
								if (3 <= b)
								{
									goto IL_0543;
								}
								goto IL_055b;
								IL_0543:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_0289;
								IL_055b:
								if (1 < b)
								{
									goto IL_0566;
								}
								goto IL_05cc;
								IL_0566:
								if (2 >= b)
								{
									goto IL_0574;
								}
								goto IL_06af;
								IL_0574:
								if (2 <= b)
								{
									goto IL_0582;
								}
								goto IL_06af;
								IL_0582:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_05ab;
								IL_05ab:
								ptr += 8;
								goto IL_05b9;
								IL_05b9:
								num4--;
								goto IL_0289;
								IL_05cc:
								if (1 <= b)
								{
									goto IL_05da;
								}
								goto IL_06af;
								IL_05da:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
								goto IL_05f3;
								IL_05f3:
								array[num4] = 0;
								goto IL_0601;
								IL_0601:
								num4++;
								goto IL_060f;
								IL_060f:
								ptr += 8;
								goto IL_0289;
								IL_0622:
								if (4 >= b)
								{
									goto IL_062d;
								}
								goto IL_063d;
								IL_062d:
								if (4 <= b)
								{
									goto IL_0289;
								}
								goto IL_06af;
								IL_063d:
								if (5 >= b)
								{
									goto IL_0648;
								}
								goto IL_06af;
								IL_0648:
								if (5 <= b)
								{
									goto IL_0653;
								}
								goto IL_06af;
								IL_0653:
								array[num4] = 0;
								goto IL_0661;
								IL_0661:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_0684;
								IL_0684:
								array2[num4] = null;
								goto IL_068e;
								continue;
								end_IL_01f3:
								break;
							}
							continue;
							end_IL_0203:
							break;
						}
						continue;
						end_IL_020e:
						break;
					}
					continue;
					end_IL_021e:
					break;
				}
				continue;
				end_IL_022e:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NlsVersionInfoExMuiResourceIdLookupMapCount.nlsVersionInfoExMuiResourceIdLookupMapCount_0);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a0:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0280:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0273:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0263:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0253:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												num = 132;
																												while (true)
																												{
																													if (num != 132)
																													{
																														if (num != 1113)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 64:
																															goto IL_0240;
																														case 13:
																															goto IL_0253;
																														case 6:
																															goto IL_0263;
																														case 16:
																														case 104:
																															goto IL_0273;
																														case 84:
																															goto IL_0280;
																														case 48:
																															goto IL_0290;
																														case 119:
																															goto IL_02a0;
																														case 44:
																															goto end_IL_02a0;
																														case 7:
																														case 29:
																															goto end_IL_02b0;
																														case 15:
																														case 70:
																															goto IL_02cb;
																														case 26:
																															goto IL_02d6;
																														case 4:
																														case 42:
																															goto IL_02e1;
																														case 72:
																															goto IL_0302;
																														case 35:
																															goto IL_030d;
																														case 90:
																														case 100:
																															goto IL_032b;
																														case 93:
																														case 102:
																															goto IL_033b;
																														case 112:
																															goto IL_0357;
																														case 81:
																														case 115:
																															goto IL_0365;
																														case 8:
																															goto IL_03a5;
																														case 122:
																															goto IL_03b9;
																														case 41:
																															goto IL_03cc;
																														case 46:
																															goto IL_03e5;
																														case 31:
																															goto IL_03fc;
																														case 113:
																															goto IL_040a;
																														case 97:
																														case 99:
																															goto IL_041d;
																														case 63:
																															goto IL_0431;
																														case 83:
																															goto IL_0485;
																														case 118:
																															goto IL_0493;
																														case 10:
																															goto IL_04af;
																														case 36:
																														case 111:
																															goto IL_04ba;
																														case 50:
																															goto IL_04fa;
																														case 18:
																															goto IL_050e;
																														case 101:
																															goto IL_0521;
																														case 3:
																														case 75:
																															goto IL_052f;
																														case 68:
																														case 71:
																															goto IL_053a;
																														case 38:
																															goto IL_0548;
																														case 17:
																														case 114:
																															goto IL_0556;
																														case 11:
																															goto IL_0564;
																														case 94:
																															goto IL_0587;
																														case 105:
																															goto IL_0591;
																														case 78:
																															goto IL_059f;
																														case 62:
																															goto IL_05b2;
																														case 57:
																														case 125:
																															goto IL_05c0;
																														case 110:
																															goto IL_0600;
																														case 86:
																															goto IL_0614;
																														case 32:
																															goto IL_0627;
																														case 88:
																														case 91:
																															goto IL_0635;
																														case 34:
																														case 85:
																															goto IL_0643;
																														case 9:
																															goto IL_0651;
																														case 53:
																														case 79:
																															goto IL_065f;
																														case 76:
																															goto IL_069f;
																														case 5:
																															goto IL_06bc;
																														case 124:
																															goto IL_06cf;
																														case 14:
																														case 87:
																															goto IL_06dc;
																														case 56:
																															goto IL_0705;
																														case 37:
																															goto IL_0713;
																														case 0:
																														case 2:
																														case 19:
																														case 20:
																														case 25:
																														case 33:
																														case 40:
																														case 51:
																														case 55:
																														case 58:
																														case 59:
																														case 61:
																														case 66:
																														case 74:
																														case 80:
																														case 82:
																														case 89:
																														case 92:
																														case 98:
																														case 103:
																														case 106:
																														case 116:
																														case 117:
																															goto end_IL_022d;
																														case 45:
																															goto IL_074f;
																														case 52:
																															goto IL_075d;
																														case 96:
																															goto IL_076b;
																														case 12:
																														case 21:
																														case 22:
																														case 24:
																														case 30:
																														case 49:
																														case 54:
																														case 60:
																														case 73:
																														case 77:
																														case 95:
																														case 107:
																														case 120:
																															goto end_IL_02c0;
																														case 67:
																															goto end_IL_0779;
																														case 121:
																															goto end_IL_078c;
																														case 109:
																															goto end_IL_0796;
																														case 65:
																															goto end_IL_07a1;
																														case 123:
																															goto end_IL_07b6;
																														case 1:
																														case 23:
																															goto end_IL_07cb;
																														case 108:
																															goto end_IL_07db;
																														case 39:
																														case 69:
																															goto end_IL_07eb;
																														case 27:
																															goto end_IL_07fb;
																														case 28:
																															goto end_IL_080b;
																														case 43:
																														case 47:
																															goto IL_0826;
																														}
																														continue;
																													}
																													goto IL_03cc;
																													IL_03fc:
																													num5++;
																													goto IL_040a;
																													IL_040a:
																													ptr2 += 8;
																													goto end_IL_02c0;
																													IL_03cc:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_03e5;
																													IL_03e5:
																													array[num5] = 0;
																													num = 31;
																													goto IL_03fc;
																													continue;
																													end_IL_022d:
																													break;
																												}
																												break;
																												IL_0240:;
																											}
																											break;
																										}
																										goto IL_032b;
																										IL_03b9:
																										num5--;
																										goto end_IL_02c0;
																										IL_032b:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0357;
																										IL_0357:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_0365;
																										IL_0365:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03a5;
																										IL_03a5:
																										array[num5 - 2] = 0;
																										goto IL_03b9;
																									}
																									break;
																								}
																								goto IL_041d;
																								IL_0493:
																								ptr2 += 8;
																								num = 21;
																								goto end_IL_02c0;
																								IL_041d:
																								array[num5 - 2] = 0;
																								goto IL_0431;
																								IL_0431:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AutoLayoutGetTypeInfoOfGuid[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_0485;
																								IL_0485:
																								num5--;
																								goto IL_0493;
																							}
																							break;
																						}
																						goto IL_02cb;
																						IL_030d:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_033b;
																						IL_02cb:
																						if (10 >= b)
																						{
																							goto IL_02d6;
																						}
																						goto IL_0302;
																						IL_02d6:
																						if (10 > b)
																						{
																							num = 92;
																							break;
																						}
																						goto IL_02e1;
																						IL_02e1:
																						num5--;
																						goto end_IL_02c0;
																						IL_033b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02c0;
																						IL_0302:
																						if (11 < b)
																						{
																							num = 40;
																							break;
																						}
																						goto IL_030d;
																					}
																					break;
																				}
																				goto IL_04af;
																				IL_0713:
																				num5--;
																				num = 95;
																				goto end_IL_02c0;
																				IL_04af:
																				if (6 <= b)
																				{
																					goto IL_04ba;
																				}
																				goto IL_0521;
																				IL_04ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04fa;
																				IL_04fa:
																				array[num5 - 2] = 0;
																				goto IL_050e;
																				IL_050e:
																				num5--;
																				goto end_IL_02c0;
																				IL_0521:
																				if (3 < b)
																				{
																					goto IL_052f;
																				}
																				goto IL_0627;
																				IL_052f:
																				if (4 < b)
																				{
																					goto IL_053a;
																				}
																				goto IL_05b2;
																				IL_053a:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0548;
																				IL_0548:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0556;
																				IL_0556:
																				array[num5] = 0;
																				goto IL_0564;
																				IL_0564:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0587;
																				IL_0587:
																				array2[num5] = null;
																				goto IL_0591;
																				IL_0591:
																				num5++;
																				goto IL_059f;
																				IL_059f:
																				ptr2 += 8;
																				goto end_IL_02c0;
																				IL_05b2:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05c0;
																				IL_05c0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0600;
																				IL_0600:
																				array[num5 - 2] = 0;
																				goto IL_0614;
																				IL_0614:
																				num5--;
																				goto end_IL_02c0;
																				IL_0627:
																				if (3 > b)
																				{
																					goto IL_0635;
																				}
																				goto IL_06dc;
																				IL_0635:
																				if (1 < b)
																				{
																					goto IL_0643;
																				}
																				goto IL_06cf;
																				IL_0643:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0651;
																				IL_0651:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_065f;
																				IL_065f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_069f;
																				IL_069f:
																				array[num5 - 2] = 0;
																				num = 5;
																				goto IL_06bc;
																				IL_06bc:
																				num5--;
																				goto end_IL_02c0;
																				IL_06cf:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_06dc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0705;
																				IL_0705:
																				ptr2 += 8;
																				goto IL_0713;
																			}
																			break;
																			IL_0290:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_074f;
																	IL_076b:
																	ptr2 += 8;
																	goto end_IL_02c0;
																	IL_075d:
																	num5++;
																	goto IL_076b;
																	IL_074f:
																	array[num5] = 0;
																	goto IL_075d;
																	continue;
																	end_IL_02a0:
																	break;
																}
																continue;
																end_IL_02b0:
																break;
															}
															continue;
															end_IL_02c0:
															break;
														}
														continue;
													}
													goto IL_0826;
													IL_0826:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0779:
													break;
												}
												continue;
												end_IL_078c:
												break;
											}
											continue;
											end_IL_0796:
											break;
										}
										continue;
										end_IL_07a1:
										break;
									}
									continue;
									end_IL_07b6:
									break;
								}
								continue;
								end_IL_07cb:
								break;
							}
							continue;
							end_IL_07db:
							break;
						}
						continue;
						end_IL_07eb:
						break;
					}
					continue;
					end_IL_07fb:
					break;
				}
				continue;
				end_IL_080b:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 74;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeNameFormatFlagsGetNumericValue.CreateSinkSecureStringToCoTaskMemUnicode);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 105;
															while (true)
															{
																if (num != 105)
																{
																	if (num != 1086)
																	{
																		goto IL_0405;
																	}
																	switch (num)
																	{
																	case 17:
																		goto end_IL_01b3;
																	case 6:
																		goto IL_01d7;
																	case 61:
																		goto IL_01ee;
																	case 7:
																		goto IL_01fc;
																	case 34:
																		goto IL_020a;
																	case 45:
																		goto IL_0218;
																	case 4:
																	case 14:
																		goto IL_0223;
																	case 51:
																		goto IL_0231;
																	case 77:
																		goto IL_0254;
																	case 50:
																		goto IL_0267;
																	case 22:
																		goto IL_0275;
																	case 40:
																		goto IL_0288;
																	case 9:
																	case 43:
																		goto IL_029f;
																	case 37:
																		goto IL_02aa;
																	case 55:
																	case 62:
																		goto IL_02b8;
																	case 91:
																		goto IL_02e1;
																	case 0:
																		goto IL_02ef;
																	case 31:
																		goto IL_0302;
																	case 56:
																		goto IL_0310;
																	case 8:
																	case 10:
																		goto IL_031e;
																	case 47:
																		goto IL_035e;
																	case 23:
																		goto IL_0372;
																	case 63:
																		goto IL_0385;
																	case 71:
																	case 87:
																		goto IL_0390;
																	case 11:
																		goto IL_03d0;
																	case 13:
																		goto IL_03e4;
																	case 30:
																		goto IL_03f7;
																	case 20:
																		goto IL_0405;
																	case 1:
																		goto IL_0418;
																	case 49:
																		goto IL_0426;
																	case 35:
																	case 57:
																		goto IL_0431;
																	case 81:
																		goto IL_044a;
																	case 96:
																		goto IL_0458;
																	case 65:
																		goto IL_0466;
																	case 36:
																		goto IL_0479;
																	case 41:
																		goto IL_0490;
																	case 25:
																	case 68:
																		goto IL_049e;
																	case 12:
																		goto IL_04de;
																	case 16:
																		goto IL_04f2;
																	case 76:
																		goto IL_0505;
																	case 15:
																		goto IL_0510;
																	case 38:
																		goto IL_051e;
																	case 88:
																	case 92:
																		goto IL_052c;
																	case 24:
																		goto IL_0551;
																	case 53:
																	case 83:
																		goto IL_0567;
																	case 5:
																		goto IL_05a7;
																	case 86:
																		goto IL_05bb;
																	case 26:
																	case 32:
																	case 33:
																	case 48:
																	case 58:
																	case 59:
																	case 66:
																	case 67:
																	case 80:
																	case 84:
																	case 85:
																	case 90:
																	case 93:
																	case 94:
																	case 95:
																		goto IL_05cb;
																	case 3:
																		goto IL_05ee;
																	case 78:
																		goto IL_05fc;
																	case 97:
																		goto IL_060a;
																	case 19:
																	case 27:
																	case 28:
																	case 44:
																	case 46:
																	case 54:
																	case 60:
																	case 64:
																	case 69:
																	case 79:
																	case 89:
																		goto end_IL_01c3;
																	case 52:
																		goto end_IL_0618;
																	case 2:
																		goto end_IL_062b;
																	case 29:
																		goto end_IL_0635;
																	case 98:
																		goto end_IL_0640;
																	case 75:
																		goto end_IL_0655;
																	case 18:
																	case 21:
																		goto end_IL_066a;
																	case 42:
																		goto end_IL_067a;
																	case 70:
																	case 72:
																		goto end_IL_068a;
																	case 73:
																		goto end_IL_069a;
																	case 74:
																		goto end_IL_06aa;
																	case 39:
																	case 82:
																		goto IL_06c5;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_01d7;
																IL_0567:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05a7;
																IL_05bb:
																num5--;
																goto end_IL_01c3;
																IL_05a7:
																array[num5 - 2] = 0;
																goto IL_05bb;
																IL_01d7:
																ptr2++;
																num = 61;
																goto IL_01ee;
																IL_01ee:
																if (b >= 1)
																{
																	goto IL_01fc;
																}
																goto IL_05cb;
																IL_01fc:
																if (b <= 9)
																{
																	goto IL_020a;
																}
																goto IL_05cb;
																IL_020a:
																if (5 >= b)
																{
																	goto IL_0218;
																}
																goto IL_0418;
																IL_0218:
																if (5 <= b)
																{
																	goto IL_0223;
																}
																goto IL_0288;
																IL_0223:
																array[num5] = 0;
																goto IL_0231;
																IL_0231:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0254;
																IL_0254:
																array2[num5] = null;
																num = 50;
																goto IL_0267;
																IL_0267:
																num5++;
																goto IL_0275;
																IL_0275:
																ptr2 += 8;
																goto end_IL_01c3;
																IL_0288:
																if (2 < b)
																{
																	num = 43;
																	goto IL_029f;
																}
																goto IL_0385;
																IL_05cb:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_05ee;
																IL_029f:
																if (3 >= b)
																{
																	goto IL_02aa;
																}
																goto IL_0302;
																IL_02aa:
																if (3 <= b)
																{
																	goto IL_02b8;
																}
																goto IL_05cb;
																IL_02b8:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_02e1;
																IL_02e1:
																ptr2 += 8;
																goto IL_02ef;
																IL_02ef:
																num5--;
																goto end_IL_01c3;
																IL_0302:
																if (4 >= b)
																{
																	goto IL_0310;
																}
																goto IL_05cb;
																IL_0310:
																if (4 <= b)
																{
																	goto IL_031e;
																}
																goto IL_05cb;
																IL_031e:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_035e;
																IL_035e:
																array[num5 - 2] = 0;
																goto IL_0372;
																IL_0372:
																num5--;
																goto end_IL_01c3;
																IL_0385:
																if (2 <= b)
																{
																	goto IL_0390;
																}
																goto IL_03f7;
																IL_0390:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_03d0;
																IL_03d0:
																array[num5 - 2] = 0;
																goto IL_03e4;
																IL_03e4:
																num5--;
																goto end_IL_01c3;
																IL_03f7:
																if (1 >= b)
																{
																	goto IL_0405;
																}
																goto IL_05cb;
																IL_0405:
																if (1 > b)
																{
																}
																goto IL_05cb;
																IL_0418:
																if (7 >= b)
																{
																	goto IL_0426;
																}
																goto IL_0505;
																IL_0426:
																if (7 <= b)
																{
																	goto IL_0431;
																}
																goto IL_0479;
																IL_0431:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_044a;
																IL_044a:
																array[num5] = 0;
																goto IL_0458;
																IL_0458:
																num5++;
																goto IL_0466;
																IL_0466:
																ptr2 += 8;
																goto end_IL_01c3;
																IL_0479:
																if (6 >= b)
																{
																	num = 41;
																	goto IL_0490;
																}
																goto IL_05cb;
																IL_05ee:
																array[num5] = 0;
																goto IL_05fc;
																IL_0490:
																if (6 <= b)
																{
																	goto IL_049e;
																}
																goto IL_05cb;
																IL_049e:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04de;
																IL_04de:
																array[num5 - 2] = 0;
																goto IL_04f2;
																IL_04f2:
																num5--;
																goto end_IL_01c3;
																IL_0505:
																if (8 < b)
																{
																	goto IL_0510;
																}
																num = 24;
																goto IL_0551;
																IL_0510:
																if (9 >= b)
																{
																	goto IL_051e;
																}
																goto IL_05cb;
																IL_051e:
																if (9 <= b)
																{
																	goto IL_052c;
																}
																goto IL_05cb;
																IL_052c:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_01c3;
																IL_05fc:
																num5++;
																goto IL_060a;
																IL_0551:
																if (8 <= b)
																{
																	goto IL_0567;
																}
																num = 93;
																goto IL_05cb;
																IL_060a:
																ptr2 += 8;
																goto end_IL_01c3;
																continue;
																end_IL_01b3:
																break;
															}
															continue;
															end_IL_01c3:
															break;
														}
														continue;
													}
													goto IL_06c5;
													IL_06c5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0618:
													break;
												}
												continue;
												end_IL_062b:
												break;
											}
											continue;
											end_IL_0635:
											break;
										}
										continue;
										end_IL_0640:
										break;
									}
									continue;
									end_IL_0655:
									break;
								}
								continue;
								end_IL_066a:
								break;
							}
							continue;
							end_IL_067a:
							break;
						}
						continue;
						end_IL_068a:
						break;
					}
					continue;
					end_IL_069a:
					break;
				}
				continue;
				end_IL_06aa:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 94;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 107;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										num = 51;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FormatDeployment.IgnoreSectdefaultPermissionSetID);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0317:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02fa:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02ea:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_02da:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_02ca:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_02ba:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															IL_028f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_0276:
																																array[num5] = 0;
																																num = 149;
																																while (true)
																																{
																																	if (num != 149)
																																	{
																																		if (num != 1130)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 92:
																																			goto IL_0276;
																																		case 11:
																																		case 139:
																																			goto IL_028f;
																																		case 18:
																																			goto IL_02aa;
																																		case 56:
																																			goto IL_02ba;
																																		case 125:
																																			goto IL_02ca;
																																		case 57:
																																		case 103:
																																			goto IL_02da;
																																		case 129:
																																			goto IL_02ea;
																																		case 97:
																																			goto IL_02fa;
																																		case 138:
																																			goto IL_0307;
																																		case 135:
																																			goto IL_0317;
																																		case 117:
																																			goto end_IL_0317;
																																		case 21:
																																		case 112:
																																			goto end_IL_0327;
																																		case 20:
																																		case 24:
																																			goto IL_0342;
																																		case 12:
																																			goto IL_0350;
																																		case 30:
																																		case 39:
																																			goto IL_035b;
																																		case 43:
																																		case 55:
																																			goto IL_0371;
																																		case 9:
																																			goto IL_037f;
																																		case 31:
																																			goto IL_038d;
																																		case 47:
																																			goto IL_0398;
																																		case 83:
																																			goto IL_03b9;
																																		case 85:
																																			goto IL_03f8;
																																		case 90:
																																			goto IL_040b;
																																		case 23:
																																		case 102:
																																			goto IL_041b;
																																		case 111:
																																			goto IL_0433;
																																		case 10:
																																		case 26:
																																			goto IL_0441;
																																		case 48:
																																			goto IL_0481;
																																		case 29:
																																			goto IL_0495;
																																		case 35:
																																		case 114:
																																			goto IL_04a8;
																																		case 62:
																																			goto IL_050a;
																																		case 130:
																																			goto IL_051d;
																																		case 84:
																																		case 96:
																																			goto IL_0528;
																																		case 124:
																																			goto IL_0536;
																																		case 58:
																																			goto IL_0549;
																																		case 80:
																																		case 122:
																																			goto IL_0554;
																																		case 3:
																																		case 133:
																																			goto IL_057b;
																																		case 60:
																																			goto IL_059e;
																																		case 131:
																																			goto IL_05ac;
																																		case 65:
																																			goto IL_05ba;
																																		case 16:
																																		case 140:
																																			goto IL_05cd;
																																		case 44:
																																			goto IL_05db;
																																		case 89:
																																		case 136:
																																			goto IL_05f2;
																																		case 105:
																																			goto IL_0613;
																																		case 137:
																																			goto IL_0626;
																																		case 42:
																																			goto IL_0634;
																																		case 79:
																																		case 98:
																																			goto IL_0642;
																																		case 37:
																																			goto IL_0674;
																																		case 68:
																																			goto IL_0682;
																																		case 78:
																																			goto IL_0695;
																																		case 6:
																																		case 77:
																																			goto IL_06a3;
																																		case 72:
																																			goto IL_06b1;
																																		case 46:
																																		case 50:
																																			goto IL_06bf;
																																		case 14:
																																			goto IL_06ff;
																																		case 127:
																																			goto IL_0713;
																																		case 61:
																																			goto IL_0726;
																																		case 66:
																																		case 81:
																																			goto IL_0731;
																																		case 95:
																																			goto IL_073f;
																																		case 22:
																																		case 87:
																																			goto IL_0752;
																																		case 34:
																																			goto IL_0760;
																																		case 38:
																																			goto IL_0783;
																																		case 67:
																																			goto IL_0796;
																																		case 17:
																																			goto IL_07a4;
																																		case 73:
																																		case 108:
																																			goto IL_07b4;
																																		case 74:
																																			goto IL_07f4;
																																		case 113:
																																			goto IL_0808;
																																		case 0:
																																		case 1:
																																		case 5:
																																		case 8:
																																		case 13:
																																		case 19:
																																		case 25:
																																		case 28:
																																		case 33:
																																		case 41:
																																		case 53:
																																		case 54:
																																		case 63:
																																		case 64:
																																		case 69:
																																		case 71:
																																		case 75:
																																		case 86:
																																		case 88:
																																		case 99:
																																		case 106:
																																		case 115:
																																		case 116:
																																		case 118:
																																		case 119:
																																		case 120:
																																		case 126:
																																		case 134:
																																		case 142:
																																			goto end_IL_0263;
																																		case 2:
																																		case 7:
																																		case 15:
																																		case 32:
																																		case 36:
																																		case 52:
																																		case 59:
																																		case 70:
																																		case 76:
																																		case 100:
																																		case 104:
																																		case 110:
																																		case 121:
																																		case 123:
																																		case 128:
																																		case 132:
																																		case 141:
																																			goto end_IL_0337;
																																		case 101:
																																			goto end_IL_082b;
																																		case 51:
																																			goto end_IL_083e;
																																		case 49:
																																			goto end_IL_0848;
																																		case 40:
																																			goto end_IL_0853;
																																		case 4:
																																		case 82:
																																			goto end_IL_0871;
																																		case 91:
																																			goto end_IL_0881;
																																		case 107:
																																			goto end_IL_0891;
																																		case 45:
																																			goto end_IL_08a1;
																																		case 93:
																																			goto end_IL_08b1;
																																		case 94:
																																			goto end_IL_08bc;
																																		case 27:
																																		case 109:
																																			goto IL_08d7;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_0613;
																																	IL_0613:
																																	ptr2 += 8;
																																	goto end_IL_0337;
																																	continue;
																																	end_IL_0263:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																														IL_02aa:;
																													}
																													break;
																												}
																												goto IL_0626;
																												IL_0682:
																												num5--;
																												goto end_IL_0337;
																												IL_0626:
																												if (2 < b)
																												{
																													break;
																												}
																												goto IL_0634;
																												IL_0634:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_0642;
																												IL_0642:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 37;
																												goto IL_0674;
																												IL_0674:
																												ptr2 += 8;
																												goto IL_0682;
																											}
																											break;
																										}
																										goto IL_041b;
																										IL_041b:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0337;
																									}
																									break;
																								}
																								goto IL_0695;
																								IL_07a4:
																								ptr2 += 8;
																								goto end_IL_0337;
																								IL_0695:
																								if (5 < b)
																								{
																									goto IL_06a3;
																								}
																								goto IL_0726;
																								IL_06a3:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_06b1;
																								IL_06b1:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_06bf;
																								IL_06bf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_06ff;
																								IL_06ff:
																								array[num5 - 2] = 0;
																								goto IL_0713;
																								IL_0713:
																								num5--;
																								goto end_IL_0337;
																								IL_0726:
																								if (5 > b)
																								{
																									goto IL_0731;
																								}
																								goto IL_0752;
																								IL_0731:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_073f;
																								IL_073f:
																								if (4 <= b)
																								{
																									goto end_IL_0337;
																								}
																								break;
																								IL_0752:
																								array[num5] = 0;
																								goto IL_0760;
																								IL_0760:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0783;
																								IL_0783:
																								array2[num5] = null;
																								num = 67;
																								goto IL_0796;
																								IL_0796:
																								num5++;
																								goto IL_07a4;
																							}
																							break;
																						}
																						goto IL_07b4;
																						IL_0808:
																						num5--;
																						goto end_IL_0337;
																						IL_07b4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_07f4;
																						IL_07f4:
																						array[num5 - 2] = 0;
																						goto IL_0808;
																					}
																					break;
																				}
																				goto IL_0342;
																				IL_05cd:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_05db;
																				IL_0342:
																				if (11 >= b)
																				{
																					goto IL_0350;
																				}
																				goto IL_051d;
																				IL_0350:
																				if (11 <= b)
																				{
																					goto IL_035b;
																				}
																				goto IL_0371;
																				IL_035b:
																				array[num5 - 1] = 0;
																				goto IL_03b9;
																				IL_03b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)GetRuntimeMethodssetRefusedSet[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_03f8;
																				IL_03f8:
																				ptr2 += 8;
																				goto end_IL_0337;
																				IL_0371:
																				if (9 >= b)
																				{
																					goto IL_037f;
																				}
																				goto IL_040b;
																				IL_037f:
																				if (9 > b)
																				{
																					goto IL_038d;
																				}
																				goto IL_04a8;
																				IL_038d:
																				if (8 < b)
																				{
																					num = 19;
																					break;
																				}
																				goto IL_0398;
																				IL_0398:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_057b;
																				IL_057b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_059e;
																				IL_059e:
																				array[num5] = 0;
																				goto IL_05ac;
																				IL_05ac:
																				num5++;
																				goto IL_05ba;
																				IL_05ba:
																				ptr2 += 8;
																				goto end_IL_0337;
																				IL_05db:
																				if (12 > b)
																				{
																					break;
																				}
																				num = 136;
																				goto IL_05f2;
																				IL_04a8:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_050a;
																				IL_050a:
																				num5 -= 2;
																				goto end_IL_0337;
																				IL_040b:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0433;
																				IL_0433:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0441;
																				IL_0441:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0481;
																				IL_0481:
																				array[num5 - 2] = 0;
																				goto IL_0495;
																				IL_0495:
																				num5--;
																				goto end_IL_0337;
																				IL_051d:
																				if (13 < b)
																				{
																					goto IL_0528;
																				}
																				goto IL_0549;
																				IL_0528:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_0536;
																				IL_0536:
																				if (14 <= b)
																				{
																				}
																				break;
																				IL_0549:
																				if (13 <= b)
																				{
																					goto IL_0554;
																				}
																				num = 140;
																				goto IL_05cd;
																				IL_0554:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0337;
																				IL_05f2:
																				num5--;
																				goto end_IL_0337;
																			}
																			break;
																			IL_0307:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0337;
																	continue;
																	end_IL_0317:
																	break;
																}
																continue;
																end_IL_0327:
																break;
															}
															continue;
															end_IL_0337:
															break;
														}
														continue;
													}
													goto IL_08d7;
													IL_08d7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_082b:
													break;
												}
												continue;
												end_IL_083e:
												break;
											}
											continue;
											end_IL_0848:
											break;
										}
										continue;
										end_IL_0853:
										break;
									}
									continue;
									end_IL_0871:
									break;
								}
								continue;
								end_IL_0881:
								break;
							}
							continue;
							end_IL_0891:
							break;
						}
						continue;
						end_IL_08a1:
						break;
					}
					continue;
					end_IL_08b1:
					break;
				}
				continue;
				end_IL_08bc:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 35;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DirectoryStringIsTransparentProxy.JaggedOffsetReferenceToTextBuffer);
											num = 44;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0261:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0244:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0237:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0227:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0217:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												num = 117;
																												while (true)
																												{
																													if (num != 117)
																													{
																														if (num != 1098)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 71:
																															goto IL_0204;
																														case 53:
																														case 95:
																															goto end_IL_01f1;
																														case 54:
																															goto IL_0227;
																														case 63:
																															goto IL_0237;
																														case 79:
																															goto IL_0244;
																														case 2:
																															goto IL_0251;
																														case 40:
																															goto IL_0261;
																														case 88:
																															goto end_IL_0261;
																														case 17:
																														case 57:
																															goto end_IL_0271;
																														case 43:
																															goto IL_028c;
																														case 51:
																														case 58:
																															goto IL_029c;
																														case 13:
																														case 39:
																															goto IL_02aa;
																														case 33:
																														case 72:
																															goto IL_02ba;
																														case 68:
																															goto IL_02fa;
																														case 45:
																															goto IL_030e;
																														case 74:
																															goto IL_032a;
																														case 84:
																															goto IL_033d;
																														case 70:
																														case 86:
																															goto IL_034b;
																														case 30:
																														case 100:
																															goto IL_0367;
																														case 23:
																															goto IL_0375;
																														case 8:
																														case 41:
																															goto IL_0380;
																														case 62:
																															goto IL_0398;
																														case 28:
																															goto IL_03a6;
																														case 31:
																														case 73:
																															goto IL_03b4;
																														case 42:
																															goto IL_03cd;
																														case 49:
																															goto IL_03db;
																														case 26:
																															goto IL_03e9;
																														case 46:
																															goto IL_03fc;
																														case 47:
																														case 52:
																															goto IL_0413;
																														case 97:
																															goto IL_0421;
																														case 3:
																														case 90:
																															goto IL_0438;
																														case 0:
																															goto IL_0446;
																														case 81:
																															goto IL_0469;
																														case 94:
																															goto IL_0473;
																														case 24:
																														case 101:
																															goto IL_0486;
																														case 37:
																															goto IL_0494;
																														case 6:
																														case 89:
																															goto IL_04ab;
																														case 9:
																															goto IL_04d4;
																														case 5:
																															goto IL_04e2;
																														case 105:
																															goto IL_04f5;
																														case 14:
																														case 34:
																															goto IL_0503;
																														case 103:
																															goto IL_0543;
																														case 106:
																															goto IL_0559;
																														case 108:
																															goto IL_056c;
																														case 109:
																															goto IL_057f;
																														case 32:
																														case 66:
																															goto IL_05a0;
																														case 93:
																															goto IL_05c3;
																														case 99:
																															goto IL_05d1;
																														case 21:
																															goto IL_05df;
																														case 36:
																														case 104:
																															goto IL_05fb;
																														case 65:
																															goto IL_0666;
																														case 1:
																														case 15:
																														case 18:
																														case 27:
																														case 50:
																														case 60:
																														case 69:
																														case 75:
																														case 76:
																														case 77:
																														case 78:
																														case 83:
																														case 85:
																														case 87:
																														case 91:
																														case 98:
																														case 110:
																															goto end_IL_0204;
																														case 7:
																														case 12:
																														case 16:
																														case 19:
																														case 22:
																														case 25:
																														case 38:
																														case 48:
																														case 56:
																														case 59:
																														case 82:
																														case 92:
																														case 102:
																														case 107:
																															goto end_IL_0281;
																														case 44:
																															goto end_IL_0689;
																														case 55:
																															goto end_IL_069c;
																														case 4:
																															goto end_IL_06a6;
																														case 96:
																															goto end_IL_06ba;
																														case 35:
																															goto end_IL_06cf;
																														case 64:
																															goto end_IL_06df;
																														case 20:
																															goto end_IL_06ef;
																														case 29:
																														case 67:
																															goto end_IL_06fa;
																														case 10:
																															goto end_IL_070a;
																														case 11:
																															goto end_IL_071a;
																														case 61:
																														case 80:
																															goto IL_0735;
																														}
																														continue;
																													}
																													if (8 > b)
																													{
																														goto end_IL_0204;
																													}
																													goto IL_05a0;
																													IL_05c3:
																													array[num5] = 0;
																													goto IL_05d1;
																													IL_05df:
																													ptr2 += 8;
																													num = 22;
																													goto end_IL_0281;
																													IL_05d1:
																													num5++;
																													goto IL_05df;
																													IL_05a0:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_05c3;
																													continue;
																													end_IL_01f1:
																													break;
																												}
																												goto IL_0217;
																												continue;
																												end_IL_0204:
																												break;
																												IL_0204:;
																											}
																											break;
																										}
																										goto IL_04f5;
																										IL_057f:
																										num5--;
																										goto end_IL_0281;
																										IL_04f5:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0503;
																										IL_0503:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0543;
																										IL_0543:
																										array[num5 - 2] = 0;
																										goto IL_057f;
																									}
																									break;
																								}
																								goto IL_05fb;
																								IL_0666:
																								num5 -= 2;
																								goto end_IL_0281;
																								IL_05fb:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 65;
																								goto IL_0666;
																							}
																							break;
																						}
																						goto IL_029c;
																						IL_034b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0281;
																						IL_029c:
																						if (10 < b)
																						{
																							goto IL_02aa;
																						}
																						goto IL_033d;
																						IL_02aa:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_032a;
																						IL_032a:
																						if (11 <= b)
																						{
																						}
																						break;
																						IL_033d:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_034b;
																					}
																					break;
																				}
																				goto IL_028c;
																				IL_056c:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_0281;
																				IL_028c:
																				if (6 <= b)
																				{
																					goto IL_02ba;
																				}
																				goto IL_0367;
																				IL_0367:
																				if (3 >= b)
																				{
																					goto IL_0375;
																				}
																				goto IL_03fc;
																				IL_0375:
																				if (3 <= b)
																				{
																					goto IL_0380;
																				}
																				goto IL_0398;
																				IL_0380:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0281;
																				IL_0398:
																				if (1 >= b)
																				{
																					goto IL_03a6;
																				}
																				goto IL_0486;
																				IL_03a6:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_03b4;
																				IL_03b4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_03cd;
																				IL_03cd:
																				array[num5] = 0;
																				goto IL_03db;
																				IL_03db:
																				num5++;
																				goto IL_03e9;
																				IL_03e9:
																				ptr2 += 8;
																				goto end_IL_0281;
																				IL_0486:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0494;
																				IL_0494:
																				if (2 > b)
																				{
																					break;
																				}
																				num = 89;
																				goto IL_04ab;
																				IL_02ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02fa;
																				IL_04ab:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04d4;
																				IL_04d4:
																				ptr2 += 8;
																				goto IL_04e2;
																				IL_04e2:
																				num5--;
																				goto end_IL_0281;
																				IL_03fc:
																				if (4 < b)
																				{
																					num = 47;
																					goto IL_0413;
																				}
																				goto IL_056c;
																				IL_02fa:
																				array[num5 - 2] = 0;
																				goto IL_030e;
																				IL_0413:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0421;
																				IL_0421:
																				if (5 > b)
																				{
																					break;
																				}
																				num = 3;
																				goto IL_0438;
																				IL_030e:
																				num5--;
																				num = 48;
																				goto end_IL_0281;
																				IL_0438:
																				array[num5] = 0;
																				goto IL_0446;
																				IL_0446:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0469;
																				IL_0469:
																				array2[num5] = null;
																				goto IL_0473;
																				IL_0473:
																				num5++;
																				goto IL_0559;
																				IL_0559:
																				ptr2 += 8;
																				goto end_IL_0281;
																			}
																			break;
																			IL_0251:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0281;
																	continue;
																	end_IL_0261:
																	break;
																}
																continue;
																end_IL_0271:
																break;
															}
															continue;
															end_IL_0281:
															break;
														}
														continue;
													}
													goto IL_0735;
													IL_0735:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0689:
													break;
												}
												continue;
												end_IL_069c:
												break;
											}
											continue;
											end_IL_06a6:
											break;
										}
										continue;
										end_IL_06ba:
										break;
									}
									continue;
									end_IL_06cf:
									break;
								}
								continue;
								end_IL_06df:
								break;
							}
							continue;
							end_IL_06ef:
							break;
						}
						continue;
						end_IL_06fa:
						break;
					}
					continue;
					end_IL_070a:
					break;
				}
				continue;
				end_IL_071a:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 10;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeftAltPressedBindToName.CLAIMSECURITYATTRIBUTESINFORMATIONBuiltinNetworkConfigurationOperatorsSid);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 71;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0202:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01e2:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01d2:
																							if (6 < b)
																							{
																								num = 54;
																								while (true)
																								{
																									IL_01c5:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											num = 93;
																											while (true)
																											{
																												if (num != 93)
																												{
																													if (num != 1074)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 56:
																														goto IL_01b2;
																													case 29:
																													case 54:
																														goto IL_01c5;
																													case 12:
																														goto IL_01d2;
																													case 41:
																														goto IL_01e2;
																													case 79:
																														goto IL_01f2;
																													case 72:
																														goto IL_0202;
																													case 82:
																														goto end_IL_0202;
																													case 4:
																													case 45:
																														goto end_IL_0212;
																													case 3:
																														goto IL_022d;
																													case 26:
																														goto IL_023d;
																													case 32:
																													case 38:
																														goto IL_0250;
																													case 52:
																														goto IL_0267;
																													case 70:
																														goto IL_027a;
																													case 14:
																													case 64:
																														goto IL_0285;
																													case 39:
																														goto IL_02ae;
																													case 27:
																														goto IL_02bc;
																													case 49:
																														goto IL_02cf;
																													case 0:
																														goto IL_02dd;
																													case 30:
																													case 67:
																														goto IL_02eb;
																													case 60:
																														goto IL_0359;
																													case 47:
																														goto IL_036c;
																													case 33:
																													case 76:
																														goto IL_037c;
																													case 57:
																													case 80:
																														goto IL_0394;
																													case 35:
																														goto IL_03a2;
																													case 59:
																														goto IL_03c5;
																													case 13:
																														goto IL_03cf;
																													case 22:
																														goto IL_03dd;
																													case 84:
																														goto IL_03f0;
																													case 28:
																													case 86:
																														goto IL_0403;
																													case 21:
																														goto IL_0411;
																													case 43:
																													case 50:
																														goto IL_041f;
																													case 18:
																														goto IL_045f;
																													case 61:
																														goto IL_0473;
																													case 23:
																													case 25:
																														goto IL_048e;
																													case 5:
																													case 6:
																													case 7:
																													case 8:
																													case 11:
																													case 15:
																													case 31:
																													case 34:
																													case 37:
																													case 46:
																													case 53:
																													case 62:
																													case 63:
																													case 83:
																													case 85:
																														goto end_IL_01b2;
																													case 55:
																														goto IL_04ca;
																													case 44:
																														goto IL_04d8;
																													case 19:
																														goto end_IL_019f;
																													case 2:
																													case 20:
																													case 42:
																													case 51:
																													case 69:
																													case 71:
																													case 74:
																													case 75:
																													case 77:
																													case 78:
																														goto end_IL_0222;
																													case 81:
																														goto end_IL_04f4;
																													case 40:
																														goto end_IL_0507;
																													case 36:
																														goto end_IL_0512;
																													case 16:
																														goto end_IL_051c;
																													case 48:
																														goto end_IL_0527;
																													case 68:
																														goto end_IL_053c;
																													case 24:
																													case 65:
																														goto end_IL_0551;
																													case 17:
																														goto end_IL_0561;
																													case 66:
																													case 73:
																														goto end_IL_0571;
																													case 9:
																														goto end_IL_0581;
																													case 10:
																														goto end_IL_0591;
																													case 1:
																													case 58:
																														goto IL_05ac;
																													}
																													continue;
																												}
																												if (8 > b)
																												{
																													goto end_IL_01b2;
																												}
																												goto IL_048e;
																												IL_048e:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												goto end_IL_0222;
																												continue;
																												end_IL_019f:
																												break;
																											}
																											goto IL_04e6;
																											continue;
																											end_IL_01b2:
																											break;
																											IL_01b2:;
																										}
																										break;
																									}
																									goto IL_023d;
																									IL_03dd:
																									ptr2 += 8;
																									goto end_IL_0222;
																									IL_023d:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0394;
																									IL_0394:
																									array[num6] = 0;
																									goto IL_03a2;
																									IL_03a2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03c5;
																									IL_03c5:
																									array2[num6] = null;
																									goto IL_03cf;
																									IL_03cf:
																									num6++;
																									goto IL_03dd;
																								}
																								break;
																							}
																							goto IL_022d;
																							IL_037c:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0222;
																							IL_0267:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_037c;
																							IL_022d:
																							if (6 <= b)
																							{
																								goto end_IL_0222;
																							}
																							goto IL_0250;
																							IL_0250:
																							if (5 < b)
																							{
																								break;
																							}
																							num = 52;
																							goto IL_0267;
																						}
																						break;
																					}
																					goto IL_027a;
																					IL_0473:
																					num6--;
																					goto end_IL_0222;
																					IL_027a:
																					if (4 <= b)
																					{
																						goto IL_0285;
																					}
																					goto IL_02cf;
																					IL_0285:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_02ae;
																					IL_02ae:
																					ptr2 += 8;
																					goto IL_02bc;
																					IL_02bc:
																					num6--;
																					goto end_IL_0222;
																					IL_02cf:
																					if (2 >= b)
																					{
																						goto IL_02dd;
																					}
																					goto IL_0403;
																					IL_02dd:
																					if (2 <= b)
																					{
																						goto IL_02eb;
																					}
																					goto IL_036c;
																					IL_02eb:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0359;
																					IL_0359:
																					num6 -= 2;
																					goto end_IL_0222;
																					IL_036c:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_03f0;
																					IL_03f0:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0403:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0411;
																					IL_0411:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_041f;
																					IL_041f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_045f;
																					IL_045f:
																					array[num6 - 2] = 0;
																					goto IL_0473;
																				}
																				break;
																				IL_01f2:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04ca;
																		IL_04e6:
																		ptr2 += 8;
																		goto end_IL_0222;
																		IL_04d8:
																		num6++;
																		goto IL_04e6;
																		IL_04ca:
																		array[num6] = 0;
																		goto IL_04d8;
																		continue;
																		end_IL_0202:
																		break;
																	}
																	continue;
																	end_IL_0212:
																	break;
																}
																continue;
																end_IL_0222:
																break;
															}
															continue;
														}
														goto IL_05ac;
														IL_05ac:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_04f4:
														break;
													}
													continue;
													end_IL_0507:
													break;
												}
												continue;
												end_IL_0512:
												break;
											}
											continue;
											end_IL_051c:
											break;
										}
										continue;
										end_IL_0527:
										break;
									}
									continue;
									end_IL_053c:
									break;
								}
								continue;
								end_IL_0551:
								break;
							}
							continue;
							end_IL_0561:
							break;
						}
						continue;
						end_IL_0571:
						break;
					}
					continue;
					end_IL_0581:
					break;
				}
				continue;
				end_IL_0591:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 14;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 56;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetGroupIsEqualDomainSid.LockedDefineDocument);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0230:
															byte b = *ptr2;
															while (true)
															{
																IL_0220:
																ptr2++;
																while (true)
																{
																	IL_0210:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01f3:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01e3:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (true)
																									{
																										IL_01b0:
																										if (5 > b)
																										{
																											num = 96;
																											while (num != 96)
																											{
																												if (num != 1077)
																												{
																													goto end_IL_01d3;
																												}
																												switch (num)
																												{
																												case 57:
																													goto IL_01b0;
																												case 31:
																												case 33:
																													goto IL_01c3;
																												case 6:
																													goto IL_01d3;
																												case 30:
																												case 65:
																													goto IL_01e3;
																												case 19:
																													goto IL_01f3;
																												case 39:
																													goto IL_0200;
																												case 27:
																													goto IL_0210;
																												case 26:
																													goto IL_0220;
																												case 9:
																												case 63:
																													goto IL_0230;
																												case 23:
																													goto IL_023b;
																												case 16:
																												case 62:
																													goto IL_0246;
																												case 73:
																													goto IL_026f;
																												case 34:
																													goto IL_027d;
																												case 10:
																												case 79:
																													goto IL_0290;
																												case 53:
																													goto IL_029e;
																												case 15:
																												case 50:
																													goto IL_02ac;
																												case 54:
																													goto IL_031a;
																												case 35:
																													goto IL_032d;
																												case 68:
																													goto IL_033b;
																												case 11:
																													goto IL_034e;
																												case 32:
																													goto IL_035c;
																												case 1:
																												case 36:
																													goto IL_036a;
																												case 8:
																													goto IL_03aa;
																												case 52:
																													goto IL_03be;
																												case 40:
																												case 84:
																													goto IL_03d1;
																												case 41:
																													goto IL_03e9;
																												case 85:
																												case 86:
																													goto IL_03f4;
																												case 17:
																													goto IL_0402;
																												case 61:
																												case 78:
																													goto IL_0410;
																												case 71:
																													goto IL_042c;
																												case 4:
																												case 5:
																													goto IL_0437;
																												case 2:
																													goto IL_0445;
																												case 69:
																													goto IL_0468;
																												case 37:
																													goto IL_0472;
																												case 83:
																													goto IL_0480;
																												case 7:
																												case 12:
																												case 18:
																												case 21:
																												case 22:
																												case 43:
																												case 45:
																												case 46:
																												case 49:
																												case 51:
																												case 59:
																												case 66:
																												case 72:
																												case 76:
																												case 77:
																												case 80:
																													goto end_IL_019d;
																												case 87:
																													goto IL_04b3;
																												case 70:
																													goto IL_04c1;
																												case 0:
																													goto IL_04cf;
																												case 3:
																												case 25:
																												case 28:
																												case 44:
																												case 55:
																												case 67:
																												case 75:
																												case 81:
																												case 82:
																												case 88:
																												case 89:
																													goto end_IL_01d3;
																												case 74:
																													goto end_IL_04e6;
																												case 60:
																													goto end_IL_04f9;
																												case 47:
																													goto end_IL_0503;
																												case 56:
																													goto end_IL_050e;
																												case 20:
																													goto end_IL_0523;
																												case 29:
																												case 38:
																													goto end_IL_0538;
																												case 42:
																													goto end_IL_0551;
																												case 24:
																												case 48:
																													goto end_IL_0561;
																												case 13:
																													goto end_IL_0571;
																												case 14:
																													goto end_IL_0581;
																												case 58:
																												case 64:
																													goto IL_05a5;
																												}
																												continue;
																												end_IL_019d:
																												break;
																											}
																											break;
																										}
																										goto IL_03d1;
																										IL_03d1:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_01d3;
																									}
																									break;
																									IL_01c3:;
																								}
																								goto end_IL_0200;
																								continue;
																								end_IL_01d3:
																								break;
																								IL_01d3:;
																							}
																							break;
																						}
																						goto IL_03e9;
																						IL_0480:
																						ptr2 += 8;
																						break;
																						IL_03e9:
																						if (7 < b)
																						{
																							goto IL_03f4;
																						}
																						goto IL_042c;
																						IL_03f4:
																						if (8 < b)
																						{
																							goto end_IL_0200;
																						}
																						goto IL_0402;
																						IL_0402:
																						if (8 > b)
																						{
																							goto end_IL_0200;
																						}
																						goto IL_0410;
																						IL_0410:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_042c:
																						if (7 > b)
																						{
																							goto end_IL_0200;
																						}
																						goto IL_0437;
																						IL_0437:
																						array[num6] = 0;
																						goto IL_0445;
																						IL_0445:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0468;
																						IL_0468:
																						array2[num6] = null;
																						goto IL_0472;
																						IL_0472:
																						num6++;
																						goto IL_0480;
																					}
																					break;
																				}
																				goto IL_023b;
																				IL_03be:
																				num6--;
																				break;
																				IL_023b:
																				if (4 <= b)
																				{
																					goto IL_0246;
																				}
																				goto IL_0290;
																				IL_0246:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_026f;
																				IL_026f:
																				ptr2 += 8;
																				goto IL_027d;
																				IL_027d:
																				num6--;
																				break;
																				IL_0290:
																				if (2 >= b)
																				{
																					goto IL_029e;
																				}
																				goto IL_034e;
																				IL_029e:
																				if (2 <= b)
																				{
																					goto IL_02ac;
																				}
																				goto IL_032d;
																				IL_02ac:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_031a;
																				IL_031a:
																				num6 -= 2;
																				break;
																				IL_032d:
																				if (1 < b)
																				{
																					goto end_IL_0200;
																				}
																				goto IL_033b;
																				IL_033b:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0200;
																				IL_034e:
																				if (3 < b)
																				{
																					goto end_IL_0200;
																				}
																				goto IL_035c;
																				IL_035c:
																				if (3 > b)
																				{
																					goto end_IL_0200;
																				}
																				goto IL_036a;
																				IL_036a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_03aa;
																				IL_03aa:
																				array[num6 - 2] = 0;
																				goto IL_03be;
																			}
																			goto end_IL_0210;
																			continue;
																			end_IL_0200:
																			break;
																			IL_0200:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b3;
																	IL_04cf:
																	ptr2 += 8;
																	num = 67;
																	break;
																	IL_04c1:
																	num6++;
																	goto IL_04cf;
																	IL_04b3:
																	array[num6] = 0;
																	goto IL_04c1;
																	continue;
																	end_IL_0210:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 64;
													goto IL_05a5;
													IL_05a5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04e6:
													break;
												}
												continue;
												end_IL_04f9:
												break;
											}
											continue;
											end_IL_0503:
											break;
										}
										continue;
										end_IL_050e:
										break;
									}
									continue;
									end_IL_0523:
									break;
								}
								continue;
								end_IL_0538:
								break;
							}
							continue;
							end_IL_0551:
							break;
						}
						continue;
						end_IL_0561:
						break;
					}
					continue;
					end_IL_0571:
					break;
				}
				continue;
				end_IL_0581:
				break;
			}
		}
	}

	private static int smethod_7(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_2;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	static Class151()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0052:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 3:
								goto IL_0046;
							case 1:
								goto IL_0052;
							case 2:
								goto end_IL_0039;
							case 0:
								return;
							case 4:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
