using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Hollow Sphere Medium", "Super Infection/Casual [MASTERCLIENT]", "Spawns medium hollow sphere.", true, 26, ModType.const_1, false)]
internal class Class115 : MonoBehaviour
{
	private static int int_0;

	private static float float_0;

	private static int int_1;

	private static int int_2;

	private static Vector3 GetConfigurationBytesglobalQueueTail;

	private static Quaternion EmitCallIgnoreSymbols;

	private static GameEntityCreateData StindREnumCategoryInstancesFlags;

	private static IntPtr[] HashElementEntryFieldIdsetApplicationUrl;

	private static IntPtr[] FromBinaryIdOps;

	private static IntPtr[] AtIdrefsRemoveAccessRuleSpecific;

	private static IntPtr[] SilverlightSynchronizationAttribute;

	private unsafe void OnEnable()
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 257;
						while (true)
						{
							int[] array3 = new int[3];
							num = 221;
							while (true)
							{
								int[] array4 = new int[9];
								num = 142;
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										while (true)
										{
											array6[0] = this;
											num = 312;
											while (true)
											{
												array6[1] = GetConfigurationBytesglobalQueueTail;
												while (true)
												{
													array6[5] = GetConfigurationBytesglobalQueueTail;
													while (true)
													{
														array6[6] = EmitCallIgnoreSymbols;
														while (true)
														{
															array6[7] = GetConfigurationBytesglobalQueueTail;
															while (true)
															{
																array6[8] = StindREnumCategoryInstancesFlags;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PermissionSetSectionL.SetCompressedStacksetMethodName);
																	while (true)
																	{
																		IL_2850:
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			IL_283d:
																			if (num4 == 1)
																			{
																				return;
																			}
																			while (true)
																			{
																				IL_09c8:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_09b8:
																					ptr2++;
																					while (true)
																					{
																						IL_09a8:
																						if (b >= 1)
																						{
																							while (b <= 67)
																							{
																								while (true)
																								{
																									IL_098b:
																									if (34 < b)
																									{
																										while (true)
																										{
																											IL_097b:
																											if (51 < b)
																											{
																												while (true)
																												{
																													IL_096b:
																													if (59 >= b)
																													{
																														while (true)
																														{
																															IL_095b:
																															if (59 > b)
																															{
																																while (true)
																																{
																																	IL_094b:
																																	if (55 < b)
																																	{
																																		while (true)
																																		{
																																			IL_093b:
																																			if (57 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_0928:
																																					if (57 <= b)
																																					{
																																						num = 574;
																																						while (true)
																																						{
																																							if (num != 574)
																																							{
																																								if (num != 1555)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 102:
																																									goto IL_0928;
																																								case 105:
																																									goto IL_093b;
																																								case 306:
																																									goto IL_094b;
																																								case 175:
																																									goto IL_095b;
																																								case 299:
																																									goto IL_096b;
																																								case 156:
																																									goto IL_097b;
																																								case 288:
																																									goto IL_098b;
																																								case 110:
																																									goto IL_0998;
																																								case 262:
																																									goto IL_09a8;
																																								case 522:
																																									goto IL_09b8;
																																								case 4:
																																								case 215:
																																									goto IL_09c8;
																																								case 337:
																																									goto IL_09d3;
																																								case 107:
																																								case 123:
																																									goto IL_09de;
																																								case 258:
																																									goto IL_0a0a;
																																								case 158:
																																									goto IL_0a18;
																																								case 38:
																																								case 73:
																																									goto IL_0a23;
																																								case 292:
																																									goto IL_0a86;
																																								case 43:
																																									goto IL_0a99;
																																								case 63:
																																									goto IL_0aa7;
																																								case 59:
																																									goto IL_0ab5;
																																								case 109:
																																									goto IL_0ac3;
																																								case 79:
																																									goto IL_0ace;
																																								case 271:
																																								case 302:
																																									goto IL_0adc;
																																								case 60:
																																									goto IL_0b04;
																																								case 86:
																																									goto IL_0b12;
																																								case 323:
																																									goto IL_0b25;
																																								case 360:
																																									goto IL_0b38;
																																								case 70:
																																								case 264:
																																									goto IL_0b46;
																																								case 310:
																																									goto IL_0b60;
																																								case 363:
																																									goto IL_0b73;
																																								case 350:
																																									goto IL_0b87;
																																								case 231:
																																									goto IL_0b92;
																																								case 311:
																																									goto IL_0bb3;
																																								case 340:
																																									goto IL_0bbe;
																																								case 270:
																																									goto IL_0bd1;
																																								case 289:
																																									goto IL_0bdf;
																																								case 200:
																																								case 290:
																																									goto IL_0bed;
																																								case 226:
																																									goto IL_0bfb;
																																								case 216:
																																									goto IL_0c1f;
																																								case 371:
																																									goto IL_0c32;
																																								case 372:
																																									goto IL_0c45;
																																								case 379:
																																									goto IL_0c58;
																																								case 381:
																																									goto IL_0c6b;
																																								case 373:
																																									goto IL_0c76;
																																								case 275:
																																									goto IL_0c84;
																																								case 45:
																																								case 47:
																																									goto IL_0c92;
																																								case 188:
																																									goto IL_0cb4;
																																								case 19:
																																									goto IL_0cbf;
																																								case 67:
																																								case 71:
																																									goto IL_0cdb;
																																								case 212:
																																									goto IL_0cef;
																																								case 207:
																																									goto IL_0d27;
																																								case 417:
																																									goto IL_0d3a;
																																								case 249:
																																									goto IL_0d48;
																																								case 422:
																																									goto IL_0d5b;
																																								case 20:
																																								case 413:
																																									goto IL_0d69;
																																								case 401:
																																									goto IL_0d7d;
																																								case 114:
																																									goto IL_0dce;
																																								case 205:
																																									goto IL_0ddc;
																																								case 91:
																																									goto IL_0def;
																																								case 425:
																																									goto IL_0e02;
																																								case 66:
																																									goto IL_0e10;
																																								case 429:
																																									goto IL_0e23;
																																								case 431:
																																									goto IL_0e36;
																																								case 433:
																																									goto IL_0e78;
																																								case 269:
																																									goto IL_0e86;
																																								case 272:
																																									goto IL_0e94;
																																								case 120:
																																									goto IL_0e9f;
																																								case 196:
																																								case 197:
																																									goto IL_0ead;
																																								case 103:
																																									goto IL_0ee5;
																																								case 261:
																																									goto IL_0ef9;
																																								case 49:
																																									goto IL_0f0c;
																																								case 314:
																																									goto IL_0f1a;
																																								case 2:
																																								case 168:
																																									goto IL_0f28;
																																								case 8:
																																									goto IL_0f3c;
																																								case 277:
																																								case 447:
																																									goto IL_0f79;
																																								case 250:
																																								case 461:
																																									goto IL_0fa9;
																																								case 117:
																																									goto IL_0ffb;
																																								case 478:
																																									goto IL_100e;
																																								case 484:
																																									goto IL_1021;
																																								case 487:
																																									goto IL_1034;
																																								case 495:
																																									goto IL_1047;
																																								case 164:
																																									goto IL_1052;
																																								case 28:
																																								case 223:
																																									goto IL_1060;
																																								case 459:
																																									goto IL_106e;
																																								case 419:
																																									goto IL_108c;
																																								case 263:
																																									goto IL_109a;
																																								case 238:
																																								case 453:
																																									goto IL_10a8;
																																								case 391:
																																									goto IL_10f4;
																																								case 498:
																																									goto IL_1107;
																																								case 332:
																																									goto IL_1115;
																																								case 316:
																																								case 435:
																																									goto IL_1120;
																																								case 171:
																																									goto IL_112e;
																																								case 421:
																																									goto IL_1151;
																																								case 128:
																																									goto IL_115b;
																																								case 129:
																																									goto IL_1169;
																																								case 147:
																																									goto IL_117c;
																																								case 486:
																																									goto IL_118a;
																																								case 174:
																																								case 233:
																																									goto IL_1198;
																																								case 491:
																																									goto IL_11d8;
																																								case 477:
																																									goto IL_11f5;
																																								case 444:
																																									goto IL_1208;
																																								case 414:
																																									goto IL_1216;
																																								case 279:
																																									goto IL_1224;
																																								case 104:
																																								case 161:
																																									goto IL_1232;
																																								case 471:
																																									goto IL_1272;
																																								case 90:
																																									goto IL_1286;
																																								case 209:
																																									goto IL_1299;
																																								case 134:
																																								case 294:
																																									goto IL_12a4;
																																								case 451:
																																									goto IL_12e4;
																																								case 506:
																																									goto IL_12fd;
																																								case 14:
																																									goto IL_130b;
																																								case 427:
																																								case 472:
																																									goto IL_1319;
																																								case 449:
																																									goto IL_1359;
																																								case 509:
																																									goto IL_137b;
																																								case 328:
																																								case 462:
																																									goto IL_1386;
																																								case 145:
																																									goto IL_139b;
																																								case 347:
																																									goto IL_13ae;
																																								case 301:
																																									goto IL_13b9;
																																								case 48:
																																								case 131:
																																									goto IL_13c7;
																																								case 9:
																																									goto IL_13f0;
																																								case 259:
																																									goto IL_13fe;
																																								case 469:
																																									goto IL_1411;
																																								case 52:
																																									goto IL_141f;
																																								case 80:
																																								case 483:
																																									goto IL_1436;
																																								case 153:
																																								case 510:
																																									goto IL_145b;
																																								case 77:
																																									goto IL_14c4;
																																								case 514:
																																									goto IL_14d7;
																																								case 126:
																																									goto IL_14f6;
																																								case 159:
																																									goto IL_1504;
																																								case 516:
																																									goto IL_1517;
																																								case 166:
																																									goto IL_1525;
																																								case 170:
																																								case 513:
																																									goto IL_1533;
																																								case 81:
																																									goto IL_154b;
																																								case 42:
																																									goto IL_1559;
																																								case 135:
																																									goto IL_1567;
																																								case 519:
																																									goto IL_1583;
																																								case 523:
																																									goto IL_159c;
																																								case 380:
																																								case 387:
																																									goto IL_15aa;
																																								case 368:
																																									goto IL_15b8;
																																								case 442:
																																									goto IL_15d6;
																																								case 184:
																																									goto IL_15e4;
																																								case 526:
																																									goto IL_15f7;
																																								case 7:
																																									goto IL_1605;
																																								case 530:
																																									goto IL_1618;
																																								case 464:
																																									goto IL_1626;
																																								case 137:
																																								case 157:
																																									goto IL_1634;
																																								case 62:
																																									goto IL_1642;
																																								case 53:
																																									goto IL_1660;
																																								case 291:
																																									goto IL_166e;
																																								case 531:
																																									goto IL_1681;
																																								case 204:
																																									goto IL_168f;
																																								case 283:
																																								case 404:
																																									goto IL_169d;
																																								case 409:
																																									goto IL_16ab;
																																								case 68:
																																									goto IL_16c3;
																																								case 190:
																																									goto IL_16d1;
																																								case 535:
																																									goto IL_16e4;
																																								case 536:
																																									goto IL_16f7;
																																								case 318:
																																									goto IL_1705;
																																								case 122:
																																								case 138:
																																									goto IL_1713;
																																								case 186:
																																									goto IL_1721;
																																								case 348:
																																									goto IL_1745;
																																								case 163:
																																									goto IL_1753;
																																								case 354:
																																								case 538:
																																									goto IL_1766;
																																								case 303:
																																									goto IL_177a;
																																								case 343:
																																									goto IL_17b9;
																																								case 539:
																																									goto IL_17cc;
																																								case 325:
																																									goto IL_17da;
																																								case 418:
																																								case 490:
																																									goto IL_17e8;
																																								case 202:
																																									goto IL_1828;
																																								case 542:
																																									goto IL_1841;
																																								case 544:
																																									goto IL_1854;
																																								case 149:
																																								case 466:
																																									goto IL_1862;
																																								case 112:
																																									goto IL_1876;
																																								case 296:
																																									goto IL_18d1;
																																								case 395:
																																									goto IL_18df;
																																								case 545:
																																									goto IL_18f2;
																																								case 551:
																																									goto IL_1905;
																																								case 220:
																																									goto IL_1913;
																																								case 85:
																																								case 321:
																																									goto IL_1921;
																																								case 351:
																																									goto IL_193a;
																																								case 446:
																																									goto IL_1948;
																																								case 515:
																																									goto IL_1956;
																																								case 30:
																																								case 552:
																																									goto IL_1969;
																																								case 93:
																																									goto IL_1977;
																																								case 467:
																																									goto IL_1995;
																																								case 50:
																																									goto IL_19a3;
																																								case 27:
																																								case 553:
																																									goto IL_19b6;
																																								case 144:
																																									goto IL_19ca;
																																								case 132:
																																									goto IL_1a07;
																																								case 554:
																																									goto IL_1a1a;
																																								case 470:
																																								case 556:
																																									goto IL_1a2d;
																																								case 561:
																																									goto IL_1a49;
																																								case 183:
																																									goto IL_1a57;
																																								case 57:
																																								case 416:
																																									goto IL_1a65;
																																								case 357:
																																									goto IL_1a73;
																																								case 500:
																																									goto IL_1a97;
																																								case 167:
																																									goto IL_1aa5;
																																								case 563:
																																									goto IL_1ab8;
																																								case 78:
																																									goto IL_1acf;
																																								case 341:
																																								case 390:
																																									goto IL_1add;
																																								case 26:
																																									goto IL_1b06;
																																								case 488:
																																									goto IL_1b14;
																																								case 527:
																																								case 567:
																																									goto IL_1b27;
																																								case 460:
																																									goto IL_1b89;
																																								case 265:
																																									goto IL_1b9c;
																																								case 329:
																																									goto IL_1baa;
																																								case 353:
																																									goto IL_1bcc;
																																								case 454:
																																									goto IL_1bda;
																																								case 565:
																																									goto IL_1bed;
																																								case 405:
																																									goto IL_1bfb;
																																								case 17:
																																								case 394:
																																									goto IL_1c09;
																																								case 224:
																																									goto IL_1c68;
																																								case 346:
																																									goto IL_1c7b;
																																								case 436:
																																									goto IL_1c89;
																																								case 319:
																																								case 393:
																																									goto IL_1c97;
																																								case 307:
																																									goto IL_1cf6;
																																								case 148:
																																									goto IL_1d09;
																																								case 458:
																																									goto IL_1d17;
																																								case 178:
																																								case 282:
																																									goto IL_1d22;
																																								case 315:
																																									goto IL_1d4c;
																																								case 252:
																																									goto IL_1d65;
																																								case 281:
																																									goto IL_1d73;
																																								case 98:
																																								case 540:
																																									goto IL_1d7e;
																																								case 489:
																																									goto IL_1d8c;
																																								case 35:
																																									goto IL_1dae;
																																								case 92:
																																									goto IL_1dbc;
																																								case 407:
																																									goto IL_1dcf;
																																								case 548:
																																									goto IL_1ddd;
																																								case 11:
																																								case 18:
																																									goto IL_1deb;
																																								case 382:
																																									goto IL_1e4b;
																																								case 406:
																																									goto IL_1e5e;
																																								case 482:
																																									goto IL_1e6c;
																																								case 241:
																																								case 440:
																																									goto IL_1e7a;
																																								case 345:
																																									goto IL_1eb7;
																																								case 375:
																																									goto IL_1ece;
																																								case 155:
																																									goto IL_1ee1;
																																								case 448:
																																									goto IL_1eef;
																																								case 430:
																																									goto IL_1efa;
																																								case 468:
																																									goto IL_1f08;
																																								case 181:
																																								case 503:
																																									goto IL_1f16;
																																								case 456:
																																									goto IL_1f41;
																																								case 199:
																																								case 268:
																																									goto IL_1f63;
																																								case 508:
																																									goto IL_1f6d;
																																								case 452:
																																									goto IL_1f7b;
																																								case 244:
																																									goto IL_1f8e;
																																								case 125:
																																									goto IL_1f99;
																																								case 248:
																																								case 426:
																																									goto IL_1fa7;
																																								case 450:
																																									goto IL_1ff4;
																																								case 240:
																																									goto IL_2002;
																																								case 64:
																																									goto IL_2015;
																																								case 388:
																																									goto IL_202c;
																																								case 400:
																																									goto IL_203f;
																																								case 25:
																																								case 242:
																																									goto IL_204a;
																																								case 309:
																																									goto IL_2072;
																																								case 335:
																																									goto IL_2080;
																																								case 355:
																																									goto IL_2093;
																																								case 518:
																																									goto IL_20a1;
																																								case 88:
																																									goto IL_20af;
																																								case 185:
																																								case 193:
																																									goto IL_20ba;
																																								case 203:
																																									goto IL_20c8;
																																								case 308:
																																									goto IL_20eb;
																																								case 150:
																																									goto IL_20f9;
																																								case 113:
																																									goto IL_210c;
																																								case 111:
																																									goto IL_211a;
																																								case 194:
																																								case 210:
																																									goto IL_2128;
																																								case 3:
																																									goto IL_213c;
																																								case 322:
																																									goto IL_218e;
																																								case 154:
																																									goto IL_219c;
																																								case 492:
																																									goto IL_21af;
																																								case 305:
																																									goto IL_21bd;
																																								case 1:
																																								case 497:
																																									goto IL_21cb;
																																								case 534:
																																									goto IL_21df;
																																								case 37:
																																									goto IL_2231;
																																								case 177:
																																									goto IL_223f;
																																								case 480:
																																									goto IL_2252;
																																								case 364:
																																									goto IL_2260;
																																								case 273:
																																								case 403:
																																									goto IL_226e;
																																								case 298:
																																									goto IL_227c;
																																								case 349:
																																									goto IL_229e;
																																								case 96:
																																									goto IL_22ac;
																																								case 517:
																																									goto IL_22bf;
																																								case 287:
																																									goto IL_22cd;
																																								case 10:
																																									goto IL_22db;
																																								case 358:
																																								case 463:
																																									goto IL_22e9;
																																								case 278:
																																									goto IL_22fd;
																																								case 560:
																																									goto IL_236c;
																																								case 65:
																																									goto IL_237f;
																																								case 69:
																																									goto IL_238d;
																																								case 24:
																																								case 330:
																																									goto IL_239b;
																																								case 365:
																																									goto IL_23af;
																																								case 485:
																																									goto IL_23ec;
																																								case 525:
																																									goto IL_23ff;
																																								case 392:
																																									goto IL_240d;
																																								case 46:
																																									goto IL_241b;
																																								case 87:
																																								case 505:
																																									goto IL_2429;
																																								case 208:
																																									goto IL_243d;
																																								case 385:
																																									goto IL_248e;
																																								case 476:
																																									goto IL_249c;
																																								case 82:
																																								case 191:
																																									goto IL_24b8;
																																								case 286:
																																									goto IL_24c6;
																																								case 229:
																																									goto IL_24df;
																																								case 558:
																																									goto IL_24fe;
																																								case 237:
																																									goto IL_250c;
																																								case 234:
																																									goto IL_2528;
																																								case 187:
																																								case 256:
																																									goto IL_2533;
																																								case 438:
																																									goto IL_2541;
																																								case 201:
																																									goto IL_2559;
																																								case 383:
																																									goto IL_2567;
																																								case 546:
																																									goto IL_257a;
																																								case 378:
																																									goto IL_2588;
																																								case 182:
																																									goto IL_2596;
																																								case 499:
																																									goto IL_25a1;
																																								case 481:
																																									goto IL_25af;
																																								case 232:
																																								case 420:
																																									goto IL_25bd;
																																								case 402:
																																									goto IL_25f6;
																																								case 29:
																																									goto IL_260a;
																																								case 15:
																																								case 214:
																																									goto IL_2626;
																																								case 533:
																																									goto IL_2644;
																																								case 33:
																																									goto IL_2652;
																																								case 6:
																																									goto IL_266e;
																																								case 23:
																																									goto IL_267c;
																																								case 21:
																																								case 564:
																																									goto IL_2693;
																																								case 119:
																																									goto IL_26b1;
																																								case 253:
																																									goto IL_26bf;
																																								case 336:
																																									goto IL_26cd;
																																								case 398:
																																									goto IL_26e9;
																																								case 16:
																																								case 507:
																																									goto IL_26f4;
																																								case 437:
																																									goto IL_2702;
																																								case 441:
																																									goto IL_2723;
																																								case 352:
																																									goto IL_2731;
																																								case 293:
																																									goto IL_2744;
																																								case 152:
																																									goto IL_2752;
																																								case 338:
																																								case 512:
																																									goto IL_275d;
																																								case 369:
																																									goto IL_277b;
																																								case 445:
																																									goto IL_2789;
																																								case 439:
																																									goto IL_279c;
																																								case 300:
																																									goto IL_27aa;
																																								case 192:
																																								case 367:
																																									goto IL_27b5;
																																								case 384:
																																									goto IL_27d3;
																																								case 169:
																																									goto IL_27e1;
																																								case 260:
																																									goto IL_27ef;
																																								case 101:
																																									goto IL_27ff;
																																								case 557:
																																									goto IL_280a;
																																								case 255:
																																								case 397:
																																									goto IL_2815;
																																								case 5:
																																								case 12:
																																								case 13:
																																								case 34:
																																								case 36:
																																								case 72:
																																								case 74:
																																								case 76:
																																								case 94:
																																								case 95:
																																								case 99:
																																								case 100:
																																								case 115:
																																								case 118:
																																								case 127:
																																								case 139:
																																								case 151:
																																								case 172:
																																								case 173:
																																								case 176:
																																								case 180:
																																								case 189:
																																								case 195:
																																								case 206:
																																								case 211:
																																								case 218:
																																								case 225:
																																								case 228:
																																								case 230:
																																								case 243:
																																								case 245:
																																								case 254:
																																								case 267:
																																								case 295:
																																								case 297:
																																								case 317:
																																								case 320:
																																								case 326:
																																								case 331:
																																								case 339:
																																								case 342:
																																								case 344:
																																								case 356:
																																								case 359:
																																								case 370:
																																								case 374:
																																								case 376:
																																								case 389:
																																								case 396:
																																								case 408:
																																								case 410:
																																								case 412:
																																								case 415:
																																								case 428:
																																								case 434:
																																								case 443:
																																								case 457:
																																								case 465:
																																								case 493:
																																								case 494:
																																								case 501:
																																								case 511:
																																								case 521:
																																								case 528:
																																								case 529:
																																								case 532:
																																								case 537:
																																								case 559:
																																								case 562:
																																								case 566:
																																									goto end_IL_0998;
																																								case 0:
																																								case 22:
																																								case 39:
																																								case 40:
																																								case 41:
																																								case 44:
																																								case 51:
																																								case 54:
																																								case 55:
																																								case 56:
																																								case 61:
																																								case 97:
																																								case 106:
																																								case 116:
																																								case 121:
																																								case 124:
																																								case 130:
																																								case 133:
																																								case 136:
																																								case 141:
																																								case 143:
																																								case 146:
																																								case 160:
																																								case 162:
																																								case 198:
																																								case 213:
																																								case 217:
																																								case 219:
																																								case 222:
																																								case 235:
																																								case 236:
																																								case 239:
																																								case 246:
																																								case 247:
																																								case 251:
																																								case 266:
																																								case 274:
																																								case 276:
																																								case 280:
																																								case 284:
																																								case 285:
																																								case 304:
																																								case 313:
																																								case 324:
																																								case 327:
																																								case 333:
																																								case 361:
																																								case 362:
																																								case 366:
																																								case 377:
																																								case 399:
																																								case 411:
																																								case 423:
																																								case 424:
																																								case 432:
																																								case 455:
																																								case 473:
																																								case 474:
																																								case 475:
																																								case 479:
																																								case 496:
																																								case 502:
																																								case 504:
																																								case 520:
																																								case 524:
																																								case 543:
																																								case 547:
																																								case 549:
																																								case 550:
																																								case 555:
																																									goto IL_283d;
																																								case 58:
																																									goto IL_2850;
																																								case 140:
																																									goto end_IL_0915;
																																								case 165:
																																									goto end_IL_285a;
																																								case 83:
																																									goto end_IL_2865;
																																								case 108:
																																									goto end_IL_287b;
																																								case 386:
																																									goto end_IL_2891;
																																								case 312:
																																									goto end_IL_28a7;
																																								case 75:
																																									goto end_IL_28bd;
																																								case 227:
																																									goto end_IL_28d3;
																																								case 142:
																																									goto end_IL_28ec;
																																								case 221:
																																									goto end_IL_28fc;
																																								case 257:
																																									goto end_IL_290c;
																																								case 89:
																																									goto end_IL_2925;
																																								case 84:
																																								case 179:
																																									goto end_IL_293e;
																																								case 31:
																																									goto end_IL_2957;
																																								case 32:
																																									goto end_IL_2967;
																																								case 334:
																																								case 541:
																																									return;
																																								}
																																								continue;
																																							}
																																							goto IL_1b9c;
																																							IL_1bcc:
																																							num5++;
																																							goto IL_1bda;
																																							IL_1bda:
																																							ptr2 += 8;
																																							goto IL_283d;
																																							IL_1b9c:
																																							array[num5] = 4;
																																							goto IL_1baa;
																																							IL_1baa:
																																							array2[num5] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																																							goto IL_1bcc;
																																							continue;
																																							end_IL_0915:
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_1bed;
																																					IL_1c09:
																																					((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).position = (Vector3)array2[num5 - 1];
																																					goto IL_1c68;
																																					IL_1c68:
																																					num5 -= 2;
																																					goto IL_283d;
																																					IL_1bed:
																																					if (56 < b)
																																					{
																																						goto end_IL_0998;
																																					}
																																					goto IL_1bfb;
																																					IL_1bfb:
																																					if (56 > b)
																																					{
																																						goto end_IL_0998;
																																					}
																																					goto IL_1c09;
																																				}
																																				break;
																																			}
																																			goto IL_1c7b;
																																			IL_1cf6:
																																			num5 -= 2;
																																			goto IL_283d;
																																			IL_1c7b:
																																			if (58 < b)
																																			{
																																				goto end_IL_0998;
																																			}
																																			goto IL_1c89;
																																			IL_1c89:
																																			if (58 > b)
																																			{
																																				goto end_IL_0998;
																																			}
																																			goto IL_1c97;
																																			IL_1c97:
																																			((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).rotation = (Quaternion)array2[num5 - 1];
																																			goto IL_1cf6;
																																		}
																																		break;
																																	}
																																	goto IL_0e23;
																																	IL_10f4:
																																	num5--;
																																	goto IL_283d;
																																	IL_0e23:
																																	if (55 > b)
																																	{
																																		goto IL_1047;
																																	}
																																	goto IL_145b;
																																	IL_145b:
																																	((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	num = 77;
																																	goto IL_14c4;
																																	IL_14c4:
																																	num5 -= 2;
																																	goto IL_283d;
																																	IL_1047:
																																	if (53 >= b)
																																	{
																																		goto IL_1052;
																																	}
																																	goto IL_108c;
																																	IL_1052:
																																	if (53 <= b)
																																	{
																																		goto IL_1060;
																																	}
																																	goto IL_1681;
																																	IL_1060:
																																	array[num5] = 13;
																																	goto IL_106e;
																																	IL_106e:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																																	goto IL_14d7;
																																	IL_14d7:
																																	array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																																	goto IL_14f6;
																																	IL_14f6:
																																	num5++;
																																	goto IL_1504;
																																	IL_1504:
																																	ptr2 += 16;
																																	goto IL_283d;
																																	IL_1681:
																																	if (52 < b)
																																	{
																																		goto end_IL_0998;
																																	}
																																	goto IL_168f;
																																	IL_168f:
																																	if (52 > b)
																																	{
																																		goto end_IL_0998;
																																	}
																																	goto IL_169d;
																																	IL_169d:
																																	array[num5] = 5;
																																	goto IL_16ab;
																																	IL_16ab:
																																	array2[num5] = array6[*(int*)(ptr2 + num3)];
																																	goto IL_16c3;
																																	IL_16c3:
																																	num5++;
																																	goto IL_16d1;
																																	IL_16d1:
																																	ptr2 += 8;
																																	goto IL_283d;
																																	IL_108c:
																																	if (54 < b)
																																	{
																																		goto end_IL_0998;
																																	}
																																	goto IL_109a;
																																	IL_109a:
																																	if (54 > b)
																																	{
																																		goto end_IL_0998;
																																	}
																																	goto IL_10a8;
																																	IL_10a8:
																																	((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4) = default(GameEntityCreateData);
																																	goto IL_10f4;
																																}
																																break;
																															}
																															goto IL_0f79;
																															IL_1583:
																															array[num5 - 1] = 1;
																															goto IL_283d;
																															IL_0f79:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																															goto IL_1583;
																														}
																														break;
																													}
																													goto IL_1d09;
																													IL_202c:
																													if (67 > b)
																													{
																													}
																													goto end_IL_0998;
																													IL_1d09:
																													if (63 >= b)
																													{
																														goto IL_1d17;
																													}
																													goto IL_1ee1;
																													IL_1d17:
																													if (63 <= b)
																													{
																														goto IL_1d22;
																													}
																													goto IL_1d65;
																													IL_1d22:
																													*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
																													goto IL_1d4c;
																													IL_1d4c:
																													array[num5 - 1] = 2;
																													goto IL_283d;
																													IL_1d65:
																													if (61 >= b)
																													{
																														goto IL_1d73;
																													}
																													goto IL_1e5e;
																													IL_1d73:
																													if (61 <= b)
																													{
																														goto IL_1d7e;
																													}
																													goto IL_1dcf;
																													IL_1d7e:
																													array[num5] = 4;
																													goto IL_1d8c;
																													IL_1d8c:
																													array2[num5] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																													goto IL_1dae;
																													IL_1dae:
																													num5++;
																													goto IL_1dbc;
																													IL_1dbc:
																													ptr2 += 8;
																													goto IL_283d;
																													IL_1dcf:
																													if (60 < b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1ddd;
																													IL_1ddd:
																													if (60 > b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1deb;
																													IL_1deb:
																													((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_1e4b;
																													IL_1e4b:
																													num5 -= 2;
																													goto IL_283d;
																													IL_1e5e:
																													if (62 < b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1e6c;
																													IL_1e6c:
																													if (62 > b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1e7a;
																													IL_1e7a:
																													((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 2], (GameEntityCreateData)array2[num5 - 1]);
																													goto IL_1eb7;
																													IL_1eb7:
																													num5 -= 2;
																													num = 375;
																													goto IL_1ece;
																													IL_1ece:
																													ptr2 += 8;
																													goto IL_283d;
																													IL_1ee1:
																													if (65 >= b)
																													{
																														goto IL_1eef;
																													}
																													goto IL_1f8e;
																													IL_1eef:
																													if (65 > b)
																													{
																														goto IL_1efa;
																													}
																													goto IL_1f63;
																													IL_1efa:
																													if (64 < b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1f08;
																													IL_1f08:
																													if (64 > b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1f16;
																													IL_1f16:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																													goto IL_1f41;
																													IL_1f41:
																													array[num5 - 1] = 0;
																													num = 251;
																													goto IL_283d;
																													IL_1f63:
																													array2[num5] = null;
																													goto IL_1f6d;
																													IL_1f6d:
																													array[num5] = 5;
																													goto IL_1f7b;
																													IL_1f7b:
																													num5++;
																													goto IL_283d;
																													IL_1f8e:
																													if (66 >= b)
																													{
																														goto IL_1f99;
																													}
																													goto IL_2015;
																													IL_1f99:
																													if (66 > b)
																													{
																														goto end_IL_0998;
																													}
																													goto IL_1fa7;
																													IL_1fa7:
																													((delegate*<List<GameEntityCreateData>, Player, bool, void>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 3], (Player)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0);
																													goto IL_1ff4;
																													IL_1ff4:
																													num5 -= 3;
																													goto IL_2002;
																													IL_2002:
																													ptr2 += 8;
																													goto IL_283d;
																													IL_2015:
																													if (67 < b)
																													{
																														goto end_IL_0998;
																													}
																													num = 388;
																													goto IL_202c;
																												}
																												break;
																											}
																											goto IL_203f;
																											IL_27d3:
																											array[num5] = 5;
																											goto IL_27e1;
																											IL_203f:
																											if (51 <= b)
																											{
																												goto IL_204a;
																											}
																											goto IL_2093;
																											IL_204a:
																											array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num5 - 1];
																											goto IL_2072;
																											IL_2072:
																											ptr2 += 8;
																											goto IL_2080;
																											IL_2080:
																											num5--;
																											goto IL_283d;
																											IL_2093:
																											if (42 < b)
																											{
																												goto IL_20a1;
																											}
																											num = 234;
																											goto IL_2528;
																											IL_20a1:
																											if (46 >= b)
																											{
																												goto IL_20af;
																											}
																											goto IL_22bf;
																											IL_20af:
																											if (46 <= b)
																											{
																												goto IL_20ba;
																											}
																											goto IL_210c;
																											IL_20ba:
																											array[num5] = 4;
																											goto IL_20c8;
																											IL_20c8:
																											array2[num5] = ((delegate*<Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																											goto IL_20eb;
																											IL_20eb:
																											num5++;
																											goto IL_20f9;
																											IL_20f9:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_210c:
																											if (44 >= b)
																											{
																												goto IL_211a;
																											}
																											goto IL_2252;
																											IL_211a:
																											if (44 <= b)
																											{
																												goto IL_2128;
																											}
																											goto IL_21af;
																											IL_2128:
																											array[num5 - 2] = 0;
																											goto IL_213c;
																											IL_213c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]);
																											goto IL_218e;
																											IL_218e:
																											num5--;
																											goto IL_219c;
																											IL_219c:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_21af:
																											if (43 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_21bd;
																											IL_21bd:
																											if (43 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_21cb;
																											IL_21cb:
																											array[num5 - 2] = 0;
																											goto IL_21df;
																											IL_21df:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]) ? 1 : 0);
																											goto IL_2231;
																											IL_2231:
																											num5--;
																											goto IL_223f;
																											IL_223f:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_2252:
																											if (45 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_2260;
																											IL_2260:
																											if (45 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_226e;
																											IL_226e:
																											array[num5] = 4;
																											goto IL_227c;
																											IL_227c:
																											array2[num5] = (Vector3)array6[*(int*)(ptr2 + num3)];
																											goto IL_229e;
																											IL_229e:
																											num5++;
																											goto IL_22ac;
																											IL_22ac:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_22bf:
																											if (48 < b)
																											{
																												goto IL_22cd;
																											}
																											goto IL_23ff;
																											IL_22cd:
																											if (49 >= b)
																											{
																												goto IL_22db;
																											}
																											goto IL_237f;
																											IL_22db:
																											if (49 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_22e9;
																											IL_22e9:
																											array[num5 - 1] = 4;
																											goto IL_22fd;
																											IL_22fd:
																											array2[num5 - 1] = ((delegate*<ref Vector3, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)HashElementEntryFieldIdsetApplicationUrl[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4));
																											goto IL_236c;
																											IL_236c:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_237f:
																											if (50 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_238d;
																											IL_238d:
																											if (50 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_239b;
																											IL_239b:
																											array[num5 - 1] = 4;
																											goto IL_23af;
																											IL_23af:
																											array2[num5 - 1] = ((delegate*<Vector3, Quaternion>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																											goto IL_23ec;
																											IL_23ec:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_23ff:
																											if (48 > b)
																											{
																												goto IL_240d;
																											}
																											num = 82;
																											goto IL_24b8;
																											IL_240d:
																											if (47 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_241b;
																											IL_241b:
																											if (47 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_2429;
																											IL_2429:
																											array[num5 - 2] = 4;
																											goto IL_243d;
																											IL_243d:
																											array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																											goto IL_248e;
																											IL_248e:
																											num5--;
																											goto IL_249c;
																											IL_249c:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_27ef:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_24b8:
																											array[num5] = 13;
																											goto IL_24c6;
																											IL_24c6:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																											goto IL_24df;
																											IL_24df:
																											array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																											goto IL_24fe;
																											IL_24fe:
																											num5++;
																											goto IL_250c;
																											IL_250c:
																											ptr2 += 16;
																											goto IL_283d;
																											IL_27e1:
																											num5++;
																											goto IL_27ef;
																											IL_2528:
																											if (42 <= b)
																											{
																												goto IL_2533;
																											}
																											goto IL_257a;
																											IL_2533:
																											array[num5] = 5;
																											goto IL_2541;
																											IL_2541:
																											array2[num5] = array6[*(int*)(ptr2 + num3)];
																											goto IL_2559;
																											IL_2559:
																											num5++;
																											goto IL_2567;
																											IL_2567:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_257a:
																											if (38 < b)
																											{
																												goto IL_2588;
																											}
																											num = 398;
																											goto IL_26e9;
																											IL_2588:
																											if (40 >= b)
																											{
																												goto IL_2596;
																											}
																											goto IL_266e;
																											IL_2596:
																											if (40 > b)
																											{
																												goto IL_25a1;
																											}
																											num = 214;
																											goto IL_2626;
																											IL_25a1:
																											if (39 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_25af;
																											IL_25af:
																											if (39 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_25bd;
																											IL_25bd:
																											array2[num5 - 2] = ((string[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																											goto IL_25f6;
																											IL_25f6:
																											array[num5 - 2] = 5;
																											goto IL_260a;
																											IL_260a:
																											num5--;
																											goto IL_283d;
																											IL_280a:
																											if (37 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_2815;
																											IL_2626:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_2644;
																											IL_2644:
																											ptr2 += 8;
																											goto IL_2652;
																											IL_2652:
																											num5--;
																											num = 543;
																											goto IL_283d;
																											IL_266e:
																											if (41 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_267c;
																											IL_267c:
																											if (41 > b)
																											{
																												goto end_IL_0998;
																											}
																											num = 21;
																											goto IL_2693;
																											IL_2815:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_283d;
																											IL_2693:
																											array2[num5] = ((delegate*<Dictionary<string, int>>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																											goto IL_26b1;
																											IL_26b1:
																											array[num5] = 5;
																											goto IL_26bf;
																											IL_26bf:
																											num5++;
																											goto IL_26cd;
																											IL_26cd:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_27ff:
																											if (37 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_280a;
																											IL_26e9:
																											if (38 <= b)
																											{
																												goto IL_26f4;
																											}
																											goto IL_2744;
																											IL_26f4:
																											array[num5] = 5;
																											goto IL_2702;
																											IL_2702:
																											array2[num5] = array6[*(int*)(ptr2 + num3)];
																											num = 441;
																											goto IL_2723;
																											IL_2723:
																											num5++;
																											goto IL_2731;
																											IL_2731:
																											ptr2 += 8;
																											goto IL_283d;
																											IL_2744:
																											if (36 >= b)
																											{
																												goto IL_2752;
																											}
																											goto IL_27ff;
																											IL_2752:
																											if (36 <= b)
																											{
																												goto IL_275d;
																											}
																											goto IL_279c;
																											IL_275d:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_277b;
																											IL_277b:
																											ptr2 += 8;
																											goto IL_2789;
																											IL_2789:
																											num5--;
																											goto IL_283d;
																											IL_279c:
																											if (35 < b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_27aa;
																											IL_27aa:
																											if (35 > b)
																											{
																												goto end_IL_0998;
																											}
																											goto IL_27b5;
																											IL_27b5:
																											array2[num5] = ((delegate*<string[]>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																											goto IL_27d3;
																										}
																										break;
																									}
																									goto IL_09d3;
																									IL_1411:
																									if (20 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_141f;
																									IL_09d3:
																									if (34 <= b)
																									{
																										goto IL_09de;
																									}
																									goto IL_0a0a;
																									IL_09de:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									num = 526;
																									goto IL_15f7;
																									IL_15f7:
																									ptr2 += 8;
																									goto IL_1605;
																									IL_1605:
																									num5--;
																									goto IL_283d;
																									IL_0a0a:
																									if (17 >= b)
																									{
																										goto IL_0a18;
																									}
																									goto IL_0a99;
																									IL_0a18:
																									if (17 <= b)
																									{
																										goto IL_0a23;
																									}
																									goto IL_0a86;
																									IL_0a23:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0c32;
																									IL_0c32:
																									num5--;
																									goto IL_283d;
																									IL_0a86:
																									if (8 < b)
																									{
																										goto IL_0b73;
																									}
																									goto IL_0c45;
																									IL_0c45:
																									if (8 > b)
																									{
																										goto IL_1107;
																									}
																									goto IL_1a2d;
																									IL_1107:
																									if (4 >= b)
																									{
																										goto IL_1115;
																									}
																									goto IL_1208;
																									IL_1115:
																									if (4 <= b)
																									{
																										goto IL_1120;
																									}
																									goto IL_117c;
																									IL_1120:
																									array[num5] = 0;
																									goto IL_112e;
																									IL_112e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																									goto IL_1151;
																									IL_1151:
																									array2[num5] = null;
																									goto IL_115b;
																									IL_115b:
																									num5++;
																									goto IL_1169;
																									IL_1169:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_117c:
																									if (2 >= b)
																									{
																										goto IL_118a;
																									}
																									goto IL_1ab8;
																									IL_118a:
																									if (2 <= b)
																									{
																										goto IL_1198;
																									}
																									goto IL_1905;
																									IL_1198:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_11d8;
																									IL_11d8:
																									array[num5 - 2] = 0;
																									num = 477;
																									goto IL_11f5;
																									IL_11f5:
																									num5--;
																									goto IL_283d;
																									IL_1905:
																									if (1 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1913;
																									IL_1913:
																									if (1 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1921;
																									IL_1921:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_193a;
																									IL_193a:
																									array[num5] = 0;
																									goto IL_1948;
																									IL_1948:
																									num5++;
																									goto IL_1956;
																									IL_1956:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_1ab8:
																									if (3 < b)
																									{
																										goto end_IL_0998;
																									}
																									num = 78;
																									goto IL_1acf;
																									IL_141f:
																									if (20 > b)
																									{
																										goto end_IL_0998;
																									}
																									num = 80;
																									goto IL_1436;
																									IL_1acf:
																									if (3 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1add;
																									IL_1add:
																									ref int reference = ref array4[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1b06;
																									IL_1b06:
																									ptr2 += 8;
																									goto IL_1b14;
																									IL_1b14:
																									num5--;
																									goto IL_283d;
																									IL_1208:
																									if (6 < b)
																									{
																										goto IL_1216;
																									}
																									goto IL_1299;
																									IL_1216:
																									if (7 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1224;
																									IL_1224:
																									if (7 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1232;
																									IL_1232:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1272;
																									IL_1272:
																									array[num5 - 2] = 0;
																									goto IL_1286;
																									IL_1286:
																									num5--;
																									goto IL_283d;
																									IL_1299:
																									if (6 <= b)
																									{
																										goto IL_12a4;
																									}
																									goto IL_12fd;
																									IL_12a4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_12e4;
																									IL_12e4:
																									array[num5 - 2] = 0;
																									goto IL_1a1a;
																									IL_1a1a:
																									num5--;
																									goto IL_283d;
																									IL_12fd:
																									if (5 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_130b;
																									IL_130b:
																									if (5 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1319;
																									IL_1319:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1359;
																									IL_1359:
																									array[num5 - 2] = 0;
																									num = 542;
																									goto IL_1841;
																									IL_1841:
																									num5--;
																									goto IL_283d;
																									IL_1a2d:
																									num5--;
																									num = 455;
																									goto IL_283d;
																									IL_0b73:
																									if (12 >= b)
																									{
																										num = 350;
																										goto IL_0b87;
																									}
																									goto IL_0bb3;
																									IL_1a07:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0b87:
																									if (12 <= b)
																									{
																										num = 324;
																										goto IL_283d;
																									}
																									goto IL_0b92;
																									IL_0b92:
																									if (10 >= b)
																									{
																										goto IL_0c58;
																									}
																									goto IL_0d3a;
																									IL_0c58:
																									if (10 > b)
																									{
																										goto IL_17cc;
																									}
																									goto IL_1b27;
																									IL_1b27:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1b89;
																									IL_1b89:
																									num5 -= 2;
																									goto IL_283d;
																									IL_17cc:
																									if (9 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_17da;
																									IL_17da:
																									if (9 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_17e8;
																									IL_17e8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1828;
																									IL_1828:
																									array[num5 - 2] = 0;
																									goto IL_18f2;
																									IL_18f2:
																									num5--;
																									goto IL_283d;
																									IL_0d3a:
																									if (11 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0d48;
																									IL_0d48:
																									if (11 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1766;
																									IL_1766:
																									array[num5 - 1] = 0;
																									goto IL_177a;
																									IL_177a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = ((delegate*<int, int>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																									goto IL_17b9;
																									IL_17b9:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_1436:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									num = 247;
																									goto IL_283d;
																									IL_0bb3:
																									if (14 >= b)
																									{
																										goto IL_0bbe;
																									}
																									goto IL_0bd1;
																									IL_0bbe:
																									if (14 <= b)
																									{
																										goto IL_0fa9;
																									}
																									goto IL_16f7;
																									IL_0fa9:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0ffb;
																									IL_0ffb:
																									num5--;
																									goto IL_283d;
																									IL_16f7:
																									if (13 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1705;
																									IL_1705:
																									if (13 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1713;
																									IL_1713:
																									array[num5] = 0;
																									goto IL_1721;
																									IL_1721:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_1745;
																									IL_1745:
																									num5++;
																									goto IL_1753;
																									IL_1753:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0bd1:
																									if (15 >= b)
																									{
																										goto IL_0bdf;
																									}
																									goto IL_1a49;
																									IL_0bdf:
																									if (15 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0bed;
																									IL_0bed:
																									array[num5] = 0;
																									goto IL_0bfb;
																									IL_0bfb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_0c1f;
																									IL_0c1f:
																									num5++;
																									goto IL_1034;
																									IL_1034:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_1a49:
																									if (16 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1a57;
																									IL_1a57:
																									if (16 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1a65;
																									IL_1a65:
																									array[num5] = 0;
																									goto IL_1a73;
																									IL_1a73:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_1a97;
																									IL_1a97:
																									num5++;
																									goto IL_1aa5;
																									IL_1aa5:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0a99:
																									if (25 < b)
																									{
																										goto IL_0aa7;
																									}
																									goto IL_0e78;
																									IL_0aa7:
																									if (29 < b)
																									{
																										goto IL_0ab5;
																									}
																									goto IL_0b38;
																									IL_0ab5:
																									if (31 < b)
																									{
																										goto IL_0ac3;
																									}
																									goto IL_0d5b;
																									IL_0ac3:
																									if (32 >= b)
																									{
																										goto IL_0ace;
																									}
																									goto IL_0b25;
																									IL_0ace:
																									if (32 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0adc;
																									IL_0adc:
																									array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num5 - 1];
																									goto IL_0b04;
																									IL_0b04:
																									ptr2 += 8;
																									goto IL_0b12;
																									IL_0b12:
																									num5--;
																									goto IL_283d;
																									IL_0b25:
																									if (33 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_159c;
																									IL_159c:
																									if (33 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_15aa;
																									IL_15aa:
																									array[num5] = 5;
																									goto IL_15b8;
																									IL_15b8:
																									array2[num5] = ((delegate*<List<GameEntityCreateData>>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																									goto IL_15d6;
																									IL_15d6:
																									num5++;
																									goto IL_15e4;
																									IL_15e4:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0d5b:
																									if (31 <= b)
																									{
																										goto IL_0d69;
																									}
																									goto IL_0def;
																									IL_0d69:
																									array[num5 - 2] = 4;
																									goto IL_0d7d;
																									IL_0d7d:
																									array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																									goto IL_0dce;
																									IL_0dce:
																									num5--;
																									goto IL_0ddc;
																									IL_0ddc:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0def:
																									if (30 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1854;
																									IL_1854:
																									if (30 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1862;
																									IL_1862:
																									array[num5 - 2] = 4;
																									goto IL_1876;
																									IL_1876:
																									array2[num5 - 2] = ((delegate*<Vector3, float, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																									num = 296;
																									goto IL_18d1;
																									IL_18d1:
																									num5--;
																									goto IL_18df;
																									IL_18df:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0b38:
																									if (29 <= b)
																									{
																										goto IL_0b46;
																									}
																									goto IL_0c6b;
																									IL_0b46:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																									goto IL_0b60;
																									IL_0b60:
																									array[num5] = 3;
																									goto IL_0e02;
																									IL_0e02:
																									num5++;
																									goto IL_0e10;
																									IL_0e10:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0c6b:
																									if (27 < b)
																									{
																										goto IL_0c76;
																									}
																									num = 188;
																									goto IL_0cb4;
																									IL_0c76:
																									if (28 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0c84;
																									IL_0c84:
																									if (28 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0c92;
																									IL_0c92:
																									array[num5 - 1] = 4;
																									goto IL_0e36;
																									IL_0e36:
																									array2[num5 - 1] = ((delegate*<Transform, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																									goto IL_1021;
																									IL_1021:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_19b6:
																									array[num5 - 1] = 4;
																									goto IL_19ca;
																									IL_0cb4:
																									if (27 > b)
																									{
																										goto IL_0cbf;
																									}
																									goto IL_0cdb;
																									IL_0cbf:
																									if (26 < b)
																									{
																										goto end_IL_0998;
																									}
																									num = 535;
																									goto IL_16e4;
																									IL_19ca:
																									array2[num5 - 1] = ((delegate*<Transform, Vector3>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																									goto IL_1a07;
																									IL_16e4:
																									if (26 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1969;
																									IL_1969:
																									array[num5] = 5;
																									goto IL_1977;
																									IL_1977:
																									array2[num5] = ((delegate*<GTPlayer>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																									goto IL_1995;
																									IL_1995:
																									num5++;
																									goto IL_19a3;
																									IL_19a3:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0cdb:
																									array[num5 - 1] = 5;
																									goto IL_0cef;
																									IL_0cef:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																									goto IL_0d27;
																									IL_0d27:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0e78:
																									if (25 > b)
																									{
																										goto IL_0e86;
																									}
																									goto IL_19b6;
																									IL_0e86:
																									if (21 < b)
																									{
																										goto IL_0e94;
																									}
																									goto IL_137b;
																									IL_0e94:
																									if (23 >= b)
																									{
																										goto IL_0e9f;
																									}
																									goto IL_0f0c;
																									IL_0e9f:
																									if (23 <= b)
																									{
																										goto IL_0ead;
																									}
																									goto IL_1618;
																									IL_0ead:
																									array2[num5 - 1] = ((delegate*<GTPlayer, SphereCollider>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																									goto IL_0ee5;
																									IL_0ee5:
																									array[num5 - 1] = 5;
																									goto IL_0ef9;
																									IL_0ef9:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_1618:
																									if (22 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1626;
																									IL_1626:
																									if (22 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1634;
																									IL_1634:
																									array[num5] = 5;
																									goto IL_1642;
																									IL_1642:
																									array2[num5] = ((delegate*<GTPlayer>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																									goto IL_1660;
																									IL_1660:
																									num5++;
																									goto IL_166e;
																									IL_166e:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_0f0c:
																									if (24 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0f1a;
																									IL_0f1a:
																									if (24 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_0f28;
																									IL_0f28:
																									array[num5 - 1] = 5;
																									goto IL_0f3c;
																									IL_0f3c:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																									goto IL_100e;
																									IL_100e:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_137b:
																									if (21 <= b)
																									{
																										goto IL_1386;
																									}
																									goto IL_13ae;
																									IL_1386:
																									((delegate*<void>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])();
																									goto IL_139b;
																									IL_139b:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_13ae:
																									if (19 >= b)
																									{
																										goto IL_13b9;
																									}
																									goto IL_1411;
																									IL_13b9:
																									if (19 <= b)
																									{
																										goto IL_13c7;
																									}
																									goto IL_1517;
																									IL_13c7:
																									((delegate*<UnityEngine.Object, void>)HashElementEntryFieldIdsetApplicationUrl[*(int*)(ptr2 + num3)])((Class115)array2[num5 - 1]);
																									goto IL_13f0;
																									IL_13f0:
																									num5--;
																									goto IL_13fe;
																									IL_13fe:
																									ptr2 += 8;
																									goto IL_283d;
																									IL_1517:
																									if (18 < b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1525;
																									IL_1525:
																									if (18 > b)
																									{
																										goto end_IL_0998;
																									}
																									goto IL_1533;
																									IL_1533:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_154b;
																									IL_154b:
																									array[num5] = 5;
																									goto IL_1559;
																									IL_1559:
																									num5++;
																									goto IL_1567;
																									IL_1567:
																									ptr2 += 8;
																									num = 160;
																									goto IL_283d;
																								}
																								goto end_IL_09a8;
																								continue;
																								end_IL_0998:
																								break;
																								IL_0998:;
																							}
																						}
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_283d;
																						continue;
																						end_IL_09a8:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																	end_IL_285a:
																	break;
																}
																continue;
																end_IL_2865:
																break;
															}
															continue;
															end_IL_287b:
															break;
														}
														continue;
														end_IL_2891:
														break;
													}
													continue;
													end_IL_28a7:
													break;
												}
												continue;
												end_IL_28bd:
												break;
											}
											continue;
											end_IL_28d3:
											break;
										}
										continue;
										end_IL_28ec:
										break;
									}
									continue;
									end_IL_28fc:
									break;
								}
								continue;
								end_IL_290c:
								break;
							}
							continue;
							end_IL_2925:
							break;
						}
						continue;
						end_IL_293e:
						break;
					}
					continue;
					end_IL_2957:
					break;
				}
				continue;
				end_IL_2967:
				break;
			}
		}
	}

	public Class115()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnableJITcompileOptimizerAttributeString.getWriteTimeoutNS);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0290:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0273:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0263:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0253:
																							if (8 <= b)
																							{
																								while (true)
																								{
																									IL_01e6:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 113;
																									while (true)
																									{
																										if (num != 113)
																										{
																											if (num != 1094)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 8:
																											case 16:
																												goto IL_01e6;
																											case 17:
																												goto IL_0253;
																											case 101:
																												goto IL_0263;
																											case 60:
																												goto IL_0273;
																											case 91:
																												goto IL_0280;
																											case 29:
																												goto IL_0290;
																											case 84:
																												goto end_IL_0290;
																											case 20:
																											case 78:
																												goto end_IL_02a0;
																											case 19:
																												goto IL_02bb;
																											case 11:
																											case 30:
																												goto IL_02c9;
																											case 22:
																												goto IL_02e0;
																											case 46:
																												goto IL_0303;
																											case 41:
																											case 82:
																												goto IL_0312;
																											case 49:
																											case 68:
																												goto IL_031d;
																											case 74:
																												goto IL_032b;
																											case 31:
																												goto IL_033e;
																											case 14:
																											case 48:
																												goto IL_0357;
																											case 85:
																											case 87:
																												goto IL_0373;
																											case 7:
																											case 79:
																												goto IL_0381;
																											case 77:
																												goto IL_038f;
																											case 25:
																											case 66:
																												goto IL_039d;
																											case 21:
																											case 93:
																												goto IL_03c5;
																											case 55:
																											case 90:
																												goto IL_03d0;
																											case 69:
																												goto IL_03db;
																											case 34:
																											case 57:
																												goto IL_03e9;
																											case 24:
																												goto IL_0401;
																											case 88:
																												goto IL_040f;
																											case 9:
																												goto IL_0422;
																											case 35:
																											case 76:
																												goto IL_0439;
																											case 54:
																												goto IL_0462;
																											case 72:
																												goto IL_0470;
																											case 97:
																												goto IL_0483;
																											case 38:
																											case 71:
																												goto IL_0491;
																											case 18:
																												goto IL_04d1;
																											case 51:
																												goto IL_04e5;
																											case 100:
																												goto IL_04f8;
																											case 64:
																												goto IL_0506;
																											case 102:
																												goto IL_0516;
																											case 37:
																												goto IL_0524;
																											case 44:
																												goto IL_0532;
																											case 36:
																											case 103:
																												goto IL_0545;
																											case 92:
																												goto IL_055e;
																											case 67:
																												goto IL_056c;
																											case 45:
																												goto IL_057a;
																											case 105:
																												goto IL_0593;
																											case 43:
																												goto IL_05a1;
																											case 0:
																											case 1:
																											case 6:
																											case 13:
																											case 23:
																											case 26:
																											case 28:
																											case 33:
																											case 42:
																											case 47:
																											case 58:
																											case 59:
																											case 61:
																											case 70:
																											case 89:
																											case 94:
																											case 95:
																											case 96:
																											case 99:
																											case 106:
																												goto end_IL_01d3;
																											case 2:
																											case 3:
																											case 4:
																											case 5:
																											case 10:
																											case 12:
																											case 15:
																											case 39:
																											case 40:
																											case 52:
																											case 53:
																											case 73:
																											case 75:
																												goto end_IL_02b0;
																											case 104:
																												goto end_IL_05d4;
																											case 50:
																												goto end_IL_05e7;
																											case 80:
																												goto end_IL_05f1;
																											case 86:
																												goto end_IL_05fc;
																											case 56:
																											case 98:
																												goto end_IL_0611;
																											case 32:
																												goto end_IL_0621;
																											case 65:
																											case 81:
																												goto end_IL_0631;
																											case 62:
																												goto end_IL_0641;
																											case 63:
																												goto end_IL_0651;
																											case 27:
																											case 83:
																												goto IL_066c;
																											}
																											continue;
																										}
																										num5 -= 2;
																										goto end_IL_02b0;
																										continue;
																										end_IL_01d3:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0373;
																							IL_04e5:
																							num5--;
																							goto end_IL_02b0;
																							IL_0373:
																							if (6 < b)
																							{
																								goto IL_0381;
																							}
																							goto IL_0483;
																							IL_0381:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_038f;
																							IL_038f:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_039d;
																							IL_039d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0516;
																							IL_0516:
																							array[num5] = 0;
																							goto IL_0524;
																							IL_0524:
																							num5++;
																							goto IL_0532;
																							IL_0532:
																							ptr2 += 8;
																							goto end_IL_02b0;
																							IL_0483:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0491;
																							IL_0491:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04d1;
																							IL_04d1:
																							array[num5 - 2] = 0;
																							goto IL_04e5;
																						}
																						break;
																					}
																					goto IL_0312;
																					IL_0357:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02b0;
																					IL_0312:
																					if (9 < b)
																					{
																						goto IL_031d;
																					}
																					goto IL_033e;
																					IL_031d:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_032b;
																					IL_032b:
																					if (10 <= b)
																					{
																					}
																					break;
																					IL_033e:
																					if (9 > b)
																					{
																						num = 13;
																						break;
																					}
																					goto IL_0357;
																				}
																				break;
																			}
																			goto IL_02bb;
																			IL_056c:
																			num5++;
																			goto IL_057a;
																			IL_02bb:
																			if (5 <= b)
																			{
																				goto IL_02c9;
																			}
																			goto IL_03c5;
																			IL_02c9:
																			array[num5] = 0;
																			num = 22;
																			goto IL_02e0;
																			IL_02e0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0303;
																			IL_0303:
																			array2[num5] = null;
																			goto IL_0593;
																			IL_0593:
																			num5++;
																			goto IL_05a1;
																			IL_05a1:
																			ptr2 += 8;
																			goto end_IL_02b0;
																			IL_03c5:
																			if (2 < b)
																			{
																				goto IL_03d0;
																			}
																			goto IL_0422;
																			IL_03d0:
																			if (3 >= b)
																			{
																				goto IL_03db;
																			}
																			goto IL_0401;
																			IL_03db:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_03e9;
																			IL_03e9:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02b0;
																			IL_0401:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_040f;
																			IL_040f:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02b0;
																			IL_0422:
																			if (2 <= b)
																			{
																				num = 35;
																				goto IL_0439;
																			}
																			goto IL_04f8;
																			IL_057a:
																			ptr2 += 8;
																			num = 15;
																			goto end_IL_02b0;
																			IL_0439:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0462;
																			IL_0462:
																			ptr2 += 8;
																			goto IL_0470;
																			IL_0470:
																			num5--;
																			goto end_IL_02b0;
																			IL_04f8:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0506;
																			IL_0506:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0545;
																			IL_0545:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_055e;
																			IL_055e:
																			array[num5] = 0;
																			goto IL_056c;
																		}
																		break;
																		IL_0280:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02b0;
																continue;
																end_IL_0290:
																break;
															}
															continue;
															end_IL_02a0:
															break;
														}
														continue;
														end_IL_02b0:
														break;
													}
													continue;
												}
												goto IL_066c;
												IL_066c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d4:
												break;
											}
											continue;
											end_IL_05e7:
											break;
										}
										continue;
										end_IL_05f1:
										break;
									}
									continue;
									end_IL_05fc:
									break;
								}
								continue;
								end_IL_0611:
								break;
							}
							continue;
							end_IL_0621:
							break;
						}
						continue;
						end_IL_0631:
						break;
					}
					continue;
					end_IL_0641:
					break;
				}
				continue;
				end_IL_0651:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3)
	{
		int num = 102;
		byte[] array = default(byte[]);
		int num4 = default(int);
		long[] array2 = default(long[]);
		byte* ptr = default(byte*);
		object[] array3 = default(object[]);
		int[] array4 = default(int[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 115;
				while (true)
				{
					num = 134;
					while (true)
					{
						if (num != 134)
						{
							if (num != 1115)
							{
								goto IL_0447;
							}
							switch (num)
							{
							case 115:
								goto end_IL_0227;
							case 101:
								goto end_IL_0237;
							case 102:
								goto end_IL_0242;
							case 40:
								goto IL_0274;
							case 104:
							case 122:
								goto IL_0282;
							case 49:
								goto IL_0290;
							case 111:
								goto IL_029e;
							case 26:
								goto IL_02b1;
							case 65:
								goto IL_02ba;
							case 5:
							case 6:
							case 7:
							case 9:
							case 41:
							case 50:
							case 54:
							case 55:
							case 70:
							case 78:
							case 79:
							case 105:
							case 106:
							case 108:
							case 113:
							case 114:
								goto IL_02c2;
							case 95:
								goto IL_02d2;
							case 16:
								goto IL_02db;
							case 83:
								goto IL_02e4;
							case 97:
								goto IL_02fb;
							case 22:
								goto IL_0309;
							case 90:
								goto IL_0317;
							case 80:
								goto IL_0325;
							case 3:
							case 100:
								goto IL_0333;
							case 68:
								goto IL_0341;
							case 31:
							case 87:
								goto IL_034f;
							case 18:
								goto IL_035a;
							case 46:
							case 84:
								goto IL_0368;
							case 8:
								goto IL_0381;
							case 25:
								goto IL_038f;
							case 62:
								goto IL_039d;
							case 75:
								goto IL_03b0;
							case 63:
								goto IL_03be;
							case 42:
							case 119:
								goto IL_03cc;
							case 0:
								goto IL_03f5;
							case 66:
								goto IL_0403;
							case 47:
							case 96:
								goto IL_0416;
							case 57:
								goto IL_042e;
							case 74:
								goto IL_043c;
							case 52:
							case 109:
								goto IL_0447;
							case 53:
								goto IL_0455;
							case 20:
							case 88:
								goto IL_0468;
							case 99:
								goto IL_0476;
							case 125:
								goto IL_0499;
							case 116:
								goto IL_04a3;
							case 60:
								goto IL_04b1;
							case 13:
								goto IL_04c4;
							case 112:
								goto IL_04d2;
							case 34:
							case 43:
								goto IL_04e0;
							case 24:
								goto IL_0520;
							case 33:
								goto IL_0534;
							case 21:
							case 71:
								goto IL_0547;
							case 37:
								goto IL_056a;
							case 91:
								goto IL_0578;
							case 67:
								goto IL_0586;
							case 11:
								goto IL_0599;
							case 76:
							case 124:
								goto IL_05a7;
							case 51:
								goto IL_05bb;
							case 81:
							case 86:
								goto IL_05c6;
							case 28:
								goto IL_05e2;
							case 44:
								goto IL_05f0;
							case 45:
							case 126:
								goto IL_05fe;
							case 85:
								goto IL_0611;
							case 61:
								goto IL_061f;
							case 35:
								goto IL_0632;
							case 56:
							case 58:
								goto IL_0640;
							case 64:
								goto IL_064e;
							case 14:
							case 36:
								goto IL_065c;
							case 72:
								goto IL_06be;
							case 73:
							case 123:
								goto IL_06d1;
							case 29:
								goto IL_06dc;
							case 4:
							case 127:
								goto IL_06ea;
							case 17:
								goto IL_072a;
							case 59:
								goto IL_073e;
							case 2:
							case 15:
								goto IL_075f;
							case 89:
								goto IL_0773;
							case 120:
								goto IL_07c7;
							case 92:
								goto IL_07d5;
							case 1:
							case 12:
							case 19:
							case 23:
							case 27:
							case 30:
							case 32:
							case 38:
							case 39:
							case 48:
							case 69:
							case 77:
							case 82:
							case 93:
							case 94:
							case 98:
							case 103:
							case 107:
							case 117:
							case 118:
							case 121:
								goto IL_07e8;
							case 10:
							case 110:
								goto IL_0809;
							}
							continue;
						}
						array = new byte[4];
						goto IL_0274;
						IL_075f:
						array[num4 - 2] = 0;
						goto IL_0773;
						IL_07c7:
						num4--;
						goto IL_07d5;
						IL_0773:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = ((delegate*<int, int, int>)FromBinaryIdOps[*(int*)(ptr + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]));
						goto IL_07c7;
						IL_0274:
						array3 = new object[4];
						goto IL_0282;
						IL_0282:
						array4 = new int[3];
						goto IL_0290;
						IL_0290:
						array2 = new long[4];
						goto IL_029e;
						IL_029e:
						array4[0] = int_3;
						goto IL_02b1;
						IL_02b1:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetModuleHandleApplicationEvidence.HasLabelResolver);
						goto IL_02ba;
						IL_02ba:
						ptr = ptr2;
						goto IL_02c2;
						IL_02c2:
						if (num5 != 1)
						{
							goto IL_02d2;
						}
						goto IL_0809;
						IL_0809:
						return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						IL_02d2:
						num = 16;
						goto IL_02db;
						IL_02db:
						b = *ptr;
						goto IL_02e4;
						IL_02e4:
						ptr++;
						num = 97;
						goto IL_02fb;
						IL_02fb:
						if (b >= 1)
						{
							goto IL_0309;
						}
						goto IL_07e8;
						IL_0309:
						if (b <= 13)
						{
							goto IL_0317;
						}
						goto IL_07e8;
						IL_0317:
						if (7 >= b)
						{
							goto IL_0325;
						}
						goto IL_0599;
						IL_0325:
						if (7 > b)
						{
							goto IL_0333;
						}
						goto IL_0547;
						IL_0333:
						if (3 >= b)
						{
							goto IL_0341;
						}
						goto IL_042e;
						IL_0341:
						if (3 > b)
						{
							goto IL_034f;
						}
						goto IL_0416;
						IL_034f:
						if (1 >= b)
						{
							goto IL_035a;
						}
						goto IL_03b0;
						IL_035a:
						if (1 <= b)
						{
							goto IL_0368;
						}
						goto IL_07e8;
						IL_0368:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = *(int*)(ptr + num3);
						goto IL_0381;
						IL_0381:
						array[num4] = 0;
						goto IL_038f;
						IL_038f:
						num4++;
						goto IL_039d;
						IL_039d:
						ptr += 8;
						goto IL_02c2;
						IL_03b0:
						if (2 >= b)
						{
							goto IL_03be;
						}
						goto IL_07e8;
						IL_03be:
						if (2 <= b)
						{
							goto IL_03cc;
						}
						goto IL_07e8;
						IL_03cc:
						ref int reference = ref array4[*(int*)(ptr + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_03f5;
						IL_03f5:
						ptr += 8;
						goto IL_0403;
						IL_0403:
						num4--;
						goto IL_02c2;
						IL_0416:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_02c2;
						IL_042e:
						if (5 >= b)
						{
							goto IL_043c;
						}
						goto IL_04c4;
						IL_043c:
						if (5 > b)
						{
							goto IL_0447;
						}
						goto IL_0468;
						IL_0447:
						if (4 >= b)
						{
							goto IL_0455;
						}
						goto IL_07e8;
						IL_0455:
						if (4 <= b)
						{
							goto IL_02c2;
						}
						goto IL_07e8;
						IL_0468:
						array[num4] = 0;
						goto IL_0476;
						IL_0476:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array4[*(int*)(ptr + num3)];
						goto IL_0499;
						IL_0499:
						array3[num4] = null;
						goto IL_04a3;
						IL_04a3:
						num4++;
						goto IL_04b1;
						IL_04b1:
						ptr += 8;
						goto IL_02c2;
						IL_04c4:
						if (6 >= b)
						{
							goto IL_04d2;
						}
						goto IL_07e8;
						IL_04d2:
						if (6 <= b)
						{
							goto IL_04e0;
						}
						goto IL_07e8;
						IL_04e0:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_0520;
						IL_0520:
						array[num4 - 2] = 0;
						goto IL_0534;
						IL_0534:
						num4--;
						goto IL_02c2;
						IL_0547:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array4[*(int*)(ptr + num3)];
						goto IL_056a;
						IL_056a:
						array[num4] = 0;
						goto IL_0578;
						IL_0578:
						num4++;
						goto IL_0586;
						IL_0586:
						ptr += 8;
						goto IL_02c2;
						IL_0599:
						if (10 < b)
						{
							goto IL_05a7;
						}
						goto IL_0632;
						IL_05a7:
						if (12 >= b)
						{
							num = 51;
							goto IL_05bb;
						}
						goto IL_0611;
						IL_07d5:
						ptr += 8;
						goto IL_02c2;
						IL_05bb:
						if (12 <= b)
						{
							goto IL_05c6;
						}
						goto IL_05e2;
						IL_05c6:
						byte* num6 = ptr;
						num5 = 1;
						ptr = num6 + -200;
						goto IL_02c2;
						IL_05e2:
						if (11 >= b)
						{
							goto IL_05f0;
						}
						goto IL_07e8;
						IL_05f0:
						if (11 <= b)
						{
							goto IL_05fe;
						}
						goto IL_07e8;
						IL_05fe:
						num4--;
						goto IL_02c2;
						IL_0611:
						if (13 >= b)
						{
							goto IL_061f;
						}
						goto IL_07e8;
						IL_061f:
						if (13 > b)
						{
						}
						goto IL_07e8;
						IL_0632:
						if (10 > b)
						{
							goto IL_0640;
						}
						goto IL_075f;
						IL_0640:
						if (8 >= b)
						{
							goto IL_064e;
						}
						goto IL_06d1;
						IL_064e:
						if (8 <= b)
						{
							goto IL_065c;
						}
						goto IL_07e8;
						IL_065c:
						ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						goto IL_06be;
						IL_06be:
						num4 -= 2;
						goto IL_02c2;
						IL_06d1:
						if (9 >= b)
						{
							goto IL_06dc;
						}
						num = 23;
						goto IL_07e8;
						IL_06dc:
						if (9 <= b)
						{
							goto IL_06ea;
						}
						goto IL_07e8;
						IL_06ea:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
						goto IL_072a;
						IL_072a:
						array[num4 - 2] = 0;
						goto IL_073e;
						IL_073e:
						num4--;
						goto IL_02c2;
						IL_07e8:
						ptr = ptr2 + *(int*)(ptr + num3);
						num = 54;
						goto IL_02c2;
						continue;
						end_IL_0227:
						break;
					}
					continue;
					end_IL_0237:
					break;
				}
				continue;
				end_IL_0242:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							num = 127;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 94;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDeclaredConstructorsPolicyException.getSectionIDGetPathList);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02c8:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02a8:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0298:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_028b:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_027b:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_026b:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														num = 134;
																														while (true)
																														{
																															if (num != 134)
																															{
																																if (num != 1115)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 69:
																																	goto IL_0248;
																																case 55:
																																	goto IL_025b;
																																case 74:
																																case 97:
																																	goto IL_026b;
																																case 63:
																																	goto IL_027b;
																																case 18:
																																	goto IL_028b;
																																case 84:
																																	goto IL_0298;
																																case 82:
																																	goto IL_02a8;
																																case 35:
																																	goto IL_02b8;
																																case 73:
																																	goto IL_02c8;
																																case 85:
																																	goto end_IL_02c8;
																																case 60:
																																case 110:
																																	goto end_IL_02d8;
																																case 30:
																																case 34:
																																	goto IL_02f3;
																																case 72:
																																	goto IL_02fe;
																																case 2:
																																	goto IL_030c;
																																case 0:
																																case 68:
																																	goto IL_031a;
																																case 108:
																																	goto IL_035f;
																																case 21:
																																case 67:
																																	goto IL_036a;
																																case 78:
																																	goto IL_0378;
																																case 17:
																																case 95:
																																	goto IL_038b;
																																case 92:
																																	goto IL_0399;
																																case 112:
																																	goto end_IL_0235;
																																case 5:
																																case 59:
																																	goto IL_03cc;
																																case 88:
																																	goto IL_03e5;
																																case 43:
																																	goto IL_03f3;
																																case 44:
																																	goto IL_040a;
																																case 121:
																																	goto IL_041d;
																																case 116:
																																	goto IL_0427;
																																case 122:
																																	goto IL_0437;
																																case 11:
																																	goto IL_044b;
																																case 126:
																																	goto IL_045e;
																																case 14:
																																	goto IL_0471;
																																case 33:
																																	goto IL_04a3;
																																case 15:
																																	goto IL_04b1;
																																case 40:
																																case 79:
																																	goto IL_04c4;
																																case 12:
																																case 31:
																																	goto IL_04dc;
																																case 71:
																																	goto IL_04ff;
																																case 56:
																																	goto IL_050d;
																																case 46:
																																	goto IL_0524;
																																case 98:
																																	goto IL_0537;
																																case 64:
																																case 118:
																																	goto IL_0545;
																																case 26:
																																case 47:
																																	goto IL_0550;
																																case 124:
																																	goto IL_055e;
																																case 8:
																																	goto IL_0571;
																																case 45:
																																case 61:
																																	goto IL_057c;
																																case 25:
																																	goto IL_0598;
																																case 99:
																																	goto IL_05a6;
																																case 62:
																																case 66:
																																	goto IL_05b4;
																																case 105:
																																	goto IL_05d0;
																																case 4:
																																case 93:
																																	goto IL_05de;
																																case 27:
																																	goto IL_05ec;
																																case 1:
																																case 38:
																																	goto IL_05fa;
																																case 10:
																																	goto IL_065c;
																																case 39:
																																	goto IL_066f;
																																case 13:
																																	goto IL_067d;
																																case 16:
																																case 36:
																																	goto IL_068b;
																																case 42:
																																	goto IL_06cb;
																																case 111:
																																	goto IL_06e8;
																																case 75:
																																case 100:
																																	goto IL_06f8;
																																case 32:
																																	goto IL_070c;
																																case 54:
																																	goto IL_074b;
																																case 3:
																																case 6:
																																case 7:
																																case 19:
																																case 24:
																																case 29:
																																case 48:
																																case 49:
																																case 52:
																																case 53:
																																case 65:
																																case 76:
																																case 77:
																																case 80:
																																case 81:
																																case 83:
																																case 89:
																																case 91:
																																case 115:
																																case 117:
																																case 123:
																																case 125:
																																	goto end_IL_0248;
																																case 9:
																																case 23:
																																case 37:
																																case 50:
																																case 51:
																																case 57:
																																case 70:
																																case 86:
																																case 101:
																																case 102:
																																case 103:
																																case 104:
																																case 107:
																																case 109:
																																case 119:
																																case 120:
																																	goto end_IL_02e8;
																																case 58:
																																	goto end_IL_076e;
																																case 94:
																																	goto end_IL_0781;
																																case 90:
																																	goto end_IL_078b;
																																case 127:
																																	goto end_IL_0796;
																																case 20:
																																case 96:
																																	goto end_IL_07b4;
																																case 22:
																																	goto end_IL_07c4;
																																case 87:
																																case 106:
																																	goto end_IL_07dd;
																																case 113:
																																	goto end_IL_07ed;
																																case 114:
																																	goto end_IL_07fd;
																																case 28:
																																case 41:
																																	goto IL_0818;
																																}
																																continue;
																															}
																															goto IL_0471;
																															IL_04a3:
																															ptr2 += 8;
																															goto IL_04b1;
																															IL_04b1:
																															num5--;
																															goto end_IL_02e8;
																															IL_0471:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															num = 33;
																															goto IL_04a3;
																															continue;
																															end_IL_0235:
																															break;
																														}
																														goto IL_03be;
																														continue;
																														end_IL_0248:
																														break;
																														IL_0248:;
																													}
																													break;
																													IL_025b:;
																												}
																												break;
																											}
																											goto IL_03be;
																											IL_040a:
																											ptr2 += 8;
																											goto end_IL_02e8;
																											IL_03be:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_03cc;
																											IL_03cc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_03e5;
																											IL_03e5:
																											array[num5] = 0;
																											goto IL_03f3;
																											IL_03f3:
																											num5++;
																											num = 44;
																											goto IL_040a;
																										}
																										break;
																									}
																									goto IL_04c4;
																									IL_04c4:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02e8;
																								}
																								break;
																							}
																							goto IL_02f3;
																							IL_045e:
																							ptr2 += 8;
																							goto end_IL_02e8;
																							IL_02f3:
																							if (5 < b)
																							{
																								goto IL_02fe;
																							}
																							goto IL_035f;
																							IL_02fe:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_030c;
																							IL_030c:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_031a;
																							IL_031a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0437;
																							IL_0437:
																							array[num5 - 2] = 0;
																							goto IL_044b;
																							IL_044b:
																							num5--;
																							goto end_IL_02e8;
																							IL_035f:
																							if (5 > b)
																							{
																								goto IL_036a;
																							}
																							goto IL_038b;
																							IL_036a:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0378;
																							IL_0378:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_02e8;
																							IL_038b:
																							array[num5] = 0;
																							goto IL_0399;
																							IL_0399:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_041d;
																							IL_041d:
																							array2[num5] = null;
																							goto IL_0427;
																							IL_0427:
																							num5++;
																							goto IL_045e;
																						}
																						break;
																					}
																					goto IL_04dc;
																					IL_0524:
																					ptr2 += 8;
																					goto end_IL_02e8;
																					IL_04dc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04ff;
																					IL_04ff:
																					array[num5] = 0;
																					goto IL_050d;
																					IL_050d:
																					num5++;
																					num = 46;
																					goto IL_0524;
																				}
																				break;
																			}
																			goto IL_0537;
																			IL_074b:
																			ptr2 += 8;
																			goto end_IL_02e8;
																			IL_0537:
																			if (10 < b)
																			{
																				goto IL_0545;
																			}
																			goto IL_05d0;
																			IL_0545:
																			if (12 < b)
																			{
																				goto IL_0550;
																			}
																			goto IL_0571;
																			IL_0550:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_055e;
																			IL_055e:
																			if (13 <= b)
																			{
																			}
																			break;
																			IL_0571:
																			if (12 <= b)
																			{
																				goto IL_057c;
																			}
																			goto IL_0598;
																			IL_057c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02e8;
																			IL_0598:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_05a6;
																			IL_05a6:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_05b4;
																			IL_05b4:
																			num5--;
																			num = 51;
																			goto end_IL_02e8;
																			IL_05d0:
																			if (10 > b)
																			{
																				goto IL_05de;
																			}
																			goto IL_06f8;
																			IL_05de:
																			if (8 >= b)
																			{
																				goto IL_05ec;
																			}
																			goto IL_066f;
																			IL_05ec:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05fa;
																			IL_05fa:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_065c;
																			IL_065c:
																			num5 -= 2;
																			goto end_IL_02e8;
																			IL_066f:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_067d;
																			IL_067d:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_068b;
																			IL_068b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06cb;
																			IL_06cb:
																			array[num5 - 2] = 0;
																			num = 111;
																			goto IL_06e8;
																			IL_06e8:
																			num5--;
																			goto end_IL_02e8;
																			IL_06f8:
																			array[num5 - 1] = 0;
																			goto IL_070c;
																			IL_070c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)AtIdrefsRemoveAccessRuleSpecific[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_074b;
																		}
																		break;
																		IL_02b8:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02e8;
																continue;
																end_IL_02c8:
																break;
															}
															continue;
															end_IL_02d8:
															break;
														}
														continue;
														end_IL_02e8:
														break;
													}
													continue;
												}
												goto IL_0818;
												IL_0818:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_076e:
												break;
											}
											continue;
											end_IL_0781:
											break;
										}
										continue;
										end_IL_078b:
										break;
									}
									continue;
									end_IL_0796:
									break;
								}
								continue;
								end_IL_07b4:
								break;
							}
							continue;
							end_IL_07c4:
							break;
						}
						continue;
						end_IL_07dd:
						break;
					}
					continue;
					end_IL_07ed:
					break;
				}
				continue;
				end_IL_07fd:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KeyGenerationFlagsGetComInterfaceForObject.GetCountSafeBindHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_031f:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02ff:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f2:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02e2:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02d2:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_02c2:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0277:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_025e:
																																ptr2 += 8;
																																num = 143;
																																while (true)
																																{
																																	if (num != 143)
																																	{
																																		if (num != 1124)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 108:
																																			goto IL_025e;
																																		case 28:
																																		case 82:
																																			goto IL_0277;
																																		case 131:
																																			goto IL_02a2;
																																		case 21:
																																			goto IL_02b2;
																																		case 116:
																																			goto IL_02c2;
																																		case 38:
																																			goto IL_02d2;
																																		case 110:
																																			goto IL_02e2;
																																		case 115:
																																			goto IL_02f2;
																																		case 72:
																																			goto IL_02ff;
																																		case 10:
																																			goto IL_030f;
																																		case 49:
																																			goto IL_031f;
																																		case 92:
																																			goto end_IL_031f;
																																		case 47:
																																		case 85:
																																			goto end_IL_032f;
																																		case 11:
																																		case 65:
																																			goto IL_034a;
																																		case 75:
																																			goto IL_038a;
																																		case 87:
																																			goto IL_03a0;
																																		case 106:
																																		case 125:
																																			goto IL_03b0;
																																		case 130:
																																			goto IL_03c8;
																																		case 16:
																																		case 135:
																																			goto IL_03db;
																																		case 29:
																																			goto IL_03f4;
																																		case 53:
																																			goto IL_0402;
																																		case 45:
																																			goto IL_0410;
																																		case 96:
																																			goto IL_0436;
																																		case 42:
																																			goto IL_0444;
																																		case 105:
																																		case 107:
																																			goto IL_044f;
																																		case 86:
																																			goto IL_045a;
																																		case 79:
																																		case 80:
																																			goto IL_047b;
																																		case 78:
																																			goto IL_0489;
																																		case 95:
																																			goto IL_04ac;
																																		case 25:
																																			goto IL_04b6;
																																		case 89:
																																			goto IL_04c4;
																																		case 99:
																																		case 123:
																																			goto IL_04d7;
																																		case 128:
																																			goto IL_04e5;
																																		case 14:
																																		case 81:
																																			goto IL_04f3;
																																		case 101:
																																			goto IL_0533;
																																		case 32:
																																			goto IL_0547;
																																		case 0:
																																			goto IL_055a;
																																		case 31:
																																		case 39:
																																			goto IL_0568;
																																		case 114:
																																			goto IL_0573;
																																		case 35:
																																		case 91:
																																			goto IL_057e;
																																		case 60:
																																			goto IL_058c;
																																		case 33:
																																		case 83:
																																			goto IL_059a;
																																		case 120:
																																		case 133:
																																			goto IL_05ad;
																																		case 8:
																																			goto IL_05c9;
																																		case 37:
																																			goto IL_05d7;
																																		case 19:
																																			goto IL_05ea;
																																		case 51:
																																		case 111:
																																			goto IL_05f8;
																																		case 5:
																																			goto IL_0606;
																																		case 18:
																																		case 117:
																																			goto IL_0611;
																																		case 66:
																																			goto IL_0673;
																																		case 36:
																																			goto IL_0686;
																																		case 20:
																																			goto IL_0694;
																																		case 48:
																																		case 118:
																																			goto IL_06a2;
																																		case 122:
																																			goto IL_06c5;
																																		case 22:
																																			goto IL_06d3;
																																		case 97:
																																			goto IL_06e1;
																																		case 1:
																																			goto IL_06f4;
																																		case 41:
																																			goto IL_0702;
																																		case 69:
																																		case 90:
																																			goto IL_0710;
																																		case 126:
																																			goto IL_0750;
																																		case 127:
																																			goto IL_076d;
																																		case 76:
																																		case 109:
																																			goto IL_0780;
																																		case 27:
																																			goto IL_0794;
																																		case 62:
																																			goto IL_07e8;
																																		case 113:
																																			goto IL_07ff;
																																		case 2:
																																		case 6:
																																		case 23:
																																		case 40:
																																		case 43:
																																		case 44:
																																		case 50:
																																		case 52:
																																		case 56:
																																		case 58:
																																		case 59:
																																		case 61:
																																		case 67:
																																		case 68:
																																		case 70:
																																		case 71:
																																		case 74:
																																		case 93:
																																		case 104:
																																		case 119:
																																		case 121:
																																		case 129:
																																		case 132:
																																		case 136:
																																			goto end_IL_024b;
																																		case 3:
																																		case 4:
																																		case 7:
																																		case 12:
																																		case 24:
																																		case 26:
																																		case 46:
																																		case 54:
																																		case 57:
																																		case 73:
																																		case 77:
																																		case 84:
																																		case 88:
																																		case 94:
																																		case 100:
																																		case 102:
																																		case 103:
																																			goto end_IL_033f;
																																		case 13:
																																			goto end_IL_0822;
																																		case 34:
																																			goto end_IL_0835;
																																		case 112:
																																			goto end_IL_083f;
																																		case 124:
																																			goto end_IL_084a;
																																		case 15:
																																		case 30:
																																			goto end_IL_085f;
																																		case 98:
																																			goto end_IL_086f;
																																		case 55:
																																		case 134:
																																			goto end_IL_087f;
																																		case 63:
																																			goto end_IL_088f;
																																		case 64:
																																			goto end_IL_089f;
																																		case 9:
																																		case 17:
																																			goto IL_08ba;
																																		}
																																		continue;
																																	}
																																	num5--;
																																	goto end_IL_033f;
																																	continue;
																																	end_IL_024b:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																														IL_02a2:;
																													}
																													break;
																													IL_02b2:;
																												}
																												break;
																											}
																											goto IL_03a0;
																											IL_0410:
																											ptr2 += 8;
																											goto end_IL_033f;
																											IL_03a0:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_03db;
																											IL_03db:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_03f4;
																											IL_03f4:
																											array[num5] = 0;
																											goto IL_0402;
																											IL_0402:
																											num5++;
																											goto IL_0410;
																										}
																										break;
																									}
																									goto IL_03b0;
																									IL_03b0:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_033f;
																								}
																								break;
																							}
																							goto IL_0436;
																							IL_0533:
																							array[num5 - 2] = 0;
																							goto IL_0547;
																							IL_0436:
																							if (5 >= b)
																							{
																								goto IL_0444;
																							}
																							goto IL_04d7;
																							IL_0444:
																							if (5 > b)
																							{
																								goto IL_044f;
																							}
																							goto IL_047b;
																							IL_044f:
																							if (4 < b)
																							{
																								num = 56;
																								break;
																							}
																							goto IL_045a;
																							IL_045a:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_033f;
																							IL_0547:
																							num5--;
																							goto end_IL_033f;
																							IL_047b:
																							array[num5] = 0;
																							goto IL_0489;
																							IL_0489:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_04ac;
																							IL_04ac:
																							array2[num5] = null;
																							goto IL_04b6;
																							IL_04b6:
																							num5++;
																							goto IL_04c4;
																							IL_04c4:
																							ptr2 += 8;
																							goto end_IL_033f;
																							IL_04d7:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_04e5;
																							IL_04e5:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_04f3;
																							IL_04f3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0533;
																						}
																						break;
																					}
																					goto IL_034a;
																					IL_03c8:
																					num5--;
																					goto end_IL_033f;
																					IL_034a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_038a;
																					IL_038a:
																					array[num5 - 2] = 0;
																					goto IL_03c8;
																				}
																				break;
																			}
																			goto IL_055a;
																			IL_07ff:
																			ptr2 += 8;
																			goto end_IL_033f;
																			IL_055a:
																			if (11 < b)
																			{
																				goto IL_0568;
																			}
																			goto IL_05ea;
																			IL_0568:
																			if (13 >= b)
																			{
																				goto IL_0573;
																			}
																			goto IL_05c9;
																			IL_0573:
																			if (13 > b)
																			{
																				goto IL_057e;
																			}
																			goto IL_05ad;
																			IL_057e:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_058c;
																			IL_058c:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_059a;
																			IL_059a:
																			num5--;
																			goto end_IL_033f;
																			IL_05ad:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_033f;
																			IL_05c9:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_05d7;
																			IL_05d7:
																			if (14 <= b)
																			{
																			}
																			break;
																			IL_05ea:
																			if (11 > b)
																			{
																				goto IL_05f8;
																			}
																			goto IL_0780;
																			IL_05f8:
																			if (9 >= b)
																			{
																				goto IL_0606;
																			}
																			goto IL_06f4;
																			IL_0606:
																			if (9 <= b)
																			{
																				goto IL_0611;
																			}
																			goto IL_0686;
																			IL_0611:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0673;
																			IL_0673:
																			num5 -= 2;
																			goto end_IL_033f;
																			IL_0686:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0694;
																			IL_0694:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_06a2;
																			IL_06a2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_06c5;
																			IL_06c5:
																			array[num5] = 0;
																			goto IL_06d3;
																			IL_06d3:
																			num5++;
																			goto IL_06e1;
																			IL_06e1:
																			ptr2 += 8;
																			goto end_IL_033f;
																			IL_06f4:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0702;
																			IL_0702:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0710;
																			IL_0710:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0750;
																			IL_0750:
																			array[num5 - 2] = 0;
																			num = 127;
																			goto IL_076d;
																			IL_076d:
																			num5--;
																			goto end_IL_033f;
																			IL_0780:
																			array[num5 - 2] = 0;
																			goto IL_0794;
																			IL_0794:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)SilverlightSynchronizationAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_07e8;
																			IL_07e8:
																			num5--;
																			num = 113;
																			goto IL_07ff;
																		}
																		break;
																		IL_030f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_033f;
																continue;
																end_IL_031f:
																break;
															}
															continue;
															end_IL_032f:
															break;
														}
														continue;
														end_IL_033f:
														break;
													}
													continue;
												}
												goto IL_08ba;
												IL_08ba:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0822:
												break;
											}
											continue;
											end_IL_0835:
											break;
										}
										continue;
										end_IL_083f:
										break;
									}
									continue;
									end_IL_084a:
									break;
								}
								continue;
								end_IL_085f:
								break;
							}
							continue;
							end_IL_086f:
							break;
						}
						continue;
						end_IL_087f:
						break;
					}
					continue;
					end_IL_088f:
					break;
				}
				continue;
				end_IL_089f:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 61;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 50;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PackgetNamespace.NumberBufferVtableLayoutMask);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02dc:
															byte b = *ptr2;
															while (true)
															{
																IL_02cc:
																ptr2++;
																while (true)
																{
																	IL_02bc:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_029c:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_028c:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_027c:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_026f:
																										if (6 >= b)
																										{
																											while (6 <= b)
																											{
																												while (true)
																												{
																													IL_021d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_0207:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_01ee:
																															num5--;
																															num = 115;
																															while (num != 115)
																															{
																																if (num != 1096)
																																{
																																	goto IL_02bc;
																																}
																																switch (num)
																																{
																																case 63:
																																	goto IL_01ee;
																																case 96:
																																	goto IL_0207;
																																case 67:
																																case 92:
																																	goto IL_021d;
																																case 49:
																																	goto IL_025f;
																																case 84:
																																case 99:
																																	goto IL_026f;
																																case 60:
																																	goto IL_027c;
																																case 29:
																																case 76:
																																	goto IL_028c;
																																case 18:
																																	goto IL_029c;
																																case 46:
																																	goto IL_02ac;
																																case 80:
																																	goto IL_02bc;
																																case 5:
																																	goto IL_02cc;
																																case 21:
																																case 105:
																																	goto IL_02dc;
																																case 9:
																																case 27:
																																	goto IL_02e7;
																																case 16:
																																	goto IL_02f5;
																																case 19:
																																case 36:
																																	goto IL_0303;
																																case 89:
																																	goto IL_0326;
																																case 33:
																																	goto IL_0334;
																																case 0:
																																	goto IL_0342;
																																case 65:
																																case 86:
																																	goto IL_0355;
																																case 53:
																																	goto IL_03b7;
																																case 32:
																																	goto IL_03d3;
																																case 31:
																																case 35:
																																	goto IL_03de;
																																case 82:
																																	goto IL_03ec;
																																case 62:
																																	goto IL_03ff;
																																case 6:
																																case 74:
																																	goto IL_040d;
																																case 37:
																																	goto IL_0429;
																																case 34:
																																case 106:
																																	goto IL_0437;
																																case 10:
																																case 13:
																																	goto IL_0442;
																																case 91:
																																	goto IL_044d;
																																case 54:
																																case 72:
																																	goto IL_045b;
																																case 94:
																																	goto IL_0473;
																																case 71:
																																	goto IL_0481;
																																case 38:
																																	goto IL_0494;
																																case 7:
																																	goto IL_049f;
																																case 55:
																																	goto IL_04ad;
																																case 42:
																																case 98:
																																	goto IL_04bb;
																																case 51:
																																	goto IL_04d4;
																																case 40:
																																	goto IL_04e2;
																																case 22:
																																	goto IL_04f0;
																																case 30:
																																case 73:
																																	goto IL_0503;
																																case 52:
																																	goto IL_0535;
																																case 59:
																																	goto IL_0543;
																																case 81:
																																case 104:
																																	goto IL_0553;
																																case 100:
																																	goto IL_0561;
																																case 68:
																																	goto IL_0584;
																																case 4:
																																	goto IL_058e;
																																case 70:
																																	goto IL_059c;
																																case 3:
																																case 11:
																																case 12:
																																case 15:
																																case 20:
																																case 26:
																																case 28:
																																case 41:
																																case 43:
																																case 44:
																																case 45:
																																case 48:
																																case 58:
																																case 66:
																																case 77:
																																case 78:
																																case 79:
																																case 90:
																																case 93:
																																case 101:
																																case 103:
																																case 108:
																																	goto end_IL_025f;
																																case 1:
																																case 23:
																																case 24:
																																case 25:
																																case 39:
																																case 64:
																																case 69:
																																case 75:
																																case 87:
																																case 88:
																																case 95:
																																case 102:
																																	goto end_IL_01db;
																																case 14:
																																	goto end_IL_05bf;
																																case 97:
																																	goto end_IL_05d2;
																																case 8:
																																	goto end_IL_05dc;
																																case 2:
																																	goto end_IL_05e7;
																																case 50:
																																	goto end_IL_05fc;
																																case 83:
																																	goto end_IL_060c;
																																case 61:
																																	goto end_IL_061c;
																																case 17:
																																case 85:
																																	goto end_IL_0627;
																																case 56:
																																	goto end_IL_0637;
																																case 57:
																																	goto end_IL_0650;
																																case 47:
																																case 107:
																																	goto IL_066b;
																																}
																																continue;
																																end_IL_01db:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02bc;
																												continue;
																												end_IL_025f:
																												break;
																												IL_025f:;
																											}
																											break;
																										}
																										goto IL_02e7;
																										IL_0342:
																										ptr2 += 8;
																										goto end_IL_02bc;
																										IL_02e7:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_02f5;
																										IL_02f5:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0303;
																										IL_0303:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0326;
																										IL_0326:
																										array[num5] = 0;
																										goto IL_0334;
																										IL_0334:
																										num5++;
																										goto IL_0342;
																									}
																									break;
																								}
																								goto IL_0355;
																								IL_03b7:
																								num5 -= 2;
																								num = 23;
																								goto end_IL_02bc;
																								IL_0355:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_03b7;
																							}
																							break;
																						}
																						goto IL_03d3;
																						IL_040d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02bc;
																						IL_03d3:
																						if (9 < b)
																						{
																							goto IL_03de;
																						}
																						goto IL_03ff;
																						IL_03de:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_03ec;
																						IL_03ec:
																						if (10 <= b)
																						{
																						}
																						break;
																						IL_03ff:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_040d;
																					}
																					break;
																				}
																				goto IL_0429;
																				IL_059c:
																				ptr2 += 8;
																				goto end_IL_02bc;
																				IL_0429:
																				if (5 > b)
																				{
																					goto IL_0437;
																				}
																				goto IL_0553;
																				IL_0437:
																				if (2 < b)
																				{
																					goto IL_0442;
																				}
																				goto IL_0494;
																				IL_0442:
																				if (3 >= b)
																				{
																					goto IL_044d;
																				}
																				goto IL_0473;
																				IL_044d:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_045b;
																				IL_045b:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02bc;
																				IL_0473:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0481;
																				IL_0481:
																				if (4 <= b)
																				{
																					goto end_IL_02bc;
																				}
																				break;
																				IL_0494:
																				if (2 > b)
																				{
																					goto IL_049f;
																				}
																				goto IL_0503;
																				IL_049f:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04ad;
																				IL_04ad:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_04bb;
																				IL_04bb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04d4;
																				IL_04d4:
																				array[num5] = 0;
																				goto IL_04e2;
																				IL_04e2:
																				num5++;
																				goto IL_04f0;
																				IL_04f0:
																				ptr2 += 8;
																				goto end_IL_02bc;
																				IL_0503:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 52;
																				goto IL_0535;
																				IL_0535:
																				ptr2 += 8;
																				goto IL_0543;
																				IL_0543:
																				num5--;
																				goto end_IL_02bc;
																				IL_0553:
																				array[num5] = 0;
																				goto IL_0561;
																				IL_0561:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0584;
																				IL_0584:
																				array2[num5] = null;
																				goto IL_058e;
																				IL_058e:
																				num5++;
																				goto IL_059c;
																			}
																			break;
																			IL_02ac:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02bc:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_066b;
													IL_066b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05bf:
													break;
												}
												continue;
												end_IL_05d2:
												break;
											}
											continue;
											end_IL_05dc:
											break;
										}
										continue;
										end_IL_05e7:
										break;
									}
									continue;
									end_IL_05fc:
									break;
								}
								continue;
								end_IL_060c:
								break;
							}
							continue;
							end_IL_061c:
							break;
						}
						continue;
						end_IL_0627:
						break;
					}
					continue;
					end_IL_0637:
					break;
				}
				continue;
				end_IL_0650:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setLeaseManagerPollTimegetPercentDecimalSeparator.ExecuteAssemblyClientSend);
										num = 12;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0699:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02e4:
														byte b = *ptr2;
														num = 33;
														while (true)
														{
															IL_02d4:
															ptr2++;
															while (true)
															{
																IL_02c4:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02b4:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_02a4:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0294:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0284:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0274:
																										if (3 > b)
																										{
																											num = 41;
																											while (true)
																											{
																												IL_0264:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															while (true)
																															{
																																IL_0210:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																num = 120;
																																while (true)
																																{
																																	if (num != 120)
																																	{
																																		if (num != 1101)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 36:
																																		case 82:
																																			goto IL_0210;
																																		case 109:
																																			goto IL_0244;
																																		case 87:
																																			goto IL_0254;
																																		case 41:
																																		case 99:
																																			goto IL_0264;
																																		case 14:
																																			goto IL_0274;
																																		case 34:
																																		case 77:
																																			goto IL_0284;
																																		case 24:
																																			goto IL_0294;
																																		case 56:
																																			goto IL_02a4;
																																		case 52:
																																			goto IL_02b4;
																																		case 67:
																																			goto IL_02c4;
																																		case 33:
																																			goto IL_02d4;
																																		case 72:
																																		case 110:
																																			goto IL_02e4;
																																		case 10:
																																		case 15:
																																			goto IL_02f8;
																																		case 74:
																																			goto IL_0310;
																																		case 83:
																																		case 86:
																																			goto IL_031e;
																																		case 90:
																																			goto IL_0337;
																																		case 30:
																																			goto IL_0345;
																																		case 62:
																																			goto IL_0353;
																																		case 32:
																																			goto IL_037d;
																																		case 106:
																																			goto IL_0399;
																																		case 58:
																																			goto IL_03a4;
																																		case 84:
																																			goto IL_03b7;
																																		case 3:
																																			goto IL_03c5;
																																		case 59:
																																		case 94:
																																			goto IL_03d3;
																																		case 61:
																																			goto IL_03e1;
																																		case 60:
																																			goto IL_0404;
																																		case 40:
																																			goto IL_040e;
																																		case 63:
																																			goto IL_041c;
																																		case 71:
																																		case 80:
																																			goto IL_042f;
																																		case 23:
																																			goto IL_046f;
																																		case 64:
																																			goto IL_0483;
																																		case 16:
																																		case 97:
																																			goto IL_049f;
																																		case 28:
																																		case 76:
																																			goto IL_04aa;
																																		case 22:
																																			goto IL_04b5;
																																		case 73:
																																		case 104:
																																			goto IL_04c3;
																																		case 1:
																																			goto IL_04df;
																																		case 48:
																																			goto IL_04ed;
																																		case 18:
																																			goto IL_0500;
																																		case 5:
																																		case 108:
																																			goto IL_050b;
																																		case 7:
																																			goto IL_056d;
																																		case 100:
																																			goto IL_0580;
																																		case 6:
																																		case 38:
																																			goto IL_058e;
																																		case 27:
																																			goto IL_059c;
																																		case 11:
																																		case 39:
																																			goto IL_05aa;
																																		case 43:
																																			goto IL_05cd;
																																		case 66:
																																			goto IL_05db;
																																		case 31:
																																			goto IL_05f2;
																																		case 47:
																																			goto IL_060e;
																																		case 88:
																																		case 112:
																																			goto IL_0619;
																																		case 42:
																																			goto IL_0659;
																																		case 44:
																																			goto IL_066d;
																																		case 0:
																																		case 2:
																																		case 4:
																																		case 8:
																																		case 17:
																																		case 20:
																																		case 21:
																																		case 29:
																																		case 35:
																																		case 49:
																																		case 50:
																																		case 51:
																																		case 53:
																																		case 54:
																																		case 65:
																																		case 68:
																																		case 69:
																																		case 75:
																																		case 89:
																																		case 107:
																																		case 111:
																																			goto end_IL_0244;
																																		case 13:
																																		case 19:
																																		case 25:
																																		case 37:
																																		case 45:
																																		case 46:
																																		case 70:
																																		case 78:
																																		case 79:
																																		case 85:
																																		case 92:
																																		case 95:
																																		case 96:
																																		case 105:
																																			goto IL_0699;
																																		case 12:
																																			goto end_IL_01fd;
																																		case 101:
																																			goto end_IL_06ac;
																																		case 26:
																																			goto end_IL_06b6;
																																		case 91:
																																			goto end_IL_06ca;
																																		case 57:
																																		case 113:
																																			goto end_IL_06df;
																																		case 55:
																																			goto end_IL_06ef;
																																		case 9:
																																		case 81:
																																			goto end_IL_06ff;
																																		case 102:
																																			goto end_IL_070f;
																																		case 103:
																																			goto end_IL_071f;
																																		case 93:
																																		case 98:
																																			goto IL_073a;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	num = 32;
																																	goto IL_037d;
																																	IL_037d:
																																	num5--;
																																	num = 19;
																																	goto IL_0699;
																																	continue;
																																	end_IL_01fd:
																																	break;
																																}
																																break;
																															}
																															goto end_IL_02c4;
																															continue;
																															end_IL_0244:
																															break;
																															IL_0244:;
																														}
																														break;
																														IL_0254:;
																													}
																													break;
																												}
																												goto IL_0310;
																												IL_0353:
																												ptr2 += 8;
																												goto IL_0699;
																												IL_0310:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_031e;
																												IL_031e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0337;
																												IL_0337:
																												array[num5] = 0;
																												goto IL_0345;
																												IL_0345:
																												num5++;
																												goto IL_0353;
																											}
																											break;
																										}
																										goto IL_02f8;
																										IL_02f8:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto IL_0699;
																									}
																									break;
																								}
																								goto IL_0399;
																								IL_041c:
																								ptr2 += 8;
																								goto IL_0699;
																								IL_0399:
																								if (4 >= b)
																								{
																									goto IL_03a4;
																								}
																								goto IL_03b7;
																								IL_03a4:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0699;
																								IL_03b7:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_03c5;
																								IL_03c5:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_03d3;
																								IL_03d3:
																								array[num5] = 0;
																								goto IL_03e1;
																								IL_03e1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0404;
																								IL_0404:
																								array2[num5] = null;
																								goto IL_040e;
																								IL_040e:
																								num5++;
																								goto IL_041c;
																							}
																							break;
																						}
																						goto IL_042f;
																						IL_0483:
																						num5--;
																						goto IL_0699;
																						IL_042f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_046f;
																						IL_046f:
																						array[num5 - 2] = 0;
																						goto IL_0483;
																					}
																					break;
																				}
																				num = 97;
																				goto IL_049f;
																				IL_0659:
																				array[num5 - 2] = 0;
																				goto IL_066d;
																				IL_066d:
																				num5--;
																				goto IL_0699;
																				IL_049f:
																				if (9 < b)
																				{
																					goto IL_04aa;
																				}
																				goto IL_0500;
																				IL_04aa:
																				if (10 >= b)
																				{
																					goto IL_04b5;
																				}
																				goto IL_04df;
																				IL_04b5:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04c3;
																				IL_04c3:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_0699;
																				IL_04df:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_04ed;
																				IL_04ed:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0500:
																				if (9 <= b)
																				{
																					goto IL_050b;
																				}
																				goto IL_0580;
																				IL_050b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_056d;
																				IL_056d:
																				num5 -= 2;
																				goto IL_0699;
																				IL_0580:
																				if (7 < b)
																				{
																					goto IL_058e;
																				}
																				goto IL_060e;
																				IL_058e:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_059c;
																				IL_059c:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05aa;
																				IL_05aa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05cd;
																				IL_05cd:
																				array[num5] = 0;
																				goto IL_05db;
																				IL_05db:
																				num5++;
																				num = 31;
																				goto IL_05f2;
																				IL_05f2:
																				ptr2 += 8;
																				num = 70;
																				goto IL_0699;
																				IL_060e:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0619;
																				IL_0619:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0659;
																			}
																		}
																		else
																		{
																			num = 29;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0699;
																continue;
																end_IL_02c4:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_073a;
												IL_073a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											continue;
											end_IL_06ac:
											break;
										}
										continue;
										end_IL_06b6:
										break;
									}
									continue;
									end_IL_06ca:
									break;
								}
								continue;
								end_IL_06df:
								break;
							}
							continue;
							end_IL_06ef:
							break;
						}
						continue;
						end_IL_06ff:
						break;
					}
					continue;
					end_IL_070f:
					break;
				}
				continue;
				end_IL_071f:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_3, int int_4)
	{
		int num = 47;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 28;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConstructorArgumentsInheritedObjectAceTypePresent.SizeofConvOvfUUn);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0227:
															byte b = *ptr2;
															while (true)
															{
																IL_0217:
																ptr2++;
																while (true)
																{
																	IL_0207:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e7:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01da:
																						if (6 >= b)
																						{
																							while (true)
																							{
																								IL_01cd:
																								if (6 > b)
																								{
																									while (true)
																									{
																										IL_01c0:
																										if (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0192:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													num = 92;
																													while (num != 92)
																													{
																														if (num != 1073)
																														{
																															goto end_IL_01b0;
																														}
																														switch (num)
																														{
																														case 7:
																														case 36:
																															goto IL_0192;
																														case 16:
																															goto IL_01b0;
																														case 12:
																															goto IL_01c0;
																														case 21:
																															goto IL_01cd;
																														case 14:
																														case 45:
																															goto IL_01da;
																														case 38:
																															goto IL_01e7;
																														case 15:
																															goto IL_01f7;
																														case 11:
																															goto IL_0207;
																														case 68:
																															goto IL_0217;
																														case 43:
																														case 60:
																															goto IL_0227;
																														case 23:
																															goto IL_024e;
																														case 19:
																															goto IL_0259;
																														case 30:
																														case 67:
																															goto IL_0267;
																														case 52:
																															goto IL_0275;
																														case 17:
																															goto IL_0298;
																														case 1:
																															goto IL_02a2;
																														case 58:
																															goto IL_02b0;
																														case 61:
																															goto IL_02c3;
																														case 48:
																															goto IL_02d1;
																														case 41:
																														case 59:
																															goto IL_02df;
																														case 69:
																															goto IL_0304;
																														case 33:
																														case 82:
																															goto IL_030f;
																														case 66:
																															goto IL_0338;
																														case 78:
																															goto IL_0346;
																														case 31:
																															goto IL_0359;
																														case 2:
																															goto IL_0367;
																														case 39:
																															goto IL_0375;
																														case 8:
																														case 10:
																															goto IL_0383;
																														case 24:
																															goto IL_03c3;
																														case 4:
																															goto IL_03d7;
																														case 84:
																															goto IL_03ea;
																														case 37:
																														case 57:
																															goto IL_03f5;
																														case 44:
																															goto IL_0463;
																														case 9:
																															goto IL_0473;
																														case 20:
																															goto IL_047e;
																														case 5:
																														case 18:
																														case 22:
																														case 26:
																														case 27:
																														case 32:
																														case 34:
																														case 42:
																														case 55:
																														case 56:
																														case 64:
																														case 65:
																														case 70:
																														case 75:
																														case 76:
																														case 80:
																															goto end_IL_01b0;
																														case 77:
																															goto IL_04b5;
																														case 72:
																															goto IL_04c3;
																														case 0:
																															goto IL_04d1;
																														case 3:
																														case 29:
																														case 49:
																														case 50:
																														case 62:
																														case 71:
																														case 74:
																														case 79:
																														case 83:
																														case 85:
																															goto end_IL_017f;
																														case 53:
																															goto end_IL_04df;
																														case 35:
																															goto end_IL_04f2;
																														case 81:
																															goto end_IL_04fc;
																														case 28:
																															goto end_IL_0507;
																														case 13:
																															goto end_IL_051c;
																														case 63:
																														case 73:
																															goto end_IL_0531;
																														case 54:
																															goto end_IL_054a;
																														case 6:
																														case 25:
																															goto end_IL_055a;
																														case 46:
																															goto end_IL_056a;
																														case 47:
																															goto end_IL_057a;
																														case 40:
																														case 51:
																															goto IL_059e;
																														}
																														continue;
																														end_IL_017f:
																														break;
																													}
																													break;
																												}
																												goto end_IL_0207;
																												continue;
																												end_IL_01b0:
																												break;
																												IL_01b0:;
																											}
																										}
																										else
																										{
																											num = 56;
																										}
																										break;
																									}
																									break;
																								}
																								num = 62;
																								goto end_IL_0207;
																							}
																							break;
																						}
																						goto IL_024e;
																						IL_02df:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						num = 71;
																						goto end_IL_0207;
																						IL_024e:
																						if (7 >= b)
																						{
																							goto IL_0259;
																						}
																						goto IL_02c3;
																						IL_0259:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0267;
																						IL_0267:
																						array[num6] = 0;
																						goto IL_0275;
																						IL_0275:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0298;
																						IL_0298:
																						array2[num6] = null;
																						goto IL_02a2;
																						IL_02a2:
																						num6++;
																						goto IL_02b0;
																						IL_02b0:
																						ptr2 += 8;
																						goto end_IL_0207;
																						IL_02c3:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_02d1;
																						IL_02d1:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_02df;
																					}
																					break;
																				}
																				goto IL_0304;
																				IL_047e:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0304:
																				if (4 <= b)
																				{
																					goto IL_030f;
																				}
																				goto IL_0359;
																				IL_030f:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0338;
																				IL_0338:
																				ptr2 += 8;
																				goto IL_0346;
																				IL_0346:
																				num6--;
																				goto end_IL_0207;
																				IL_0359:
																				if (2 < b)
																				{
																					goto IL_0367;
																				}
																				goto IL_03ea;
																				IL_0367:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0375;
																				IL_0375:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0383;
																				IL_0383:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_03c3;
																				IL_03c3:
																				array[num6 - 2] = 0;
																				goto IL_03d7;
																				IL_03d7:
																				num6--;
																				goto end_IL_0207;
																				IL_03ea:
																				if (2 <= b)
																				{
																					goto IL_03f5;
																				}
																				goto IL_0473;
																				IL_03f5:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0463;
																				IL_0463:
																				num6 -= 2;
																				goto end_IL_0207;
																				IL_0473:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_047e;
																			}
																			break;
																			IL_01f7:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	num = 77;
																	goto IL_04b5;
																	IL_04d1:
																	ptr2 += 8;
																	break;
																	IL_04c3:
																	num6++;
																	goto IL_04d1;
																	IL_04b5:
																	array[num6] = 0;
																	goto IL_04c3;
																	continue;
																	end_IL_0207:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 40;
													goto IL_059e;
													IL_059e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04df:
													break;
												}
												continue;
												end_IL_04f2:
												break;
											}
											continue;
											end_IL_04fc:
											break;
										}
										continue;
										end_IL_0507:
										break;
									}
									continue;
									end_IL_051c:
									break;
								}
								continue;
								end_IL_0531:
								break;
							}
							continue;
							end_IL_054a:
							break;
						}
						continue;
						end_IL_055a:
						break;
					}
					continue;
					end_IL_056a:
					break;
				}
				continue;
				end_IL_057a:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MemoryBarrierfullPath.CLRConfigLdelemU);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0264:
														byte b = *ptr2;
														while (true)
														{
															IL_0254:
															ptr2++;
															while (true)
															{
																IL_0244:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0224:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0214:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0204:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_01f7:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											num = 109;
																											while (true)
																											{
																												if (num != 109)
																												{
																													if (num != 1090)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 62:
																														goto IL_01e4;
																													case 40:
																													case 42:
																														goto IL_01f7;
																													case 73:
																														goto IL_0204;
																													case 35:
																													case 61:
																														goto IL_0214;
																													case 84:
																														goto IL_0224;
																													case 4:
																														goto IL_0234;
																													case 68:
																														goto IL_0244;
																													case 60:
																														goto IL_0254;
																													case 78:
																													case 80:
																														goto IL_0264;
																													case 3:
																														goto IL_026f;
																													case 17:
																													case 31:
																														goto IL_027d;
																													case 69:
																														goto IL_02bd;
																													case 32:
																														goto IL_02d1;
																													case 0:
																													case 95:
																														goto IL_02e4;
																													case 18:
																													case 83:
																														goto IL_02ef;
																													case 48:
																														goto IL_02ff;
																													case 7:
																													case 57:
																														goto IL_030a;
																													case 99:
																														goto IL_0334;
																													case 51:
																													case 86:
																														goto IL_0355;
																													case 74:
																														goto IL_0378;
																													case 43:
																														goto IL_0386;
																													case 11:
																														goto IL_0394;
																													case 8:
																													case 21:
																														goto IL_03b0;
																													case 100:
																														goto IL_0412;
																													case 98:
																														goto IL_042e;
																													case 77:
																														goto IL_043c;
																													case 66:
																														goto IL_044a;
																													case 47:
																													case 49:
																														goto IL_0455;
																													case 75:
																														goto IL_047e;
																													case 82:
																														goto IL_048c;
																													case 89:
																														goto IL_049f;
																													case 97:
																														goto IL_04ad;
																													case 30:
																													case 90:
																														goto IL_04bb;
																													case 64:
																														goto IL_04d4;
																													case 25:
																														goto IL_04e2;
																													case 16:
																														goto IL_04f0;
																													case 52:
																														goto IL_0503;
																													case 45:
																													case 58:
																														goto IL_050e;
																													case 6:
																														goto IL_051c;
																													case 72:
																														goto IL_052c;
																													case 50:
																													case 70:
																														goto IL_0537;
																													case 20:
																													case 38:
																														goto IL_054c;
																													case 19:
																														goto IL_055a;
																													case 33:
																														goto IL_057d;
																													case 24:
																														goto IL_0587;
																													case 34:
																														goto IL_0595;
																													case 1:
																													case 10:
																													case 15:
																													case 22:
																													case 27:
																													case 28:
																													case 29:
																													case 36:
																													case 46:
																													case 53:
																													case 54:
																													case 55:
																													case 76:
																													case 85:
																													case 88:
																													case 101:
																													case 102:
																														goto end_IL_01e4;
																													case 2:
																													case 9:
																													case 12:
																													case 14:
																													case 37:
																													case 39:
																													case 41:
																													case 44:
																													case 59:
																													case 71:
																													case 79:
																													case 81:
																													case 87:
																														goto end_IL_01d1;
																													case 26:
																														goto end_IL_05b8;
																													case 94:
																														goto end_IL_05cb;
																													case 96:
																														goto end_IL_05d5;
																													case 93:
																														goto end_IL_05e0;
																													case 5:
																													case 56:
																														goto end_IL_05f5;
																													case 63:
																														goto end_IL_0605;
																													case 65:
																													case 67:
																														goto end_IL_0615;
																													case 91:
																														goto end_IL_0625;
																													case 92:
																														goto end_IL_0635;
																													case 13:
																													case 23:
																														goto IL_0650;
																													}
																													continue;
																												}
																												if (7 > b)
																												{
																													goto end_IL_01e4;
																												}
																												goto IL_0355;
																												IL_0378:
																												array[num5] = 0;
																												goto IL_0386;
																												IL_0394:
																												ptr2 += 8;
																												num = 81;
																												break;
																												IL_0386:
																												num5++;
																												goto IL_0394;
																												IL_0355:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0378;
																												continue;
																												end_IL_01d1:
																												break;
																											}
																											goto end_IL_0244;
																											continue;
																											end_IL_01e4:
																											break;
																											IL_01e4:;
																										}
																										break;
																									}
																									goto IL_026f;
																									IL_02d1:
																									num5--;
																									goto end_IL_0244;
																									IL_026f:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_027d;
																									IL_027d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_02bd;
																									IL_02bd:
																									array[num5 - 2] = 0;
																									goto IL_02d1;
																								}
																								break;
																							}
																							goto IL_03b0;
																							IL_0412:
																							num5 -= 2;
																							num = 39;
																							goto end_IL_0244;
																							IL_03b0:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0412;
																						}
																						break;
																					}
																					goto IL_02e4;
																					IL_030a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0244;
																					IL_02e4:
																					if (9 < b)
																					{
																						goto IL_02ef;
																					}
																					goto IL_02ff;
																					IL_02ef:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0334;
																					IL_0334:
																					if (10 <= b)
																					{
																					}
																					break;
																					IL_02ff:
																					if (9 > b)
																					{
																						num = 27;
																						break;
																					}
																					goto IL_030a;
																				}
																				break;
																			}
																			goto IL_042e;
																			IL_0595:
																			ptr2 += 8;
																			goto end_IL_0244;
																			IL_042e:
																			if (5 > b)
																			{
																				goto IL_043c;
																			}
																			goto IL_054c;
																			IL_043c:
																			if (2 >= b)
																			{
																				goto IL_044a;
																			}
																			goto IL_0503;
																			IL_044a:
																			if (2 <= b)
																			{
																				goto IL_0455;
																			}
																			goto IL_049f;
																			IL_0455:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_047e;
																			IL_047e:
																			ptr2 += 8;
																			goto IL_048c;
																			IL_048c:
																			num5--;
																			goto end_IL_0244;
																			IL_049f:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04ad;
																			IL_04ad:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04bb;
																			IL_04bb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04d4;
																			IL_04d4:
																			array[num5] = 0;
																			goto IL_04e2;
																			IL_04e2:
																			num5++;
																			goto IL_04f0;
																			IL_04f0:
																			ptr2 += 8;
																			goto end_IL_0244;
																			IL_0503:
																			if (3 < b)
																			{
																				goto IL_050e;
																			}
																			goto IL_052c;
																			IL_050e:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_051c;
																			IL_051c:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0244;
																			IL_052c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0537;
																			IL_0537:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0244;
																			IL_054c:
																			array[num5] = 0;
																			goto IL_055a;
																			IL_055a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_057d;
																			IL_057d:
																			array2[num5] = null;
																			goto IL_0587;
																			IL_0587:
																			num5++;
																			goto IL_0595;
																		}
																		break;
																		IL_0234:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0244:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0650;
												IL_0650:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b8:
												break;
											}
											continue;
											end_IL_05cb:
											break;
										}
										continue;
										end_IL_05d5:
										break;
									}
									continue;
									end_IL_05e0:
									break;
								}
								continue;
								end_IL_05f5:
								break;
							}
							continue;
							end_IL_0605:
							break;
						}
						continue;
						end_IL_0615:
						break;
					}
					continue;
					end_IL_0625:
					break;
				}
				continue;
				end_IL_0635:
				break;
			}
		}
	}

	static Class115()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_004a:
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 6:
								goto IL_004a;
							case 4:
								goto end_IL_003d;
							case 5:
								goto end_IL_005f;
							case 3:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}
}
