using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Connect USW", "Room", "Connect to USW servers.", true, 3, ModType.const_1, false)]
internal class Class163 : MonoBehaviour
{
	private static int int_0;

	private static int int_1;

	private static double double_0;

	private static double double_1;

	private static bool bool_0;

	private static float float_0;

	private static bool bool_1;

	private static IntPtr[] RequiresIMethodMessage;

	private static IntPtr[] SameDomainByteArray;

	private static IntPtr[] GetValueKindPOLICYLOOKUPNAMES;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_03e3, IL_03f6, IL_040f, IL_041f, IL_042b, IL_0450, IL_0460, IL_0470, IL_0480, IL_0490, IL_04a0, IL_04b0, IL_04c0, IL_04cd, IL_04dd, IL_04ed, IL_04fd, IL_0508, IL_0516, IL_0524, IL_0532, IL_0540, IL_054e, IL_055c, IL_0579, IL_05c8, IL_05d2, IL_05ff, IL_0613, IL_0621, IL_063d, IL_064b, IL_0659, IL_0677, IL_0685, IL_0698, IL_06a3, IL_06b1, IL_06bf, IL_06c8, IL_06db, IL_0722, IL_0735, IL_073e, IL_074c, IL_0757, IL_0767, IL_077a, IL_07a3, IL_07bc, IL_07ca, IL_07d8, IL_07f0, IL_07fe, IL_080c, IL_081f, IL_082d, IL_083b, IL_0853, IL_0861, IL_0874, IL_0884, IL_08ad, IL_08bb, IL_08ce, IL_08ea, IL_0902, IL_0920, IL_0944, IL_095c, IL_096f, IL_097a, IL_098e, IL_09cc, IL_09df, IL_09ea, IL_09f8, IL_0a06, IL_0a1b, IL_0a2e, IL_0a3c, IL_0a50, IL_0a88, IL_0a9b, IL_0aa9, IL_0ab7, IL_0ac0, IL_0b00, IL_0b14, IL_0b27, IL_0b32, IL_0b5b, IL_0b69, IL_0b7c, IL_0b87, IL_0b9a, IL_0ba8, IL_0bb6, IL_0bf6, IL_0c0a, IL_0c1d, IL_0c5d, IL_0c71, IL_0c84, IL_0c92, IL_0ca0, IL_0cab, IL_0cb9, IL_0cc7, IL_0cda, IL_0ce8, IL_0d28, IL_0d3c, IL_0d4f, IL_0d8f, IL_0da3, IL_0db6, IL_0dc4, IL_0dd2, IL_0ddb, IL_0e3d, IL_0e59, IL_0e67, IL_0e75, IL_0e92, IL_0ee6, IL_0ef4, IL_0f04, IL_0f0d, IL_0f26, IL_0f34, IL_0f42, IL_0f50, IL_0f63, IL_0f6d, IL_0f78, IL_0f88, IL_0f98, IL_0fa8, IL_0fb8, IL_0fc8, IL_0fd8, IL_0fe8, IL_1001 are reachable both inside and outside the pinned region starting at IL_1016. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 147;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef75 = default(int);
			ref int reference = ref __rxRef75;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1001:
					num2 = 1;
					while (true)
					{
						IL_0fe8:
						num3 = num2 * 4;
						num = 139;
						while (true)
						{
							IL_0fd8:
							array2 = new byte[4];
							while (true)
							{
								IL_0fc8:
								array3 = new object[4];
								while (true)
								{
									IL_0fb8:
									array4 = new int[4];
									while (true)
									{
										IL_0fa8:
										array5 = new int[6];
										while (true)
										{
											IL_0f98:
											array6 = new long[4];
											while (true)
											{
												IL_0f88:
												array7 = new object[5];
												while (true)
												{
													IL_0f78:
													array7[0] = this;
													while (true)
													{
														IL_0f6d:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PermissionSetEnumeratorInternalEnumSubcategoriesFlags.IConvertibleGetUrlsForObject);
														while (true)
														{
															IL_0f63:
															ptr2 = ptr;
															while (true)
															{
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_04fd:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_04ed:
																		ptr2++;
																		while (true)
																		{
																			IL_04dd:
																			if (b >= 1)
																			{
																				while (b <= 24)
																				{
																					while (true)
																					{
																						IL_04c0:
																						if (12 >= b)
																						{
																							while (12 > b)
																							{
																								while (true)
																								{
																									IL_04a0:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_0490:
																											if (6 > b)
																											{
																												while (true)
																												{
																													IL_0480:
																													if (3 < b)
																													{
																														while (true)
																														{
																															IL_0470:
																															if (4 >= b)
																															{
																																while (4 <= b)
																																{
																																	while (true)
																																	{
																																		IL_0450:
																																		array2[num5] = 0;
																																		while (true)
																																		{
																																			IL_042b:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																																			while (true)
																																			{
																																				IL_041f:
																																				array3[num5] = null;
																																				while (true)
																																				{
																																					IL_040f:
																																					num5++;
																																					while (true)
																																					{
																																						IL_03f6:
																																						ptr2 += 8;
																																						num = 245;
																																						while (num != 245 && num == 1226)
																																						{
																																							switch (num)
																																							{
																																							case 147:
																																								break;
																																							default:
																																								continue;
																																							case 67:
																																								goto IL_03f6;
																																							case 41:
																																								goto IL_040f;
																																							case 93:
																																								goto IL_041f;
																																							case 61:
																																								goto IL_042b;
																																							case 16:
																																							case 121:
																																								goto IL_0450;
																																							case 165:
																																								goto IL_0460;
																																							case 175:
																																							case 180:
																																								goto IL_0470;
																																							case 25:
																																							case 213:
																																								goto IL_0480;
																																							case 84:
																																								goto IL_0490;
																																							case 184:
																																								goto IL_04a0;
																																							case 149:
																																								goto IL_04b0;
																																							case 229:
																																								goto IL_04c0;
																																							case 219:
																																								goto IL_04cd;
																																							case 3:
																																								goto IL_04dd;
																																							case 79:
																																								goto IL_04ed;
																																							case 152:
																																							case 177:
																																								goto IL_04fd;
																																							case 142:
																																							case 183:
																																								goto IL_0508;
																																							case 173:
																																								goto IL_0516;
																																							case 12:
																																							case 26:
																																								goto IL_0524;
																																							case 63:
																																								goto IL_0532;
																																							case 144:
																																							case 179:
																																								goto IL_0540;
																																							case 8:
																																								goto IL_054e;
																																							case 19:
																																							case 90:
																																								goto IL_055c;
																																							case 98:
																																								goto IL_0613;
																																							case 89:
																																								goto IL_0621;
																																							case 91:
																																								goto IL_063d;
																																							case 124:
																																								goto IL_064b;
																																							case 35:
																																							case 62:
																																								goto IL_0659;
																																							case 127:
																																								goto IL_0677;
																																							case 178:
																																								goto IL_0685;
																																							case 31:
																																								goto IL_0698;
																																							case 22:
																																								goto IL_06a3;
																																							case 40:
																																							case 82:
																																								goto IL_06c8;
																																							case 75:
																																							case 135:
																																								goto IL_06db;
																																							case 108:
																																								goto IL_0722;
																																							case 49:
																																							case 118:
																																								goto IL_073e;
																																							case 87:
																																							case 117:
																																								goto IL_074c;
																																							case 36:
																																								goto IL_0757;
																																							case 11:
																																							case 160:
																																								goto IL_0767;
																																							case 70:
																																							case 196:
																																								goto IL_077a;
																																							case 45:
																																								goto IL_07a3;
																																							case 64:
																																							case 199:
																																								goto IL_07bc;
																																							case 33:
																																								goto IL_07ca;
																																							case 1:
																																							case 112:
																																								goto IL_07d8;
																																							case 97:
																																								goto IL_07f0;
																																							case 81:
																																								goto IL_07fe;
																																							case 80:
																																								goto IL_080c;
																																							case 205:
																																								goto IL_081f;
																																							case 99:
																																							case 113:
																																								goto IL_082d;
																																							case 72:
																																								goto IL_083b;
																																							case 143:
																																								goto IL_0853;
																																							case 189:
																																								goto IL_0861;
																																							case 211:
																																								goto IL_0874;
																																							case 10:
																																							case 218:
																																								goto IL_0884;
																																							case 88:
																																								goto IL_08ad;
																																							case 43:
																																								goto IL_08bb;
																																							case 34:
																																							case 223:
																																								goto IL_08ce;
																																							case 110:
																																							case 224:
																																								goto IL_08ea;
																																							case 148:
																																								goto IL_0902;
																																							case 104:
																																								goto IL_0920;
																																							case 128:
																																								goto IL_0944;
																																							case 115:
																																								goto IL_095c;
																																							case 233:
																																								goto IL_096f;
																																							case 51:
																																							case 52:
																																								goto IL_097a;
																																							case 188:
																																								goto IL_098e;
																																							case 85:
																																								goto IL_09cc;
																																							case 96:
																																								goto IL_09df;
																																							case 86:
																																							case 202:
																																								goto IL_09ea;
																																							case 190:
																																								goto IL_09f8;
																																							case 60:
																																							case 114:
																																								goto IL_0a06;
																																							case 195:
																																								goto IL_0a1b;
																																							case 76:
																																								goto IL_0a2e;
																																							case 162:
																																							case 164:
																																								goto IL_0a3c;
																																							case 141:
																																								goto IL_0a50;
																																							case 30:
																																								goto IL_0a88;
																																							case 18:
																																								goto IL_0a9b;
																																							case 161:
																																								goto IL_0aa9;
																																							case 77:
																																							case 95:
																																								goto IL_0ac0;
																																							case 163:
																																								goto IL_0b00;
																																							case 65:
																																								goto IL_0b14;
																																							case 210:
																																								goto IL_0b27;
																																							case 94:
																																							case 203:
																																								goto IL_0b32;
																																							case 167:
																																								goto IL_0b5b;
																																							case 122:
																																								goto IL_0b69;
																																							case 111:
																																								goto IL_0b7c;
																																							case 109:
																																								goto IL_0b87;
																																							case 92:
																																							case 100:
																																								goto IL_0b9a;
																																							case 134:
																																								goto IL_0ba8;
																																							case 6:
																																							case 236:
																																								goto IL_0bb6;
																																							case 47:
																																								goto IL_0bf6;
																																							case 235:
																																								goto IL_0c0a;
																																							case 126:
																																							case 225:
																																								goto IL_0c1d;
																																							case 103:
																																								goto IL_0c5d;
																																							case 212:
																																								goto IL_0c71;
																																							case 14:
																																								goto IL_0c84;
																																							case 105:
																																								goto IL_0c92;
																																							case 207:
																																							case 214:
																																								goto IL_0ca0;
																																							case 48:
																																							case 220:
																																								goto IL_0cab;
																																							case 145:
																																								goto IL_0cb9;
																																							case 4:
																																							case 101:
																																								goto IL_0cc7;
																																							case 138:
																																								goto IL_0cda;
																																							case 157:
																																							case 197:
																																								goto IL_0ce8;
																																							case 237:
																																								goto IL_0d28;
																																							case 168:
																																								goto IL_0d3c;
																																							case 107:
																																							case 193:
																																								goto IL_0d4f;
																																							case 204:
																																								goto IL_0d8f;
																																							case 227:
																																								goto IL_0da3;
																																							case 42:
																																								goto IL_0db6;
																																							case 221:
																																								goto IL_0dc4;
																																							case 13:
																																							case 32:
																																								goto IL_0ddb;
																																							case 56:
																																								goto IL_0e3d;
																																							case 125:
																																								goto IL_0e59;
																																							case 137:
																																								goto IL_0e67;
																																							case 130:
																																							case 158:
																																								goto IL_0e75;
																																							case 176:
																																								goto IL_0e92;
																																							case 133:
																																								goto IL_0ee6;
																																							case 206:
																																								goto IL_0ef4;
																																							case 0:
																																							case 7:
																																							case 9:
																																							case 20:
																																							case 21:
																																							case 38:
																																							case 44:
																																							case 46:
																																							case 50:
																																							case 54:
																																							case 55:
																																							case 59:
																																							case 66:
																																							case 69:
																																							case 71:
																																							case 73:
																																							case 102:
																																							case 116:
																																							case 129:
																																							case 132:
																																							case 140:
																																							case 155:
																																							case 159:
																																							case 166:
																																							case 169:
																																							case 170:
																																							case 174:
																																							case 185:
																																							case 186:
																																							case 187:
																																							case 192:
																																							case 200:
																																							case 201:
																																							case 209:
																																							case 216:
																																							case 217:
																																							case 222:
																																							case 230:
																																							case 232:
																																							case 234:
																																							case 238:
																																								goto end_IL_0460;
																																							case 74:
																																								goto IL_0f26;
																																							case 231:
																																								goto IL_0f34;
																																							case 106:
																																								goto IL_0f42;
																																							case 5:
																																							case 15:
																																							case 23:
																																							case 24:
																																							case 28:
																																							case 29:
																																							case 37:
																																							case 58:
																																							case 68:
																																							case 78:
																																							case 83:
																																							case 119:
																																							case 120:
																																							case 150:
																																							case 151:
																																							case 153:
																																							case 154:
																																							case 171:
																																							case 172:
																																							case 181:
																																							case 182:
																																							case 191:
																																							case 194:
																																							case 198:
																																							case 208:
																																							case 215:
																																								goto end_IL_03e3;
																																							case 226:
																																								goto IL_0f63;
																																							case 123:
																																								goto IL_0f6d;
																																							case 39:
																																								goto IL_0f78;
																																							case 2:
																																								goto IL_0f88;
																																							case 131:
																																								goto IL_0f98;
																																							case 27:
																																								goto IL_0fa8;
																																							case 17:
																																								goto IL_0fb8;
																																							case 53:
																																								goto IL_0fc8;
																																							case 57:
																																							case 139:
																																								goto IL_0fd8;
																																							case 228:
																																								goto IL_0fe8;
																																							case 146:
																																								goto IL_1001;
																																							case 136:
																																							case 156:
																																								return;
																																							}
																																							goto end_IL_0f50;
																																							continue;
																																							end_IL_03e3:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto end_IL_04b0;
																																	continue;
																																	end_IL_0460:
																																	break;
																																	IL_0460:;
																																}
																																break;
																															}
																															goto IL_0a9b;
																															IL_0b00:
																															array2[num5 - 2] = 0;
																															goto IL_0b14;
																															IL_0a9b:
																															if (5 < b)
																															{
																																break;
																															}
																															goto IL_0aa9;
																															IL_0aa9:
																															if (5 > b)
																															{
																																break;
																															}
																															num = 77;
																															goto IL_0ac0;
																															IL_0b14:
																															num5--;
																															goto end_IL_04b0;
																															IL_0ac0:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															goto IL_0b00;
																														}
																														break;
																													}
																													goto IL_0b27;
																													IL_0c0a:
																													num5--;
																													goto end_IL_04b0;
																													IL_0b27:
																													if (3 <= b)
																													{
																														goto IL_0b32;
																													}
																													goto IL_0b7c;
																													IL_0b32:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													goto IL_0b5b;
																													IL_0b5b:
																													ptr2 += 8;
																													goto IL_0b69;
																													IL_0b69:
																													num5--;
																													goto end_IL_04b0;
																													IL_0b7c:
																													if (1 >= b)
																													{
																														goto IL_0b87;
																													}
																													goto IL_0b9a;
																													IL_0b87:
																													if (1 > b)
																													{
																													}
																													break;
																													IL_0b9a:
																													if (2 < b)
																													{
																														break;
																													}
																													goto IL_0ba8;
																													IL_0ba8:
																													if (2 > b)
																													{
																														break;
																													}
																													goto IL_0bb6;
																													IL_0bb6:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													goto IL_0bf6;
																													IL_0bf6:
																													array2[num5 - 2] = 0;
																													goto IL_0c0a;
																												}
																												break;
																											}
																											goto IL_0c1d;
																											IL_0c71:
																											num5--;
																											goto end_IL_04b0;
																											IL_0c1d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0c5d;
																											IL_0c5d:
																											array2[num5 - 2] = 0;
																											goto IL_0c71;
																										}
																										break;
																									}
																									goto IL_0c84;
																									IL_0ee6:
																									num5--;
																									goto IL_0ef4;
																									IL_0c84:
																									if (9 >= b)
																									{
																										goto IL_0c92;
																									}
																									goto IL_0db6;
																									IL_0c92:
																									if (9 > b)
																									{
																										goto IL_0ca0;
																									}
																									goto IL_0d4f;
																									IL_0ca0:
																									if (7 < b)
																									{
																										goto IL_0cab;
																									}
																									goto IL_0cda;
																									IL_0cab:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0cb9;
																									IL_0cb9:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_0cc7;
																									IL_0cc7:
																									num5--;
																									goto end_IL_04b0;
																									IL_0cda:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0ce8;
																									IL_0ce8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0d28;
																									IL_0d28:
																									array2[num5 - 2] = 0;
																									goto IL_0d3c;
																									IL_0d3c:
																									num5--;
																									goto end_IL_04b0;
																									IL_0d4f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0d8f;
																									IL_0d8f:
																									array2[num5 - 2] = 0;
																									goto IL_0da3;
																									IL_0da3:
																									num5--;
																									goto end_IL_04b0;
																									IL_0db6:
																									if (10 >= b)
																									{
																										goto IL_0dc4;
																									}
																									goto IL_0e59;
																									IL_0dc4:
																									if (10 > b)
																									{
																										break;
																									}
																									num = 13;
																									goto IL_0ddb;
																									IL_0ef4:
																									ptr2 += 8;
																									goto end_IL_04b0;
																									IL_0ddb:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0e3d;
																									IL_0e3d:
																									num5 -= 2;
																									num = 154;
																									goto end_IL_04b0;
																									IL_0e59:
																									if (11 < b)
																									{
																										num = 232;
																										break;
																									}
																									goto IL_0e67;
																									IL_0e67:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_0e75;
																									IL_0e75:
																									array2[num5 - 2] = 0;
																									num = 176;
																									goto IL_0e92;
																									IL_0e92:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																									goto IL_0ee6;
																								}
																								goto end_IL_04cd;
																								continue;
																								end_IL_04b0:
																								break;
																								IL_04b0:;
																							}
																							break;
																						}
																						goto IL_0508;
																						IL_09f8:
																						if (20 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_0a06;
																						IL_0508:
																						if (18 >= b)
																						{
																							goto IL_0516;
																						}
																						num = 118;
																						goto IL_073e;
																						IL_0516:
																						if (18 > b)
																						{
																							goto IL_0524;
																						}
																						goto IL_06db;
																						IL_0524:
																						if (15 >= b)
																						{
																							goto IL_0532;
																						}
																						goto IL_0698;
																						IL_0532:
																						if (15 > b)
																						{
																							goto IL_0540;
																						}
																						goto IL_077a;
																						IL_0540:
																						if (13 >= b)
																						{
																							goto IL_054e;
																						}
																						goto IL_063d;
																						IL_054e:
																						if (13 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_055c;
																						IL_055c:
																						array8 = array3;
																						num6 = num5;
																						if (array == null)
																						{
																							goto IL_056b;
																						}
																						num7 = ptr2;
																						byte b2 = *num7;
																						ptr2 = num7 + 4;
																						int num8 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num8;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0613;
																						IL_0a1b:
																						ptr2 += 8;
																						break;
																						IL_0a2e:
																						if (19 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_0a3c;
																						IL_0a3c:
																						array2[num5 - 1] = 5;
																						goto IL_0a50;
																						IL_0613:
																						array2[num5] = 5;
																						goto IL_0621;
																						IL_0621:
																						num5++;
																						num = 83;
																						break;
																						IL_063d:
																						if (14 < b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_064b;
																						IL_064b:
																						if (14 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_0659;
																						IL_0659:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0677;
																						IL_0677:
																						ptr2 += 8;
																						goto IL_0685;
																						IL_0685:
																						num5--;
																						break;
																						IL_077a:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_07a3;
																						IL_07a3:
																						array2[num5 - 1] = 5;
																						break;
																						IL_0698:
																						if (16 >= b)
																						{
																							goto IL_06a3;
																						}
																						num = 82;
																						goto IL_06c8;
																						IL_06a3:
																						if (16 > b)
																						{
																							goto end_IL_04cd;
																						}
																						num = 110;
																						goto IL_08ea;
																						IL_0a88:
																						ptr2 += 8;
																						break;
																						IL_08ea:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0902;
																						IL_0902:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_0920;
																						IL_0920:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0944;
																						IL_0944:
																						array3[num5] = array3[num5 - 1];
																						goto IL_095c;
																						IL_095c:
																						num5++;
																						break;
																						IL_0a50:
																						array3[num5 - 1] = ((delegate*<string[], string>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0a88;
																						IL_06c8:
																						if (17 < b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_081f;
																						IL_081f:
																						if (17 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_082d;
																						IL_082d:
																						array2[num5] = 5;
																						goto IL_083b;
																						IL_083b:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0853;
																						IL_0853:
																						num5++;
																						goto IL_0861;
																						IL_0861:
																						ptr2 += 8;
																						break;
																						IL_06db:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						num = 108;
																						goto IL_0722;
																						IL_0722:
																						num5 -= 3;
																						break;
																						IL_0a06:
																						((delegate*<void>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])();
																						goto IL_0a1b;
																						IL_073e:
																						if (21 < b)
																						{
																							goto IL_074c;
																						}
																						goto IL_096f;
																						IL_074c:
																						if (23 >= b)
																						{
																							goto IL_0757;
																						}
																						goto IL_0767;
																						IL_0757:
																						if (23 > b)
																						{
																							goto IL_07bc;
																						}
																						goto IL_0884;
																						IL_07bc:
																						if (22 < b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_07ca;
																						IL_07ca:
																						if (22 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_07d8;
																						IL_07d8:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_07f0;
																						IL_07f0:
																						array2[num5] = 5;
																						goto IL_07fe;
																						IL_07fe:
																						num5++;
																						goto IL_080c;
																						IL_080c:
																						ptr2 += 8;
																						break;
																						IL_0884:
																						((delegate*<UnityEngine.Object, void>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((Class163)array3[num5 - 1]);
																						goto IL_08ad;
																						IL_08ad:
																						num5--;
																						goto IL_08bb;
																						IL_08bb:
																						ptr2 += 8;
																						break;
																						IL_0767:
																						if (24 < b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_0874;
																						IL_0874:
																						if (24 > b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_08ce;
																						IL_08ce:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						break;
																						IL_096f:
																						if (21 <= b)
																						{
																							goto IL_097a;
																						}
																						goto IL_09df;
																						IL_097a:
																						array2[num5 - 1] = 0;
																						goto IL_098e;
																						IL_098e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (((delegate*<string, bool>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]) ? 1 : 0);
																						goto IL_09cc;
																						IL_09cc:
																						ptr2 += 8;
																						break;
																						IL_09df:
																						if (19 < b)
																						{
																							goto IL_09ea;
																						}
																						goto IL_0a2e;
																						IL_09ea:
																						if (20 < b)
																						{
																							goto end_IL_04cd;
																						}
																						goto IL_09f8;
																					}
																					goto end_IL_04dd;
																					continue;
																					end_IL_04cd:
																					break;
																					IL_04cd:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0f26;
																			IL_0f42:
																			ptr2 += 8;
																			break;
																			IL_0f34:
																			num5++;
																			goto IL_0f42;
																			IL_0f26:
																			array2[num5] = 0;
																			goto IL_0f34;
																			continue;
																			end_IL_04dd:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_0f50:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_056b:
			while (true)
			{
				IL_056b_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0613_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0621_2:
							num5++;
							num = 83;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_04fd_2:
									byte b = *ptr2;
									while (true)
									{
										IL_04ed_2:
										ptr2++;
										while (true)
										{
											IL_04dd_2:
											if (b >= 1)
											{
												while (b <= 24)
												{
													while (true)
													{
														IL_04c0_2:
														if (12 >= b)
														{
															while (12 > b)
															{
																while (true)
																{
																	IL_04a0_2:
																	if (6 >= b)
																	{
																		while (true)
																		{
																			IL_0490_2:
																			if (6 > b)
																			{
																				while (true)
																				{
																					IL_0480_2:
																					if (3 < b)
																					{
																						while (true)
																						{
																							IL_0470_2:
																							if (4 >= b)
																							{
																								while (4 <= b)
																								{
																									while (true)
																									{
																										IL_0450_2:
																										array2[num5] = 0;
																										while (true)
																										{
																											IL_042b_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																											while (true)
																											{
																												IL_041f_2:
																												array3[num5] = null;
																												while (true)
																												{
																													IL_040f_2:
																													num5++;
																													while (true)
																													{
																														IL_03f6_2:
																														ptr2 += 8;
																														num = 245;
																														while (num != 245 && num == 1226)
																														{
																															switch (num)
																															{
																															case 67:
																																goto IL_03f6_2;
																															case 41:
																																goto IL_040f_2;
																															case 93:
																																goto IL_041f_2;
																															case 61:
																																goto IL_042b_2;
																															case 16:
																															case 121:
																																goto IL_0450_2;
																															case 165:
																																goto IL_0460_2;
																															case 175:
																															case 180:
																																goto IL_0470_2;
																															case 25:
																															case 213:
																																goto IL_0480_2;
																															case 84:
																																goto IL_0490_2;
																															case 184:
																																goto IL_04a0_2;
																															case 149:
																																goto IL_04b0_2;
																															case 229:
																																goto IL_04c0_2;
																															case 219:
																																goto IL_04cd_2;
																															case 3:
																																goto IL_04dd_2;
																															case 79:
																																goto IL_04ed_2;
																															case 152:
																															case 177:
																																goto IL_04fd_2;
																															case 142:
																															case 183:
																																goto IL_0508_2;
																															case 173:
																																goto IL_0516_2;
																															case 12:
																															case 26:
																																goto IL_0524_2;
																															case 63:
																																goto IL_0532_2;
																															case 144:
																															case 179:
																																goto IL_0540_2;
																															case 8:
																																goto IL_054e_2;
																															case 19:
																															case 90:
																																goto end_IL_0f50_2;
																															case 98:
																																goto IL_0613_2;
																															case 89:
																																goto IL_0621_2;
																															case 91:
																																goto IL_063d_2;
																															case 124:
																																goto IL_064b_2;
																															case 35:
																															case 62:
																																goto IL_0659_2;
																															case 127:
																																goto IL_0677_2;
																															case 178:
																																goto IL_0685_2;
																															case 31:
																																goto IL_0698_2;
																															case 22:
																																goto IL_06a3_2;
																															case 40:
																															case 82:
																																goto IL_06c8_2;
																															case 75:
																															case 135:
																																goto IL_06db_2;
																															case 108:
																																goto IL_0722_2;
																															case 49:
																															case 118:
																																goto IL_073e_2;
																															case 87:
																															case 117:
																																goto IL_074c_2;
																															case 36:
																																goto IL_0757_2;
																															case 11:
																															case 160:
																																goto IL_0767_2;
																															case 70:
																															case 196:
																																goto IL_077a_2;
																															case 45:
																																goto IL_07a3_2;
																															case 64:
																															case 199:
																																goto IL_07bc_2;
																															case 33:
																																goto IL_07ca_2;
																															case 1:
																															case 112:
																																goto IL_07d8_2;
																															case 97:
																																goto IL_07f0_2;
																															case 81:
																																goto IL_07fe_2;
																															case 80:
																																goto IL_080c_2;
																															case 205:
																																goto IL_081f_2;
																															case 99:
																															case 113:
																																goto IL_082d_2;
																															case 72:
																																goto IL_083b_2;
																															case 143:
																																goto IL_0853_2;
																															case 189:
																																goto IL_0861_2;
																															case 211:
																																goto IL_0874_2;
																															case 10:
																															case 218:
																																goto IL_0884_2;
																															case 88:
																																goto IL_08ad_2;
																															case 43:
																																goto IL_08bb_2;
																															case 34:
																															case 223:
																																goto IL_08ce_2;
																															case 110:
																															case 224:
																																goto IL_08ea_2;
																															case 148:
																																goto IL_0902_2;
																															case 104:
																																goto IL_0920_2;
																															case 128:
																																goto IL_0944_2;
																															case 115:
																																goto IL_095c_2;
																															case 233:
																																goto IL_096f_2;
																															case 51:
																															case 52:
																																goto IL_097a_2;
																															case 188:
																																goto IL_098e_2;
																															case 85:
																																goto IL_09cc_2;
																															case 96:
																																goto IL_09df_2;
																															case 86:
																															case 202:
																																goto IL_09ea_2;
																															case 190:
																																goto IL_09f8_2;
																															case 60:
																															case 114:
																																goto IL_0a06_2;
																															case 195:
																																goto IL_0a1b_2;
																															case 76:
																																goto IL_0a2e_2;
																															case 162:
																															case 164:
																																goto IL_0a3c_2;
																															case 141:
																																goto IL_0a50_2;
																															case 30:
																																goto IL_0a88_2;
																															case 18:
																																goto IL_0a9b_2;
																															case 161:
																																goto IL_0aa9_2;
																															case 77:
																															case 95:
																																goto IL_0ac0_2;
																															case 163:
																																goto IL_0b00_2;
																															case 65:
																																goto IL_0b14_2;
																															case 210:
																																goto IL_0b27_2;
																															case 94:
																															case 203:
																																goto IL_0b32_2;
																															case 167:
																																goto IL_0b5b_2;
																															case 122:
																																goto IL_0b69_2;
																															case 111:
																																goto IL_0b7c_2;
																															case 109:
																																goto IL_0b87_2;
																															case 92:
																															case 100:
																																goto IL_0b9a_2;
																															case 134:
																																goto IL_0ba8_2;
																															case 6:
																															case 236:
																																goto IL_0bb6_2;
																															case 47:
																																goto IL_0bf6_2;
																															case 235:
																																goto IL_0c0a_2;
																															case 126:
																															case 225:
																																goto IL_0c1d_2;
																															case 103:
																																goto IL_0c5d_2;
																															case 212:
																																goto IL_0c71_2;
																															case 14:
																																goto IL_0c84_2;
																															case 105:
																																goto IL_0c92_2;
																															case 207:
																															case 214:
																																goto IL_0ca0_2;
																															case 48:
																															case 220:
																																goto IL_0cab_2;
																															case 145:
																																goto IL_0cb9_2;
																															case 4:
																															case 101:
																																goto IL_0cc7_2;
																															case 138:
																																goto IL_0cda_2;
																															case 157:
																															case 197:
																																goto IL_0ce8_2;
																															case 237:
																																goto IL_0d28_2;
																															case 168:
																																goto IL_0d3c_2;
																															case 107:
																															case 193:
																																goto IL_0d4f_2;
																															case 204:
																																goto IL_0d8f_2;
																															case 227:
																																goto IL_0da3_2;
																															case 42:
																																goto IL_0db6_2;
																															case 221:
																																goto IL_0dc4_2;
																															case 13:
																															case 32:
																																goto IL_0ddb_2;
																															case 56:
																																goto IL_0e3d_2;
																															case 125:
																																goto IL_0e59_2;
																															case 137:
																																goto IL_0e67_2;
																															case 130:
																															case 158:
																																goto IL_0e75_2;
																															case 176:
																																goto IL_0e92_2;
																															case 133:
																																goto IL_0ee6_2;
																															case 206:
																																goto IL_0ef4_2;
																															case 0:
																															case 7:
																															case 9:
																															case 20:
																															case 21:
																															case 38:
																															case 44:
																															case 46:
																															case 50:
																															case 54:
																															case 55:
																															case 59:
																															case 66:
																															case 69:
																															case 71:
																															case 73:
																															case 102:
																															case 116:
																															case 129:
																															case 132:
																															case 140:
																															case 155:
																															case 159:
																															case 166:
																															case 169:
																															case 170:
																															case 174:
																															case 185:
																															case 186:
																															case 187:
																															case 192:
																															case 200:
																															case 201:
																															case 209:
																															case 216:
																															case 217:
																															case 222:
																															case 230:
																															case 232:
																															case 234:
																															case 238:
																																goto end_IL_0460_2;
																															case 74:
																																goto IL_0f26_2;
																															case 231:
																																goto IL_0f34_2;
																															case 106:
																																goto IL_0f42_2;
																															case 5:
																															case 15:
																															case 23:
																															case 24:
																															case 28:
																															case 29:
																															case 37:
																															case 58:
																															case 68:
																															case 78:
																															case 83:
																															case 119:
																															case 120:
																															case 150:
																															case 151:
																															case 153:
																															case 154:
																															case 171:
																															case 172:
																															case 181:
																															case 182:
																															case 191:
																															case 194:
																															case 198:
																															case 208:
																															case 215:
																																goto end_IL_03e3_2;
																															case 226:
																																ptr2 = ptr;
																																goto end_IL_03e3_2;
																															case 123:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PermissionSetEnumeratorInternalEnumSubcategoriesFlags.IConvertibleGetUrlsForObject);
																																goto case 226;
																															case 39:
																																array7[0] = this;
																																goto case 123;
																															case 2:
																																array7 = new object[5];
																																goto case 39;
																															case 131:
																																array6 = new long[4];
																																goto case 2;
																															case 27:
																																array5 = new int[6];
																																goto case 131;
																															case 17:
																																array4 = new int[4];
																																goto case 27;
																															case 53:
																																array3 = new object[4];
																																goto case 17;
																															case 57:
																															case 139:
																																array2 = new byte[4];
																																goto case 53;
																															case 228:
																																num3 = num2 * 4;
																																num = 139;
																																goto case 57;
																															case 146:
																																num2 = 1;
																																goto case 228;
																															case 147:
																																goto end_IL_0579;
																															case 136:
																															case 156:
																																return;
																															}
																															continue;
																															end_IL_03e3_2:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto end_IL_04b0_2;
																									continue;
																									end_IL_0460_2:
																									break;
																									IL_0460_2:;
																								}
																								break;
																							}
																							goto IL_0a9b_2;
																							IL_0b00_2:
																							array2[num5 - 2] = 0;
																							goto IL_0b14_2;
																							IL_0a9b_2:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0aa9_2;
																							IL_0aa9_2:
																							if (5 > b)
																							{
																								break;
																							}
																							num = 77;
																							goto IL_0ac0_2;
																							IL_0b14_2:
																							num5--;
																							goto end_IL_04b0_2;
																							IL_0ac0_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0b00_2;
																						}
																						break;
																					}
																					goto IL_0b27_2;
																					IL_0c0a_2:
																					num5--;
																					goto end_IL_04b0_2;
																					IL_0b27_2:
																					if (3 <= b)
																					{
																						goto IL_0b32_2;
																					}
																					goto IL_0b7c_2;
																					IL_0b32_2:
																					reference = ref array5[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_0b5b_2;
																					IL_0b5b_2:
																					ptr2 += 8;
																					goto IL_0b69_2;
																					IL_0b69_2:
																					num5--;
																					goto end_IL_04b0_2;
																					IL_0b7c_2:
																					if (1 >= b)
																					{
																						goto IL_0b87_2;
																					}
																					goto IL_0b9a_2;
																					IL_0b87_2:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0b9a_2:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0ba8_2;
																					IL_0ba8_2:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0bb6_2;
																					IL_0bb6_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_0bf6_2;
																					IL_0bf6_2:
																					array2[num5 - 2] = 0;
																					goto IL_0c0a_2;
																				}
																				break;
																			}
																			goto IL_0c1d_2;
																			IL_0c71_2:
																			num5--;
																			goto end_IL_04b0_2;
																			IL_0c1d_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0c5d_2;
																			IL_0c5d_2:
																			array2[num5 - 2] = 0;
																			goto IL_0c71_2;
																		}
																		break;
																	}
																	goto IL_0c84_2;
																	IL_0ee6_2:
																	num5--;
																	goto IL_0ef4_2;
																	IL_0c84_2:
																	if (9 >= b)
																	{
																		goto IL_0c92_2;
																	}
																	goto IL_0db6_2;
																	IL_0c92_2:
																	if (9 > b)
																	{
																		goto IL_0ca0_2;
																	}
																	goto IL_0d4f_2;
																	IL_0ca0_2:
																	if (7 < b)
																	{
																		goto IL_0cab_2;
																	}
																	goto IL_0cda_2;
																	IL_0cab_2:
																	if (8 < b)
																	{
																		break;
																	}
																	goto IL_0cb9_2;
																	IL_0cb9_2:
																	if (8 > b)
																	{
																		break;
																	}
																	goto IL_0cc7_2;
																	IL_0cc7_2:
																	num5--;
																	goto end_IL_04b0_2;
																	IL_0cda_2:
																	if (7 > b)
																	{
																		break;
																	}
																	goto IL_0ce8_2;
																	IL_0ce8_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_0d28_2;
																	IL_0d28_2:
																	array2[num5 - 2] = 0;
																	goto IL_0d3c_2;
																	IL_0d3c_2:
																	num5--;
																	goto end_IL_04b0_2;
																	IL_0d4f_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_0d8f_2;
																	IL_0d8f_2:
																	array2[num5 - 2] = 0;
																	goto IL_0da3_2;
																	IL_0da3_2:
																	num5--;
																	goto end_IL_04b0_2;
																	IL_0db6_2:
																	if (10 >= b)
																	{
																		goto IL_0dc4_2;
																	}
																	goto IL_0e59_2;
																	IL_0dc4_2:
																	if (10 > b)
																	{
																		break;
																	}
																	num = 13;
																	goto IL_0ddb_2;
																	IL_0ef4_2:
																	ptr2 += 8;
																	goto end_IL_04b0_2;
																	IL_0ddb_2:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0e3d_2;
																	IL_0e3d_2:
																	num5 -= 2;
																	num = 154;
																	goto end_IL_04b0_2;
																	IL_0e59_2:
																	if (11 < b)
																	{
																		num = 232;
																		break;
																	}
																	goto IL_0e67_2;
																	IL_0e67_2:
																	if (11 > b)
																	{
																		break;
																	}
																	goto IL_0e75_2;
																	IL_0e75_2:
																	array2[num5 - 2] = 0;
																	num = 176;
																	goto IL_0e92_2;
																	IL_0e92_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																	goto IL_0ee6_2;
																}
																goto end_IL_04cd_2;
																continue;
																end_IL_04b0_2:
																break;
																IL_04b0_2:;
															}
															break;
														}
														goto IL_0508_2;
														IL_0a2e_2:
														if (19 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_0a3c_2;
														IL_0508_2:
														if (18 >= b)
														{
															goto IL_0516_2;
														}
														num = 118;
														goto IL_073e_2;
														IL_0516_2:
														if (18 > b)
														{
															goto IL_0524_2;
														}
														goto IL_06db_2;
														IL_0524_2:
														if (15 >= b)
														{
															goto IL_0532_2;
														}
														goto IL_0698_2;
														IL_0532_2:
														if (15 > b)
														{
															goto IL_0540_2;
														}
														goto IL_077a_2;
														IL_0540_2:
														if (13 >= b)
														{
															goto IL_054e_2;
														}
														goto IL_063d_2;
														IL_054e_2:
														if (13 > b)
														{
															goto end_IL_04cd_2;
														}
														goto end_IL_0f50_2;
														IL_063d_2:
														if (14 < b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_064b_2;
														IL_064b_2:
														if (14 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_0659_2;
														IL_0659_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_0677_2;
														IL_0677_2:
														ptr2 += 8;
														goto IL_0685_2;
														IL_0685_2:
														num5--;
														break;
														IL_077a_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_07a3_2;
														IL_07a3_2:
														array2[num5 - 1] = 5;
														break;
														IL_0698_2:
														if (16 >= b)
														{
															goto IL_06a3_2;
														}
														num = 82;
														goto IL_06c8_2;
														IL_06a3_2:
														if (16 > b)
														{
															goto end_IL_04cd_2;
														}
														num = 110;
														goto IL_08ea_2;
														IL_0a88_2:
														ptr2 += 8;
														break;
														IL_08ea_2:
														array2[num5] = array2[num5 - 1];
														goto IL_0902_2;
														IL_0902_2:
														array4[num5 - 0] = array4[num5 - 1];
														goto IL_0920_2;
														IL_0920_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0944_2;
														IL_0944_2:
														array3[num5] = array3[num5 - 1];
														goto IL_095c_2;
														IL_095c_2:
														num5++;
														break;
														IL_0a50_2:
														array3[num5 - 1] = ((delegate*<string[], string>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
														goto IL_0a88_2;
														IL_06c8_2:
														if (17 < b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_081f_2;
														IL_081f_2:
														if (17 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_082d_2;
														IL_082d_2:
														array2[num5] = 5;
														goto IL_083b_2;
														IL_083b_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_0853_2;
														IL_0853_2:
														num5++;
														goto IL_0861_2;
														IL_0861_2:
														ptr2 += 8;
														break;
														IL_06db_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														num = 108;
														goto IL_0722_2;
														IL_0722_2:
														num5 -= 3;
														break;
														IL_0a3c_2:
														array2[num5 - 1] = 5;
														goto IL_0a50_2;
														IL_073e_2:
														if (21 < b)
														{
															goto IL_074c_2;
														}
														goto IL_096f_2;
														IL_074c_2:
														if (23 >= b)
														{
															goto IL_0757_2;
														}
														goto IL_0767_2;
														IL_0757_2:
														if (23 > b)
														{
															goto IL_07bc_2;
														}
														goto IL_0884_2;
														IL_07bc_2:
														if (22 < b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_07ca_2;
														IL_07ca_2:
														if (22 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_07d8_2;
														IL_07d8_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_07f0_2;
														IL_07f0_2:
														array2[num5] = 5;
														goto IL_07fe_2;
														IL_07fe_2:
														num5++;
														goto IL_080c_2;
														IL_080c_2:
														ptr2 += 8;
														break;
														IL_0884_2:
														((delegate*<UnityEngine.Object, void>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((Class163)array3[num5 - 1]);
														goto IL_08ad_2;
														IL_08ad_2:
														num5--;
														goto IL_08bb_2;
														IL_08bb_2:
														ptr2 += 8;
														break;
														IL_0767_2:
														if (24 < b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_0874_2;
														IL_0874_2:
														if (24 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_08ce_2;
														IL_08ce_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														break;
														IL_096f_2:
														if (21 <= b)
														{
															goto IL_097a_2;
														}
														goto IL_09df_2;
														IL_097a_2:
														array2[num5 - 1] = 0;
														goto IL_098e_2;
														IL_098e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (((delegate*<string, bool>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]) ? 1 : 0);
														goto IL_09cc_2;
														IL_09cc_2:
														ptr2 += 8;
														break;
														IL_09df_2:
														if (19 < b)
														{
															goto IL_09ea_2;
														}
														goto IL_0a2e_2;
														IL_09ea_2:
														if (20 < b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_09f8_2;
														IL_09f8_2:
														if (20 > b)
														{
															goto end_IL_04cd_2;
														}
														goto IL_0a06_2;
														IL_0a06_2:
														((delegate*<void>)RequiresIMethodMessage[*(int*)(ptr2 + num3)])();
														goto IL_0a1b_2;
														IL_0a1b_2:
														ptr2 += 8;
														break;
													}
													goto end_IL_04dd_2;
													continue;
													end_IL_04cd_2:
													break;
													IL_04cd_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_0f26_2;
											IL_0f42_2:
											ptr2 += 8;
											break;
											IL_0f34_2:
											num5++;
											goto IL_0f42_2;
											IL_0f26_2:
											array2[num5] = 0;
											goto IL_0f34_2;
											continue;
											end_IL_04dd_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_0f50_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_056b_2;
					}
					continue;
					end_IL_0579:
					break;
				}
				break;
			}
		}
	}

	public Class163()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NodePinvokeOLE.CommonStartMenuGenerate);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f8:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02db:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02cb:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02bb:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02ab:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_0298:
																											if (10 <= b)
																											{
																												num = 154;
																												while (true)
																												{
																													if (num != 154)
																													{
																														if (num != 1135)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 98:
																															goto IL_0298;
																														case 15:
																														case 23:
																															goto IL_02ab;
																														case 118:
																															goto IL_02bb;
																														case 81:
																															goto IL_02cb;
																														case 3:
																															goto IL_02db;
																														case 51:
																															goto end_IL_02db;
																														case 119:
																															goto IL_02f8;
																														case 88:
																															goto end_IL_02f8;
																														case 45:
																														case 77:
																															goto end_IL_0308;
																														case 55:
																															goto IL_0323;
																														case 70:
																															goto IL_0333;
																														case 87:
																															goto IL_0341;
																														case 0:
																														case 109:
																															goto IL_0354;
																														case 72:
																														case 113:
																															goto IL_036c;
																														case 21:
																															goto IL_037a;
																														case 34:
																														case 35:
																															goto IL_0388;
																														case 125:
																															goto IL_03d5;
																														case 25:
																															goto IL_03e9;
																														case 48:
																														case 135:
																															goto IL_03fc;
																														case 69:
																															goto IL_040a;
																														case 62:
																														case 115:
																															goto IL_0418;
																														case 122:
																															goto IL_0423;
																														case 120:
																														case 123:
																															goto IL_0431;
																														case 95:
																															goto IL_043f;
																														case 27:
																														case 52:
																															goto IL_044a;
																														case 37:
																															goto IL_0463;
																														case 102:
																															goto IL_0471;
																														case 116:
																															goto IL_0492;
																														case 53:
																															goto IL_04a0;
																														case 7:
																														case 30:
																															goto IL_04ae;
																														case 112:
																															goto IL_04d7;
																														case 18:
																														case 97:
																															goto end_IL_0285;
																														case 127:
																															goto IL_050e;
																														case 16:
																															goto IL_051c;
																														case 9:
																															goto IL_0538;
																														case 22:
																														case 94:
																															goto IL_0543;
																														case 91:
																															goto IL_0556;
																														case 65:
																														case 129:
																															goto IL_0561;
																														case 56:
																															goto IL_056f;
																														case 78:
																														case 117:
																															goto IL_057d;
																														case 107:
																															goto IL_058b;
																														case 104:
																															goto IL_05a3;
																														case 28:
																															goto IL_05b1;
																														case 121:
																														case 138:
																															goto IL_05c4;
																														case 46:
																															goto IL_0603;
																														case 50:
																														case 140:
																															goto IL_0616;
																														case 54:
																															goto IL_0656;
																														case 12:
																															goto IL_066a;
																														case 143:
																															goto IL_067d;
																														case 11:
																														case 14:
																															goto IL_068b;
																														case 84:
																															goto IL_06b4;
																														case 108:
																															goto IL_06c2;
																														case 146:
																															goto IL_06d5;
																														case 57:
																															goto IL_06e8;
																														case 4:
																															goto IL_06f6;
																														case 39:
																															goto IL_0719;
																														case 42:
																															goto IL_0723;
																														case 6:
																															goto IL_0731;
																														case 10:
																														case 17:
																															goto IL_0744;
																														case 90:
																															goto IL_0784;
																														case 26:
																															goto IL_0798;
																														case 137:
																															goto IL_07ab;
																														case 5:
																														case 38:
																															goto IL_07b6;
																														case 141:
																															goto IL_07c4;
																														case 93:
																															goto IL_07d7;
																														case 103:
																														case 142:
																															goto IL_07e2;
																														case 128:
																															goto IL_07fe;
																														case 64:
																															goto IL_0809;
																														case 124:
																														case 134:
																															goto IL_0814;
																														case 61:
																															goto IL_0876;
																														case 8:
																														case 13:
																														case 31:
																														case 36:
																														case 41:
																														case 43:
																														case 58:
																														case 67:
																														case 68:
																														case 71:
																														case 74:
																														case 79:
																														case 80:
																														case 82:
																														case 83:
																														case 85:
																														case 86:
																														case 89:
																														case 92:
																														case 96:
																														case 99:
																														case 106:
																														case 111:
																														case 114:
																														case 132:
																														case 136:
																															goto end_IL_02e8;
																														case 1:
																														case 19:
																														case 20:
																														case 29:
																														case 44:
																														case 47:
																														case 59:
																														case 60:
																														case 66:
																														case 73:
																														case 100:
																														case 105:
																														case 110:
																														case 126:
																														case 131:
																														case 133:
																														case 144:
																														case 147:
																															goto end_IL_0318;
																														case 24:
																															goto end_IL_0899;
																														case 2:
																															goto end_IL_08ac;
																														case 40:
																															goto end_IL_08b6;
																														case 32:
																															goto end_IL_08c1;
																														case 130:
																														case 145:
																															goto end_IL_08d1;
																														case 33:
																															goto end_IL_08e1;
																														case 63:
																														case 101:
																															goto end_IL_08f1;
																														case 75:
																															goto end_IL_0901;
																														case 76:
																															goto end_IL_0911;
																														case 49:
																														case 139:
																															goto IL_092c;
																														}
																														continue;
																													}
																													goto IL_06e8;
																													IL_0723:
																													num5++;
																													goto IL_0731;
																													IL_0731:
																													ptr2 += 8;
																													goto end_IL_0318;
																													IL_06e8:
																													array[num5] = 0;
																													goto IL_06f6;
																													IL_06f6:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_0719;
																													IL_0719:
																													array2[num5] = null;
																													goto IL_0723;
																													continue;
																													end_IL_0285:
																													break;
																												}
																												break;
																											}
																											goto IL_0333;
																											IL_0333:
																											if (9 < b)
																											{
																												goto end_IL_02e8;
																											}
																											goto IL_0341;
																											IL_0341:
																											if (9 <= b)
																											{
																												goto end_IL_0318;
																											}
																											goto end_IL_02e8;
																										}
																										break;
																									}
																									goto IL_036c;
																									IL_03e9:
																									num5--;
																									goto end_IL_0318;
																									IL_036c:
																									if (11 < b)
																									{
																										goto end_IL_02e8;
																									}
																									goto IL_037a;
																									IL_037a:
																									if (11 > b)
																									{
																										goto end_IL_02e8;
																									}
																									goto IL_0388;
																									IL_0388:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									num = 125;
																									goto IL_03d5;
																									IL_03d5:
																									array[num5 - 2] = 0;
																									goto IL_03e9;
																								}
																								break;
																							}
																							goto IL_0744;
																							IL_0798:
																							num5--;
																							goto end_IL_0318;
																							IL_0744:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0784;
																							IL_0784:
																							array[num5 - 2] = 0;
																							goto IL_0798;
																						}
																						break;
																					}
																					goto IL_07ab;
																					IL_0876:
																					num5 -= 2;
																					goto end_IL_0318;
																					IL_07ab:
																					if (14 < b)
																					{
																						goto IL_07b6;
																					}
																					goto IL_07d7;
																					IL_07b6:
																					if (15 < b)
																					{
																						goto end_IL_02e8;
																					}
																					goto IL_07c4;
																					IL_07c4:
																					if (15 > b)
																					{
																					}
																					goto end_IL_02e8;
																					IL_07d7:
																					if (14 <= b)
																					{
																						goto IL_07e2;
																					}
																					goto IL_07fe;
																					IL_07e2:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0318;
																					IL_07fe:
																					if (13 < b)
																					{
																						goto end_IL_02e8;
																					}
																					goto IL_0809;
																					IL_0809:
																					if (13 > b)
																					{
																						goto end_IL_02e8;
																					}
																					goto IL_0814;
																					IL_0814:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0876;
																				}
																				goto IL_04f0;
																			}
																			goto IL_0323;
																			IL_0603:
																			num5 -= 3;
																			goto end_IL_0318;
																			IL_0323:
																			if (8 <= b)
																			{
																				goto IL_0354;
																			}
																			goto IL_03fc;
																			IL_03fc:
																			if (4 >= b)
																			{
																				goto IL_040a;
																			}
																			goto IL_0538;
																			IL_040a:
																			if (4 > b)
																			{
																				goto IL_0418;
																			}
																			goto IL_04f0;
																			IL_0418:
																			if (2 >= b)
																			{
																				goto IL_0423;
																			}
																			goto IL_0492;
																			IL_0423:
																			if (2 > b)
																			{
																				goto IL_0431;
																			}
																			goto IL_0616;
																			IL_0431:
																			if (1 < b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_043f;
																			IL_043f:
																			if (1 > b)
																			{
																				num = 31;
																				goto end_IL_02e8;
																			}
																			goto IL_044a;
																			IL_044a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0463;
																			IL_0463:
																			array[num5] = 0;
																			goto IL_0471;
																			IL_0471:
																			num5++;
																			goto IL_06d5;
																			IL_06d5:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_0354:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0318;
																			IL_0616:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0656;
																			IL_0656:
																			array[num5 - 2] = 0;
																			goto IL_066a;
																			IL_066a:
																			num5--;
																			goto end_IL_0318;
																			IL_0492:
																			if (3 < b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_04a0;
																			IL_04a0:
																			if (3 > b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_04ae;
																			IL_04ae:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04d7;
																			IL_04d7:
																			array[num5 - 1] = 5;
																			goto end_IL_0318;
																			IL_04f0:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_050e;
																			IL_050e:
																			ptr2 += 8;
																			goto IL_051c;
																			IL_051c:
																			num5--;
																			num = 66;
																			goto end_IL_0318;
																			IL_0538:
																			if (6 < b)
																			{
																				goto IL_0543;
																			}
																			goto IL_0556;
																			IL_0543:
																			if (7 < b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_067d;
																			IL_067d:
																			if (7 > b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_068b;
																			IL_068b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06b4;
																			IL_06b4:
																			ptr2 += 8;
																			goto IL_06c2;
																			IL_06c2:
																			num5--;
																			goto end_IL_0318;
																			IL_0556:
																			if (6 > b)
																			{
																				goto IL_0561;
																			}
																			goto IL_05c4;
																			IL_0561:
																			if (5 < b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_056f;
																			IL_056f:
																			if (5 > b)
																			{
																				goto end_IL_02e8;
																			}
																			goto IL_057d;
																			IL_057d:
																			array[num5] = 5;
																			goto IL_058b;
																			IL_058b:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_05a3;
																			IL_05a3:
																			num5++;
																			goto IL_05b1;
																			IL_05b1:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_05c4:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0603;
																			continue;
																			end_IL_02db:
																			break;
																		}
																		continue;
																		end_IL_02e8:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0318;
																continue;
																end_IL_02f8:
																break;
															}
															continue;
															end_IL_0308:
															break;
														}
														continue;
														end_IL_0318:
														break;
													}
													continue;
												}
												goto IL_092c;
												IL_092c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0899:
												break;
											}
											continue;
											end_IL_08ac:
											break;
										}
										continue;
										end_IL_08b6:
										break;
									}
									continue;
									end_IL_08c1:
									break;
								}
								continue;
								end_IL_08d1:
								break;
							}
							continue;
							end_IL_08e1:
							break;
						}
						continue;
						end_IL_08f1:
						break;
					}
					continue;
					end_IL_0901:
					break;
				}
				continue;
				end_IL_0911:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IidParameterIndexFieldHandle.QueueDebugViewSetLength);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0390:
														byte b = *ptr2;
														while (true)
														{
															IL_0380:
															ptr2++;
															while (true)
															{
																IL_0370:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0350:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0333:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_0323:
																								if (4 > b)
																								{
																									while (true)
																									{
																										IL_0313:
																										if (2 >= b)
																										{
																											while (true)
																											{
																												IL_0303:
																												if (2 > b)
																												{
																													while (1 >= b)
																													{
																														while (true)
																														{
																															IL_02e0:
																															if (1 > b)
																															{
																																num = 172;
																																while (num != 172 && num == 1153)
																																{
																																	switch (num)
																																	{
																																	case 15:
																																		goto IL_02e0;
																																	case 76:
																																	case 110:
																																		goto IL_02f3;
																																	case 22:
																																		goto IL_0303;
																																	case 9:
																																	case 122:
																																		goto IL_0313;
																																	case 75:
																																		goto IL_0323;
																																	case 14:
																																	case 106:
																																		goto IL_0333;
																																	case 136:
																																		goto IL_0340;
																																	case 162:
																																		goto IL_0350;
																																	case 78:
																																		goto IL_0360;
																																	case 50:
																																		goto IL_0370;
																																	case 127:
																																		goto IL_0380;
																																	case 40:
																																	case 101:
																																		goto IL_0390;
																																	case 81:
																																	case 113:
																																		goto IL_039b;
																																	case 12:
																																		goto IL_03a6;
																																	case 95:
																																	case 114:
																																		goto IL_03b9;
																																	case 118:
																																	case 119:
																																		goto IL_03d4;
																																	case 54:
																																	case 73:
																																		goto IL_03df;
																																	case 80:
																																		goto IL_03ed;
																																	case 42:
																																	case 79:
																																		goto IL_03fb;
																																	case 17:
																																		goto IL_0413;
																																	case 31:
																																	case 92:
																																		goto IL_0421;
																																	case 124:
																																		goto IL_044f;
																																	case 96:
																																		goto IL_045d;
																																	case 141:
																																		goto IL_046d;
																																	case 143:
																																		goto IL_047d;
																																	case 156:
																																		goto IL_0490;
																																	case 68:
																																	case 140:
																																		goto IL_049e;
																																	case 134:
																																		goto IL_04ac;
																																	case 56:
																																		goto IL_04c4;
																																	case 16:
																																		goto IL_04d2;
																																	case 39:
																																	case 157:
																																		goto IL_04e5;
																																	case 77:
																																		goto IL_0503;
																																	case 158:
																																		goto IL_0513;
																																	case 36:
																																		goto IL_0521;
																																	case 161:
																																		goto IL_0534;
																																	case 116:
																																	case 165:
																																		goto IL_0547;
																																	case 55:
																																		goto IL_0586;
																																	case 5:
																																	case 19:
																																		goto IL_0599;
																																	case 121:
																																		goto IL_05d9;
																																	case 49:
																																		goto IL_05ed;
																																	case 52:
																																	case 117:
																																		goto IL_0609;
																																	case 10:
																																		goto IL_0617;
																																	case 41:
																																	case 137:
																																		goto IL_0625;
																																	case 153:
																																		goto IL_064e;
																																	case 164:
																																		goto IL_0667;
																																	case 13:
																																	case 70:
																																		goto IL_0675;
																																	case 148:
																																		goto IL_0683;
																																	case 65:
																																	case 160:
																																		goto IL_068e;
																																	case 21:
																																		goto IL_06a1;
																																	case 163:
																																		goto IL_06af;
																																	case 7:
																																	case 48:
																																		goto IL_06bd;
																																	case 126:
																																		goto IL_06cb;
																																	case 66:
																																		goto IL_06ef;
																																	case 144:
																																		goto IL_06fd;
																																	case 93:
																																		goto IL_0710;
																																	case 109:
																																		goto IL_071b;
																																	case 63:
																																	case 69:
																																		goto IL_0729;
																																	case 61:
																																		goto IL_0745;
																																	case 43:
																																		goto IL_0753;
																																	case 71:
																																		goto IL_0766;
																																	case 130:
																																	case 155:
																																		goto IL_0774;
																																	case 88:
																																		goto IL_0782;
																																	case 35:
																																	case 83:
																																		goto IL_078d;
																																	case 112:
																																		goto IL_07d1;
																																	case 27:
																																		goto IL_07e5;
																																	case 64:
																																	case 142:
																																		goto IL_0801;
																																	case 51:
																																		goto IL_080f;
																																	case 84:
																																	case 104:
																																		goto IL_081d;
																																	case 87:
																																		goto IL_082b;
																																	case 89:
																																		goto IL_084e;
																																	case 111:
																																		goto IL_0858;
																																	case 11:
																																		goto IL_0866;
																																	case 38:
																																		goto IL_0879;
																																	case 2:
																																		goto IL_0887;
																																	case 67:
																																	case 125:
																																		goto IL_0895;
																																	case 33:
																																		goto IL_08d5;
																																	case 34:
																																		goto IL_08e9;
																																	case 32:
																																	case 97:
																																		goto IL_08fc;
																																	case 132:
																																		goto IL_095e;
																																	case 1:
																																	case 3:
																																	case 4:
																																	case 6:
																																	case 8:
																																	case 29:
																																	case 30:
																																	case 37:
																																	case 58:
																																	case 60:
																																	case 72:
																																	case 74:
																																	case 82:
																																	case 85:
																																	case 90:
																																	case 100:
																																	case 103:
																																	case 105:
																																	case 107:
																																	case 128:
																																	case 129:
																																	case 131:
																																	case 133:
																																	case 135:
																																	case 145:
																																	case 146:
																																	case 147:
																																	case 151:
																																		goto end_IL_02cd;
																																	case 18:
																																	case 20:
																																	case 23:
																																	case 25:
																																	case 26:
																																	case 44:
																																	case 45:
																																	case 53:
																																	case 57:
																																	case 59:
																																	case 62:
																																	case 86:
																																	case 94:
																																	case 102:
																																	case 115:
																																	case 120:
																																	case 123:
																																	case 149:
																																	case 152:
																																	case 159:
																																		goto end_IL_0340;
																																	case 139:
																																		goto end_IL_0981;
																																	case 108:
																																		goto end_IL_0994;
																																	case 46:
																																		goto end_IL_099e;
																																	case 28:
																																		goto end_IL_09a9;
																																	case 47:
																																	case 138:
																																		goto end_IL_09b9;
																																	case 24:
																																		goto end_IL_09c9;
																																	case 0:
																																	case 91:
																																		goto end_IL_09d9;
																																	case 98:
																																		goto end_IL_09e9;
																																	case 99:
																																		goto end_IL_09f9;
																																	case 150:
																																	case 154:
																																		goto IL_0a14;
																																	}
																																	continue;
																																	end_IL_02cd:
																																	break;
																																}
																																break;
																															}
																															goto IL_03b9;
																															IL_045d:
																															num5++;
																															goto IL_047d;
																															IL_047d:
																															ptr2 += 8;
																															goto end_IL_0340;
																															IL_03b9:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															goto IL_044f;
																															IL_044f:
																															array[num5] = 0;
																															goto IL_045d;
																														}
																														break;
																														IL_02f3:;
																													}
																													break;
																												}
																												goto IL_0599;
																												IL_05ed:
																												num5--;
																												goto end_IL_0340;
																												IL_0599:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_05d9;
																												IL_05d9:
																												array[num5 - 2] = 0;
																												goto IL_05ed;
																											}
																											break;
																										}
																										num = 117;
																										goto IL_0609;
																										IL_0625:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_064e;
																										IL_064e:
																										array[num5 - 1] = 5;
																										goto end_IL_0340;
																										IL_0609:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_0617;
																										IL_0617:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0625;
																									}
																									break;
																								}
																								goto IL_04e5;
																								IL_0534:
																								num5--;
																								goto end_IL_0340;
																								IL_04e5:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_0503;
																								IL_0503:
																								ptr2 += 8;
																								goto IL_0534;
																							}
																							break;
																						}
																						goto IL_039b;
																						IL_0521:
																						num5--;
																						goto end_IL_0340;
																						IL_039b:
																						if (6 >= b)
																						{
																							goto IL_03a6;
																						}
																						goto IL_03d4;
																						IL_03a6:
																						if (6 > b)
																						{
																							goto IL_046d;
																						}
																						goto IL_0547;
																						IL_046d:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0490;
																						IL_0490:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_049e;
																						IL_049e:
																						array[num5] = 5;
																						goto IL_04ac;
																						IL_04ac:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_04c4;
																						IL_04c4:
																						num5++;
																						goto IL_04d2;
																						IL_04d2:
																						ptr2 += 8;
																						goto end_IL_0340;
																						IL_0547:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0586;
																						IL_0586:
																						num5 -= 3;
																						goto end_IL_0340;
																						IL_03d4:
																						if (7 < b)
																						{
																							goto IL_03df;
																						}
																						goto IL_0413;
																						IL_03df:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_03ed;
																						IL_03ed:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_03fb;
																						IL_03fb:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0340;
																						IL_0413:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0421;
																						IL_0421:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0513;
																						IL_0513:
																						ptr2 += 8;
																						goto IL_0521;
																					}
																					goto end_IL_0360;
																					continue;
																					end_IL_0340:
																					break;
																					IL_0340:;
																				}
																				break;
																			}
																			goto IL_0667;
																			IL_08fc:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_095e;
																			IL_0667:
																			if (13 < b)
																			{
																				goto IL_0675;
																			}
																			goto IL_0766;
																			IL_0675:
																			if (15 >= b)
																			{
																				goto IL_0683;
																			}
																			goto IL_0710;
																			IL_0683:
																			if (15 <= b)
																			{
																				goto IL_068e;
																			}
																			goto IL_06a1;
																			IL_068e:
																			num5--;
																			break;
																			IL_06a1:
																			if (14 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_06af;
																			IL_06af:
																			if (14 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_06bd;
																			IL_06bd:
																			array[num5] = 0;
																			goto IL_06cb;
																			IL_06cb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)SameDomainByteArray[*(int*)(ptr2 + num3)])();
																			goto IL_06ef;
																			IL_06ef:
																			num5++;
																			goto IL_06fd;
																			IL_06fd:
																			ptr2 += 8;
																			break;
																			IL_0710:
																			if (16 >= b)
																			{
																				goto IL_071b;
																			}
																			goto IL_0745;
																			IL_071b:
																			if (16 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0729;
																			IL_0729:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0745:
																			if (17 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0753;
																			IL_0753:
																			if (17 <= b)
																			{
																			}
																			goto end_IL_0360;
																			IL_0766:
																			if (13 > b)
																			{
																				goto IL_0774;
																			}
																			goto IL_08fc;
																			IL_0774:
																			if (11 >= b)
																			{
																				goto IL_0782;
																			}
																			goto IL_0879;
																			IL_0782:
																			if (11 <= b)
																			{
																				goto IL_078d;
																			}
																			num = 64;
																			goto IL_0801;
																			IL_078d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07d1;
																			IL_07d1:
																			array[num5 - 2] = 0;
																			goto IL_07e5;
																			IL_07e5:
																			num5--;
																			break;
																			IL_095e:
																			num5 -= 2;
																			break;
																			IL_0801:
																			if (10 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_080f;
																			IL_080f:
																			if (10 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_081d;
																			IL_081d:
																			array[num5] = 0;
																			goto IL_082b;
																			IL_082b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_084e;
																			IL_084e:
																			array2[num5] = null;
																			goto IL_0858;
																			IL_0858:
																			num5++;
																			goto IL_0866;
																			IL_0866:
																			ptr2 += 8;
																			break;
																			IL_0879:
																			if (12 < b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0887;
																			IL_0887:
																			if (12 > b)
																			{
																				goto end_IL_0360;
																			}
																			goto IL_0895;
																			IL_0895:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_08d5;
																			IL_08d5:
																			array[num5 - 2] = 0;
																			goto IL_08e9;
																			IL_08e9:
																			num5--;
																			break;
																		}
																		goto end_IL_0370;
																		continue;
																		end_IL_0360:
																		break;
																		IL_0360:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0370:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a14;
												IL_0a14:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0981:
												break;
											}
											continue;
											end_IL_0994:
											break;
										}
										continue;
										end_IL_099e:
										break;
									}
									continue;
									end_IL_09a9:
									break;
								}
								continue;
								end_IL_09b9:
								break;
							}
							continue;
							end_IL_09c9:
							break;
						}
						continue;
						end_IL_09d9:
						break;
					}
					continue;
					end_IL_09e9:
					break;
				}
				continue;
				end_IL_09f9:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 19;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SerializationEventsWhitespace.getUrigetInvalidCultureName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 95;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0281:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_0264:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_0254:
																							if (8 >= b)
																							{
																								while (true)
																								{
																									IL_0244:
																									if (8 > b)
																									{
																										while (true)
																										{
																											IL_0234:
																											if (6 < b)
																											{
																												while (7 >= b)
																												{
																													while (7 <= b)
																													{
																														while (true)
																														{
																															IL_0204:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_01df:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																while (true)
																																{
																																	IL_01ca:
																																	array2[num5] = null;
																																	num = 106;
																																	while (true)
																																	{
																																		if (num != 106)
																																		{
																																			if (num != 1087)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 9:
																																				goto IL_01ca;
																																			case 14:
																																				goto IL_01df;
																																			case 40:
																																			case 87:
																																				goto IL_0204;
																																			case 66:
																																				goto IL_0214;
																																			case 24:
																																				goto IL_0224;
																																			case 43:
																																				goto IL_0234;
																																			case 31:
																																				goto IL_0244;
																																			case 81:
																																				goto IL_0254;
																																			case 3:
																																				goto IL_0264;
																																			case 80:
																																				goto IL_0271;
																																			case 88:
																																				goto IL_0281;
																																			case 12:
																																				goto end_IL_0281;
																																			case 30:
																																			case 58:
																																				goto end_IL_0291;
																																			case 39:
																																				goto IL_02ac;
																																			case 29:
																																			case 59:
																																				goto IL_02b7;
																																			case 37:
																																			case 67:
																																				goto IL_02cf;
																																			case 82:
																																				goto IL_02eb;
																																			case 27:
																																				goto IL_02f6;
																																			case 35:
																																			case 46:
																																				goto IL_0312;
																																			case 23:
																																				goto IL_0320;
																																			case 49:
																																			case 65:
																																				goto IL_032e;
																																			case 50:
																																			case 83:
																																				goto IL_034a;
																																			case 18:
																																				goto IL_0358;
																																			case 52:
																																				goto IL_037c;
																																			case 16:
																																				goto IL_038a;
																																			case 70:
																																			case 86:
																																				goto IL_039d;
																																			case 90:
																																				goto IL_03b0;
																																			case 10:
																																			case 22:
																																				goto IL_03be;
																																			case 54:
																																				goto IL_042c;
																																			case 21:
																																				goto IL_043f;
																																			case 84:
																																				goto IL_044d;
																																			case 93:
																																				goto IL_0460;
																																			case 25:
																																				goto IL_046b;
																																			case 20:
																																				goto IL_0479;
																																			case 33:
																																			case 56:
																																				goto IL_0487;
																																			case 53:
																																				goto IL_04b0;
																																			case 68:
																																				goto IL_04be;
																																			case 47:
																																				goto IL_04d1;
																																			case 15:
																																			case 94:
																																				goto IL_04df;
																																			case 60:
																																				goto IL_0528;
																																			case 4:
																																				goto IL_053c;
																																			case 8:
																																				goto IL_055d;
																																			case 78:
																																				goto IL_0576;
																																			case 2:
																																			case 11:
																																			case 17:
																																			case 26:
																																			case 28:
																																			case 38:
																																			case 41:
																																			case 51:
																																			case 55:
																																			case 62:
																																			case 71:
																																			case 73:
																																			case 75:
																																			case 85:
																																			case 91:
																																			case 92:
																																				goto end_IL_0214;
																																			case 44:
																																				goto IL_05a4;
																																			case 63:
																																				goto end_IL_01b7;
																																			case 98:
																																				goto IL_05c9;
																																			case 13:
																																			case 32:
																																			case 36:
																																			case 48:
																																			case 61:
																																			case 64:
																																			case 72:
																																			case 74:
																																			case 77:
																																			case 79:
																																			case 95:
																																			case 96:
																																				goto end_IL_02a1;
																																			case 76:
																																				goto end_IL_05d7;
																																			case 99:
																																				goto end_IL_05ea;
																																			case 69:
																																				goto end_IL_05f5;
																																			case 6:
																																				goto end_IL_05ff;
																																			case 34:
																																				goto end_IL_060a;
																																			case 57:
																																				goto end_IL_061f;
																																			case 7:
																																			case 19:
																																				goto end_IL_0634;
																																			case 5:
																																				goto end_IL_0644;
																																			case 45:
																																			case 97:
																																				goto end_IL_0654;
																																			case 0:
																																				goto end_IL_066d;
																																			case 1:
																																				goto end_IL_067d;
																																			case 42:
																																			case 89:
																																				goto IL_0698;
																																			}
																																			continue;
																																		}
																																		num5++;
																																		goto IL_055d;
																																		IL_055d:
																																		ptr2 += 8;
																																		goto end_IL_02a1;
																																		continue;
																																		end_IL_01b7:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_05b2;
																														continue;
																														end_IL_0214:
																														break;
																														IL_0214:;
																													}
																													break;
																													IL_0224:;
																												}
																												break;
																											}
																											num = 78;
																											goto IL_0576;
																											IL_0576:
																											if (6 <= b)
																											{
																												goto end_IL_02a1;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_034a;
																									IL_038a:
																									ptr2 += 8;
																									goto end_IL_02a1;
																									IL_034a:
																									array[num5] = 0;
																									goto IL_0358;
																									IL_0358:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)GetValueKindPOLICYLOOKUPNAMES[*(int*)(ptr2 + num3)])();
																									goto IL_037c;
																									IL_037c:
																									num5++;
																									goto IL_038a;
																								}
																								break;
																							}
																							goto IL_02eb;
																							IL_0320:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_032e;
																							IL_02eb:
																							if (9 >= b)
																							{
																								goto IL_02f6;
																							}
																							goto IL_0312;
																							IL_02f6:
																							if (9 > b)
																							{
																								num = 41;
																								break;
																							}
																							goto IL_039d;
																							IL_032e:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_02a1;
																							IL_039d:
																							num5--;
																							goto end_IL_02a1;
																							IL_0312:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0320;
																						}
																						break;
																					}
																					goto IL_02ac;
																					IL_0528:
																					array[num5 - 2] = 0;
																					goto IL_053c;
																					IL_02ac:
																					if (5 <= b)
																					{
																						goto IL_02b7;
																					}
																					goto IL_02cf;
																					IL_02b7:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02a1;
																					IL_02cf:
																					if (2 >= b)
																					{
																						num = 90;
																						goto IL_03b0;
																					}
																					goto IL_0460;
																					IL_053c:
																					num5--;
																					goto end_IL_02a1;
																					IL_03b0:
																					if (2 <= b)
																					{
																						goto IL_03be;
																					}
																					goto IL_043f;
																					IL_03be:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_042c;
																					IL_042c:
																					num5 -= 2;
																					goto end_IL_02a1;
																					IL_043f:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_044d;
																					IL_044d:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_0460:
																					if (3 < b)
																					{
																						goto IL_046b;
																					}
																					goto IL_04d1;
																					IL_046b:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0479;
																					IL_0479:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0487;
																					IL_0487:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04b0;
																					IL_04b0:
																					ptr2 += 8;
																					goto IL_04be;
																					IL_04be:
																					num5--;
																					goto end_IL_02a1;
																					IL_04d1:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_04df;
																					IL_04df:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 60;
																					goto IL_0528;
																				}
																				break;
																				IL_0271:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05a4;
																		IL_05c9:
																		ptr2 += 8;
																		goto end_IL_02a1;
																		IL_05b2:
																		num5++;
																		num = 98;
																		goto IL_05c9;
																		IL_05a4:
																		array[num5] = 0;
																		goto IL_05b2;
																		continue;
																		end_IL_0281:
																		break;
																	}
																	continue;
																	end_IL_0291:
																	break;
																}
																continue;
																end_IL_02a1:
																break;
															}
															continue;
														}
														goto IL_0698;
														IL_0698:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_05d7:
														break;
													}
													continue;
													end_IL_05ea:
													break;
												}
												continue;
												end_IL_05f5:
												break;
											}
											continue;
											end_IL_05ff:
											break;
										}
										continue;
										end_IL_060a:
										break;
									}
									continue;
									end_IL_061f:
									break;
								}
								continue;
								end_IL_0634:
								break;
							}
							continue;
							end_IL_0644:
							break;
						}
						continue;
						end_IL_0654:
						break;
					}
					continue;
					end_IL_066d:
					break;
				}
				continue;
				end_IL_067d:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemPageSizegetIsInputRedirected.DisablegetRefusedSet);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 36;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0268:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0248:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0238:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_022b:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_021b:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											num = 118;
																											while (true)
																											{
																												if (num != 118)
																												{
																													if (num != 1099)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 7:
																													case 74:
																														goto IL_0208;
																													case 48:
																														goto IL_021b;
																													case 0:
																													case 71:
																														goto IL_022b;
																													case 65:
																														goto IL_0238;
																													case 23:
																														goto IL_0248;
																													case 45:
																														goto IL_0258;
																													case 18:
																														goto IL_0268;
																													case 36:
																														goto end_IL_0268;
																													case 66:
																													case 105:
																														goto end_IL_0278;
																													case 53:
																														goto IL_029c;
																													case 2:
																													case 55:
																														goto IL_02a7;
																													case 64:
																													case 88:
																														goto IL_02bf;
																													case 73:
																														goto IL_02ca;
																													case 41:
																													case 63:
																														goto IL_02d8;
																													case 62:
																														goto IL_02f1;
																													case 61:
																														goto IL_0301;
																													case 12:
																														goto IL_030f;
																													case 52:
																													case 59:
																														goto IL_031d;
																													case 34:
																														goto IL_0346;
																													case 89:
																														goto IL_035f;
																													case 96:
																														goto IL_036f;
																													case 102:
																														goto IL_0382;
																													case 67:
																													case 70:
																														goto IL_03a3;
																													case 108:
																														goto IL_03b1;
																													case 51:
																														goto IL_03d4;
																													case 43:
																														goto IL_03de;
																													case 19:
																														goto IL_03ec;
																													case 68:
																														goto IL_03ff;
																													case 22:
																													case 109:
																														goto IL_041b;
																													case 11:
																														goto IL_045b;
																													case 47:
																														goto IL_046f;
																													case 97:
																														goto IL_0482;
																													case 21:
																														goto IL_0490;
																													case 72:
																													case 101:
																														goto IL_049b;
																													case 87:
																														goto IL_04fd;
																													case 80:
																														goto IL_0510;
																													case 56:
																													case 94:
																														goto IL_051b;
																													case 28:
																														goto IL_0529;
																													case 26:
																													case 110:
																														goto IL_0537;
																													case 10:
																														goto IL_055a;
																													case 33:
																														goto IL_0568;
																													case 6:
																														goto IL_0576;
																													case 44:
																														goto IL_0589;
																													case 91:
																													case 106:
																														goto IL_0597;
																													case 32:
																														goto IL_05d7;
																													case 35:
																														goto IL_05eb;
																													case 14:
																														goto IL_05fb;
																													case 15:
																													case 16:
																														goto IL_0606;
																													case 38:
																														goto IL_0611;
																													case 58:
																														goto IL_061e;
																													case 20:
																													case 27:
																														goto IL_0629;
																													case 3:
																													case 17:
																													case 25:
																													case 30:
																													case 31:
																													case 37:
																													case 40:
																													case 42:
																													case 46:
																													case 54:
																													case 69:
																													case 84:
																													case 85:
																													case 86:
																													case 90:
																													case 93:
																													case 98:
																													case 107:
																													case 111:
																														goto end_IL_01f5;
																													case 5:
																													case 9:
																													case 13:
																													case 29:
																													case 39:
																													case 49:
																													case 57:
																													case 77:
																													case 78:
																													case 81:
																													case 82:
																													case 83:
																													case 95:
																													case 99:
																														goto end_IL_0288;
																													case 4:
																														goto end_IL_065e;
																													case 60:
																														goto end_IL_0671;
																													case 8:
																														goto end_IL_067b;
																													case 75:
																														goto end_IL_0686;
																													case 50:
																													case 79:
																														goto end_IL_069b;
																													case 76:
																														goto end_IL_06ab;
																													case 24:
																													case 92:
																														goto end_IL_06bb;
																													case 103:
																														goto end_IL_06cb;
																													case 104:
																														goto end_IL_06db;
																													case 1:
																													case 100:
																														goto IL_06f6;
																													}
																													continue;
																												}
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_03a3;
																												IL_03d4:
																												array2[num5] = null;
																												goto IL_03de;
																												IL_03ec:
																												ptr2 += 8;
																												goto end_IL_0288;
																												IL_03de:
																												num5++;
																												goto IL_03ec;
																												IL_03a3:
																												array[num5] = 0;
																												goto IL_03b1;
																												IL_03b1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_03d4;
																												continue;
																												end_IL_01f5:
																												break;
																											}
																											break;
																											IL_0208:;
																										}
																										break;
																									}
																									goto IL_03ff;
																									IL_03ff:
																									if (4 > b)
																									{
																										break;
																									}
																									num = 82;
																									goto end_IL_0288;
																								}
																								break;
																							}
																							goto IL_029c;
																							IL_036f:
																							num5--;
																							goto end_IL_0288;
																							IL_029c:
																							if (3 <= b)
																							{
																								goto IL_02a7;
																							}
																							goto IL_02bf;
																							IL_02a7:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0288;
																							IL_02bf:
																							if (1 >= b)
																							{
																								goto IL_02ca;
																							}
																							goto IL_0301;
																							IL_02ca:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_02d8;
																							IL_02d8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_02f1;
																							IL_02f1:
																							array[num5] = 0;
																							goto IL_035f;
																							IL_035f:
																							num5++;
																							goto IL_0382;
																							IL_0382:
																							ptr2 += 8;
																							goto end_IL_0288;
																							IL_0301:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_030f;
																							IL_030f:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_031d;
																							IL_031d:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0346;
																							IL_0346:
																							ptr2 += 8;
																							num = 96;
																							goto IL_036f;
																						}
																						break;
																					}
																					goto IL_041b;
																					IL_046f:
																					num5--;
																					goto end_IL_0288;
																					IL_041b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_045b;
																					IL_045b:
																					array[num5 - 2] = 0;
																					goto IL_046f;
																				}
																				break;
																			}
																			goto IL_0482;
																			IL_0629:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0288;
																			IL_0482:
																			if (9 >= b)
																			{
																				goto IL_0490;
																			}
																			goto IL_05fb;
																			IL_0490:
																			if (9 <= b)
																			{
																				goto IL_049b;
																			}
																			goto IL_0510;
																			IL_049b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04fd;
																			IL_04fd:
																			num5 -= 2;
																			goto end_IL_0288;
																			IL_0510:
																			if (7 < b)
																			{
																				goto IL_051b;
																			}
																			goto IL_0589;
																			IL_051b:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0529;
																			IL_0529:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0537;
																			IL_0537:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_055a;
																			IL_055a:
																			array[num5] = 0;
																			goto IL_0568;
																			IL_0568:
																			num5++;
																			goto IL_0576;
																			IL_0576:
																			ptr2 += 8;
																			goto end_IL_0288;
																			IL_0589:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0597;
																			IL_0597:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05d7;
																			IL_05d7:
																			array[num5 - 2] = 0;
																			goto IL_05eb;
																			IL_05eb:
																			num5--;
																			goto end_IL_0288;
																			IL_05fb:
																			if (10 < b)
																			{
																				goto IL_0606;
																			}
																			goto IL_061e;
																			IL_0606:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0611;
																			IL_0611:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_061e:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0629;
																		}
																		break;
																		IL_0258:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 57;
																goto end_IL_0288;
																continue;
																end_IL_0268:
																break;
															}
															continue;
															end_IL_0278:
															break;
														}
														continue;
														end_IL_0288:
														break;
													}
													continue;
												}
												goto IL_06f6;
												IL_06f6:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_065e:
												break;
											}
											continue;
											end_IL_0671:
											break;
										}
										continue;
										end_IL_067b:
										break;
									}
									continue;
									end_IL_0686:
									break;
								}
								continue;
								end_IL_069b:
								break;
							}
							continue;
							end_IL_06ab:
							break;
						}
						continue;
						end_IL_06bb:
						break;
					}
					continue;
					end_IL_06cb:
					break;
				}
				continue;
				end_IL_06db:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 68;
		byte* ptr = default(byte*);
		int num4 = default(int);
		byte[] array = default(byte[]);
		object[] array2 = default(object[]);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 98;
				while (true)
				{
					if (num == 98)
					{
						goto IL_01cb;
					}
					if (num != 1079)
					{
						goto IL_03f3;
					}
					switch (num)
					{
					case 67:
						goto end_IL_0197;
					case 68:
						goto end_IL_01a7;
					case 34:
						goto IL_01cb;
					case 27:
						goto IL_01e2;
					case 16:
					case 69:
						goto IL_01f0;
					case 26:
						goto IL_01fe;
					case 37:
						goto IL_020c;
					case 3:
						goto IL_021f;
					case 25:
						goto IL_0232;
					case 49:
						goto IL_0244;
					case 10:
					case 13:
					case 15:
					case 20:
					case 33:
					case 61:
					case 63:
					case 81:
					case 84:
					case 87:
					case 91:
						goto IL_0255;
					case 77:
					case 78:
						goto IL_0265;
					case 44:
						goto IL_026e;
					case 56:
						goto IL_027c;
					case 7:
						goto IL_028a;
					case 53:
						goto IL_02a1;
					case 8:
						goto IL_02af;
					case 11:
					case 62:
						goto IL_02bd;
					case 57:
						goto IL_02c8;
					case 51:
						goto IL_02d3;
					case 65:
					case 86:
						goto IL_02e1;
					case 48:
						goto IL_0314;
					case 35:
					case 58:
						goto IL_032b;
					case 32:
						goto IL_0339;
					case 12:
						goto IL_035c;
					case 40:
						goto IL_0366;
					case 23:
						goto IL_0374;
					case 60:
						goto IL_0387;
					case 66:
					case 88:
						goto IL_0395;
					case 39:
						goto IL_03a3;
					case 5:
					case 6:
						goto IL_03b1;
					case 82:
						goto IL_03c9;
					case 30:
					case 89:
						goto IL_03d7;
					case 31:
					case 73:
						goto IL_03e5;
					case 79:
						goto IL_03f3;
					case 14:
					case 45:
						goto IL_0401;
					case 29:
						goto IL_0441;
					case 41:
						goto IL_0455;
					case 36:
						goto IL_0468;
					case 4:
					case 43:
						goto IL_0473;
					case 46:
						goto IL_0481;
					case 42:
					case 74:
						goto IL_0494;
					case 90:
						goto IL_0502;
					case 64:
					case 83:
						goto IL_0515;
					case 17:
						goto IL_053e;
					case 55:
						goto IL_054c;
					case 70:
						goto IL_055f;
					case 2:
						goto IL_056d;
					case 22:
						goto IL_057b;
					case 0:
					case 1:
					case 19:
					case 21:
					case 24:
					case 28:
					case 38:
					case 47:
					case 50:
					case 52:
					case 54:
					case 59:
					case 71:
					case 72:
					case 75:
					case 76:
					case 80:
					case 85:
						goto IL_058e;
					case 9:
					case 18:
						goto IL_05b3;
					}
					continue;
					IL_053e:
					ptr += 8;
					goto IL_054c;
					IL_054c:
					num4--;
					goto IL_0255;
					IL_01cb:
					array = new byte[2];
					num = 27;
					goto IL_01e2;
					IL_01e2:
					array2 = new object[2];
					goto IL_01f0;
					IL_01f0:
					array3 = new int[3];
					goto IL_01fe;
					IL_01fe:
					array4 = new long[2];
					goto IL_020c;
					IL_020c:
					array3[0] = int_2;
					goto IL_021f;
					IL_021f:
					array3[1] = int_3;
					goto IL_0232;
					IL_0232:
					ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct89.ChannelServicesDataOverflow);
					num = 49;
					goto IL_0244;
					IL_0244:
					ptr = ptr2;
					num = 84;
					goto IL_0255;
					IL_0255:
					if (num5 != 1)
					{
						goto IL_0265;
					}
					goto IL_05b3;
					IL_05b3:
					return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					IL_0265:
					b = *ptr;
					goto IL_026e;
					IL_026e:
					ptr++;
					goto IL_027c;
					IL_027c:
					if (b >= 1)
					{
						goto IL_028a;
					}
					goto IL_058e;
					IL_028a:
					if (b <= 8)
					{
						num = 53;
						goto IL_02a1;
					}
					goto IL_058e;
					IL_058e:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
					goto IL_055f;
					IL_02a1:
					if (4 < b)
					{
						goto IL_02af;
					}
					goto IL_03c9;
					IL_02af:
					if (6 < b)
					{
						goto IL_02bd;
					}
					goto IL_0387;
					IL_02bd:
					if (7 < b)
					{
						goto IL_02c8;
					}
					num = 48;
					goto IL_0314;
					IL_02c8:
					if (8 >= b)
					{
						goto IL_02d3;
					}
					num = 38;
					goto IL_058e;
					IL_02d3:
					if (8 <= b)
					{
						goto IL_02e1;
					}
					goto IL_058e;
					IL_02e1:
					byte* num6 = ptr;
					num5 = 1;
					ptr = num6 + -200;
					goto IL_0255;
					IL_056d:
					num4++;
					goto IL_057b;
					IL_055f:
					array[num4] = 0;
					goto IL_056d;
					IL_0314:
					if (7 <= b)
					{
						num = 35;
						goto IL_032b;
					}
					goto IL_058e;
					IL_057b:
					ptr += 8;
					goto IL_0255;
					IL_032b:
					array[num4] = 0;
					goto IL_0339;
					IL_0339:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
					goto IL_035c;
					IL_035c:
					array2[num4] = null;
					goto IL_0366;
					IL_0366:
					num4++;
					goto IL_0374;
					IL_0374:
					ptr += 8;
					goto IL_0255;
					IL_0387:
					if (6 <= b)
					{
						goto IL_0255;
					}
					goto IL_0395;
					IL_0395:
					if (5 >= b)
					{
						goto IL_03a3;
					}
					goto IL_058e;
					IL_03a3:
					if (5 <= b)
					{
						goto IL_03b1;
					}
					goto IL_058e;
					IL_03b1:
					ptr = ptr2 + *(int*)(ptr + num3);
					goto IL_0255;
					IL_03c9:
					if (4 > b)
					{
						goto IL_03d7;
					}
					goto IL_0515;
					IL_03d7:
					if (2 < b)
					{
						goto IL_03e5;
					}
					goto IL_0468;
					IL_03e5:
					if (3 >= b)
					{
						goto IL_03f3;
					}
					goto IL_058e;
					IL_03f3:
					if (3 <= b)
					{
						goto IL_0401;
					}
					goto IL_058e;
					IL_0401:
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_0441;
					IL_0441:
					array[num4 - 2] = 0;
					goto IL_0455;
					IL_0455:
					num4--;
					goto IL_0255;
					IL_0468:
					if (2 > b)
					{
						goto IL_0473;
					}
					goto IL_0494;
					IL_0473:
					if (1 >= b)
					{
						goto IL_0481;
					}
					goto IL_058e;
					IL_0481:
					if (1 > b)
					{
					}
					goto IL_058e;
					IL_0494:
					ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
					goto IL_0502;
					IL_0502:
					num4 -= 2;
					goto IL_0255;
					IL_0515:
					ref int reference = ref array3[*(int*)(ptr + num3)];
					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
					goto IL_053e;
					continue;
					end_IL_0197:
					break;
				}
				continue;
				end_IL_01a7:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 19;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 48;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReservedDay.ApplicationManifestBytesDateWordToken);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01f8:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01d8:
																					if (4 < b)
																					{
																						goto IL_03b6;
																					}
																					while (true)
																					{
																						IL_01c8:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01b8:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01a8:
																										if (2 <= b)
																										{
																											num = 94;
																											while (true)
																											{
																												if (num != 94)
																												{
																													if (num != 1075)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 59:
																														goto IL_01a8;
																													case 62:
																													case 78:
																														goto IL_01b8;
																													case 77:
																														goto IL_01c8;
																													case 42:
																														goto IL_01d8;
																													case 38:
																														goto end_IL_01d8;
																													case 13:
																														goto IL_01f8;
																													case 57:
																														goto end_IL_01f8;
																													case 8:
																													case 73:
																														goto end_IL_0208;
																													case 52:
																														goto IL_0223;
																													case 36:
																														goto IL_0231;
																													case 40:
																														goto IL_024d;
																													case 56:
																														goto IL_02bb;
																													case 41:
																														goto IL_02ce;
																													case 14:
																														goto IL_02e5;
																													case 24:
																													case 74:
																														goto IL_02f3;
																													case 61:
																														goto IL_0333;
																													case 39:
																														goto IL_0347;
																													case 44:
																													case 81:
																														goto IL_0363;
																													case 26:
																														goto IL_038c;
																													case 60:
																														goto IL_03a3;
																													case 84:
																														goto IL_03b6;
																													case 29:
																														goto IL_03c1;
																													case 25:
																													case 58:
																														goto IL_03cf;
																													case 16:
																														goto IL_03dd;
																													case 65:
																													case 80:
																														goto IL_03eb;
																													case 21:
																														goto IL_0403;
																													case 66:
																														goto IL_040e;
																													case 11:
																													case 46:
																														goto IL_041c;
																													case 33:
																														goto IL_042a;
																													case 53:
																														goto IL_044d;
																													case 51:
																														goto IL_0457;
																													case 86:
																														goto IL_0465;
																													case 69:
																														goto IL_0475;
																													case 0:
																														goto IL_0480;
																													case 30:
																													case 79:
																														goto end_IL_0195;
																													case 17:
																													case 20:
																													case 23:
																													case 28:
																													case 31:
																													case 32:
																													case 34:
																													case 35:
																													case 43:
																													case 45:
																													case 49:
																													case 63:
																													case 64:
																													case 68:
																													case 70:
																													case 71:
																													case 85:
																														goto end_IL_01e8;
																													case 47:
																														goto IL_04c7;
																													case 7:
																														goto IL_04d5;
																													case 82:
																														goto IL_04e3;
																													case 1:
																													case 2:
																													case 4:
																													case 6:
																													case 9:
																													case 10:
																													case 15:
																													case 55:
																													case 67:
																													case 83:
																													case 87:
																														goto end_IL_0218;
																													case 27:
																														goto end_IL_04f1;
																													case 54:
																														goto end_IL_0504;
																													case 76:
																														goto end_IL_050e;
																													case 50:
																														goto end_IL_0519;
																													case 3:
																														goto end_IL_052e;
																													case 48:
																														goto end_IL_0543;
																													case 22:
																														goto end_IL_0553;
																													case 37:
																														goto end_IL_0563;
																													case 72:
																													case 75:
																														goto end_IL_056e;
																													case 18:
																														goto end_IL_057e;
																													case 19:
																														goto end_IL_058e;
																													case 5:
																													case 12:
																														goto IL_05a9;
																													}
																													continue;
																												}
																												goto IL_024d;
																												IL_024d:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_02bb;
																												IL_02bb:
																												num5 -= 2;
																												goto end_IL_0218;
																												continue;
																												end_IL_0195:
																												break;
																											}
																											break;
																										}
																										goto IL_0223;
																										IL_0223:
																										if (1 < b)
																										{
																											goto end_IL_01e8;
																										}
																										goto IL_0231;
																										IL_0231:
																										if (1 > b)
																										{
																											num = 23;
																										}
																										goto end_IL_01e8;
																									}
																									break;
																								}
																								goto IL_02ce;
																								IL_0333:
																								array[num5 - 2] = 0;
																								goto IL_0347;
																								IL_02ce:
																								if (3 < b)
																								{
																									goto end_IL_01e8;
																								}
																								num = 14;
																								goto IL_02e5;
																								IL_0347:
																								num5--;
																								num = 10;
																								goto end_IL_0218;
																								IL_02e5:
																								if (3 > b)
																								{
																									goto end_IL_01e8;
																								}
																								goto IL_02f3;
																								IL_02f3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0333;
																							}
																							break;
																						}
																						goto IL_0363;
																						IL_03a3:
																						num5--;
																						goto end_IL_0218;
																						IL_0363:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_038c;
																						IL_038c:
																						ptr2 += 8;
																						num = 60;
																						goto IL_03a3;
																					}
																					goto IL_048b;
																					IL_048b:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0218;
																					IL_03b6:
																					if (6 >= b)
																					{
																						goto IL_03c1;
																					}
																					goto IL_0403;
																					IL_03c1:
																					if (6 <= b)
																					{
																						goto end_IL_0218;
																					}
																					goto IL_03cf;
																					IL_03cf:
																					if (5 < b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_03dd;
																					IL_03dd:
																					if (5 > b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_03eb;
																					IL_03eb:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0218;
																					IL_0403:
																					if (7 >= b)
																					{
																						goto IL_040e;
																					}
																					goto IL_0475;
																					IL_040e:
																					if (7 > b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_041c;
																					IL_041c:
																					array[num5] = 0;
																					goto IL_042a;
																					IL_042a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_044d;
																					IL_044d:
																					array2[num5] = null;
																					goto IL_0457;
																					IL_0457:
																					num5++;
																					goto IL_0465;
																					IL_0465:
																					ptr2 += 8;
																					goto end_IL_0218;
																					IL_0475:
																					if (8 < b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_0480;
																					IL_0480:
																					if (8 > b)
																					{
																						goto end_IL_01e8;
																					}
																					goto IL_048b;
																					continue;
																					end_IL_01d8:
																					break;
																				}
																				continue;
																				end_IL_01e8:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04c7;
																		IL_04e3:
																		ptr2 += 8;
																		goto end_IL_0218;
																		IL_04d5:
																		num5++;
																		goto IL_04e3;
																		IL_04c7:
																		array[num5] = 0;
																		goto IL_04d5;
																		continue;
																		end_IL_01f8:
																		break;
																	}
																	continue;
																	end_IL_0208:
																	break;
																}
																continue;
																end_IL_0218:
																break;
															}
															continue;
														}
														goto IL_05a9;
														IL_05a9:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04f1:
														break;
													}
													continue;
													end_IL_0504:
													break;
												}
												continue;
												end_IL_050e:
												break;
											}
											continue;
											end_IL_0519:
											break;
										}
										continue;
										end_IL_052e:
										break;
									}
									continue;
									end_IL_0543:
									break;
								}
								continue;
								end_IL_0553:
								break;
							}
							continue;
							end_IL_0563:
							break;
						}
						continue;
						end_IL_056e:
						break;
					}
					continue;
					end_IL_057e:
					break;
				}
				continue;
				end_IL_058e:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 59;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TMgetLicenseFile.FormatNamespaceGetFactorySuppliedEvidence);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0256:
															byte b = *ptr2;
															while (true)
															{
																IL_023d:
																ptr2++;
																num = 73;
																while (true)
																{
																	IL_022d:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			num = 68;
																			while (true)
																			{
																				IL_020d:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_01fa:
																						if (5 > b)
																						{
																							num = 111;
																							while (true)
																							{
																								if (num != 111)
																								{
																									if (num != 1092)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 50:
																										goto IL_01fa;
																									case 68:
																										goto IL_020d;
																									case 3:
																										goto IL_021a;
																									case 73:
																										goto IL_022d;
																									case 45:
																										goto IL_023d;
																									case 1:
																									case 35:
																										goto IL_0256;
																									case 4:
																									case 40:
																										goto IL_0261;
																									case 19:
																										goto IL_026c;
																									case 43:
																									case 47:
																										goto IL_028a;
																									case 34:
																									case 49:
																										goto IL_02f1;
																									case 54:
																										goto IL_02ff;
																									case 20:
																									case 62:
																										goto IL_0324;
																									case 53:
																										goto IL_032f;
																									case 69:
																										goto IL_033d;
																									case 71:
																										goto IL_0350;
																									case 32:
																									case 46:
																										goto IL_035e;
																									case 72:
																										goto IL_037a;
																									case 70:
																									case 78:
																										goto IL_0389;
																									case 60:
																										goto IL_0394;
																									case 11:
																									case 24:
																										goto IL_03a2;
																									case 6:
																										goto IL_03e2;
																									case 27:
																										goto IL_03f8;
																									case 51:
																										goto IL_0406;
																									case 80:
																										goto IL_0416;
																									case 90:
																										goto IL_0429;
																									case 5:
																										goto IL_0437;
																									case 33:
																									case 92:
																										goto IL_044a;
																									case 38:
																										goto IL_046d;
																									case 56:
																										goto IL_047b;
																									case 67:
																										goto IL_0489;
																									case 96:
																										goto IL_049c;
																									case 58:
																										goto IL_04af;
																									case 2:
																										goto IL_04bd;
																									case 0:
																									case 14:
																										goto IL_04c8;
																									case 15:
																										goto IL_04f1;
																									case 86:
																										goto IL_04ff;
																									case 97:
																										goto IL_0512;
																									case 100:
																										goto IL_0520;
																									case 7:
																									case 76:
																										goto IL_052e;
																									case 61:
																										goto IL_0547;
																									case 84:
																										goto IL_0555;
																									case 101:
																										goto IL_0563;
																									case 8:
																										goto IL_0573;
																									case 9:
																									case 99:
																										goto IL_057e;
																									case 39:
																										goto IL_0589;
																									case 88:
																										goto IL_0596;
																									case 23:
																									case 63:
																										goto IL_05a1;
																									case 12:
																									case 13:
																									case 22:
																									case 25:
																									case 29:
																									case 30:
																									case 42:
																									case 55:
																									case 57:
																									case 74:
																									case 75:
																									case 81:
																									case 82:
																									case 83:
																									case 87:
																									case 89:
																									case 91:
																									case 95:
																									case 98:
																										goto end_IL_021a;
																									case 16:
																									case 18:
																									case 26:
																									case 28:
																									case 31:
																									case 36:
																									case 37:
																									case 44:
																									case 52:
																									case 77:
																									case 85:
																									case 102:
																									case 104:
																										goto end_IL_01e7;
																									case 94:
																										goto end_IL_05d2;
																									case 41:
																										goto end_IL_05e5;
																									case 17:
																										goto end_IL_05ef;
																									case 93:
																										goto end_IL_05fa;
																									case 59:
																										goto end_IL_060f;
																									case 79:
																										goto end_IL_061f;
																									case 48:
																										goto end_IL_062f;
																									case 10:
																									case 64:
																										goto end_IL_063a;
																									case 65:
																										goto end_IL_064a;
																									case 66:
																										goto end_IL_065a;
																									case 21:
																									case 103:
																										goto IL_0675;
																									}
																									continue;
																								}
																								goto IL_04af;
																								IL_0596:
																								if (3 > b)
																								{
																									goto end_IL_021a;
																								}
																								goto IL_05a1;
																								IL_05a1:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_04af:
																								if (2 >= b)
																								{
																									goto IL_04bd;
																								}
																								goto IL_0573;
																								IL_04bd:
																								if (2 <= b)
																								{
																									goto IL_04c8;
																								}
																								goto IL_0512;
																								IL_04c8:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04f1;
																								IL_04f1:
																								ptr2 += 8;
																								goto IL_04ff;
																								IL_04ff:
																								num5--;
																								break;
																								IL_0512:
																								if (1 < b)
																								{
																									goto end_IL_021a;
																								}
																								goto IL_0520;
																								IL_0520:
																								if (1 > b)
																								{
																									goto end_IL_021a;
																								}
																								goto IL_052e;
																								IL_052e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0547;
																								IL_0547:
																								array[num5] = 0;
																								goto IL_0555;
																								IL_0555:
																								num5++;
																								goto IL_0563;
																								IL_0563:
																								ptr2 += 8;
																								break;
																								IL_0573:
																								if (3 < b)
																								{
																									goto IL_057e;
																								}
																								goto IL_0596;
																								IL_057e:
																								if (4 < b)
																								{
																									goto end_IL_021a;
																								}
																								goto IL_0589;
																								IL_0589:
																								if (4 > b)
																								{
																									goto end_IL_021a;
																								}
																								break;
																								continue;
																								end_IL_01e7:
																								break;
																							}
																							break;
																						}
																						goto IL_02f1;
																						IL_0429:
																						num5++;
																						goto IL_0437;
																						IL_0437:
																						ptr2 += 8;
																						break;
																						IL_02f1:
																						array[num5] = 0;
																						goto IL_02ff;
																						IL_02ff:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_037a;
																						IL_037a:
																						array2[num5] = null;
																						goto IL_0429;
																					}
																					break;
																				}
																				goto IL_0261;
																				IL_0350:
																				if (9 > b)
																				{
																					goto end_IL_021a;
																				}
																				goto IL_035e;
																				IL_0261:
																				if (8 >= b)
																				{
																					goto IL_026c;
																				}
																				num = 62;
																				goto IL_0324;
																				IL_026c:
																				if (8 <= b)
																				{
																					goto IL_028a;
																				}
																				goto IL_0389;
																				IL_0389:
																				if (6 >= b)
																				{
																					goto IL_0394;
																				}
																				goto IL_03f8;
																				IL_0394:
																				if (6 > b)
																				{
																					goto end_IL_021a;
																				}
																				goto IL_03a2;
																				IL_03a2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03e2;
																				IL_03e2:
																				array[num5 - 2] = 0;
																				goto IL_0416;
																				IL_0416:
																				num5--;
																				break;
																				IL_03f8:
																				if (7 < b)
																				{
																					goto end_IL_021a;
																				}
																				goto IL_0406;
																				IL_0406:
																				if (7 > b)
																				{
																					goto end_IL_021a;
																				}
																				goto IL_044a;
																				IL_044a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_046d;
																				IL_046d:
																				array[num5] = 0;
																				goto IL_047b;
																				IL_047b:
																				num5++;
																				goto IL_0489;
																				IL_0489:
																				ptr2 += 8;
																				break;
																				IL_028a:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_049c;
																				IL_049c:
																				num5 -= 2;
																				break;
																				IL_035e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0324:
																				if (9 < b)
																				{
																					goto IL_032f;
																				}
																				goto IL_0350;
																				IL_032f:
																				if (10 < b)
																				{
																					goto end_IL_021a;
																				}
																				goto IL_033d;
																				IL_033d:
																				if (10 > b)
																				{
																				}
																				goto end_IL_021a;
																			}
																			goto end_IL_022d;
																			continue;
																			end_IL_021a:
																			break;
																			IL_021a:;
																		}
																	}
																	else
																	{
																		num = 98;
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_022d:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0675;
													IL_0675:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05d2:
													break;
												}
												continue;
												end_IL_05e5:
												break;
											}
											continue;
											end_IL_05ef:
											break;
										}
										continue;
										end_IL_05fa:
										break;
									}
									continue;
									end_IL_060f:
									break;
								}
								continue;
								end_IL_061f:
								break;
							}
							continue;
							end_IL_062f:
							break;
						}
						continue;
						end_IL_063a:
						break;
					}
					continue;
					end_IL_064a:
					break;
				}
				continue;
				end_IL_065a:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 94;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AwaitOnCompletedSoapIdrefs.TrailingNewLineLockRegion);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0218:
														byte b = *ptr2;
														while (true)
														{
															IL_0208:
															ptr2++;
															while (true)
															{
																IL_01f8:
																if (b < 1)
																{
																	num = 114;
																	while (num != 114)
																	{
																		if (num != 1095)
																		{
																			goto end_IL_01f8;
																		}
																		switch (num)
																		{
																		case 25:
																			goto IL_01f8;
																		case 32:
																			goto IL_0208;
																		case 73:
																		case 79:
																			goto IL_0218;
																		case 27:
																			goto IL_0223;
																		case 51:
																			goto IL_0231;
																		case 20:
																			goto IL_023c;
																		case 38:
																		case 45:
																			goto IL_0253;
																		case 3:
																		case 36:
																			goto IL_0261;
																		case 33:
																			goto IL_026c;
																		case 31:
																			goto IL_027a;
																		case 42:
																		case 57:
																			goto IL_028d;
																		case 54:
																			goto IL_029b;
																		case 35:
																			goto IL_02a9;
																		case 62:
																			goto IL_02bc;
																		case 10:
																		case 74:
																			goto IL_02cf;
																		case 15:
																			goto IL_02dd;
																		case 44:
																			goto IL_0300;
																		case 60:
																			goto IL_030a;
																		case 75:
																			goto IL_031d;
																		case 14:
																		case 26:
																			goto IL_032b;
																		case 52:
																			goto IL_038d;
																		case 67:
																		case 77:
																			goto IL_03a0;
																		case 49:
																		case 80:
																			goto IL_03b8;
																		case 81:
																			goto IL_03d4;
																		case 0:
																		case 8:
																			goto IL_03e2;
																		case 78:
																			goto IL_0414;
																		case 55:
																		case 84:
																			goto IL_0424;
																		case 39:
																			goto IL_042f;
																		case 86:
																			goto IL_0450;
																		case 87:
																			goto IL_0463;
																		case 90:
																			goto IL_047f;
																		case 24:
																			goto IL_048a;
																		case 22:
																		case 53:
																			goto IL_0498;
																		case 47:
																			goto IL_04d8;
																		case 64:
																			goto IL_04ec;
																		case 30:
																		case 34:
																			goto IL_0511;
																		case 11:
																			goto IL_051f;
																		case 5:
																		case 100:
																			goto IL_052f;
																		case 6:
																			goto IL_0546;
																		case 13:
																		case 95:
																			goto IL_0554;
																		case 72:
																			goto IL_056d;
																		case 12:
																			goto IL_057b;
																		case 99:
																		case 104:
																			goto IL_058b;
																		case 91:
																			goto IL_05ae;
																		case 71:
																			goto IL_05bc;
																		case 58:
																			goto IL_05ca;
																		case 106:
																			goto IL_05da;
																		case 1:
																		case 4:
																		case 7:
																		case 16:
																		case 18:
																		case 19:
																		case 28:
																		case 37:
																		case 50:
																		case 63:
																		case 66:
																		case 69:
																		case 76:
																		case 82:
																		case 85:
																		case 89:
																		case 96:
																		case 101:
																		case 105:
																		case 107:
																			goto end_IL_01e5;
																		case 21:
																		case 23:
																		case 29:
																		case 41:
																		case 43:
																		case 48:
																		case 59:
																		case 61:
																		case 65:
																		case 68:
																		case 97:
																		case 98:
																		case 102:
																			goto end_IL_01f8;
																		case 56:
																			goto end_IL_0606;
																		case 2:
																			goto end_IL_0619;
																		case 17:
																			goto end_IL_0623;
																		case 9:
																			goto end_IL_062e;
																		case 40:
																		case 103:
																			goto end_IL_0643;
																		case 70:
																			goto end_IL_0653;
																		case 46:
																		case 83:
																			goto end_IL_0663;
																		case 93:
																			goto end_IL_0673;
																		case 94:
																			goto end_IL_0683;
																		case 88:
																		case 92:
																			goto IL_069e;
																		}
																		continue;
																		end_IL_01e5:
																		break;
																	}
																	goto IL_05ea;
																}
																goto IL_0223;
																IL_051f:
																if (7 <= b)
																{
																	goto IL_058b;
																}
																goto IL_05ea;
																IL_058b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_05ae;
																IL_0223:
																if (b <= 10)
																{
																	goto IL_0231;
																}
																goto IL_05ea;
																IL_0231:
																if (5 >= b)
																{
																	goto IL_023c;
																}
																goto IL_028d;
																IL_023c:
																if (5 > b)
																{
																	num = 38;
																	goto IL_0253;
																}
																goto IL_02cf;
																IL_05ae:
																array[num5] = 0;
																goto IL_05bc;
																IL_0253:
																if (2 < b)
																{
																	goto IL_0261;
																}
																goto IL_03d4;
																IL_0261:
																if (3 < b)
																{
																	goto IL_026c;
																}
																goto IL_02bc;
																IL_026c:
																if (4 >= b)
																{
																	goto IL_027a;
																}
																goto IL_05ea;
																IL_027a:
																if (4 <= b)
																{
																	break;
																}
																goto IL_05ea;
																IL_02bc:
																if (3 <= b)
																{
																	goto IL_03a0;
																}
																goto IL_05ea;
																IL_03a0:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_03d4:
																if (2 <= b)
																{
																	goto IL_03e2;
																}
																goto IL_052f;
																IL_03e2:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 78;
																goto IL_0414;
																IL_0414:
																ptr2 += 8;
																goto IL_0450;
																IL_0450:
																num5--;
																break;
																IL_052f:
																if (1 >= b)
																{
																	num = 6;
																	goto IL_0546;
																}
																goto IL_05ea;
																IL_05bc:
																num5++;
																goto IL_05ca;
																IL_0546:
																if (1 <= b)
																{
																	goto IL_0554;
																}
																goto IL_05ea;
																IL_0554:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_056d;
																IL_056d:
																array[num5] = 0;
																goto IL_057b;
																IL_057b:
																num5++;
																goto IL_05da;
																IL_05da:
																ptr2 += 8;
																break;
																IL_02cf:
																array[num5] = 0;
																goto IL_02dd;
																IL_02dd:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0300;
																IL_0300:
																array2[num5] = null;
																goto IL_030a;
																IL_030a:
																num5++;
																goto IL_0463;
																IL_0463:
																ptr2 += 8;
																num = 43;
																break;
																IL_028d:
																if (8 < b)
																{
																	goto IL_029b;
																}
																goto IL_031d;
																IL_029b:
																if (9 >= b)
																{
																	goto IL_02a9;
																}
																goto IL_0424;
																IL_02a9:
																if (9 <= b)
																{
																	goto IL_03b8;
																}
																goto IL_05ea;
																IL_03b8:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																break;
																IL_0424:
																if (10 >= b)
																{
																	goto IL_042f;
																}
																num = 105;
																goto IL_05ea;
																IL_042f:
																if (10 > b)
																{
																}
																goto IL_05ea;
																IL_05ca:
																ptr2 += 8;
																break;
																IL_031d:
																if (8 <= b)
																{
																	goto IL_032b;
																}
																goto IL_047f;
																IL_032b:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_038d;
																IL_038d:
																num5 -= 2;
																break;
																IL_047f:
																if (6 >= b)
																{
																	goto IL_048a;
																}
																num = 30;
																goto IL_0511;
																IL_048a:
																if (6 <= b)
																{
																	goto IL_0498;
																}
																goto IL_05ea;
																IL_0498:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04d8;
																IL_04d8:
																array[num5 - 2] = 0;
																goto IL_04ec;
																IL_04ec:
																num5--;
																num = 97;
																break;
																IL_05ea:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 68;
																break;
																IL_0511:
																if (7 >= b)
																{
																	goto IL_051f;
																}
																goto IL_05ea;
																continue;
																end_IL_01f8:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_069e;
												IL_069e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0606:
												break;
											}
											continue;
											end_IL_0619:
											break;
										}
										continue;
										end_IL_0623:
										break;
									}
									continue;
									end_IL_062e:
									break;
								}
								continue;
								end_IL_0643:
								break;
							}
							continue;
							end_IL_0653:
							break;
						}
						continue;
						end_IL_0663:
						break;
					}
					continue;
					end_IL_0673:
					break;
				}
				continue;
				end_IL_0683:
				break;
			}
		}
	}

	static Class163()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0055:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 4:
								goto IL_0046;
							case 1:
								goto IL_0055;
							case 2:
								goto end_IL_0039;
							case 3:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
