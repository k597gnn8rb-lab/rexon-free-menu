using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Dash Forward", "Rig", "Left secondary to dash forward.", false, 19, ModType.const_0, false)]
internal class Class175 : MonoBehaviour
{
	private float float_0;

	private Rigidbody rigidbody_0;

	private static bool bool_0;

	private static bool bool_1;

	private static bool bool_2;

	private static double double_0;

	private static IntPtr[] FormatUIntDefineProperty;

	private static IntPtr[] OldNamesCaseSensitive;

	private static IntPtr[] ReleaseThreadCacheNextActivator;

	private static IntPtr[] IsBrowserDisplaySetDeploymentMetadata;

	private static IntPtr[] GetEventProviderNameTrue;

	private unsafe static int smethod_0(int int_0, int int_1)
	{
		int num = 13;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnableCountReflectionEmit.getFlagsMSIL);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02e0:
															byte b = *ptr2;
															while (true)
															{
																IL_02d0:
																ptr2++;
																while (true)
																{
																	IL_02c0:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02a0:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_0280:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0273:
																									if (4 >= b)
																									{
																										while (4 <= b)
																										{
																											num = 22;
																											while (true)
																											{
																												IL_022c:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 127;
																												while (true)
																												{
																													if (num != 127)
																													{
																														if (num != 1108)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 15:
																														case 22:
																															goto IL_022c;
																														case 24:
																															goto IL_0260;
																														case 61:
																															goto IL_0273;
																														case 39:
																														case 109:
																															goto IL_0280;
																														case 11:
																															goto IL_0290;
																														case 26:
																															goto IL_02a0;
																														case 72:
																															goto IL_02b0;
																														case 99:
																															goto IL_02c0;
																														case 27:
																															goto IL_02d0;
																														case 30:
																														case 45:
																															goto IL_02e0;
																														case 50:
																														case 73:
																															goto IL_02eb;
																														case 6:
																															goto IL_02f9;
																														case 44:
																														case 104:
																															goto IL_0307;
																														case 105:
																															goto IL_031f;
																														case 75:
																														case 91:
																															goto IL_032d;
																														case 32:
																															goto IL_033b;
																														case 89:
																															goto IL_0349;
																														case 96:
																														case 101:
																															goto IL_0357;
																														case 76:
																															goto IL_03d3;
																														case 70:
																														case 88:
																															goto IL_03e6;
																														case 7:
																															goto end_IL_0219;
																														case 52:
																															goto IL_043a;
																														case 114:
																															goto IL_044d;
																														case 28:
																															goto IL_046e;
																														case 98:
																															goto IL_0481;
																														case 21:
																															goto IL_048f;
																														case 49:
																															goto IL_049d;
																														case 57:
																														case 74:
																															goto IL_04a8;
																														case 62:
																															goto IL_04bb;
																														case 83:
																															goto IL_04c9;
																														case 41:
																														case 112:
																															goto IL_04d7;
																														case 78:
																															goto IL_04f4;
																														case 25:
																															goto IL_0533;
																														case 80:
																															goto IL_0546;
																														case 3:
																															goto IL_0554;
																														case 36:
																														case 115:
																															goto IL_0562;
																														case 38:
																															goto IL_057e;
																														case 71:
																														case 103:
																															goto IL_058c;
																														case 55:
																														case 68:
																															goto IL_0597;
																														case 100:
																															goto IL_05a5;
																														case 19:
																														case 33:
																															goto IL_05b3;
																														case 46:
																															goto IL_05cc;
																														case 108:
																															goto IL_05da;
																														case 8:
																															goto IL_05e8;
																														case 90:
																															goto IL_05fb;
																														case 4:
																														case 81:
																															goto IL_0609;
																														case 47:
																															goto IL_0617;
																														case 93:
																															goto IL_063a;
																														case 35:
																															goto IL_0644;
																														case 16:
																															goto IL_0652;
																														case 20:
																														case 64:
																															goto IL_0665;
																														case 51:
																															goto IL_06a5;
																														case 92:
																															goto IL_06b9;
																														case 1:
																														case 18:
																														case 23:
																														case 29:
																														case 34:
																														case 42:
																														case 48:
																														case 56:
																														case 59:
																														case 60:
																														case 65:
																														case 77:
																														case 82:
																														case 86:
																														case 95:
																														case 110:
																														case 111:
																														case 113:
																														case 116:
																														case 120:
																															goto end_IL_0260;
																														case 106:
																															goto IL_06ec;
																														case 85:
																															goto IL_06fa;
																														case 10:
																															goto IL_0711;
																														case 2:
																														case 5:
																														case 37:
																														case 40:
																														case 54:
																														case 58:
																														case 63:
																														case 66:
																														case 79:
																														case 84:
																														case 94:
																														case 97:
																														case 102:
																														case 117:
																														case 119:
																															goto end_IL_0290;
																														case 31:
																															goto end_IL_0728;
																														case 107:
																															goto end_IL_073b;
																														case 69:
																															goto end_IL_0745;
																														case 0:
																															goto end_IL_0750;
																														case 53:
																															goto end_IL_0765;
																														case 67:
																														case 118:
																															goto end_IL_077a;
																														case 9:
																															goto end_IL_078a;
																														case 14:
																														case 43:
																															goto end_IL_079a;
																														case 12:
																															goto end_IL_07aa;
																														case 13:
																															goto end_IL_07ba;
																														case 17:
																														case 87:
																															goto IL_07d5;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto IL_046e;
																													IL_046e:
																													num5--;
																													goto end_IL_0290;
																													continue;
																													end_IL_0219:
																													break;
																												}
																												break;
																											}
																											goto IL_0426;
																											continue;
																											end_IL_0260:
																											break;
																											IL_0260:;
																										}
																										break;
																									}
																									goto IL_02eb;
																									IL_0307:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0290;
																									IL_02eb:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_02f9;
																									IL_02f9:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0307;
																								}
																								break;
																							}
																							goto IL_031f;
																							IL_0426:
																							array[num5 - 2] = 0;
																							goto IL_043a;
																							IL_031f:
																							if (3 > b)
																							{
																								goto IL_032d;
																							}
																							goto IL_03e6;
																							IL_032d:
																							if (1 < b)
																							{
																								goto IL_033b;
																							}
																							num = 76;
																							goto IL_03d3;
																							IL_033b:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0349;
																							IL_0349:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0357;
																							IL_0357:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_044d;
																							IL_044d:
																							num5 -= 2;
																							goto end_IL_0290;
																							IL_043a:
																							num5--;
																							goto end_IL_0290;
																							IL_03d3:
																							if (1 <= b)
																							{
																							}
																							break;
																							IL_03e6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0426;
																						}
																						goto end_IL_02b0;
																						continue;
																						end_IL_0290:
																						break;
																						IL_0290:;
																					}
																					break;
																				}
																				goto IL_0481;
																				IL_06b9:
																				num5--;
																				break;
																				IL_0481:
																				if (9 < b)
																				{
																					goto IL_048f;
																				}
																				goto IL_057e;
																				IL_048f:
																				if (11 >= b)
																				{
																					goto IL_049d;
																				}
																				goto IL_0546;
																				IL_049d:
																				if (11 <= b)
																				{
																					goto IL_04a8;
																				}
																				goto IL_04bb;
																				IL_04a8:
																				num5--;
																				break;
																				IL_04bb:
																				if (10 < b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_04c9;
																				IL_04c9:
																				if (10 > b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_04d7;
																				IL_04d7:
																				array[num5 - 1] = 0;
																				num = 78;
																				goto IL_04f4;
																				IL_04f4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)GetEventProviderNameTrue[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0533;
																				IL_0533:
																				ptr2 += 8;
																				break;
																				IL_0546:
																				if (12 < b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_0554;
																				IL_0554:
																				if (12 > b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_0562;
																				IL_0562:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_057e:
																				if (9 > b)
																				{
																					goto IL_058c;
																				}
																				goto IL_0665;
																				IL_058c:
																				if (7 < b)
																				{
																					goto IL_0597;
																				}
																				goto IL_05fb;
																				IL_0597:
																				if (8 < b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_05a5;
																				IL_05a5:
																				if (8 > b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_05b3;
																				IL_05b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05cc;
																				IL_05cc:
																				array[num5] = 0;
																				goto IL_05da;
																				IL_05da:
																				num5++;
																				goto IL_05e8;
																				IL_05e8:
																				ptr2 += 8;
																				break;
																				IL_05fb:
																				if (7 > b)
																				{
																					goto end_IL_02b0;
																				}
																				goto IL_0609;
																				IL_0609:
																				array[num5] = 0;
																				goto IL_0617;
																				IL_0617:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_063a;
																				IL_063a:
																				array2[num5] = null;
																				goto IL_0644;
																				IL_0644:
																				num5++;
																				goto IL_0652;
																				IL_0652:
																				ptr2 += 8;
																				break;
																				IL_0665:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06a5;
																				IL_06a5:
																				array[num5 - 2] = 0;
																				goto IL_06b9;
																			}
																			goto end_IL_02c0;
																			continue;
																			end_IL_02b0:
																			break;
																			IL_02b0:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06ec;
																	IL_0711:
																	ptr2 += 8;
																	num = 54;
																	break;
																	IL_06fa:
																	num5++;
																	num = 10;
																	goto IL_0711;
																	IL_06ec:
																	array[num5] = 0;
																	goto IL_06fa;
																	continue;
																	end_IL_02c0:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07d5;
													IL_07d5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0728:
													break;
												}
												continue;
												end_IL_073b:
												break;
											}
											continue;
											end_IL_0745:
											break;
										}
										continue;
										end_IL_0750:
										break;
									}
									continue;
									end_IL_0765:
									break;
								}
								continue;
								end_IL_077a:
								break;
							}
							continue;
							end_IL_078a:
							break;
						}
						continue;
						end_IL_079a:
						break;
					}
					continue;
					end_IL_07aa:
					break;
				}
				continue;
				end_IL_07ba:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num != 995)
						{
							return;
						}
						switch (num)
						{
						case 0:
							goto end_IL_0041;
						case 1:
							goto end_IL_004e;
						case 6:
							goto IL_0066;
						case 2:
						case 7:
							goto IL_0088;
						case 5:
							goto IL_008e;
						case 3:
						case 4:
							return;
						}
						continue;
					}
					num3 = 0;
					goto IL_0088;
					IL_0088:
					if (num3 != 30)
					{
						goto IL_0066;
					}
					goto IL_008e;
					IL_0066:
					((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class175, void>)OldNamesCaseSensitive[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
					goto IL_0088;
					IL_008e:
					num3 = 0;
					return;
					continue;
					end_IL_0041:
					break;
				}
				continue;
				end_IL_004e:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 5;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StoppedgetObjectType.NullableISubcategoryMembershipEntry);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0255:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0238:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0228:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0218:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0205:
																									if (2 > b)
																									{
																										num = 73;
																										while (1 >= b)
																										{
																											num = 109;
																											while (true)
																											{
																												if (num != 109)
																												{
																													if (num != 1090)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 37:
																													case 73:
																														goto IL_01f2;
																													case 63:
																														goto IL_0205;
																													case 50:
																														goto IL_0218;
																													case 28:
																														goto IL_0228;
																													case 83:
																														goto IL_0238;
																													case 94:
																														goto IL_0245;
																													case 77:
																														goto IL_0255;
																													case 86:
																														goto end_IL_0255;
																													case 43:
																													case 79:
																														goto end_IL_0265;
																													case 66:
																													case 72:
																														goto IL_0280;
																													case 47:
																														goto IL_028b;
																													case 38:
																													case 69:
																														goto IL_0296;
																													case 70:
																														goto IL_02a4;
																													case 30:
																														goto IL_02b7;
																													case 4:
																														goto IL_02d3;
																													case 12:
																													case 57:
																														goto IL_02de;
																													case 59:
																														goto IL_02ec;
																													case 20:
																													case 87:
																														goto end_IL_01df;
																													case 19:
																														goto IL_0361;
																													case 88:
																														goto IL_0374;
																													case 74:
																														goto IL_0382;
																													case 10:
																													case 46:
																														goto IL_0390;
																													case 91:
																														goto IL_03b3;
																													case 44:
																													case 98:
																														goto IL_03c3;
																													case 18:
																														goto IL_03ec;
																													case 32:
																														goto IL_03fa;
																													case 100:
																														goto IL_040d;
																													case 16:
																														goto IL_041b;
																													case 80:
																													case 101:
																														goto IL_042e;
																													case 93:
																														goto IL_046e;
																													case 7:
																														goto IL_0482;
																													case 31:
																													case 102:
																														goto IL_0495;
																													case 9:
																													case 78:
																														goto IL_04c8;
																													case 96:
																														goto IL_04e1;
																													case 85:
																														goto IL_04ef;
																													case 64:
																														goto IL_04fd;
																													case 56:
																														goto IL_0510;
																													case 22:
																														goto IL_051b;
																													case 62:
																													case 71:
																														goto IL_0529;
																													case 34:
																														goto IL_0541;
																													case 90:
																														goto IL_054c;
																													case 36:
																													case 67:
																														goto IL_055c;
																													case 97:
																														goto IL_0573;
																													case 1:
																														goto IL_0596;
																													case 84:
																														goto IL_05a9;
																													case 39:
																														goto IL_05b7;
																													case 2:
																													case 6:
																													case 8:
																													case 21:
																													case 23:
																													case 24:
																													case 25:
																													case 26:
																													case 33:
																													case 35:
																													case 41:
																													case 55:
																													case 58:
																													case 61:
																													case 76:
																													case 81:
																													case 82:
																													case 99:
																														goto end_IL_01f2;
																													case 11:
																													case 13:
																													case 15:
																													case 17:
																													case 27:
																													case 29:
																													case 40:
																													case 45:
																													case 49:
																													case 51:
																													case 65:
																													case 75:
																													case 95:
																														goto end_IL_0275;
																													case 60:
																														goto end_IL_05da;
																													case 42:
																														goto end_IL_05ed;
																													case 52:
																														goto end_IL_05f7;
																													case 5:
																														goto end_IL_0602;
																													case 0:
																													case 68:
																														goto end_IL_0617;
																													case 92:
																														goto end_IL_0627;
																													case 3:
																													case 48:
																														goto end_IL_0640;
																													case 53:
																														goto end_IL_0650;
																													case 54:
																														goto end_IL_0660;
																													case 14:
																													case 89:
																														goto IL_067b;
																													}
																													continue;
																												}
																												if (1 > b)
																												{
																													goto end_IL_01f2;
																												}
																												goto IL_04c8;
																												IL_04e1:
																												array[num5] = 0;
																												goto IL_04ef;
																												IL_04fd:
																												ptr2 += 8;
																												goto end_IL_0275;
																												IL_04ef:
																												num5++;
																												goto IL_04fd;
																												IL_04c8:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_04e1;
																												continue;
																												end_IL_01df:
																												break;
																											}
																											goto IL_02ff;
																											continue;
																											end_IL_01f2:
																											break;
																											IL_01f2:;
																										}
																										break;
																									}
																									goto IL_03c3;
																									IL_03ec:
																									ptr2 += 8;
																									goto IL_03fa;
																									IL_03fa:
																									num5--;
																									goto end_IL_0275;
																									IL_03c3:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03ec;
																								}
																								break;
																							}
																							goto IL_0510;
																							IL_054c:
																							if (4 <= b)
																							{
																								goto end_IL_0275;
																							}
																							break;
																							IL_0510:
																							if (3 >= b)
																							{
																								goto IL_051b;
																							}
																							goto IL_0541;
																							IL_051b:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0529;
																							IL_0529:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0275;
																							IL_0541:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_054c;
																						}
																						break;
																					}
																					goto IL_055c;
																					IL_05b7:
																					ptr2 += 8;
																					goto end_IL_0275;
																					IL_055c:
																					array[num5] = 0;
																					num = 97;
																					goto IL_0573;
																					IL_0573:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0596;
																					IL_0596:
																					array2[num5] = null;
																					num = 84;
																					goto IL_05a9;
																					IL_05a9:
																					num5++;
																					goto IL_05b7;
																				}
																				break;
																			}
																			goto IL_0280;
																			IL_02ff:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0361;
																			IL_0280:
																			if (8 < b)
																			{
																				goto IL_028b;
																			}
																			num = 4;
																			goto IL_02d3;
																			IL_028b:
																			if (9 < b)
																			{
																				goto IL_0296;
																			}
																			goto IL_02b7;
																			IL_0296:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_02a4;
																			IL_02a4:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_02b7:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0495;
																			IL_0495:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 45;
																			goto end_IL_0275;
																			IL_0361:
																			num5 -= 2;
																			goto end_IL_0275;
																			IL_02d3:
																			if (8 > b)
																			{
																				goto IL_02de;
																			}
																			goto IL_02ff;
																			IL_02de:
																			if (6 >= b)
																			{
																				goto IL_02ec;
																			}
																			goto IL_0374;
																			IL_02ec:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_042e;
																			IL_042e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_046e;
																			IL_046e:
																			array[num5 - 2] = 0;
																			goto IL_0482;
																			IL_0482:
																			num5--;
																			goto end_IL_0275;
																			IL_0374:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0382;
																			IL_0382:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0390;
																			IL_0390:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03b3;
																			IL_03b3:
																			array[num5] = 0;
																			goto IL_040d;
																			IL_040d:
																			num5++;
																			goto IL_041b;
																			IL_041b:
																			ptr2 += 8;
																			goto end_IL_0275;
																		}
																		break;
																		IL_0245:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0275;
																continue;
																end_IL_0255:
																break;
															}
															continue;
															end_IL_0265:
															break;
														}
														continue;
														end_IL_0275:
														break;
													}
													continue;
												}
												goto IL_067b;
												IL_067b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05da:
												break;
											}
											continue;
											end_IL_05ed:
											break;
										}
										continue;
										end_IL_05f7:
										break;
									}
									continue;
									end_IL_0602:
									break;
								}
								continue;
								end_IL_0617:
								break;
							}
							continue;
							end_IL_0627:
							break;
						}
						continue;
						end_IL_0640:
						break;
					}
					continue;
					end_IL_0650:
					break;
				}
				continue;
				end_IL_0660:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0, int int_1)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 82;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 48;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SafeIsolatedStorageFileHandleGetXsdType.MicrosoftTelemetryIDRole);
												num = 56;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_029e:
																		if (b >= 1)
																		{
																			num = 53;
																			while (b <= 11)
																			{
																				while (true)
																				{
																					if (6 >= b)
																					{
																						while (true)
																						{
																							if (6 > b)
																							{
																								while (true)
																								{
																									IL_025e:
																									if (3 >= b)
																									{
																										while (true)
																										{
																											IL_0251:
																											if (3 > b)
																											{
																												while (true)
																												{
																													IL_023e:
																													if (1 < b)
																													{
																														num = 128;
																														while (true)
																														{
																															if (num != 128)
																															{
																																if (num != 1109)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 12:
																																	goto IL_023e;
																																case 63:
																																	goto IL_0251;
																																case 61:
																																case 97:
																																	goto IL_025e;
																																case 72:
																																	goto end_IL_025e;
																																case 66:
																																	goto end_IL_026e;
																																case 53:
																																	goto end_IL_027e;
																																case 93:
																																	goto IL_029e;
																																case 13:
																																	goto end_IL_029e;
																																case 28:
																																case 65:
																																	goto end_IL_02b1;
																																case 37:
																																case 47:
																																	goto IL_02cc;
																																case 30:
																																	goto IL_02f5;
																																case 4:
																																case 62:
																																	goto IL_0305;
																																case 59:
																																	goto IL_0345;
																																case 94:
																																	goto IL_0359;
																																case 118:
																																	goto IL_036c;
																																case 29:
																																	goto IL_037f;
																																case 83:
																																	goto IL_038d;
																																case 60:
																																case 89:
																																	goto IL_039b;
																																case 73:
																																	goto IL_03db;
																																case 90:
																																	goto IL_03ef;
																																case 76:
																																	goto IL_0402;
																																case 6:
																																case 119:
																																	goto end_IL_022b;
																																case 42:
																																case 107:
																																	goto IL_0420;
																																case 71:
																																	goto IL_042e;
																																case 11:
																																case 52:
																																	goto IL_043c;
																																case 7:
																																	goto IL_044a;
																																case 87:
																																	goto IL_046d;
																																case 43:
																																	goto IL_0477;
																																case 114:
																																	goto IL_0485;
																																case 80:
																																	goto IL_0498;
																																case 3:
																																case 49:
																																	goto IL_04a6;
																																case 78:
																																	goto IL_04e6;
																																case 88:
																																	goto IL_04fa;
																																case 24:
																																	goto IL_050d;
																																case 45:
																																	goto IL_051b;
																																case 55:
																																case 99:
																																	goto IL_0529;
																																case 84:
																																	goto IL_0537;
																																case 96:
																																	goto IL_0545;
																																case 79:
																																case 85:
																																	goto IL_0553;
																																case 35:
																																	goto IL_0593;
																																case 26:
																																	goto IL_05a7;
																																case 31:
																																	goto IL_05cc;
																																case 15:
																																case 81:
																																	goto IL_05e5;
																																case 75:
																																	goto IL_0607;
																																case 51:
																																	goto IL_0615;
																																case 23:
																																	goto IL_062c;
																																case 38:
																																case 98:
																																	goto IL_063f;
																																case 110:
																																	goto IL_064d;
																																case 68:
																																	goto IL_0671;
																																case 5:
																																	goto IL_067f;
																																case 17:
																																	goto IL_0692;
																																case 9:
																																	goto IL_069d;
																																case 117:
																																	goto IL_06a8;
																																case 41:
																																case 74:
																																	goto IL_06b3;
																																case 20:
																																	goto IL_06d7;
																																case 10:
																																case 33:
																																	goto IL_06e2;
																																case 1:
																																case 2:
																																case 8:
																																case 14:
																																case 18:
																																case 19:
																																case 25:
																																case 34:
																																case 44:
																																case 46:
																																case 54:
																																case 58:
																																case 64:
																																case 69:
																																case 70:
																																case 77:
																																case 86:
																																case 101:
																																case 102:
																																case 109:
																																case 121:
																																	goto end_IL_028e;
																																case 120:
																																	goto IL_0715;
																																case 0:
																																	goto IL_0723;
																																case 36:
																																	goto IL_073a;
																																case 21:
																																case 22:
																																case 32:
																																case 50:
																																case 57:
																																case 67:
																																case 100:
																																case 103:
																																case 106:
																																case 108:
																																case 111:
																																case 112:
																																case 116:
																																	goto end_IL_02c1;
																																case 56:
																																	goto end_IL_0748;
																																case 104:
																																	goto end_IL_075b;
																																case 105:
																																	goto end_IL_0765;
																																case 95:
																																	goto end_IL_0779;
																																case 27:
																																	goto end_IL_078e;
																																case 48:
																																	goto end_IL_07a3;
																																case 115:
																																	goto end_IL_07b3;
																																case 82:
																																	goto end_IL_07c3;
																																case 40:
																																case 113:
																																	goto end_IL_07ce;
																																case 91:
																																	goto end_IL_07de;
																																case 92:
																																	goto end_IL_07f7;
																																case 16:
																																case 39:
																																	goto IL_0812;
																																}
																																continue;
																															}
																															goto IL_037f;
																															IL_03db:
																															array[num5 - 2] = 0;
																															goto IL_03ef;
																															IL_03ef:
																															num5--;
																															goto end_IL_02c1;
																															IL_037f:
																															if (2 < b)
																															{
																																goto end_IL_028e;
																															}
																															goto IL_038d;
																															IL_038d:
																															if (2 > b)
																															{
																																goto end_IL_028e;
																															}
																															goto IL_039b;
																															IL_039b:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_03db;
																															continue;
																															end_IL_022b:
																															break;
																														}
																														break;
																													}
																													goto IL_0402;
																													IL_0402:
																													if (1 > b)
																													{
																													}
																													goto end_IL_028e;
																												}
																												break;
																											}
																											goto IL_02cc;
																											IL_036c:
																											num5--;
																											goto end_IL_02c1;
																											IL_02cc:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_02f5;
																											IL_02f5:
																											ptr2 += 8;
																											goto IL_036c;
																										}
																									}
																									if (4 < b)
																									{
																										goto IL_0420;
																									}
																									goto IL_0498;
																									IL_04fa:
																									num5--;
																									goto end_IL_02c1;
																									IL_04e6:
																									array[num5 - 2] = 0;
																									goto IL_04fa;
																									IL_0420:
																									if (5 < b)
																									{
																										goto end_IL_028e;
																									}
																									goto IL_042e;
																									IL_042e:
																									if (5 > b)
																									{
																										goto end_IL_028e;
																									}
																									goto IL_043c;
																									IL_043c:
																									array[num5] = 0;
																									goto IL_044a;
																									IL_044a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_046d;
																									IL_046d:
																									array2[num5] = null;
																									goto IL_0477;
																									IL_0477:
																									num5++;
																									goto IL_0485;
																									IL_0485:
																									ptr2 += 8;
																									goto end_IL_02c1;
																									IL_0498:
																									if (4 > b)
																									{
																										goto end_IL_028e;
																									}
																									goto IL_04a6;
																									IL_04a6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04e6;
																									continue;
																									end_IL_025e:
																									break;
																								}
																								continue;
																							}
																							goto IL_0305;
																							IL_0359:
																							num5--;
																							goto end_IL_02c1;
																							IL_0305:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0345;
																							IL_0345:
																							array[num5 - 2] = 0;
																							goto IL_0359;
																							continue;
																							end_IL_026e:
																							break;
																						}
																						continue;
																					}
																					goto IL_050d;
																					IL_06b3:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02c1;
																					IL_050d:
																					if (9 >= b)
																					{
																						goto IL_051b;
																					}
																					goto IL_0692;
																					IL_051b:
																					if (9 > b)
																					{
																						goto IL_0529;
																					}
																					goto IL_063f;
																					IL_0529:
																					if (7 < b)
																					{
																						goto IL_0537;
																					}
																					num = 31;
																					goto IL_05cc;
																					IL_0537:
																					if (8 < b)
																					{
																						goto end_IL_028e;
																					}
																					goto IL_0545;
																					IL_0545:
																					if (8 > b)
																					{
																						goto end_IL_028e;
																					}
																					goto IL_0553;
																					IL_0553:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0593;
																					IL_0593:
																					array[num5 - 2] = 0;
																					goto IL_05a7;
																					IL_05a7:
																					num5--;
																					num = 112;
																					goto end_IL_02c1;
																					IL_06e2:
																					num5--;
																					goto end_IL_02c1;
																					IL_05cc:
																					if (7 > b)
																					{
																						num = 121;
																						goto end_IL_028e;
																					}
																					goto IL_05e5;
																					IL_06d7:
																					if (10 > b)
																					{
																						goto end_IL_028e;
																					}
																					goto IL_06e2;
																					IL_05e5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 75;
																					goto IL_0607;
																					IL_0607:
																					array[num5] = 0;
																					goto IL_0615;
																					IL_0615:
																					num5++;
																					num = 23;
																					goto IL_062c;
																					IL_062c:
																					ptr2 += 8;
																					goto end_IL_02c1;
																					IL_063f:
																					array[num5] = 0;
																					goto IL_064d;
																					IL_064d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)IsBrowserDisplaySetDeploymentMetadata[*(int*)(ptr2 + num3)])();
																					goto IL_0671;
																					IL_0671:
																					num5++;
																					goto IL_067f;
																					IL_067f:
																					ptr2 += 8;
																					goto end_IL_02c1;
																					IL_0692:
																					if (10 < b)
																					{
																						goto IL_069d;
																					}
																					goto IL_06d7;
																					IL_069d:
																					if (11 < b)
																					{
																						goto end_IL_028e;
																					}
																					goto IL_06a8;
																					IL_06a8:
																					if (11 > b)
																					{
																						num = 109;
																						goto end_IL_028e;
																					}
																					goto IL_06b3;
																					continue;
																					end_IL_027e:
																					break;
																				}
																				continue;
																				end_IL_028e:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0715;
																		IL_0723:
																		num5++;
																		num = 36;
																		goto IL_073a;
																		IL_073a:
																		ptr2 += 8;
																		goto end_IL_02c1;
																		IL_0715:
																		array[num5] = 0;
																		goto IL_0723;
																		continue;
																		end_IL_029e:
																		break;
																	}
																	continue;
																	end_IL_02b1:
																	break;
																}
																continue;
																end_IL_02c1:
																break;
															}
															continue;
														}
														goto IL_0812;
														IL_0812:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0748:
														break;
													}
													continue;
													end_IL_075b:
													break;
												}
												continue;
												end_IL_0765:
												break;
											}
											continue;
											end_IL_0779:
											break;
										}
										continue;
										end_IL_078e:
										break;
									}
									continue;
									end_IL_07a3:
									break;
								}
								continue;
								end_IL_07b3:
								break;
							}
							continue;
							end_IL_07c3:
							break;
						}
						continue;
						end_IL_07ce:
						break;
					}
					continue;
					end_IL_07de:
					break;
				}
				continue;
				end_IL_07f7:
				break;
			}
		}
	}

	private static int smethod_3(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		if (num <= num2)
		{
			num = int_1;
			num2 = int_0;
			return num - num2;
		}
		num = int_0;
		num2 = int_1;
		return num - num2;
	}

	private unsafe void method_0()
	{
		int num = 164;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FinishLockRegion.FormatBasicGenericEqualityComparer);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_04a0:
															byte b = *ptr2;
															while (true)
															{
																IL_0490:
																ptr2++;
																while (true)
																{
																	IL_0480:
																	if (b >= 1)
																	{
																		while (b <= 25)
																		{
																			while (true)
																			{
																				IL_0463:
																				if (13 < b)
																				{
																					while (true)
																					{
																						IL_0456:
																						if (19 < b)
																						{
																							while (true)
																							{
																								IL_0446:
																								if (22 >= b)
																								{
																									while (true)
																									{
																										IL_0436:
																										if (22 > b)
																										{
																											while (true)
																											{
																												IL_0426:
																												if (20 < b)
																												{
																													while (21 >= b)
																													{
																														while (21 <= b)
																														{
																															while (true)
																															{
																																IL_03f0:
																																array[num6 - 1] = 3;
																																while (true)
																																{
																																	IL_03af:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ReleaseThreadCacheNextActivator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																																	while (true)
																																	{
																																		IL_0396:
																																		ptr2 += 8;
																																		num = 221;
																																		while (num != 221)
																																		{
																																			if (num != 1202)
																																			{
																																				goto IL_090a;
																																			}
																																			switch (num)
																																			{
																																			case 173:
																																				goto IL_0396;
																																			case 203:
																																				goto IL_03af;
																																			case 47:
																																			case 168:
																																				goto IL_03f0;
																																			case 138:
																																				goto IL_0406;
																																			case 143:
																																				goto IL_0416;
																																			case 71:
																																				goto IL_0426;
																																			case 147:
																																				goto IL_0436;
																																			case 84:
																																				goto IL_0446;
																																			case 179:
																																				goto IL_0456;
																																			case 4:
																																				goto IL_0463;
																																			case 144:
																																				goto IL_0470;
																																			case 72:
																																				goto IL_0480;
																																			case 97:
																																				goto IL_0490;
																																			case 61:
																																			case 82:
																																				goto IL_04a0;
																																			case 11:
																																				goto IL_04b4;
																																			case 111:
																																				goto IL_04d0;
																																			case 96:
																																			case 119:
																																				goto IL_04de;
																																			case 7:
																																				goto IL_050c;
																																			case 13:
																																			case 121:
																																				goto IL_051f;
																																			case 108:
																																				goto IL_055f;
																																			case 122:
																																				goto IL_0578;
																																			case 161:
																																				goto IL_0588;
																																			case 166:
																																				goto IL_059b;
																																			case 85:
																																				goto IL_05a6;
																																			case 57:
																																			case 58:
																																				goto IL_05b4;
																																			case 91:
																																				goto IL_05d1;
																																			case 89:
																																				goto IL_05df;
																																			case 25:
																																			case 184:
																																				goto IL_05f2;
																																			case 182:
																																				goto IL_060b;
																																			case 81:
																																				goto IL_0619;
																																			case 133:
																																				goto IL_0627;
																																			case 190:
																																				goto IL_063a;
																																			case 189:
																																				goto IL_0648;
																																			case 141:
																																				goto IL_0656;
																																			case 77:
																																			case 117:
																																				goto IL_0661;
																																			case 103:
																																				goto IL_06a1;
																																			case 22:
																																				goto IL_06b5;
																																			case 162:
																																				goto IL_06c8;
																																			case 131:
																																				goto IL_06d3;
																																			case 115:
																																				goto IL_06e6;
																																			case 158:
																																				goto IL_06f4;
																																			case 48:
																																			case 66:
																																				goto IL_0702;
																																			case 0:
																																				goto IL_0715;
																																			case 49:
																																				goto IL_0723;
																																			case 12:
																																			case 95:
																																				goto IL_0731;
																																			case 64:
																																				goto IL_0745;
																																			case 37:
																																				goto IL_0799;
																																			case 36:
																																				goto IL_07ac;
																																			case 142:
																																				goto IL_07c8;
																																			case 128:
																																				goto IL_07d6;
																																			case 127:
																																				goto IL_07e4;
																																			case 60:
																																				goto IL_07f2;
																																			case 126:
																																				goto IL_07fd;
																																			case 3:
																																			case 94:
																																				goto IL_080b;
																																			case 112:
																																				goto IL_0824;
																																			case 44:
																																				goto IL_0832;
																																			case 107:
																																				goto IL_0840;
																																			case 124:
																																				goto IL_085c;
																																			case 183:
																																				goto IL_086a;
																																			case 14:
																																			case 17:
																																				goto IL_0878;
																																			case 18:
																																				goto IL_08c1;
																																			case 86:
																																				goto IL_08de;
																																			case 146:
																																				goto IL_08f1;
																																			case 186:
																																				goto IL_08fc;
																																			case 136:
																																			case 178:
																																				goto IL_090a;
																																			case 5:
																																				goto IL_0918;
																																			case 160:
																																				goto IL_093b;
																																			case 106:
																																				goto IL_0945;
																																			case 125:
																																				goto IL_095c;
																																			case 102:
																																				goto IL_0978;
																																			case 39:
																																				goto IL_0986;
																																			case 78:
																																			case 150:
																																				goto IL_0994;
																																			case 130:
																																				goto IL_09d4;
																																			case 24:
																																				goto IL_09e8;
																																			case 191:
																																				goto IL_0a09;
																																			case 192:
																																				goto IL_0a1c;
																																			case 198:
																																				goto IL_0a38;
																																			case 83:
																																				goto IL_0a46;
																																			case 88:
																																				goto IL_0a51;
																																			case 32:
																																			case 153:
																																				goto IL_0a5f;
																																			case 79:
																																				goto IL_0a77;
																																			case 51:
																																				goto IL_0a85;
																																			case 187:
																																			case 194:
																																				goto IL_0a93;
																																			case 65:
																																				goto IL_0ad4;
																																			case 16:
																																				goto IL_0ae8;
																																			case 201:
																																				goto IL_0b04;
																																			case 202:
																																				goto IL_0b17;
																																			case 67:
																																				goto IL_0b25;
																																			case 52:
																																			case 193:
																																				goto IL_0b33;
																																			case 110:
																																				goto IL_0b95;
																																			case 76:
																																			case 204:
																																				goto IL_0ba8;
																																			case 123:
																																				goto IL_0bc1;
																																			case 23:
																																				goto IL_0bcf;
																																			case 43:
																																				goto IL_0bdd;
																																			case 152:
																																			case 207:
																																				goto IL_0bf0;
																																			case 100:
																																				goto IL_0c42;
																																			case 55:
																																			case 208:
																																				goto IL_0c55;
																																			case 134:
																																				goto IL_0c7e;
																																			case 75:
																																				goto IL_0c8c;
																																			case 73:
																																			case 209:
																																				goto IL_0c9f;
																																			case 114:
																																				goto IL_0cdf;
																																			case 68:
																																				goto IL_0cf3;
																																			case 210:
																																				goto IL_0d06;
																																			case 139:
																																				goto IL_0d14;
																																			case 151:
																																			case 211:
																																				goto IL_0d24;
																																			case 197:
																																				goto IL_0d64;
																																			case 205:
																																				goto IL_0d78;
																																			case 213:
																																				goto IL_0d8b;
																																			case 167:
																																			case 214:
																																				goto IL_0d9e;
																																			case 42:
																																				goto IL_0db8;
																																			case 41:
																																				goto IL_0dc6;
																																			case 157:
																																				goto IL_0dd4;
																																			case 69:
																																				goto IL_0de7;
																																			case 93:
																																				goto IL_0df5;
																																			case 30:
																																			case 113:
																																				goto IL_0e00;
																																			case 116:
																																				goto IL_0e1c;
																																			case 137:
																																				goto IL_0e2a;
																																			case 74:
																																			case 156:
																																				goto IL_0e35;
																																			case 104:
																																				goto IL_0e49;
																																			case 46:
																																				goto IL_0e88;
																																			case 195:
																																				goto IL_0e98;
																																			case 35:
																																				goto IL_0ea3;
																																			case 1:
																																			case 6:
																																			case 9:
																																			case 10:
																																			case 15:
																																			case 19:
																																			case 34:
																																			case 38:
																																			case 40:
																																			case 53:
																																			case 56:
																																			case 63:
																																			case 90:
																																			case 98:
																																			case 99:
																																			case 101:
																																			case 118:
																																			case 135:
																																			case 148:
																																			case 154:
																																			case 159:
																																			case 165:
																																			case 176:
																																			case 177:
																																			case 180:
																																			case 196:
																																			case 199:
																																			case 206:
																																				goto end_IL_0406;
																																			case 2:
																																			case 8:
																																			case 20:
																																			case 27:
																																			case 28:
																																			case 29:
																																			case 31:
																																			case 33:
																																			case 50:
																																			case 59:
																																			case 80:
																																			case 87:
																																			case 92:
																																			case 109:
																																			case 120:
																																			case 129:
																																			case 132:
																																			case 145:
																																			case 149:
																																			case 169:
																																			case 170:
																																			case 171:
																																			case 172:
																																			case 181:
																																			case 185:
																																			case 188:
																																			case 200:
																																				goto end_IL_0383;
																																			case 45:
																																				goto end_IL_0eca;
																																			case 174:
																																				goto end_IL_0edd;
																																			case 212:
																																				goto end_IL_0ee7;
																																			case 21:
																																				goto end_IL_0ef2;
																																			case 175:
																																				goto end_IL_0f02;
																																			case 54:
																																			case 140:
																																				goto end_IL_0f12;
																																			case 70:
																																				goto end_IL_0f22;
																																			case 105:
																																				goto end_IL_0f32;
																																			case 26:
																																				goto end_IL_0f42;
																																			case 163:
																																				goto end_IL_0f52;
																																			case 164:
																																				goto end_IL_0f62;
																																			case 62:
																																			case 155:
																																				return;
																																			}
																																			continue;
																																			end_IL_0383:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_0480;
																															continue;
																															end_IL_0406:
																															break;
																															IL_0406:;
																														}
																														break;
																														IL_0416:;
																													}
																													break;
																												}
																												goto IL_0588;
																												IL_0bdd:
																												ptr2 += 16;
																												goto end_IL_0480;
																												IL_0588:
																												if (20 > b)
																												{
																													break;
																												}
																												goto IL_0ba8;
																												IL_0ba8:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																												goto IL_0bc1;
																												IL_0bc1:
																												array[num6] = 3;
																												goto IL_0bcf;
																												IL_0bcf:
																												num6++;
																												goto IL_0bdd;
																											}
																											break;
																										}
																										goto IL_051f;
																										IL_0b04:
																										num6--;
																										goto end_IL_0480;
																										IL_051f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_055f;
																										IL_055f:
																										array[num6 - 2] = 3;
																										goto IL_0b04;
																									}
																									break;
																								}
																								goto IL_0de7;
																								IL_0ea3:
																								if (25 <= b)
																								{
																								}
																								break;
																								IL_0de7:
																								if (24 >= b)
																								{
																									goto IL_0df5;
																								}
																								goto IL_0e98;
																								IL_0df5:
																								if (24 <= b)
																								{
																									goto IL_0e00;
																								}
																								goto IL_0e1c;
																								IL_0e00:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								goto end_IL_0480;
																								IL_0e1c:
																								if (23 < b)
																								{
																									break;
																								}
																								goto IL_0e2a;
																								IL_0e2a:
																								if (23 > b)
																								{
																									break;
																								}
																								goto IL_0e35;
																								IL_0e35:
																								array[num6 - 1] = 0;
																								goto IL_0e49;
																								IL_0e49:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ReleaseThreadCacheNextActivator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_0e88;
																								IL_0e88:
																								ptr2 += 8;
																								goto end_IL_0480;
																								IL_0e98:
																								if (25 < b)
																								{
																									break;
																								}
																								goto IL_0ea3;
																							}
																							break;
																						}
																						goto IL_04d0;
																						IL_0c42:
																						num6--;
																						goto end_IL_0480;
																						IL_04d0:
																						if (19 <= b)
																						{
																							goto IL_04de;
																						}
																						goto IL_0578;
																						IL_04de:
																						((Class175)array2[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_050c;
																						IL_050c:
																						num6 -= 2;
																						goto end_IL_0480;
																						IL_0578:
																						if (16 < b)
																						{
																							goto IL_059b;
																						}
																						goto IL_0a38;
																						IL_059b:
																						if (17 >= b)
																						{
																							goto IL_05a6;
																						}
																						goto IL_05d1;
																						IL_05a6:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_05b4;
																						IL_05b4:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0d06;
																						IL_0d06:
																						array[num6] = 5;
																						goto IL_0d14;
																						IL_0d14:
																						num6++;
																						goto IL_0d8b;
																						IL_0d8b:
																						ptr2 += 8;
																						goto end_IL_0480;
																						IL_05d1:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_05df;
																						IL_05df:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0d9e;
																						IL_0d9e:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																						goto IL_0db8;
																						IL_0db8:
																						array[num6] = 3;
																						goto IL_0dc6;
																						IL_0dc6:
																						num6++;
																						goto IL_0dd4;
																						IL_0dd4:
																						ptr2 += 8;
																						goto end_IL_0480;
																						IL_0a38:
																						if (16 > b)
																						{
																							goto IL_0a46;
																						}
																						goto IL_0bf0;
																						IL_0a46:
																						if (14 >= b)
																						{
																							goto IL_0a51;
																						}
																						goto IL_0a77;
																						IL_0a51:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0a5f;
																						IL_0a5f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0480;
																						IL_0a77:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0a85;
																						IL_0a85:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_0a93;
																						IL_0a93:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0ad4;
																						IL_0ad4:
																						array[num6 - 2] = 0;
																						goto IL_0ae8;
																						IL_0ae8:
																						num6--;
																						num = 80;
																						goto end_IL_0480;
																						IL_0bf0:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c42;
																					}
																					break;
																				}
																				num = 11;
																				goto IL_04b4;
																				IL_09d4:
																				array[num6 - 2] = 0;
																				goto IL_09e8;
																				IL_09e8:
																				num6--;
																				goto end_IL_0480;
																				IL_04b4:
																				if (13 <= b)
																				{
																					num = 25;
																					goto IL_05f2;
																				}
																				goto IL_063a;
																				IL_0cf3:
																				num6--;
																				goto end_IL_0480;
																				IL_05f2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_060b;
																				IL_060b:
																				array[num6] = 1;
																				goto IL_0619;
																				IL_0619:
																				num6++;
																				goto IL_0627;
																				IL_0627:
																				ptr2 += 16;
																				goto end_IL_0480;
																				IL_063a:
																				if (6 < b)
																				{
																					goto IL_0648;
																				}
																				num = 142;
																				goto IL_07c8;
																				IL_0648:
																				if (9 >= b)
																				{
																					goto IL_0656;
																				}
																				goto IL_0715;
																				IL_0656:
																				if (9 <= b)
																				{
																					goto IL_0661;
																				}
																				goto IL_06c8;
																				IL_0661:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_06a1;
																				IL_06a1:
																				array[num6 - 2] = 0;
																				goto IL_06b5;
																				IL_06b5:
																				num6--;
																				goto end_IL_0480;
																				IL_06c8:
																				if (7 >= b)
																				{
																					goto IL_06d3;
																				}
																				goto IL_06e6;
																				IL_06d3:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0d24;
																				IL_0d24:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0d64;
																				IL_0d64:
																				array[num6 - 2] = 0;
																				goto IL_0d78;
																				IL_0d78:
																				num6--;
																				goto end_IL_0480;
																				IL_06e6:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_06f4;
																				IL_06f4:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0702;
																				IL_0702:
																				num6--;
																				goto end_IL_0480;
																				IL_0715:
																				if (11 >= b)
																				{
																					goto IL_0723;
																				}
																				goto IL_07ac;
																				IL_0723:
																				if (11 <= b)
																				{
																					goto IL_0731;
																				}
																				goto IL_0b17;
																				IL_0731:
																				array[num6 - 2] = 0;
																				goto IL_0745;
																				IL_0745:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)ReleaseThreadCacheNextActivator[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0799;
																				IL_0799:
																				num6--;
																				goto IL_0a09;
																				IL_0a09:
																				ptr2 += 8;
																				goto end_IL_0480;
																				IL_0b17:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0b25;
																				IL_0b25:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0b33;
																				IL_0b33:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0b95;
																				IL_0b95:
																				num6 -= 2;
																				goto end_IL_0480;
																				IL_07ac:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_0a1c;
																				IL_0a1c:
																				if (12 > b)
																				{
																					break;
																				}
																				num = 169;
																				goto end_IL_0480;
																				IL_0cdf:
																				array[num6 - 2] = 0;
																				goto IL_0cf3;
																				IL_0c9f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0cdf;
																				IL_07c8:
																				if (6 > b)
																				{
																					goto IL_07d6;
																				}
																				num = 73;
																				goto IL_0c9f;
																				IL_07d6:
																				if (3 >= b)
																				{
																					goto IL_07e4;
																				}
																				goto IL_08f1;
																				IL_07e4:
																				if (3 > b)
																				{
																					goto IL_07f2;
																				}
																				goto IL_0c55;
																				IL_07f2:
																				if (1 >= b)
																				{
																					goto IL_07fd;
																				}
																				goto IL_085c;
																				IL_07fd:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_080b;
																				IL_080b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0824;
																				IL_0824:
																				array[num6] = 0;
																				goto IL_0832;
																				IL_0832:
																				num6++;
																				goto IL_0840;
																				IL_0840:
																				ptr2 += 8;
																				num = 171;
																				goto end_IL_0480;
																				IL_085c:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_086a;
																				IL_086a:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0878;
																				IL_0878:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 18;
																				goto IL_08c1;
																				IL_08c1:
																				array[num6 - 2] = 0;
																				num = 86;
																				goto IL_08de;
																				IL_08de:
																				num6--;
																				goto end_IL_0480;
																				IL_0c55:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0c7e;
																				IL_0c7e:
																				ptr2 += 8;
																				goto IL_0c8c;
																				IL_0c8c:
																				num6--;
																				goto end_IL_0480;
																				IL_08f1:
																				if (4 >= b)
																				{
																					goto IL_08fc;
																				}
																				goto IL_0978;
																				IL_08fc:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_090a;
																				IL_090a:
																				array[num6] = 0;
																				goto IL_0918;
																				IL_0918:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_093b;
																				IL_093b:
																				array2[num6] = null;
																				goto IL_0945;
																				IL_0945:
																				num6++;
																				num = 125;
																				goto IL_095c;
																				IL_095c:
																				ptr2 += 8;
																				num = 20;
																				goto end_IL_0480;
																				IL_0978:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0986;
																				IL_0986:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0994;
																				IL_0994:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_09d4;
																			}
																			break;
																			IL_0470:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 50;
																	break;
																	continue;
																	end_IL_0480:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0eca:
														break;
													}
													continue;
													end_IL_0edd:
													break;
												}
												continue;
												end_IL_0ee7:
												break;
											}
											continue;
											end_IL_0ef2:
											break;
										}
										continue;
										end_IL_0f02:
										break;
									}
									continue;
									end_IL_0f12:
									break;
								}
								continue;
								end_IL_0f22:
								break;
							}
							continue;
							end_IL_0f32:
							break;
						}
						continue;
						end_IL_0f42:
						break;
					}
					continue;
					end_IL_0f52:
					break;
				}
				continue;
				end_IL_0f62:
				break;
			}
		}
	}

	private static bool IconFilegetRequestedPermissions(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private unsafe void OnDisable()
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 39;
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTypeArrayclsid.UnmanagedTypegetUri);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02cd:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ad:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_029d:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_028a:
																							if (4 >= b)
																							{
																								num = 116;
																								while (true)
																								{
																									IL_027a:
																									if (4 <= b)
																									{
																										num = 143;
																										while (true)
																										{
																											if (num != 143)
																											{
																												if (num != 1124)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 116:
																													goto IL_027a;
																												case 70:
																													goto IL_028a;
																												case 15:
																													goto IL_029d;
																												case 64:
																													goto IL_02ad;
																												case 101:
																													goto IL_02bd;
																												case 42:
																													goto IL_02cd;
																												case 117:
																													goto end_IL_02cd;
																												case 51:
																												case 130:
																													goto end_IL_02dd;
																												case 32:
																													goto IL_02f8;
																												case 23:
																													goto IL_0303;
																												case 18:
																													goto IL_0316;
																												case 31:
																													goto IL_0324;
																												case 10:
																												case 68:
																													goto IL_0332;
																												case 88:
																													goto IL_035b;
																												case 93:
																													goto IL_036e;
																												case 17:
																													goto IL_0379;
																												case 33:
																												case 72:
																													goto IL_0384;
																												case 19:
																													goto IL_03c4;
																												case 46:
																													goto IL_03dd;
																												case 86:
																													goto IL_03f0;
																												case 97:
																													goto IL_03fe;
																												case 8:
																												case 27:
																													goto IL_040c;
																												case 99:
																													goto IL_0451;
																												case 41:
																													goto IL_045f;
																												case 55:
																												case 109:
																													goto IL_0472;
																												case 69:
																													goto IL_04b2;
																												case 83:
																													goto IL_04c6;
																												case 118:
																													goto IL_04d9;
																												case 94:
																												case 103:
																													goto IL_04e7;
																												case 40:
																													goto IL_0527;
																												case 121:
																													goto IL_053d;
																												case 125:
																													goto IL_0550;
																												case 102:
																												case 128:
																													goto IL_0563;
																												case 133:
																													goto IL_0576;
																												case 73:
																													goto IL_058a;
																												case 134:
																													goto IL_059d;
																												case 136:
																													goto IL_05b0;
																												case 63:
																													goto IL_05be;
																												case 81:
																													goto IL_05e1;
																												case 119:
																													goto IL_05eb;
																												case 1:
																													goto IL_05f9;
																												case 12:
																													goto IL_060c;
																												case 110:
																													goto IL_061a;
																												case 57:
																												case 59:
																													goto IL_0625;
																												case 53:
																													goto IL_0646;
																												case 20:
																													goto IL_0654;
																												case 77:
																													goto IL_0662;
																												case 36:
																													goto IL_0675;
																												case 50:
																													goto IL_0683;
																												case 49:
																												case 90:
																													goto IL_068e;
																												case 54:
																													goto IL_06f0;
																												case 35:
																													goto IL_0703;
																												case 122:
																													goto IL_0711;
																												case 7:
																												case 89:
																													goto IL_071f;
																												case 5:
																													goto IL_075f;
																												case 85:
																													goto IL_077c;
																												case 29:
																													goto IL_078f;
																												case 58:
																													goto IL_079d;
																												case 124:
																													goto IL_07b0;
																												case 37:
																													goto IL_07be;
																												case 0:
																												case 4:
																													goto IL_07c9;
																												case 100:
																													goto IL_07f7;
																												case 28:
																													goto IL_080a;
																												case 113:
																													goto IL_0821;
																												case 67:
																												case 132:
																													goto IL_082c;
																												case 107:
																													goto IL_0846;
																												case 92:
																													goto IL_0854;
																												case 38:
																													goto IL_086b;
																												case 104:
																													goto IL_087b;
																												case 25:
																													goto IL_0886;
																												case 11:
																												case 123:
																													goto IL_0891;
																												case 2:
																												case 9:
																												case 14:
																												case 30:
																												case 34:
																												case 48:
																												case 56:
																												case 61:
																												case 65:
																												case 66:
																												case 74:
																												case 80:
																												case 87:
																												case 91:
																												case 95:
																												case 106:
																												case 115:
																												case 129:
																													goto end_IL_0267;
																												case 126:
																													goto IL_08c3;
																												case 71:
																													goto IL_08da;
																												case 22:
																													goto IL_08e8;
																												case 6:
																												case 13:
																												case 16:
																												case 26:
																												case 44:
																												case 47:
																												case 60:
																												case 62:
																												case 75:
																												case 76:
																												case 84:
																												case 98:
																												case 105:
																												case 108:
																												case 111:
																												case 114:
																												case 131:
																												case 135:
																													goto end_IL_02ed;
																												case 112:
																													goto end_IL_08f6;
																												case 120:
																													goto end_IL_0909;
																												case 127:
																													goto end_IL_0913;
																												case 43:
																													goto end_IL_091e;
																												case 82:
																													goto end_IL_092e;
																												case 39:
																												case 52:
																													goto end_IL_093e;
																												case 45:
																													goto end_IL_094e;
																												case 3:
																												case 96:
																													goto end_IL_095e;
																												case 78:
																													goto end_IL_0977;
																												case 79:
																													goto end_IL_0987;
																												case 21:
																												case 24:
																													return;
																												}
																												continue;
																											}
																											goto IL_05b0;
																											IL_05eb:
																											num5++;
																											goto IL_05f9;
																											IL_05f9:
																											ptr2 += 8;
																											goto end_IL_02ed;
																											IL_05b0:
																											array[num5] = 0;
																											goto IL_05be;
																											IL_05be:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_05e1;
																											IL_05e1:
																											array2[num5] = null;
																											goto IL_05eb;
																											continue;
																											end_IL_0267:
																											break;
																										}
																										break;
																									}
																									goto IL_02f8;
																									IL_035b:
																									ptr2 += 8;
																									goto IL_0550;
																									IL_0550:
																									num5--;
																									goto end_IL_02ed;
																									IL_02f8:
																									if (2 >= b)
																									{
																										goto IL_0303;
																									}
																									goto IL_0316;
																									IL_0303:
																									if (2 > b)
																									{
																										goto IL_0451;
																									}
																									goto IL_0472;
																									IL_0472:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04b2;
																									IL_04b2:
																									array[num5 - 2] = 0;
																									goto IL_04c6;
																									IL_04c6:
																									num5--;
																									goto end_IL_02ed;
																									IL_0451:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_045f;
																									IL_045f:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_0316:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_0324;
																									IL_0324:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0332;
																									IL_0332:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_035b;
																								}
																								break;
																							}
																							goto IL_036e;
																							IL_0576:
																							array[num5 - 2] = 0;
																							goto IL_058a;
																							IL_058a:
																							num5--;
																							goto end_IL_02ed;
																							IL_036e:
																							if (6 >= b)
																							{
																								goto IL_0379;
																							}
																							goto IL_03f0;
																							IL_0379:
																							if (6 <= b)
																							{
																								goto IL_0384;
																							}
																							goto IL_03dd;
																							IL_0384:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03c4;
																							IL_03c4:
																							array[num5 - 2] = 0;
																							goto IL_053d;
																							IL_053d:
																							num5--;
																							goto end_IL_02ed;
																							IL_03dd:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_04d9;
																							IL_04d9:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_04e7;
																							IL_04e7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0527;
																							IL_0527:
																							array[num5 - 2] = 0;
																							goto IL_059d;
																							IL_059d:
																							num5--;
																							goto end_IL_02ed;
																							IL_03f0:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_03fe;
																							IL_03fe:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_040c;
																							IL_040c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0576;
																						}
																						break;
																					}
																					goto IL_0563;
																					IL_0563:
																					num5--;
																					goto end_IL_02ed;
																				}
																				break;
																			}
																			goto IL_060c;
																			IL_0886:
																			if (15 > b)
																			{
																				break;
																			}
																			goto IL_0891;
																			IL_060c:
																			if (12 >= b)
																			{
																				goto IL_061a;
																			}
																			goto IL_07b0;
																			IL_061a:
																			if (12 <= b)
																			{
																				goto IL_0625;
																			}
																			goto IL_0675;
																			IL_0625:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 53;
																			goto IL_0646;
																			IL_0646:
																			array[num5] = 5;
																			goto IL_0654;
																			IL_0654:
																			num5++;
																			goto IL_0662;
																			IL_0662:
																			ptr2 += 8;
																			goto end_IL_02ed;
																			IL_0675:
																			if (10 >= b)
																			{
																				goto IL_0683;
																			}
																			goto IL_078f;
																			IL_0683:
																			if (10 <= b)
																			{
																				goto IL_068e;
																			}
																			goto IL_0703;
																			IL_068e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06f0;
																			IL_06f0:
																			num5 -= 2;
																			goto end_IL_02ed;
																			IL_0703:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0711;
																			IL_0711:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_071f;
																			IL_071f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_075f;
																			IL_075f:
																			array[num5 - 2] = 0;
																			num = 85;
																			goto IL_077c;
																			IL_077c:
																			num5--;
																			goto end_IL_02ed;
																			IL_078f:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_079d;
																			IL_079d:
																			if (11 > b)
																			{
																				break;
																			}
																			goto end_IL_02ed;
																			IL_07b0:
																			if (14 >= b)
																			{
																				goto IL_07be;
																			}
																			goto IL_087b;
																			IL_07be:
																			if (14 <= b)
																			{
																				goto IL_07c9;
																			}
																			goto IL_080a;
																			IL_07c9:
																			((Class175)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_07f7;
																			IL_07f7:
																			num5 -= 2;
																			goto end_IL_02ed;
																			IL_080a:
																			if (13 < b)
																			{
																				break;
																			}
																			num = 113;
																			goto IL_0821;
																			IL_0891:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02ed;
																			IL_0821:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_082c;
																			IL_082c:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																			goto IL_0846;
																			IL_0846:
																			array[num5] = 3;
																			goto IL_0854;
																			IL_0854:
																			num5++;
																			num = 38;
																			goto IL_086b;
																			IL_086b:
																			ptr2 += 8;
																			goto end_IL_02ed;
																			IL_087b:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0886;
																		}
																		break;
																		IL_02bd:;
																	}
																}
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_08c3;
																IL_08e8:
																ptr2 += 8;
																goto end_IL_02ed;
																IL_08da:
																num5++;
																goto IL_08e8;
																IL_08c3:
																array[num5] = 0;
																num = 71;
																goto IL_08da;
																continue;
																end_IL_02cd:
																break;
															}
															continue;
															end_IL_02dd:
															break;
														}
														continue;
														end_IL_02ed:
														break;
													}
													continue;
													end_IL_08f6:
													break;
												}
												continue;
												end_IL_0909:
												break;
											}
											continue;
											end_IL_0913:
											break;
										}
										continue;
										end_IL_091e:
										break;
									}
									continue;
									end_IL_092e:
									break;
								}
								continue;
								end_IL_093e:
								break;
							}
							continue;
							end_IL_094e:
							break;
						}
						continue;
						end_IL_095e:
						break;
					}
					continue;
					end_IL_0977:
					break;
				}
				continue;
				end_IL_0987:
				break;
			}
		}
	}

	public Class175()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_4(int int_0)
	{
		int num = 44;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 80;
							while (true)
							{
								int[] array3 = new int[4];
								num = 4;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UCOMIPersistFileYearDefault.getIsMethodDefGetFullPath);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02cf:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02b2:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02a2:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0292:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0285:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_024c:
																														array[num5] = 0;
																														num = 106;
																														while (true)
																														{
																															IL_0227:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_021b:
																																array2[num5] = null;
																																while (true)
																																{
																																	IL_0202:
																																	num5++;
																																	num = 120;
																																	while (true)
																																	{
																																		if (num != 120)
																																		{
																																			if (num != 1101)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 61:
																																				goto IL_0202;
																																			case 45:
																																				goto IL_021b;
																																			case 106:
																																				goto IL_0227;
																																			case 53:
																																			case 81:
																																				goto IL_024c;
																																			case 28:
																																				goto IL_0265;
																																			case 90:
																																				goto IL_0275;
																																			case 1:
																																			case 54:
																																				goto IL_0285;
																																			case 95:
																																				goto IL_0292;
																																			case 41:
																																				goto IL_02a2;
																																			case 20:
																																				goto IL_02b2;
																																			case 104:
																																				goto IL_02bf;
																																			case 63:
																																				goto IL_02cf;
																																			case 15:
																																				goto end_IL_02cf;
																																			case 27:
																																			case 100:
																																				goto end_IL_02df;
																																			case 2:
																																				goto IL_02fa;
																																			case 29:
																																			case 94:
																																				goto IL_030d;
																																			case 34:
																																			case 35:
																																				goto IL_0318;
																																			case 75:
																																				goto end_IL_01ef;
																																			case 62:
																																				goto IL_0336;
																																			case 3:
																																				goto IL_0344;
																																			case 17:
																																				goto IL_0357;
																																			case 46:
																																			case 69:
																																				goto IL_0362;
																																			case 38:
																																				goto IL_03c4;
																																			case 68:
																																				goto IL_03d7;
																																			case 6:
																																			case 25:
																																				goto IL_03e2;
																																			case 31:
																																				goto IL_03f2;
																																			case 26:
																																			case 92:
																																				goto IL_0400;
																																			case 58:
																																				goto IL_0440;
																																			case 12:
																																				goto IL_0454;
																																			case 101:
																																				goto IL_0467;
																																			case 82:
																																			case 97:
																																				goto IL_0475;
																																			case 50:
																																				goto IL_0498;
																																			case 16:
																																				goto IL_04a6;
																																			case 102:
																																				goto IL_04b4;
																																			case 48:
																																			case 110:
																																				goto IL_04c7;
																																			case 33:
																																				goto IL_04f6;
																																			case 8:
																																			case 56:
																																				goto IL_0504;
																																			case 19:
																																			case 49:
																																				goto IL_050f;
																																			case 51:
																																				goto IL_051d;
																																			case 77:
																																			case 89:
																																				goto IL_052b;
																																			case 47:
																																				goto IL_0554;
																																			case 103:
																																				goto IL_0562;
																																			case 55:
																																				goto IL_0575;
																																			case 96:
																																			case 98:
																																				goto IL_0580;
																																			case 108:
																																				goto IL_0599;
																																			case 24:
																																				goto IL_05a7;
																																			case 60:
																																				goto IL_05b5;
																																			case 0:
																																			case 5:
																																			case 7:
																																			case 9:
																																			case 18:
																																			case 21:
																																			case 39:
																																			case 42:
																																			case 65:
																																			case 72:
																																			case 78:
																																			case 79:
																																			case 87:
																																			case 88:
																																			case 93:
																																			case 99:
																																			case 105:
																																			case 109:
																																			case 112:
																																			case 113:
																																				goto end_IL_0265;
																																			case 57:
																																			case 73:
																																				goto IL_05e0;
																																			case 10:
																																			case 32:
																																				goto IL_05fe;
																																			case 13:
																																				goto IL_063e;
																																			case 66:
																																				goto IL_0652;
																																			case 11:
																																			case 23:
																																			case 36:
																																			case 52:
																																			case 59:
																																			case 67:
																																			case 70:
																																			case 71:
																																			case 74:
																																			case 83:
																																			case 84:
																																			case 85:
																																			case 107:
																																			case 111:
																																				goto end_IL_02ef;
																																			case 14:
																																				goto end_IL_0660;
																																			case 30:
																																				goto end_IL_0673;
																																			case 40:
																																				goto end_IL_067d;
																																			case 4:
																																				goto end_IL_0688;
																																			case 80:
																																				goto end_IL_069d;
																																			case 64:
																																				goto end_IL_06ad;
																																			case 76:
																																				goto end_IL_06c6;
																																			case 22:
																																			case 86:
																																				goto end_IL_06d1;
																																			case 43:
																																				goto end_IL_06e1;
																																			case 44:
																																				goto end_IL_06f1;
																																			case 37:
																																			case 91:
																																				goto IL_0715;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_02ef;
																																		continue;
																																		end_IL_01ef:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0323;
																													continue;
																													end_IL_0265:
																													break;
																													IL_0265:;
																												}
																												break;
																												IL_0275:;
																											}
																											break;
																										}
																										goto IL_02fa;
																										IL_02fa:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_02ef;
																									}
																									break;
																								}
																								goto IL_04f6;
																								IL_05e0:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02ef;
																								IL_04f6:
																								if (3 > b)
																								{
																									goto IL_0504;
																								}
																								goto IL_05e0;
																								IL_0504:
																								if (1 < b)
																								{
																									goto IL_050f;
																								}
																								goto IL_0575;
																								IL_050f:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_051d;
																								IL_051d:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_052b;
																								IL_052b:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0554;
																								IL_0554:
																								ptr2 += 8;
																								goto IL_0562;
																								IL_0562:
																								num5--;
																								goto end_IL_02ef;
																								IL_0575:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0580;
																								IL_0580:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0599;
																								IL_0599:
																								array[num5] = 0;
																								goto IL_05a7;
																								IL_05a7:
																								num5++;
																								goto IL_05b5;
																								IL_05b5:
																								ptr2 += 8;
																								goto end_IL_02ef;
																							}
																							break;
																						}
																						num = 10;
																						goto IL_05fe;
																						IL_063e:
																						array[num5 - 2] = 0;
																						goto IL_0652;
																						IL_0652:
																						num5--;
																						goto end_IL_02ef;
																						IL_05fe:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_063e;
																					}
																					break;
																				}
																				goto IL_030d;
																				IL_0454:
																				num5--;
																				goto end_IL_02ef;
																				IL_030d:
																				if (9 < b)
																				{
																					goto IL_0318;
																				}
																				goto IL_0357;
																				IL_0318:
																				if (10 >= b)
																				{
																					goto IL_0323;
																				}
																				goto IL_0336;
																				IL_0323:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04c7;
																				IL_04c7:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ef;
																				IL_0336:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0344;
																				IL_0344:
																				if (11 > b)
																				{
																				}
																				break;
																				IL_0357:
																				if (9 <= b)
																				{
																					goto IL_0362;
																				}
																				goto IL_03d7;
																				IL_0362:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03c4;
																				IL_03c4:
																				num5 -= 2;
																				goto end_IL_02ef;
																				IL_03d7:
																				if (7 < b)
																				{
																					goto IL_03e2;
																				}
																				goto IL_03f2;
																				IL_03e2:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0467;
																				IL_0467:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0475;
																				IL_0475:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0498;
																				IL_0498:
																				array[num5] = 0;
																				goto IL_04a6;
																				IL_04a6:
																				num5++;
																				goto IL_04b4;
																				IL_04b4:
																				ptr2 += 8;
																				goto end_IL_02ef;
																				IL_03f2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0400;
																				IL_0400:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0440;
																				IL_0440:
																				array[num5 - 2] = 0;
																				goto IL_0454;
																			}
																			break;
																			IL_02bf:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02ef;
																	continue;
																	end_IL_02cf:
																	break;
																}
																continue;
																end_IL_02df:
																break;
															}
															continue;
															end_IL_02ef:
															break;
														}
														continue;
													}
													num = 37;
													goto IL_0715;
													IL_0715:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0660:
													break;
												}
												continue;
												end_IL_0673:
												break;
											}
											continue;
											end_IL_067d:
											break;
										}
										continue;
										end_IL_0688:
										break;
									}
									continue;
									end_IL_069d:
									break;
								}
								continue;
								end_IL_06ad:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06d1:
						break;
					}
					continue;
					end_IL_06e1:
					break;
				}
				continue;
				end_IL_06f1:
				break;
			}
		}
	}

	private unsafe void Start()
	{
		int num = 10;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref INVOCATIONFLAGSXmlNsForClrTypeWithNs.WantsToListenEndInvoke);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_036e:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_034e:
																				if (8 < b)
																				{
																					goto IL_067d;
																				}
																				while (true)
																				{
																					IL_0341:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0334:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_0324:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_0314:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_02ef:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												while (true)
																												{
																													IL_02e3:
																													array2[num5] = null;
																													while (true)
																													{
																														IL_02ca:
																														num5++;
																														num = 170;
																														while (true)
																														{
																															if (num != 170)
																															{
																																if (num != 1151)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 25:
																																	goto IL_02ca;
																																case 127:
																																	goto IL_02e3;
																																case 157:
																																	goto IL_02ef;
																																case 81:
																																case 161:
																																	goto IL_0314;
																																case 40:
																																	goto IL_0324;
																																case 115:
																																	goto IL_0334;
																																case 132:
																																	goto IL_0341;
																																case 19:
																																	goto IL_034e;
																																case 140:
																																	goto end_IL_034e;
																																case 22:
																																	goto IL_036e;
																																case 73:
																																	goto end_IL_036e;
																																case 89:
																																case 121:
																																	goto end_IL_037e;
																																case 24:
																																case 137:
																																	goto IL_0399;
																																case 44:
																																case 142:
																																	goto IL_03ac;
																																case 3:
																																	goto IL_03ba;
																																case 30:
																																case 94:
																																	goto IL_03c5;
																																case 17:
																																	goto IL_0405;
																																case 102:
																																	goto IL_0419;
																																case 95:
																																	goto IL_042c;
																																case 113:
																																	goto IL_043a;
																																case 59:
																																case 91:
																																	goto IL_0448;
																																case 65:
																																	goto IL_0488;
																																case 32:
																																case 42:
																																	goto IL_04b3;
																																case 34:
																																	goto IL_04c1;
																																case 71:
																																case 98:
																																	goto IL_04cf;
																																case 124:
																																	goto IL_050f;
																																case 0:
																																	goto IL_0523;
																																case 145:
																																	goto IL_0536;
																																case 57:
																																	goto IL_0565;
																																case 96:
																																case 138:
																																	goto IL_0570;
																																case 160:
																																	goto IL_057e;
																																case 1:
																																case 26:
																																	goto IL_0589;
																																case 136:
																																	goto IL_05b2;
																																case 129:
																																	goto IL_05c0;
																																case 2:
																																	goto IL_05e1;
																																case 77:
																																case 151:
																																	goto IL_05ec;
																																case 104:
																																	goto IL_062c;
																																case 68:
																																	goto IL_0640;
																																case 14:
																																	goto IL_0653;
																																case 163:
																																	goto IL_066a;
																																case 63:
																																	goto IL_067d;
																																case 15:
																																case 146:
																																	goto IL_068b;
																																case 123:
																																case 156:
																																	goto IL_0699;
																																case 76:
																																	goto IL_06a4;
																																case 117:
																																	goto IL_06b2;
																																case 58:
																																case 130:
																																	goto IL_06c0;
																																case 62:
																																	goto IL_06dc;
																																case 31:
																																case 133:
																																	goto IL_06ea;
																																case 99:
																																	goto IL_0717;
																																case 111:
																																	goto IL_072a;
																																case 54:
																																case 107:
																																	goto IL_0735;
																																case 45:
																																	goto IL_0743;
																																case 139:
																																	goto IL_0761;
																																case 49:
																																	goto IL_076f;
																																case 23:
																																	goto IL_0782;
																																case 120:
																																	goto IL_0799;
																																case 84:
																																case 141:
																																	goto end_IL_02b7;
																																case 46:
																																	goto IL_07bf;
																																case 125:
																																	goto IL_07cd;
																																case 83:
																																	goto IL_07db;
																																case 72:
																																	goto IL_07ee;
																																case 112:
																																case 162:
																																	goto IL_07fc;
																																case 53:
																																case 55:
																																	goto IL_080a;
																																case 69:
																																	goto IL_0818;
																																case 92:
																																case 126:
																																	goto IL_0826;
																																case 158:
																																	goto IL_083a;
																																case 114:
																																	goto IL_088e;
																																case 7:
																																	goto IL_089c;
																																case 159:
																																	goto IL_08af;
																																case 52:
																																case 106:
																																	goto IL_08bd;
																																case 86:
																																	goto IL_08cb;
																																case 37:
																																case 148:
																																	goto IL_08d9;
																																case 33:
																																	goto IL_0919;
																																case 75:
																																	goto IL_092d;
																																case 13:
																																case 144:
																																	goto IL_0940;
																																case 36:
																																	goto IL_09a2;
																																case 5:
																																case 6:
																																case 18:
																																case 20:
																																case 21:
																																case 41:
																																case 48:
																																case 60:
																																case 61:
																																case 64:
																																case 67:
																																case 78:
																																case 79:
																																case 80:
																																case 85:
																																case 87:
																																case 90:
																																case 93:
																																case 103:
																																case 105:
																																case 108:
																																case 109:
																																case 119:
																																case 122:
																																case 128:
																																case 131:
																																case 143:
																																case 149:
																																case 154:
																																	goto end_IL_035e;
																																case 97:
																																	goto IL_09cb;
																																case 74:
																																	goto IL_09d9;
																																case 4:
																																	goto IL_09e7;
																																case 8:
																																case 11:
																																case 12:
																																case 27:
																																case 29:
																																case 47:
																																case 50:
																																case 51:
																																case 56:
																																case 66:
																																case 82:
																																case 88:
																																case 101:
																																case 118:
																																case 134:
																																case 135:
																																case 147:
																																case 150:
																																case 152:
																																	goto end_IL_038e;
																																case 38:
																																	goto end_IL_09f5;
																																case 155:
																																	goto end_IL_0a08;
																																case 28:
																																	goto end_IL_0a12;
																																case 70:
																																	goto end_IL_0a1d;
																																case 35:
																																	goto end_IL_0a2d;
																																case 16:
																																case 39:
																																	goto end_IL_0a3d;
																																case 110:
																																	goto end_IL_0a4d;
																																case 43:
																																case 100:
																																	goto end_IL_0a5d;
																																case 9:
																																	goto end_IL_0a6d;
																																case 10:
																																	goto end_IL_0a7d;
																																case 116:
																																case 153:
																																	return;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															num = 147;
																															goto end_IL_038e;
																															continue;
																															end_IL_02b7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0565;
																									IL_0653:
																									if (1 < b)
																									{
																										goto end_IL_035e;
																									}
																									num = 163;
																									goto IL_066a;
																									IL_0565:
																									if (2 < b)
																									{
																										goto IL_0570;
																									}
																									goto IL_05e1;
																									IL_0570:
																									if (3 < b)
																									{
																										goto end_IL_035e;
																									}
																									goto IL_057e;
																									IL_057e:
																									if (3 > b)
																									{
																										num = 79;
																										goto end_IL_035e;
																									}
																									goto IL_0589;
																									IL_0589:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05b2;
																									IL_05b2:
																									ptr2 += 8;
																									goto IL_05c0;
																									IL_05c0:
																									num5--;
																									goto end_IL_038e;
																									IL_066a:
																									if (1 <= b)
																									{
																									}
																									goto end_IL_035e;
																									IL_05e1:
																									if (2 <= b)
																									{
																										goto IL_05ec;
																									}
																									goto IL_0653;
																									IL_05ec:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_062c;
																									IL_062c:
																									array[num5 - 2] = 0;
																									goto IL_0640;
																									IL_0640:
																									num5--;
																									goto end_IL_038e;
																								}
																								break;
																							}
																							goto IL_03ac;
																							IL_050f:
																							array[num5 - 2] = 0;
																							goto IL_0523;
																							IL_03ac:
																							if (6 >= b)
																							{
																								goto IL_03ba;
																							}
																							num = 32;
																							goto IL_04b3;
																							IL_03ba:
																							if (6 <= b)
																							{
																								goto IL_03c5;
																							}
																							goto IL_042c;
																							IL_03c5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0405;
																							IL_0405:
																							array[num5 - 2] = 0;
																							goto IL_0419;
																							IL_0419:
																							num5--;
																							goto end_IL_038e;
																							IL_042c:
																							if (5 < b)
																							{
																								goto end_IL_035e;
																							}
																							goto IL_043a;
																							IL_043a:
																							if (5 > b)
																							{
																								goto end_IL_035e;
																							}
																							goto IL_0448;
																							IL_0448:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0488;
																							IL_0488:
																							array[num5 - 2] = 0;
																							num = 145;
																							goto IL_0536;
																							IL_0536:
																							num5--;
																							goto end_IL_038e;
																							IL_0523:
																							num5--;
																							goto end_IL_038e;
																							IL_04b3:
																							if (7 < b)
																							{
																								goto end_IL_035e;
																							}
																							goto IL_04c1;
																							IL_04c1:
																							if (7 > b)
																							{
																								goto end_IL_035e;
																							}
																							goto IL_04cf;
																							IL_04cf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_050f;
																						}
																						break;
																					}
																					goto IL_0399;
																					IL_0399:
																					num5--;
																					goto end_IL_038e;
																				}
																				goto IL_07a7;
																				IL_0940:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_09a2;
																				IL_067d:
																				if (12 < b)
																				{
																					goto IL_068b;
																				}
																				goto IL_07ee;
																				IL_068b:
																				if (14 < b)
																				{
																					goto IL_0699;
																				}
																				goto IL_072a;
																				IL_0699:
																				if (15 < b)
																				{
																					goto IL_06a4;
																				}
																				goto IL_06dc;
																				IL_06a4:
																				if (16 < b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_06b2;
																				IL_06b2:
																				if (16 > b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_06c0;
																				IL_06c0:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_038e;
																				IL_06dc:
																				if (15 > b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_06ea;
																				IL_06ea:
																				((Class175)array2[num5 - 2]).rigidbody_0 = (Rigidbody)array2[num5 - 1];
																				goto IL_0717;
																				IL_0717:
																				num5 -= 2;
																				goto end_IL_038e;
																				IL_072a:
																				if (14 <= b)
																				{
																					goto IL_0735;
																				}
																				goto IL_0782;
																				IL_0735:
																				array[num5] = 5;
																				goto IL_0743;
																				IL_0743:
																				array2[num5] = ((delegate*<Rigidbody>)FormatUIntDefineProperty[*(int*)(ptr2 + num3)])();
																				goto IL_0761;
																				IL_0761:
																				num5++;
																				goto IL_076f;
																				IL_076f:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_0782:
																				if (13 < b)
																				{
																					goto end_IL_035e;
																				}
																				num = 120;
																				goto IL_0799;
																				IL_09a2:
																				num5 -= 2;
																				goto end_IL_038e;
																				IL_0799:
																				if (13 > b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_07a7;
																				IL_07a7:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_07bf;
																				IL_07bf:
																				array[num5] = 5;
																				goto IL_07cd;
																				IL_07cd:
																				num5++;
																				goto IL_07db;
																				IL_07db:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_07ee:
																				if (12 <= b)
																				{
																					goto end_IL_038e;
																				}
																				goto IL_07fc;
																				IL_07fc:
																				if (10 < b)
																				{
																					goto IL_080a;
																				}
																				goto IL_08af;
																				IL_080a:
																				if (11 < b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_0818;
																				IL_0818:
																				if (11 > b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_0826;
																				IL_0826:
																				array[num5 - 2] = 0;
																				goto IL_083a;
																				IL_083a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)FormatUIntDefineProperty[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_088e;
																				IL_088e:
																				num5--;
																				goto IL_089c;
																				IL_089c:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_08af:
																				if (10 > b)
																				{
																					goto IL_08bd;
																				}
																				goto IL_0940;
																				IL_08bd:
																				if (9 < b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_08cb;
																				IL_08cb:
																				if (9 > b)
																				{
																					goto end_IL_035e;
																				}
																				goto IL_08d9;
																				IL_08d9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0919;
																				IL_0919:
																				array[num5 - 2] = 0;
																				goto IL_092d;
																				IL_092d:
																				num5--;
																				goto end_IL_038e;
																				continue;
																				end_IL_034e:
																				break;
																			}
																			continue;
																			end_IL_035e:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_09cb;
																	IL_09e7:
																	ptr2 += 8;
																	goto end_IL_038e;
																	IL_09d9:
																	num5++;
																	goto IL_09e7;
																	IL_09cb:
																	array[num5] = 0;
																	goto IL_09d9;
																	continue;
																	end_IL_036e:
																	break;
																}
																continue;
																end_IL_037e:
																break;
															}
															continue;
															end_IL_038e:
															break;
														}
														continue;
													}
													num = 153;
													return;
													continue;
													end_IL_09f5:
													break;
												}
												continue;
												end_IL_0a08:
												break;
											}
											continue;
											end_IL_0a12:
											break;
										}
										continue;
										end_IL_0a1d:
										break;
									}
									continue;
									end_IL_0a2d:
									break;
								}
								continue;
								end_IL_0a3d:
								break;
							}
							continue;
							end_IL_0a4d:
							break;
						}
						continue;
						end_IL_0a5d:
						break;
					}
					continue;
					end_IL_0a6d:
					break;
				}
				continue;
				end_IL_0a7d:
				break;
			}
		}
	}

	private static int RevisionWaitTimeout(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool SubKeyCountPrefixCode(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerSecondaryButton;
	}

	private static void StateMachineAttributeIClrStrongNameUsingIntPtr(Rigidbody rigidbody_1, Vector3 vector3_0)
	{
		rigidbody_1.velocity = vector3_0;
	}

	private static ControllerInputPoller EnumerablePartitionerOptionsCheckSecuritySettings()
	{
		return ControllerInputPoller.instance;
	}

	private static double getInnerExceptionsgetKeysOrderedInEachPartition(double double_1)
	{
		return Math.Log(double_1);
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDayOfWeekGetITypeInfoForType.getBuildNumberGetReturnValue);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02aa:
														byte b = *ptr2;
														while (true)
														{
															IL_029a:
															ptr2++;
															while (true)
															{
																IL_028a:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_026d:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_025d:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_024d:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0240:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01fb:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_01eb:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_01d2:
																															num5++;
																															num = 108;
																															while (true)
																															{
																																if (num != 108)
																																{
																																	if (num != 1089)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 65:
																																		goto IL_01d2;
																																	case 22:
																																		goto IL_01eb;
																																	case 21:
																																	case 39:
																																		goto IL_01fb;
																																	case 58:
																																		goto IL_0220;
																																	case 46:
																																		goto IL_0230;
																																	case 36:
																																	case 74:
																																		goto IL_0240;
																																	case 93:
																																		goto IL_024d;
																																	case 15:
																																	case 68:
																																		goto IL_025d;
																																	case 45:
																																		goto IL_026d;
																																	case 83:
																																		goto IL_027a;
																																	case 80:
																																		goto IL_028a;
																																	case 70:
																																		goto IL_029a;
																																	case 4:
																																	case 95:
																																		goto IL_02aa;
																																	case 2:
																																		goto IL_02b5;
																																	case 31:
																																		goto IL_02c5;
																																	case 29:
																																	case 57:
																																		goto IL_02d8;
																																	case 24:
																																		goto IL_02e6;
																																	case 18:
																																		goto IL_02f1;
																																	case 78:
																																		goto IL_02ff;
																																	case 9:
																																	case 37:
																																		goto IL_030d;
																																	case 16:
																																	case 91:
																																		goto IL_0328;
																																	case 14:
																																		goto IL_0351;
																																	case 90:
																																		goto IL_035f;
																																	case 92:
																																		goto IL_0372;
																																	case 59:
																																		goto IL_0380;
																																	case 53:
																																	case 96:
																																		goto IL_0390;
																																	case 87:
																																		goto IL_03a7;
																																	case 55:
																																		goto IL_03ca;
																																	case 79:
																																		goto IL_03d4;
																																	case 64:
																																		goto IL_03eb;
																																	case 97:
																																		goto IL_03fe;
																																	case 3:
																																	case 98:
																																		goto IL_0411;
																																	case 47:
																																	case 76:
																																		goto IL_041c;
																																	case 73:
																																		goto IL_042c;
																																	case 44:
																																	case 81:
																																		goto IL_043a;
																																	case 99:
																																		goto IL_0452;
																																	case 82:
																																	case 100:
																																		goto IL_0465;
																																	case 0:
																																		goto IL_04a5;
																																	case 49:
																																		goto IL_04b9;
																																	case 50:
																																	case 94:
																																		goto IL_04df;
																																	case 26:
																																		goto IL_0541;
																																	case 13:
																																		goto IL_0551;
																																	case 61:
																																		goto IL_055c;
																																	case 32:
																																	case 60:
																																		goto IL_0567;
																																	case 56:
																																		goto IL_0580;
																																	case 66:
																																		goto IL_058b;
																																	case 1:
																																	case 5:
																																	case 8:
																																	case 17:
																																	case 20:
																																	case 25:
																																	case 33:
																																	case 34:
																																	case 35:
																																	case 38:
																																	case 54:
																																	case 67:
																																	case 84:
																																	case 85:
																																	case 88:
																																	case 89:
																																		goto end_IL_0220;
																																	case 10:
																																	case 12:
																																	case 19:
																																	case 27:
																																	case 28:
																																	case 40:
																																	case 41:
																																	case 51:
																																	case 71:
																																	case 72:
																																	case 77:
																																	case 86:
																																	case 101:
																																		goto end_IL_01bf;
																																	case 69:
																																		goto end_IL_05a9;
																																	case 30:
																																		goto end_IL_05bc;
																																	case 48:
																																		goto end_IL_05c6;
																																	case 42:
																																		goto end_IL_05d1;
																																	case 23:
																																	case 63:
																																		goto end_IL_05e6;
																																	case 52:
																																		goto end_IL_05f6;
																																	case 62:
																																	case 75:
																																		goto end_IL_0606;
																																	case 6:
																																		goto end_IL_0616;
																																	case 7:
																																		goto end_IL_0626;
																																	case 11:
																																	case 43:
																																		goto IL_0641;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																break;
																																continue;
																																end_IL_01bf:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_028a;
																												continue;
																												end_IL_0220:
																												break;
																												IL_0220:;
																											}
																											break;
																											IL_0230:;
																										}
																										break;
																									}
																									goto IL_02c5;
																									IL_04b9:
																									num5--;
																									goto end_IL_028a;
																									IL_02c5:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0465;
																									IL_0465:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04a5;
																									IL_04a5:
																									array[num5 - 2] = 0;
																									goto IL_04b9;
																								}
																								break;
																							}
																							goto IL_04df;
																							IL_0541:
																							num5 -= 2;
																							goto end_IL_028a;
																							IL_04df:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0541;
																						}
																						break;
																					}
																					goto IL_0551;
																					IL_058b:
																					if (10 <= b)
																					{
																					}
																					break;
																					IL_0551:
																					if (9 >= b)
																					{
																						goto IL_055c;
																					}
																					goto IL_0580;
																					IL_055c:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0567;
																					IL_0567:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_028a;
																					IL_0580:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_058b;
																				}
																				break;
																			}
																			goto IL_02b5;
																			IL_03eb:
																			ptr2 += 8;
																			goto end_IL_028a;
																			IL_02b5:
																			if (5 > b)
																			{
																				goto IL_02d8;
																			}
																			goto IL_0390;
																			IL_02d8:
																			if (2 >= b)
																			{
																				goto IL_02e6;
																			}
																			goto IL_0411;
																			IL_02e6:
																			if (2 > b)
																			{
																				goto IL_02f1;
																			}
																			goto IL_0328;
																			IL_02f1:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_02ff;
																			IL_02ff:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_030d;
																			IL_030d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0372;
																			IL_0372:
																			array[num5] = 0;
																			goto IL_0380;
																			IL_0380:
																			num5++;
																			goto IL_03fe;
																			IL_03fe:
																			ptr2 += 8;
																			goto end_IL_028a;
																			IL_0328:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0351;
																			IL_0351:
																			ptr2 += 8;
																			goto IL_035f;
																			IL_035f:
																			num5--;
																			goto end_IL_028a;
																			IL_0411:
																			if (3 < b)
																			{
																				goto IL_041c;
																			}
																			goto IL_042c;
																			IL_041c:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0452;
																			IL_0452:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_028a;
																			IL_042c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_043a;
																			IL_043a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_028a;
																			IL_0390:
																			array[num5] = 0;
																			num = 87;
																			goto IL_03a7;
																			IL_03a7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03ca;
																			IL_03ca:
																			array2[num5] = null;
																			goto IL_03d4;
																			IL_03d4:
																			num5++;
																			num = 64;
																			goto IL_03eb;
																		}
																		break;
																		IL_027a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_028a:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0641;
												IL_0641:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05a9:
												break;
											}
											continue;
											end_IL_05bc:
											break;
										}
										continue;
										end_IL_05c6:
										break;
									}
									continue;
									end_IL_05d1:
									break;
								}
								continue;
								end_IL_05e6:
								break;
							}
							continue;
							end_IL_05f6:
							break;
						}
						continue;
						end_IL_0606:
						break;
					}
					continue;
					end_IL_0616:
					break;
				}
				continue;
				end_IL_0626:
				break;
			}
		}
	}

	private static double DomainMaskUnknownToken(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static Vector3 ParagraphSeparatorFileWritableType()
	{
		return global::_003CModule_003E.o_007D_003E_003CBWkDko;
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 34;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllowTrailingSignEndBuffered.AbsentOriginSchemePtrToStringUni);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 24;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0259:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_023c:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_022f:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_021f:
																								if (10 < b)
																								{
																									while (true)
																									{
																										IL_020c:
																										if (11 < b)
																										{
																											num = 119;
																											while (num != 119)
																											{
																												if (num != 1100)
																												{
																													goto IL_0592;
																												}
																												switch (num)
																												{
																												case 45:
																													goto IL_020c;
																												case 99:
																													goto IL_021f;
																												case 10:
																												case 13:
																													goto IL_022f;
																												case 41:
																													goto IL_023c;
																												case 38:
																													goto IL_0249;
																												case 66:
																													goto IL_0259;
																												case 11:
																													goto end_IL_0259;
																												case 5:
																												case 109:
																													goto end_IL_0269;
																												case 4:
																													goto IL_028f;
																												case 12:
																												case 20:
																													goto IL_029d;
																												case 25:
																													goto IL_02dd;
																												case 42:
																													goto IL_02f6;
																												case 63:
																													goto IL_0306;
																												case 64:
																													goto IL_0319;
																												case 0:
																													goto IL_0327;
																												case 1:
																												case 47:
																													goto IL_0335;
																												case 69:
																													goto IL_037a;
																												case 82:
																													goto IL_038d;
																												case 9:
																												case 58:
																													goto IL_039b;
																												case 7:
																												case 56:
																													goto IL_03a9;
																												case 83:
																													goto IL_03b7;
																												case 75:
																												case 77:
																													goto IL_03c5;
																												case 71:
																													goto IL_03d3;
																												case 52:
																													goto IL_03f6;
																												case 88:
																													goto IL_0402;
																												case 51:
																													goto IL_0410;
																												case 18:
																												case 62:
																													goto IL_041e;
																												case 86:
																													goto IL_0441;
																												case 93:
																													goto IL_0454;
																												case 94:
																													goto IL_0467;
																												case 49:
																													goto IL_0475;
																												case 84:
																												case 96:
																													goto IL_0488;
																												case 26:
																													goto IL_04ea;
																												case 98:
																													goto IL_04fd;
																												case 85:
																													goto IL_0511;
																												case 101:
																													goto IL_0524;
																												case 46:
																													goto IL_052f;
																												case 29:
																													goto IL_053a;
																												case 65:
																													goto IL_0548;
																												case 44:
																												case 90:
																													goto IL_0556;
																												case 61:
																													goto IL_057f;
																												case 3:
																													goto IL_0592;
																												case 19:
																												case 40:
																													goto IL_05a2;
																												case 102:
																													goto IL_05ba;
																												case 74:
																													goto IL_05c8;
																												case 2:
																												case 106:
																													goto IL_05db;
																												case 28:
																													goto IL_05f4;
																												case 23:
																													goto IL_0602;
																												case 87:
																													goto IL_0610;
																												case 107:
																													goto IL_0620;
																												case 39:
																													goto IL_0630;
																												case 91:
																												case 100:
																													goto IL_063b;
																												case 6:
																												case 8:
																												case 14:
																												case 16:
																												case 17:
																												case 30:
																												case 32:
																												case 43:
																												case 48:
																												case 53:
																												case 54:
																												case 55:
																												case 57:
																												case 59:
																												case 72:
																												case 73:
																												case 78:
																												case 81:
																												case 89:
																												case 92:
																												case 111:
																													goto end_IL_01f9;
																												case 21:
																												case 22:
																												case 24:
																												case 31:
																												case 60:
																												case 67:
																												case 68:
																												case 76:
																												case 80:
																												case 95:
																												case 104:
																												case 105:
																												case 108:
																													goto end_IL_0279;
																												case 103:
																													goto end_IL_0667;
																												case 37:
																													goto end_IL_067a;
																												case 50:
																													goto end_IL_0685;
																												case 35:
																													goto end_IL_068f;
																												case 110:
																													goto end_IL_069a;
																												case 70:
																												case 97:
																													goto end_IL_06af;
																												case 15:
																													goto end_IL_06bf;
																												case 27:
																												case 112:
																													goto end_IL_06cf;
																												case 33:
																													goto end_IL_06df;
																												case 34:
																													goto end_IL_06ef;
																												case 36:
																												case 79:
																													goto IL_0713;
																												}
																												continue;
																												end_IL_01f9:
																												break;
																											}
																											break;
																										}
																										goto IL_0306;
																										IL_0306:
																										if (11 <= b)
																										{
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0630;
																								IL_063b:
																								byte* num5 = ptr2;
																								num4 = 1;
																								ptr2 = num5 + -200;
																								goto end_IL_0279;
																								IL_0630:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_063b;
																							}
																							break;
																						}
																						num = 42;
																						goto IL_02f6;
																						IL_05ba:
																						num6++;
																						goto IL_05c8;
																						IL_05c8:
																						ptr2 += 8;
																						goto end_IL_0279;
																						IL_02f6:
																						if (9 > b)
																						{
																							goto IL_0319;
																						}
																						goto IL_0488;
																						IL_0488:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_04ea;
																						IL_04ea:
																						num6 -= 2;
																						goto end_IL_0279;
																						IL_0319:
																						if (7 >= b)
																						{
																							goto IL_0327;
																						}
																						goto IL_0402;
																						IL_0327:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0335;
																						IL_0335:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_04fd;
																						IL_04fd:
																						array[num6 - 2] = 0;
																						goto IL_0511;
																						IL_0511:
																						num6--;
																						goto end_IL_0279;
																						IL_0402:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0410;
																						IL_0410:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_041e;
																						IL_041e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0441;
																						IL_0441:
																						array[num6] = 0;
																						goto IL_05ba;
																					}
																					break;
																				}
																				goto IL_028f;
																				IL_05a2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0279;
																				IL_028f:
																				if (6 <= b)
																				{
																					goto IL_029d;
																				}
																				goto IL_038d;
																				IL_029d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_02dd;
																				IL_02dd:
																				array[num6 - 2] = 0;
																				goto IL_037a;
																				IL_037a:
																				num6--;
																				goto end_IL_0279;
																				IL_038d:
																				if (3 < b)
																				{
																					goto IL_039b;
																				}
																				goto IL_0524;
																				IL_039b:
																				if (4 < b)
																				{
																					goto IL_03a9;
																				}
																				goto IL_0454;
																				IL_03a9:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_03b7;
																				IL_03b7:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03c5;
																				IL_03c5:
																				array[num6] = 0;
																				goto IL_03d3;
																				IL_03d3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03f6;
																				IL_03f6:
																				array2[num6] = null;
																				goto IL_0467;
																				IL_0467:
																				num6++;
																				goto IL_0475;
																				IL_0475:
																				ptr2 += 8;
																				goto end_IL_0279;
																				IL_0454:
																				if (4 <= b)
																				{
																					goto end_IL_0279;
																				}
																				break;
																				IL_0524:
																				if (3 > b)
																				{
																					goto IL_052f;
																				}
																				goto IL_05a2;
																				IL_052f:
																				if (1 < b)
																				{
																					goto IL_053a;
																				}
																				goto IL_0592;
																				IL_053a:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0548;
																				IL_0548:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0556;
																				IL_0556:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_057f;
																				IL_057f:
																				ptr2 += 8;
																				goto IL_0620;
																				IL_0620:
																				num6--;
																				goto end_IL_0279;
																				IL_0592:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_05db;
																				IL_05db:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_05f4;
																				IL_05f4:
																				array[num6] = 0;
																				goto IL_0602;
																				IL_0602:
																				num6++;
																				goto IL_0610;
																				IL_0610:
																				ptr2 += 8;
																				goto end_IL_0279;
																			}
																			break;
																			IL_0249:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0279;
																	continue;
																	end_IL_0259:
																	break;
																}
																continue;
																end_IL_0269:
																break;
															}
															continue;
															end_IL_0279:
															break;
														}
														continue;
													}
													num = 79;
													goto IL_0713;
													IL_0713:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0667:
													break;
												}
												continue;
												end_IL_067a:
												break;
											}
											continue;
											end_IL_0685:
											break;
										}
										continue;
										end_IL_068f:
										break;
									}
									continue;
									end_IL_069a:
									break;
								}
								continue;
								end_IL_06af:
								break;
							}
							continue;
							end_IL_06bf:
							break;
						}
						continue;
						end_IL_06cf:
						break;
					}
					continue;
					end_IL_06df:
					break;
				}
				continue;
				end_IL_06ef:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 95;
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		object[] array5 = default(object[]);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 160;
						while (true)
						{
							if (num != 160)
							{
								if (num != 1141)
								{
									goto IL_0337;
								}
								switch (num)
								{
								case 115:
									goto end_IL_028f;
								case 1:
								case 140:
									goto end_IL_029f;
								case 94:
									goto end_IL_02b8;
								case 95:
									goto end_IL_02c8;
								case 62:
									goto IL_02ec;
								case 42:
									goto IL_02fa;
								case 22:
									goto IL_0308;
								case 107:
									goto IL_0316;
								case 67:
									goto IL_031f;
								case 10:
								case 15:
								case 23:
								case 29:
								case 37:
								case 38:
								case 40:
								case 60:
								case 96:
								case 99:
								case 104:
								case 113:
								case 114:
								case 122:
								case 123:
								case 127:
								case 129:
								case 142:
									goto IL_0327;
								case 63:
									goto IL_0337;
								case 2:
									goto IL_0340;
								case 145:
									goto IL_0352;
								case 70:
									goto IL_0360;
								case 100:
									goto IL_036e;
								case 4:
									goto IL_037c;
								case 24:
								case 143:
									goto IL_038a;
								case 87:
								case 98:
									goto IL_0398;
								case 53:
									goto IL_03a6;
								case 18:
								case 66:
									goto IL_03b1;
								case 125:
									goto IL_03d6;
								case 65:
									goto IL_03e4;
								case 9:
								case 112:
									goto IL_03f2;
								case 48:
									goto IL_0454;
								case 32:
								case 128:
									goto IL_0467;
								case 0:
									goto IL_0475;
								case 69:
									goto IL_0488;
								case 88:
								case 97:
									goto IL_0493;
								case 138:
									goto IL_04d3;
								case 6:
									goto IL_04e7;
								case 91:
								case 149:
									goto IL_04fa;
								case 25:
								case 54:
									goto IL_0508;
								case 119:
									goto IL_0516;
								case 44:
								case 45:
									goto IL_0524;
								case 101:
									goto IL_0568;
								case 68:
									goto IL_057c;
								case 110:
									goto IL_058f;
								case 14:
								case 93:
									goto IL_059a;
								case 12:
									goto IL_05a8;
								case 75:
								case 78:
									goto IL_05bb;
								case 132:
									goto IL_05c9;
								case 17:
									goto IL_05ec;
								case 135:
									goto IL_05f6;
								case 28:
									goto IL_0604;
								case 47:
									goto IL_0617;
								case 58:
								case 136:
									goto IL_0622;
								case 124:
									goto IL_063a;
								case 33:
								case 46:
									goto IL_0648;
								case 116:
									goto IL_0656;
								case 64:
									goto IL_0661;
								case 31:
									goto IL_066f;
								case 36:
								case 120:
									goto IL_067d;
								case 86:
									goto IL_068b;
								case 84:
									goto IL_06a3;
								case 43:
									goto IL_06b1;
								case 27:
								case 83:
									goto IL_06c4;
								case 92:
									goto IL_0703;
								case 13:
								case 153:
									goto IL_071f;
								case 152:
									goto IL_072d;
								case 35:
								case 55:
									goto IL_073b;
								case 21:
									goto IL_0764;
								case 34:
									goto IL_0772;
								case 148:
									goto IL_0785;
								case 73:
								case 133:
									goto IL_0793;
								case 106:
									goto IL_07a1;
								case 105:
								case 111:
									goto IL_07ac;
								case 109:
									goto IL_07ba;
								case 39:
								case 49:
									goto IL_07c8;
								case 52:
									goto IL_07ea;
								case 56:
									goto IL_07f8;
								case 81:
									goto IL_0806;
								case 26:
								case 79:
									goto IL_0819;
								case 7:
									goto IL_0859;
								case 51:
									goto IL_0876;
								case 74:
									goto IL_0889;
								case 3:
									goto IL_0897;
								case 71:
								case 72:
									goto IL_08a5;
								case 126:
									goto IL_08ce;
								case 61:
								case 147:
									goto IL_08e7;
								case 146:
									goto IL_0905;
								case 80:
									goto IL_0913;
								case 5:
								case 8:
								case 11:
								case 16:
								case 19:
								case 20:
								case 30:
								case 41:
								case 50:
								case 57:
								case 59:
								case 76:
								case 77:
								case 82:
								case 85:
								case 89:
								case 90:
								case 103:
								case 108:
								case 117:
								case 118:
								case 121:
								case 131:
								case 134:
								case 137:
								case 139:
								case 141:
								case 144:
								case 150:
								case 151:
									goto IL_0926;
								case 102:
								case 130:
									goto IL_093e;
								}
								continue;
							}
							num = 62;
							goto IL_02ec;
							IL_0905:
							ptr += 8;
							goto IL_0913;
							IL_0926:
							ptr = ptr2 + *(int*)(ptr + num3);
							goto IL_0327;
							IL_0913:
							num4--;
							goto IL_0327;
							IL_02ec:
							array3 = new int[2];
							goto IL_02fa;
							IL_02fa:
							array4 = new long[4];
							goto IL_0308;
							IL_0308:
							array5 = new object[1];
							goto IL_0316;
							IL_0316:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TimeZoneTokenc.SecurityAssertHasFlushedFinalBlock);
							goto IL_031f;
							IL_031f:
							ptr = ptr2;
							goto IL_0327;
							IL_0327:
							if (num5 != 1)
							{
								goto IL_0337;
							}
							goto IL_093e;
							IL_093e:
							return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							IL_0337:
							num = 2;
							goto IL_0340;
							IL_0340:
							b = *ptr;
							num = 145;
							goto IL_0352;
							IL_0352:
							ptr++;
							goto IL_0360;
							IL_0360:
							if (b >= 1)
							{
								goto IL_036e;
							}
							goto IL_0926;
							IL_036e:
							if (b <= 15)
							{
								goto IL_037c;
							}
							goto IL_0926;
							IL_037c:
							if (8 < b)
							{
								goto IL_038a;
							}
							goto IL_0617;
							IL_038a:
							if (12 < b)
							{
								goto IL_0398;
							}
							goto IL_0488;
							IL_0398:
							if (14 >= b)
							{
								goto IL_03a6;
							}
							goto IL_0467;
							IL_03a6:
							if (14 <= b)
							{
								goto IL_03b1;
							}
							goto IL_03d6;
							IL_03b1:
							byte* num6 = ptr;
							num5 = 1;
							ptr = num6 + -200;
							num = 142;
							goto IL_0327;
							IL_03d6:
							if (13 >= b)
							{
								goto IL_03e4;
							}
							goto IL_0926;
							IL_03e4:
							if (13 <= b)
							{
								goto IL_03f2;
							}
							goto IL_0926;
							IL_03f2:
							ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
							goto IL_0454;
							IL_0454:
							num4 -= 2;
							goto IL_0327;
							IL_0467:
							if (15 >= b)
							{
								goto IL_0475;
							}
							goto IL_0926;
							IL_0475:
							if (15 <= b)
							{
							}
							goto IL_0926;
							IL_0488:
							if (12 <= b)
							{
								goto IL_0493;
							}
							goto IL_04fa;
							IL_0493:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_04d3;
							IL_04d3:
							array[num4 - 2] = 0;
							goto IL_04e7;
							IL_04e7:
							num4--;
							goto IL_0327;
							IL_04fa:
							if (10 < b)
							{
								goto IL_0508;
							}
							goto IL_058f;
							IL_0508:
							if (11 >= b)
							{
								goto IL_0516;
							}
							goto IL_0926;
							IL_0516:
							if (11 <= b)
							{
								goto IL_0524;
							}
							goto IL_0926;
							IL_0524:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
							goto IL_0568;
							IL_0568:
							array[num4 - 2] = 0;
							goto IL_057c;
							IL_057c:
							num4--;
							goto IL_0327;
							IL_058f:
							if (10 > b)
							{
								goto IL_059a;
							}
							goto IL_05bb;
							IL_059a:
							if (9 >= b)
							{
								goto IL_05a8;
							}
							goto IL_0926;
							IL_05a8:
							if (9 <= b)
							{
								goto IL_0327;
							}
							goto IL_0926;
							IL_05bb:
							array[num4] = 0;
							goto IL_05c9;
							IL_05c9:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
							goto IL_05ec;
							IL_05ec:
							array2[num4] = null;
							goto IL_05f6;
							IL_05f6:
							num4++;
							goto IL_0604;
							IL_0604:
							ptr += 8;
							goto IL_0327;
							IL_0617:
							if (8 <= b)
							{
								goto IL_0622;
							}
							goto IL_063a;
							IL_0622:
							ptr = ptr2 + *(int*)(ptr + num3);
							goto IL_0327;
							IL_063a:
							if (4 < b)
							{
								goto IL_0648;
							}
							goto IL_0785;
							IL_0648:
							if (6 >= b)
							{
								goto IL_0656;
							}
							goto IL_071f;
							IL_0656:
							if (6 > b)
							{
								goto IL_0661;
							}
							goto IL_06c4;
							IL_0661:
							if (5 >= b)
							{
								goto IL_066f;
							}
							goto IL_0926;
							IL_066f:
							if (5 <= b)
							{
								goto IL_067d;
							}
							goto IL_0926;
							IL_067d:
							array[num4] = 5;
							goto IL_068b;
							IL_068b:
							array2[num4] = array5[*(int*)(ptr + num3)];
							goto IL_06a3;
							IL_06a3:
							num4++;
							goto IL_06b1;
							IL_06b1:
							ptr += 8;
							goto IL_0327;
							IL_06c4:
							((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0703;
							IL_0703:
							num4 -= 3;
							num = 37;
							goto IL_0327;
							IL_071f:
							if (7 >= b)
							{
								goto IL_072d;
							}
							goto IL_0926;
							IL_072d:
							if (7 <= b)
							{
								goto IL_073b;
							}
							goto IL_0926;
							IL_073b:
							ref int reference = ref array3[*(int*)(ptr + num3)];
							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0764;
							IL_0764:
							ptr += 8;
							goto IL_0772;
							IL_0772:
							num4--;
							goto IL_0327;
							IL_0785:
							if (4 > b)
							{
								goto IL_0793;
							}
							goto IL_08e7;
							IL_0793:
							if (2 >= b)
							{
								goto IL_07a1;
							}
							goto IL_0889;
							IL_07a1:
							if (2 > b)
							{
								goto IL_07ac;
							}
							goto IL_0819;
							IL_07ac:
							if (1 >= b)
							{
								goto IL_07ba;
							}
							goto IL_0926;
							IL_07ba:
							if (1 <= b)
							{
								goto IL_07c8;
							}
							goto IL_0926;
							IL_07c8:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
							num = 52;
							goto IL_07ea;
							IL_07ea:
							array[num4] = 0;
							goto IL_07f8;
							IL_07f8:
							num4++;
							goto IL_0806;
							IL_0806:
							ptr += 8;
							goto IL_0327;
							IL_0819:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0859;
							IL_0859:
							array[num4 - 2] = 0;
							num = 51;
							goto IL_0876;
							IL_0876:
							num4--;
							goto IL_0327;
							IL_0889:
							if (3 >= b)
							{
								goto IL_0897;
							}
							goto IL_0926;
							IL_0897:
							if (3 <= b)
							{
								goto IL_08a5;
							}
							goto IL_0926;
							IL_08a5:
							array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
							goto IL_08ce;
							IL_08ce:
							array[num4 - 1] = 5;
							goto IL_0327;
							IL_08e7:
							array5[*(int*)(ptr + num3)] = array2[num4 - 1];
							goto IL_0905;
							continue;
							end_IL_028f:
							break;
						}
						continue;
						end_IL_029f:
						break;
					}
					continue;
					end_IL_02b8:
					break;
				}
				continue;
				end_IL_02c8:
				break;
			}
		}
	}

	private static float CachePathValueTraceSynchronousWork()
	{
		return Time.time;
	}

	static Class175()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0069:
				Class300.smethod_0();
				while (true)
				{
					IL_005d:
					num = 3;
					while (true)
					{
						IL_004e:
						num = 14;
						while (true)
						{
							if (num != 14)
							{
								if (num != 995)
								{
									break;
								}
								switch (num)
								{
								case 3:
								case 4:
									goto IL_004e;
								case 5:
									goto IL_005d;
								case 1:
									goto IL_0069;
								case 2:
									goto end_IL_0041;
								case 0:
								case 6:
									goto IL_0079;
								case 7:
									return;
								}
								continue;
							}
							goto IL_0079;
							IL_0079:
							num = 7;
							return;
							continue;
							end_IL_0041:
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static float SorterObjectArrayObjectDisposedException()
	{
		return Time.time;
	}

	private static Vector3 TickCountInvocationList(Vector3 vector3_0, float float_1)
	{
		return vector3_0 * float_1;
	}

	private static double AssemblyReferenceDependentAssemblyHashValueIsConstructor(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static float HostContextUseSpacesInDayNames(Class175 class175_1)
	{
		return class175_1.float_0;
	}

	private static Rigidbody TypeAttributessetXmlTypeName(Class175 class175_1)
	{
		return class175_1.rigidbody_0;
	}

	private static Vector3 InnerExceptionAddField()
	{
		return Class9.smethod_68();
	}

	private static double BuiltinPowerUsersSidProcess(double double_1)
	{
		return Math.Abs(double_1);
	}
}
