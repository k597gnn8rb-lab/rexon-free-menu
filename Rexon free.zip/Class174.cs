using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Cannon Launch [ALL BUTTONS + GRIPS]", "Rig", "Massive launch in the direction you look.", false, 21, ModType.const_0, false)]
internal class Class174 : MonoBehaviour
{
	private float float_0;

	private Rigidbody rigidbody_0;

	private static bool bool_0;

	private static bool bool_1;

	private static float float_1;

	private static bool bool_2;

	private static double double_0;

	private static bool bool_3;

	private static IntPtr[] InheritanceDemandGetVarCustData;

	private static IntPtr[] getEventSectionCustomStoreList;

	private static IntPtr[] INVOCATIONFLAGSISDELEGATECTORInternalCall;

	private static Transform RequireParenthesisParentField(Component component_0)
	{
		return component_0.transform;
	}

	private static float CMSENTRYPOINTFLAGUnmanagedMemoryStream()
	{
		return Time.time;
	}

	private static void getKeysNormalizedgetIsRetval(Rigidbody rigidbody_1, Vector3 vector3_0)
	{
		rigidbody_1.velocity = vector3_0;
	}

	private unsafe void Start()
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct92.getPkcsMakePointerType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0388:
																if (b >= 1)
																{
																	while (b <= 16)
																	{
																		while (true)
																		{
																			if (8 >= b)
																			{
																				while (true)
																				{
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0348:
																							if (4 >= b)
																							{
																								goto IL_04d5;
																							}
																							while (true)
																							{
																								IL_033b:
																								if (6 >= b)
																								{
																									while (true)
																									{
																										IL_032b:
																										if (6 <= b)
																										{
																											while (true)
																											{
																												IL_02e9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_02ca:
																													array[num5 - 2] = 0;
																													num = 170;
																													while (true)
																													{
																														if (num != 170)
																														{
																															if (num != 1151)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 126:
																																goto IL_02ca;
																															case 78:
																															case 125:
																																goto IL_02e9;
																															case 163:
																																goto IL_032b;
																															case 74:
																															case 150:
																																goto IL_033b;
																															case 45:
																															case 133:
																																goto IL_0348;
																															case 35:
																																goto end_IL_0348;
																															case 121:
																																goto end_IL_0358;
																															case 11:
																																goto end_IL_0368;
																															case 68:
																																goto IL_0388;
																															case 75:
																																goto end_IL_0388;
																															case 76:
																															case 85:
																																goto end_IL_0398;
																															case 64:
																															case 100:
																																goto IL_03b3;
																															case 91:
																																goto IL_03ca;
																															case 98:
																															case 148:
																																goto IL_03d8;
																															case 54:
																																goto IL_0418;
																															case 21:
																																goto IL_042c;
																															case 152:
																																goto IL_0452;
																															case 110:
																																goto IL_0460;
																															case 143:
																															case 144:
																																goto IL_046e;
																															case 15:
																																goto IL_04ae;
																															case 77:
																																goto IL_04c2;
																															case 102:
																																goto IL_04d5;
																															case 132:
																																goto IL_04e3;
																															case 89:
																																goto IL_04f1;
																															case 142:
																															case 161:
																																goto end_IL_02b7;
																															case 140:
																																goto IL_050a;
																															case 114:
																															case 128:
																																goto IL_051d;
																															case 84:
																																goto IL_055d;
																															case 5:
																																goto IL_0571;
																															case 112:
																																goto IL_0584;
																															case 105:
																																goto IL_059b;
																															case 62:
																															case 101:
																																goto IL_05a9;
																															case 123:
																																goto IL_05d2;
																															case 147:
																																goto IL_05e9;
																															case 26:
																															case 149:
																																goto IL_05fc;
																															case 72:
																																goto IL_060a;
																															case 38:
																																goto IL_062d;
																															case 156:
																																goto IL_0637;
																															case 52:
																																goto IL_0645;
																															case 6:
																															case 57:
																																goto IL_0658;
																															case 69:
																																goto IL_066b;
																															case 29:
																															case 39:
																																goto IL_0679;
																															case 88:
																																goto IL_0687;
																															case 116:
																																goto IL_0692;
																															case 137:
																																goto IL_06a0;
																															case 55:
																															case 95:
																																goto IL_06ae;
																															case 135:
																																goto IL_06bc;
																															case 107:
																																goto IL_06da;
																															case 154:
																																goto IL_06e8;
																															case 146:
																															case 162:
																																goto IL_06fb;
																															case 2:
																																goto IL_070f;
																															case 0:
																																goto IL_0747;
																															case 48:
																																goto IL_075a;
																															case 63:
																																goto IL_0765;
																															case 12:
																																goto IL_0773;
																															case 59:
																															case 92:
																																goto IL_0781;
																															case 99:
																																goto IL_079d;
																															case 18:
																															case 124:
																																goto IL_07ab;
																															case 14:
																																goto IL_07d8;
																															case 20:
																																goto IL_07f4;
																															case 17:
																															case 51:
																																goto IL_07ff;
																															case 86:
																																goto IL_0817;
																															case 37:
																																goto IL_0825;
																															case 22:
																																goto IL_0833;
																															case 113:
																																goto IL_0846;
																															case 122:
																															case 155:
																																goto IL_0851;
																															case 160:
																																goto IL_085f;
																															case 60:
																																goto IL_0872;
																															case 104:
																															case 118:
																																goto IL_087d;
																															case 119:
																																goto IL_08df;
																															case 41:
																															case 106:
																																goto IL_08f2;
																															case 46:
																																goto IL_08fd;
																															case 139:
																															case 157:
																																goto IL_0908;
																															case 158:
																																goto IL_0948;
																															case 30:
																																goto IL_095c;
																															case 1:
																															case 3:
																															case 4:
																															case 7:
																															case 16:
																															case 28:
																															case 32:
																															case 40:
																															case 42:
																															case 43:
																															case 44:
																															case 53:
																															case 65:
																															case 67:
																															case 73:
																															case 79:
																															case 80:
																															case 81:
																															case 83:
																															case 87:
																															case 90:
																															case 108:
																															case 117:
																															case 120:
																															case 127:
																															case 130:
																															case 131:
																															case 138:
																															case 145:
																															case 151:
																															case 159:
																																goto end_IL_0378;
																															case 94:
																																goto IL_0985;
																															case 8:
																																goto IL_0993;
																															case 24:
																																goto IL_09a1;
																															case 9:
																															case 19:
																															case 23:
																															case 25:
																															case 31:
																															case 33:
																															case 36:
																															case 47:
																															case 50:
																															case 56:
																															case 58:
																															case 66:
																															case 82:
																															case 103:
																															case 109:
																															case 115:
																															case 134:
																															case 141:
																															case 153:
																																goto end_IL_03a8;
																															case 70:
																																goto end_IL_09b8;
																															case 34:
																																goto end_IL_09cb;
																															case 129:
																																goto end_IL_09d5;
																															case 27:
																																goto end_IL_09e0;
																															case 111:
																																goto end_IL_09f0;
																															case 10:
																															case 49:
																																goto end_IL_0a00;
																															case 61:
																																goto end_IL_0a10;
																															case 71:
																															case 136:
																																goto end_IL_0a20;
																															case 96:
																																goto end_IL_0a30;
																															case 97:
																																goto end_IL_0a40;
																															case 13:
																															case 93:
																																return;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_03a8;
																														continue;
																														end_IL_02b7:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_0452;
																										IL_04c2:
																										num5--;
																										goto end_IL_03a8;
																										IL_0452:
																										if (5 < b)
																										{
																											goto end_IL_0378;
																										}
																										goto IL_0460;
																										IL_0460:
																										if (5 > b)
																										{
																											goto end_IL_0378;
																										}
																										goto IL_046e;
																										IL_046e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04ae;
																										IL_04ae:
																										array[num5 - 2] = 0;
																										goto IL_04c2;
																									}
																									break;
																								}
																								goto IL_03b3;
																								IL_0418:
																								array[num5 - 2] = 0;
																								goto IL_042c;
																								IL_03b3:
																								if (7 < b)
																								{
																									goto end_IL_0378;
																								}
																								num = 91;
																								goto IL_03ca;
																								IL_042c:
																								num5--;
																								goto end_IL_03a8;
																								IL_03ca:
																								if (7 > b)
																								{
																									goto end_IL_0378;
																								}
																								goto IL_03d8;
																								IL_03d8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0418;
																							}
																							goto IL_04fc;
																							IL_0637:
																							num5++;
																							goto IL_0645;
																							IL_04d5:
																							if (4 > b)
																							{
																								goto IL_04e3;
																							}
																							goto IL_05fc;
																							IL_04e3:
																							if (2 >= b)
																							{
																								goto IL_04f1;
																							}
																							goto IL_0584;
																							IL_04f1:
																							if (2 > b)
																							{
																								goto IL_04fc;
																							}
																							goto IL_051d;
																							IL_04fc:
																							if (1 < b)
																							{
																								goto end_IL_0378;
																							}
																							goto IL_050a;
																							IL_050a:
																							if (1 > b)
																							{
																							}
																							goto end_IL_0378;
																							IL_051d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_055d;
																							IL_055d:
																							array[num5 - 2] = 0;
																							goto IL_0571;
																							IL_0571:
																							num5--;
																							goto end_IL_03a8;
																							IL_0584:
																							if (3 < b)
																							{
																								goto end_IL_0378;
																							}
																							num = 105;
																							goto IL_059b;
																							IL_0645:
																							ptr2 += 8;
																							goto end_IL_03a8;
																							IL_059b:
																							if (3 > b)
																							{
																								goto end_IL_0378;
																							}
																							goto IL_05a9;
																							IL_05a9:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05d2;
																							IL_05d2:
																							ptr2 += 8;
																							num = 147;
																							goto IL_05e9;
																							IL_05e9:
																							num5--;
																							goto end_IL_03a8;
																							IL_05fc:
																							array[num5] = 0;
																							goto IL_060a;
																							IL_060a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_062d;
																							IL_062d:
																							array2[num5] = null;
																							goto IL_0637;
																							continue;
																							end_IL_0348:
																							break;
																						}
																						continue;
																					}
																					goto IL_0658;
																					IL_0658:
																					num5--;
																					goto end_IL_03a8;
																					continue;
																					end_IL_0358:
																					break;
																				}
																				continue;
																			}
																			goto IL_066b;
																			IL_095c:
																			num5--;
																			goto end_IL_03a8;
																			IL_066b:
																			if (12 < b)
																			{
																				goto IL_0679;
																			}
																			goto IL_07f4;
																			IL_0679:
																			if (14 >= b)
																			{
																				goto IL_0687;
																			}
																			goto IL_075a;
																			IL_0687:
																			if (14 > b)
																			{
																				goto IL_0692;
																			}
																			goto IL_06fb;
																			IL_0692:
																			if (13 < b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_06a0;
																			IL_06a0:
																			if (13 > b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_06ae;
																			IL_06ae:
																			array[num5] = 5;
																			goto IL_06bc;
																			IL_06bc:
																			array2[num5] = ((delegate*<GTPlayer>)InheritanceDemandGetVarCustData[*(int*)(ptr2 + num3)])();
																			goto IL_06da;
																			IL_06da:
																			num5++;
																			goto IL_06e8;
																			IL_06e8:
																			ptr2 += 8;
																			goto end_IL_03a8;
																			IL_06fb:
																			array[num5 - 1] = 5;
																			goto IL_070f;
																			IL_070f:
																			array2[num5 - 1] = ((delegate*<Component, Rigidbody>)InheritanceDemandGetVarCustData[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																			goto IL_0747;
																			IL_0747:
																			ptr2 += 8;
																			goto end_IL_03a8;
																			IL_075a:
																			if (15 < b)
																			{
																				goto IL_0765;
																			}
																			goto IL_079d;
																			IL_0765:
																			if (16 < b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_0773;
																			IL_0773:
																			if (16 > b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_0781;
																			IL_0781:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_03a8;
																			IL_079d:
																			if (15 > b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_07ab;
																			IL_07ab:
																			((Class174)array2[num5 - 2]).rigidbody_0 = (Rigidbody)array2[num5 - 1];
																			goto IL_07d8;
																			IL_07d8:
																			num5 -= 2;
																			num = 33;
																			goto end_IL_03a8;
																			IL_07f4:
																			if (12 <= b)
																			{
																				goto IL_07ff;
																			}
																			goto IL_0846;
																			IL_07ff:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0817;
																			IL_0817:
																			array[num5] = 5;
																			goto IL_0825;
																			IL_0825:
																			num5++;
																			goto IL_0833;
																			IL_0833:
																			ptr2 += 8;
																			goto end_IL_03a8;
																			IL_0846:
																			if (10 < b)
																			{
																				goto IL_0851;
																			}
																			goto IL_0872;
																			IL_0851:
																			if (11 < b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_085f;
																			IL_085f:
																			if (11 <= b)
																			{
																				goto end_IL_03a8;
																			}
																			goto end_IL_0378;
																			IL_0872:
																			if (10 <= b)
																			{
																				goto IL_087d;
																			}
																			goto IL_08f2;
																			IL_087d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_08df;
																			IL_08df:
																			num5 -= 2;
																			goto end_IL_03a8;
																			IL_08f2:
																			if (9 < b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_08fd;
																			IL_08fd:
																			if (9 > b)
																			{
																				goto end_IL_0378;
																			}
																			goto IL_0908;
																			IL_0908:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0948;
																			IL_0948:
																			array[num5 - 2] = 0;
																			goto IL_095c;
																			continue;
																			end_IL_0368:
																			break;
																		}
																		continue;
																		end_IL_0378:
																		break;
																	}
																}
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0985;
																IL_09a1:
																ptr2 += 8;
																num = 82;
																goto end_IL_03a8;
																IL_0993:
																num5++;
																goto IL_09a1;
																IL_0985:
																array[num5] = 0;
																goto IL_0993;
																continue;
																end_IL_0388:
																break;
															}
															continue;
															end_IL_0398:
															break;
														}
														continue;
														end_IL_03a8:
														break;
													}
													continue;
													end_IL_09b8:
													break;
												}
												continue;
												end_IL_09cb:
												break;
											}
											continue;
											end_IL_09d5:
											break;
										}
										continue;
										end_IL_09e0:
										break;
									}
									continue;
									end_IL_09f0:
									break;
								}
								continue;
								end_IL_0a00:
								break;
							}
							continue;
							end_IL_0a10:
							break;
						}
						continue;
						end_IL_0a20:
						break;
					}
					continue;
					end_IL_0a30:
					break;
				}
				continue;
				end_IL_0a40:
				break;
			}
		}
	}

	private static double AssemblyBuilderDataOwnerDefaulted(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static bool DangerousGetRawExecutionContextYellow(PhotonView photonView_0, string string_0, RpcTarget rpcTarget_0, object[] object_0)
	{
		return photonView_0.smethod_3(string_0, rpcTarget_0, object_0);
	}

	private static float GetRealObjectsetLastAccessTime(Class174 class174_1)
	{
		return class174_1.float_0;
	}

	private unsafe static int smethod_0(int int_0, int int_1)
	{
		int num = 15;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 14;
			while (true)
			{
				int num3 = num2 * 4;
				num = 13;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PrefixCodeMediaNext.RunImpersonatedInitLocals);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0249:
															byte b = *ptr2;
															while (true)
															{
																IL_0239:
																ptr2++;
																while (true)
																{
																	IL_0229:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0209:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01f9:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01ec:
																								if (7 < b)
																								{
																									while (8 >= b)
																									{
																										while (8 <= b)
																										{
																											while (true)
																											{
																												IL_01aa:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 98;
																												while (num != 98)
																												{
																													if (num != 1079)
																													{
																														goto IL_0309;
																													}
																													switch (num)
																													{
																													case 57:
																													case 76:
																														goto IL_01aa;
																													case 50:
																														goto IL_01cc;
																													case 88:
																														goto IL_01dc;
																													case 20:
																													case 43:
																														goto IL_01ec;
																													case 85:
																														goto IL_01f9;
																													case 25:
																														goto IL_0209;
																													case 68:
																														goto IL_0219;
																													case 65:
																														goto IL_0229;
																													case 36:
																														goto IL_0239;
																													case 6:
																													case 39:
																														goto IL_0249;
																													case 80:
																														goto IL_025d;
																													case 52:
																													case 61:
																														goto IL_026b;
																													case 3:
																														goto IL_0279;
																													case 45:
																														goto IL_029c;
																													case 40:
																														goto IL_02a6;
																													case 28:
																														goto IL_02b4;
																													case 91:
																														goto IL_02c7;
																													case 73:
																														goto IL_02d5;
																													case 17:
																														goto IL_02e3;
																													case 31:
																													case 55:
																														goto IL_02f1;
																													case 70:
																														goto IL_0309;
																													case 24:
																													case 86:
																														goto IL_0317;
																													case 23:
																														goto IL_0325;
																													case 12:
																													case 44:
																														goto IL_0333;
																													case 0:
																														goto IL_03a1;
																													case 35:
																													case 64:
																														goto IL_03b4;
																													case 9:
																														goto IL_03c2;
																													case 5:
																													case 53:
																														goto IL_03d5;
																													case 27:
																														goto IL_03e3;
																													case 2:
																													case 47:
																														goto IL_03f1;
																													case 77:
																														goto IL_0431;
																													case 4:
																														goto IL_0445;
																													case 22:
																													case 46:
																														goto IL_0458;
																													case 33:
																														goto IL_0481;
																													case 11:
																														goto IL_048f;
																													case 18:
																													case 19:
																													case 26:
																													case 29:
																													case 30:
																													case 37:
																													case 38:
																													case 41:
																													case 48:
																													case 49:
																													case 54:
																													case 56:
																													case 59:
																													case 60:
																													case 66:
																													case 74:
																													case 78:
																													case 84:
																													case 87:
																														goto end_IL_01cc;
																													case 63:
																														goto IL_04c2;
																													case 62:
																														goto IL_04d0;
																													case 8:
																														goto IL_04de;
																													case 32:
																													case 34:
																													case 58:
																													case 69:
																													case 71:
																													case 72:
																													case 81:
																													case 83:
																													case 89:
																													case 90:
																														goto end_IL_0197;
																													case 1:
																														goto end_IL_04ec;
																													case 10:
																														goto end_IL_04ff;
																													case 21:
																														goto end_IL_0509;
																													case 67:
																														goto end_IL_0514;
																													case 75:
																														goto end_IL_0529;
																													case 7:
																													case 51:
																														goto end_IL_053e;
																													case 82:
																														goto end_IL_054e;
																													case 13:
																													case 42:
																														goto end_IL_055e;
																													case 14:
																														goto end_IL_056e;
																													case 15:
																														goto end_IL_057e;
																													case 16:
																													case 79:
																														goto IL_05ab;
																													}
																													continue;
																													end_IL_0197:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0229;
																											continue;
																											end_IL_01cc:
																											break;
																											IL_01cc:;
																										}
																										break;
																										IL_01dc:;
																									}
																									break;
																								}
																								num = 80;
																								goto IL_025d;
																								IL_02a6:
																								num6++;
																								goto IL_02b4;
																								IL_02b4:
																								ptr2 += 8;
																								goto end_IL_0229;
																								IL_025d:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_026b;
																								IL_026b:
																								array[num6] = 0;
																								goto IL_0279;
																								IL_0279:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_029c;
																								IL_029c:
																								array2[num6] = null;
																								goto IL_02a6;
																							}
																							break;
																						}
																						goto IL_02c7;
																						IL_02f1:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0229;
																						IL_02c7:
																						if (6 <= b)
																						{
																							goto end_IL_0229;
																						}
																						goto IL_02d5;
																						IL_02d5:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02e3;
																						IL_02e3:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02f1;
																					}
																					break;
																				}
																				goto IL_0309;
																				IL_048f:
																				num6--;
																				goto end_IL_0229;
																				IL_0309:
																				if (4 > b)
																				{
																					goto IL_0317;
																				}
																				goto IL_0458;
																				IL_0317:
																				if (2 >= b)
																				{
																					goto IL_0325;
																				}
																				goto IL_03d5;
																				IL_0325:
																				if (2 <= b)
																				{
																					goto IL_0333;
																				}
																				goto IL_03b4;
																				IL_0333:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03a1;
																				IL_03a1:
																				num6 -= 2;
																				goto end_IL_0229;
																				IL_03b4:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03c2;
																				IL_03c2:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_03d5:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_03e3;
																				IL_03e3:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_03f1;
																				IL_03f1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0431;
																				IL_0431:
																				array[num6 - 2] = 0;
																				goto IL_0445;
																				IL_0445:
																				num6--;
																				goto end_IL_0229;
																				IL_0458:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0481;
																				IL_0481:
																				ptr2 += 8;
																				goto IL_048f;
																			}
																			break;
																			IL_0219:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c2;
																	IL_04de:
																	ptr2 += 8;
																	break;
																	IL_04d0:
																	num6++;
																	goto IL_04de;
																	IL_04c2:
																	array[num6] = 0;
																	goto IL_04d0;
																	continue;
																	end_IL_0229:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05ab;
													IL_05ab:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04ec:
													break;
												}
												continue;
												end_IL_04ff:
												break;
											}
											continue;
											end_IL_0509:
											break;
										}
										continue;
										end_IL_0514:
										break;
									}
									continue;
									end_IL_0529:
									break;
								}
								continue;
								end_IL_053e:
								break;
							}
							continue;
							end_IL_054e:
							break;
						}
						continue;
						end_IL_055e:
						break;
					}
					continue;
					end_IL_056e:
					break;
				}
				continue;
				end_IL_057e:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 29;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSASSEMBLYDEPLOYMENTFLAGRUNAFTERINSTALLgetDynamicMethod.GroupNoteChangeTime);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0282:
														byte b = *ptr2;
														while (true)
														{
															IL_0272:
															ptr2++;
															while (true)
															{
																IL_0262:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0242:
																			if (6 < b)
																			{
																				num = 116;
																				while (true)
																				{
																					IL_0232:
																					if (9 >= b)
																					{
																						num = 125;
																						while (true)
																						{
																							if (num != 125)
																							{
																								if (num != 1106)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 99:
																								case 116:
																									goto IL_0232;
																								case 4:
																									goto IL_0242;
																								case 17:
																									goto IL_0252;
																								case 91:
																									goto IL_0262;
																								case 28:
																									goto IL_0272;
																								case 71:
																								case 78:
																									goto IL_0282;
																								case 9:
																									goto IL_028d;
																								case 25:
																									goto IL_029a;
																								case 57:
																									goto IL_02aa;
																								case 1:
																								case 63:
																									goto IL_02bd;
																								case 55:
																								case 73:
																									goto IL_02ff;
																								case 45:
																									goto IL_030d;
																								case 77:
																									goto IL_0320;
																								case 33:
																									goto IL_0334;
																								case 2:
																								case 86:
																									goto IL_0347;
																								case 48:
																									goto IL_0352;
																								case 34:
																								case 72:
																									goto IL_035d;
																								case 6:
																								case 11:
																									goto IL_0368;
																								case 41:
																									goto IL_0376;
																								case 26:
																									goto IL_0389;
																								case 38:
																								case 47:
																									goto IL_0399;
																								case 43:
																								case 62:
																									goto IL_03ba;
																								case 50:
																								case 69:
																									goto IL_03c8;
																								case 75:
																									goto IL_03e1;
																								case 46:
																								case 74:
																									goto IL_03ef;
																								case 84:
																								case 90:
																									goto IL_0402;
																								case 82:
																									goto IL_041b;
																								case 61:
																									goto IL_0429;
																								case 44:
																									goto IL_0437;
																								case 93:
																									goto IL_044a;
																								case 5:
																								case 96:
																									goto IL_045d;
																								case 67:
																								case 107:
																									goto IL_0479;
																								case 15:
																									goto IL_04a2;
																								case 64:
																									goto IL_04b0;
																								case 113:
																									goto IL_04c3;
																								case 108:
																									goto IL_04e6;
																								case 19:
																									goto IL_04f0;
																								case 109:
																									goto IL_04fe;
																								case 27:
																								case 59:
																									goto IL_051c;
																								case 40:
																									goto IL_057e;
																								case 52:
																									goto IL_0591;
																								case 54:
																									goto IL_059c;
																								case 14:
																								case 36:
																									goto IL_05aa;
																								case 110:
																									goto IL_05ea;
																								case 8:
																									goto IL_05fe;
																								case 112:
																									goto IL_0611;
																								case 65:
																									goto IL_061c;
																								case 10:
																								case 117:
																									goto IL_0630;
																								case 7:
																									goto IL_0653;
																								case 13:
																									goto IL_0661;
																								case 24:
																									goto IL_066f;
																								case 3:
																								case 12:
																								case 16:
																								case 23:
																								case 30:
																								case 31:
																								case 42:
																								case 49:
																								case 58:
																								case 66:
																								case 68:
																								case 79:
																								case 80:
																								case 81:
																								case 85:
																								case 87:
																								case 92:
																								case 94:
																								case 102:
																								case 103:
																								case 104:
																								case 106:
																								case 111:
																								case 118:
																									goto end_IL_0252;
																								case 0:
																								case 18:
																								case 22:
																								case 32:
																								case 35:
																								case 53:
																								case 70:
																								case 83:
																								case 88:
																								case 95:
																								case 97:
																								case 98:
																								case 105:
																								case 115:
																									goto end_IL_021f;
																								case 114:
																									goto end_IL_0692;
																								case 51:
																									goto end_IL_06a5;
																								case 60:
																									goto end_IL_06af;
																								case 21:
																									goto end_IL_06ba;
																								case 29:
																								case 37:
																									goto end_IL_06cf;
																								case 56:
																									goto end_IL_06df;
																								case 39:
																								case 76:
																									goto end_IL_06ef;
																								case 100:
																									goto end_IL_0708;
																								case 101:
																									goto end_IL_0718;
																								case 20:
																								case 89:
																									goto IL_0733;
																								}
																								continue;
																							}
																							if (9 <= b)
																							{
																								goto IL_051c;
																							}
																							goto IL_0591;
																							IL_0630:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0653;
																							IL_0661:
																							num5++;
																							goto IL_066f;
																							IL_0653:
																							array[num5] = 0;
																							goto IL_0661;
																							IL_051c:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_057e;
																							IL_057e:
																							num5 -= 2;
																							break;
																							IL_0591:
																							if (7 >= b)
																							{
																								goto IL_059c;
																							}
																							goto IL_0611;
																							IL_059c:
																							if (7 > b)
																							{
																								goto end_IL_0252;
																							}
																							goto IL_05aa;
																							IL_05aa:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05ea;
																							IL_05ea:
																							array[num5 - 2] = 0;
																							goto IL_05fe;
																							IL_05fe:
																							num5--;
																							break;
																							IL_0611:
																							if (8 < b)
																							{
																								goto end_IL_0252;
																							}
																							goto IL_061c;
																							IL_061c:
																							if (8 > b)
																							{
																								goto end_IL_0252;
																							}
																							num = 117;
																							goto IL_0630;
																							IL_066f:
																							ptr2 += 8;
																							break;
																							continue;
																							end_IL_021f:
																							break;
																						}
																						break;
																					}
																					goto IL_028d;
																					IL_02aa:
																					if (10 > b)
																					{
																						goto end_IL_0252;
																					}
																					goto IL_045d;
																					IL_045d:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_028d:
																					if (10 >= b)
																					{
																						goto IL_02aa;
																					}
																					goto IL_02ff;
																					IL_02ff:
																					if (11 < b)
																					{
																						goto end_IL_0252;
																					}
																					goto IL_030d;
																					IL_030d:
																					if (11 <= b)
																					{
																					}
																					goto end_IL_0252;
																				}
																				break;
																			}
																			goto IL_029a;
																			IL_044a:
																			if (4 <= b)
																			{
																				break;
																			}
																			goto end_IL_0252;
																			IL_02bd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0320;
																			IL_029a:
																			if (6 <= b)
																			{
																				goto IL_02bd;
																			}
																			goto IL_0347;
																			IL_0347:
																			if (3 >= b)
																			{
																				goto IL_0352;
																			}
																			num = 43;
																			goto IL_03ba;
																			IL_0352:
																			if (3 > b)
																			{
																				goto IL_035d;
																			}
																			goto IL_0399;
																			IL_035d:
																			if (1 < b)
																			{
																				goto IL_0368;
																			}
																			goto IL_0389;
																			IL_0368:
																			if (2 < b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_0376;
																			IL_0376:
																			if (2 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_0479;
																			IL_0479:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04a2;
																			IL_04a2:
																			ptr2 += 8;
																			goto IL_04b0;
																			IL_04b0:
																			num5--;
																			break;
																			IL_0389:
																			if (1 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_0402;
																			IL_0402:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_041b;
																			IL_041b:
																			array[num5] = 0;
																			goto IL_0429;
																			IL_0429:
																			num5++;
																			goto IL_0437;
																			IL_0437:
																			ptr2 += 8;
																			break;
																			IL_0399:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0320:
																			array[num5 - 2] = 0;
																			goto IL_0334;
																			IL_03ba:
																			if (4 < b)
																			{
																				goto IL_03c8;
																			}
																			goto IL_044a;
																			IL_03c8:
																			if (5 < b)
																			{
																				num = 103;
																				goto end_IL_0252;
																			}
																			goto IL_03e1;
																			IL_0334:
																			num5--;
																			break;
																			IL_03e1:
																			if (5 > b)
																			{
																				goto end_IL_0252;
																			}
																			goto IL_03ef;
																			IL_03ef:
																			array[num5] = 0;
																			goto IL_04c3;
																			IL_04c3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04e6;
																			IL_04e6:
																			array2[num5] = null;
																			goto IL_04f0;
																			IL_04f0:
																			num5++;
																			goto IL_04fe;
																			IL_04fe:
																			ptr2 += 8;
																			break;
																		}
																		goto end_IL_0262;
																		continue;
																		end_IL_0252:
																		break;
																		IL_0252:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0262:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0733;
												IL_0733:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0692:
												break;
											}
											continue;
											end_IL_06a5:
											break;
										}
										continue;
										end_IL_06af:
										break;
									}
									continue;
									end_IL_06ba:
									break;
								}
								continue;
								end_IL_06cf:
								break;
							}
							continue;
							end_IL_06df:
							break;
						}
						continue;
						end_IL_06ef:
						break;
					}
					continue;
					end_IL_0708:
					break;
				}
				continue;
				end_IL_0718:
				break;
			}
		}
	}

	private static VRRig BrowserRefreshURLString(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	private unsafe void Update()
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					while (true)
					{
						IL_00ad:
						if (num3 == 51)
						{
							num = 14;
							while (true)
							{
								if (num != 14)
								{
									if (num != 995)
									{
										break;
									}
									switch (num)
									{
									case 0:
										break;
									default:
										continue;
									case 2:
									case 6:
										goto IL_00ad;
									case 7:
										goto end_IL_00a0;
									case 4:
										goto end_IL_00b8;
									case 5:
										goto end_IL_00bd;
									case 1:
									case 3:
										return;
									}
									goto IL_000e;
								}
								num3 = 0;
								return;
								continue;
								end_IL_00a0:
								break;
							}
							break;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, Class174, void>)getEventSectionCustomStoreList[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref num11, this);
						num = 6;
					}
					continue;
					end_IL_00b8:
					break;
				}
				continue;
				end_IL_00bd:
				break;
			}
		}
	}

	private static bool AddClaimGetPEKind(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static bool OverflowIsolatedStorageFile(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftGrab;
	}

	private static double getRequestedExecutionLevelUIAccessBrowserHome(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							IL_06c8:
							int[] array3 = new int[4];
							num = 79;
							while (true)
							{
								IL_06b8:
								long[] array4 = new long[3];
								while (true)
								{
									IL_06a3:
									array3[0] = int_0;
									while (true)
									{
										IL_068f:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NumberBufferToDecimalGetRuntimeMethods.MuiResourceMapResourceTypeIdStringSizeDeploymentMetadataEntry);
										num = 18;
										while (true)
										{
											IL_0685:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0672:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02cf:
														byte b = *ptr2;
														while (true)
														{
															IL_02bf:
															ptr2++;
															while (true)
															{
																IL_02af:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_028f:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0282:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0275:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0265:
																									if (7 >= b)
																									{
																										while (7 <= b)
																										{
																											while (true)
																											{
																												IL_020a:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 122;
																												while (true)
																												{
																													if (num != 122)
																													{
																														if (num != 1103)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 29:
																														case 51:
																															goto IL_020a;
																														case 69:
																															goto IL_0255;
																														case 46:
																															goto IL_0265;
																														case 56:
																															goto IL_0275;
																														case 19:
																														case 48:
																															goto IL_0282;
																														case 4:
																															goto IL_028f;
																														case 104:
																															goto IL_029f;
																														case 55:
																															goto IL_02af;
																														case 66:
																															goto IL_02bf;
																														case 13:
																														case 16:
																															goto IL_02cf;
																														case 22:
																														case 39:
																															goto IL_02e3;
																														case 23:
																															goto IL_02f1;
																														case 47:
																														case 81:
																															goto IL_0301;
																														case 35:
																															goto IL_0363;
																														case 92:
																															goto IL_0376;
																														case 93:
																															goto IL_0392;
																														case 9:
																														case 28:
																															goto IL_03a0;
																														case 10:
																															goto IL_03d0;
																														case 62:
																															goto IL_03e3;
																														case 65:
																															goto IL_03f1;
																														case 20:
																														case 61:
																															goto IL_03ff;
																														case 1:
																															goto IL_0422;
																														case 113:
																															goto IL_0430;
																														case 52:
																															goto IL_043e;
																														case 77:
																															goto IL_045a;
																														case 54:
																														case 88:
																															goto IL_0468;
																														case 43:
																															goto IL_0476;
																														case 21:
																														case 96:
																															goto IL_0481;
																														case 3:
																														case 84:
																															goto IL_0499;
																														case 60:
																														case 73:
																															goto IL_04a4;
																														case 111:
																															goto IL_04b2;
																														case 50:
																														case 87:
																															goto IL_04c0;
																														case 2:
																															goto IL_04e9;
																														case 53:
																															goto IL_04f7;
																														case 67:
																															goto IL_050a;
																														case 30:
																														case 37:
																															goto IL_0515;
																														case 75:
																															goto IL_052e;
																														case 64:
																															goto IL_053c;
																														case 78:
																															goto IL_054a;
																														case 24:
																														case 108:
																															goto IL_056b;
																														case 109:
																															goto IL_0576;
																														case 82:
																															goto IL_0584;
																														case 58:
																														case 91:
																															goto IL_0592;
																														case 34:
																															goto IL_05a0;
																														case 26:
																															goto IL_05c3;
																														case 110:
																															goto IL_05cd;
																														case 105:
																															goto IL_05db;
																														case 70:
																															goto IL_05ee;
																														case 57:
																														case 74:
																															goto IL_05fb;
																														case 44:
																															goto IL_063b;
																														case 114:
																															goto IL_064f;
																														case 5:
																														case 12:
																														case 25:
																														case 38:
																														case 45:
																														case 49:
																														case 68:
																														case 71:
																														case 72:
																														case 80:
																														case 83:
																														case 89:
																														case 90:
																														case 94:
																														case 95:
																														case 97:
																														case 99:
																														case 100:
																														case 101:
																														case 102:
																														case 106:
																														case 112:
																															goto end_IL_0255;
																														case 0:
																														case 7:
																														case 11:
																														case 14:
																														case 15:
																														case 17:
																														case 27:
																														case 33:
																														case 36:
																														case 40:
																														case 41:
																														case 59:
																														case 107:
																														case 115:
																															goto IL_0672;
																														case 18:
																															goto IL_0685;
																														case 103:
																															goto IL_068f;
																														case 85:
																															goto IL_06a3;
																														case 79:
																															goto IL_06b8;
																														case 42:
																														case 86:
																															goto IL_06c8;
																														case 76:
																															goto end_IL_01f7;
																														case 6:
																														case 63:
																															goto end_IL_06e1;
																														case 31:
																															goto end_IL_06f1;
																														case 32:
																															goto end_IL_0701;
																														case 8:
																														case 98:
																															goto IL_071c;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													goto IL_03d0;
																													IL_03d0:
																													num5--;
																													goto IL_0672;
																													continue;
																													end_IL_01f7:
																													break;
																												}
																												break;
																											}
																											goto end_IL_02af;
																											continue;
																											end_IL_0255:
																											break;
																											IL_0255:;
																										}
																										break;
																									}
																									goto IL_03e3;
																									IL_043e:
																									ptr2 += 8;
																									num = 14;
																									goto IL_0672;
																									IL_03e3:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_03f1;
																									IL_03f1:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_03ff;
																									IL_03ff:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0422;
																									IL_0422:
																									array[num5] = 0;
																									goto IL_0430;
																									IL_0430:
																									num5++;
																									goto IL_043e;
																								}
																								break;
																							}
																							goto IL_0301;
																							IL_0363:
																							num5 -= 2;
																							goto IL_0672;
																							IL_0301:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0363;
																						}
																						break;
																					}
																					num = 39;
																					goto IL_02e3;
																					IL_03a0:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0672;
																					IL_0392:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_03a0;
																					IL_02e3:
																					if (10 < b)
																					{
																						goto IL_02f1;
																					}
																					goto IL_0392;
																					IL_02f1:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0376;
																					IL_0376:
																					if (11 <= b)
																					{
																						num = 90;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_045a;
																			IL_063b:
																			array[num5 - 2] = 0;
																			goto IL_064f;
																			IL_045a:
																			if (6 > b)
																			{
																				goto IL_0468;
																			}
																			goto IL_05fb;
																			IL_0468:
																			if (3 >= b)
																			{
																				goto IL_0476;
																			}
																			goto IL_056b;
																			IL_0476:
																			if (3 <= b)
																			{
																				goto IL_0481;
																			}
																			goto IL_0499;
																			IL_0481:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_0672;
																			IL_0499:
																			if (1 < b)
																			{
																				goto IL_04a4;
																			}
																			goto IL_050a;
																			IL_04a4:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04b2;
																			IL_04b2:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04c0;
																			IL_04c0:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e9;
																			IL_04e9:
																			ptr2 += 8;
																			goto IL_04f7;
																			IL_04f7:
																			num5--;
																			goto IL_0672;
																			IL_050a:
																			if (1 > b)
																			{
																				num = 5;
																				break;
																			}
																			goto IL_0515;
																			IL_0515:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_052e;
																			IL_052e:
																			array[num5] = 0;
																			goto IL_053c;
																			IL_053c:
																			num5++;
																			goto IL_054a;
																			IL_054a:
																			ptr2 += 8;
																			goto IL_0672;
																			IL_064f:
																			num5--;
																			goto IL_0672;
																			IL_056b:
																			if (4 < b)
																			{
																				goto IL_0576;
																			}
																			goto IL_05ee;
																			IL_0576:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0584;
																			IL_0584:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0592;
																			IL_0592:
																			array[num5] = 0;
																			goto IL_05a0;
																			IL_05a0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05c3;
																			IL_05c3:
																			array2[num5] = null;
																			goto IL_05cd;
																			IL_05cd:
																			num5++;
																			goto IL_05db;
																			IL_05db:
																			ptr2 += 8;
																			goto IL_0672;
																			IL_05ee:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_0672;
																			IL_05fb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_063b;
																		}
																		break;
																		IL_029f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0672;
																continue;
																end_IL_02af:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_071c;
												IL_071c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_06e1:
						break;
					}
					continue;
					end_IL_06f1:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private static double FixedBufferAttributeStoreCategoryEnumeration(double double_1)
	{
		return Math.Floor(double_1);
	}

	private static ControllerInputPoller getUseLegacyPathHandlingBestFitUseAsm()
	{
		return ControllerInputPoller.instance;
	}

	private static Vector3 DeclaredEventsGetAllCustData(Transform transform_0)
	{
		return transform_0.forward;
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									num = 14;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDirectorySectionInternalPartitionEnumerator.NotationDigestAlgorithm);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 108;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03cf:
																	if (b >= 1)
																	{
																		goto IL_024b;
																	}
																	goto IL_03a7;
																	IL_03a7:
																	while (true)
																	{
																		IL_03a7_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_023b:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_0222:
																				num5++;
																				num = 128;
																				while (true)
																				{
																					if (num != 128)
																					{
																						if (num != 1109)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 79:
																							goto IL_0222;
																						case 20:
																							goto IL_023b;
																						case 67:
																							goto IL_024b;
																						case 52:
																							goto IL_0259;
																						case 16:
																							goto IL_0264;
																						case 46:
																							goto IL_0272;
																						case 59:
																							goto IL_0280;
																						case 56:
																							goto IL_028d;
																						case 70:
																							goto IL_02a4;
																						case 75:
																							goto IL_02b4;
																						case 83:
																							goto IL_02c7;
																						case 12:
																						case 84:
																							goto IL_02da;
																						case 55:
																							goto IL_02e5;
																						case 15:
																						case 85:
																							goto IL_02f8;
																						case 36:
																							goto IL_0306;
																						case 88:
																							goto IL_0322;
																						case 25:
																						case 66:
																							goto IL_032d;
																						case 78:
																							goto IL_0338;
																						case 96:
																							goto IL_0348;
																						case 29:
																						case 35:
																							goto end_IL_020f;
																						case 62:
																							goto IL_0361;
																						case 57:
																							goto IL_036e;
																						case 107:
																							goto IL_0379;
																						case 109:
																							goto IL_0389;
																						case 120:
																							goto IL_0399;
																						case 7:
																						case 11:
																						case 13:
																						case 19:
																						case 22:
																						case 30:
																						case 31:
																						case 33:
																						case 37:
																						case 43:
																						case 45:
																						case 48:
																						case 49:
																						case 53:
																						case 77:
																						case 81:
																						case 91:
																						case 93:
																						case 100:
																						case 103:
																						case 111:
																						case 115:
																						case 121:
																							goto IL_03a7_2;
																						case 106:
																							goto IL_03cf;
																						case 108:
																							goto end_IL_03cf;
																						case 38:
																						case 99:
																							goto end_IL_03df;
																						case 51:
																						case 68:
																							goto IL_0403;
																						case 6:
																							goto IL_0417;
																						case 63:
																							goto IL_0456;
																						case 50:
																						case 69:
																							goto IL_0469;
																						case 2:
																							goto IL_0482;
																						case 18:
																							goto IL_0490;
																						case 42:
																						case 47:
																							goto IL_04ac;
																						case 23:
																						case 32:
																							goto IL_04c8;
																						case 71:
																							goto IL_04f1;
																						case 86:
																							goto IL_04ff;
																						case 95:
																						case 102:
																							goto IL_0512;
																						case 89:
																							goto IL_0552;
																						case 72:
																							goto IL_0566;
																						case 64:
																						case 104:
																							goto IL_0579;
																						case 82:
																							goto IL_05b9;
																						case 87:
																							goto IL_05cd;
																						case 10:
																						case 105:
																							goto IL_05e0;
																						case 24:
																						case 80:
																							goto IL_062e;
																						case 58:
																							goto IL_066e;
																						case 26:
																							goto IL_0682;
																						case 1:
																						case 110:
																							goto IL_0695;
																						case 73:
																							goto IL_06a3;
																						case 44:
																							goto IL_06c6;
																						case 98:
																							goto IL_06d0;
																						case 4:
																							goto IL_06de;
																						case 113:
																							goto IL_06ee;
																						case 118:
																							goto IL_06fe;
																						case 92:
																							goto IL_071b;
																						case 9:
																						case 61:
																							goto IL_072b;
																						case 3:
																						case 5:
																						case 8:
																						case 28:
																						case 34:
																						case 65:
																						case 76:
																						case 90:
																						case 112:
																						case 114:
																						case 116:
																						case 117:
																						case 119:
																							goto end_IL_03ef;
																						case 17:
																							goto end_IL_0749;
																						case 94:
																							goto end_IL_075c;
																						case 14:
																							goto end_IL_0766;
																						case 21:
																							goto end_IL_0771;
																						case 41:
																							goto end_IL_0786;
																						case 0:
																						case 27:
																							goto end_IL_07a4;
																						case 97:
																							goto end_IL_07b4;
																						case 54:
																						case 60:
																							goto end_IL_07c4;
																						case 39:
																							goto end_IL_07d4;
																						case 40:
																							goto end_IL_07e4;
																						case 74:
																						case 101:
																							goto IL_07ff;
																						}
																						continue;
																					}
																					ptr2 += 8;
																					goto end_IL_03ef;
																					continue;
																					end_IL_020f:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0356;
																	IL_024b:
																	if (b <= 11)
																	{
																		goto IL_0259;
																	}
																	goto IL_03a7;
																	IL_0259:
																	if (6 >= b)
																	{
																		goto IL_0264;
																	}
																	goto IL_028d;
																	IL_0264:
																	if (6 > b)
																	{
																		goto IL_0272;
																	}
																	goto IL_05e0;
																	IL_0272:
																	if (3 < b)
																	{
																		goto IL_0280;
																	}
																	goto IL_0348;
																	IL_0280:
																	if (4 < b)
																	{
																		goto IL_02b4;
																	}
																	goto IL_02c7;
																	IL_02c7:
																	if (4 > b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_0512;
																	IL_0512:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0552;
																	IL_0552:
																	array[num5 - 2] = 0;
																	goto IL_0566;
																	IL_0566:
																	num5--;
																	goto end_IL_03ef;
																	IL_02b4:
																	if (5 >= b)
																	{
																		goto IL_0389;
																	}
																	goto IL_03a7;
																	IL_0389:
																	if (5 > b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_0695;
																	IL_0695:
																	array[num5] = 0;
																	goto IL_06a3;
																	IL_06a3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06c6;
																	IL_06c6:
																	array2[num5] = null;
																	goto IL_06d0;
																	IL_06d0:
																	num5++;
																	goto IL_06de;
																	IL_06de:
																	ptr2 += 8;
																	goto end_IL_03ef;
																	IL_0348:
																	if (3 > b)
																	{
																		goto IL_0356;
																	}
																	goto IL_04c8;
																	IL_0356:
																	if (1 >= b)
																	{
																		goto IL_0361;
																	}
																	goto IL_036e;
																	IL_0361:
																	if (1 <= b)
																	{
																	}
																	goto IL_03a7;
																	IL_036e:
																	if (2 >= b)
																	{
																		goto IL_0379;
																	}
																	goto IL_03a7;
																	IL_0379:
																	if (2 > b)
																	{
																		goto IL_03a7;
																	}
																	num = 80;
																	goto IL_062e;
																	IL_04ac:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_03ef;
																	IL_062e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_066e;
																	IL_066e:
																	array[num5 - 2] = 0;
																	goto IL_0682;
																	IL_0682:
																	num5--;
																	goto end_IL_03ef;
																	IL_04c8:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04f1;
																	IL_04f1:
																	ptr2 += 8;
																	goto IL_04ff;
																	IL_04ff:
																	num5--;
																	goto end_IL_03ef;
																	IL_05e0:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_06fe;
																	IL_06fe:
																	array[num5 - 2] = 0;
																	num = 92;
																	goto IL_071b;
																	IL_071b:
																	num5--;
																	goto end_IL_03ef;
																	IL_028d:
																	if (9 >= b)
																	{
																		num = 70;
																		goto IL_02a4;
																	}
																	goto IL_0322;
																	IL_0399:
																	if (10 > b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_072b;
																	IL_02a4:
																	if (9 > b)
																	{
																		goto IL_02da;
																	}
																	goto IL_0403;
																	IL_02da:
																	if (7 >= b)
																	{
																		goto IL_02e5;
																	}
																	goto IL_02f8;
																	IL_02e5:
																	if (7 > b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_0469;
																	IL_0469:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0482;
																	IL_0482:
																	array[num5] = 0;
																	goto IL_0490;
																	IL_0490:
																	num5++;
																	num = 113;
																	goto IL_06ee;
																	IL_06ee:
																	ptr2 += 8;
																	goto end_IL_03ef;
																	IL_02f8:
																	if (8 >= b)
																	{
																		goto IL_0306;
																	}
																	goto IL_03a7;
																	IL_0306:
																	if (8 > b)
																	{
																		num = 37;
																		goto IL_03a7;
																	}
																	goto IL_0579;
																	IL_072b:
																	num5--;
																	goto end_IL_03ef;
																	IL_0579:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05b9;
																	IL_05b9:
																	array[num5 - 2] = 0;
																	goto IL_05cd;
																	IL_05cd:
																	num5--;
																	goto end_IL_03ef;
																	IL_0403:
																	array[num5 - 1] = 0;
																	goto IL_0417;
																	IL_0417:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)INVOCATIONFLAGSISDELEGATECTORInternalCall[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	goto IL_0456;
																	IL_0456:
																	ptr2 += 8;
																	goto end_IL_03ef;
																	IL_0322:
																	if (10 < b)
																	{
																		goto IL_032d;
																	}
																	goto IL_0399;
																	IL_032d:
																	if (11 >= b)
																	{
																		goto IL_0338;
																	}
																	goto IL_03a7;
																	IL_0338:
																	if (11 > b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_04ac;
																	continue;
																	end_IL_03cf:
																	break;
																}
																continue;
																end_IL_03df:
																break;
															}
															continue;
															end_IL_03ef:
															break;
														}
														continue;
													}
													goto IL_07ff;
													IL_07ff:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0749:
													break;
												}
												continue;
												end_IL_075c:
												break;
											}
											continue;
											end_IL_0766:
											break;
										}
										continue;
										end_IL_0771:
										break;
									}
									continue;
									end_IL_0786:
									break;
								}
								continue;
								end_IL_07a4:
								break;
							}
							continue;
							end_IL_07b4:
							break;
						}
						continue;
						end_IL_07c4:
						break;
					}
					continue;
					end_IL_07d4:
					break;
				}
				continue;
				end_IL_07e4:
				break;
			}
		}
	}

	private static GorillaTagger SinkProviderEntryArgRegKeyStrLenBug()
	{
		return GorillaTagger.Instance;
	}

	private static GorillaTagger ReflectionOnlyGetTypeStartOfUserTypes()
	{
		return GorillaTagger.Instance;
	}

	private static double EndOfStringgetGuarantees(double double_1)
	{
		return Math.Cos(double_1);
	}

	private unsafe void OnDisable()
	{
		int num = 73;
		long[] array4 = default(long[]);
		byte b = default(byte);
		int num4 = default(int);
		byte* ptr = default(byte*);
		object[] array5 = default(object[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							num = 143;
							while (true)
							{
								if (num != 143)
								{
									if (num != 1124)
									{
										goto IL_0938;
									}
									switch (num)
									{
									case 82:
									case 116:
										goto end_IL_024b;
									case 75:
										goto end_IL_025b;
									case 62:
									case 91:
										goto end_IL_0274;
									case 72:
										goto end_IL_0284;
									case 73:
										goto end_IL_0294;
									case 92:
										goto IL_02bd;
									case 102:
										goto IL_02cb;
									case 0:
										goto IL_02d9;
									case 29:
										goto IL_02eb;
									case 53:
									case 115:
										goto IL_02f8;
									case 120:
										goto IL_0301;
									case 1:
										goto IL_030f;
									case 41:
										goto IL_031d;
									case 95:
										goto IL_032b;
									case 5:
										goto IL_0339;
									case 70:
									case 124:
										goto IL_0344;
									case 76:
										goto IL_0357;
									case 34:
										goto IL_0365;
									case 44:
									case 101:
										goto IL_0370;
									case 3:
										goto IL_037e;
									case 49:
										goto IL_03a1;
									case 89:
										goto IL_03ab;
									case 23:
										goto IL_03b9;
									case 100:
										goto IL_03cc;
									case 22:
										goto IL_03da;
									case 37:
									case 69:
										goto IL_03e5;
									case 46:
										goto IL_0425;
									case 93:
										goto IL_0439;
									case 112:
										goto IL_044c;
									case 13:
										goto IL_045a;
									case 27:
										goto IL_046d;
									case 61:
										goto IL_047b;
									case 11:
									case 81:
										goto IL_0489;
									case 16:
										goto IL_04b2;
									case 125:
										goto IL_04c0;
									case 133:
										goto IL_04dc;
									case 103:
										goto IL_04ea;
									case 10:
									case 14:
										goto IL_04f5;
									case 2:
										goto IL_0535;
									case 109:
										goto IL_0549;
									case 111:
										goto IL_0565;
									case 106:
										goto IL_0573;
									case 25:
									case 98:
										goto IL_0581;
									case 60:
										goto IL_05c1;
									case 59:
										goto IL_05d5;
									case 104:
										goto IL_05e8;
									case 119:
										goto IL_05ff;
									case 63:
									case 80:
										goto IL_0616;
									case 94:
										goto IL_0656;
									case 43:
										goto IL_066a;
									case 35:
										goto IL_067d;
									case 68:
										goto IL_068b;
									case 38:
										goto IL_0699;
									case 39:
									case 65:
										goto IL_06a4;
									case 15:
										goto IL_06d2;
									case 66:
										goto IL_06e5;
									case 18:
										goto IL_06f3;
									case 88:
									case 127:
										goto IL_0701;
									case 52:
										goto IL_071b;
									case 57:
										goto IL_0729;
									case 4:
										goto IL_0737;
									case 9:
										goto IL_074a;
									case 132:
										goto IL_0758;
									case 21:
									case 24:
										goto IL_0766;
									case 105:
										goto IL_0782;
									case 51:
									case 71:
										goto IL_078d;
									case 36:
										goto IL_07a5;
									case 31:
										goto IL_07b3;
									case 131:
										goto IL_07c1;
									case 12:
										goto IL_07d4;
									case 32:
										goto IL_07e2;
									case 7:
									case 48:
										goto IL_07ed;
									case 42:
										goto IL_084f;
									case 113:
										goto IL_0862;
									case 56:
										goto IL_0870;
									case 28:
									case 108:
										goto IL_087b;
									case 74:
										goto IL_08bb;
									case 129:
										goto IL_08cf;
									case 47:
										goto IL_08df;
									case 33:
										goto IL_08ea;
									case 8:
									case 17:
									case 19:
									case 30:
									case 45:
									case 50:
									case 54:
									case 55:
									case 58:
									case 67:
									case 78:
									case 83:
									case 87:
									case 110:
									case 121:
									case 122:
									case 123:
									case 126:
										goto IL_08f5;
									case 114:
										goto IL_090e;
									case 130:
										goto IL_091c;
									case 118:
										goto IL_092a;
									case 6:
									case 20:
									case 26:
									case 40:
									case 64:
									case 77:
									case 79:
									case 85:
									case 86:
									case 90:
									case 96:
									case 99:
									case 107:
									case 117:
									case 128:
									case 134:
									case 135:
									case 136:
										goto IL_0938;
									case 84:
									case 97:
										return;
									}
									continue;
								}
								array4 = new long[3];
								goto IL_02bd;
								IL_08df:
								if (11 >= b)
								{
									goto IL_08ea;
								}
								goto IL_08f5;
								IL_08f5:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
								goto IL_090e;
								IL_08ea:
								if (11 > b)
								{
									goto IL_08f5;
								}
								goto IL_0938;
								IL_02bd:
								array5 = new object[1];
								goto IL_02cb;
								IL_02cb:
								array5[0] = this;
								goto IL_02d9;
								IL_02d9:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ActivatedClientTypeEntryInterfaceIsIUnknown.ParameterTokenMuiResourceMapResourceTypeIdIntSize);
								num = 29;
								goto IL_02eb;
								IL_02eb:
								ptr = ptr2;
								goto IL_0938;
								IL_0938:
								if (num5 == 1)
								{
									num = 97;
									return;
								}
								goto IL_02f8;
								IL_090e:
								array[num4] = 0;
								goto IL_091c;
								IL_02f8:
								b = *ptr;
								goto IL_0301;
								IL_0301:
								ptr++;
								goto IL_030f;
								IL_030f:
								if (b >= 1)
								{
									goto IL_031d;
								}
								goto IL_08f5;
								IL_031d:
								if (b <= 15)
								{
									goto IL_032b;
								}
								goto IL_08f5;
								IL_032b:
								if (8 >= b)
								{
									goto IL_0339;
								}
								goto IL_067d;
								IL_0339:
								if (8 <= b)
								{
									goto IL_0344;
								}
								goto IL_0357;
								IL_0344:
								num4--;
								goto IL_0938;
								IL_0357:
								if (4 >= b)
								{
									goto IL_0365;
								}
								goto IL_04dc;
								IL_0365:
								if (4 <= b)
								{
									goto IL_0370;
								}
								goto IL_03cc;
								IL_0370:
								array[num4] = 0;
								goto IL_037e;
								IL_037e:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_03a1;
								IL_03a1:
								array2[num4] = null;
								goto IL_03ab;
								IL_03ab:
								num4++;
								goto IL_03b9;
								IL_03b9:
								ptr += 8;
								goto IL_0938;
								IL_03cc:
								if (2 >= b)
								{
									goto IL_03da;
								}
								goto IL_046d;
								IL_03da:
								if (2 <= b)
								{
									goto IL_03e5;
								}
								goto IL_044c;
								IL_03e5:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0425;
								IL_0425:
								array[num4 - 2] = 0;
								goto IL_0439;
								IL_0439:
								num4--;
								goto IL_0938;
								IL_044c:
								if (1 >= b)
								{
									goto IL_045a;
								}
								goto IL_08f5;
								IL_045a:
								if (1 > b)
								{
								}
								goto IL_08f5;
								IL_046d:
								if (3 >= b)
								{
									goto IL_047b;
								}
								goto IL_08f5;
								IL_047b:
								if (3 <= b)
								{
									goto IL_0489;
								}
								goto IL_08f5;
								IL_0489:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_04b2;
								IL_04b2:
								ptr += 8;
								goto IL_04c0;
								IL_04c0:
								num4--;
								num = 128;
								goto IL_0938;
								IL_04dc:
								if (6 >= b)
								{
									goto IL_04ea;
								}
								goto IL_05e8;
								IL_04ea:
								if (6 <= b)
								{
									goto IL_04f5;
								}
								goto IL_0565;
								IL_04f5:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0535;
								IL_0535:
								array[num4 - 2] = 0;
								goto IL_0549;
								IL_0549:
								num4--;
								num = 6;
								goto IL_0938;
								IL_0565:
								if (5 >= b)
								{
									goto IL_0573;
								}
								goto IL_08f5;
								IL_0573:
								if (5 <= b)
								{
									goto IL_0581;
								}
								goto IL_08f5;
								IL_0581:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_05c1;
								IL_05c1:
								array[num4 - 2] = 0;
								goto IL_05d5;
								IL_05d5:
								num4--;
								goto IL_0938;
								IL_05e8:
								if (7 >= b)
								{
									num = 119;
									goto IL_05ff;
								}
								goto IL_08f5;
								IL_091c:
								num4++;
								goto IL_092a;
								IL_05ff:
								if (7 <= b)
								{
									num = 80;
									goto IL_0616;
								}
								goto IL_08f5;
								IL_092a:
								ptr += 8;
								goto IL_0938;
								IL_0616:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0656;
								IL_0656:
								array[num4 - 2] = 0;
								goto IL_066a;
								IL_066a:
								num4--;
								goto IL_0938;
								IL_067d:
								if (12 < b)
								{
									goto IL_068b;
								}
								goto IL_0782;
								IL_068b:
								if (14 >= b)
								{
									goto IL_0699;
								}
								goto IL_074a;
								IL_0699:
								if (14 <= b)
								{
									goto IL_06a4;
								}
								goto IL_06e5;
								IL_06a4:
								((Class174)array2[num4 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
								goto IL_06d2;
								IL_06d2:
								num4 -= 2;
								goto IL_0938;
								IL_06e5:
								if (13 >= b)
								{
									goto IL_06f3;
								}
								goto IL_08f5;
								IL_06f3:
								if (13 <= b)
								{
									goto IL_0701;
								}
								goto IL_08f5;
								IL_0701:
								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(float*)(ptr + num3);
								goto IL_071b;
								IL_071b:
								array[num4] = 3;
								goto IL_0729;
								IL_0729:
								num4++;
								goto IL_0737;
								IL_0737:
								ptr += 8;
								goto IL_0938;
								IL_074a:
								if (15 >= b)
								{
									goto IL_0758;
								}
								goto IL_08f5;
								IL_0758:
								if (15 <= b)
								{
									goto IL_0766;
								}
								goto IL_08f5;
								IL_0766:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0938;
								IL_0782:
								if (12 <= b)
								{
									goto IL_078d;
								}
								goto IL_07d4;
								IL_078d:
								array2[num4] = array5[*(int*)(ptr + num3)];
								goto IL_07a5;
								IL_07a5:
								array[num4] = 5;
								goto IL_07b3;
								IL_07b3:
								num4++;
								goto IL_07c1;
								IL_07c1:
								ptr += 8;
								goto IL_0938;
								IL_07d4:
								if (10 >= b)
								{
									goto IL_07e2;
								}
								goto IL_08df;
								IL_07e2:
								if (10 <= b)
								{
									goto IL_07ed;
								}
								goto IL_0862;
								IL_07ed:
								ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_084f;
								IL_084f:
								num4 -= 2;
								goto IL_0938;
								IL_0862:
								if (9 >= b)
								{
									goto IL_0870;
								}
								goto IL_08f5;
								IL_0870:
								if (9 <= b)
								{
									goto IL_087b;
								}
								goto IL_08f5;
								IL_087b:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_08bb;
								IL_08bb:
								array[num4 - 2] = 0;
								goto IL_08cf;
								IL_08cf:
								num4--;
								goto IL_0938;
								continue;
								end_IL_024b:
								break;
							}
							continue;
							end_IL_025b:
							break;
						}
						continue;
						end_IL_0274:
						break;
					}
					continue;
					end_IL_0284:
					break;
				}
				continue;
				end_IL_0294:
				break;
			}
		}
	}

	private static int ComposedOfNoStaticMembersContinuationTask(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static float AttributeStringComMemberType()
	{
		return Time.time;
	}

	private static int getLocalSafeFindHandle(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static int ReflectionPermissionFlaggetContentType(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool ApplicationIsolationByRoamingUsersetFirstDayOfWeek(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerSecondaryButton;
	}

	private static bool setHashValueResolveMethodHandle(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightGrab;
	}

	private static double MscorlibDictionaryKeyCollectionDebugViewMustUnderstand(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static bool CheckAccessOnOverrideRSACspObject(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerSecondaryButton;
	}

	private unsafe static int smethod_5()
	{
		int num = 36;
		byte b = default(byte);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		object[] array5 = default(object[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 35;
			while (true)
			{
				int num3 = num2 * 4;
				num = 24;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 152;
						while (true)
						{
							if (num == 152)
							{
								goto IL_02d5;
							}
							if (num != 1133)
							{
								goto IL_0580;
							}
							switch (num)
							{
							case 21:
								goto end_IL_026f;
							case 24:
							case 105:
								goto end_IL_027f;
							case 35:
								goto end_IL_0298;
							case 36:
								goto end_IL_02a8;
							case 79:
								goto IL_02d5;
							case 34:
								goto IL_02e3;
							case 80:
								goto IL_02f1;
							case 8:
								goto IL_02ff;
							case 50:
								goto IL_0308;
							case 1:
							case 20:
							case 43:
							case 67:
							case 74:
							case 82:
							case 84:
							case 85:
							case 90:
							case 100:
							case 111:
							case 113:
							case 119:
							case 120:
							case 123:
							case 125:
							case 126:
							case 131:
								goto IL_0310;
							case 132:
								goto IL_0320;
							case 55:
								goto IL_0329;
							case 14:
								goto IL_033b;
							case 23:
								goto IL_0349;
							case 13:
								goto IL_0357;
							case 29:
								goto IL_0365;
							case 69:
								goto IL_037c;
							case 118:
							case 144:
								goto IL_0387;
							case 87:
								goto IL_039f;
							case 57:
								goto IL_03ad;
							case 9:
							case 60:
								goto IL_03b8;
							case 61:
								goto IL_03d6;
							case 112:
								goto IL_03e4;
							case 44:
							case 129:
								goto IL_03f7;
							case 59:
								goto IL_0405;
							case 75:
								goto IL_0410;
							case 70:
								goto IL_041e;
							case 115:
							case 117:
								goto IL_042c;
							case 142:
								goto IL_0445;
							case 37:
								goto IL_045c;
							case 27:
								goto IL_046a;
							case 41:
							case 58:
								goto IL_0486;
							case 25:
								goto IL_04c6;
							case 17:
								goto IL_04da;
							case 32:
								goto IL_04ed;
							case 64:
								goto IL_04fb;
							case 68:
							case 89:
								goto IL_0509;
							case 7:
								goto IL_0532;
							case 19:
							case 102:
								goto IL_054b;
							case 31:
								goto IL_0559;
							case 95:
							case 108:
								goto IL_0564;
							case 11:
								goto IL_0572;
							case 26:
							case 121:
								goto IL_0580;
							case 3:
								goto IL_058e;
							case 97:
								goto IL_05a6;
							case 96:
								goto IL_05b4;
							case 94:
							case 133:
								goto IL_05c7;
							case 62:
								goto IL_0606;
							case 63:
								goto IL_0619;
							case 110:
								goto IL_0627;
							case 92:
							case 99:
								goto IL_0635;
							case 145:
								goto IL_065e;
							case 114:
								goto IL_0675;
							case 48:
								goto IL_0691;
							case 86:
								goto IL_069f;
							case 16:
							case 77:
								goto IL_06aa;
							case 5:
								goto IL_06ea;
							case 139:
								goto IL_06fe;
							case 141:
								goto IL_0711;
							case 137:
								goto IL_071f;
							case 33:
							case 107:
								goto IL_072a;
							case 30:
								goto IL_0738;
							case 51:
							case 78:
								goto IL_074b;
							case 135:
								goto IL_0762;
							case 136:
								goto IL_078e;
							case 46:
								goto IL_0798;
							case 53:
								goto IL_07a6;
							case 88:
								goto IL_07b9;
							case 134:
								goto IL_07c7;
							case 28:
							case 103:
								goto IL_07d5;
							case 6:
								goto IL_0819;
							case 38:
								goto IL_082d;
							case 140:
								goto IL_0840;
							case 91:
							case 138:
								goto IL_084b;
							case 0:
								goto IL_0859;
							case 18:
								goto IL_0875;
							case 2:
							case 127:
								goto IL_0880;
							case 22:
							case 52:
								goto IL_089c;
							case 101:
								goto IL_08aa;
							case 42:
							case 56:
								goto IL_08b5;
							case 76:
								goto IL_0917;
							case 4:
							case 10:
							case 12:
							case 15:
							case 39:
							case 45:
							case 47:
							case 49:
							case 54:
							case 65:
							case 66:
							case 71:
							case 72:
							case 73:
							case 81:
							case 93:
							case 98:
							case 104:
							case 106:
							case 109:
							case 116:
							case 122:
							case 124:
							case 128:
							case 130:
							case 143:
								goto IL_0933;
							case 40:
							case 83:
								goto IL_094b;
							}
							continue;
							IL_089c:
							if (13 >= b)
							{
								goto IL_08aa;
							}
							goto IL_0933;
							IL_08aa:
							if (13 <= b)
							{
								goto IL_08b5;
							}
							goto IL_0933;
							IL_02d5:
							array3 = new int[2];
							goto IL_02e3;
							IL_02e3:
							array4 = new long[4];
							goto IL_02f1;
							IL_02f1:
							array5 = new object[1];
							goto IL_02ff;
							IL_02ff:
							ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CondBranchCMSSECTIONIDSTRINGSECTION.HandleToInfoNegativeInfinity);
							goto IL_0308;
							IL_0308:
							ptr2 = ptr;
							goto IL_0310;
							IL_0310:
							if (num4 != 1)
							{
								goto IL_0320;
							}
							goto IL_094b;
							IL_094b:
							return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
							IL_0320:
							num = 55;
							goto IL_0329;
							IL_0329:
							b = *ptr2;
							num = 14;
							goto IL_033b;
							IL_033b:
							ptr2++;
							goto IL_0349;
							IL_0349:
							if (b >= 1)
							{
								goto IL_0357;
							}
							num = 122;
							goto IL_0933;
							IL_0357:
							if (b <= 15)
							{
								goto IL_0365;
							}
							goto IL_0933;
							IL_0365:
							if (8 >= b)
							{
								num = 69;
								goto IL_037c;
							}
							goto IL_0691;
							IL_0917:
							num5 -= 2;
							goto IL_0310;
							IL_037c:
							if (8 <= b)
							{
								goto IL_0387;
							}
							goto IL_039f;
							IL_0387:
							ptr2 = ptr + *(int*)(ptr2 + num3);
							goto IL_0310;
							IL_039f:
							if (4 >= b)
							{
								goto IL_03ad;
							}
							goto IL_054b;
							IL_03ad:
							if (4 <= b)
							{
								goto IL_03b8;
							}
							goto IL_03f7;
							IL_03b8:
							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
							goto IL_03d6;
							IL_03d6:
							ptr2 += 8;
							goto IL_03e4;
							IL_03e4:
							num5--;
							goto IL_0310;
							IL_03f7:
							if (2 >= b)
							{
								goto IL_0405;
							}
							goto IL_04ed;
							IL_0405:
							if (2 > b)
							{
								goto IL_0410;
							}
							num = 41;
							goto IL_0486;
							IL_0410:
							if (1 >= b)
							{
								goto IL_041e;
							}
							goto IL_0933;
							IL_041e:
							if (1 <= b)
							{
								goto IL_042c;
							}
							goto IL_0933;
							IL_042c:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
							goto IL_0445;
							IL_0445:
							array[num5] = 0;
							num = 37;
							goto IL_045c;
							IL_045c:
							num5++;
							goto IL_046a;
							IL_046a:
							ptr2 += 8;
							goto IL_0310;
							IL_08b5:
							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
							goto IL_0917;
							IL_0486:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
							goto IL_04c6;
							IL_04c6:
							array[num5 - 2] = 0;
							goto IL_04da;
							IL_04da:
							num5--;
							goto IL_0310;
							IL_04ed:
							if (3 >= b)
							{
								goto IL_04fb;
							}
							goto IL_0933;
							IL_04fb:
							if (3 <= b)
							{
								goto IL_0509;
							}
							goto IL_0933;
							IL_0509:
							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
							goto IL_0532;
							IL_0532:
							array[num5 - 1] = 5;
							goto IL_0310;
							IL_054b:
							if (6 >= b)
							{
								goto IL_0559;
							}
							goto IL_0619;
							IL_0559:
							if (6 > b)
							{
								goto IL_0564;
							}
							goto IL_05c7;
							IL_0564:
							if (5 >= b)
							{
								goto IL_0572;
							}
							goto IL_0933;
							IL_0572:
							if (5 <= b)
							{
								goto IL_0580;
							}
							goto IL_0933;
							IL_0580:
							array[num5] = 5;
							goto IL_058e;
							IL_058e:
							array2[num5] = array5[*(int*)(ptr2 + num3)];
							goto IL_05a6;
							IL_05a6:
							num5++;
							goto IL_05b4;
							IL_05b4:
							ptr2 += 8;
							goto IL_0310;
							IL_05c7:
							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
							goto IL_0606;
							IL_0606:
							num5 -= 3;
							goto IL_0310;
							IL_0619:
							if (7 >= b)
							{
								goto IL_0627;
							}
							goto IL_0933;
							IL_0627:
							if (7 <= b)
							{
								goto IL_0635;
							}
							goto IL_0933;
							IL_0635:
							ref int reference = ref array3[*(int*)(ptr2 + num3)];
							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
							goto IL_065e;
							IL_065e:
							ptr2 += 8;
							num = 114;
							goto IL_0675;
							IL_0675:
							num5--;
							num = 131;
							goto IL_0310;
							IL_0691:
							if (12 >= b)
							{
								goto IL_069f;
							}
							goto IL_0840;
							IL_069f:
							if (12 <= b)
							{
								goto IL_06aa;
							}
							goto IL_0711;
							IL_06aa:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
							goto IL_06ea;
							IL_06ea:
							array[num5 - 2] = 0;
							goto IL_06fe;
							IL_06fe:
							num5--;
							goto IL_0310;
							IL_0711:
							if (10 >= b)
							{
								goto IL_071f;
							}
							goto IL_07b9;
							IL_071f:
							if (10 > b)
							{
								goto IL_072a;
							}
							goto IL_074b;
							IL_072a:
							if (9 >= b)
							{
								goto IL_0738;
							}
							goto IL_0933;
							IL_0738:
							if (9 <= b)
							{
								goto IL_0310;
							}
							goto IL_0933;
							IL_074b:
							array[num5] = 0;
							num = 135;
							goto IL_0762;
							IL_0762:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
							num = 136;
							goto IL_078e;
							IL_078e:
							array2[num5] = null;
							goto IL_0798;
							IL_0798:
							num5++;
							goto IL_07a6;
							IL_07a6:
							ptr2 += 8;
							goto IL_0310;
							IL_07b9:
							if (11 >= b)
							{
								goto IL_07c7;
							}
							goto IL_0933;
							IL_07c7:
							if (11 <= b)
							{
								goto IL_07d5;
							}
							goto IL_0933;
							IL_07d5:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
							goto IL_0819;
							IL_0819:
							array[num5 - 2] = 0;
							goto IL_082d;
							IL_082d:
							num5--;
							goto IL_0310;
							IL_0840:
							if (14 < b)
							{
								goto IL_084b;
							}
							goto IL_0875;
							IL_084b:
							if (15 >= b)
							{
								goto IL_0859;
							}
							goto IL_0933;
							IL_0859:
							if (15 <= b)
							{
								num = 124;
							}
							goto IL_0933;
							IL_0933:
							ptr2 = ptr + *(int*)(ptr2 + num3);
							goto IL_0310;
							IL_0875:
							if (14 <= b)
							{
								goto IL_0880;
							}
							goto IL_089c;
							IL_0880:
							byte* num6 = ptr2;
							num4 = 1;
							ptr2 = num6 + -200;
							goto IL_0310;
							continue;
							end_IL_026f:
							break;
						}
						continue;
						end_IL_027f:
						break;
					}
					continue;
					end_IL_0298:
					break;
				}
				continue;
				end_IL_02a8:
				break;
			}
		}
	}

	private static PhotonView ITupleInternalOutTypeChainFlag(NetworkView networkView_0)
	{
		return networkView_0.GetView;
	}

	public Class174()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static string ResourceTableMappingFinalStringMappedgetKeysOrderedAcrossPartitions(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static double RuntimeMethodInfoGetDeclaredStaticMethod(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static double ISTOREENUMFILESFLAGINCLUDEINSTALLEDFILESgetIsAuthenticated(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static Rigidbody RemUnGetSize(Class174 class174_1)
	{
		return class174_1.rigidbody_0;
	}

	static Class174()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0046:
				Class300.smethod_0();
				num = 12;
				while (true)
				{
					if (num != 12)
					{
						if (num != 993)
						{
							break;
						}
						switch (num)
						{
						case 3:
							goto IL_0046;
						case 4:
							goto end_IL_0039;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 5:
							return;
						}
						continue;
					}
					return;
					continue;
					end_IL_0039:
					break;
				}
				break;
			}
		}
	}

	private static Quaternion getSignedFilegetWindowHeight(Transform transform_0)
	{
		return transform_0.rotation;
	}

	private static Vector3 smethod_7()
	{
		return global::_003CModule_003E.vector3_125;
	}

	private static int NoFlagslpValue(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static double AreAuditRulesCanonicalOffsetToStringData(double double_1)
	{
		return Math.Round(double_1);
	}

	private static double getPrivateBinPathProbeMapToCollectionAdapter(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static SphereCollider getTaskSchedulergetTargetSite(GTPlayer gtplayer_0)
	{
		return gtplayer_0.headCollider;
	}

	private static double CONSOLESCREENBUFFERINFOSideBySide(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static void getDaysWantsToListen(GorillaTagger gorillaTagger_0, XRNode xrnode_0, float float_2, float float_3)
	{
		gorillaTagger_0.DoVibration(xrnode_0, float_2, float_3);
	}

	private static Vector3 getCertificateLdflda(Vector3 vector3_0, float float_2)
	{
		return vector3_0 * float_2;
	}

	private unsafe static int smethod_8()
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 128;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BaseConfigHandlerIConnectionPoint.DomainPolicyGetGenericParameterConstraints);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 53;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02a4:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0284:
																				if (8 >= b)
																				{
																					num = 149;
																					while (true)
																					{
																						if (num != 149)
																						{
																							if (num != 1130)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 87:
																								goto IL_0284;
																							case 141:
																								goto IL_0294;
																							case 134:
																								goto IL_02a4;
																							case 136:
																								goto end_IL_02a4;
																							case 53:
																								goto end_IL_02b4;
																							case 65:
																								goto end_IL_02c4;
																							case 59:
																								goto IL_02da;
																							case 46:
																							case 62:
																								goto IL_02e5;
																							case 79:
																								goto IL_02f8;
																							case 83:
																							case 93:
																								goto IL_0303;
																							case 104:
																								goto IL_0348;
																							case 1:
																								goto IL_0353;
																							case 48:
																							case 101:
																								goto IL_036a;
																							case 69:
																								goto IL_037d;
																							case 78:
																								goto IL_038b;
																							case 15:
																							case 95:
																								goto IL_0399;
																							case 38:
																								goto IL_03dd;
																							case 52:
																								goto IL_03f1;
																							case 114:
																								goto IL_0404;
																							case 118:
																								goto IL_0417;
																							case 28:
																								goto IL_042b;
																							case 43:
																							case 123:
																								goto IL_043e;
																							case 129:
																								goto IL_044c;
																							case 107:
																								goto IL_046f;
																							case 16:
																								goto IL_0479;
																							case 31:
																								goto IL_0487;
																							case 131:
																								goto IL_049a;
																							case 139:
																								goto IL_04ad;
																							case 14:
																							case 27:
																								goto IL_04bb;
																							case 91:
																								goto IL_04d2;
																							case 55:
																							case 86:
																								goto IL_04e0;
																							case 41:
																								goto IL_0542;
																							case 49:
																							case 56:
																								goto IL_055e;
																							case 140:
																								goto IL_057a;
																							case 45:
																							case 120:
																								goto IL_05a4;
																							case 88:
																								goto IL_05b2;
																							case 30:
																							case 133:
																								goto IL_05bd;
																							case 10:
																								goto IL_05db;
																							case 22:
																								goto IL_05e9;
																							case 137:
																								goto IL_0605;
																							case 4:
																							case 44:
																								goto IL_0610;
																							case 121:
																								goto IL_061e;
																							case 75:
																							case 126:
																								goto IL_062c;
																							case 50:
																								goto IL_065e;
																							case 89:
																								goto IL_0677;
																							case 68:
																							case 132:
																								goto IL_0682;
																							case 76:
																								goto IL_06c2;
																							case 81:
																								goto IL_06d6;
																							case 34:
																								goto IL_06e9;
																							case 138:
																								goto IL_06f7;
																							case 24:
																							case 82:
																								goto IL_0705;
																							case 9:
																								goto IL_071e;
																							case 130:
																								goto IL_072c;
																							case 98:
																								goto IL_073a;
																							case 5:
																								goto IL_0756;
																							case 116:
																								goto IL_0764;
																							case 110:
																								goto IL_076f;
																							case 54:
																								goto IL_077d;
																							case 73:
																							case 103:
																								goto IL_078b;
																							case 18:
																								goto IL_0799;
																							case 51:
																								goto IL_07b1;
																							case 109:
																								goto IL_07bf;
																							case 63:
																							case 92:
																								goto IL_07d2;
																							case 42:
																								goto IL_0811;
																							case 36:
																								goto IL_082d;
																							case 3:
																								goto IL_0838;
																							case 19:
																							case 80:
																								goto IL_0843;
																							case 7:
																								goto IL_086c;
																							case 142:
																								goto IL_087a;
																							case 17:
																							case 117:
																								goto IL_088a;
																							case 6:
																							case 12:
																							case 20:
																							case 21:
																							case 23:
																							case 26:
																							case 32:
																							case 33:
																							case 39:
																							case 47:
																							case 58:
																							case 60:
																							case 74:
																							case 84:
																							case 90:
																							case 94:
																							case 99:
																							case 100:
																							case 115:
																							case 119:
																							case 122:
																							case 125:
																							case 127:
																							case 135:
																								goto end_IL_0271;
																							case 2:
																							case 8:
																							case 11:
																							case 13:
																							case 35:
																							case 37:
																							case 61:
																							case 67:
																							case 70:
																							case 77:
																							case 85:
																							case 96:
																							case 97:
																							case 102:
																							case 106:
																							case 111:
																							case 112:
																							case 113:
																								goto end_IL_02cf;
																							case 25:
																								goto end_IL_08b2;
																							case 128:
																								goto end_IL_08c5;
																							case 66:
																								goto end_IL_08cf;
																							case 64:
																								goto end_IL_08da;
																							case 29:
																							case 108:
																								goto end_IL_08f3;
																							case 40:
																								goto end_IL_0903;
																							case 57:
																							case 124:
																								goto end_IL_0913;
																							case 71:
																								goto end_IL_0923;
																							case 72:
																								goto end_IL_0933;
																							case 0:
																							case 105:
																								goto IL_094e;
																							}
																							continue;
																						}
																						if (8 > b)
																						{
																							goto IL_05a4;
																						}
																						goto IL_088a;
																						IL_086c:
																						ptr2 += 8;
																						goto IL_087a;
																						IL_088a:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02cf;
																						IL_087a:
																						num5--;
																						goto end_IL_02cf;
																						IL_05a4:
																						if (4 >= b)
																						{
																							goto IL_05b2;
																						}
																						goto IL_0756;
																						IL_05b2:
																						if (4 <= b)
																						{
																							goto IL_05bd;
																						}
																						goto IL_0605;
																						IL_05bd:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_05db;
																						IL_05db:
																						ptr2 += 8;
																						goto IL_05e9;
																						IL_05e9:
																						num5--;
																						num = 85;
																						goto end_IL_02cf;
																						IL_0605:
																						if (2 < b)
																						{
																							goto IL_0610;
																						}
																						goto IL_0677;
																						IL_0610:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_061e;
																						IL_061e:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_062c;
																						IL_062c:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						num = 50;
																						goto IL_065e;
																						IL_065e:
																						array[num5 - 1] = 5;
																						goto end_IL_02cf;
																						IL_0677:
																						if (2 <= b)
																						{
																							goto IL_0682;
																						}
																						goto IL_06e9;
																						IL_0682:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_06c2;
																						IL_06c2:
																						array[num5 - 2] = 0;
																						goto IL_06d6;
																						IL_06d6:
																						num5--;
																						goto end_IL_02cf;
																						IL_06e9:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_06f7;
																						IL_06f7:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0705;
																						IL_0705:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_071e;
																						IL_071e:
																						array[num5] = 0;
																						goto IL_072c;
																						IL_072c:
																						num5++;
																						goto IL_073a;
																						IL_073a:
																						ptr2 += 8;
																						num = 70;
																						goto end_IL_02cf;
																						IL_0756:
																						if (6 >= b)
																						{
																							goto IL_0764;
																						}
																						goto IL_082d;
																						IL_0764:
																						if (6 > b)
																						{
																							goto IL_076f;
																						}
																						goto IL_07d2;
																						IL_076f:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_077d;
																						IL_077d:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_078b;
																						IL_078b:
																						array[num5] = 5;
																						goto IL_0799;
																						IL_0799:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_07b1;
																						IL_07b1:
																						num5++;
																						goto IL_07bf;
																						IL_07bf:
																						ptr2 += 8;
																						goto end_IL_02cf;
																						IL_07d2:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0811;
																						IL_0811:
																						num5 -= 3;
																						num = 111;
																						goto end_IL_02cf;
																						IL_082d:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0838;
																						IL_0838:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0843;
																						IL_0843:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_086c;
																						continue;
																						end_IL_0271:
																						break;
																					}
																					break;
																				}
																				goto IL_02da;
																				IL_037d:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_038b;
																				IL_038b:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0399;
																				IL_02da:
																				if (12 < b)
																				{
																					goto IL_02e5;
																				}
																				goto IL_02f8;
																				IL_02e5:
																				if (14 < b)
																				{
																					goto IL_049a;
																				}
																				goto IL_04ad;
																				IL_04ad:
																				if (14 > b)
																				{
																					goto IL_04bb;
																				}
																				goto IL_055e;
																				IL_04bb:
																				if (13 < b)
																				{
																					break;
																				}
																				num = 91;
																				goto IL_04d2;
																				IL_0399:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_03dd;
																				IL_04d2:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_04e0;
																				IL_04e0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0542;
																				IL_0542:
																				num5 -= 2;
																				num = 96;
																				goto end_IL_02cf;
																				IL_055e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02cf;
																				IL_049a:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_057a;
																				IL_057a:
																				if (15 > b)
																				{
																					num = 74;
																				}
																				break;
																				IL_03dd:
																				array[num5 - 2] = 0;
																				goto IL_03f1;
																				IL_02f8:
																				if (12 <= b)
																				{
																					goto IL_0303;
																				}
																				goto IL_0348;
																				IL_0303:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0417;
																				IL_0417:
																				array[num5 - 2] = 0;
																				goto IL_042b;
																				IL_042b:
																				num5--;
																				goto end_IL_02cf;
																				IL_0348:
																				if (10 >= b)
																				{
																					goto IL_0353;
																				}
																				goto IL_037d;
																				IL_0353:
																				if (10 > b)
																				{
																					num = 101;
																					goto IL_036a;
																				}
																				goto IL_043e;
																				IL_03f1:
																				num5--;
																				goto end_IL_02cf;
																				IL_036a:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0404;
																				IL_0404:
																				if (9 > b)
																				{
																					break;
																				}
																				goto end_IL_02cf;
																				IL_043e:
																				array[num5] = 0;
																				goto IL_044c;
																				IL_044c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_046f;
																				IL_046f:
																				array2[num5] = null;
																				goto IL_0479;
																				IL_0479:
																				num5++;
																				goto IL_0487;
																				IL_0487:
																				ptr2 += 8;
																				goto end_IL_02cf;
																			}
																			break;
																			IL_0294:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02cf;
																	continue;
																	end_IL_02a4:
																	break;
																}
																continue;
																end_IL_02b4:
																break;
															}
															continue;
															end_IL_02c4:
															break;
														}
														continue;
														end_IL_02cf:
														break;
													}
													continue;
												}
												goto IL_094e;
												IL_094e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b2:
												break;
											}
											continue;
											end_IL_08c5:
											break;
										}
										continue;
										end_IL_08cf:
										break;
									}
									continue;
									end_IL_08da:
									break;
								}
								continue;
								end_IL_08f3:
								break;
							}
							continue;
							end_IL_0903:
							break;
						}
						continue;
						end_IL_0913:
						break;
					}
					continue;
					end_IL_0923:
					break;
				}
				continue;
				end_IL_0933:
				break;
			}
		}
	}

	private static Vector3 SingleProducerSingleConsumerQueueGetModuleHandle(Transform transform_0)
	{
		return transform_0.position;
	}

	private static double smethod_9(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static Transform OwnerReaderWriterLockTimedOutException(Component component_0)
	{
		return component_0.transform;
	}

	private unsafe static int smethod_10(int int_0)
	{
		int num = 15;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSiteVoidTaskResult.NonSpacingMarkAppDomainInitializerInfo);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 23;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0290:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0283:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0273:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0263:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0250:
																											if (1 >= b)
																											{
																												num = 19;
																												while (1 <= b)
																												{
																													while (true)
																													{
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_020c:
																															array[num5] = 0;
																															num = 119;
																															while (true)
																															{
																																if (num != 119)
																																{
																																	if (num != 1100)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 60:
																																		goto IL_020c;
																																	case 56:
																																	case 102:
																																		goto end_IL_01f9;
																																	case 19:
																																		goto end_IL_0225;
																																	case 59:
																																	case 69:
																																		goto IL_0250;
																																	case 47:
																																		goto IL_0263;
																																	case 109:
																																		goto IL_0273;
																																	case 110:
																																		goto IL_0283;
																																	case 42:
																																		goto IL_0290;
																																	case 10:
																																		goto IL_02a0;
																																	case 38:
																																		goto IL_02b0;
																																	case 54:
																																		goto end_IL_02b0;
																																	case 27:
																																	case 50:
																																		goto end_IL_02c0;
																																	case 7:
																																	case 62:
																																		goto IL_02db;
																																	case 70:
																																		goto IL_031b;
																																	case 74:
																																		goto IL_0334;
																																	case 48:
																																		goto IL_0342;
																																	case 21:
																																	case 72:
																																		goto IL_0350;
																																	case 91:
																																		goto IL_0379;
																																	case 80:
																																		goto IL_0387;
																																	case 13:
																																	case 105:
																																		goto IL_039a;
																																	case 40:
																																	case 57:
																																		goto IL_03a5;
																																	case 99:
																																		goto IL_03b0;
																																	case 22:
																																		goto IL_03c3;
																																	case 30:
																																		goto IL_03d1;
																																	case 79:
																																		goto IL_03e4;
																																	case 1:
																																	case 85:
																																		goto IL_03f2;
																																	case 49:
																																		goto IL_03fd;
																																	case 24:
																																	case 66:
																																		goto IL_040b;
																																	case 87:
																																		goto IL_044b;
																																	case 36:
																																		goto IL_045f;
																																	case 45:
																																		goto IL_0472;
																																	case 31:
																																		goto IL_0480;
																																	case 41:
																																	case 46:
																																		goto IL_0493;
																																	case 65:
																																		goto IL_04f5;
																																	case 106:
																																		goto IL_0508;
																																	case 51:
																																	case 108:
																																		goto IL_0524;
																																	case 64:
																																	case 112:
																																		goto IL_0540;
																																	case 26:
																																		goto IL_0563;
																																	case 58:
																																		goto IL_0571;
																																	case 96:
																																		goto IL_0588;
																																	case 104:
																																		goto IL_05b2;
																																	case 8:
																																	case 63:
																																		goto IL_05c5;
																																	case 37:
																																		goto IL_05dd;
																																	case 0:
																																	case 6:
																																		goto IL_05eb;
																																	case 3:
																																		goto IL_0602;
																																	case 86:
																																	case 94:
																																		goto IL_060d;
																																	case 11:
																																		goto IL_061b;
																																	case 12:
																																		goto IL_063e;
																																	case 71:
																																		goto IL_0648;
																																	case 89:
																																		goto IL_0656;
																																	case 55:
																																		goto IL_066f;
																																	case 2:
																																	case 16:
																																	case 18:
																																	case 32:
																																	case 43:
																																	case 53:
																																	case 61:
																																	case 67:
																																	case 73:
																																	case 76:
																																	case 77:
																																	case 81:
																																	case 83:
																																	case 84:
																																	case 92:
																																	case 95:
																																	case 97:
																																	case 100:
																																	case 103:
																																	case 107:
																																		goto end_IL_0240;
																																	case 4:
																																	case 5:
																																	case 9:
																																	case 17:
																																	case 23:
																																	case 25:
																																	case 33:
																																	case 34:
																																	case 68:
																																	case 78:
																																	case 82:
																																	case 90:
																																	case 101:
																																	case 111:
																																		goto end_IL_02d0;
																																	case 88:
																																		goto end_IL_068d;
																																	case 44:
																																		goto end_IL_06a0;
																																	case 29:
																																		goto end_IL_06b3;
																																	case 35:
																																		goto end_IL_06be;
																																	case 28:
																																	case 75:
																																		goto end_IL_06d3;
																																	case 20:
																																		goto end_IL_06e3;
																																	case 52:
																																	case 98:
																																		goto end_IL_06f3;
																																	case 14:
																																		goto end_IL_0703;
																																	case 15:
																																		goto end_IL_0713;
																																	case 39:
																																	case 93:
																																		goto IL_072e;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_05b2;
																																IL_05b2:
																																ptr2 += 8;
																																goto end_IL_02d0;
																																continue;
																																end_IL_01f9:
																																break;
																															}
																															break;
																														}
																														continue;
																														end_IL_0225:
																														break;
																													}
																													continue;
																													end_IL_0240:
																													break;
																												}
																												break;
																											}
																											goto IL_0334;
																											IL_0379:
																											ptr2 += 8;
																											goto IL_0387;
																											IL_0387:
																											num5--;
																											goto end_IL_02d0;
																											IL_0334:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0342;
																											IL_0342:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0350;
																											IL_0350:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0379;
																										}
																										break;
																									}
																									goto IL_05c5;
																									IL_05c5:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02d0;
																								}
																								break;
																							}
																							goto IL_05dd;
																							IL_0656:
																							ptr2 += 8;
																							num = 5;
																							goto end_IL_02d0;
																							IL_05dd:
																							if (4 < b)
																							{
																								goto IL_05eb;
																							}
																							goto IL_066f;
																							IL_05eb:
																							if (5 < b)
																							{
																								break;
																							}
																							num = 3;
																							goto IL_0602;
																							IL_066f:
																							if (4 <= b)
																							{
																								goto end_IL_02d0;
																							}
																							break;
																							IL_0602:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_060d;
																							IL_060d:
																							array[num5] = 0;
																							goto IL_061b;
																							IL_061b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_063e;
																							IL_063e:
																							array2[num5] = null;
																							goto IL_0648;
																							IL_0648:
																							num5++;
																							goto IL_0656;
																						}
																						break;
																					}
																					goto IL_02db;
																					IL_0508:
																					num5--;
																					num = 25;
																					goto end_IL_02d0;
																					IL_02db:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_031b;
																					IL_031b:
																					array[num5 - 2] = 0;
																					goto IL_0508;
																				}
																				break;
																			}
																			goto IL_039a;
																			IL_04f5:
																			num5 -= 2;
																			goto end_IL_02d0;
																			IL_039a:
																			if (9 < b)
																			{
																				goto IL_03a5;
																			}
																			goto IL_03e4;
																			IL_03a5:
																			if (10 >= b)
																			{
																				goto IL_03b0;
																			}
																			goto IL_03c3;
																			IL_03b0:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0524;
																			IL_0524:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d0;
																			IL_03c3:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03d1;
																			IL_03d1:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_03e4:
																			if (9 > b)
																			{
																				goto IL_03f2;
																			}
																			goto IL_0493;
																			IL_03f2:
																			if (7 >= b)
																			{
																				goto IL_03fd;
																			}
																			goto IL_0472;
																			IL_03fd:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_040b;
																			IL_040b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_044b;
																			IL_044b:
																			array[num5 - 2] = 0;
																			goto IL_045f;
																			IL_045f:
																			num5--;
																			goto end_IL_02d0;
																			IL_0472:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0480;
																			IL_0480:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0540;
																			IL_0540:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0563;
																			IL_0563:
																			array[num5] = 0;
																			goto IL_0571;
																			IL_0571:
																			num5++;
																			num = 96;
																			goto IL_0588;
																			IL_0588:
																			ptr2 += 8;
																			num = 111;
																			goto end_IL_02d0;
																			IL_0493:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04f5;
																		}
																		break;
																		IL_02a0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d0;
																continue;
																end_IL_02b0:
																break;
															}
															continue;
															end_IL_02c0:
															break;
														}
														continue;
														end_IL_02d0:
														break;
													}
													continue;
												}
												goto IL_072e;
												IL_072e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068d:
												break;
											}
											continue;
											end_IL_06a0:
											break;
										}
										continue;
										end_IL_06b3:
										break;
									}
									continue;
									end_IL_06be:
									break;
								}
								continue;
								end_IL_06d3:
								break;
							}
							continue;
							end_IL_06e3:
							break;
						}
						continue;
						end_IL_06f3:
						break;
					}
					continue;
					end_IL_0703:
					break;
				}
				continue;
				end_IL_0713:
				break;
			}
		}
	}

	private static GTPlayer DisableEventsAssemblyInformationalVersionAttribute()
	{
		return GTPlayer.Instance;
	}

	private static NetworkView METHODSTOSKIPSend(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.myVRRig;
	}

	private unsafe static int smethod_11(int int_0, int int_1)
	{
		int num = 67;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCharUnknownHighGetSubKeyNames.getIsSystemgetYear);
											num = 53;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 33;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01e1:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				num = 8;
																				while (true)
																				{
																					IL_01bb:
																					if (4 < b)
																					{
																						num = 96;
																						while (true)
																						{
																							if (num != 96)
																							{
																								if (num != 1077)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 8:
																									goto IL_01bb;
																								case 85:
																									goto IL_01ce;
																								case 1:
																									goto IL_01e1;
																								case 61:
																									goto end_IL_01e1;
																								case 33:
																									goto end_IL_01f1;
																								case 24:
																									goto end_IL_0201;
																								case 88:
																									goto IL_0217;
																								case 73:
																									goto IL_0222;
																								case 7:
																								case 63:
																									goto IL_0230;
																								case 43:
																									goto IL_023e;
																								case 37:
																								case 41:
																									goto IL_024c;
																								case 4:
																									goto IL_0264;
																								case 46:
																									goto IL_026f;
																								case 29:
																								case 30:
																									goto IL_027d;
																								case 56:
																									goto IL_028b;
																								case 77:
																									goto IL_02ae;
																								case 60:
																									goto IL_02b8;
																								case 19:
																									goto IL_02c6;
																								case 26:
																									goto IL_02d9;
																								case 81:
																									goto IL_02e7;
																								case 36:
																								case 47:
																									goto IL_02f5;
																								case 51:
																									goto IL_0311;
																								case 16:
																									goto IL_031f;
																								case 42:
																									goto IL_032d;
																								case 6:
																								case 62:
																									goto IL_0338;
																								case 71:
																									goto IL_0346;
																								case 3:
																								case 68:
																									goto IL_0359;
																								case 40:
																									goto IL_03c7;
																								case 15:
																								case 54:
																									goto IL_03da;
																								case 76:
																									goto IL_03e8;
																								case 49:
																								case 82:
																									goto IL_03f6;
																								case 35:
																									goto IL_043f;
																								case 74:
																									goto IL_0453;
																								case 13:
																								case 57:
																									goto IL_046f;
																								case 87:
																									goto IL_0498;
																								case 65:
																									goto IL_04a6;
																								case 10:
																								case 11:
																								case 14:
																								case 21:
																								case 22:
																								case 25:
																								case 27:
																								case 31:
																								case 34:
																								case 39:
																								case 45:
																								case 52:
																								case 69:
																								case 70:
																								case 78:
																								case 79:
																								case 86:
																									goto end_IL_01ab;
																								case 2:
																									goto IL_04d9;
																								case 32:
																									goto IL_04f0;
																								case 12:
																									goto IL_04fe;
																								case 0:
																								case 5:
																								case 20:
																								case 44:
																								case 48:
																								case 55:
																								case 64:
																								case 72:
																								case 80:
																								case 84:
																								case 89:
																									goto end_IL_020c;
																								case 53:
																									goto end_IL_050c;
																								case 17:
																									goto end_IL_051f;
																								case 28:
																									goto end_IL_0529;
																								case 83:
																									goto end_IL_053d;
																								case 38:
																									goto end_IL_0552;
																								case 9:
																								case 75:
																									goto end_IL_0567;
																								case 59:
																									goto end_IL_0577;
																								case 18:
																								case 50:
																									goto end_IL_0587;
																								case 66:
																									goto end_IL_0597;
																								case 67:
																									goto end_IL_05a7;
																								case 23:
																								case 58:
																									goto IL_05c2;
																								}
																								continue;
																							}
																							goto IL_0217;
																							IL_02e7:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_02f5;
																							IL_02f5:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_020c;
																							IL_0217:
																							if (6 >= b)
																							{
																								goto IL_0222;
																							}
																							goto IL_0264;
																							IL_0222:
																							if (6 <= b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_0230;
																							IL_0230:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_023e;
																							IL_023e:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_024c;
																							IL_024c:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_020c;
																							IL_0264:
																							if (7 >= b)
																							{
																								goto IL_026f;
																							}
																							goto IL_02d9;
																							IL_026f:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_027d;
																							IL_027d:
																							array[num6] = 0;
																							goto IL_028b;
																							IL_028b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_02ae;
																							IL_02ae:
																							array2[num6] = null;
																							goto IL_02b8;
																							IL_02b8:
																							num6++;
																							goto IL_02c6;
																							IL_02c6:
																							ptr2 += 8;
																							goto end_IL_020c;
																							IL_02d9:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_02e7;
																							continue;
																							end_IL_01ab:
																							break;
																						}
																						break;
																					}
																					goto IL_0311;
																					IL_0498:
																					ptr2 += 8;
																					goto IL_04a6;
																					IL_04a6:
																					num6--;
																					goto end_IL_020c;
																					IL_0311:
																					if (4 > b)
																					{
																						goto IL_031f;
																					}
																					goto IL_046f;
																					IL_031f:
																					if (2 >= b)
																					{
																						goto IL_032d;
																					}
																					goto IL_03da;
																					IL_032d:
																					if (2 > b)
																					{
																						goto IL_0338;
																					}
																					goto IL_0359;
																					IL_0338:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0346;
																					IL_0346:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_0359:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03c7;
																					IL_03c7:
																					num6 -= 2;
																					goto end_IL_020c;
																					IL_03da:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_03e8;
																					IL_03e8:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_03f6;
																					IL_03f6:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 35;
																					goto IL_043f;
																					IL_043f:
																					array[num6 - 2] = 0;
																					goto IL_0453;
																					IL_0453:
																					num6--;
																					num = 64;
																					goto end_IL_020c;
																					IL_046f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0498;
																				}
																				break;
																				IL_01ce:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04d9;
																		IL_04fe:
																		ptr2 += 8;
																		goto end_IL_020c;
																		IL_04f0:
																		num6++;
																		goto IL_04fe;
																		IL_04d9:
																		array[num6] = 0;
																		num = 32;
																		goto IL_04f0;
																		continue;
																		end_IL_01e1:
																		break;
																	}
																	continue;
																	end_IL_01f1:
																	break;
																}
																continue;
																end_IL_0201:
																break;
															}
															continue;
															end_IL_020c:
															break;
														}
														continue;
													}
													goto IL_05c2;
													IL_05c2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_050c:
													break;
												}
												continue;
												end_IL_051f:
												break;
											}
											continue;
											end_IL_0529:
											break;
										}
										continue;
										end_IL_053d:
										break;
									}
									continue;
									end_IL_0552:
									break;
								}
								continue;
								end_IL_0567:
								break;
							}
							continue;
							end_IL_0577:
							break;
						}
						continue;
						end_IL_0587:
						break;
					}
					continue;
					end_IL_0597:
					break;
				}
				continue;
				end_IL_05a7:
				break;
			}
		}
	}
}
