using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gadget Hollow Sphere Large", "Super Infection/Casual [MASTERCLIENT]", "Spawns large hollow sphere.", true, 25, ModType.const_1, false)]
internal class Class114 : MonoBehaviour
{
	private static int int_0;

	private static int int_1;

	private static int int_2;

	private static float float_0;

	private static double double_0;

	private static Vector3 ICustomMarshalerIsCompatibilitySwitchSet;

	private static Quaternion UpgradeToWriterLockIsAutoLayout;

	private static GameEntityCreateData getIsSerializableRSACryptoServiceProvider;

	private static IntPtr[] ReleaseSharedStringMakerBeginCriticalRegion;

	private static IntPtr[] URIMax;

	private unsafe void OnEnable()
	{
		int num = 531;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								int[] array4 = new int[9];
								while (true)
								{
									long[] array5 = new long[3];
									while (true)
									{
										object[] array6 = new object[9];
										while (true)
										{
											array6[0] = this;
											while (true)
											{
												array6[1] = ICustomMarshalerIsCompatibilitySwitchSet;
												while (true)
												{
													array6[5] = ICustomMarshalerIsCompatibilitySwitchSet;
													while (true)
													{
														array6[6] = UpgradeToWriterLockIsAutoLayout;
														while (true)
														{
															array6[7] = ICustomMarshalerIsCompatibilitySwitchSet;
															while (true)
															{
																array6[8] = getIsSerializableRSACryptoServiceProvider;
																while (true)
																{
																	byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setAssemblyEvidenceASCIIEncoding.IsFamilyOrAssemblyMidpointRounding);
																	while (true)
																	{
																		byte* ptr2 = ptr;
																		while (true)
																		{
																			if (num4 == 1)
																			{
																				return;
																			}
																			while (true)
																			{
																				byte b = *ptr2;
																				while (true)
																				{
																					ptr2++;
																					while (true)
																					{
																						IL_0995:
																						if (b >= 1)
																						{
																							while (b <= 66)
																							{
																								while (true)
																								{
																									IL_0978:
																									if (33 < b)
																									{
																										while (true)
																										{
																											IL_096b:
																											if (50 < b)
																											{
																												while (true)
																												{
																													IL_095b:
																													if (58 >= b)
																													{
																														while (true)
																														{
																															IL_094b:
																															if (58 > b)
																															{
																																while (true)
																																{
																																	IL_093b:
																																	if (54 < b)
																																	{
																																		while (true)
																																		{
																																			IL_092b:
																																			if (56 < b)
																																			{
																																				while (57 >= b)
																																				{
																																					while (57 <= b)
																																					{
																																						num = 566;
																																						while (true)
																																						{
																																							if (num != 566)
																																							{
																																								if (num != 1547)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 510:
																																									goto IL_0908;
																																								case 472:
																																									goto IL_091b;
																																								case 468:
																																									goto IL_092b;
																																								case 70:
																																									goto IL_093b;
																																								case 526:
																																									goto IL_094b;
																																								case 234:
																																									goto IL_095b;
																																								case 271:
																																									goto IL_096b;
																																								case 300:
																																									goto IL_0978;
																																								case 513:
																																									goto IL_0985;
																																								case 153:
																																									goto IL_0995;
																																								case 411:
																																									goto end_IL_0995;
																																								case 221:
																																								case 470:
																																									goto end_IL_09a5;
																																								case 10:
																																									goto IL_09c0;
																																								case 30:
																																									goto IL_09d3;
																																								case 132:
																																									goto IL_09e6;
																																								case 273:
																																								case 354:
																																									goto IL_09f1;
																																								case 376:
																																									goto IL_0a14;
																																								case 7:
																																									goto IL_0a22;
																																								case 227:
																																									goto IL_0a30;
																																								case 176:
																																								case 237:
																																									goto IL_0a3b;
																																								case 47:
																																									goto IL_0a4f;
																																								case 44:
																																									goto IL_0a8c;
																																								case 158:
																																									goto IL_0a9f;
																																								case 251:
																																									goto IL_0aaa;
																																								case 212:
																																									goto IL_0ab5;
																																								case 136:
																																									goto IL_0ac3;
																																								case 215:
																																									goto IL_0ad1;
																																								case 209:
																																								case 290:
																																									goto IL_0af6;
																																								case 15:
																																									goto IL_0b0b;
																																								case 102:
																																									goto IL_0b1e;
																																								case 363:
																																									goto IL_0b2c;
																																								case 57:
																																									goto IL_0b37;
																																								case 275:
																																									goto IL_0b45;
																																								case 37:
																																								case 210:
																																									goto IL_0b58;
																																								case 78:
																																									goto IL_0b99;
																																								case 62:
																																									goto IL_0bad;
																																								case 129:
																																									goto IL_0bc0;
																																								case 148:
																																									goto IL_0bce;
																																								case 262:
																																									goto IL_0be1;
																																								case 39:
																																									goto IL_0bec;
																																								case 395:
																																									goto IL_0c1b;
																																								case 249:
																																									goto IL_0c26;
																																								case 34:
																																								case 172:
																																									goto IL_0c34;
																																								case 365:
																																									goto IL_0c42;
																																								case 95:
																																									goto IL_0c5b;
																																								case 223:
																																									goto IL_0c7a;
																																								case 274:
																																									goto IL_0c8a;
																																								case 397:
																																									goto IL_0c9d;
																																								case 398:
																																									goto IL_0cb0;
																																								case 1:
																																								case 64:
																																									goto IL_0cbb;
																																								case 131:
																																									goto IL_0ce4;
																																								case 323:
																																									goto IL_0d00;
																																								case 406:
																																									goto IL_0d13;
																																								case 8:
																																								case 378:
																																									goto IL_0d21;
																																								case 239:
																																									goto IL_0d3b;
																																								case 69:
																																									goto IL_0d49;
																																								case 267:
																																									goto IL_0d57;
																																								case 423:
																																									goto IL_0d6a;
																																								case 259:
																																								case 371:
																																									goto IL_0d75;
																																								case 370:
																																									goto IL_0d83;
																																								case 140:
																																									goto IL_0da5;
																																								case 292:
																																									goto IL_0db3;
																																								case 240:
																																									goto IL_0dc6;
																																								case 17:
																																									goto IL_0dd4;
																																								case 279:
																																								case 426:
																																									goto IL_0de7;
																																								case 186:
																																									goto IL_0e47;
																																								case 430:
																																									goto IL_0e5a;
																																								case 375:
																																									goto IL_0e71;
																																								case 169:
																																								case 407:
																																									goto IL_0e88;
																																								case 166:
																																									goto IL_0eb9;
																																								case 435:
																																									goto IL_0ecc;
																																								case 325:
																																									goto IL_0eda;
																																								case 42:
																																								case 429:
																																									goto IL_0ee8;
																																								case 348:
																																									goto IL_0ef6;
																																								case 450:
																																									goto IL_0f0e;
																																								case 356:
																																								case 451:
																																									goto IL_0f21;
																																								case 141:
																																									goto IL_0f2f;
																																								case 160:
																																									goto IL_0f4d;
																																								case 199:
																																									goto IL_0f5b;
																																								case 455:
																																									goto IL_0f6e;
																																								case 459:
																																									goto IL_0f81;
																																								case 128:
																																								case 380:
																																									goto IL_0f8f;
																																								case 211:
																																									goto IL_0fdb;
																																								case 474:
																																									goto IL_0fee;
																																								case 424:
																																								case 432:
																																									goto IL_0ff9;
																																								case 171:
																																									goto IL_1057;
																																								case 133:
																																									goto IL_106a;
																																								case 203:
																																									goto IL_1078;
																																								case 79:
																																									goto IL_1086;
																																								case 109:
																																								case 123:
																																									goto IL_1091;
																																								case 330:
																																									goto IL_109f;
																																								case 399:
																																									goto IL_10c3;
																																								case 193:
																																									goto IL_10d1;
																																								case 350:
																																									goto IL_10e4;
																																								case 92:
																																									goto IL_10f2;
																																								case 5:
																																								case 222:
																																									goto IL_10fd;
																																								case 11:
																																									goto IL_115f;
																																								case 122:
																																									goto IL_1172;
																																								case 460:
																																									goto IL_1180;
																																								case 112:
																																								case 135:
																																									goto IL_118e;
																																								case 438:
																																									goto IL_11ce;
																																								case 14:
																																									goto IL_11e7;
																																								case 46:
																																									goto IL_11f2;
																																								case 392:
																																								case 410:
																																									goto IL_11fd;
																																								case 117:
																																									goto IL_120b;
																																								case 400:
																																									goto IL_122f;
																																								case 458:
																																									goto IL_123d;
																																								case 198:
																																									goto IL_1250;
																																								case 125:
																																									goto IL_1263;
																																								case 441:
																																									goto IL_1271;
																																								case 134:
																																								case 329:
																																									goto IL_127f;
																																								case 103:
																																									goto IL_128d;
																																								case 154:
																																									goto IL_12b1;
																																								case 248:
																																									goto IL_12bf;
																																								case 344:
																																									goto IL_12db;
																																								case 187:
																																								case 416:
																																									goto IL_12e6;
																																								case 319:
																																									goto IL_12f9;
																																								case 322:
																																									goto IL_1304;
																																								case 180:
																																									goto IL_1320;
																																								case 431:
																																									goto IL_132e;
																																								case 317:
																																									goto IL_133c;
																																								case 49:
																																								case 71:
																																									goto IL_134a;
																																								case 419:
																																									goto IL_138a;
																																								case 254:
																																									goto IL_139e;
																																								case 207:
																																								case 479:
																																									goto IL_13b1;
																																								case 201:
																																									goto IL_13dc;
																																								case 195:
																																								case 485:
																																									goto IL_13f5;
																																								case 381:
																																									goto IL_1403;
																																								case 464:
																																									goto IL_1426;
																																								case 98:
																																									goto IL_1430;
																																								case 113:
																																									goto IL_143e;
																																								case 65:
																																								case 487:
																																									goto IL_1451;
																																								case 205:
																																									goto IL_1465;
																																								case 29:
																																									goto IL_149d;
																																								case 490:
																																									goto IL_14b0;
																																								case 41:
																																								case 293:
																																									goto IL_14bb;
																																								case 343:
																																									goto IL_14d4;
																																								case 480:
																																									goto IL_14e2;
																																								case 185:
																																								case 265:
																																									goto IL_14f0;
																																								case 433:
																																									goto IL_1504;
																																								case 229:
																																									goto IL_155f;
																																								case 421:
																																									goto IL_156d;
																																								case 494:
																																									goto IL_1580;
																																								case 495:
																																									goto IL_1593;
																																								case 402:
																																									goto IL_15a1;
																																								case 303:
																																									goto IL_15b8;
																																								case 16:
																																								case 461:
																																									goto IL_15c6;
																																								case 409:
																																									goto IL_15da;
																																								case 143:
																																									goto IL_1617;
																																								case 463:
																																									goto IL_162a;
																																								case 497:
																																									goto IL_163d;
																																								case 82:
																																									goto IL_164b;
																																								case 86:
																																								case 299:
																																									goto IL_1656;
																																								case 384:
																																									goto IL_1664;
																																								case 305:
																																									goto IL_167c;
																																								case 146:
																																									goto IL_168a;
																																								case 442:
																																									goto IL_169d;
																																								case 437:
																																									goto IL_16ab;
																																								case 50:
																																									goto IL_16b9;
																																								case 111:
																																									goto IL_16c7;
																																								case 87:
																																									goto IL_16d2;
																																								case 258:
																																									goto IL_16e0;
																																								case 352:
																																								case 452:
																																									goto IL_16ee;
																																								case 373:
																																									goto IL_170c;
																																								case 218:
																																									goto IL_171a;
																																								case 60:
																																									goto IL_1731;
																																								case 233:
																																								case 389:
																																									goto IL_1744;
																																								case 332:
																																									goto IL_1762;
																																								case 28:
																																									goto IL_1770;
																																								case 448:
																																									goto IL_1783;
																																								case 276:
																																									goto IL_179a;
																																								case 142:
																																								case 228:
																																									goto IL_17a8;
																																								case 333:
																																								case 486:
																																									goto IL_17c9;
																																								case 386:
																																									goto IL_17dc;
																																								case 328:
																																									goto IL_17ef;
																																								case 55:
																																									goto IL_17fd;
																																								case 96:
																																									goto IL_1808;
																																								case 118:
																																								case 422:
																																									goto IL_1813;
																																								case 177:
																																									goto IL_1821;
																																								case 391:
																																									goto IL_183a;
																																								case 304:
																																									goto IL_1859;
																																								case 320:
																																									goto IL_186c;
																																								case 313:
																																									goto IL_187f;
																																								case 369:
																																									goto IL_188d;
																																								case 282:
																																									goto IL_189b;
																																								case 167:
																																								case 178:
																																									goto IL_18a9;
																																								case 144:
																																									goto IL_18bd;
																																								case 84:
																																									goto IL_1908;
																																								case 130:
																																								case 349:
																																									goto IL_1913;
																																								case 382:
																																									goto IL_1926;
																																								case 12:
																																									goto IL_1931;
																																								case 189:
																																									goto IL_193f;
																																								case 152:
																																								case 417:
																																									goto IL_194d;
																																								case 83:
																																									goto IL_195b;
																																								case 252:
																																									goto IL_1986;
																																								case 213:
																																									goto IL_1994;
																																								case 454:
																																									goto IL_19a7;
																																								case 261:
																																								case 338:
																																									goto IL_19b5;
																																								case 505:
																																									goto IL_19ce;
																																								case 89:
																																								case 506:
																																									goto IL_19e1;
																																								case 508:
																																									goto IL_19fd;
																																								case 372:
																																									goto IL_1a0b;
																																								case 335:
																																									goto IL_1a19;
																																								case 6:
																																								case 250:
																																									goto IL_1a27;
																																								case 204:
																																									goto IL_1a60;
																																								case 482:
																																									goto IL_1a7d;
																																								case 54:
																																								case 443:
																																									goto IL_1a99;
																																								case 219:
																																									goto IL_1ab7;
																																								case 192:
																																									goto IL_1ace;
																																								case 509:
																																									goto IL_1ae1;
																																								case 359:
																																									goto IL_1af9;
																																								case 260:
																																									goto IL_1b07;
																																								case 511:
																																									goto IL_1b23;
																																								case 316:
																																									goto IL_1b3a;
																																								case 257:
																																								case 347:
																																									goto end_IL_08f5;
																																								case 277:
																																									goto IL_1b66;
																																								case 297:
																																									goto IL_1b74;
																																								case 512:
																																									goto IL_1b87;
																																								case 414:
																																									goto IL_1b92;
																																								case 31:
																																									goto IL_1b9d;
																																								case 302:
																																									goto IL_1bab;
																																								case 116:
																																								case 138:
																																									goto IL_1bb9;
																																								case 236:
																																									goto IL_1be5;
																																								case 413:
																																									goto IL_1bf3;
																																								case 514:
																																									goto IL_1c06;
																																								case 48:
																																									goto IL_1c29;
																																								case 51:
																																									goto IL_1c37;
																																								case 517:
																																									goto IL_1c4a;
																																								case 268:
																																									goto IL_1c58;
																																								case 518:
																																									goto IL_1c6b;
																																								case 0:
																																									goto IL_1c79;
																																								case 67:
																																									goto IL_1c87;
																																								case 519:
																																									goto IL_1c9a;
																																								case 163:
																																								case 387:
																																									goto IL_1ca8;
																																								case 520:
																																									goto IL_1cc1;
																																								case 85:
																																									goto IL_1d13;
																																								case 288:
																																									goto IL_1d21;
																																								case 521:
																																									goto IL_1d34;
																																								case 396:
																																								case 522:
																																									goto IL_1d50;
																																								case 523:
																																									goto IL_1d7d;
																																								case 165:
																																								case 289:
																																									goto IL_1d88;
																																								case 379:
																																									goto IL_1dc8;
																																								case 94:
																																									goto IL_1ddc;
																																								case 59:
																																									goto IL_1def;
																																								case 503:
																																									goto IL_1dfd;
																																								case 326:
																																								case 449:
																																									goto IL_1e0b;
																																								case 168:
																																									goto IL_1e4b;
																																								case 93:
																																									goto IL_1e5f;
																																								case 232:
																																								case 532:
																																									goto IL_1e7b;
																																								case 310:
																																									goto IL_1e8f;
																																								case 516:
																																									goto IL_1ed0;
																																								case 533:
																																									goto IL_1ee3;
																																								case 100:
																																									goto IL_1ef1;
																																								case 76:
																																								case 500:
																																									goto IL_1f08;
																																								case 466:
																																									goto IL_1f16;
																																								case 484:
																																									goto IL_1f34;
																																								case 469:
																																									goto IL_1f42;
																																								case 528:
																																								case 536:
																																									goto IL_1f55;
																																								case 77:
																																									goto IL_1f87;
																																								case 53:
																																									goto IL_1f95;
																																								case 538:
																																									goto IL_1fa8;
																																								case 539:
																																									goto IL_1fc4;
																																								case 425:
																																									goto IL_1fd2;
																																								case 540:
																																									goto IL_1fee;
																																								case 542:
																																									goto IL_2062;
																																								case 543:
																																									goto IL_2075;
																																								case 368:
																																								case 403:
																																									goto IL_2083;
																																								case 170:
																																									goto IL_20d5;
																																								case 544:
																																									goto IL_20e8;
																																								case 546:
																																									goto IL_2104;
																																								case 355:
																																									goto IL_2112;
																																								case 214:
																																								case 377:
																																									goto IL_2120;
																																								case 440:
																																									goto IL_213d;
																																								case 243:
																																									goto IL_218f;
																																								case 341:
																																									goto IL_219d;
																																								case 547:
																																									goto IL_21b0;
																																								case 90:
																																									goto IL_2201;
																																								case 548:
																																									goto IL_220f;
																																								case 549:
																																									goto IL_2222;
																																								case 24:
																																								case 550:
																																									goto IL_2235;
																																								case 504:
																																									goto IL_224d;
																																								case 404:
																																									goto IL_225b;
																																								case 263:
																																									goto IL_2269;
																																								case 551:
																																									goto IL_227c;
																																								case 106:
																																									goto IL_228a;
																																								case 552:
																																									goto IL_229d;
																																								case 535:
																																								case 553:
																																									goto IL_22b0;
																																								case 366:
																																									goto IL_22c4;
																																								case 3:
																																									goto IL_2315;
																																								case 499:
																																									goto IL_2323;
																																								case 220:
																																								case 554:
																																									goto IL_2336;
																																								case 357:
																																									goto IL_2376;
																																								case 307:
																																									goto IL_238a;
																																								case 20:
																																								case 556:
																																									goto IL_239d;
																																								case 202:
																																									goto IL_23fc;
																																								case 557:
																																									goto IL_240f;
																																								case 559:
																																									goto IL_2422;
																																								case 462:
																																									goto IL_2430;
																																								case 81:
																																								case 126:
																																									goto IL_243e;
																																								case 150:
																																									goto IL_244c;
																																								case 324:
																																									goto IL_246a;
																																								case 353:
																																									goto IL_2478;
																																								case 388:
																																									goto IL_248b;
																																								case 351:
																																									goto IL_24ea;
																																								case 120:
																																									goto IL_24fd;
																																								case 476:
																																									goto IL_250b;
																																								case 393:
																																								case 558:
																																									goto IL_2516;
																																								case 175:
																																									goto IL_2540;
																																								case 284:
																																									goto IL_2559;
																																								case 200:
																																									goto IL_2567;
																																								case 159:
																																								case 336:
																																									goto IL_2572;
																																								case 157:
																																									goto IL_2580;
																																								case 231:
																																									goto IL_25a2;
																																								case 247:
																																									goto IL_25b0;
																																								case 394:
																																									goto IL_25c3;
																																								case 478:
																																									goto IL_25d1;
																																								case 38:
																																								case 197:
																																									goto IL_25df;
																																								case 174:
																																									goto IL_263f;
																																								case 360:
																																									goto IL_2652;
																																								case 447:
																																									goto IL_2660;
																																								case 58:
																																								case 465:
																																									goto IL_266e;
																																								case 114:
																																									goto IL_26ab;
																																								case 281:
																																									goto IL_26b9;
																																								case 242:
																																									goto IL_26cc;
																																								case 362:
																																									goto IL_26da;
																																								case 13:
																																								case 477:
																																									goto IL_26e5;
																																								case 434:
																																									goto IL_26ef;
																																								case 496:
																																									goto IL_26fd;
																																								case 492:
																																									goto IL_2710;
																																								case 483:
																																									goto IL_271e;
																																								case 238:
																																								case 311:
																																									goto IL_272c;
																																								case 278:
																																									goto IL_2757;
																																								case 314:
																																									goto IL_2770;
																																								case 428:
																																									goto IL_277b;
																																								case 467:
																																								case 527:
																																									goto IL_2789;
																																								case 27:
																																									goto IL_27d6;
																																								case 315:
																																									goto IL_27e4;
																																								case 285:
																																									goto IL_27f4;
																																								case 235:
																																									goto IL_27ff;
																																								case 4:
																																								case 18:
																																								case 19:
																																								case 26:
																																								case 32:
																																								case 33:
																																								case 35:
																																								case 36:
																																								case 40:
																																								case 45:
																																								case 52:
																																								case 56:
																																								case 68:
																																								case 72:
																																								case 104:
																																								case 107:
																																								case 121:
																																								case 124:
																																								case 147:
																																								case 156:
																																								case 164:
																																								case 181:
																																								case 182:
																																								case 183:
																																								case 188:
																																								case 190:
																																								case 191:
																																								case 194:
																																								case 196:
																																								case 217:
																																								case 224:
																																								case 226:
																																								case 230:
																																								case 269:
																																								case 270:
																																								case 283:
																																								case 286:
																																								case 291:
																																								case 306:
																																								case 312:
																																								case 321:
																																								case 334:
																																								case 339:
																																								case 340:
																																								case 345:
																																								case 346:
																																								case 358:
																																								case 361:
																																								case 364:
																																								case 390:
																																								case 408:
																																								case 412:
																																								case 418:
																																								case 436:
																																								case 439:
																																								case 445:
																																								case 446:
																																								case 456:
																																								case 471:
																																								case 473:
																																								case 481:
																																								case 489:
																																								case 493:
																																								case 498:
																																								case 524:
																																								case 529:
																																								case 534:
																																								case 541:
																																								case 555:
																																									goto end_IL_0908;
																																								case 2:
																																								case 9:
																																								case 21:
																																								case 22:
																																								case 23:
																																								case 25:
																																								case 63:
																																								case 66:
																																								case 73:
																																								case 75:
																																								case 80:
																																								case 91:
																																								case 97:
																																								case 99:
																																								case 105:
																																								case 108:
																																								case 110:
																																								case 115:
																																								case 119:
																																								case 127:
																																								case 139:
																																								case 145:
																																								case 149:
																																								case 151:
																																								case 155:
																																								case 173:
																																								case 179:
																																								case 184:
																																								case 206:
																																								case 208:
																																								case 225:
																																								case 244:
																																								case 245:
																																								case 246:
																																								case 253:
																																								case 255:
																																								case 256:
																																								case 264:
																																								case 272:
																																								case 294:
																																								case 295:
																																								case 296:
																																								case 298:
																																								case 301:
																																								case 308:
																																								case 309:
																																								case 318:
																																								case 327:
																																								case 331:
																																								case 342:
																																								case 367:
																																								case 374:
																																								case 383:
																																								case 385:
																																								case 401:
																																								case 405:
																																								case 420:
																																								case 427:
																																								case 453:
																																								case 457:
																																								case 475:
																																								case 488:
																																								case 491:
																																								case 501:
																																								case 502:
																																								case 515:
																																								case 525:
																																								case 537:
																																								case 545:
																																									goto end_IL_09b5;
																																								case 161:
																																									goto end_IL_281d;
																																								case 162:
																																									goto end_IL_2830;
																																								case 444:
																																									goto end_IL_283a;
																																								case 61:
																																									goto end_IL_2845;
																																								case 137:
																																									goto end_IL_285b;
																																								case 74:
																																									goto end_IL_2871;
																																								case 43:
																																									goto end_IL_2887;
																																								case 88:
																																									goto end_IL_289d;
																																								case 101:
																																									goto end_IL_28b3;
																																								case 280:
																																									goto end_IL_28c3;
																																								case 507:
																																									goto end_IL_28d3;
																																								case 266:
																																									goto end_IL_28e3;
																																								case 415:
																																									goto end_IL_28f3;
																																								case 241:
																																								case 337:
																																									goto end_IL_2903;
																																								case 530:
																																									goto end_IL_2913;
																																								case 531:
																																									goto end_IL_2923;
																																								case 216:
																																								case 287:
																																									return;
																																								}
																																								continue;
																																							}
																																							goto IL_248b;
																																							IL_248b:
																																							((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).rotation = (Quaternion)array2[num5 - 1];
																																							goto IL_24ea;
																																							IL_24ea:
																																							num5 -= 2;
																																							goto end_IL_09b5;
																																							continue;
																																							end_IL_08f5:
																																							break;
																																						}
																																						goto IL_1b48;
																																						continue;
																																						end_IL_0908:
																																						break;
																																						IL_0908:;
																																					}
																																					break;
																																					IL_091b:;
																																				}
																																				break;
																																			}
																																			goto IL_0d6a;
																																			IL_23fc:
																																			num5 -= 2;
																																			goto end_IL_09b5;
																																			IL_0d6a:
																																			if (56 <= b)
																																			{
																																				goto IL_0d75;
																																			}
																																			goto IL_0dc6;
																																			IL_0d75:
																																			array[num5] = 4;
																																			goto IL_0d83;
																																			IL_0d83:
																																			array2[num5] = (Quaternion)array6[*(int*)(ptr2 + num3)];
																																			goto IL_0da5;
																																			IL_0da5:
																																			num5++;
																																			goto IL_0db3;
																																			IL_0db3:
																																			ptr2 += 8;
																																			goto end_IL_09b5;
																																			IL_0dc6:
																																			if (55 < b)
																																			{
																																				break;
																																			}
																																			goto IL_0dd4;
																																			IL_0dd4:
																																			if (55 > b)
																																			{
																																				break;
																																			}
																																			goto IL_239d;
																																			IL_239d:
																																			((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).position = (Vector3)array2[num5 - 1];
																																			goto IL_23fc;
																																		}
																																		break;
																																	}
																																	goto IL_09d3;
																																	IL_0fdb:
																																	num5--;
																																	goto end_IL_09b5;
																																	IL_09d3:
																																	if (54 > b)
																																	{
																																		goto IL_0c1b;
																																	}
																																	goto IL_0de7;
																																	IL_0de7:
																																	((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).entityTypeId = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																																	goto IL_0e47;
																																	IL_0e47:
																																	num5 -= 2;
																																	goto end_IL_09b5;
																																	IL_0c1b:
																																	if (52 >= b)
																																	{
																																		goto IL_0c26;
																																	}
																																	goto IL_0c8a;
																																	IL_0c26:
																																	if (52 <= b)
																																	{
																																		goto IL_0c34;
																																	}
																																	goto IL_0ecc;
																																	IL_0c34:
																																	array[num5] = 13;
																																	goto IL_0c42;
																																	IL_0c42:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																																	goto IL_0c5b;
																																	IL_0c5b:
																																	array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																																	goto IL_0c7a;
																																	IL_0c7a:
																																	num5++;
																																	goto IL_0c9d;
																																	IL_0c9d:
																																	ptr2 += 16;
																																	goto end_IL_09b5;
																																	IL_0ecc:
																																	if (51 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0eda;
																																	IL_0eda:
																																	if (51 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0ee8;
																																	IL_0ee8:
																																	array[num5] = 5;
																																	goto IL_0ef6;
																																	IL_0ef6:
																																	array2[num5] = array6[*(int*)(ptr2 + num3)];
																																	goto IL_0f0e;
																																	IL_0f0e:
																																	num5++;
																																	goto IL_2222;
																																	IL_2222:
																																	ptr2 += 8;
																																	goto end_IL_09b5;
																																	IL_0c8a:
																																	if (53 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0f81;
																																	IL_0f81:
																																	if (53 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0f8f;
																																	IL_0f8f:
																																	((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4) = default(GameEntityCreateData);
																																	goto IL_0fdb;
																																}
																																break;
																															}
																															goto IL_13b1;
																															IL_13dc:
																															array[num5 - 1] = 1;
																															goto end_IL_09b5;
																															IL_13b1:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																															goto IL_13dc;
																														}
																														break;
																													}
																													goto IL_24fd;
																													IL_27ff:
																													if (66 <= b)
																													{
																													}
																													break;
																													IL_24fd:
																													if (62 >= b)
																													{
																														goto IL_250b;
																													}
																													goto IL_26cc;
																													IL_250b:
																													if (62 <= b)
																													{
																														goto IL_2516;
																													}
																													goto IL_2559;
																													IL_2516:
																													*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
																													goto IL_2540;
																													IL_2540:
																													array[num5 - 1] = 2;
																													goto end_IL_09b5;
																													IL_2559:
																													if (60 >= b)
																													{
																														goto IL_2567;
																													}
																													goto IL_2652;
																													IL_2567:
																													if (60 <= b)
																													{
																														goto IL_2572;
																													}
																													goto IL_25c3;
																													IL_2572:
																													array[num5] = 4;
																													goto IL_2580;
																													IL_2580:
																													array2[num5] = (GameEntityCreateData)array6[*(int*)(ptr2 + num3)];
																													goto IL_25a2;
																													IL_25a2:
																													num5++;
																													goto IL_25b0;
																													IL_25b0:
																													ptr2 += 8;
																													goto end_IL_09b5;
																													IL_25c3:
																													if (59 < b)
																													{
																														break;
																													}
																													goto IL_25d1;
																													IL_25d1:
																													if (59 > b)
																													{
																														break;
																													}
																													goto IL_25df;
																													IL_25df:
																													((delegate*<object, IntPtr, object[], int[], ref GameEntityCreateData>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6, array4).createData = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_263f;
																													IL_263f:
																													num5 -= 2;
																													goto end_IL_09b5;
																													IL_2652:
																													if (61 < b)
																													{
																														break;
																													}
																													goto IL_2660;
																													IL_2660:
																													if (61 > b)
																													{
																														break;
																													}
																													goto IL_266e;
																													IL_266e:
																													((delegate*<List<GameEntityCreateData>, GameEntityCreateData, void>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 2], (GameEntityCreateData)array2[num5 - 1]);
																													goto IL_26ab;
																													IL_26ab:
																													num5 -= 2;
																													goto IL_26b9;
																													IL_26b9:
																													ptr2 += 8;
																													goto end_IL_09b5;
																													IL_26cc:
																													if (64 >= b)
																													{
																														goto IL_26da;
																													}
																													goto IL_2770;
																													IL_26da:
																													if (64 <= b)
																													{
																														goto IL_26e5;
																													}
																													goto IL_2710;
																													IL_26e5:
																													array2[num5] = null;
																													goto IL_26ef;
																													IL_26ef:
																													array[num5] = 5;
																													goto IL_26fd;
																													IL_26fd:
																													num5++;
																													goto end_IL_09b5;
																													IL_2710:
																													if (63 < b)
																													{
																														break;
																													}
																													goto IL_271e;
																													IL_271e:
																													if (63 > b)
																													{
																														break;
																													}
																													goto IL_272c;
																													IL_272c:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																													goto IL_2757;
																													IL_2757:
																													array[num5 - 1] = 0;
																													goto end_IL_09b5;
																													IL_2770:
																													if (65 >= b)
																													{
																														goto IL_277b;
																													}
																													goto IL_27f4;
																													IL_277b:
																													if (65 > b)
																													{
																														break;
																													}
																													goto IL_2789;
																													IL_2789:
																													((delegate*<List<GameEntityCreateData>, Player, bool, void>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((List<GameEntityCreateData>)array2[num5 - 3], (Player)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0);
																													goto IL_27d6;
																													IL_27d6:
																													num5 -= 3;
																													goto IL_27e4;
																													IL_27e4:
																													ptr2 += 8;
																													goto end_IL_09b5;
																													IL_27f4:
																													if (66 < b)
																													{
																														break;
																													}
																													goto IL_27ff;
																												}
																												break;
																											}
																											goto IL_09c0;
																											IL_1d21:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_09c0:
																											if (50 > b)
																											{
																												goto IL_163d;
																											}
																											goto IL_1d50;
																											IL_1d50:
																											array6[*(int*)(ptr2 + num3)] = (Quaternion)array2[num5 - 1];
																											goto IL_1fc4;
																											IL_1fc4:
																											ptr2 += 8;
																											goto IL_1fd2;
																											IL_1fd2:
																											num5--;
																											num = 502;
																											goto end_IL_09b5;
																											IL_163d:
																											if (41 >= b)
																											{
																												goto IL_164b;
																											}
																											goto IL_17ef;
																											IL_164b:
																											if (41 <= b)
																											{
																												goto IL_1656;
																											}
																											goto IL_169d;
																											IL_1656:
																											array[num5] = 5;
																											goto IL_1664;
																											IL_1664:
																											array2[num5] = array6[*(int*)(ptr2 + num3)];
																											goto IL_167c;
																											IL_167c:
																											num5++;
																											goto IL_168a;
																											IL_168a:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_169d:
																											if (37 >= b)
																											{
																												goto IL_16ab;
																											}
																											goto IL_17dc;
																											IL_16ab:
																											if (37 > b)
																											{
																												goto IL_16b9;
																											}
																											num = 486;
																											goto IL_17c9;
																											IL_16b9:
																											if (35 >= b)
																											{
																												goto IL_16c7;
																											}
																											goto IL_1783;
																											IL_16c7:
																											if (35 > b)
																											{
																												goto IL_16d2;
																											}
																											goto IL_1744;
																											IL_16d2:
																											if (34 < b)
																											{
																												break;
																											}
																											goto IL_16e0;
																											IL_16e0:
																											if (34 > b)
																											{
																												break;
																											}
																											goto IL_16ee;
																											IL_16ee:
																											array2[num5] = ((delegate*<string[]>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																											goto IL_170c;
																											IL_170c:
																											array[num5] = 5;
																											goto IL_171a;
																											IL_171a:
																											num5++;
																											num = 60;
																											goto IL_1731;
																											IL_1731:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_1744:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_1762;
																											IL_1762:
																											ptr2 += 8;
																											goto IL_1770;
																											IL_1770:
																											num5--;
																											goto end_IL_09b5;
																											IL_1783:
																											if (36 < b)
																											{
																												break;
																											}
																											num = 276;
																											goto IL_179a;
																											IL_2112:
																											if (42 > b)
																											{
																												break;
																											}
																											goto IL_2120;
																											IL_179a:
																											if (36 > b)
																											{
																												break;
																											}
																											goto IL_17a8;
																											IL_17a8:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_09b5;
																											IL_2104:
																											if (42 < b)
																											{
																												break;
																											}
																											goto IL_2112;
																											IL_17c9:
																											array[num5] = 5;
																											goto IL_1ae1;
																											IL_1ae1:
																											array2[num5] = array6[*(int*)(ptr2 + num3)];
																											goto IL_1af9;
																											IL_1af9:
																											num5++;
																											goto IL_1b07;
																											IL_1b07:
																											ptr2 += 8;
																											num = 405;
																											goto end_IL_09b5;
																											IL_17dc:
																											if (39 >= b)
																											{
																												goto IL_19fd;
																											}
																											goto IL_1b23;
																											IL_19fd:
																											if (39 > b)
																											{
																												goto IL_1a0b;
																											}
																											num = 54;
																											goto IL_1a99;
																											IL_1a0b:
																											if (38 < b)
																											{
																												break;
																											}
																											goto IL_1a19;
																											IL_1a19:
																											if (38 > b)
																											{
																												break;
																											}
																											goto IL_1a27;
																											IL_1a27:
																											array2[num5 - 2] = ((string[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																											goto IL_1a60;
																											IL_1a60:
																											array[num5 - 2] = 5;
																											num = 482;
																											goto IL_1a7d;
																											IL_1a7d:
																											num5--;
																											goto end_IL_09b5;
																											IL_2120:
																											array[num5 - 2] = 0;
																											num = 440;
																											goto IL_213d;
																											IL_1a99:
																											array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											goto IL_1ab7;
																											IL_1ab7:
																											ptr2 += 8;
																											num = 192;
																											goto IL_1ace;
																											IL_1ace:
																											num5--;
																											goto end_IL_09b5;
																											IL_1b23:
																											if (40 < b)
																											{
																												break;
																											}
																											num = 316;
																											goto IL_1b3a;
																											IL_213d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]) ? 1 : 0);
																											goto IL_218f;
																											IL_1b3a:
																											if (40 > b)
																											{
																												break;
																											}
																											goto IL_1b48;
																											IL_1b48:
																											array2[num5] = ((delegate*<Dictionary<string, int>>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																											goto IL_1b66;
																											IL_1b66:
																											array[num5] = 5;
																											goto IL_1b74;
																											IL_1b74:
																											num5++;
																											goto IL_20e8;
																											IL_20e8:
																											ptr2 += 8;
																											num = 383;
																											goto end_IL_09b5;
																											IL_17ef:
																											if (45 < b)
																											{
																												goto IL_17fd;
																											}
																											num = 84;
																											goto IL_1908;
																											IL_17fd:
																											if (47 >= b)
																											{
																												goto IL_1808;
																											}
																											goto IL_187f;
																											IL_1808:
																											if (47 <= b)
																											{
																												goto IL_1813;
																											}
																											goto IL_186c;
																											IL_1813:
																											array[num5] = 13;
																											goto IL_1821;
																											IL_1821:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																											goto IL_183a;
																											IL_183a:
																											array3[num5 - 0] = *(int*)(ptr2 + 8 + num3);
																											goto IL_1859;
																											IL_1859:
																											num5++;
																											goto IL_19ce;
																											IL_19ce:
																											ptr2 += 16;
																											goto end_IL_09b5;
																											IL_186c:
																											if (46 < b)
																											{
																												break;
																											}
																											goto IL_1d34;
																											IL_1d34:
																											if (46 > b)
																											{
																												break;
																											}
																											num = 553;
																											goto IL_22b0;
																											IL_219d:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_22b0:
																											array[num5 - 2] = 4;
																											goto IL_22c4;
																											IL_22c4:
																											array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																											goto IL_2315;
																											IL_2315:
																											num5--;
																											goto IL_2323;
																											IL_2323:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_187f:
																											if (48 < b)
																											{
																												goto IL_188d;
																											}
																											goto IL_1c9a;
																											IL_188d:
																											if (49 < b)
																											{
																												break;
																											}
																											goto IL_189b;
																											IL_189b:
																											if (49 > b)
																											{
																												break;
																											}
																											goto IL_18a9;
																											IL_18a9:
																											array[num5 - 1] = 4;
																											goto IL_18bd;
																											IL_18bd:
																											array2[num5 - 1] = ((delegate*<Vector3, Quaternion>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 1]);
																											goto IL_2062;
																											IL_2062:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_1c9a:
																											if (48 > b)
																											{
																												break;
																											}
																											goto IL_1ca8;
																											IL_1ca8:
																											array[num5 - 1] = 4;
																											goto IL_1fee;
																											IL_1fee:
																											array2[num5 - 1] = ((delegate*<ref Vector3, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[array3[num5 - 1]])(array2[num5 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])), array6, array4));
																											goto IL_240f;
																											IL_240f:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_218f:
																											num5--;
																											goto IL_219d;
																											IL_1908:
																											if (45 <= b)
																											{
																												goto IL_1913;
																											}
																											goto IL_1926;
																											IL_1913:
																											array[num5] = 4;
																											goto IL_1c06;
																											IL_1c06:
																											array2[num5] = ((delegate*<Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																											goto IL_1c29;
																											IL_1c29:
																											num5++;
																											goto IL_1c37;
																											IL_1c37:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_1926:
																											if (43 < b)
																											{
																												goto IL_1931;
																											}
																											goto IL_19a7;
																											IL_1931:
																											if (44 < b)
																											{
																												break;
																											}
																											goto IL_193f;
																											IL_193f:
																											if (44 > b)
																											{
																												break;
																											}
																											goto IL_194d;
																											IL_194d:
																											array[num5] = 4;
																											goto IL_195b;
																											IL_195b:
																											array2[num5] = (Vector3)array6[*(int*)(ptr2 + num3)];
																											num = 252;
																											goto IL_1986;
																											IL_1986:
																											num5++;
																											goto IL_1994;
																											IL_1994:
																											ptr2 += 8;
																											goto end_IL_09b5;
																											IL_19a7:
																											if (43 <= b)
																											{
																												goto IL_19b5;
																											}
																											goto IL_2104;
																											IL_19b5:
																											array[num5 - 2] = 0;
																											goto IL_1cc1;
																											IL_1cc1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array2[num5 - 2], (string)array2[num5 - 1]);
																											goto IL_1d13;
																											IL_1d13:
																											num5--;
																											goto IL_1d21;
																										}
																										break;
																									}
																									goto IL_09e6;
																									IL_134a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_138a;
																									IL_09e6:
																									if (33 <= b)
																									{
																										goto IL_09f1;
																									}
																									goto IL_0a14;
																									IL_09f1:
																									array6[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_227c;
																									IL_227c:
																									ptr2 += 8;
																									goto IL_228a;
																									IL_228a:
																									num5--;
																									goto end_IL_09b5;
																									IL_0a14:
																									if (16 < b)
																									{
																										goto IL_0a22;
																									}
																									num = 474;
																									goto IL_0fee;
																									IL_0a22:
																									if (24 >= b)
																									{
																										goto IL_0a30;
																									}
																									goto IL_0be1;
																									IL_0a30:
																									if (24 <= b)
																									{
																										goto IL_0a3b;
																									}
																									goto IL_0a9f;
																									IL_0a3b:
																									array[num5 - 1] = 4;
																									goto IL_0a4f;
																									IL_0a4f:
																									array2[num5 - 1] = ((delegate*<Transform, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																									goto IL_0a8c;
																									IL_0a8c:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0a9f:
																									if (20 >= b)
																									{
																										goto IL_0aaa;
																									}
																									goto IL_0b1e;
																									IL_0aaa:
																									if (20 > b)
																									{
																										goto IL_0ab5;
																									}
																									num = 290;
																									goto IL_0af6;
																									IL_0ab5:
																									if (18 < b)
																									{
																										goto IL_0ac3;
																									}
																									goto IL_0cb0;
																									IL_0ac3:
																									if (19 < b)
																									{
																										break;
																									}
																									goto IL_0ad1;
																									IL_0ad1:
																									if (19 > b)
																									{
																										break;
																									}
																									num = 506;
																									goto IL_19e1;
																									IL_1d7d:
																									if (6 <= b)
																									{
																										goto IL_1d88;
																									}
																									goto IL_1def;
																									IL_19e1:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_09b5;
																									IL_0cb0:
																									if (18 <= b)
																									{
																										goto IL_0cbb;
																									}
																									goto IL_0d00;
																									IL_0cbb:
																									((delegate*<UnityEngine.Object, void>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Class114)array2[num5 - 1]);
																									goto IL_0ce4;
																									IL_0ce4:
																									num5--;
																									num = 538;
																									goto IL_1fa8;
																									IL_1fa8:
																									ptr2 += 8;
																									num = 80;
																									goto end_IL_09b5;
																									IL_0d00:
																									if (17 < b)
																									{
																										break;
																									}
																									goto IL_0f6e;
																									IL_0f6e:
																									if (17 > b)
																									{
																										break;
																									}
																									goto IL_2235;
																									IL_2235:
																									array2[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_224d;
																									IL_224d:
																									array[num5] = 5;
																									goto IL_225b;
																									IL_225b:
																									num5++;
																									goto IL_2269;
																									IL_2269:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_139e:
																									num5--;
																									goto end_IL_09b5;
																									IL_0af6:
																									((delegate*<void>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																									goto IL_0b0b;
																									IL_0b0b:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0b1e:
																									if (22 >= b)
																									{
																										goto IL_0b2c;
																									}
																									goto IL_0bc0;
																									IL_0b2c:
																									if (22 > b)
																									{
																										goto IL_0b37;
																									}
																									goto IL_0b58;
																									IL_0b37:
																									if (21 < b)
																									{
																										break;
																									}
																									goto IL_0b45;
																									IL_0b45:
																									if (21 > b)
																									{
																										break;
																									}
																									goto IL_0f21;
																									IL_0f21:
																									array[num5] = 5;
																									goto IL_0f2f;
																									IL_0f2f:
																									array2[num5] = ((delegate*<GTPlayer>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																									goto IL_0f4d;
																									IL_0f4d:
																									num5++;
																									goto IL_0f5b;
																									IL_0f5b:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0b58:
																									array2[num5 - 1] = ((delegate*<GTPlayer, SphereCollider>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((GTPlayer)array2[num5 - 1]);
																									num = 78;
																									goto IL_0b99;
																									IL_0b99:
																									array[num5 - 1] = 5;
																									goto IL_0bad;
																									IL_0bad:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0bc0:
																									if (23 < b)
																									{
																										break;
																									}
																									goto IL_0bce;
																									IL_0bce:
																									if (23 > b)
																									{
																										break;
																									}
																									goto IL_1451;
																									IL_1451:
																									array[num5 - 1] = 5;
																									goto IL_1465;
																									IL_1465:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																									goto IL_149d;
																									IL_149d:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0be1:
																									if (28 < b)
																									{
																										goto IL_0bec;
																									}
																									num = 406;
																									goto IL_0d13;
																									IL_0bec:
																									if (30 < b)
																									{
																										goto IL_0e5a;
																									}
																									goto IL_14b0;
																									IL_14b0:
																									if (30 <= b)
																									{
																										goto IL_14bb;
																									}
																									goto IL_14d4;
																									IL_14bb:
																									array[num5 - 2] = 4;
																									goto IL_21b0;
																									IL_21b0:
																									array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																									goto IL_2201;
																									IL_2201:
																									num5--;
																									goto IL_220f;
																									IL_220f:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_14d4:
																									if (29 < b)
																									{
																										break;
																									}
																									goto IL_14e2;
																									IL_14e2:
																									if (29 > b)
																									{
																										break;
																									}
																									goto IL_14f0;
																									IL_14f0:
																									array[num5 - 2] = 4;
																									goto IL_1504;
																									IL_1504:
																									array2[num5 - 2] = ((delegate*<Vector3, float, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																									num = 229;
																									goto IL_155f;
																									IL_155f:
																									num5--;
																									goto IL_156d;
																									IL_156d:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_0e5a:
																									if (31 >= b)
																									{
																										num = 375;
																										goto IL_0e71;
																									}
																									goto IL_2422;
																									IL_1dc8:
																									array[num5 - 2] = 0;
																									goto IL_1ddc;
																									IL_0e71:
																									if (31 > b)
																									{
																										break;
																									}
																									num = 407;
																									goto IL_0e88;
																									IL_1ddc:
																									num5--;
																									goto end_IL_09b5;
																									IL_0e88:
																									array6[*(int*)(ptr2 + num3)] = (Vector3)array2[num5 - 1];
																									num = 166;
																									goto IL_0eb9;
																									IL_0eb9:
																									ptr2 += 8;
																									goto IL_1580;
																									IL_1580:
																									num5--;
																									goto end_IL_09b5;
																									IL_2422:
																									if (32 < b)
																									{
																										break;
																									}
																									goto IL_2430;
																									IL_2430:
																									if (32 > b)
																									{
																										break;
																									}
																									goto IL_243e;
																									IL_243e:
																									array[num5] = 5;
																									goto IL_244c;
																									IL_244c:
																									array2[num5] = ((delegate*<List<GameEntityCreateData>>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																									goto IL_246a;
																									IL_246a:
																									num5++;
																									goto IL_2478;
																									IL_2478:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1d88:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1dc8;
																									IL_0d13:
																									if (28 <= b)
																									{
																										goto IL_0d21;
																									}
																									goto IL_1593;
																									IL_0d21:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																									goto IL_0d3b;
																									IL_0d3b:
																									array[num5] = 3;
																									goto IL_0d49;
																									IL_0d49:
																									num5++;
																									goto IL_0d57;
																									IL_0d57:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1593:
																									if (26 < b)
																									{
																										goto IL_15a1;
																									}
																									goto IL_162a;
																									IL_15a1:
																									if (27 < b)
																									{
																										break;
																									}
																									num = 303;
																									goto IL_15b8;
																									IL_1def:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_1dfd;
																									IL_15b8:
																									if (27 > b)
																									{
																										break;
																									}
																									goto IL_15c6;
																									IL_15c6:
																									array[num5 - 1] = 4;
																									goto IL_15da;
																									IL_15da:
																									array2[num5 - 1] = ((delegate*<Transform, Vector3>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																									goto IL_1617;
																									IL_1617:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_162a:
																									if (26 <= b)
																									{
																										goto IL_1e7b;
																									}
																									goto IL_1ee3;
																									IL_1e7b:
																									array[num5 - 1] = 5;
																									goto IL_1e8f;
																									IL_1e8f:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])((SphereCollider)array2[num5 - 1]);
																									num = 516;
																									goto IL_1ed0;
																									IL_1ed0:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1ee3:
																									if (25 < b)
																									{
																										break;
																									}
																									goto IL_1ef1;
																									IL_1ef1:
																									if (25 > b)
																									{
																										break;
																									}
																									num = 500;
																									goto IL_1f08;
																									IL_1dfd:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_1e0b;
																									IL_1f08:
																									array[num5] = 5;
																									goto IL_1f16;
																									IL_1f16:
																									array2[num5] = ((delegate*<GTPlayer>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])();
																									goto IL_1f34;
																									IL_1f34:
																									num5++;
																									goto IL_1f42;
																									IL_1f42:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_138a:
																									array[num5 - 2] = 0;
																									goto IL_139e;
																									IL_0fee:
																									if (16 <= b)
																									{
																										goto IL_0ff9;
																									}
																									goto IL_106a;
																									IL_0ff9:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_1057;
																									IL_1057:
																									num5--;
																									goto end_IL_09b5;
																									IL_106a:
																									if (8 < b)
																									{
																										goto IL_1078;
																									}
																									num = 344;
																									goto IL_12db;
																									IL_1078:
																									if (12 >= b)
																									{
																										goto IL_1086;
																									}
																									goto IL_11e7;
																									IL_1086:
																									if (12 <= b)
																									{
																										goto IL_1091;
																									}
																									goto IL_10e4;
																									IL_1091:
																									array[num5] = 0;
																									goto IL_109f;
																									IL_109f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_10c3;
																									IL_10c3:
																									num5++;
																									goto IL_10d1;
																									IL_10d1:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_10e4:
																									if (10 >= b)
																									{
																										goto IL_10f2;
																									}
																									goto IL_1c4a;
																									IL_10f2:
																									if (10 <= b)
																									{
																										goto IL_10fd;
																									}
																									goto IL_1172;
																									IL_10fd:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_115f;
																									IL_115f:
																									num5 -= 2;
																									goto end_IL_09b5;
																									IL_1172:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_1180;
																									IL_1180:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_118e;
																									IL_118e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_11ce;
																									IL_11ce:
																									array[num5 - 2] = 0;
																									goto IL_229d;
																									IL_229d:
																									num5--;
																									goto end_IL_09b5;
																									IL_1c4a:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_1c58;
																									IL_1c58:
																									if (11 > b)
																									{
																										break;
																									}
																									goto end_IL_09b5;
																									IL_11e7:
																									if (14 >= b)
																									{
																										goto IL_11f2;
																									}
																									goto IL_1263;
																									IL_11f2:
																									if (14 <= b)
																									{
																										goto IL_11fd;
																									}
																									goto IL_1250;
																									IL_11fd:
																									array[num5] = 0;
																									goto IL_120b;
																									IL_120b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_122f;
																									IL_122f:
																									num5++;
																									goto IL_123d;
																									IL_123d:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1250:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_2075;
																									IL_2075:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_2083;
																									IL_2083:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_20d5;
																									IL_20d5:
																									num5--;
																									goto end_IL_09b5;
																									IL_1263:
																									if (15 < b)
																									{
																										break;
																									}
																									goto IL_1271;
																									IL_1271:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_127f;
																									IL_127f:
																									array[num5] = 0;
																									goto IL_128d;
																									IL_128d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = (((delegate*<bool>)ReleaseSharedStringMakerBeginCriticalRegion[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_12b1;
																									IL_12b1:
																									num5++;
																									goto IL_12bf;
																									IL_12bf:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1e0b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_1e4b;
																									IL_12db:
																									if (8 <= b)
																									{
																										goto IL_12e6;
																									}
																									goto IL_12f9;
																									IL_12e6:
																									num5--;
																									goto end_IL_09b5;
																									IL_12f9:
																									if (4 >= b)
																									{
																										goto IL_1304;
																									}
																									goto IL_1320;
																									IL_1304:
																									if (4 <= b)
																									{
																										num = 485;
																										goto IL_13f5;
																									}
																									goto IL_1b87;
																									IL_1e4b:
																									array[num5 - 2] = 0;
																									goto IL_1e5f;
																									IL_13f5:
																									array[num5] = 0;
																									goto IL_1403;
																									IL_1403:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = array4[*(int*)(ptr2 + num3)];
																									goto IL_1426;
																									IL_1426:
																									array2[num5] = null;
																									goto IL_1430;
																									IL_1430:
																									num5++;
																									goto IL_143e;
																									IL_143e:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1b87:
																									if (2 >= b)
																									{
																										goto IL_1b92;
																									}
																									goto IL_1be5;
																									IL_1b92:
																									if (2 > b)
																									{
																										goto IL_1b9d;
																									}
																									num = 220;
																									goto IL_2336;
																									IL_1b9d:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_1bab;
																									IL_1bab:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_1bb9;
																									IL_1bb9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																									goto IL_1c6b;
																									IL_1c6b:
																									array[num5] = 0;
																									goto IL_1c79;
																									IL_1c79:
																									num5++;
																									goto IL_1c87;
																									IL_1c87:
																									ptr2 += 8;
																									goto end_IL_09b5;
																									IL_1e5f:
																									num5--;
																									num = 21;
																									goto end_IL_09b5;
																									IL_2336:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									goto IL_2376;
																									IL_2376:
																									array[num5 - 2] = 0;
																									goto IL_238a;
																									IL_238a:
																									num5--;
																									goto end_IL_09b5;
																									IL_1be5:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_1bf3;
																									IL_1bf3:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_1f55;
																									IL_1f55:
																									ref int reference = ref array4[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																									num = 77;
																									goto IL_1f87;
																									IL_1f87:
																									ptr2 += 8;
																									goto IL_1f95;
																									IL_1f95:
																									num5--;
																									goto end_IL_09b5;
																									IL_1320:
																									if (6 < b)
																									{
																										goto IL_132e;
																									}
																									goto IL_1d7d;
																									IL_132e:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_133c;
																									IL_133c:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_134a;
																								}
																								break;
																								IL_0985:;
																							}
																						}
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_09b5;
																						continue;
																						end_IL_0995:
																						break;
																					}
																					continue;
																					end_IL_09a5:
																					break;
																				}
																				continue;
																				end_IL_09b5:
																				break;
																			}
																			continue;
																			end_IL_281d:
																			break;
																		}
																		continue;
																		end_IL_2830:
																		break;
																	}
																	continue;
																	end_IL_283a:
																	break;
																}
																continue;
																end_IL_2845:
																break;
															}
															continue;
															end_IL_285b:
															break;
														}
														continue;
														end_IL_2871:
														break;
													}
													continue;
													end_IL_2887:
													break;
												}
												continue;
												end_IL_289d:
												break;
											}
											continue;
											end_IL_28b3:
											break;
										}
										continue;
										end_IL_28c3:
										break;
									}
									continue;
									end_IL_28d3:
									break;
								}
								continue;
								end_IL_28e3:
								break;
							}
							continue;
							end_IL_28f3:
							break;
						}
						continue;
						end_IL_2903:
						break;
					}
					continue;
					end_IL_2913:
					break;
				}
				continue;
				end_IL_2923:
				break;
			}
		}
	}

	public Class114()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		num += num2;
		int num3 = num;
		num = int_3;
		num2 = int_4;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 38;
		num2 = 19;
		return num + 19;
	}

	private unsafe static int smethod_1()
	{
		int num = 17;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetSignatureAssumeUniversal.OaepCLRConfig);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_034f:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0332:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_031f:
																					if (8 > b)
																					{
																						num = 24;
																						while (true)
																						{
																							IL_030f:
																							if (4 >= b)
																							{
																								num = 143;
																								while (true)
																								{
																									IL_02ff:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02ef:
																											if (2 >= b)
																											{
																												while (true)
																												{
																													IL_02df:
																													if (2 > b)
																													{
																														while (true)
																														{
																															IL_02cc:
																															if (1 < b)
																															{
																																num = 160;
																																while (num != 160)
																																{
																																	if (num != 1141)
																																	{
																																		goto IL_06c9;
																																	}
																																	switch (num)
																																	{
																																	case 6:
																																	case 153:
																																		goto IL_02cc;
																																	case 13:
																																		goto IL_02df;
																																	case 20:
																																	case 63:
																																		goto IL_02ef;
																																	case 143:
																																		goto IL_02ff;
																																	case 24:
																																	case 144:
																																		goto IL_030f;
																																	case 148:
																																		goto IL_031f;
																																	case 18:
																																		goto IL_0332;
																																	case 135:
																																		goto IL_033f;
																																	case 61:
																																		goto IL_034f;
																																	case 118:
																																		goto end_IL_034f;
																																	case 68:
																																	case 85:
																																		goto end_IL_035f;
																																	case 25:
																																		goto IL_037a;
																																	case 31:
																																		goto IL_0388;
																																	case 41:
																																	case 54:
																																		goto IL_039b;
																																	case 72:
																																		goto IL_03ab;
																																	case 75:
																																		goto IL_03bb;
																																	case 3:
																																	case 7:
																																		goto IL_03c9;
																																	case 56:
																																		goto IL_03d7;
																																	case 42:
																																	case 94:
																																		goto IL_03e7;
																																	case 47:
																																		goto IL_0400;
																																	case 4:
																																		goto IL_040e;
																																	case 8:
																																		goto IL_0425;
																																	case 67:
																																	case 99:
																																		goto IL_0438;
																																	case 52:
																																		goto IL_0446;
																																	case 27:
																																	case 102:
																																		goto IL_0459;
																																	case 97:
																																		goto IL_0464;
																																	case 23:
																																	case 43:
																																		goto IL_046f;
																																	case 96:
																																		goto IL_047d;
																																	case 12:
																																	case 87:
																																		goto IL_0490;
																																	case 49:
																																		goto IL_04ac;
																																	case 1:
																																		goto IL_04ba;
																																	case 37:
																																	case 112:
																																		goto IL_04cd;
																																	case 46:
																																		goto IL_04db;
																																	case 26:
																																	case 62:
																																		goto IL_04e9;
																																	case 33:
																																		goto IL_0512;
																																	case 57:
																																	case 116:
																																		goto IL_052b;
																																	case 74:
																																		goto IL_056b;
																																	case 111:
																																		goto IL_0588;
																																	case 32:
																																	case 117:
																																		goto IL_059b;
																																	case 71:
																																		goto IL_05fd;
																																	case 103:
																																	case 124:
																																		goto IL_0610;
																																	case 58:
																																		goto IL_0650;
																																	case 104:
																																		goto IL_0664;
																																	case 113:
																																	case 126:
																																		goto IL_0677;
																																	case 125:
																																	case 129:
																																		goto IL_068a;
																																	case 92:
																																		goto IL_06c9;
																																	case 130:
																																		goto IL_06dc;
																																	case 51:
																																		goto IL_06ea;
																																	case 45:
																																	case 88:
																																		goto IL_06f8;
																																	case 100:
																																		goto IL_0706;
																																	case 39:
																																		goto IL_071e;
																																	case 84:
																																		goto IL_072c;
																																	case 131:
																																		goto IL_0748;
																																	case 123:
																																		goto IL_076b;
																																	case 30:
																																		goto IL_0775;
																																	case 64:
																																		goto IL_0783;
																																	case 9:
																																	case 134:
																																		goto IL_0796;
																																	case 137:
																																		goto IL_07a6;
																																	case 10:
																																		goto IL_07b4;
																																	case 29:
																																	case 128:
																																		goto IL_07c2;
																																	case 19:
																																		goto IL_07eb;
																																	case 136:
																																		goto IL_07f9;
																																	case 150:
																																	case 151:
																																		goto IL_080c;
																																	case 152:
																																		goto IL_0824;
																																	case 35:
																																	case 140:
																																		goto IL_0832;
																																	case 106:
																																		goto IL_0876;
																																	case 141:
																																		goto IL_088a;
																																	case 55:
																																	case 73:
																																		goto IL_089a;
																																	case 5:
																																		goto IL_08b8;
																																	case 0:
																																		goto IL_08c6;
																																	case 2:
																																	case 11:
																																	case 14:
																																	case 15:
																																	case 21:
																																	case 28:
																																	case 34:
																																	case 38:
																																	case 40:
																																	case 44:
																																	case 53:
																																	case 59:
																																	case 60:
																																	case 70:
																																	case 76:
																																	case 77:
																																	case 78:
																																	case 82:
																																	case 86:
																																	case 89:
																																	case 91:
																																	case 93:
																																	case 114:
																																	case 115:
																																	case 119:
																																	case 127:
																																	case 133:
																																	case 147:
																																	case 149:
																																		goto end_IL_02b9;
																																	case 22:
																																	case 48:
																																	case 50:
																																	case 69:
																																	case 79:
																																	case 81:
																																	case 90:
																																	case 95:
																																	case 98:
																																	case 108:
																																	case 109:
																																	case 110:
																																	case 120:
																																	case 121:
																																	case 122:
																																	case 132:
																																	case 139:
																																	case 142:
																																		goto end_IL_036f;
																																	case 80:
																																		goto end_IL_08f2;
																																	case 105:
																																		goto end_IL_0905;
																																	case 107:
																																		goto end_IL_090f;
																																	case 145:
																																		goto end_IL_091a;
																																	case 65:
																																	case 83:
																																		goto end_IL_092a;
																																	case 36:
																																		goto end_IL_093a;
																																	case 66:
																																	case 146:
																																		goto end_IL_094a;
																																	case 16:
																																		goto end_IL_095a;
																																	case 17:
																																		goto end_IL_096a;
																																	case 101:
																																	case 138:
																																		goto IL_0985;
																																	}
																																	continue;
																																	end_IL_02b9:
																																	break;
																																}
																																break;
																															}
																															goto IL_03ab;
																															IL_040e:
																															num5++;
																															num = 8;
																															goto IL_0425;
																															IL_0425:
																															ptr2 += 8;
																															goto end_IL_036f;
																															IL_03ab:
																															if (1 > b)
																															{
																																break;
																															}
																															goto IL_03e7;
																															IL_03e7:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															goto IL_0400;
																															IL_0400:
																															array[num5] = 0;
																															goto IL_040e;
																														}
																														break;
																													}
																													goto IL_0610;
																													IL_0664:
																													num5--;
																													goto end_IL_036f;
																													IL_0610:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0650;
																													IL_0650:
																													array[num5 - 2] = 0;
																													goto IL_0664;
																												}
																												break;
																											}
																											goto IL_04cd;
																											IL_0512:
																											array[num5 - 1] = 5;
																											goto end_IL_036f;
																											IL_04cd:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_04db;
																											IL_04db:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_04e9;
																											IL_04e9:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0512;
																										}
																										break;
																									}
																									goto IL_089a;
																									IL_08c6:
																									num5--;
																									num = 22;
																									goto end_IL_036f;
																									IL_089a:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_08b8;
																									IL_08b8:
																									ptr2 += 8;
																									goto IL_08c6;
																								}
																								break;
																							}
																							goto IL_037a;
																							IL_07eb:
																							ptr2 += 8;
																							goto IL_07f9;
																							IL_07f9:
																							num5--;
																							goto end_IL_036f;
																							IL_037a:
																							if (6 >= b)
																							{
																								goto IL_0388;
																							}
																							goto IL_07a6;
																							IL_0388:
																							if (6 <= b)
																							{
																								goto IL_068a;
																							}
																							goto IL_06dc;
																							IL_068a:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_06c9;
																							IL_06c9:
																							num5 -= 3;
																							goto end_IL_036f;
																							IL_06dc:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_06ea;
																							IL_06ea:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_06f8;
																							IL_06f8:
																							array[num5] = 5;
																							goto IL_0706;
																							IL_0706:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_071e;
																							IL_071e:
																							num5++;
																							goto IL_072c;
																							IL_072c:
																							ptr2 += 8;
																							num = 120;
																							goto end_IL_036f;
																							IL_07a6:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_07b4;
																							IL_07b4:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_07c2;
																							IL_07c2:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07eb;
																						}
																						break;
																					}
																					goto IL_080c;
																					IL_080c:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_036f;
																				}
																				break;
																			}
																			goto IL_039b;
																			IL_0588:
																			num5--;
																			goto end_IL_036f;
																			IL_039b:
																			if (12 >= b)
																			{
																				goto IL_03bb;
																			}
																			goto IL_0459;
																			IL_0459:
																			if (14 >= b)
																			{
																				goto IL_0464;
																			}
																			goto IL_04ac;
																			IL_0464:
																			if (14 > b)
																			{
																				goto IL_046f;
																			}
																			goto IL_0490;
																			IL_046f:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_047d;
																			IL_047d:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_059b;
																			IL_059b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05fd;
																			IL_05fd:
																			num5 -= 2;
																			goto end_IL_036f;
																			IL_0490:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_036f;
																			IL_04ac:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_04ba;
																			IL_04ba:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_03bb:
																			if (12 > b)
																			{
																				goto IL_03c9;
																			}
																			goto IL_052b;
																			IL_03c9:
																			if (10 >= b)
																			{
																				goto IL_03d7;
																			}
																			goto IL_0796;
																			IL_03d7:
																			if (10 > b)
																			{
																				goto IL_0438;
																			}
																			goto IL_0677;
																			IL_0438:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0446;
																			IL_0446:
																			if (9 <= b)
																			{
																				goto end_IL_036f;
																			}
																			break;
																			IL_0677:
																			array[num5] = 0;
																			goto IL_0748;
																			IL_0748:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_076b;
																			IL_076b:
																			array2[num5] = null;
																			goto IL_0775;
																			IL_0775:
																			num5++;
																			goto IL_0783;
																			IL_0783:
																			ptr2 += 8;
																			goto end_IL_036f;
																			IL_0796:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0824;
																			IL_0824:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0832;
																			IL_0832:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0876;
																			IL_0876:
																			array[num5 - 2] = 0;
																			goto IL_088a;
																			IL_088a:
																			num5--;
																			goto end_IL_036f;
																			IL_052b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_056b;
																			IL_056b:
																			array[num5 - 2] = 0;
																			num = 111;
																			goto IL_0588;
																		}
																		break;
																		IL_033f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_036f;
																continue;
																end_IL_034f:
																break;
															}
															continue;
															end_IL_035f:
															break;
														}
														continue;
														end_IL_036f:
														break;
													}
													continue;
												}
												goto IL_0985;
												IL_0985:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08f2:
												break;
											}
											continue;
											end_IL_0905:
											break;
										}
										continue;
										end_IL_090f:
										break;
									}
									continue;
									end_IL_091a:
									break;
								}
								continue;
								end_IL_092a:
								break;
							}
							continue;
							end_IL_093a:
							break;
						}
						continue;
						end_IL_094a:
						break;
					}
					continue;
					end_IL_095a:
					break;
				}
				continue;
				end_IL_096a:
				break;
			}
		}
	}

	private static int smethod_2(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		num += num2;
		int num3 = num;
		num = int_3;
		num2 = int_4;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 748;
		num2 = 68;
		return num + 68;
	}

	private static int smethod_3(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		if (num <= num2)
		{
			num = int_4;
			num2 = int_3;
			return num - num2;
		}
		num = int_3;
		num2 = int_4;
		return num - num2;
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 47;
		int num3 = default(int);
		byte b = default(byte);
		byte[] array = default(byte[]);
		int num4 = default(int);
		long[] array2 = default(long[]);
		int[] array3 = default(int[]);
		byte* ptr = default(byte*);
		object[] array4 = default(object[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 136;
			while (true)
			{
				if (num != 136)
				{
					if (num != 1117)
					{
						goto IL_060f;
					}
					switch (num)
					{
					case 47:
						goto end_IL_022f;
					case 9:
					case 16:
						goto IL_026a;
					case 21:
						goto IL_0278;
					case 67:
					case 128:
						goto IL_0286;
					case 18:
						goto IL_0294;
					case 129:
						goto IL_02a2;
					case 95:
						goto IL_02b5;
					case 82:
						goto IL_02be;
					case 10:
					case 22:
					case 30:
					case 36:
					case 41:
					case 54:
					case 70:
					case 77:
					case 85:
					case 89:
					case 96:
					case 105:
					case 107:
					case 108:
					case 121:
					case 125:
						goto IL_02c6;
					case 79:
						goto IL_02d6;
					case 104:
						goto IL_02df;
					case 92:
						goto IL_02e8;
					case 86:
						goto IL_02f6;
					case 78:
						goto IL_0304;
					case 112:
						goto IL_0312;
					case 26:
						goto IL_0320;
					case 51:
					case 58:
						goto IL_032b;
					case 109:
						goto IL_036b;
					case 106:
						goto IL_0388;
					case 120:
						goto IL_039b;
					case 14:
						goto IL_03a9;
					case 83:
						goto IL_03b7;
					case 32:
					case 110:
						goto IL_03c2;
					case 23:
						goto IL_03d0;
					case 8:
					case 127:
						goto IL_03e3;
					case 66:
						goto IL_03f1;
					case 113:
						goto IL_0414;
					case 52:
						goto IL_041e;
					case 42:
						goto IL_042c;
					case 97:
						goto IL_043f;
					case 80:
						goto IL_044d;
					case 28:
					case 88:
						goto IL_045b;
					case 103:
						goto IL_049b;
					case 50:
						goto IL_04af;
					case 102:
						goto IL_04cb;
					case 33:
					case 37:
						goto IL_04d9;
					case 57:
					case 62:
						goto IL_04e4;
					case 124:
						goto IL_04fb;
					case 11:
					case 84:
						goto IL_0509;
					case 25:
						goto IL_0532;
					case 4:
						goto IL_0540;
					case 117:
						goto IL_0553;
					case 49:
					case 118:
						goto IL_0561;
					case 64:
						goto IL_057a;
					case 100:
						goto IL_0588;
					case 122:
						goto IL_0596;
					case 12:
					case 38:
						goto IL_05a9;
					case 63:
						goto IL_05c1;
					case 0:
					case 75:
						goto IL_05cf;
					case 74:
						goto IL_05da;
					case 111:
					case 115:
						goto IL_05e5;
					case 65:
						goto IL_0601;
					case 56:
						goto IL_060f;
					case 31:
					case 114:
						goto IL_061d;
					case 68:
						goto IL_0630;
					case 40:
						goto IL_063e;
					case 73:
						goto IL_065a;
					case 29:
					case 45:
						goto IL_0665;
					case 76:
						goto IL_0673;
					case 7:
						goto IL_0697;
					case 13:
						goto IL_06a5;
					case 48:
					case 123:
						goto IL_06b8;
					case 15:
					case 17:
						goto IL_06c6;
					case 60:
						goto IL_06d4;
					case 1:
					case 55:
						goto IL_06e2;
					case 39:
						goto IL_0744;
					case 116:
						goto IL_0757;
					case 6:
					case 126:
						goto IL_0762;
					case 5:
						goto IL_0785;
					case 93:
						goto IL_0793;
					case 61:
						goto IL_07a1;
					case 2:
					case 3:
					case 19:
					case 20:
					case 24:
					case 27:
					case 34:
					case 35:
					case 43:
					case 44:
					case 46:
					case 53:
					case 59:
					case 71:
					case 72:
					case 81:
					case 87:
					case 90:
					case 91:
					case 94:
					case 99:
					case 101:
					case 119:
						goto IL_07b4;
					case 69:
					case 98:
						goto IL_07cc;
					}
					continue;
				}
				num3 = num2 * 4;
				num = 16;
				goto IL_026a;
				IL_0757:
				if (8 <= b)
				{
					goto IL_0762;
				}
				goto IL_07b4;
				IL_0785:
				array[num4] = 0;
				goto IL_0793;
				IL_0762:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array3[*(int*)(ptr + num3)];
				goto IL_0785;
				IL_026a:
				array = new byte[3];
				goto IL_0278;
				IL_0278:
				array4 = new object[3];
				goto IL_0286;
				IL_0286:
				array3 = new int[4];
				goto IL_0294;
				IL_0294:
				array2 = new long[3];
				goto IL_02a2;
				IL_02a2:
				array3[0] = int_3;
				goto IL_02b5;
				IL_02b5:
				ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConcurrentExclusiveTaskSchedulerEscapedCodeBase.getTargetSchedulerOSArchitecture);
				goto IL_02be;
				IL_02be:
				ptr = ptr2;
				goto IL_02c6;
				IL_02c6:
				if (num5 != 1)
				{
					goto IL_02d6;
				}
				goto IL_07cc;
				IL_07cc:
				return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				IL_02d6:
				num = 104;
				goto IL_02df;
				IL_02df:
				b = *ptr;
				goto IL_02e8;
				IL_02e8:
				ptr++;
				goto IL_02f6;
				IL_02f6:
				if (b >= 1)
				{
					goto IL_0304;
				}
				goto IL_07b4;
				IL_0304:
				if (b <= 13)
				{
					goto IL_0312;
				}
				goto IL_07b4;
				IL_0312:
				if (7 >= b)
				{
					goto IL_0320;
				}
				goto IL_05c1;
				IL_0320:
				if (7 <= b)
				{
					goto IL_032b;
				}
				goto IL_039b;
				IL_032b:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				goto IL_036b;
				IL_036b:
				array[num4 - 2] = 0;
				num = 106;
				goto IL_0388;
				IL_0388:
				num4--;
				goto IL_02c6;
				IL_039b:
				if (3 < b)
				{
					goto IL_03a9;
				}
				num = 102;
				goto IL_04cb;
				IL_03a9:
				if (5 >= b)
				{
					goto IL_03b7;
				}
				goto IL_043f;
				IL_03b7:
				if (5 > b)
				{
					goto IL_03c2;
				}
				goto IL_03e3;
				IL_03c2:
				if (4 >= b)
				{
					goto IL_03d0;
				}
				goto IL_07b4;
				IL_03d0:
				if (4 <= b)
				{
					goto IL_02c6;
				}
				goto IL_07b4;
				IL_03e3:
				array[num4] = 0;
				goto IL_03f1;
				IL_03f1:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = array3[*(int*)(ptr + num3)];
				goto IL_0414;
				IL_0414:
				array4[num4] = null;
				goto IL_041e;
				IL_041e:
				num4++;
				goto IL_042c;
				IL_042c:
				ptr += 8;
				goto IL_02c6;
				IL_043f:
				if (6 >= b)
				{
					goto IL_044d;
				}
				goto IL_07b4;
				IL_044d:
				if (6 <= b)
				{
					goto IL_045b;
				}
				goto IL_07b4;
				IL_045b:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				goto IL_049b;
				IL_049b:
				array[num4 - 2] = 0;
				goto IL_04af;
				IL_04af:
				num4--;
				goto IL_02c6;
				IL_0793:
				num4++;
				goto IL_07a1;
				IL_04cb:
				if (3 > b)
				{
					goto IL_04d9;
				}
				goto IL_05a9;
				IL_04d9:
				if (1 < b)
				{
					goto IL_04e4;
				}
				goto IL_0553;
				IL_04e4:
				if (2 >= b)
				{
					num = 124;
					goto IL_04fb;
				}
				goto IL_07b4;
				IL_07a1:
				ptr += 8;
				goto IL_02c6;
				IL_04fb:
				if (2 <= b)
				{
					goto IL_0509;
				}
				goto IL_07b4;
				IL_0509:
				ref int reference = ref array3[*(int*)(ptr + num3)];
				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1]);
				goto IL_0532;
				IL_0532:
				ptr += 8;
				goto IL_0540;
				IL_0540:
				num4--;
				goto IL_02c6;
				IL_0553:
				if (1 <= b)
				{
					goto IL_0561;
				}
				goto IL_07b4;
				IL_0561:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = *(int*)(ptr + num3);
				goto IL_057a;
				IL_057a:
				array[num4] = 0;
				goto IL_0588;
				IL_0588:
				num4++;
				goto IL_0596;
				IL_0596:
				ptr += 8;
				goto IL_02c6;
				IL_05a9:
				ptr = ptr2 + *(int*)(ptr + num3);
				goto IL_02c6;
				IL_05c1:
				if (10 < b)
				{
					goto IL_05cf;
				}
				goto IL_065a;
				IL_05cf:
				if (12 >= b)
				{
					goto IL_05da;
				}
				goto IL_0630;
				IL_05da:
				if (12 <= b)
				{
					goto IL_05e5;
				}
				goto IL_0601;
				IL_05e5:
				byte* num6 = ptr;
				num5 = 1;
				ptr = num6 + -200;
				goto IL_02c6;
				IL_0601:
				if (11 >= b)
				{
					goto IL_060f;
				}
				goto IL_07b4;
				IL_060f:
				if (11 <= b)
				{
					goto IL_061d;
				}
				goto IL_07b4;
				IL_061d:
				num4--;
				goto IL_02c6;
				IL_0630:
				if (13 >= b)
				{
					goto IL_063e;
				}
				goto IL_07b4;
				IL_063e:
				if (13 <= b)
				{
					num = 35;
				}
				goto IL_07b4;
				IL_07b4:
				ptr = ptr2 + *(int*)(ptr + num3);
				goto IL_02c6;
				IL_065a:
				if (10 <= b)
				{
					goto IL_0665;
				}
				goto IL_06b8;
				IL_0665:
				array[num4] = 0;
				goto IL_0673;
				IL_0673:
				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4]) = ((delegate*<int>)URIMax[*(int*)(ptr + num3)])();
				goto IL_0697;
				IL_0697:
				num4++;
				goto IL_06a5;
				IL_06a5:
				ptr += 8;
				goto IL_02c6;
				IL_06b8:
				if (8 < b)
				{
					goto IL_06c6;
				}
				goto IL_0757;
				IL_06c6:
				if (9 >= b)
				{
					goto IL_06d4;
				}
				goto IL_07b4;
				IL_06d4:
				if (9 <= b)
				{
					goto IL_06e2;
				}
				goto IL_07b4;
				IL_06e2:
				ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array2[num4 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
				goto IL_0744;
				IL_0744:
				num4 -= 2;
				goto IL_02c6;
				continue;
				end_IL_022f:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 73;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 91;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemoveAuditRuleSpecificKind.ParameterInfoDoubleQuote);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_026d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024d:
																			if (5 < b)
																			{
																				goto IL_03dc;
																			}
																			while (true)
																			{
																				IL_0240:
																				if (5 <= b)
																				{
																					while (true)
																					{
																						IL_0230:
																						array[num5] = 0;
																						while (true)
																						{
																							IL_020b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							while (true)
																							{
																								IL_01ff:
																								array2[num5] = null;
																								while (true)
																								{
																									IL_01e6:
																									num5++;
																									num = 113;
																									while (true)
																									{
																										if (num != 113)
																										{
																											if (num != 1094)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 96:
																												goto IL_01e6;
																											case 4:
																												goto IL_01ff;
																											case 95:
																												goto IL_020b;
																											case 51:
																											case 68:
																												goto IL_0230;
																											case 36:
																												goto IL_0240;
																											case 62:
																												goto IL_024d;
																											case 3:
																												goto end_IL_024d;
																											case 76:
																												goto IL_026d;
																											case 102:
																												goto end_IL_026d;
																											case 1:
																											case 46:
																												goto end_IL_027d;
																											case 44:
																												goto IL_02ab;
																											case 22:
																											case 63:
																												goto IL_02b6;
																											case 31:
																												goto IL_02ca;
																											case 41:
																											case 105:
																												goto IL_02d8;
																											case 98:
																												goto IL_02f0;
																											case 38:
																												goto IL_02fe;
																											case 5:
																												goto IL_0311;
																											case 7:
																											case 84:
																												goto IL_031c;
																											case 83:
																												goto IL_032a;
																											case 2:
																											case 11:
																												goto IL_0338;
																											case 19:
																												goto IL_0351;
																											case 60:
																												goto IL_0368;
																											case 39:
																												goto IL_0376;
																											case 21:
																											case 93:
																												goto IL_0389;
																											case 30:
																												goto IL_03b2;
																											case 92:
																												goto IL_03c9;
																											case 37:
																												goto IL_03dc;
																											case 16:
																											case 27:
																												goto IL_03e7;
																											case 94:
																												goto IL_03f2;
																											case 10:
																											case 57:
																												goto end_IL_01d3;
																											case 6:
																												goto IL_041c;
																											case 50:
																												goto IL_0433;
																											case 59:
																												goto IL_0446;
																											case 65:
																											case 103:
																												goto IL_0454;
																											case 29:
																											case 104:
																												goto IL_045f;
																											case 77:
																												goto IL_046d;
																											case 25:
																											case 34:
																												goto IL_047b;
																											case 40:
																												goto IL_049e;
																											case 89:
																												goto IL_04ac;
																											case 69:
																												goto IL_04ba;
																											case 78:
																												goto IL_04cd;
																											case 79:
																											case 87:
																												goto IL_04db;
																											case 48:
																												goto IL_051b;
																											case 49:
																												goto IL_052f;
																											case 18:
																											case 85:
																												goto IL_054b;
																											case 90:
																												goto IL_05ad;
																											case 9:
																											case 12:
																											case 13:
																											case 14:
																											case 15:
																											case 20:
																											case 23:
																											case 26:
																											case 43:
																											case 52:
																											case 54:
																											case 58:
																											case 64:
																											case 66:
																											case 71:
																											case 74:
																											case 80:
																											case 81:
																											case 82:
																											case 86:
																											case 99:
																												goto end_IL_025d;
																											case 17:
																											case 24:
																											case 28:
																											case 33:
																											case 35:
																											case 42:
																											case 47:
																											case 55:
																											case 61:
																											case 70:
																											case 75:
																											case 100:
																											case 106:
																												goto end_IL_028d;
																											case 0:
																												goto end_IL_05d0;
																											case 88:
																												goto end_IL_05e3;
																											case 91:
																												goto end_IL_05ed;
																											case 101:
																												goto end_IL_05f8;
																											case 32:
																											case 67:
																												goto end_IL_060d;
																											case 53:
																												goto end_IL_0626;
																											case 8:
																											case 56:
																												goto end_IL_0636;
																											case 72:
																												goto end_IL_0646;
																											case 73:
																												goto end_IL_0656;
																											case 45:
																											case 97:
																												goto IL_0671;
																											}
																											continue;
																										}
																										ptr2 += 8;
																										goto end_IL_028d;
																										continue;
																										end_IL_01d3:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_02ab;
																				IL_03b2:
																				ptr2 += 8;
																				num = 92;
																				goto IL_03c9;
																				IL_02ab:
																				if (2 < b)
																				{
																					goto IL_02b6;
																				}
																				goto IL_0311;
																				IL_02b6:
																				if (3 >= b)
																				{
																					num = 31;
																					goto IL_02ca;
																				}
																				goto IL_02f0;
																				IL_03c9:
																				num5--;
																				goto end_IL_028d;
																				IL_02ca:
																				if (3 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_02d8;
																				IL_02d8:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_028d;
																				IL_02f0:
																				if (4 < b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_02fe;
																				IL_02fe:
																				if (4 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto end_IL_028d;
																				IL_0311:
																				if (2 > b)
																				{
																					goto IL_031c;
																				}
																				goto IL_0389;
																				IL_031c:
																				if (1 < b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_032a;
																				IL_032a:
																				if (1 > b)
																				{
																					goto end_IL_025d;
																				}
																				goto IL_0338;
																				IL_0338:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0351;
																				IL_0351:
																				array[num5] = 0;
																				num = 60;
																				goto IL_0368;
																				IL_0368:
																				num5++;
																				goto IL_0376;
																				IL_0376:
																				ptr2 += 8;
																				goto end_IL_028d;
																				IL_0389:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03b2;
																			}
																			goto IL_0400;
																			IL_054b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05ad;
																			IL_03dc:
																			if (8 < b)
																			{
																				goto IL_03e7;
																			}
																			goto IL_0446;
																			IL_03e7:
																			if (9 >= b)
																			{
																				goto IL_03f2;
																			}
																			goto IL_041c;
																			IL_03f2:
																			if (9 > b)
																			{
																				goto end_IL_025d;
																			}
																			goto IL_0400;
																			IL_0400:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_028d;
																			IL_041c:
																			if (10 < b)
																			{
																				goto end_IL_025d;
																			}
																			num = 50;
																			goto IL_0433;
																			IL_05ad:
																			num5 -= 2;
																			goto end_IL_028d;
																			IL_0433:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_025d;
																			IL_0446:
																			if (8 > b)
																			{
																				goto IL_0454;
																			}
																			goto IL_054b;
																			IL_0454:
																			if (6 < b)
																			{
																				goto IL_045f;
																			}
																			goto IL_04cd;
																			IL_045f:
																			if (7 < b)
																			{
																				goto end_IL_025d;
																			}
																			goto IL_046d;
																			IL_046d:
																			if (7 > b)
																			{
																				goto end_IL_025d;
																			}
																			goto IL_047b;
																			IL_047b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_049e;
																			IL_049e:
																			array[num5] = 0;
																			goto IL_04ac;
																			IL_04ac:
																			num5++;
																			goto IL_04ba;
																			IL_04ba:
																			ptr2 += 8;
																			goto end_IL_028d;
																			IL_04cd:
																			if (6 > b)
																			{
																				goto end_IL_025d;
																			}
																			goto IL_04db;
																			IL_04db:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_051b;
																			IL_051b:
																			array[num5 - 2] = 0;
																			goto IL_052f;
																			IL_052f:
																			num5--;
																			num = 55;
																			goto end_IL_028d;
																			continue;
																			end_IL_024d:
																			break;
																		}
																		continue;
																		end_IL_025d:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_028d;
																continue;
																end_IL_026d:
																break;
															}
															continue;
															end_IL_027d:
															break;
														}
														continue;
														end_IL_028d:
														break;
													}
													continue;
												}
												goto IL_0671;
												IL_0671:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d0:
												break;
											}
											continue;
											end_IL_05e3:
											break;
										}
										continue;
										end_IL_05ed:
										break;
									}
									continue;
									end_IL_05f8:
									break;
								}
								continue;
								end_IL_060d:
								break;
							}
							continue;
							end_IL_0626:
							break;
						}
						continue;
						end_IL_0636:
						break;
					}
					continue;
					end_IL_0646:
					break;
				}
				continue;
				end_IL_0656:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SatelliteToSerializedString.DecoderExceptionFallbackBufferRegistrationClassContext);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0365:
														byte b = *ptr2;
														while (true)
														{
															IL_0355:
															ptr2++;
															while (true)
															{
																IL_0345:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0322:
																			if (8 < b)
																			{
																				num = 36;
																				while (true)
																				{
																					IL_0312:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_0302:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02ef:
																									if (10 >= b)
																									{
																										num = 109;
																										while (true)
																										{
																											IL_02df:
																											if (10 > b)
																											{
																												while (9 >= b)
																												{
																													while (9 <= b)
																													{
																														num = 156;
																														while (num != 156)
																														{
																															if (num != 1137)
																															{
																																goto IL_07ab;
																															}
																															switch (num)
																															{
																															case 85:
																																goto IL_02bc;
																															case 76:
																																goto IL_02cf;
																															case 109:
																																goto IL_02df;
																															case 114:
																															case 139:
																																goto IL_02ef;
																															case 38:
																																goto IL_0302;
																															case 36:
																															case 135:
																																goto IL_0312;
																															case 83:
																																goto IL_0322;
																															case 75:
																																goto IL_0335;
																															case 122:
																																goto IL_0345;
																															case 107:
																																goto IL_0355;
																															case 42:
																															case 132:
																																goto IL_0365;
																															case 27:
																															case 34:
																																goto IL_0370;
																															case 78:
																																goto IL_037e;
																															case 5:
																																goto IL_03a1;
																															case 119:
																																goto IL_03b0;
																															case 138:
																																goto IL_03be;
																															case 47:
																															case 79:
																																goto IL_03cc;
																															case 113:
																																goto IL_0410;
																															case 101:
																																goto IL_0424;
																															case 143:
																																goto IL_0437;
																															case 0:
																																goto IL_0445;
																															case 130:
																															case 146:
																																goto IL_0458;
																															case 33:
																																goto IL_04a1;
																															case 54:
																																goto IL_04b5;
																															case 95:
																																goto IL_04c8;
																															case 18:
																																goto IL_04d6;
																															case 55:
																															case 66:
																																goto IL_04e4;
																															case 126:
																																goto IL_04f2;
																															case 115:
																															case 142:
																																goto IL_0500;
																															case 77:
																																goto IL_0562;
																															case 70:
																															case 141:
																																goto IL_0575;
																															case 2:
																																goto IL_0591;
																															case 147:
																																goto IL_059f;
																															case 149:
																																goto IL_05b2;
																															case 108:
																															case 123:
																																goto IL_05c0;
																															case 32:
																															case 112:
																																goto IL_05ce;
																															case 87:
																															case 125:
																																goto IL_05d9;
																															case 28:
																																goto IL_05e7;
																															case 12:
																															case 39:
																																goto IL_05f5;
																															case 30:
																																goto IL_061e;
																															case 94:
																																goto IL_062c;
																															case 3:
																																goto IL_063f;
																															case 57:
																															case 104:
																																goto IL_064a;
																															case 91:
																																goto IL_0658;
																															case 96:
																															case 131:
																																goto IL_0666;
																															case 81:
																																goto IL_0674;
																															case 16:
																																goto IL_068c;
																															case 99:
																																goto IL_069a;
																															case 19:
																															case 59:
																																goto IL_06ad;
																															case 68:
																																goto IL_06ec;
																															case 46:
																																goto IL_0708;
																															case 6:
																															case 124:
																																goto IL_0713;
																															case 37:
																																goto IL_0731;
																															case 60:
																																goto IL_073f;
																															case 58:
																															case 133:
																																goto IL_075b;
																															case 43:
																															case 98:
																																goto IL_0766;
																															case 15:
																																goto IL_0774;
																															case 116:
																															case 145:
																																goto IL_0782;
																															case 22:
																																goto IL_07ab;
																															case 103:
																																goto IL_07c4;
																															case 97:
																															case 140:
																																goto IL_07cf;
																															case 100:
																																goto IL_07dd;
																															case 40:
																															case 63:
																																goto IL_07eb;
																															case 44:
																																goto IL_0804;
																															case 41:
																																goto IL_0812;
																															case 62:
																																goto IL_0820;
																															case 71:
																															case 86:
																																goto IL_0833;
																															case 73:
																																goto IL_0873;
																															case 25:
																																goto IL_0887;
																															case 13:
																															case 93:
																																goto IL_0897;
																															case 1:
																															case 10:
																															case 17:
																															case 20:
																															case 23:
																															case 24:
																															case 26:
																															case 29:
																															case 50:
																															case 51:
																															case 52:
																															case 56:
																															case 61:
																															case 64:
																															case 65:
																															case 69:
																															case 72:
																															case 74:
																															case 80:
																															case 92:
																															case 111:
																															case 118:
																															case 121:
																															case 128:
																															case 134:
																															case 144:
																																goto end_IL_02bc;
																															case 7:
																															case 8:
																															case 9:
																															case 14:
																															case 45:
																															case 48:
																															case 49:
																															case 53:
																															case 67:
																															case 82:
																															case 102:
																															case 105:
																															case 106:
																															case 110:
																															case 136:
																															case 137:
																															case 148:
																																goto end_IL_02a9;
																															case 88:
																																goto end_IL_08bf;
																															case 129:
																																goto end_IL_08d2;
																															case 127:
																																goto end_IL_08dc;
																															case 84:
																																goto end_IL_08e7;
																															case 4:
																															case 120:
																																goto end_IL_08f7;
																															case 117:
																																goto end_IL_0907;
																															case 11:
																															case 31:
																																goto end_IL_0917;
																															case 89:
																																goto end_IL_0927;
																															case 90:
																																goto end_IL_0937;
																															case 21:
																															case 35:
																																goto IL_0952;
																															}
																															continue;
																															end_IL_02a9:
																															break;
																														}
																														goto end_IL_0345;
																														continue;
																														end_IL_02bc:
																														break;
																														IL_02bc:;
																													}
																													break;
																													IL_02cf:;
																												}
																												break;
																											}
																											goto IL_0370;
																											IL_0445:
																											ptr2 += 8;
																											goto end_IL_0345;
																											IL_0370:
																											array[num5] = 0;
																											goto IL_037e;
																											IL_037e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_03a1;
																											IL_03a1:
																											array2[num5] = null;
																											goto IL_0437;
																											IL_0437:
																											num5++;
																											goto IL_0445;
																										}
																										break;
																									}
																									goto IL_03b0;
																									IL_0410:
																									array[num5 - 2] = 0;
																									goto IL_0424;
																									IL_0424:
																									num5--;
																									goto end_IL_0345;
																									IL_03b0:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_03be;
																									IL_03be:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_03cc;
																									IL_03cc:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0410;
																								}
																								break;
																							}
																							goto IL_0458;
																							IL_04b5:
																							num5--;
																							goto end_IL_0345;
																							IL_0458:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 33;
																							goto IL_04a1;
																							IL_04a1:
																							array[num5 - 2] = 0;
																							goto IL_04b5;
																						}
																						break;
																					}
																					goto IL_04c8;
																					IL_059f:
																					if (15 > b)
																					{
																					}
																					break;
																					IL_04c8:
																					if (14 >= b)
																					{
																						goto IL_04d6;
																					}
																					goto IL_0591;
																					IL_04d6:
																					if (14 > b)
																					{
																						goto IL_04e4;
																					}
																					goto IL_0575;
																					IL_04e4:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_04f2;
																					IL_04f2:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0500;
																					IL_0500:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0562;
																					IL_0562:
																					num5 -= 2;
																					goto end_IL_0345;
																					IL_0575:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0345;
																					IL_0591:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_059f;
																				}
																				break;
																			}
																			goto IL_05b2;
																			IL_0873:
																			array[num5 - 2] = 0;
																			goto IL_0887;
																			IL_0887:
																			num5--;
																			goto end_IL_0345;
																			IL_05b2:
																			if (8 > b)
																			{
																				goto IL_05c0;
																			}
																			goto IL_0897;
																			IL_05c0:
																			if (4 < b)
																			{
																				goto IL_05ce;
																			}
																			goto IL_0708;
																			IL_05ce:
																			if (6 < b)
																			{
																				goto IL_05d9;
																			}
																			goto IL_063f;
																			IL_05d9:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_05e7;
																			IL_05e7:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05f5;
																			IL_05f5:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_061e;
																			IL_061e:
																			ptr2 += 8;
																			goto IL_062c;
																			IL_062c:
																			num5--;
																			goto end_IL_0345;
																			IL_063f:
																			if (6 > b)
																			{
																				goto IL_064a;
																			}
																			goto IL_06ad;
																			IL_064a:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0658;
																			IL_0658:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0666;
																			IL_0666:
																			array[num5] = 5;
																			goto IL_0674;
																			IL_0674:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_068c;
																			IL_068c:
																			num5++;
																			goto IL_069a;
																			IL_069a:
																			ptr2 += 8;
																			goto end_IL_0345;
																			IL_06ad:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06ec;
																			IL_06ec:
																			num5 -= 3;
																			num = 9;
																			goto end_IL_0345;
																			IL_0708:
																			if (4 <= b)
																			{
																				goto IL_0713;
																			}
																			num = 58;
																			goto IL_075b;
																			IL_0713:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0731;
																			IL_0731:
																			ptr2 += 8;
																			goto IL_073f;
																			IL_073f:
																			num5--;
																			goto end_IL_0345;
																			IL_0897:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0345;
																			IL_075b:
																			if (2 < b)
																			{
																				goto IL_0766;
																			}
																			goto IL_07c4;
																			IL_0766:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0774;
																			IL_0774:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0782;
																			IL_0782:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07ab;
																			IL_07ab:
																			array[num5 - 1] = 5;
																			goto end_IL_0345;
																			IL_07c4:
																			if (2 > b)
																			{
																				goto IL_07cf;
																			}
																			goto IL_0833;
																			IL_07cf:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_07dd;
																			IL_07dd:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_07eb;
																			IL_07eb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0804;
																			IL_0804:
																			array[num5] = 0;
																			goto IL_0812;
																			IL_0812:
																			num5++;
																			goto IL_0820;
																			IL_0820:
																			ptr2 += 8;
																			goto end_IL_0345;
																			IL_0833:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0873;
																		}
																		break;
																		IL_0335:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0345:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0952;
												IL_0952:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08bf:
												break;
											}
											continue;
											end_IL_08d2:
											break;
										}
										continue;
										end_IL_08dc:
										break;
									}
									continue;
									end_IL_08e7:
									break;
								}
								continue;
								end_IL_08f7:
								break;
							}
							continue;
							end_IL_0907:
							break;
						}
						continue;
						end_IL_0917:
						break;
					}
					continue;
					end_IL_0927:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MachineAccountCannotUnloadAppDomainException.RestoreFlowResolveEventHandler);
										num = 95;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 45;
														while (true)
														{
															ptr2++;
															num = 32;
															while (true)
															{
																IL_0209:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_01dc:
																					if (5 <= b)
																					{
																						num = 107;
																						while (true)
																						{
																							if (num != 107)
																							{
																								if (num != 1088)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 55:
																									goto IL_01dc;
																								case 2:
																									goto end_IL_01dc;
																								case 78:
																									goto end_IL_01ec;
																								case 32:
																									goto IL_0209;
																								case 45:
																									goto end_IL_0209;
																								case 31:
																								case 89:
																									goto end_IL_0219;
																								case 0:
																									goto IL_0246;
																								case 27:
																									goto IL_0254;
																								case 28:
																									goto IL_026d;
																								case 4:
																								case 17:
																									goto IL_027b;
																								case 6:
																								case 21:
																									goto IL_0292;
																								case 14:
																									goto IL_02a9;
																								case 33:
																									goto IL_02bc;
																								case 1:
																									goto IL_02ca;
																								case 54:
																									goto IL_02dd;
																								case 5:
																									goto IL_02e8;
																								case 16:
																								case 58:
																									goto IL_02fb;
																								case 66:
																									goto IL_0329;
																								case 67:
																									goto IL_033c;
																								case 39:
																									goto IL_034a;
																								case 52:
																									goto IL_0355;
																								case 37:
																									goto IL_0363;
																								case 72:
																									goto IL_0373;
																								case 23:
																								case 77:
																									goto IL_0383;
																								case 68:
																									goto IL_03a6;
																								case 83:
																									goto IL_03c2;
																								case 53:
																								case 74:
																									goto IL_03d0;
																								case 46:
																								case 86:
																									goto IL_03ec;
																								case 51:
																									goto IL_042c;
																								case 25:
																									goto IL_0440;
																								case 82:
																								case 92:
																									goto IL_0453;
																								case 26:
																								case 93:
																									goto IL_046b;
																								case 94:
																									goto IL_04cd;
																								case 96:
																									goto IL_04e0;
																								case 63:
																									goto IL_04ee;
																								case 99:
																									goto end_IL_01c9;
																								case 9:
																									goto IL_050f;
																								case 100:
																									goto IL_0522;
																								case 48:
																								case 90:
																									goto IL_0530;
																								case 79:
																									goto IL_0549;
																								case 91:
																									goto IL_0557;
																								case 70:
																									goto IL_0565;
																								case 61:
																									goto IL_0575;
																								case 69:
																									goto IL_0583;
																								case 75:
																									goto IL_05a6;
																								case 84:
																									goto IL_05b0;
																								case 97:
																									goto IL_05be;
																								case 7:
																								case 8:
																								case 10:
																								case 13:
																								case 19:
																								case 20:
																								case 24:
																								case 43:
																								case 50:
																								case 57:
																								case 59:
																								case 65:
																								case 71:
																								case 73:
																								case 76:
																								case 80:
																								case 85:
																								case 87:
																									goto end_IL_01f9;
																								case 18:
																								case 22:
																								case 29:
																								case 34:
																								case 35:
																								case 36:
																								case 42:
																								case 47:
																								case 56:
																								case 60:
																								case 64:
																								case 81:
																								case 98:
																									goto end_IL_0232;
																								case 95:
																									goto end_IL_05e1;
																								case 12:
																									goto end_IL_05f4;
																								case 30:
																									goto end_IL_05fe;
																								case 62:
																									goto end_IL_0612;
																								case 15:
																								case 49:
																									goto end_IL_0627;
																								case 88:
																									goto end_IL_0637;
																								case 11:
																								case 38:
																									goto end_IL_0647;
																								case 40:
																									goto end_IL_0657;
																								case 41:
																									goto end_IL_0667;
																								case 3:
																								case 44:
																									goto IL_0682;
																								}
																								continue;
																							}
																							goto IL_0575;
																							IL_05b0:
																							num5++;
																							goto IL_05be;
																							IL_05be:
																							ptr2 += 8;
																							goto end_IL_0232;
																							IL_0575:
																							array[num5] = 0;
																							goto IL_0583;
																							IL_0583:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05a6;
																							IL_05a6:
																							array2[num5] = null;
																							goto IL_05b0;
																							continue;
																							end_IL_01c9:
																							break;
																						}
																						goto IL_0501;
																					}
																					goto IL_0246;
																					IL_02fb:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0501;
																					IL_0501:
																					ptr2 += 8;
																					goto IL_050f;
																					IL_0246:
																					if (2 < b)
																					{
																						goto IL_0254;
																					}
																					goto IL_02dd;
																					IL_0254:
																					if (3 < b)
																					{
																						goto IL_02bc;
																					}
																					num = 66;
																					goto IL_0329;
																					IL_050f:
																					num5--;
																					goto end_IL_0232;
																					IL_0329:
																					if (3 > b)
																					{
																						goto end_IL_01f9;
																					}
																					goto IL_0453;
																					IL_0453:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0232;
																					IL_02bc:
																					if (4 < b)
																					{
																						goto end_IL_01f9;
																					}
																					goto IL_02ca;
																					IL_02ca:
																					if (4 > b)
																					{
																						goto end_IL_01f9;
																					}
																					goto end_IL_0232;
																					IL_02dd:
																					if (2 > b)
																					{
																						goto IL_02e8;
																					}
																					goto IL_02fb;
																					IL_02e8:
																					if (1 < b)
																					{
																						goto end_IL_01f9;
																					}
																					goto IL_0522;
																					IL_0522:
																					if (1 > b)
																					{
																						goto end_IL_01f9;
																					}
																					goto IL_0530;
																					IL_0530:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0549;
																					IL_0549:
																					array[num5] = 0;
																					goto IL_0557;
																					IL_0557:
																					num5++;
																					goto IL_0565;
																					IL_0565:
																					ptr2 += 8;
																					goto end_IL_0232;
																					continue;
																					end_IL_01dc:
																					break;
																				}
																				continue;
																			}
																			goto IL_026d;
																			IL_0440:
																			num5--;
																			goto end_IL_0232;
																			IL_026d:
																			if (8 < b)
																			{
																				goto IL_027b;
																			}
																			goto IL_033c;
																			IL_027b:
																			if (9 < b)
																			{
																				num = 21;
																				goto IL_0292;
																			}
																			goto IL_03c2;
																			IL_046b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04cd;
																			IL_0292:
																			if (10 < b)
																			{
																				goto end_IL_01f9;
																			}
																			num = 14;
																			goto IL_02a9;
																			IL_04cd:
																			num5 -= 2;
																			goto end_IL_0232;
																			IL_02a9:
																			if (10 > b)
																			{
																			}
																			goto end_IL_01f9;
																			IL_03c2:
																			if (9 > b)
																			{
																				goto end_IL_01f9;
																			}
																			goto IL_03d0;
																			IL_03d0:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0232;
																			IL_033c:
																			if (8 > b)
																			{
																				goto IL_034a;
																			}
																			goto IL_046b;
																			IL_034a:
																			if (6 < b)
																			{
																				goto IL_0355;
																			}
																			goto IL_0373;
																			IL_0355:
																			if (7 < b)
																			{
																				goto end_IL_01f9;
																			}
																			goto IL_0363;
																			IL_0363:
																			if (7 > b)
																			{
																				goto end_IL_01f9;
																			}
																			goto IL_0383;
																			IL_0383:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03a6;
																			IL_03a6:
																			array[num5] = 0;
																			num = 96;
																			goto IL_04e0;
																			IL_04e0:
																			num5++;
																			goto IL_04ee;
																			IL_04ee:
																			ptr2 += 8;
																			goto end_IL_0232;
																			IL_0373:
																			if (6 > b)
																			{
																				goto end_IL_01f9;
																			}
																			goto IL_03ec;
																			IL_03ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_042c;
																			IL_042c:
																			array[num5 - 2] = 0;
																			goto IL_0440;
																			continue;
																			end_IL_01ec:
																			break;
																		}
																		continue;
																		end_IL_01f9:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0232;
																continue;
																end_IL_0209:
																break;
															}
															continue;
															end_IL_0219:
															break;
														}
														continue;
														end_IL_0232:
														break;
													}
													continue;
												}
												goto IL_0682;
												IL_0682:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05e1:
												break;
											}
											continue;
											end_IL_05f4:
											break;
										}
										continue;
										end_IL_05fe:
										break;
									}
									continue;
									end_IL_0612:
									break;
								}
								continue;
								end_IL_0627:
								break;
							}
							continue;
							end_IL_0637:
							break;
						}
						continue;
						end_IL_0647:
						break;
					}
					continue;
					end_IL_0657:
					break;
				}
				continue;
				end_IL_0667:
				break;
			}
		}
	}

	static Class114()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 11;
			while (true)
			{
				if (num != 11)
				{
					if (num == 992)
					{
						switch (num)
						{
						default:
							continue;
						case 3:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 4:
							return;
						}
					}
					break;
				}
				Class300.smethod_0();
				return;
			}
		}
	}
}
