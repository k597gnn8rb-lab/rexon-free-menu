using System;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Server Sided Menu Button Sounds", "Room", "Other players hear your menu button clicks.", false, 9, ModType.const_0, false)]
internal class Class169 : MonoBehaviour
{
	private static bool bool_0;

	private static bool bool_1;

	private static int int_0;

	private static float float_0;

	private static int int_1;

	private static bool bool_2;

	private static float float_1;

	private static IntPtr[] MetadataSectionEntryFieldIdTrim;

	private static IntPtr[] ExistsStructureToPtr;

	private static IntPtr[] TokenVirtualizationAllowedSystemMaxDBCSCharSize;

	public unsafe static bool Enabled
	{
		get
		{
			int num = 41;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							num = 70;
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAbbreviatedMonthNamesInnerExceptions.getMemberNameStoreCategoryEnumeration);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_033e:
																	if (b >= 1)
																	{
																		num = 133;
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_0321:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0311:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0301:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02f1:
																										if (6 < b)
																										{
																											while (true)
																											{
																												IL_02de:
																												if (7 < b)
																												{
																													num = 168;
																													while (num != 168)
																													{
																														if (num != 1149)
																														{
																															goto end_IL_033e;
																														}
																														switch (num)
																														{
																														case 10:
																															goto IL_02de;
																														case 14:
																														case 36:
																															goto IL_02f1;
																														case 76:
																														case 126:
																															goto IL_0301;
																														case 47:
																															goto IL_0311;
																														case 82:
																															goto IL_0321;
																														case 133:
																															goto IL_032e;
																														case 88:
																															goto IL_033e;
																														case 13:
																															goto end_IL_033e;
																														case 67:
																														case 114:
																															goto end_IL_0351;
																														case 77:
																														case 91:
																															goto IL_036c;
																														case 19:
																															goto IL_0377;
																														case 120:
																															goto IL_0393;
																														case 73:
																														case 98:
																															goto IL_03a1;
																														case 121:
																															goto IL_03ef;
																														case 81:
																															goto IL_03fa;
																														case 106:
																															goto IL_0408;
																														case 9:
																															goto IL_0416;
																														case 85:
																														case 115:
																															goto IL_0424;
																														case 104:
																															goto IL_043d;
																														case 107:
																															goto IL_044b;
																														case 119:
																															goto IL_045e;
																														case 7:
																															goto IL_0469;
																														case 52:
																														case 86:
																															goto IL_0477;
																														case 96:
																															goto IL_049b;
																														case 31:
																															goto IL_04a9;
																														case 11:
																															goto IL_04b9;
																														case 68:
																															goto IL_04c7;
																														case 100:
																														case 135:
																															goto IL_04da;
																														case 140:
																															goto IL_04f2;
																														case 144:
																															goto IL_050b;
																														case 44:
																														case 145:
																															goto IL_051e;
																														case 55:
																															goto IL_0529;
																														case 132:
																														case 137:
																															goto IL_0537;
																														case 80:
																															goto IL_05a7;
																														case 51:
																															goto IL_05b5;
																														case 28:
																														case 102:
																															goto IL_05c3;
																														case 131:
																															goto IL_05d1;
																														case 45:
																															goto IL_05f5;
																														case 17:
																															goto IL_0603;
																														case 147:
																															goto IL_0616;
																														case 149:
																															goto IL_0629;
																														case 153:
																															goto IL_063c;
																														case 37:
																														case 78:
																															goto IL_064a;
																														case 117:
																															goto IL_068a;
																														case 143:
																															goto IL_069e;
																														case 56:
																														case 154:
																															goto IL_06b1;
																														case 123:
																															goto IL_06bf;
																														case 72:
																														case 105:
																															goto IL_06ca;
																														case 108:
																															goto IL_070a;
																														case 29:
																															goto IL_071e;
																														case 50:
																														case 155:
																															goto IL_073f;
																														case 27:
																															goto IL_074d;
																														case 101:
																														case 124:
																															goto IL_075b;
																														case 22:
																															goto IL_079b;
																														case 128:
																															goto IL_07af;
																														case 159:
																															goto IL_07c2;
																														case 4:
																														case 161:
																															goto IL_07d5;
																														case 24:
																															goto IL_07f1;
																														case 94:
																															goto IL_07ff;
																														case 43:
																														case 57:
																															goto IL_080a;
																														case 89:
																															goto IL_0818;
																														case 2:
																														case 113:
																															goto IL_0826;
																														case 49:
																															goto IL_084f;
																														case 26:
																															goto IL_085d;
																														case 48:
																															goto IL_0870;
																														case 21:
																														case 152:
																															goto IL_087b;
																														case 64:
																															goto IL_08c4;
																														case 12:
																															goto IL_08d8;
																														case 66:
																															goto IL_08eb;
																														case 62:
																															goto IL_08f9;
																														case 34:
																														case 103:
																															goto IL_0906;
																														case 158:
																															goto IL_091d;
																														case 142:
																															goto IL_0940;
																														case 125:
																															goto IL_094a;
																														case 23:
																															goto IL_0958;
																														case 3:
																														case 32:
																															goto IL_0968;
																														case 1:
																														case 15:
																														case 46:
																														case 54:
																														case 59:
																														case 61:
																														case 65:
																														case 69:
																														case 71:
																														case 83:
																														case 84:
																														case 87:
																														case 90:
																														case 92:
																														case 93:
																														case 97:
																														case 109:
																														case 110:
																														case 111:
																														case 118:
																														case 127:
																														case 129:
																														case 130:
																														case 134:
																														case 136:
																														case 141:
																														case 146:
																														case 148:
																														case 151:
																														case 156:
																															goto end_IL_02cb;
																														case 0:
																															goto IL_099a;
																														case 138:
																															goto IL_09b1;
																														case 38:
																															goto IL_09bf;
																														case 6:
																														case 8:
																														case 16:
																														case 18:
																														case 20:
																														case 30:
																														case 33:
																														case 39:
																														case 42:
																														case 53:
																														case 60:
																														case 63:
																														case 79:
																														case 95:
																														case 99:
																														case 116:
																														case 122:
																														case 139:
																														case 157:
																															goto end_IL_0361;
																														case 58:
																															goto end_IL_09cd;
																														case 25:
																															goto end_IL_09e0;
																														case 74:
																															goto end_IL_09ea;
																														case 35:
																														case 75:
																															goto end_IL_09f5;
																														case 70:
																															goto end_IL_0a05;
																														case 112:
																															goto end_IL_0a15;
																														case 160:
																															goto end_IL_0a25;
																														case 40:
																															goto end_IL_0a3e;
																														case 41:
																															goto end_IL_0a4e;
																														case 5:
																														case 150:
																															goto IL_0a69;
																														}
																														continue;
																														end_IL_02cb:
																														break;
																													}
																													break;
																												}
																												goto IL_0393;
																												IL_04f2:
																												array[num6 - 2] = 0;
																												goto IL_0616;
																												IL_0616:
																												num6--;
																												goto end_IL_0361;
																												IL_0393:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_03a1;
																												IL_03a1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												num = 140;
																												goto IL_04f2;
																											}
																											break;
																										}
																										goto IL_063c;
																										IL_07af:
																										num6--;
																										goto end_IL_0361;
																										IL_063c:
																										if (6 <= b)
																										{
																											goto IL_064a;
																										}
																										goto IL_073f;
																										IL_064a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_068a;
																										IL_068a:
																										array[num6 - 2] = 0;
																										goto IL_069e;
																										IL_069e:
																										num6--;
																										goto end_IL_0361;
																										IL_073f:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_074d;
																										IL_074d:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_075b;
																										IL_075b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_079b;
																										IL_079b:
																										array[num6 - 2] = 0;
																										goto IL_07af;
																									}
																									break;
																								}
																								goto IL_07f1;
																								IL_0958:
																								ptr2 += 8;
																								goto end_IL_0361;
																								IL_07f1:
																								if (4 > b)
																								{
																									goto IL_07ff;
																								}
																								goto IL_0906;
																								IL_07ff:
																								if (2 < b)
																								{
																									goto IL_080a;
																								}
																								goto IL_0870;
																								IL_080a:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0818;
																								IL_0818:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0826;
																								IL_0826:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_084f;
																								IL_084f:
																								ptr2 += 8;
																								goto IL_085d;
																								IL_085d:
																								num6--;
																								goto end_IL_0361;
																								IL_0870:
																								if (2 <= b)
																								{
																									goto IL_087b;
																								}
																								goto IL_08eb;
																								IL_087b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								num = 64;
																								goto IL_08c4;
																								IL_08c4:
																								array[num6 - 2] = 0;
																								goto IL_08d8;
																								IL_08d8:
																								num6--;
																								goto end_IL_0361;
																								IL_08eb:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_08f9;
																								IL_08f9:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0906:
																								array[num6] = 0;
																								num = 158;
																								goto IL_091d;
																								IL_091d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0940;
																								IL_0940:
																								array2[num6] = null;
																								goto IL_094a;
																								IL_094a:
																								num6++;
																								goto IL_0958;
																							}
																							break;
																						}
																						goto IL_0968;
																						IL_0968:
																						num6--;
																						num = 6;
																						goto end_IL_0361;
																					}
																					break;
																				}
																				goto IL_036c;
																				IL_04b9:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_04c7;
																				IL_036c:
																				if (12 >= b)
																				{
																					goto IL_0377;
																				}
																				goto IL_03ef;
																				IL_0377:
																				if (12 <= b)
																				{
																					goto end_IL_0361;
																				}
																				num = 145;
																				goto IL_051e;
																				IL_04c7:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_07d5;
																				IL_051e:
																				if (10 >= b)
																				{
																					goto IL_0529;
																				}
																				goto IL_05a7;
																				IL_0529:
																				if (10 <= b)
																				{
																					goto IL_0537;
																				}
																				goto IL_06b1;
																				IL_0537:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 149;
																				goto IL_0629;
																				IL_0629:
																				num6 -= 2;
																				goto end_IL_0361;
																				IL_06b1:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_06bf;
																				IL_06bf:
																				if (9 > b)
																				{
																					num = 92;
																					break;
																				}
																				goto IL_06ca;
																				IL_06ca:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_070a;
																				IL_070a:
																				array[num6 - 2] = 0;
																				goto IL_071e;
																				IL_071e:
																				num6--;
																				goto end_IL_0361;
																				IL_07d5:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0361;
																				IL_05a7:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_05b5;
																				IL_05b5:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_05c3;
																				IL_05c3:
																				array[num6] = 0;
																				goto IL_05d1;
																				IL_05d1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)MetadataSectionEntryFieldIdTrim[*(int*)(ptr2 + num3)])();
																				goto IL_05f5;
																				IL_05f5:
																				num6++;
																				goto IL_0603;
																				IL_0603:
																				ptr2 += 8;
																				goto end_IL_0361;
																				IL_03ef:
																				if (14 >= b)
																				{
																					goto IL_03fa;
																				}
																				goto IL_045e;
																				IL_03fa:
																				if (14 > b)
																				{
																					goto IL_0408;
																				}
																				goto IL_04da;
																				IL_0408:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0416;
																				IL_0416:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0424;
																				IL_0424:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_043d;
																				IL_043d:
																				array[num6] = 1;
																				goto IL_044b;
																				IL_044b:
																				num6++;
																				goto IL_07c2;
																				IL_07c2:
																				ptr2 += 16;
																				goto end_IL_0361;
																				IL_04da:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0361;
																				IL_045e:
																				if (15 >= b)
																				{
																					goto IL_0469;
																				}
																				goto IL_04b9;
																				IL_0469:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0477;
																				IL_0477:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)MetadataSectionEntryFieldIdTrim[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_049b;
																				IL_049b:
																				array[num6] = 0;
																				goto IL_04a9;
																				IL_04a9:
																				num6++;
																				goto IL_050b;
																				IL_050b:
																				ptr2 += 8;
																				goto end_IL_0361;
																			}
																			break;
																			IL_032e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_099a;
																	IL_09b1:
																	num6++;
																	goto IL_09bf;
																	IL_09bf:
																	ptr2 += 8;
																	goto end_IL_0361;
																	IL_099a:
																	array[num6] = 0;
																	num = 138;
																	goto IL_09b1;
																	continue;
																	end_IL_033e:
																	break;
																}
																continue;
																end_IL_0351:
																break;
															}
															continue;
															end_IL_0361:
															break;
														}
														continue;
													}
													goto IL_0a69;
													IL_0a69:
													return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
													continue;
													end_IL_09cd:
													break;
												}
												continue;
												end_IL_09e0:
												break;
											}
											continue;
											end_IL_09ea:
											break;
										}
										continue;
										end_IL_09f5:
										break;
									}
									continue;
									end_IL_0a05:
									break;
								}
								continue;
								end_IL_0a15:
								break;
							}
							continue;
							end_IL_0a25:
							break;
						}
						continue;
						end_IL_0a3e:
						break;
					}
					continue;
					end_IL_0a4e:
					break;
				}
			}
		}
		private set
		{
			int num = 123;
			int num5 = default(int);
			int num7 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								num = 111;
								while (true)
								{
									sbyte[] array3 = new sbyte[1];
									while (true)
									{
										int[] array4 = new int[6];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NumDatesepInit.GetSignatureSpinWait);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																num = 163;
																while (true)
																{
																	if (num != 163)
																	{
																		if (num != 1144)
																		{
																			goto IL_08d6;
																		}
																		switch (num)
																		{
																		case 21:
																		case 97:
																			goto end_IL_029b;
																		case 85:
																			goto IL_02cd;
																		case 15:
																			goto IL_02db;
																		case 112:
																			goto IL_02e9;
																		case 91:
																			goto IL_02f7;
																		case 35:
																		case 93:
																			goto IL_0302;
																		case 48:
																			goto IL_0315;
																		case 151:
																		case 153:
																			goto IL_0323;
																		case 63:
																			goto IL_0331;
																		case 54:
																		case 83:
																			goto IL_033f;
																		case 25:
																			goto IL_034d;
																		case 8:
																		case 56:
																			goto IL_035b;
																		case 118:
																			goto IL_039b;
																		case 37:
																			goto IL_03af;
																		case 65:
																		case 73:
																			goto IL_03c2;
																		case 108:
																			goto IL_0402;
																		case 39:
																			goto IL_0416;
																		case 136:
																			goto IL_0429;
																		case 103:
																			goto IL_0437;
																		case 47:
																		case 74:
																			goto IL_0445;
																		case 121:
																			goto IL_0485;
																		case 113:
																			goto IL_0499;
																		case 129:
																			goto IL_04ac;
																		case 84:
																			goto IL_04ba;
																		case 96:
																		case 141:
																			goto IL_04c5;
																		case 127:
																			goto IL_04d3;
																		case 46:
																		case 107:
																			goto IL_04e1;
																		case 26:
																			goto IL_0513;
																		case 87:
																			goto IL_0521;
																		case 78:
																			goto IL_0534;
																		case 17:
																		case 50:
																			goto IL_053f;
																		case 88:
																			goto IL_054d;
																		case 117:
																		case 128:
																			goto IL_0560;
																		case 59:
																			goto IL_05a0;
																		case 32:
																			goto IL_05b4;
																		case 42:
																		case 149:
																			goto IL_05d0;
																		case 71:
																			goto IL_05de;
																		case 27:
																			goto IL_0601;
																		case 152:
																			goto IL_060b;
																		case 41:
																			goto IL_0619;
																		case 44:
																			goto IL_062c;
																		case 64:
																			goto IL_063a;
																		case 18:
																		case 45:
																			goto IL_0645;
																		case 95:
																			goto IL_065e;
																		case 3:
																			goto IL_066c;
																		case 76:
																			goto IL_067a;
																		case 144:
																			goto IL_068d;
																		case 53:
																			goto IL_069b;
																		case 79:
																		case 81:
																			goto IL_06a6;
																		case 115:
																			goto IL_0708;
																		case 139:
																			goto IL_071b;
																		case 132:
																			goto IL_0729;
																		case 28:
																		case 155:
																			goto IL_0737;
																		case 68:
																			goto IL_0777;
																		case 5:
																			goto IL_078b;
																		case 51:
																		case 137:
																			goto IL_07a7;
																		case 58:
																			goto IL_07b5;
																		case 69:
																			goto IL_07c8;
																		case 116:
																			goto IL_07d6;
																		case 12:
																		case 147:
																			goto IL_07e1;
																		case 99:
																			goto IL_07ef;
																		case 80:
																		case 89:
																			goto IL_07fd;
																		case 43:
																		case 130:
																			goto IL_0815;
																		case 133:
																			goto IL_0838;
																		case 19:
																			goto IL_0846;
																		case 14:
																			goto IL_0854;
																		case 126:
																			goto IL_0867;
																		case 154:
																			goto IL_0872;
																		case 67:
																		case 72:
																			goto IL_087d;
																		case 156:
																			goto IL_0897;
																		case 145:
																			goto IL_08a7;
																		case 24:
																			goto IL_08b2;
																		case 16:
																		case 109:
																			goto IL_08bd;
																		case 2:
																		case 4:
																		case 7:
																		case 9:
																		case 10:
																		case 29:
																		case 30:
																		case 36:
																		case 40:
																		case 52:
																		case 55:
																		case 60:
																		case 70:
																		case 77:
																		case 82:
																		case 86:
																		case 90:
																		case 92:
																		case 94:
																		case 100:
																		case 105:
																		case 114:
																		case 125:
																		case 135:
																		case 138:
																		case 140:
																		case 142:
																			goto IL_08d6;
																		case 0:
																			goto IL_08ef;
																		case 120:
																			goto IL_0906;
																		case 57:
																			goto IL_0914;
																		case 1:
																		case 6:
																		case 11:
																		case 13:
																		case 22:
																		case 33:
																		case 38:
																		case 49:
																		case 66:
																		case 75:
																		case 98:
																		case 106:
																		case 110:
																		case 124:
																		case 131:
																		case 134:
																		case 143:
																		case 146:
																		case 148:
																			goto end_IL_02ab;
																		case 31:
																			goto end_IL_0922;
																		case 101:
																			goto end_IL_0935;
																		case 23:
																			goto end_IL_093f;
																		case 119:
																			goto end_IL_094a;
																		case 20:
																			goto end_IL_095f;
																		case 102:
																		case 111:
																			goto end_IL_096f;
																		case 34:
																			goto end_IL_097f;
																		case 61:
																			goto end_IL_098f;
																		case 150:
																			goto end_IL_09a8;
																		case 122:
																			goto end_IL_09b8;
																		case 123:
																			goto end_IL_09c8;
																		case 62:
																		case 104:
																			return;
																		}
																		continue;
																	}
																	ptr2++;
																	goto IL_02cd;
																	IL_08bd:
																	byte* num6 = ptr2;
																	num5 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_02ab;
																	IL_08ef:
																	array[num7] = 0;
																	num = 120;
																	goto IL_0906;
																	IL_08d6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(int*)(ptr2 + num3);
																	goto IL_08ef;
																	IL_02cd:
																	if (b >= 1)
																	{
																		goto IL_02db;
																	}
																	goto IL_08d6;
																	IL_02db:
																	if (b <= 16)
																	{
																		goto IL_02e9;
																	}
																	goto IL_08d6;
																	IL_02e9:
																	if (8 >= b)
																	{
																		goto IL_02f7;
																	}
																	goto IL_062c;
																	IL_02f7:
																	if (8 <= b)
																	{
																		goto IL_0302;
																	}
																	goto IL_0315;
																	IL_0302:
																	num7--;
																	goto end_IL_02ab;
																	IL_0315:
																	if (4 < b)
																	{
																		goto IL_0323;
																	}
																	goto IL_04ac;
																	IL_0323:
																	if (6 >= b)
																	{
																		goto IL_0331;
																	}
																	goto IL_0429;
																	IL_0331:
																	if (6 > b)
																	{
																		goto IL_033f;
																	}
																	goto IL_03c2;
																	IL_033f:
																	if (5 >= b)
																	{
																		goto IL_034d;
																	}
																	goto IL_08d6;
																	IL_034d:
																	if (5 <= b)
																	{
																		goto IL_035b;
																	}
																	goto IL_08d6;
																	IL_035b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	goto IL_039b;
																	IL_039b:
																	array[num7 - 2] = 0;
																	goto IL_03af;
																	IL_03af:
																	num7--;
																	goto end_IL_02ab;
																	IL_03c2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	goto IL_0402;
																	IL_0402:
																	array[num7 - 2] = 0;
																	goto IL_0416;
																	IL_0416:
																	num7--;
																	goto end_IL_02ab;
																	IL_0429:
																	if (7 >= b)
																	{
																		goto IL_0437;
																	}
																	goto IL_08d6;
																	IL_0437:
																	if (7 <= b)
																	{
																		goto IL_0445;
																	}
																	goto IL_08d6;
																	IL_0445:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	goto IL_0485;
																	IL_0485:
																	array[num7 - 2] = 0;
																	goto IL_0499;
																	IL_0499:
																	num7--;
																	goto end_IL_02ab;
																	IL_04ac:
																	if (4 > b)
																	{
																		goto IL_04ba;
																	}
																	num = 42;
																	goto IL_05d0;
																	IL_04ba:
																	if (2 < b)
																	{
																		goto IL_04c5;
																	}
																	goto IL_0534;
																	IL_04c5:
																	if (3 >= b)
																	{
																		goto IL_04d3;
																	}
																	goto IL_08d6;
																	IL_04d3:
																	if (3 <= b)
																	{
																		goto IL_04e1;
																	}
																	goto IL_08d6;
																	IL_04e1:
																	ref int reference = ref array4[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	num = 26;
																	goto IL_0513;
																	IL_0513:
																	ptr2 += 8;
																	goto IL_0521;
																	IL_0521:
																	num7--;
																	goto end_IL_02ab;
																	IL_0534:
																	if (2 > b)
																	{
																		goto IL_053f;
																	}
																	goto IL_0560;
																	IL_053f:
																	if (1 >= b)
																	{
																		goto IL_054d;
																	}
																	goto IL_08d6;
																	IL_054d:
																	if (1 > b)
																	{
																	}
																	goto IL_08d6;
																	IL_0560:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	goto IL_05a0;
																	IL_05a0:
																	array[num7 - 2] = 0;
																	goto IL_05b4;
																	IL_05b4:
																	num7--;
																	goto end_IL_02ab;
																	IL_0906:
																	num7++;
																	goto IL_0914;
																	IL_05d0:
																	array[num7] = 0;
																	goto IL_05de;
																	IL_05de:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = array4[*(int*)(ptr2 + num3)];
																	goto IL_0601;
																	IL_0601:
																	array2[num7] = null;
																	goto IL_060b;
																	IL_060b:
																	num7++;
																	goto IL_0619;
																	IL_0619:
																	ptr2 += 8;
																	goto end_IL_02ab;
																	IL_062c:
																	if (12 >= b)
																	{
																		goto IL_063a;
																	}
																	goto IL_07c8;
																	IL_063a:
																	if (12 <= b)
																	{
																		goto IL_0645;
																	}
																	goto IL_068d;
																	IL_0645:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(long*)(ptr2 + num4);
																	goto IL_065e;
																	IL_065e:
																	array[num7] = 1;
																	goto IL_066c;
																	IL_066c:
																	num7++;
																	goto IL_067a;
																	IL_067a:
																	ptr2 += 16;
																	goto end_IL_02ab;
																	IL_068d:
																	if (10 >= b)
																	{
																		goto IL_069b;
																	}
																	num = 51;
																	goto IL_07a7;
																	IL_069b:
																	if (10 <= b)
																	{
																		goto IL_06a6;
																	}
																	goto IL_071b;
																	IL_06a6:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0708;
																	IL_0708:
																	num7 -= 2;
																	goto end_IL_02ab;
																	IL_071b:
																	if (9 >= b)
																	{
																		goto IL_0729;
																	}
																	goto IL_08d6;
																	IL_0729:
																	if (9 <= b)
																	{
																		goto IL_0737;
																	}
																	goto IL_08d6;
																	IL_0737:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																	goto IL_0777;
																	IL_0777:
																	array[num7 - 2] = 0;
																	goto IL_078b;
																	IL_078b:
																	num7--;
																	goto end_IL_02ab;
																	IL_0914:
																	ptr2 += 8;
																	goto end_IL_02ab;
																	IL_07a7:
																	if (11 >= b)
																	{
																		goto IL_07b5;
																	}
																	goto IL_08d6;
																	IL_07b5:
																	if (11 <= b)
																	{
																		goto end_IL_02ab;
																	}
																	goto IL_08d6;
																	IL_07c8:
																	if (14 >= b)
																	{
																		goto IL_07d6;
																	}
																	goto IL_0867;
																	IL_07d6:
																	if (14 > b)
																	{
																		goto IL_07e1;
																	}
																	goto IL_0815;
																	IL_07e1:
																	if (13 >= b)
																	{
																		goto IL_07ef;
																	}
																	goto IL_08d6;
																	IL_07ef:
																	if (13 <= b)
																	{
																		goto IL_07fd;
																	}
																	goto IL_08d6;
																	IL_07fd:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02ab;
																	IL_0815:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0838;
																	IL_0838:
																	array[num7] = 0;
																	goto IL_0846;
																	IL_0846:
																	num7++;
																	goto IL_0854;
																	IL_0854:
																	ptr2 += 8;
																	goto end_IL_02ab;
																	IL_0867:
																	if (15 >= b)
																	{
																		goto IL_0872;
																	}
																	goto IL_08a7;
																	IL_0872:
																	if (15 <= b)
																	{
																		goto IL_087d;
																	}
																	goto IL_08d6;
																	IL_087d:
																	bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])) != 0;
																	goto IL_0897;
																	IL_0897:
																	num7--;
																	goto end_IL_02ab;
																	IL_08a7:
																	if (16 >= b)
																	{
																		goto IL_08b2;
																	}
																	goto IL_08d6;
																	IL_08b2:
																	if (16 <= b)
																	{
																		goto IL_08bd;
																	}
																	goto IL_08d6;
																	continue;
																	end_IL_029b:
																	break;
																}
																continue;
																end_IL_02ab:
																break;
															}
															continue;
															end_IL_0922:
															break;
														}
														continue;
														end_IL_0935:
														break;
													}
													continue;
													end_IL_093f:
													break;
												}
												continue;
												end_IL_094a:
												break;
											}
											continue;
											end_IL_095f:
											break;
										}
										continue;
										end_IL_096f:
										break;
									}
									continue;
									end_IL_097f:
									break;
								}
								continue;
								end_IL_098f:
								break;
							}
							continue;
							end_IL_09a8:
							break;
						}
						continue;
						end_IL_09b8:
						break;
					}
					continue;
					end_IL_09c8:
					break;
				}
			}
		}
	}

	private void OnEnable()
	{
		AllLocalFilesIClosable(bool_3: true);
	}

	private void OnDisable()
	{
		getReferenceIdentityDemanded(bool_3: false);
	}

	public static void smethod_0(bool bool_3)
	{
		int num = 175;
		num = 35;
		num = 242;
		num = 22;
		num = 35;
		num = 53;
		num = 55;
		num = 55;
		num = 638;
		num = 58;
		num = 553;
		num = 79;
		num = 58;
		num = 137;
		num = 4463;
		num = 4463;
		num = 4518;
		num = 366;
		num = 183;
		object obj = "p";
		object obj2 = obj;
		obj = "d";
		object obj3 = obj;
		obj = "_";
		object obj4 = obj;
		obj = "l";
		object obj5 = obj;
		obj = "R";
		object obj6 = obj;
		obj = "C";
		object obj7 = obj;
		obj = "P";
		object obj8 = obj;
		obj = "n";
		object obj9 = obj;
		obj = "a";
		object obj10 = obj;
		obj = "H";
		object obj11 = obj;
		obj = "y";
		object obj12 = obj;
		obj = "T";
		object obj13 = obj;
		num = 105;
		num = 15;
		obj = new string[15];
		object obj14 = obj;
		object obj15 = obj6;
		((string[])obj14)[0] = (string)obj15;
		obj14 = obj;
		obj15 = obj8;
		((string[])obj14)[1] = (string)obj15;
		obj14 = obj;
		int num2 = 11;
		obj15 = obj7;
		((string[])obj14)[2] = (string)obj15;
		obj14 = obj;
		num2 = 11;
		obj15 = obj4;
		((string[])obj14)[3] = (string)obj15;
		obj14 = obj;
		num2 = 11;
		obj15 = obj8;
		((string[])obj14)[4] = (string)obj15;
		obj14 = obj;
		num2 = 4;
		obj15 = obj5;
		((string[])obj14)[5] = (string)obj15;
		obj14 = obj;
		num2 = 2;
		obj15 = obj10;
		((string[])obj14)[6] = (string)obj15;
		obj14 = obj;
		num2 = 4;
		obj15 = obj12;
		((string[])obj14)[7] = (string)obj15;
		obj14 = obj;
		num2 = 13;
		obj15 = obj11;
		((string[])obj14)[8] = (string)obj15;
		obj14 = obj;
		num2 = 3;
		obj15 = obj10;
		((string[])obj14)[9] = (string)obj15;
		obj14 = obj;
		num2 = 11;
		obj15 = obj9;
		((string[])obj14)[10] = (string)obj15;
		obj14 = obj;
		num2 = 13;
		obj15 = obj3;
		((string[])obj14)[11] = (string)obj15;
		obj14 = obj;
		num2 = 3;
		obj15 = obj13;
		((string[])obj14)[12] = (string)obj15;
		obj14 = obj;
		num2 = 3;
		obj15 = obj10;
		((string[])obj14)[13] = (string)obj15;
		obj14 = obj;
		num2 = 11;
		obj15 = obj2;
		((string[])obj14)[14] = (string)obj15;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj16 = obj;
		if (!Enabled)
		{
			return;
		}
		GorillaTagger instance = GorillaTagger.Instance;
		obj = instance;
		obj14 = null;
		if ((GorillaTagger)obj == (UnityEngine.Object)obj14)
		{
			return;
		}
		GorillaTagger instance2 = GorillaTagger.Instance;
		obj = instance2;
		NetworkView myVRRig = ((GorillaTagger)obj).myVRRig;
		obj = myVRRig;
		obj14 = null;
		if ((UnityEngine.Object)(object)(NetworkView)obj == (UnityEngine.Object)obj14)
		{
			return;
		}
		try
		{
			GorillaTagger instance3 = GorillaTagger.Instance;
			obj = instance3;
			NetworkView myVRRig2 = ((GorillaTagger)obj).myVRRig;
			obj = myVRRig2;
			PhotonView getView = ((NetworkView)obj).GetView;
			obj = getView;
			obj14 = obj16;
			double num3 = 2.929262798332297;
			double d = 1.5;
			double num4 = Math.Cos(d);
			d = num4;
			num3 += d;
			int num5 = Convert.ToInt32(num3);
			num2 = num5;
			obj15 = new object[num2];
			object obj17 = obj15;
			int num6 = 0;
			double num7 = 106.43115819671957;
			double a = 53.0;
			double num8 = Math.Tan(a);
			a = num8;
			num7 += a;
			int num9 = Convert.ToInt32(num7);
			int num10 = num9;
			object obj18 = num10;
			((object[])obj17)[0] = obj18;
			obj17 = obj15;
			num6 = 1;
			num10 = (bool_3 ? 1 : 0);
			obj18 = (byte)num10 != 0;
			((object[])obj17)[1] = obj18;
			obj17 = obj15;
			double num11 = 1.0;
			num7 = 1.0;
			double num12 = Math.Round(num7);
			num7 = num12;
			num11 += num7;
			int num13 = Convert.ToInt32(num11);
			num6 = num13;
			num7 = 1000.0;
			obj18 = (float)num7;
			((object[])obj17)[num6] = obj18;
			num = (((PhotonView)obj).smethod_3((string)obj14, RpcTarget.All, (object[])obj15) ? 1 : 0);
			Class9.smethod_82();
		}
		catch
		{
		}
	}

	public Class169()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_1()
	{
		int num = 12;
		int num2 = 3;
		num = 4;
		object obj = new int[4];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 22;
		num3 = 2;
		((int[])obj)[0] = 2;
		obj = obj2;
		num2 = 1;
		num3 = 429;
		num3 = 39;
		((int[])obj)[1] = 39;
		obj = obj2;
		num2 = 14;
		num3 = 7;
		num2 = 2;
		num3 = 48;
		num3 = 24;
		((int[])obj)[2] = 24;
		obj = obj2;
		num2 = 9;
		num3 = 3;
		num2 = 3;
		num3 = 259;
		num3 = 37;
		((int[])obj)[3] = 37;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 44;
			num3 = 11;
			num2 = 4;
			if (num >= 4)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 40;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ConvRUnObjectUri.DeclaringTypeSecurityContext);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0241:
															byte b = *ptr2;
															num = 28;
															while (true)
															{
																IL_0231:
																ptr2++;
																while (true)
																{
																	IL_0221:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0204:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01f4:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01e4:
																								if (7 < b)
																								{
																									while (8 >= b)
																									{
																										while (8 <= b)
																										{
																											while (true)
																											{
																												IL_01a2:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												num = 96;
																												while (num != 96)
																												{
																													if (num != 1077)
																													{
																														goto end_IL_01c4;
																													}
																													switch (num)
																													{
																													case 4:
																													case 25:
																														goto IL_01a2;
																													case 11:
																														goto IL_01c4;
																													case 75:
																														goto IL_01d4;
																													case 34:
																													case 54:
																														goto IL_01e4;
																													case 87:
																														goto IL_01f4;
																													case 35:
																														goto IL_0204;
																													case 42:
																														goto IL_0211;
																													case 57:
																														goto IL_0221;
																													case 28:
																														goto IL_0231;
																													case 2:
																													case 78:
																														goto IL_0241;
																													case 69:
																														goto IL_0255;
																													case 13:
																													case 19:
																														goto IL_0260;
																													case 63:
																														goto IL_028e;
																													case 58:
																														goto IL_029c;
																													case 44:
																													case 68:
																														goto IL_02aa;
																													case 46:
																														goto IL_0318;
																													case 5:
																														goto IL_032b;
																													case 16:
																														goto IL_0339;
																													case 81:
																														goto IL_034c;
																													case 17:
																														goto IL_035a;
																													case 49:
																													case 76:
																														goto IL_0368;
																													case 20:
																														goto IL_03a8;
																													case 1:
																														goto IL_03bc;
																													case 86:
																														goto IL_03cf;
																													case 79:
																														goto IL_03dd;
																													case 9:
																														goto IL_0402;
																													case 6:
																													case 77:
																														goto IL_0410;
																													case 18:
																														goto IL_041e;
																													case 0:
																														goto IL_0441;
																													case 33:
																														goto IL_044b;
																													case 51:
																														goto IL_0459;
																													case 84:
																														goto IL_046c;
																													case 32:
																													case 45:
																														goto IL_047a;
																													case 59:
																														goto IL_0485;
																													case 37:
																													case 70:
																														goto IL_0490;
																													case 14:
																													case 21:
																													case 23:
																													case 24:
																													case 30:
																													case 36:
																													case 43:
																													case 47:
																													case 52:
																													case 55:
																													case 60:
																													case 61:
																													case 66:
																													case 71:
																													case 72:
																													case 74:
																													case 82:
																													case 85:
																													case 89:
																														goto end_IL_01c4;
																													case 27:
																														goto IL_04c8;
																													case 56:
																														goto IL_04d6;
																													case 88:
																														goto IL_04e4;
																													case 3:
																													case 29:
																													case 41:
																													case 50:
																													case 53:
																													case 62:
																													case 64:
																													case 67:
																													case 73:
																													case 80:
																														goto end_IL_018f;
																													case 48:
																														goto end_IL_04fb;
																													case 7:
																														goto end_IL_050e;
																													case 22:
																														goto end_IL_0518;
																													case 15:
																														goto end_IL_0523;
																													case 10:
																														goto end_IL_0538;
																													case 26:
																													case 31:
																														goto end_IL_054d;
																													case 65:
																														goto end_IL_055d;
																													case 8:
																													case 12:
																														goto end_IL_056d;
																													case 39:
																														goto end_IL_057d;
																													case 40:
																														goto end_IL_058d;
																													case 38:
																													case 83:
																														goto IL_05a8;
																													}
																													continue;
																													end_IL_018f:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0221;
																											continue;
																											end_IL_01c4:
																											break;
																											IL_01c4:;
																										}
																										break;
																										IL_01d4:;
																									}
																									break;
																								}
																								num = 9;
																								goto IL_0402;
																								IL_044b:
																								num6++;
																								goto IL_0459;
																								IL_0459:
																								ptr2 += 8;
																								goto end_IL_0221;
																								IL_0402:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0410;
																								IL_0410:
																								array[num6] = 0;
																								goto IL_041e;
																								IL_041e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0441;
																								IL_0441:
																								array2[num6] = null;
																								goto IL_044b;
																							}
																							break;
																						}
																						goto IL_046c;
																						IL_0490:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0221;
																						IL_046c:
																						if (6 <= b)
																						{
																							goto end_IL_0221;
																						}
																						goto IL_047a;
																						IL_047a:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0485;
																						IL_0485:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0490;
																					}
																					break;
																				}
																				goto IL_0255;
																				IL_03bc:
																				num6--;
																				goto end_IL_0221;
																				IL_0255:
																				if (4 <= b)
																				{
																					goto IL_0260;
																				}
																				goto IL_028e;
																				IL_0260:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_03cf;
																				IL_03cf:
																				ptr2 += 8;
																				goto IL_03dd;
																				IL_03dd:
																				num6--;
																				num = 64;
																				goto end_IL_0221;
																				IL_028e:
																				if (2 >= b)
																				{
																					goto IL_029c;
																				}
																				goto IL_034c;
																				IL_029c:
																				if (2 <= b)
																				{
																					goto IL_02aa;
																				}
																				goto IL_032b;
																				IL_02aa:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0318;
																				IL_0318:
																				num6 -= 2;
																				goto end_IL_0221;
																				IL_032b:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0339;
																				IL_0339:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_034c:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_035a;
																				IL_035a:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0368;
																				IL_0368:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_03a8;
																				IL_03a8:
																				array[num6 - 2] = 0;
																				goto IL_03bc;
																			}
																			break;
																			IL_0211:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c8;
																	IL_04e4:
																	ptr2 += 8;
																	num = 67;
																	break;
																	IL_04d6:
																	num6++;
																	goto IL_04e4;
																	IL_04c8:
																	array[num6] = 0;
																	goto IL_04d6;
																	continue;
																	end_IL_0221:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a8;
													IL_05a8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04fb:
													break;
												}
												continue;
												end_IL_050e:
												break;
											}
											continue;
											end_IL_0518:
											break;
										}
										continue;
										end_IL_0523:
										break;
									}
									continue;
									end_IL_0538:
									break;
								}
								continue;
								end_IL_054d:
								break;
							}
							continue;
							end_IL_055d:
							break;
						}
						continue;
						end_IL_056d:
						break;
					}
					continue;
					end_IL_057d:
					break;
				}
				continue;
				end_IL_058d:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CompletegetSetMethod.ITokenReaderIProgIdRedirectionEntry);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0374:
														byte b = *ptr2;
														while (true)
														{
															IL_0364:
															ptr2++;
															while (true)
															{
																IL_0354:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0334:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0317:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_0307:
																								if (4 <= b)
																								{
																									while (true)
																									{
																										IL_02e7:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										while (true)
																										{
																											IL_02ce:
																											ptr2 += 8;
																											num = 171;
																											while (true)
																											{
																												if (num != 171)
																												{
																													if (num != 1152)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 164:
																														goto IL_02ce;
																													case 122:
																													case 142:
																														goto IL_02e7;
																													case 125:
																														goto IL_0307;
																													case 32:
																														goto IL_0317;
																													case 51:
																														goto IL_0324;
																													case 94:
																														goto IL_0334;
																													case 120:
																														goto IL_0344;
																													case 29:
																														goto IL_0354;
																													case 5:
																														goto IL_0364;
																													case 111:
																													case 160:
																														goto IL_0374;
																													case 132:
																													case 145:
																														goto IL_037f;
																													case 106:
																														goto IL_038d;
																													case 9:
																													case 103:
																														goto IL_0398;
																													case 90:
																														goto IL_03a6;
																													case 17:
																													case 104:
																														goto IL_03bd;
																													case 110:
																														goto IL_03cb;
																													case 137:
																														goto IL_03e3;
																													case 38:
																													case 44:
																														goto IL_03f6;
																													case 74:
																														goto IL_0435;
																													case 45:
																													case 156:
																														goto IL_0448;
																													case 21:
																													case 134:
																														goto IL_0453;
																													case 53:
																														goto IL_0461;
																													case 46:
																													case 72:
																														goto IL_046f;
																													case 26:
																														goto IL_04a1;
																													case 130:
																														goto IL_04ba;
																													case 86:
																													case 92:
																														goto IL_04c5;
																													case 16:
																														goto IL_04d3;
																													case 65:
																													case 95:
																														goto IL_04e1;
																													case 19:
																														goto IL_04fa;
																													case 68:
																														goto IL_0508;
																													case 37:
																														goto IL_0516;
																													case 97:
																													case 153:
																														goto IL_0529;
																													case 139:
																														goto IL_0569;
																													case 115:
																														goto IL_0586;
																													case 157:
																														goto IL_0599;
																													case 158:
																														goto IL_05b5;
																													case 34:
																													case 135:
																														goto IL_05c0;
																													case 144:
																														goto IL_05d0;
																													case 91:
																													case 121:
																														goto IL_05de;
																													case 108:
																														goto IL_0610;
																													case 87:
																														goto IL_061e;
																													case 159:
																														goto IL_0631;
																													case 77:
																													case 124:
																														goto IL_063c;
																													case 73:
																														goto IL_0675;
																													case 66:
																														goto IL_0683;
																													case 36:
																													case 113:
																														goto IL_068e;
																													case 25:
																														goto IL_06f0;
																													case 99:
																														goto IL_0703;
																													case 84:
																														goto IL_0711;
																													case 131:
																													case 136:
																														goto IL_071c;
																													case 18:
																														goto IL_0760;
																													case 133:
																														goto IL_0774;
																													case 154:
																														goto IL_0787;
																													case 163:
																														goto IL_0795;
																													case 88:
																													case 161:
																														goto IL_07a3;
																													case 107:
																														goto IL_07b1;
																													case 57:
																														goto IL_07dd;
																													case 41:
																														goto IL_07e7;
																													case 58:
																														goto end_IL_02bb;
																													case 4:
																													case 149:
																														goto IL_0808;
																													case 48:
																														goto IL_0816;
																													case 63:
																													case 83:
																														goto IL_0824;
																													case 146:
																														goto IL_0864;
																													case 1:
																														goto IL_0878;
																													case 123:
																														goto IL_0894;
																													case 55:
																														goto IL_08a2;
																													case 28:
																													case 75:
																														goto IL_08ad;
																													case 126:
																														goto IL_08c0;
																													case 98:
																														goto IL_08ce;
																													case 62:
																													case 112:
																														goto IL_08dc;
																													case 67:
																														goto IL_08f9;
																													case 23:
																														goto IL_0938;
																													case 0:
																													case 152:
																														goto IL_0948;
																													case 60:
																														goto IL_0953;
																													case 10:
																													case 20:
																														goto IL_095e;
																													case 102:
																														goto IL_0977;
																													case 148:
																														goto IL_0982;
																													case 3:
																													case 6:
																													case 7:
																													case 8:
																													case 11:
																													case 14:
																													case 22:
																													case 27:
																													case 35:
																													case 39:
																													case 40:
																													case 43:
																													case 47:
																													case 54:
																													case 59:
																													case 61:
																													case 64:
																													case 70:
																													case 71:
																													case 82:
																													case 85:
																													case 89:
																													case 100:
																													case 118:
																													case 119:
																													case 128:
																													case 129:
																													case 138:
																													case 150:
																													case 151:
																													case 155:
																														goto end_IL_0344;
																													case 2:
																													case 24:
																													case 30:
																													case 31:
																													case 33:
																													case 42:
																													case 49:
																													case 50:
																													case 52:
																													case 69:
																													case 80:
																													case 81:
																													case 93:
																													case 96:
																													case 101:
																													case 105:
																													case 114:
																													case 127:
																													case 140:
																													case 162:
																														goto end_IL_0324;
																													case 76:
																														goto end_IL_09a0;
																													case 117:
																														goto end_IL_09b3;
																													case 56:
																														goto end_IL_09bd;
																													case 141:
																														goto end_IL_09c8;
																													case 12:
																													case 116:
																														goto end_IL_09d8;
																													case 109:
																														goto end_IL_09e8;
																													case 13:
																													case 143:
																														goto end_IL_09f8;
																													case 78:
																														goto end_IL_0a08;
																													case 79:
																														goto end_IL_0a18;
																													case 15:
																													case 147:
																														goto IL_0a33;
																													}
																													continue;
																												}
																												num5--;
																												goto end_IL_0324;
																												continue;
																												end_IL_02bb:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0448;
																								IL_0586:
																								num5--;
																								goto end_IL_0324;
																								IL_0448:
																								if (2 < b)
																								{
																									goto IL_0453;
																								}
																								goto IL_04ba;
																								IL_0453:
																								if (3 < b)
																								{
																									goto end_IL_0344;
																								}
																								goto IL_0461;
																								IL_0461:
																								if (3 > b)
																								{
																									goto end_IL_0344;
																								}
																								goto IL_046f;
																								IL_046f:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								num = 26;
																								goto IL_04a1;
																								IL_04a1:
																								array[num5 - 1] = 5;
																								goto end_IL_0324;
																								IL_04ba:
																								if (2 > b)
																								{
																									goto IL_04c5;
																								}
																								goto IL_0529;
																								IL_04c5:
																								if (1 < b)
																								{
																									goto end_IL_0344;
																								}
																								goto IL_04d3;
																								IL_04d3:
																								if (1 > b)
																								{
																									goto end_IL_0344;
																								}
																								goto IL_04e1;
																								IL_04e1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_04fa;
																								IL_04fa:
																								array[num5] = 0;
																								goto IL_0508;
																								IL_0508:
																								num5++;
																								goto IL_0516;
																								IL_0516:
																								ptr2 += 8;
																								goto end_IL_0324;
																								IL_0529:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0569;
																								IL_0569:
																								array[num5 - 2] = 0;
																								num = 115;
																								goto IL_0586;
																							}
																							break;
																						}
																						goto IL_037f;
																						IL_05de:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 108;
																						goto IL_0610;
																						IL_037f:
																						if (6 >= b)
																						{
																							goto IL_038d;
																						}
																						goto IL_05b5;
																						IL_038d:
																						if (6 > b)
																						{
																							goto IL_0398;
																						}
																						goto IL_03f6;
																						IL_0398:
																						if (5 < b)
																						{
																							goto end_IL_0344;
																						}
																						goto IL_03a6;
																						IL_03a6:
																						if (5 > b)
																						{
																							goto end_IL_0344;
																						}
																						num = 17;
																						goto IL_03bd;
																						IL_0610:
																						ptr2 += 8;
																						goto IL_061e;
																						IL_03bd:
																						array[num5] = 5;
																						goto IL_03cb;
																						IL_03cb:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_03e3;
																						IL_03e3:
																						num5++;
																						goto IL_0599;
																						IL_0599:
																						ptr2 += 8;
																						num = 80;
																						goto end_IL_0324;
																						IL_03f6:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0435;
																						IL_0435:
																						num5 -= 3;
																						goto end_IL_0324;
																						IL_05b5:
																						if (7 < b)
																						{
																							goto IL_05c0;
																						}
																						goto IL_05d0;
																						IL_05c0:
																						if (8 < b)
																						{
																							goto end_IL_0344;
																						}
																						goto IL_0631;
																						IL_0631:
																						if (8 > b)
																						{
																							num = 39;
																							goto end_IL_0344;
																						}
																						goto IL_063c;
																						IL_063c:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0324;
																						IL_061e:
																						num5--;
																						goto end_IL_0324;
																						IL_05d0:
																						if (7 > b)
																						{
																							goto end_IL_0344;
																						}
																						goto IL_05de;
																					}
																					goto IL_07f5;
																					continue;
																					end_IL_0324:
																					break;
																					IL_0324:;
																				}
																				break;
																			}
																			goto IL_0675;
																			IL_0982:
																			if (17 > b)
																			{
																			}
																			goto end_IL_0344;
																			IL_0675:
																			if (13 >= b)
																			{
																				goto IL_0683;
																			}
																			goto IL_0894;
																			IL_0683:
																			if (13 <= b)
																			{
																				goto IL_068e;
																			}
																			goto IL_0703;
																			IL_068e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06f0;
																			IL_06f0:
																			num5 -= 2;
																			break;
																			IL_0703:
																			if (11 >= b)
																			{
																				goto IL_0711;
																			}
																			goto IL_0808;
																			IL_0711:
																			if (11 <= b)
																			{
																				goto IL_071c;
																			}
																			goto IL_0787;
																			IL_071c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0760;
																			IL_0760:
																			array[num5 - 2] = 0;
																			goto IL_0774;
																			IL_0774:
																			num5--;
																			break;
																			IL_0787:
																			if (10 < b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_0795;
																			IL_0795:
																			if (10 > b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_07a3;
																			IL_07a3:
																			array[num5] = 0;
																			goto IL_07b1;
																			IL_07b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 57;
																			goto IL_07dd;
																			IL_07dd:
																			array2[num5] = null;
																			goto IL_07e7;
																			IL_07e7:
																			num5++;
																			goto IL_07f5;
																			IL_07f5:
																			ptr2 += 8;
																			break;
																			IL_0808:
																			if (12 < b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_0816;
																			IL_0816:
																			if (12 > b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_0824;
																			IL_0824:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0864;
																			IL_0864:
																			array[num5 - 2] = 0;
																			goto IL_0878;
																			IL_0878:
																			num5--;
																			num = 50;
																			break;
																			IL_0894:
																			if (15 >= b)
																			{
																				goto IL_08a2;
																			}
																			goto IL_0948;
																			IL_08a2:
																			if (15 <= b)
																			{
																				goto IL_08ad;
																			}
																			goto IL_08c0;
																			IL_08ad:
																			num5--;
																			break;
																			IL_08c0:
																			if (14 < b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_08ce;
																			IL_08ce:
																			if (14 > b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_08dc;
																			IL_08dc:
																			array[num5 - 1] = 0;
																			num = 67;
																			goto IL_08f9;
																			IL_08f9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ExistsStructureToPtr[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0938;
																			IL_0938:
																			ptr2 += 8;
																			break;
																			IL_0948:
																			if (16 >= b)
																			{
																				goto IL_0953;
																			}
																			goto IL_0977;
																			IL_0953:
																			if (16 > b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_095e;
																			IL_095e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0977:
																			if (17 < b)
																			{
																				goto end_IL_0344;
																			}
																			goto IL_0982;
																		}
																		goto end_IL_0354;
																		continue;
																		end_IL_0344:
																		break;
																		IL_0344:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0354:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a33;
												IL_0a33:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09a0:
												break;
											}
											continue;
											end_IL_09b3:
											break;
										}
										continue;
										end_IL_09bd:
										break;
									}
									continue;
									end_IL_09c8:
									break;
								}
								continue;
								end_IL_09d8:
								break;
							}
							continue;
							end_IL_09e8:
							break;
						}
						continue;
						end_IL_09f8:
						break;
					}
					continue;
					end_IL_0a08:
					break;
				}
				continue;
				end_IL_0a18:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 48;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumPropertiesCompute.getIsDiscretionaryAclCanonicalNumberBufferToDecimal);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02b0:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0290:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0280:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0273:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_0211:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01f2:
																													array[num5 - 2] = 0;
																													num = 116;
																													while (true)
																													{
																														if (num != 116)
																														{
																															if (num != 1097)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 26:
																																goto IL_01f2;
																															case 21:
																															case 41:
																																goto IL_0211;
																															case 71:
																																goto IL_0253;
																															case 88:
																															case 99:
																																goto IL_0263;
																															case 37:
																																goto IL_0273;
																															case 42:
																															case 64:
																																goto IL_0280;
																															case 31:
																																goto IL_0290;
																															case 24:
																																goto IL_02a0;
																															case 62:
																																goto end_IL_01df;
																															case 51:
																																goto end_IL_02b0;
																															case 72:
																															case 92:
																																goto end_IL_02c0;
																															case 27:
																															case 30:
																																goto IL_02db;
																															case 91:
																																goto IL_02f4;
																															case 79:
																																goto IL_0302;
																															case 10:
																																goto IL_0310;
																															case 96:
																																goto IL_0336;
																															case 6:
																															case 54:
																																goto IL_0341;
																															case 55:
																																goto IL_034f;
																															case 93:
																															case 104:
																																goto IL_035d;
																															case 61:
																																goto IL_0379;
																															case 1:
																															case 28:
																																goto IL_0387;
																															case 90:
																																goto IL_03c7;
																															case 39:
																																goto IL_03db;
																															case 50:
																																goto IL_03ee;
																															case 86:
																																goto IL_03fc;
																															case 22:
																															case 38:
																																goto IL_040a;
																															case 46:
																																goto IL_0415;
																															case 94:
																															case 97:
																																goto IL_0423;
																															case 76:
																																goto IL_044c;
																															case 84:
																																goto IL_045a;
																															case 89:
																																goto IL_046d;
																															case 101:
																																goto IL_047b;
																															case 35:
																															case 49:
																																goto IL_0489;
																															case 3:
																																goto IL_04c9;
																															case 56:
																																goto IL_04dd;
																															case 5:
																																goto IL_04f0;
																															case 44:
																															case 70:
																																goto IL_04fb;
																															case 23:
																																goto IL_0506;
																															case 0:
																															case 2:
																															case 12:
																															case 13:
																															case 18:
																															case 20:
																															case 36:
																															case 40:
																															case 45:
																															case 59:
																															case 60:
																															case 63:
																															case 67:
																															case 68:
																															case 75:
																															case 81:
																															case 82:
																															case 85:
																															case 98:
																															case 100:
																															case 105:
																															case 106:
																																goto end_IL_0253;
																															case 19:
																																goto IL_0534;
																															case 17:
																																goto IL_0542;
																															case 8:
																																goto IL_0550;
																															case 47:
																															case 69:
																																goto IL_056c;
																															case 34:
																																goto IL_05ac;
																															case 74:
																																goto IL_05c0;
																															case 9:
																															case 14:
																																goto IL_05d0;
																															case 58:
																																goto IL_05de;
																															case 53:
																																goto IL_060a;
																															case 57:
																																goto IL_0614;
																															case 102:
																																goto IL_0622;
																															case 15:
																															case 25:
																															case 43:
																															case 52:
																															case 66:
																															case 73:
																															case 77:
																															case 80:
																															case 95:
																															case 107:
																															case 108:
																																goto end_IL_02d0;
																															case 109:
																																goto end_IL_0639;
																															case 83:
																																goto end_IL_064c;
																															case 87:
																																goto end_IL_0656;
																															case 11:
																																goto end_IL_0661;
																															case 78:
																																goto end_IL_0676;
																															case 7:
																															case 16:
																																goto end_IL_068b;
																															case 48:
																																goto end_IL_069b;
																															case 29:
																															case 65:
																																goto end_IL_06ab;
																															case 32:
																																goto end_IL_06bb;
																															case 33:
																																goto end_IL_06d4;
																															case 4:
																															case 103:
																																goto IL_06ef;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02d0;
																														continue;
																														end_IL_01df:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_02b0;
																											continue;
																											end_IL_0253:
																											break;
																											IL_0253:;
																										}
																										break;
																										IL_0263:;
																									}
																									break;
																								}
																								goto IL_02db;
																								IL_0310:
																								ptr2 += 8;
																								goto end_IL_02d0;
																								IL_02db:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02f4;
																								IL_02f4:
																								array[num5] = 0;
																								goto IL_0302;
																								IL_0302:
																								num5++;
																								goto IL_0310;
																							}
																							break;
																						}
																						goto IL_0336;
																						IL_03db:
																						num5--;
																						goto end_IL_02d0;
																						IL_0336:
																						if (8 < b)
																						{
																							goto IL_0341;
																						}
																						goto IL_0379;
																						IL_0341:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_034f;
																						IL_034f:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_035d;
																						IL_035d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02d0;
																						IL_0379:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0387;
																						IL_0387:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03c7;
																						IL_03c7:
																						array[num5 - 2] = 0;
																						goto IL_03db;
																					}
																					break;
																				}
																				goto IL_03ee;
																				IL_0622:
																				ptr2 += 8;
																				num = 77;
																				goto end_IL_02d0;
																				IL_03ee:
																				if (5 > b)
																				{
																					goto IL_03fc;
																				}
																				goto IL_05d0;
																				IL_03fc:
																				if (2 < b)
																				{
																					goto IL_040a;
																				}
																				goto IL_04f0;
																				IL_040a:
																				if (3 >= b)
																				{
																					goto IL_0415;
																				}
																				goto IL_046d;
																				IL_0415:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0423;
																				IL_0423:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_044c;
																				IL_044c:
																				ptr2 += 8;
																				goto IL_045a;
																				IL_045a:
																				num5--;
																				goto end_IL_02d0;
																				IL_046d:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_047b;
																				IL_047b:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0489;
																				IL_0489:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c9;
																				IL_04c9:
																				array[num5 - 2] = 0;
																				goto IL_04dd;
																				IL_04dd:
																				num5--;
																				goto end_IL_02d0;
																				IL_04f0:
																				if (2 > b)
																				{
																					goto IL_04fb;
																				}
																				goto IL_056c;
																				IL_04fb:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0506;
																				IL_0506:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_056c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ac;
																				IL_05ac:
																				array[num5 - 2] = 0;
																				goto IL_05c0;
																				IL_05c0:
																				num5--;
																				goto end_IL_02d0;
																				IL_05d0:
																				array[num5] = 0;
																				goto IL_05de;
																				IL_05de:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 53;
																				goto IL_060a;
																				IL_060a:
																				array2[num5] = null;
																				goto IL_0614;
																				IL_0614:
																				num5++;
																				goto IL_0622;
																			}
																			break;
																			IL_02a0:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0534;
																	IL_0550:
																	ptr2 += 8;
																	num = 95;
																	goto end_IL_02d0;
																	IL_0542:
																	num5++;
																	goto IL_0550;
																	IL_0534:
																	array[num5] = 0;
																	goto IL_0542;
																	continue;
																	end_IL_02b0:
																	break;
																}
																continue;
																end_IL_02c0:
																break;
															}
															continue;
															end_IL_02d0:
															break;
														}
														continue;
													}
													goto IL_06ef;
													IL_06ef:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0639:
													break;
												}
												continue;
												end_IL_064c:
												break;
											}
											continue;
											end_IL_0656:
											break;
										}
										continue;
										end_IL_0661:
										break;
									}
									continue;
									end_IL_0676:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_069b:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06d4:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 98;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							num = 34;
							while (true)
							{
								num = 11;
								while (true)
								{
									int[] array3 = new int[5];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											array3[0] = int_2;
											while (true)
											{
												array3[1] = int_3;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LocalDataStoreHolderFunc.JAPANESELUNISOLARMultiDomain);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	IL_0287:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0277:
																		ptr2++;
																		while (true)
																		{
																			IL_0267:
																			if (b >= 1)
																			{
																				while (b <= 9)
																				{
																					while (true)
																					{
																						IL_0247:
																						if (5 < b)
																						{
																							while (true)
																							{
																								IL_023a:
																								if (7 >= b)
																								{
																									while (true)
																									{
																										IL_022a:
																										if (7 <= b)
																										{
																											while (true)
																											{
																												IL_020f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												while (true)
																												{
																													IL_01ff:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_01ef:
																														num5++;
																														while (true)
																														{
																															IL_01d6:
																															ptr2 += 8;
																															num = 109;
																															while (num != 109)
																															{
																																if (num != 1090)
																																{
																																	goto end_IL_0257;
																																}
																																switch (num)
																																{
																																case 67:
																																	goto IL_01d6;
																																case 33:
																																	goto IL_01ef;
																																case 80:
																																	goto IL_01ff;
																																case 25:
																																case 44:
																																	goto IL_020f;
																																case 19:
																																	goto IL_022a;
																																case 27:
																																case 79:
																																	goto IL_023a;
																																case 63:
																																	goto IL_0247;
																																case 24:
																																	goto IL_0257;
																																case 62:
																																	goto IL_0267;
																																case 100:
																																	goto IL_0277;
																																case 55:
																																case 92:
																																	goto IL_0287;
																																case 29:
																																case 84:
																																	goto IL_0292;
																																case 12:
																																	goto IL_029d;
																																case 4:
																																case 59:
																																	goto IL_02ab;
																																case 14:
																																	goto IL_02ed;
																																case 90:
																																	goto IL_02fb;
																																case 91:
																																	goto IL_030b;
																																case 78:
																																	goto IL_031f;
																																case 56:
																																case 94:
																																	goto IL_0332;
																																case 7:
																																	goto IL_034e;
																																case 40:
																																	goto IL_035c;
																																case 32:
																																case 88:
																																	goto IL_036a;
																																case 82:
																																	goto IL_03aa;
																																case 58:
																																	goto IL_03be;
																																case 99:
																																	goto IL_03d1;
																																case 21:
																																case 47:
																																	goto IL_03df;
																																case 39:
																																	goto IL_03ed;
																																case 38:
																																case 51:
																																	goto IL_03f8;
																																case 3:
																																	goto IL_0441;
																																case 42:
																																	goto IL_0455;
																																case 85:
																																	goto IL_0468;
																																case 52:
																																	goto IL_0476;
																																case 37:
																																	goto IL_0489;
																																case 2:
																																	goto IL_0494;
																																case 22:
																																case 45:
																																	goto IL_04a2;
																																case 36:
																																	goto IL_04cb;
																																case 81:
																																	goto IL_04d9;
																																case 28:
																																	goto IL_04ec;
																																case 20:
																																	goto IL_04fa;
																																case 23:
																																case 70:
																																	goto IL_0508;
																																case 41:
																																	goto IL_0548;
																																case 86:
																																	goto IL_055c;
																																case 75:
																																case 77:
																																	goto IL_056f;
																																case 53:
																																	goto IL_057d;
																																case 5:
																																	goto IL_05a0;
																																case 76:
																																	goto IL_05aa;
																																case 48:
																																	goto IL_05b8;
																																case 1:
																																case 8:
																																case 10:
																																case 13:
																																case 15:
																																case 17:
																																case 18:
																																case 35:
																																case 46:
																																case 50:
																																case 61:
																																case 64:
																																case 69:
																																case 87:
																																case 93:
																																case 101:
																																case 102:
																																	goto end_IL_0257;
																																case 57:
																																	goto IL_05eb;
																																case 74:
																																	goto IL_05f9;
																																case 68:
																																	goto IL_0607;
																																case 0:
																																case 9:
																																case 26:
																																case 30:
																																case 31:
																																case 54:
																																case 60:
																																case 65:
																																case 73:
																																case 89:
																																	goto end_IL_01c3;
																																case 71:
																																	goto end_IL_0615;
																																case 43:
																																	goto end_IL_0628;
																																case 49:
																																	goto end_IL_0632;
																																case 72:
																																	goto end_IL_063d;
																																case 83:
																																	goto end_IL_0652;
																																case 11:
																																	goto end_IL_0667;
																																case 34:
																																	goto end_IL_0677;
																																case 97:
																																	goto end_IL_0687;
																																case 98:
																																	goto end_IL_0692;
																																case 16:
																																	goto end_IL_06ab;
																																case 95:
																																	goto end_IL_06bb;
																																case 96:
																																	goto end_IL_06c6;
																																case 6:
																																case 66:
																																	goto IL_06e1;
																																}
																																continue;
																																end_IL_01c3:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_034e;
																										IL_03be:
																										num5--;
																										break;
																										IL_034e:
																										if (6 < b)
																										{
																											goto end_IL_0257;
																										}
																										goto IL_035c;
																										IL_035c:
																										if (6 > b)
																										{
																											goto end_IL_0257;
																										}
																										goto IL_036a;
																										IL_036a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03aa;
																										IL_03aa:
																										array[num5 - 2] = 0;
																										goto IL_03be;
																									}
																									break;
																								}
																								goto IL_0292;
																								IL_0332:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								break;
																								IL_0292:
																								if (8 >= b)
																								{
																									goto IL_029d;
																								}
																								goto IL_02ed;
																								IL_029d:
																								if (8 > b)
																								{
																									goto end_IL_0257;
																								}
																								goto IL_02ab;
																								IL_02ab:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_030b;
																								IL_030b:
																								array[num5 - 2] = 0;
																								goto IL_031f;
																								IL_031f:
																								num5--;
																								break;
																								IL_02ed:
																								if (9 < b)
																								{
																									goto end_IL_0257;
																								}
																								goto IL_02fb;
																								IL_02fb:
																								if (9 > b)
																								{
																									goto end_IL_0257;
																								}
																								goto IL_0332;
																							}
																							break;
																						}
																						goto IL_03d1;
																						IL_05b8:
																						ptr2 += 8;
																						break;
																						IL_03d1:
																						if (5 > b)
																						{
																							goto IL_03df;
																						}
																						goto IL_056f;
																						IL_03df:
																						if (2 >= b)
																						{
																							goto IL_03ed;
																						}
																						goto IL_0489;
																						IL_03ed:
																						if (2 <= b)
																						{
																							goto IL_03f8;
																						}
																						goto IL_0468;
																						IL_03f8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 3;
																						goto IL_0441;
																						IL_0441:
																						array[num5 - 2] = 0;
																						goto IL_0455;
																						IL_0455:
																						num5--;
																						break;
																						IL_0468:
																						if (1 < b)
																						{
																							goto end_IL_0257;
																						}
																						goto IL_0476;
																						IL_0476:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0257;
																						IL_0489:
																						if (3 >= b)
																						{
																							goto IL_0494;
																						}
																						goto IL_04ec;
																						IL_0494:
																						if (3 > b)
																						{
																							goto end_IL_0257;
																						}
																						goto IL_04a2;
																						IL_04a2:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04cb;
																						IL_04cb:
																						ptr2 += 8;
																						goto IL_04d9;
																						IL_04d9:
																						num5--;
																						break;
																						IL_04ec:
																						if (4 < b)
																						{
																							goto end_IL_0257;
																						}
																						goto IL_04fa;
																						IL_04fa:
																						if (4 > b)
																						{
																							goto end_IL_0257;
																						}
																						goto IL_0508;
																						IL_0508:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0548;
																						IL_0548:
																						array[num5 - 2] = 0;
																						goto IL_055c;
																						IL_055c:
																						num5--;
																						break;
																						IL_056f:
																						array[num5] = 0;
																						goto IL_057d;
																						IL_057d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05a0;
																						IL_05a0:
																						array2[num5] = null;
																						goto IL_05aa;
																						IL_05aa:
																						num5++;
																						goto IL_05b8;
																					}
																					goto end_IL_0267;
																					continue;
																					end_IL_0257:
																					break;
																					IL_0257:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05eb;
																			IL_0607:
																			ptr2 += 8;
																			break;
																			IL_05f9:
																			num5++;
																			goto IL_0607;
																			IL_05eb:
																			array[num5] = 0;
																			goto IL_05f9;
																			continue;
																			end_IL_0267:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
															}
															goto IL_06e1;
															IL_06e1:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_0615:
															break;
														}
														continue;
														end_IL_0628:
														break;
													}
													continue;
													end_IL_0632:
													break;
												}
												continue;
												end_IL_063d:
												break;
											}
											continue;
											end_IL_0652:
											break;
										}
										continue;
										end_IL_0667:
										break;
									}
									continue;
									end_IL_0677:
									break;
								}
								continue;
								end_IL_0687:
								break;
							}
							continue;
							end_IL_0692:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06c6:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 74;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ObjectNamegetIsGenericTypeDefinition.QuerygetIsNestedAssembly);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 69;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d5:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 77;
																		while (true)
																		{
																			IL_02b2:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_02a2:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0292:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0282:
																									if (7 < b)
																									{
																										while (8 >= b)
																										{
																											while (8 <= b)
																											{
																												while (true)
																												{
																													IL_023d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													while (true)
																													{
																														IL_022d:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_0214:
																															num5++;
																															num = 121;
																															while (true)
																															{
																																if (num != 121)
																																{
																																	if (num != 1102)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 55:
																																		goto IL_0214;
																																	case 80:
																																		goto IL_022d;
																																	case 42:
																																	case 79:
																																		goto IL_023d;
																																	case 70:
																																		goto IL_0262;
																																	case 6:
																																	case 27:
																																		goto IL_0272;
																																	case 96:
																																	case 110:
																																		goto IL_0282;
																																	case 17:
																																		goto IL_0292;
																																	case 4:
																																	case 58:
																																		goto IL_02a2;
																																	case 77:
																																		goto IL_02b2;
																																	case 102:
																																		goto IL_02c2;
																																	case 91:
																																		goto IL_02d5;
																																	case 25:
																																		goto end_IL_02d5;
																																	case 39:
																																	case 83:
																																		goto end_IL_02e5;
																																	case 31:
																																		goto IL_0313;
																																	case 81:
																																	case 84:
																																		goto IL_0321;
																																	case 14:
																																		goto IL_0361;
																																	case 97:
																																		goto IL_0375;
																																	case 101:
																																	case 112:
																																		goto end_IL_0201;
																																	case 51:
																																		goto IL_03ea;
																																	case 100:
																																	case 113:
																																		goto IL_03fd;
																																	case 111:
																																		goto IL_0408;
																																	case 26:
																																	case 72:
																																		goto IL_0416;
																																	case 98:
																																		goto IL_0432;
																																	case 0:
																																		goto IL_0440;
																																	case 49:
																																		goto IL_0453;
																																	case 11:
																																	case 24:
																																		goto IL_0461;
																																	case 29:
																																	case 76:
																																		goto IL_046f;
																																	case 88:
																																		goto IL_047a;
																																	case 36:
																																		goto IL_048d;
																																	case 73:
																																		goto IL_049b;
																																	case 37:
																																	case 48:
																																		goto IL_04a9;
																																	case 10:
																																		goto IL_04b7;
																																	case 41:
																																		goto IL_04da;
																																	case 62:
																																		goto IL_04e4;
																																	case 104:
																																		goto IL_04f2;
																																	case 19:
																																		goto IL_0505;
																																	case 18:
																																	case 35:
																																		goto IL_0513;
																																	case 38:
																																	case 71:
																																		goto IL_051e;
																																	case 9:
																																		goto IL_0529;
																																	case 46:
																																	case 87:
																																		goto IL_0534;
																																	case 34:
																																		goto IL_055d;
																																	case 54:
																																		goto IL_056b;
																																	case 7:
																																		goto IL_057e;
																																	case 2:
																																	case 5:
																																	case 8:
																																	case 13:
																																	case 15:
																																	case 44:
																																	case 50:
																																	case 53:
																																	case 56:
																																	case 68:
																																	case 75:
																																	case 78:
																																	case 82:
																																	case 95:
																																	case 99:
																																	case 103:
																																	case 105:
																																	case 106:
																																	case 109:
																																		goto end_IL_0262;
																																	case 16:
																																	case 92:
																																		goto IL_05a1;
																																	case 20:
																																		goto IL_05ba;
																																	case 12:
																																		goto IL_05c8;
																																	case 28:
																																		goto IL_05df;
																																	case 65:
																																	case 85:
																																		goto IL_05ef;
																																	case 33:
																																	case 64:
																																		goto IL_0604;
																																	case 45:
																																		goto IL_0644;
																																	case 67:
																																		goto IL_0658;
																																	case 3:
																																	case 22:
																																	case 23:
																																	case 30:
																																	case 40:
																																	case 57:
																																	case 59:
																																	case 60:
																																	case 61:
																																	case 66:
																																	case 69:
																																	case 86:
																																	case 93:
																																	case 114:
																																		goto end_IL_02f5;
																																	case 21:
																																		goto end_IL_0666;
																																	case 74:
																																		goto end_IL_0679;
																																	case 43:
																																		goto end_IL_068c;
																																	case 94:
																																		goto end_IL_0697;
																																	case 1:
																																	case 63:
																																		goto end_IL_06b5;
																																	case 52:
																																		goto end_IL_06c5;
																																	case 47:
																																	case 108:
																																		goto end_IL_06d5;
																																	case 89:
																																		goto end_IL_06e5;
																																	case 90:
																																		goto end_IL_06f5;
																																	case 32:
																																	case 107:
																																		goto IL_0710;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_02f5;
																																continue;
																																end_IL_0201:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0388;
																												continue;
																												end_IL_0262:
																												break;
																												IL_0262:;
																											}
																											break;
																											IL_0272:;
																										}
																										break;
																									}
																									goto IL_0313;
																									IL_0375:
																									num5--;
																									goto end_IL_02f5;
																									IL_0313:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0321;
																									IL_0321:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0361;
																									IL_0361:
																									array[num5 - 2] = 0;
																									goto IL_0375;
																								}
																								break;
																							}
																							goto IL_0388;
																							IL_03ea:
																							num5 -= 2;
																							goto end_IL_02f5;
																							IL_0388:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03ea;
																						}
																						break;
																					}
																					goto IL_03fd;
																					IL_0440:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_03fd:
																					if (10 >= b)
																					{
																						goto IL_0408;
																					}
																					goto IL_0432;
																					IL_0408:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0416;
																					IL_0416:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02f5;
																					IL_0432:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0440;
																				}
																				break;
																			}
																			goto IL_0453;
																			IL_0658:
																			num5--;
																			goto end_IL_02f5;
																			IL_0453:
																			if (6 > b)
																			{
																				goto IL_0461;
																			}
																			goto IL_0604;
																			IL_0461:
																			if (3 < b)
																			{
																				goto IL_046f;
																			}
																			goto IL_0505;
																			IL_046f:
																			if (4 >= b)
																			{
																				goto IL_047a;
																			}
																			goto IL_048d;
																			IL_047a:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02f5;
																			IL_048d:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_049b;
																			IL_049b:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_04a9;
																			IL_04a9:
																			array[num5] = 0;
																			goto IL_04b7;
																			IL_04b7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04da;
																			IL_04da:
																			array2[num5] = null;
																			goto IL_04e4;
																			IL_04e4:
																			num5++;
																			goto IL_04f2;
																			IL_04f2:
																			ptr2 += 8;
																			goto end_IL_02f5;
																			IL_0505:
																			if (3 > b)
																			{
																				goto IL_0513;
																			}
																			goto IL_05ef;
																			IL_0513:
																			if (1 < b)
																			{
																				goto IL_051e;
																			}
																			goto IL_057e;
																			IL_051e:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0529;
																			IL_0529:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0534;
																			IL_0534:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_055d;
																			IL_055d:
																			ptr2 += 8;
																			goto IL_056b;
																			IL_056b:
																			num5--;
																			goto end_IL_02f5;
																			IL_057e:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05a1;
																			IL_05a1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05ba;
																			IL_05ba:
																			array[num5] = 0;
																			goto IL_05c8;
																			IL_05c8:
																			num5++;
																			num = 28;
																			goto IL_05df;
																			IL_05df:
																			ptr2 += 8;
																			goto end_IL_02f5;
																			IL_05ef:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02f5;
																			IL_0604:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0644;
																			IL_0644:
																			array[num5 - 2] = 0;
																			goto IL_0658;
																		}
																		break;
																		IL_02c2:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f5;
																continue;
																end_IL_02d5:
																break;
															}
															continue;
															end_IL_02e5:
															break;
														}
														continue;
														end_IL_02f5:
														break;
													}
													continue;
												}
												goto IL_0710;
												IL_0710:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0666:
												break;
											}
											continue;
											end_IL_0679:
											break;
										}
										continue;
										end_IL_068c:
										break;
									}
									continue;
									end_IL_0697:
									break;
								}
								continue;
								end_IL_06b5:
								break;
							}
							continue;
							end_IL_06c5:
							break;
						}
						continue;
						end_IL_06d5:
						break;
					}
					continue;
					end_IL_06e5:
					break;
				}
				continue;
				end_IL_06f5:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 100;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NoInliningResourceFallbackCulture.PtrToStringAutoReflectionOnlyLoading);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0280:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				if (6 >= b)
																				{
																					while (true)
																					{
																						if (6 > b)
																						{
																							while (true)
																							{
																								if (3 >= b)
																								{
																									while (true)
																									{
																										if (3 > b)
																										{
																											while (true)
																											{
																												if (1 < b)
																												{
																													num = 124;
																													while (true)
																													{
																														if (num == 124)
																														{
																															goto IL_0550;
																														}
																														if (num != 1105)
																														{
																															goto IL_055e;
																														}
																														switch (num)
																														{
																														case 41:
																															goto end_IL_020d;
																														case 48:
																															goto end_IL_0220;
																														case 115:
																															goto end_IL_0233;
																														case 45:
																															goto end_IL_0240;
																														case 31:
																															goto end_IL_0250;
																														case 43:
																															goto end_IL_0260;
																														case 27:
																															goto IL_0280;
																														case 50:
																															goto end_IL_0280;
																														case 96:
																														case 107:
																															goto end_IL_0290;
																														case 11:
																														case 47:
																															goto IL_02ab;
																														case 40:
																															goto IL_02d4;
																														case 30:
																															goto IL_02e2;
																														case 13:
																														case 69:
																															goto IL_02f5;
																														case 3:
																															goto IL_0335;
																														case 83:
																															goto IL_0349;
																														case 15:
																														case 105:
																															goto IL_035c;
																														case 80:
																															goto IL_0367;
																														case 76:
																															goto IL_0372;
																														case 9:
																															goto IL_0380;
																														case 25:
																														case 35:
																															goto IL_038e;
																														case 87:
																															goto IL_03b3;
																														case 18:
																														case 62:
																															goto IL_03c1;
																														case 24:
																															goto IL_03dd;
																														case 29:
																														case 57:
																															goto IL_03f1;
																														case 102:
																															goto IL_03fc;
																														case 70:
																															goto IL_040c;
																														case 90:
																														case 103:
																															goto IL_041f;
																														case 67:
																															goto IL_042d;
																														case 106:
																														case 109:
																															goto IL_045f;
																														case 98:
																															goto IL_0478;
																														case 93:
																															goto IL_0486;
																														case 113:
																															goto IL_0494;
																														case 114:
																															goto IL_04a7;
																														case 71:
																														case 94:
																															goto IL_04b5;
																														case 0:
																															goto IL_04f5;
																														case 51:
																															goto IL_0509;
																														case 116:
																															goto IL_051c;
																														case 117:
																															goto IL_052f;
																														case 60:
																															goto IL_053d;
																														case 5:
																															goto IL_0550;
																														case 86:
																															goto IL_055e;
																														case 6:
																														case 26:
																															goto IL_056c;
																														case 77:
																															goto IL_05ac;
																														case 33:
																															goto IL_05c0;
																														case 66:
																															goto IL_05d3;
																														case 42:
																														case 72:
																															goto IL_05de;
																														case 2:
																															goto IL_05ec;
																														case 63:
																														case 74:
																															goto IL_05fa;
																														case 95:
																															goto IL_0608;
																														case 59:
																															goto IL_062b;
																														case 64:
																															goto IL_0635;
																														case 104:
																															goto IL_0643;
																														case 14:
																															goto IL_0656;
																														case 56:
																														case 85:
																															goto IL_0661;
																														case 61:
																															goto IL_06a1;
																														case 55:
																															goto IL_06b5;
																														case 1:
																														case 12:
																														case 22:
																														case 23:
																														case 28:
																														case 39:
																														case 44:
																														case 54:
																														case 58:
																														case 73:
																														case 75:
																														case 82:
																														case 84:
																														case 91:
																														case 92:
																														case 97:
																														case 108:
																														case 112:
																															goto end_IL_0270;
																														case 8:
																															goto IL_06e8;
																														case 4:
																															goto IL_06ff;
																														case 21:
																															goto IL_070d;
																														case 7:
																														case 10:
																														case 17:
																														case 19:
																														case 32:
																														case 38:
																														case 49:
																														case 68:
																														case 79:
																														case 81:
																														case 88:
																														case 99:
																														case 110:
																															goto end_IL_02a0;
																														case 52:
																															goto end_IL_071b;
																														case 65:
																															goto end_IL_072e;
																														case 53:
																															goto end_IL_0738;
																														case 111:
																															goto end_IL_0743;
																														case 78:
																															goto end_IL_0758;
																														case 34:
																														case 37:
																															goto end_IL_076d;
																														case 20:
																															goto end_IL_077d;
																														case 16:
																														case 46:
																															goto end_IL_078d;
																														case 100:
																															goto end_IL_079d;
																														case 101:
																															goto end_IL_07ad;
																														case 36:
																														case 89:
																															goto IL_07da;
																														}
																														continue;
																														IL_05ac:
																														array[num5 - 2] = 0;
																														goto IL_05c0;
																														IL_05c0:
																														num5--;
																														goto end_IL_02a0;
																														IL_0550:
																														if (2 < b)
																														{
																															goto end_IL_0270;
																														}
																														goto IL_055e;
																														IL_055e:
																														if (2 > b)
																														{
																															goto end_IL_0270;
																														}
																														goto IL_056c;
																														IL_056c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_05ac;
																														continue;
																														end_IL_020d:
																														break;
																													}
																													continue;
																												}
																												goto IL_051c;
																												IL_051c:
																												if (1 > b)
																												{
																												}
																												goto end_IL_0270;
																												continue;
																												end_IL_0220:
																												break;
																											}
																											continue;
																										}
																										goto IL_02ab;
																										IL_02e2:
																										num5--;
																										goto end_IL_02a0;
																										IL_02ab:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_02d4;
																										IL_02d4:
																										ptr2 += 8;
																										goto IL_02e2;
																										continue;
																										end_IL_0233:
																										break;
																									}
																									continue;
																								}
																								goto IL_05d3;
																								IL_06b5:
																								num5--;
																								goto end_IL_02a0;
																								IL_05d3:
																								if (4 < b)
																								{
																									goto IL_05de;
																								}
																								goto IL_0656;
																								IL_05de:
																								if (5 < b)
																								{
																									goto end_IL_0270;
																								}
																								goto IL_05ec;
																								IL_05ec:
																								if (5 > b)
																								{
																									goto end_IL_0270;
																								}
																								goto IL_05fa;
																								IL_05fa:
																								array[num5] = 0;
																								goto IL_0608;
																								IL_0608:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_062b;
																								IL_062b:
																								array2[num5] = null;
																								goto IL_0635;
																								IL_0635:
																								num5++;
																								goto IL_0643;
																								IL_0643:
																								ptr2 += 8;
																								goto end_IL_02a0;
																								IL_0656:
																								if (4 > b)
																								{
																									goto end_IL_0270;
																								}
																								goto IL_0661;
																								IL_0661:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_06a1;
																								IL_06a1:
																								array[num5 - 2] = 0;
																								goto IL_06b5;
																								continue;
																								end_IL_0240:
																								break;
																							}
																							continue;
																						}
																						goto IL_02f5;
																						IL_0349:
																						num5--;
																						goto end_IL_02a0;
																						IL_02f5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0335;
																						IL_0335:
																						array[num5 - 2] = 0;
																						goto IL_0349;
																						continue;
																						end_IL_0250:
																						break;
																					}
																					continue;
																				}
																				goto IL_035c;
																				IL_041f:
																				array[num5] = 0;
																				goto IL_042d;
																				IL_035c:
																				if (9 < b)
																				{
																					goto IL_0367;
																				}
																				num = 24;
																				goto IL_03dd;
																				IL_0367:
																				if (10 < b)
																				{
																					goto IL_0372;
																				}
																				num = 87;
																				goto IL_03b3;
																				IL_0372:
																				if (11 < b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_0380;
																				IL_0380:
																				if (11 > b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_038e;
																				IL_038e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a0;
																				IL_052f:
																				num5++;
																				goto IL_053d;
																				IL_03b3:
																				if (10 > b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_03c1;
																				IL_03c1:
																				num5--;
																				goto end_IL_02a0;
																				IL_042d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)TokenVirtualizationAllowedSystemMaxDBCSCharSize[*(int*)(ptr2 + num3)])();
																				num = 117;
																				goto IL_052f;
																				IL_03dd:
																				if (9 > b)
																				{
																					num = 29;
																					goto IL_03f1;
																				}
																				goto IL_041f;
																				IL_053d:
																				ptr2 += 8;
																				goto end_IL_02a0;
																				IL_03f1:
																				if (7 >= b)
																				{
																					goto IL_03fc;
																				}
																				goto IL_040c;
																				IL_03fc:
																				if (7 > b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_045f;
																				IL_045f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0478;
																				IL_0478:
																				array[num5] = 0;
																				goto IL_0486;
																				IL_0486:
																				num5++;
																				goto IL_0494;
																				IL_0494:
																				ptr2 += 8;
																				goto end_IL_02a0;
																				IL_040c:
																				if (8 < b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_04a7;
																				IL_04a7:
																				if (8 > b)
																				{
																					goto end_IL_0270;
																				}
																				goto IL_04b5;
																				IL_04b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f5;
																				IL_04f5:
																				array[num5 - 2] = 0;
																				goto IL_0509;
																				IL_0509:
																				num5--;
																				goto end_IL_02a0;
																				continue;
																				end_IL_0260:
																				break;
																			}
																			continue;
																			end_IL_0270:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e8;
																	IL_070d:
																	ptr2 += 8;
																	goto end_IL_02a0;
																	IL_06ff:
																	num5++;
																	goto IL_070d;
																	IL_06e8:
																	array[num5] = 0;
																	num = 4;
																	goto IL_06ff;
																	continue;
																	end_IL_0280:
																	break;
																}
																continue;
																end_IL_0290:
																break;
															}
															continue;
															end_IL_02a0:
															break;
														}
														continue;
													}
													num = 36;
													goto IL_07da;
													IL_07da:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071b:
													break;
												}
												continue;
												end_IL_072e:
												break;
											}
											continue;
											end_IL_0738:
											break;
										}
										continue;
										end_IL_0743:
										break;
									}
									continue;
									end_IL_0758:
									break;
								}
								continue;
								end_IL_076d:
								break;
							}
							continue;
							end_IL_077d:
							break;
						}
						continue;
						end_IL_078d:
						break;
					}
					continue;
					end_IL_079d:
					break;
				}
				continue;
				end_IL_07ad:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 56;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnsolicitedInputBitField.MaximumAgepValue);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 83;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02ae:
															byte b = *ptr2;
															while (true)
															{
																IL_029e:
																ptr2++;
																while (true)
																{
																	IL_028e:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_026e:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_025e:
																						if (5 <= b)
																						{
																							num = 72;
																							while (true)
																							{
																								IL_024e:
																								array[num5] = 0;
																								while (true)
																								{
																									IL_0229:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									while (true)
																									{
																										IL_021d:
																										array2[num5] = null;
																										while (true)
																										{
																											IL_020d:
																											num5++;
																											while (true)
																											{
																												IL_01f4:
																												ptr2 += 8;
																												num = 113;
																												while (num != 113)
																												{
																													if (num != 1094)
																													{
																														goto end_IL_027e;
																													}
																													switch (num)
																													{
																													case 46:
																														goto IL_01f4;
																													case 25:
																														goto IL_020d;
																													case 105:
																														goto IL_021d;
																													case 61:
																														goto IL_0229;
																													case 3:
																													case 72:
																														goto IL_024e;
																													case 43:
																														goto IL_025e;
																													case 95:
																														goto IL_026e;
																													case 20:
																														goto IL_027e;
																													case 39:
																														goto IL_028e;
																													case 23:
																														goto IL_029e;
																													case 71:
																													case 84:
																														goto IL_02ae;
																													case 54:
																														goto IL_02b9;
																													case 11:
																														goto IL_02c4;
																													case 10:
																														goto IL_02da;
																													case 19:
																													case 82:
																														goto IL_02ed;
																													case 50:
																														goto IL_02fb;
																													case 9:
																													case 88:
																														goto IL_030b;
																													case 7:
																													case 89:
																														goto IL_0336;
																													case 24:
																														goto IL_034f;
																													case 6:
																														goto IL_035d;
																													case 8:
																														goto IL_036b;
																													case 13:
																													case 96:
																														goto IL_037e;
																													case 67:
																														goto IL_038c;
																													case 100:
																														goto IL_039f;
																													case 55:
																														goto IL_03ad;
																													case 103:
																														goto IL_03c9;
																													case 4:
																													case 78:
																														goto IL_03d7;
																													case 77:
																														goto IL_03ef;
																													case 42:
																														goto IL_03fd;
																													case 32:
																													case 58:
																														goto IL_0408;
																													case 36:
																														goto IL_046a;
																													case 90:
																														goto IL_047d;
																													case 22:
																													case 49:
																														goto IL_0488;
																													case 73:
																														goto IL_0496;
																													case 57:
																													case 65:
																														goto IL_04a4;
																													case 64:
																														goto IL_04c7;
																													case 33:
																														goto IL_04d5;
																													case 28:
																														goto IL_04e3;
																													case 69:
																														goto IL_04f6;
																													case 44:
																													case 47:
																														goto IL_0504;
																													case 26:
																														goto IL_0544;
																													case 94:
																														goto IL_0558;
																													case 14:
																													case 101:
																														goto IL_0571;
																													case 51:
																														goto IL_057c;
																													case 75:
																													case 80:
																														goto IL_0587;
																													case 18:
																													case 29:
																														goto IL_05a9;
																													case 16:
																														goto IL_05b4;
																													case 1:
																													case 12:
																													case 15:
																													case 17:
																													case 21:
																													case 27:
																													case 38:
																													case 40:
																													case 41:
																													case 45:
																													case 48:
																													case 53:
																													case 59:
																													case 60:
																													case 66:
																													case 74:
																													case 76:
																													case 79:
																													case 98:
																													case 104:
																													case 106:
																														goto end_IL_027e;
																													case 5:
																													case 30:
																													case 34:
																													case 37:
																													case 52:
																													case 83:
																													case 85:
																													case 87:
																													case 91:
																													case 93:
																													case 102:
																														goto end_IL_01e1;
																													case 0:
																														goto end_IL_05d2;
																													case 92:
																														goto end_IL_05e5;
																													case 70:
																														goto end_IL_05f0;
																													case 35:
																														goto end_IL_05fa;
																													case 68:
																														goto end_IL_0605;
																													case 81:
																													case 86:
																														goto end_IL_061a;
																													case 56:
																														goto end_IL_062a;
																													case 31:
																													case 99:
																														goto end_IL_063a;
																													case 62:
																														goto end_IL_064a;
																													case 63:
																														goto end_IL_0663;
																													case 2:
																													case 97:
																														goto IL_067e;
																													}
																													continue;
																													end_IL_01e1:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02b9;
																						IL_038c:
																						if (4 > b)
																						{
																							goto end_IL_027e;
																						}
																						break;
																						IL_03c9:
																						if (3 > b)
																						{
																							goto end_IL_027e;
																						}
																						goto IL_03d7;
																						IL_02b9:
																						if (2 >= b)
																						{
																							goto IL_02c4;
																						}
																						goto IL_02da;
																						IL_02c4:
																						if (2 > b)
																						{
																							num = 19;
																							goto IL_02ed;
																						}
																						goto IL_030b;
																						IL_03d7:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_02ed:
																						if (1 < b)
																						{
																							goto end_IL_027e;
																						}
																						goto IL_02fb;
																						IL_02fb:
																						if (1 > b)
																						{
																							goto end_IL_027e;
																						}
																						goto IL_0336;
																						IL_0336:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_034f;
																						IL_034f:
																						array[num5] = 0;
																						goto IL_035d;
																						IL_035d:
																						num5++;
																						goto IL_036b;
																						IL_036b:
																						ptr2 += 8;
																						break;
																						IL_030b:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_039f;
																						IL_039f:
																						ptr2 += 8;
																						goto IL_03ad;
																						IL_03ad:
																						num5--;
																						num = 52;
																						break;
																						IL_02da:
																						if (3 < b)
																						{
																							goto IL_037e;
																						}
																						goto IL_03c9;
																						IL_037e:
																						if (4 < b)
																						{
																							goto end_IL_027e;
																						}
																						goto IL_038c;
																					}
																					break;
																				}
																				goto IL_03ef;
																				IL_05b4:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_027e;
																				IL_03ef:
																				if (8 >= b)
																				{
																					goto IL_03fd;
																				}
																				num = 14;
																				goto IL_0571;
																				IL_03fd:
																				if (8 <= b)
																				{
																					goto IL_0408;
																				}
																				goto IL_047d;
																				IL_0408:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_046a;
																				IL_046a:
																				num5 -= 2;
																				break;
																				IL_047d:
																				if (6 < b)
																				{
																					goto IL_0488;
																				}
																				goto IL_04f6;
																				IL_0488:
																				if (7 < b)
																				{
																					goto end_IL_027e;
																				}
																				goto IL_0496;
																				IL_0496:
																				if (7 > b)
																				{
																					goto end_IL_027e;
																				}
																				goto IL_04a4;
																				IL_04a4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04c7;
																				IL_04c7:
																				array[num5] = 0;
																				goto IL_04d5;
																				IL_04d5:
																				num5++;
																				goto IL_04e3;
																				IL_04e3:
																				ptr2 += 8;
																				break;
																				IL_04f6:
																				if (6 > b)
																				{
																					goto end_IL_027e;
																				}
																				goto IL_0504;
																				IL_0504:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0544;
																				IL_0544:
																				array[num5 - 2] = 0;
																				goto IL_0558;
																				IL_0558:
																				num5--;
																				break;
																				IL_05a9:
																				if (10 < b)
																				{
																					goto end_IL_027e;
																				}
																				goto IL_05b4;
																				IL_0571:
																				if (9 >= b)
																				{
																					goto IL_057c;
																				}
																				num = 29;
																				goto IL_05a9;
																				IL_057c:
																				if (9 > b)
																				{
																					goto end_IL_027e;
																				}
																				goto IL_0587;
																				IL_0587:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																			}
																			goto end_IL_028e;
																			continue;
																			end_IL_027e:
																			break;
																			IL_027e:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_028e:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_067e;
													IL_067e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05d2:
													break;
												}
												continue;
												end_IL_05e5:
												break;
											}
											continue;
											end_IL_05f0:
											break;
										}
										continue;
										end_IL_05fa:
										break;
									}
									continue;
									end_IL_0605:
									break;
								}
								continue;
								end_IL_061a:
								break;
							}
							continue;
							end_IL_062a:
							break;
						}
						continue;
						end_IL_063a:
						break;
					}
					continue;
					end_IL_064a:
					break;
				}
				continue;
				end_IL_0663:
				break;
			}
		}
	}

	static Class169()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 15;
				while (true)
				{
					if (num == 15 || num != 996)
					{
						return;
					}
					switch (num)
					{
					case 4:
						goto end_IL_0045;
					case 5:
						goto end_IL_0052;
					case 0:
						return;
					case 1:
						return;
					case 2:
						return;
					case 3:
						return;
					case 6:
						return;
					case 7:
						return;
					case 8:
						return;
					}
					continue;
					end_IL_0045:
					break;
				}
				continue;
				end_IL_0052:
				break;
			}
		}
	}

	private static void AllLocalFilesIClosable(bool bool_3)
	{
		Enabled = bool_3;
	}

	private static void getReferenceIdentityDemanded(bool bool_3)
	{
		Enabled = bool_3;
	}
}
