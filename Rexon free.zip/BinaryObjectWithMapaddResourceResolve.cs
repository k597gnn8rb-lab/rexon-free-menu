using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 81)]
internal struct BinaryObjectWithMapaddResourceResolve
{
	internal static BinaryObjectWithMapaddResourceResolve STAThreadAttributeRequired/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 01 01 00 00 00 03 3F 80 00 00 00 00 80 3F 04 05 00 00 00 04 04 00 00 00 05 00 00 00 02 02 00 00 00 06 07 05 00 00 00 4D 4D 00 00 00 05 00 00 00 0B 0B 00 00 00 06 08 09 0A 0B 00 00 00 02 02 00 00 00 0C 0D) */;
}
