using System;
using System.Runtime.CompilerServices;
using BepInEx;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;

[Mod("WASD Fly", "Settings", "WASD keys to fly", false, 13, ModType.const_0, true)]
internal class Class141 : MonoBehaviour
{
	private static string string_0;

	public static float float_0;

	public static Vector3 vector3_0;

	public static float float_1;

	public static float float_2;

	public static float float_3;

	public static float float_4;

	private static int int_0;

	private static float float_5;

	private static int int_1;

	private static double double_0;

	private static bool bool_0;

	private static float float_6;

	private static float float_7;

	private static IntPtr[] GeneratedTypeNamePostfixResourceFallbackCulture;

	private static IntPtr[] CMSSECTIONIDCOUNTERSECTIONTypeContractsAreFor;

	private static IntPtr[] RectgetInitializationFlags;

	private static IntPtr[] SuppressFinalizeConstructionResponse;

	private static IntPtr[] OpenNamespaceArray;

	private static IntPtr[] opDivisionFinal;

	public unsafe static float flySpeed
	{
		get
		{
			double num = float_0;
			GTPlayer instance = GTPlayer.Instance;
			object obj = instance;
			float scale = ((GTPlayer)obj).scale;
			double num2 = scale;
			num *= num2;
			return (float)num;
		}
		set
		{
			int num = 84;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						num = 10;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										float[] array4 = new float[1];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array4[0] = value;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentEncodinggetTicks.SystemEnvironmentBuiltInPermissionFlag);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02f5:
																		if (b >= 1)
																		{
																			while (b <= 16)
																			{
																				while (true)
																				{
																					IL_02d5:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_02c5:
																							if (12 < b)
																							{
																								while (true)
																								{
																									IL_02b5:
																									if (14 < b)
																									{
																										while (true)
																										{
																											IL_02a5:
																											if (15 >= b)
																											{
																												num = 113;
																												while (15 <= b)
																												{
																													num = 149;
																													while (true)
																													{
																														if (num != 149)
																														{
																															if (num != 1130)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 113:
																																goto IL_0292;
																															case 29:
																																goto IL_02a5;
																															case 52:
																																goto IL_02b5;
																															case 128:
																																goto IL_02c5;
																															case 126:
																																goto IL_02d5;
																															case 19:
																																goto IL_02e5;
																															case 50:
																																goto IL_02f5;
																															case 41:
																																goto end_IL_02f5;
																															case 66:
																															case 121:
																																goto end_IL_0305;
																															case 36:
																																goto IL_0320;
																															case 49:
																																goto IL_032e;
																															case 89:
																															case 96:
																																goto IL_033c;
																															case 69:
																																goto IL_0361;
																															case 90:
																																goto IL_037b;
																															case 51:
																																goto IL_038e;
																															case 94:
																																goto IL_0399;
																															case 97:
																																goto IL_03a7;
																															case 78:
																															case 111:
																																goto IL_03b5;
																															case 46:
																															case 114:
																																goto IL_03cd;
																															case 74:
																																goto IL_03f0;
																															case 7:
																																goto IL_03fe;
																															case 4:
																																goto IL_040c;
																															case 80:
																																goto IL_041f;
																															case 27:
																															case 32:
																																goto IL_042a;
																															case 53:
																																goto IL_0443;
																															case 98:
																																goto IL_0451;
																															case 85:
																																goto IL_045f;
																															case 68:
																																goto IL_0472;
																															case 56:
																																goto IL_0480;
																															case 40:
																															case 87:
																																goto IL_048b;
																															case 140:
																																goto IL_04ed;
																															case 59:
																																goto IL_0500;
																															case 115:
																																goto IL_050e;
																															case 9:
																															case 44:
																																goto IL_051c;
																															case 133:
																																goto IL_055c;
																															case 129:
																																goto IL_0579;
																															case 33:
																																goto IL_058c;
																															case 47:
																																goto IL_059a;
																															case 122:
																																goto IL_05bf;
																															case 20:
																															case 21:
																																goto IL_05ca;
																															case 70:
																																goto IL_05dd;
																															case 17:
																																goto IL_05eb;
																															case 2:
																															case 15:
																																goto IL_05f6;
																															case 1:
																																goto IL_0604;
																															case 71:
																																goto IL_0627;
																															case 142:
																																goto IL_0631;
																															case 31:
																																goto IL_063f;
																															case 54:
																																goto IL_0652;
																															case 18:
																																goto IL_0660;
																															case 109:
																																goto IL_066b;
																															case 108:
																																goto IL_0679;
																															case 12:
																															case 38:
																																goto IL_068c;
																															case 116:
																																goto IL_06d5;
																															case 35:
																																goto IL_06e9;
																															case 26:
																																goto IL_06fc;
																															case 102:
																																goto IL_070a;
																															case 103:
																															case 106:
																																goto IL_0718;
																															case 88:
																																goto IL_0741;
																															case 131:
																																goto IL_074f;
																															case 48:
																																goto IL_0762;
																															case 25:
																																goto IL_0770;
																															case 79:
																																goto IL_077e;
																															case 39:
																															case 119:
																																goto IL_078c;
																															case 101:
																																goto IL_07cc;
																															case 67:
																																goto IL_07e0;
																															case 105:
																																goto IL_07fc;
																															case 16:
																															case 112:
																																goto IL_0807;
																															case 76:
																																goto IL_0850;
																															case 86:
																																goto IL_0864;
																															case 77:
																																goto IL_0877;
																															case 132:
																																goto IL_0882;
																															case 45:
																															case 104:
																																goto IL_088d;
																															case 0:
																																goto IL_08cd;
																															case 81:
																																goto IL_08ea;
																															case 5:
																															case 6:
																															case 23:
																															case 37:
																															case 43:
																															case 58:
																															case 61:
																															case 62:
																															case 63:
																															case 64:
																															case 72:
																															case 93:
																															case 95:
																															case 110:
																															case 123:
																															case 127:
																															case 136:
																															case 139:
																															case 141:
																																goto end_IL_027f;
																															case 118:
																																goto IL_0913;
																															case 91:
																																goto IL_092a;
																															case 100:
																																goto IL_0941;
																															case 3:
																															case 8:
																															case 13:
																															case 14:
																															case 22:
																															case 24:
																															case 34:
																															case 42:
																															case 55:
																															case 57:
																															case 65:
																															case 73:
																															case 75:
																															case 99:
																															case 117:
																															case 134:
																															case 135:
																															case 137:
																															case 138:
																																goto end_IL_0315;
																															case 125:
																																goto end_IL_094f;
																															case 30:
																																goto end_IL_0962;
																															case 120:
																																goto end_IL_096c;
																															case 11:
																																goto end_IL_0977;
																															case 28:
																																goto end_IL_098c;
																															case 82:
																															case 124:
																																goto end_IL_099c;
																															case 107:
																																goto end_IL_09ac;
																															case 10:
																																goto end_IL_09bc;
																															case 92:
																																goto end_IL_09cc;
																															case 83:
																																goto end_IL_09dc;
																															case 84:
																																goto end_IL_09f5;
																															case 60:
																															case 130:
																																return;
																															}
																															continue;
																														}
																														goto IL_0361;
																														IL_0361:
																														float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																														goto IL_037b;
																														IL_037b:
																														num6--;
																														goto end_IL_0315;
																														continue;
																														end_IL_027f:
																														break;
																													}
																													break;
																													IL_0292:;
																												}
																												break;
																											}
																											goto IL_0320;
																											IL_032e:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_033c;
																											IL_033c:
																											byte* num7 = ptr2;
																											num5 = 1;
																											ptr2 = num7 + -200;
																											num = 42;
																											goto end_IL_0315;
																											IL_0320:
																											if (16 < b)
																											{
																												break;
																											}
																											goto IL_032e;
																										}
																										break;
																									}
																									goto IL_038e;
																									IL_040c:
																									ptr2 += 8;
																									goto end_IL_0315;
																									IL_038e:
																									if (14 > b)
																									{
																										goto IL_0399;
																									}
																									goto IL_03cd;
																									IL_0399:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_03a7;
																									IL_03a7:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_03b5;
																									IL_03b5:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0315;
																									IL_03cd:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																									goto IL_03f0;
																									IL_03f0:
																									array[num6] = 3;
																									goto IL_03fe;
																									IL_03fe:
																									num6++;
																									goto IL_040c;
																								}
																								break;
																							}
																							goto IL_041f;
																							IL_059a:
																							if (11 > b)
																							{
																								break;
																							}
																							num = 34;
																							goto end_IL_0315;
																							IL_041f:
																							if (12 <= b)
																							{
																								goto IL_042a;
																							}
																							goto IL_0472;
																							IL_042a:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0443;
																							IL_0443:
																							array[num6] = 1;
																							goto IL_0451;
																							IL_0451:
																							num6++;
																							goto IL_045f;
																							IL_045f:
																							ptr2 += 16;
																							goto end_IL_0315;
																							IL_0472:
																							if (10 >= b)
																							{
																								goto IL_0480;
																							}
																							goto IL_058c;
																							IL_0480:
																							if (10 <= b)
																							{
																								goto IL_048b;
																							}
																							goto IL_0500;
																							IL_048b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_04ed;
																							IL_04ed:
																							num6 -= 2;
																							goto end_IL_0315;
																							IL_0500:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_050e;
																							IL_050e:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_051c;
																							IL_051c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_055c;
																							IL_055c:
																							array[num6 - 2] = 0;
																							num = 129;
																							goto IL_0579;
																							IL_0579:
																							num6--;
																							goto end_IL_0315;
																							IL_058c:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_059a;
																						}
																						break;
																					}
																					num = 122;
																					goto IL_05bf;
																					IL_088d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_08cd;
																					IL_08cd:
																					array[num6 - 2] = 0;
																					num = 81;
																					goto IL_08ea;
																					IL_05bf:
																					if (8 <= b)
																					{
																						goto IL_05ca;
																					}
																					goto IL_05dd;
																					IL_05ca:
																					num6--;
																					goto end_IL_0315;
																					IL_05dd:
																					if (4 >= b)
																					{
																						goto IL_05eb;
																					}
																					goto IL_0762;
																					IL_05eb:
																					if (4 <= b)
																					{
																						goto IL_05f6;
																					}
																					goto IL_0652;
																					IL_05f6:
																					array[num6] = 0;
																					goto IL_0604;
																					IL_0604:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0627;
																					IL_0627:
																					array2[num6] = null;
																					goto IL_0631;
																					IL_0631:
																					num6++;
																					goto IL_063f;
																					IL_063f:
																					ptr2 += 8;
																					goto end_IL_0315;
																					IL_0652:
																					if (2 >= b)
																					{
																						goto IL_0660;
																					}
																					goto IL_06fc;
																					IL_0660:
																					if (2 > b)
																					{
																						goto IL_066b;
																					}
																					goto IL_068c;
																					IL_066b:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0679;
																					IL_0679:
																					if (1 > b)
																					{
																					}
																					break;
																					IL_068c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					num = 116;
																					goto IL_06d5;
																					IL_06d5:
																					array[num6 - 2] = 0;
																					goto IL_06e9;
																					IL_06e9:
																					num6--;
																					goto end_IL_0315;
																					IL_06fc:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_070a;
																					IL_070a:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0718;
																					IL_0718:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0741;
																					IL_0741:
																					ptr2 += 8;
																					goto IL_074f;
																					IL_074f:
																					num6--;
																					goto end_IL_0315;
																					IL_0762:
																					if (6 < b)
																					{
																						goto IL_0770;
																					}
																					num = 105;
																					goto IL_07fc;
																					IL_0770:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_077e;
																					IL_077e:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_078c;
																					IL_078c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_07cc;
																					IL_07cc:
																					array[num6 - 2] = 0;
																					goto IL_07e0;
																					IL_07e0:
																					num6--;
																					goto end_IL_0315;
																					IL_08ea:
																					num6--;
																					goto end_IL_0315;
																					IL_07fc:
																					if (6 <= b)
																					{
																						goto IL_0807;
																					}
																					goto IL_0877;
																					IL_0807:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					num = 76;
																					goto IL_0850;
																					IL_0850:
																					array[num6 - 2] = 0;
																					goto IL_0864;
																					IL_0864:
																					num6--;
																					goto end_IL_0315;
																					IL_0877:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_0882;
																					IL_0882:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_088d;
																				}
																				break;
																				IL_02e5:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0913;
																		IL_0941:
																		ptr2 += 8;
																		goto end_IL_0315;
																		IL_092a:
																		num6++;
																		num = 100;
																		goto IL_0941;
																		IL_0913:
																		array[num6] = 0;
																		num = 91;
																		goto IL_092a;
																		continue;
																		end_IL_02f5:
																		break;
																	}
																	continue;
																	end_IL_0305:
																	break;
																}
																continue;
																end_IL_0315:
																break;
															}
															continue;
															end_IL_094f:
															break;
														}
														continue;
														end_IL_0962:
														break;
													}
													continue;
													end_IL_096c:
													break;
												}
												continue;
												end_IL_0977:
												break;
											}
											continue;
											end_IL_098c:
											break;
										}
										continue;
										end_IL_099c:
										break;
									}
									continue;
									end_IL_09ac:
									break;
								}
								continue;
								end_IL_09bc:
								break;
							}
							continue;
							end_IL_09cc:
							break;
						}
						continue;
						end_IL_09dc:
						break;
					}
					continue;
					end_IL_09f5:
					break;
				}
			}
		}
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 94;
		byte* ptr2 = default(byte*);
		byte b = default(byte);
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 97;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 91;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 64;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RestoreFlowAccessRightType.GetRefTypeOfImplTypeDefineEnum);
										num = 108;
										while (true)
										{
											if (num != 108)
											{
												if (num != 1089)
												{
													goto IL_0638;
												}
												switch (num)
												{
												case 64:
													goto end_IL_01bf;
												case 57:
													goto end_IL_01d2;
												case 98:
													goto end_IL_01e6;
												case 65:
												case 91:
													goto end_IL_0204;
												case 89:
													goto end_IL_0214;
												case 92:
												case 97:
													goto end_IL_0224;
												case 93:
													goto end_IL_023d;
												case 94:
													goto end_IL_024d;
												case 3:
												case 12:
												case 15:
												case 20:
												case 27:
												case 33:
												case 38:
												case 39:
												case 41:
												case 44:
												case 72:
												case 76:
												case 79:
													goto IL_0279;
												case 8:
												case 53:
													goto IL_0289;
												case 70:
													goto IL_0292;
												case 7:
													goto IL_02a0;
												case 69:
													goto IL_02ae;
												case 6:
													goto IL_02bc;
												case 46:
													goto IL_02ca;
												case 4:
												case 47:
													goto IL_02d8;
												case 23:
													goto IL_02e6;
												case 67:
												case 82:
													goto IL_02f1;
												case 54:
													goto IL_031a;
												case 5:
													goto IL_0328;
												case 100:
													goto IL_033b;
												case 28:
													goto IL_0349;
												case 31:
												case 43:
													goto IL_0357;
												case 56:
													goto IL_0370;
												case 40:
													goto IL_037e;
												case 2:
													goto IL_038c;
												case 75:
													goto IL_039f;
												case 90:
													goto IL_03aa;
												case 30:
												case 42:
													goto IL_03b8;
												case 9:
													goto IL_03d0;
												case 55:
													goto IL_03de;
												case 24:
												case 51:
													goto IL_03fa;
												case 10:
													goto IL_0408;
												case 34:
													goto IL_042b;
												case 71:
													goto IL_043e;
												case 87:
													goto IL_044c;
												case 68:
												case 95:
													goto IL_0468;
												case 45:
													goto IL_0476;
												case 62:
													goto IL_0484;
												case 36:
													goto IL_048f;
												case 18:
													goto IL_049d;
												case 66:
												case 84:
													goto IL_04ab;
												case 17:
													goto IL_04ce;
												case 49:
													goto IL_04dc;
												case 37:
													goto IL_04ea;
												case 0:
													goto IL_04fd;
												case 26:
												case 48:
													goto IL_050b;
												case 11:
													goto IL_054b;
												case 81:
													goto IL_055f;
												case 25:
												case 96:
													goto IL_0572;
												case 16:
													goto IL_05d4;
												case 14:
												case 50:
													goto IL_05f0;
												case 1:
													goto IL_05fb;
												case 74:
												case 99:
													goto IL_0606;
												case 77:
													goto IL_0622;
												case 88:
													goto IL_062d;
												case 13:
												case 19:
												case 21:
												case 22:
												case 29:
												case 32:
												case 35:
												case 52:
												case 59:
												case 60:
												case 61:
												case 63:
												case 73:
												case 78:
												case 83:
												case 85:
												case 86:
												case 101:
													goto IL_0638;
												case 58:
												case 80:
													goto IL_0650;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_0279;
											IL_05fb:
											if (9 <= b)
											{
												goto IL_0606;
											}
											goto IL_0638;
											IL_0622:
											if (10 >= b)
											{
												goto IL_062d;
											}
											goto IL_0638;
											IL_0606:
											byte* num4 = ptr2;
											num5 = 1;
											ptr2 = num4 + -200;
											goto IL_0279;
											IL_0279:
											if (num5 != 1)
											{
												goto IL_0289;
											}
											goto IL_0650;
											IL_0650:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											IL_0289:
											b = *ptr2;
											goto IL_0292;
											IL_0292:
											ptr2++;
											goto IL_02a0;
											IL_02a0:
											if (b >= 1)
											{
												goto IL_02ae;
											}
											goto IL_0638;
											IL_02ae:
											if (b <= 10)
											{
												goto IL_02bc;
											}
											goto IL_0638;
											IL_02bc:
											if (5 >= b)
											{
												goto IL_02ca;
											}
											goto IL_0468;
											IL_02ca:
											if (5 > b)
											{
												goto IL_02d8;
											}
											goto IL_03fa;
											IL_02d8:
											if (2 >= b)
											{
												goto IL_02e6;
											}
											goto IL_039f;
											IL_02e6:
											if (2 <= b)
											{
												goto IL_02f1;
											}
											goto IL_033b;
											IL_02f1:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_031a;
											IL_031a:
											ptr2 += 8;
											goto IL_0328;
											IL_0328:
											num6--;
											goto IL_0279;
											IL_033b:
											if (1 >= b)
											{
												goto IL_0349;
											}
											goto IL_0638;
											IL_0349:
											if (1 <= b)
											{
												goto IL_0357;
											}
											goto IL_0638;
											IL_0357:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
											goto IL_0370;
											IL_0370:
											array[num6] = 0;
											goto IL_037e;
											IL_037e:
											num6++;
											goto IL_038c;
											IL_038c:
											ptr2 += 8;
											goto IL_0279;
											IL_039f:
											if (3 >= b)
											{
												goto IL_03aa;
											}
											goto IL_03d0;
											IL_03aa:
											if (3 <= b)
											{
												goto IL_03b8;
											}
											goto IL_0638;
											IL_03b8:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0279;
											IL_03d0:
											if (4 >= b)
											{
												goto IL_03de;
											}
											goto IL_0638;
											IL_03de:
											if (4 <= b)
											{
												num = 15;
												goto IL_0279;
											}
											goto IL_0638;
											IL_062d:
											if (10 <= b)
											{
											}
											goto IL_0638;
											IL_03fa:
											array[num6] = 0;
											goto IL_0408;
											IL_0408:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
											goto IL_042b;
											IL_042b:
											array2[num6] = null;
											num = 71;
											goto IL_043e;
											IL_043e:
											num6++;
											goto IL_044c;
											IL_044c:
											ptr2 += 8;
											num = 76;
											goto IL_0279;
											IL_0468:
											if (8 >= b)
											{
												goto IL_0476;
											}
											num = 50;
											goto IL_05f0;
											IL_0476:
											if (8 > b)
											{
												goto IL_0484;
											}
											goto IL_0572;
											IL_0484:
											if (6 < b)
											{
												goto IL_048f;
											}
											goto IL_04fd;
											IL_048f:
											if (7 >= b)
											{
												goto IL_049d;
											}
											goto IL_0638;
											IL_049d:
											if (7 <= b)
											{
												goto IL_04ab;
											}
											goto IL_0638;
											IL_04ab:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
											goto IL_04ce;
											IL_04ce:
											array[num6] = 0;
											goto IL_04dc;
											IL_04dc:
											num6++;
											goto IL_04ea;
											IL_04ea:
											ptr2 += 8;
											goto IL_0279;
											IL_04fd:
											if (6 <= b)
											{
												goto IL_050b;
											}
											goto IL_0638;
											IL_050b:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_054b;
											IL_054b:
											array[num6 - 2] = 0;
											goto IL_055f;
											IL_055f:
											num6--;
											goto IL_0279;
											IL_0572:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_05d4;
											IL_05d4:
											num6 -= 2;
											goto IL_0279;
											IL_0638:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0279;
											IL_05f0:
											if (9 >= b)
											{
												goto IL_05fb;
											}
											goto IL_0622;
											continue;
											end_IL_01bf:
											break;
										}
										continue;
										end_IL_01d2:
										break;
									}
									continue;
									end_IL_01e6:
									break;
								}
								continue;
								end_IL_0204:
								break;
							}
							continue;
							end_IL_0214:
							break;
						}
						continue;
						end_IL_0224:
						break;
					}
					continue;
					end_IL_023d:
					break;
				}
				continue;
				end_IL_024d:
				break;
			}
		}
	}

	private static float CompareOrdinalCOREFILENOTFOUND(float float_8, float float_9, float float_10)
	{
		return Mathf.Clamp(float_8, float_9, float_10);
	}

	private static void SafeLibraryHandleLiveActivities(Rigidbody rigidbody_0, Vector3 vector3_1)
	{
		rigidbody_0.linearVelocity = vector3_1;
	}

	private static Transform ResourceManagerControlClientContextTerminatorSink(VRMap vrmap_0)
	{
		return vrmap_0.rigTarget;
	}

	private static Mouse getAllNoReturnValue()
	{
		return Mouse.current;
	}

	private static Vector2Control IsReadOnlyWriteAllText(Pointer pointer_0)
	{
		return pointer_0.position;
	}

	private static int OSVersionKnownAce(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool SetConstantClassSemanticsMask(ButtonControl buttonControl_0)
	{
		return buttonControl_0.isPressed;
	}

	private static float ArgumentOutOfRangeBiggerThanCollectionMachineAccount()
	{
		return flySpeed;
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PublicsetNegativeInfinitySymbol.DefaultStringServerException);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0326:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0309:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_02f9:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_02e9:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_02d9:
																									if (9 < b)
																									{
																										while (10 >= b)
																										{
																											while (10 <= b)
																											{
																												while (true)
																												{
																													IL_026e:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 147;
																													while (true)
																													{
																														if (num != 147)
																														{
																															if (num != 1128)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 11:
																															case 119:
																																goto IL_026e;
																															case 81:
																																goto IL_02b9;
																															case 88:
																																goto IL_02c9;
																															case 76:
																															case 114:
																																goto IL_02d9;
																															case 67:
																																goto IL_02e9;
																															case 14:
																																goto IL_02f9;
																															case 54:
																																goto end_IL_025b;
																															case 4:
																																goto IL_0316;
																															case 82:
																																goto IL_0326;
																															case 21:
																																goto end_IL_0326;
																															case 45:
																															case 79:
																																goto end_IL_0336;
																															case 42:
																																goto IL_0351;
																															case 43:
																															case 44:
																																goto IL_035c;
																															case 35:
																															case 92:
																																goto IL_036c;
																															case 56:
																																goto IL_03ac;
																															case 18:
																																goto IL_03c0;
																															case 113:
																																goto IL_03d3;
																															case 16:
																															case 87:
																																goto IL_03de;
																															case 59:
																																goto IL_03f6;
																															case 125:
																																goto IL_0404;
																															case 78:
																															case 100:
																																goto IL_0412;
																															case 25:
																																goto IL_042b;
																															case 17:
																																goto IL_0439;
																															case 9:
																																goto IL_0447;
																															case 85:
																															case 130:
																																goto IL_045a;
																															case 127:
																																goto IL_0468;
																															case 2:
																															case 13:
																																goto IL_0476;
																															case 74:
																																goto IL_0484;
																															case 47:
																															case 131:
																																goto IL_0497;
																															case 80:
																																goto IL_04a5;
																															case 8:
																															case 48:
																																goto IL_04b3;
																															case 77:
																																goto IL_04dc;
																															case 6:
																																goto IL_04ea;
																															case 95:
																															case 133:
																																goto IL_04fd;
																															case 34:
																																goto IL_050b;
																															case 19:
																																goto IL_052e;
																															case 75:
																																goto IL_0538;
																															case 97:
																																goto IL_0546;
																															case 134:
																															case 139:
																																goto IL_0562;
																															case 5:
																																goto IL_0570;
																															case 105:
																															case 117:
																																goto IL_057e;
																															case 36:
																																goto IL_05be;
																															case 60:
																																goto IL_05d2;
																															case 118:
																																goto IL_05f9;
																															case 12:
																																goto IL_060c;
																															case 37:
																															case 39:
																																goto IL_0617;
																															case 61:
																																goto IL_0679;
																															case 22:
																																goto IL_068c;
																															case 63:
																																goto IL_069a;
																															case 90:
																															case 121:
																																goto IL_06a8;
																															case 120:
																																goto IL_06cb;
																															case 101:
																																goto IL_06d9;
																															case 26:
																																goto IL_06f0;
																															case 15:
																															case 83:
																																goto IL_0703;
																															case 109:
																																goto IL_0720;
																															case 84:
																																goto IL_075f;
																															case 50:
																																goto IL_0772;
																															case 123:
																															case 126:
																																goto IL_077d;
																															case 40:
																																goto IL_0788;
																															case 93:
																																goto IL_0795;
																															case 41:
																															case 49:
																																goto IL_07a0;
																															case 98:
																																goto IL_07ab;
																															case 32:
																															case 57:
																																goto IL_07b6;
																															case 30:
																															case 128:
																																goto IL_07c6;
																															case 7:
																															case 24:
																															case 31:
																															case 33:
																															case 46:
																															case 53:
																															case 62:
																															case 64:
																															case 65:
																															case 68:
																															case 69:
																															case 86:
																															case 89:
																															case 102:
																															case 103:
																															case 104:
																															case 108:
																															case 110:
																															case 111:
																															case 116:
																															case 124:
																															case 129:
																															case 132:
																															case 135:
																															case 136:
																															case 138:
																																goto end_IL_02b9;
																															case 0:
																															case 1:
																															case 20:
																															case 27:
																															case 29:
																															case 38:
																															case 51:
																															case 52:
																															case 58:
																															case 70:
																															case 71:
																															case 73:
																															case 94:
																															case 99:
																															case 112:
																															case 115:
																															case 122:
																																goto end_IL_0346;
																															case 28:
																																goto end_IL_07fb;
																															case 140:
																																goto end_IL_080e;
																															case 66:
																																goto end_IL_0818;
																															case 23:
																																goto end_IL_0823;
																															case 96:
																															case 137:
																																goto end_IL_0838;
																															case 91:
																																goto end_IL_0848;
																															case 10:
																															case 55:
																																goto end_IL_0858;
																															case 106:
																																goto end_IL_0868;
																															case 107:
																																goto end_IL_0878;
																															case 3:
																															case 72:
																																goto IL_0893;
																															}
																															continue;
																														}
																														array[num5 - 2] = 0;
																														goto IL_05f9;
																														IL_05f9:
																														num5--;
																														goto end_IL_0346;
																														continue;
																														end_IL_025b:
																														break;
																													}
																													break;
																												}
																												goto IL_0309;
																												continue;
																												end_IL_02b9:
																												break;
																												IL_02b9:;
																											}
																											break;
																											IL_02c9:;
																										}
																										break;
																									}
																									goto IL_060c;
																									IL_06f0:
																									ptr2 += 8;
																									goto end_IL_0346;
																									IL_060c:
																									if (9 <= b)
																									{
																										goto IL_0617;
																									}
																									goto IL_068c;
																									IL_0617:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0679;
																									IL_0679:
																									num5 -= 2;
																									goto end_IL_0346;
																									IL_068c:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_069a;
																									IL_069a:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_06a8;
																									IL_06a8:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_06cb;
																									IL_06cb:
																									array[num5] = 0;
																									goto IL_06d9;
																									IL_06d9:
																									num5++;
																									num = 26;
																									goto IL_06f0;
																								}
																								break;
																							}
																							goto IL_0703;
																							IL_075f:
																							ptr2 += 8;
																							goto end_IL_0346;
																							IL_0703:
																							array[num5 - 1] = 0;
																							num = 109;
																							goto IL_0720;
																							IL_0720:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SuppressFinalizeConstructionResponse[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_075f;
																						}
																						break;
																					}
																					goto IL_0772;
																					IL_07c6:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 71;
																					goto end_IL_0346;
																					IL_0772:
																					if (13 < b)
																					{
																						goto IL_077d;
																					}
																					goto IL_0795;
																					IL_077d:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_0788;
																					IL_0788:
																					if (14 > b)
																					{
																					}
																					break;
																					IL_0795:
																					if (13 > b)
																					{
																						goto IL_07a0;
																					}
																					goto IL_07c6;
																					IL_07a0:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_07ab;
																					IL_07ab:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_07b6;
																					IL_07b6:
																					num5--;
																					goto end_IL_0346;
																				}
																				break;
																			}
																			goto IL_0351;
																			IL_03c0:
																			num5--;
																			goto end_IL_0346;
																			IL_0351:
																			if (7 > b)
																			{
																				goto IL_035c;
																			}
																			goto IL_036c;
																			IL_035c:
																			if (3 >= b)
																			{
																				goto IL_03d3;
																			}
																			goto IL_045a;
																			IL_045a:
																			if (5 >= b)
																			{
																				goto IL_0468;
																			}
																			goto IL_0562;
																			IL_0468:
																			if (5 > b)
																			{
																				goto IL_0476;
																			}
																			goto IL_04fd;
																			IL_0476:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0484;
																			IL_0484:
																			if (4 <= b)
																			{
																				goto end_IL_0346;
																			}
																			break;
																			IL_04fd:
																			array[num5] = 0;
																			goto IL_050b;
																			IL_050b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_052e;
																			IL_052e:
																			array2[num5] = null;
																			goto IL_0538;
																			IL_0538:
																			num5++;
																			goto IL_0546;
																			IL_0546:
																			ptr2 += 8;
																			num = 29;
																			goto end_IL_0346;
																			IL_0562:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_0570;
																			IL_0570:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_057e;
																			IL_057e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05be;
																			IL_05be:
																			array[num5 - 2] = 0;
																			goto IL_05d2;
																			IL_05d2:
																			num5--;
																			goto end_IL_0346;
																			IL_03d3:
																			if (3 <= b)
																			{
																				goto IL_03de;
																			}
																			goto IL_03f6;
																			IL_03de:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0346;
																			IL_03f6:
																			if (1 >= b)
																			{
																				goto IL_0404;
																			}
																			goto IL_0497;
																			IL_0404:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0412;
																			IL_0412:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_042b;
																			IL_042b:
																			array[num5] = 0;
																			goto IL_0439;
																			IL_0439:
																			num5++;
																			goto IL_0447;
																			IL_0447:
																			ptr2 += 8;
																			goto end_IL_0346;
																			IL_0497:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04a5;
																			IL_04a5:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04b3;
																			IL_04b3:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04dc;
																			IL_04dc:
																			ptr2 += 8;
																			goto IL_04ea;
																			IL_04ea:
																			num5--;
																			goto end_IL_0346;
																			IL_036c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03ac;
																			IL_03ac:
																			array[num5 - 2] = 0;
																			goto IL_03c0;
																		}
																		break;
																		IL_0316:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0346;
																continue;
																end_IL_0326:
																break;
															}
															continue;
															end_IL_0336:
															break;
														}
														continue;
														end_IL_0346:
														break;
													}
													continue;
												}
												goto IL_0893;
												IL_0893:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07fb:
												break;
											}
											continue;
											end_IL_080e:
											break;
										}
										continue;
										end_IL_0818:
										break;
									}
									continue;
									end_IL_0823:
									break;
								}
								continue;
								end_IL_0838:
								break;
							}
							continue;
							end_IL_0848:
							break;
						}
						continue;
						end_IL_0858:
						break;
					}
					continue;
					end_IL_0868:
					break;
				}
				continue;
				end_IL_0878:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 9;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StartCreateActContextFromCategoryInstance.DelayLoadClientChannelEntryInternalSink);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02bf:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02a2:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0292:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0282:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0272:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0262:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0217:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_01fe:
																																ptr2 += 8;
																																num = 119;
																																while (true)
																																{
																																	if (num != 119)
																																	{
																																		if (num != 1100)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 29:
																																			goto IL_01fe;
																																		case 3:
																																		case 19:
																																			goto IL_0217;
																																		case 34:
																																			goto IL_0242;
																																		case 80:
																																			goto IL_0252;
																																		case 68:
																																		case 77:
																																			goto IL_0262;
																																		case 62:
																																			goto IL_0272;
																																		case 50:
																																			goto IL_0282;
																																		case 106:
																																			goto IL_0292;
																																		case 17:
																																			goto IL_02a2;
																																		case 82:
																																			goto IL_02af;
																																		case 59:
																																			goto IL_02bf;
																																		case 38:
																																			goto end_IL_02bf;
																																		case 14:
																																		case 47:
																																			goto end_IL_02cf;
																																		case 2:
																																		case 23:
																																			goto IL_02ea;
																																		case 45:
																																			goto IL_0301;
																																		case 46:
																																			goto IL_0311;
																																		case 32:
																																		case 48:
																																			goto IL_0324;
																																		case 40:
																																		case 55:
																																			goto IL_0388;
																																		case 6:
																																			goto IL_03c8;
																																		case 71:
																																			goto IL_03e1;
																																		case 53:
																																		case 73:
																																			goto IL_03f4;
																																		case 4:
																																			goto IL_03ff;
																																		case 27:
																																		case 39:
																																			goto IL_040d;
																																		case 7:
																																			goto IL_0456;
																																		case 72:
																																			goto IL_046c;
																																		case 61:
																																			goto IL_047a;
																																		case 10:
																																		case 16:
																																			goto IL_0488;
																																		case 30:
																																			goto IL_04ab;
																																		case 28:
																																			goto IL_04b9;
																																		case 76:
																																			goto IL_04cc;
																																		case 85:
																																			goto IL_04df;
																																		case 33:
																																			goto IL_04ea;
																																		case 12:
																																		case 87:
																																			goto IL_04fd;
																																		case 52:
																																			goto IL_050b;
																																		case 90:
																																			goto IL_051b;
																																		case 15:
																																			goto IL_0526;
																																		case 42:
																																			goto IL_0536;
																																		case 86:
																																			goto IL_0544;
																																		case 91:
																																			goto IL_0557;
																																		case 92:
																																			goto IL_056a;
																																		case 26:
																																		case 97:
																																			goto IL_057d;
																																		case 57:
																																			goto IL_058b;
																																		case 22:
																																		case 107:
																																			goto IL_05b0;
																																		case 111:
																																			goto IL_05d5;
																																		case 24:
																																			goto IL_05df;
																																		case 11:
																																			goto IL_05f6;
																																		case 70:
																																		case 112:
																																			goto IL_0606;
																																		case 110:
																																			goto IL_061f;
																																		case 75:
																																			goto IL_062d;
																																		case 20:
																																			goto IL_063b;
																																		case 1:
																																		case 21:
																																		case 35:
																																		case 41:
																																		case 49:
																																		case 56:
																																		case 58:
																																		case 64:
																																		case 65:
																																		case 66:
																																		case 67:
																																		case 74:
																																		case 83:
																																		case 84:
																																		case 88:
																																		case 89:
																																		case 93:
																																		case 94:
																																		case 98:
																																		case 101:
																																		case 103:
																																			goto end_IL_01eb;
																																		case 99:
																																		case 109:
																																			goto IL_0670;
																																		case 0:
																																		case 5:
																																		case 13:
																																		case 36:
																																		case 43:
																																		case 44:
																																		case 51:
																																		case 69:
																																		case 81:
																																		case 95:
																																		case 96:
																																		case 100:
																																		case 104:
																																		case 108:
																																			goto end_IL_02df;
																																		case 18:
																																			goto end_IL_0683;
																																		case 102:
																																			goto end_IL_0696;
																																		case 63:
																																			goto end_IL_06a0;
																																		case 9:
																																			goto end_IL_06ab;
																																		case 8:
																																		case 60:
																																			goto end_IL_06c0;
																																		case 37:
																																			goto end_IL_06d0;
																																		case 54:
																																		case 105:
																																			goto end_IL_06e9;
																																		case 78:
																																			goto end_IL_06f9;
																																		case 79:
																																			goto end_IL_0709;
																																		case 25:
																																		case 31:
																																			goto IL_0724;
																																		}
																																		continue;
																																	}
																																	num5--;
																																	goto end_IL_02df;
																																	continue;
																																	end_IL_01eb:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																														IL_0242:;
																													}
																													break;
																													IL_0252:;
																												}
																												break;
																											}
																											goto IL_0311;
																											IL_063b:
																											ptr2 += 8;
																											goto end_IL_02df;
																											IL_0311:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0606;
																											IL_0606:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_061f;
																											IL_061f:
																											array[num5] = 0;
																											goto IL_062d;
																											IL_062d:
																											num5++;
																											goto IL_063b;
																										}
																										break;
																									}
																									goto IL_0670;
																									IL_0670:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02df;
																								}
																								break;
																							}
																							goto IL_04df;
																							IL_05f6:
																							ptr2 += 8;
																							goto end_IL_02df;
																							IL_04df:
																							if (4 >= b)
																							{
																								goto IL_04ea;
																							}
																							goto IL_04fd;
																							IL_04ea:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_02df;
																							IL_04fd:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_050b;
																							IL_050b:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_057d;
																							IL_057d:
																							array[num5] = 0;
																							goto IL_058b;
																							IL_058b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05d5;
																							IL_05d5:
																							array2[num5] = null;
																							goto IL_05df;
																							IL_05df:
																							num5++;
																							num = 11;
																							goto IL_05f6;
																						}
																						break;
																					}
																					goto IL_0388;
																					IL_0557:
																					num5--;
																					goto end_IL_02df;
																					IL_0388:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c8;
																					IL_03c8:
																					array[num5 - 2] = 0;
																					goto IL_0557;
																				}
																				break;
																			}
																			goto IL_02ea;
																			IL_0536:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0544;
																			IL_02ea:
																			if (9 >= b)
																			{
																				num = 45;
																				goto IL_0301;
																			}
																			goto IL_051b;
																			IL_0544:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0301:
																			if (9 <= b)
																			{
																				goto IL_0324;
																			}
																			goto IL_03f4;
																			IL_03f4:
																			if (7 >= b)
																			{
																				goto IL_03ff;
																			}
																			goto IL_046c;
																			IL_03ff:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_040d;
																			IL_040d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 7;
																			goto IL_0456;
																			IL_0456:
																			array[num5 - 2] = 0;
																			goto IL_04cc;
																			IL_04cc:
																			num5--;
																			goto end_IL_02df;
																			IL_046c:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_047a;
																			IL_047a:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0488;
																			IL_0488:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04ab;
																			IL_04ab:
																			array[num5] = 0;
																			goto IL_04b9;
																			IL_04b9:
																			num5++;
																			goto IL_056a;
																			IL_056a:
																			ptr2 += 8;
																			goto end_IL_02df;
																			IL_0324:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03e1;
																			IL_03e1:
																			num5 -= 2;
																			goto end_IL_02df;
																			IL_051b:
																			if (10 >= b)
																			{
																				goto IL_0526;
																			}
																			goto IL_0536;
																			IL_0526:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_05b0;
																			IL_05b0:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 108;
																			goto end_IL_02df;
																		}
																		break;
																		IL_02af:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02df;
																continue;
																end_IL_02bf:
																break;
															}
															continue;
															end_IL_02cf:
															break;
														}
														continue;
														end_IL_02df:
														break;
													}
													continue;
												}
												goto IL_0724;
												IL_0724:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0683:
												break;
											}
											continue;
											end_IL_0696:
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e9:
						break;
					}
					continue;
					end_IL_06f9:
					break;
				}
				continue;
				end_IL_0709:
				break;
			}
		}
	}

	public unsafe static void smethod_3()
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					while (true)
					{
						IL_007f:
						if (num3 == 31)
						{
							num = 14;
							while (true)
							{
								if (num != 14)
								{
									if (num != 995)
									{
										break;
									}
									switch (num)
									{
									case 3:
										break;
									default:
										continue;
									case 1:
									case 2:
										goto IL_007f;
									case 0:
										goto end_IL_0072;
									case 6:
										goto end_IL_0087;
									case 7:
										goto end_IL_008c;
									case 4:
									case 5:
										return;
									}
									goto IL_000e;
								}
								num3 = 0;
								return;
								continue;
								end_IL_0072:
								break;
							}
							break;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, void>)CMSSECTIONIDCOUNTERSECTIONTypeContractsAreFor[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11);
					}
					continue;
					end_IL_0087:
					break;
				}
				continue;
				end_IL_008c:
				break;
			}
		}
	}

	private static double TokenElevationTypeNN(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static bool smethod_4(Vector3 vector3_1, Vector3 vector3_2)
	{
		return vector3_1 != vector3_2;
	}

	public Class141()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static float MetadataSectionResourceTypeManifestResourcesDependencyCMSFILEWRITABLETYPEAPPLICATIONDATA(Vector3 vector3_1)
	{
		return vector3_1.x;
	}

	private static int smethod_5(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			return num - num2;
		}
		num = int_2;
		num2 = int_3;
		return num - num2;
	}

	private static Vector3 digitsPrint()
	{
		return global::_003CModule_003E.vector3_109;
	}

	private static Vector3 MngdSafeArrayMarshalerDisconnect(Transform transform_0)
	{
		return transform_0.forward;
	}

	private static bool IncrementReferenceCountgetUrl()
	{
		return BundleManager.IsSearchInputFocused;
	}

	private static Vector3 RaiseDeserializationEventUTFEncodingSealed()
	{
		return Vector3.zero;
	}

	private static float MkrefanysetUseSalt()
	{
		return Time.deltaTime;
	}

	private unsafe void Update()
	{
		int num = 177;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenericTypeParametersdefaultPermissionSetID.LocalSiteStringXMLUtil);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													IL_03fd:
													byte b = *ptr2;
													while (true)
													{
														IL_03ed:
														ptr2++;
														while (true)
														{
															IL_03dd:
															if (b >= 1)
															{
																while (b <= 25)
																{
																	while (true)
																	{
																		IL_03bd:
																		if (13 >= b)
																		{
																			while (true)
																			{
																				IL_03b0:
																				if (13 > b)
																				{
																					while (true)
																					{
																						IL_03a0:
																						if (6 >= b)
																						{
																							while (true)
																							{
																								IL_0390:
																								if (6 <= b)
																								{
																									num = 216;
																									while (true)
																									{
																										if (num != 216)
																										{
																											if (num != 1197)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 160:
																												goto IL_0390;
																											case 115:
																												goto IL_03a0;
																											case 107:
																												goto IL_03b0;
																											case 16:
																												goto IL_03bd;
																											case 79:
																												goto IL_03cd;
																											case 108:
																												goto IL_03dd;
																											case 89:
																												goto IL_03ed;
																											case 96:
																											case 187:
																												goto IL_03fd;
																											case 1:
																												goto IL_0408;
																											case 15:
																												goto IL_0416;
																											case 68:
																											case 71:
																												goto IL_0426;
																											case 159:
																												goto IL_043e;
																											case 20:
																											case 136:
																												goto IL_044c;
																											case 25:
																												goto IL_045a;
																											case 109:
																												goto IL_047d;
																											case 76:
																												goto IL_0487;
																											case 73:
																												goto IL_0495;
																											case 169:
																												goto IL_04a8;
																											case 184:
																												goto IL_04b6;
																											case 36:
																											case 91:
																												goto IL_04c4;
																											case 14:
																												goto IL_0504;
																											case 19:
																												goto IL_0518;
																											case 203:
																												goto IL_052b;
																											case 58:
																											case 60:
																												goto IL_0536;
																											case 120:
																												goto IL_055f;
																											case 39:
																												goto IL_056d;
																											case 43:
																												goto IL_0589;
																											case 5:
																												goto IL_0594;
																											case 150:
																											case 179:
																												goto IL_05a2;
																											case 51:
																												goto IL_05bb;
																											case 141:
																												goto IL_05c9;
																											case 139:
																												goto IL_05d7;
																											case 57:
																												goto IL_05ea;
																											case 202:
																												goto IL_05f8;
																											case 153:
																											case 190:
																												goto IL_0606;
																											case 205:
																												goto IL_0646;
																											case 116:
																												goto IL_065a;
																											case 128:
																												goto IL_066d;
																											case 206:
																												goto IL_06b6;
																											case 17:
																												goto IL_06ca;
																											case 69:
																												goto IL_06e6;
																											case 0:
																												goto IL_06f4;
																											case 123:
																											case 132:
																												goto IL_06ff;
																											case 47:
																												goto IL_073f;
																											case 6:
																												goto IL_0753;
																											case 155:
																												goto IL_0766;
																											case 3:
																												goto IL_0771;
																											case 75:
																											case 112:
																												goto IL_077f;
																											case 143:
																												goto IL_07bf;
																											case 87:
																												goto IL_07d3;
																											case 166:
																												goto IL_07ef;
																											case 53:
																												goto IL_07fd;
																											case 26:
																											case 80:
																												goto IL_080b;
																											case 180:
																												goto IL_081e;
																											case 41:
																												goto IL_082c;
																											case 56:
																												goto IL_083a;
																											case 100:
																												goto IL_0848;
																											case 175:
																											case 186:
																												goto IL_0856;
																											case 77:
																												goto IL_08b8;
																											case 185:
																												goto IL_08cb;
																											case 24:
																												goto IL_08d9;
																											case 31:
																											case 65:
																												goto IL_08e7;
																											case 124:
																												goto IL_0900;
																											case 32:
																												goto IL_090e;
																											case 99:
																												goto IL_091c;
																											case 165:
																												goto IL_092f;
																											case 28:
																												goto IL_093d;
																											case 119:
																											case 121:
																												goto IL_0948;
																											case 38:
																												goto IL_095c;
																											case 21:
																												goto IL_099b;
																											case 195:
																												goto IL_09ae;
																											case 85:
																												goto IL_09bc;
																											case 10:
																												goto IL_09ca;
																											case 34:
																												goto IL_09d5;
																											case 146:
																											case 181:
																												goto IL_09e3;
																											case 54:
																												goto IL_0a2d;
																											case 50:
																												goto IL_0a41;
																											case 59:
																												goto IL_0a54;
																											case 199:
																												goto IL_0a6b;
																											case 63:
																											case 196:
																												goto IL_0a79;
																											case 164:
																												goto IL_0acb;
																											case 174:
																											case 194:
																												goto IL_0ae7;
																											case 97:
																												goto IL_0afc;
																											case 127:
																												goto IL_0b0f;
																											case 23:
																												goto IL_0b1a;
																											case 4:
																											case 90:
																												goto IL_0b28;
																											case 135:
																												goto IL_0b41;
																											case 189:
																												goto IL_0b4f;
																											case 129:
																												goto IL_0b5d;
																											case 72:
																												goto IL_0b70;
																											case 92:
																												goto IL_0b7e;
																											case 88:
																											case 117:
																												goto IL_0b8c;
																											case 148:
																												goto IL_0bcc;
																											case 84:
																												goto IL_0be0;
																											case 154:
																												goto IL_0bf3;
																											case 156:
																												goto IL_0c01;
																											case 122:
																												goto IL_0c0f;
																											case 161:
																											case 178:
																												goto IL_0c1a;
																											case 130:
																												goto IL_0c36;
																											case 61:
																												goto IL_0c44;
																											case 8:
																											case 151:
																												goto IL_0c52;
																											case 33:
																												goto IL_0c92;
																											case 142:
																												goto IL_0ca6;
																											case 162:
																												goto IL_0cb9;
																											case 106:
																												goto IL_0cc7;
																											case 170:
																												goto IL_0cda;
																											case 44:
																											case 126:
																												goto IL_0ce5;
																											case 52:
																												goto IL_0cf9;
																											case 110:
																												goto IL_0d38;
																											case 55:
																												goto IL_0d4b;
																											case 9:
																												goto IL_0d56;
																											case 42:
																											case 198:
																												goto IL_0d64;
																											case 200:
																												goto IL_0d72;
																											case 83:
																												goto IL_0d9f;
																											case 163:
																												goto IL_0dad;
																											case 64:
																												goto IL_0dc0;
																											case 209:
																												goto IL_0dd7;
																											case 30:
																											case 114:
																												goto IL_0de2;
																											case 147:
																												goto IL_0e40;
																											case 7:
																											case 18:
																											case 27:
																											case 37:
																											case 40:
																											case 45:
																											case 46:
																											case 74:
																											case 81:
																											case 94:
																											case 95:
																											case 98:
																											case 102:
																											case 103:
																											case 104:
																											case 105:
																											case 131:
																											case 133:
																											case 137:
																											case 138:
																											case 145:
																											case 152:
																											case 167:
																											case 182:
																											case 183:
																											case 193:
																											case 201:
																											case 208:
																												goto end_IL_03cd;
																											case 2:
																											case 12:
																											case 13:
																											case 29:
																											case 48:
																											case 62:
																											case 67:
																											case 70:
																											case 78:
																											case 82:
																											case 93:
																											case 111:
																											case 113:
																											case 118:
																											case 125:
																											case 134:
																											case 140:
																											case 149:
																											case 157:
																											case 158:
																											case 168:
																											case 171:
																											case 173:
																											case 188:
																											case 191:
																											case 197:
																											case 204:
																											case 207:
																												goto end_IL_037d;
																											case 86:
																												goto end_IL_0e63;
																											case 144:
																												goto end_IL_0e76;
																											case 101:
																												goto end_IL_0e80;
																											case 35:
																											case 49:
																												goto end_IL_0e8b;
																											case 192:
																												goto end_IL_0e9b;
																											case 172:
																												goto end_IL_0eab;
																											case 11:
																												goto end_IL_0ebb;
																											case 176:
																												goto end_IL_0ecb;
																											case 177:
																												goto end_IL_0edb;
																											case 22:
																											case 66:
																												return;
																											}
																											continue;
																										}
																										goto IL_066d;
																										IL_06b6:
																										array[num6 - 2] = 0;
																										goto IL_06ca;
																										IL_06ca:
																										num6--;
																										num = 29;
																										break;
																										IL_066d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 206;
																										goto IL_06b6;
																										continue;
																										end_IL_037d:
																										break;
																									}
																									break;
																								}
																								goto IL_0408;
																								IL_0646:
																								array[num6 - 2] = 0;
																								goto IL_065a;
																								IL_065a:
																								num6--;
																								break;
																								IL_0408:
																								if (3 < b)
																								{
																									goto IL_0416;
																								}
																								goto IL_052b;
																								IL_0416:
																								if (4 >= b)
																								{
																									goto IL_043e;
																								}
																								goto IL_04a8;
																								IL_043e:
																								if (4 > b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_044c;
																								IL_044c:
																								array[num6] = 0;
																								goto IL_045a;
																								IL_045a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_047d;
																								IL_047d:
																								array2[num6] = null;
																								goto IL_0487;
																								IL_0487:
																								num6++;
																								goto IL_0495;
																								IL_0495:
																								ptr2 += 8;
																								break;
																								IL_04a8:
																								if (5 < b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_04b6;
																								IL_04b6:
																								if (5 > b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_04c4;
																								IL_04c4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0504;
																								IL_0504:
																								array[num6 - 2] = 0;
																								goto IL_0518;
																								IL_0518:
																								num6--;
																								break;
																								IL_052b:
																								if (3 <= b)
																								{
																									goto IL_0536;
																								}
																								goto IL_0589;
																								IL_0536:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_055f;
																								IL_055f:
																								ptr2 += 8;
																								goto IL_056d;
																								IL_056d:
																								num6--;
																								num = 13;
																								break;
																								IL_0589:
																								if (1 >= b)
																								{
																									goto IL_0594;
																								}
																								goto IL_05ea;
																								IL_0594:
																								if (1 > b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_05a2;
																								IL_05a2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																								goto IL_05bb;
																								IL_05bb:
																								array[num6] = 0;
																								goto IL_05c9;
																								IL_05c9:
																								num6++;
																								goto IL_05d7;
																								IL_05d7:
																								ptr2 += 8;
																								break;
																								IL_05ea:
																								if (2 < b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_05f8;
																								IL_05f8:
																								if (2 > b)
																								{
																									goto end_IL_03cd;
																								}
																								goto IL_0606;
																								IL_0606:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0646;
																							}
																							break;
																						}
																						goto IL_06e6;
																						IL_091c:
																						ptr2 += 16;
																						break;
																						IL_06e6:
																						if (9 >= b)
																						{
																							goto IL_06f4;
																						}
																						goto IL_081e;
																						IL_06f4:
																						if (9 <= b)
																						{
																							goto IL_06ff;
																						}
																						goto IL_0766;
																						IL_06ff:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_073f;
																						IL_073f:
																						array[num6 - 2] = 0;
																						goto IL_0753;
																						IL_0753:
																						num6--;
																						break;
																						IL_0766:
																						if (7 >= b)
																						{
																							goto IL_0771;
																						}
																						goto IL_07ef;
																						IL_0771:
																						if (7 > b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_077f;
																						IL_077f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_07bf;
																						IL_07bf:
																						array[num6 - 2] = 0;
																						goto IL_07d3;
																						IL_07d3:
																						num6--;
																						num = 173;
																						break;
																						IL_07ef:
																						if (8 < b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_07fd;
																						IL_07fd:
																						if (8 > b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_080b;
																						IL_080b:
																						num6--;
																						break;
																						IL_081e:
																						if (11 >= b)
																						{
																							goto IL_082c;
																						}
																						goto IL_08cb;
																						IL_082c:
																						if (11 <= b)
																						{
																							break;
																						}
																						goto IL_083a;
																						IL_083a:
																						if (10 < b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_0848;
																						IL_0848:
																						if (10 > b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_0856;
																						IL_0856:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_08b8;
																						IL_08b8:
																						num6 -= 2;
																						break;
																						IL_08cb:
																						if (12 < b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_08d9;
																						IL_08d9:
																						if (12 > b)
																						{
																							goto end_IL_03cd;
																						}
																						goto IL_08e7;
																						IL_08e7:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0900;
																						IL_0900:
																						array[num6] = 1;
																						goto IL_090e;
																						IL_090e:
																						num6++;
																						goto IL_091c;
																					}
																					break;
																				}
																				goto IL_0426;
																				IL_0426:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																			}
																			break;
																		}
																		goto IL_092f;
																		IL_0e40:
																		num6--;
																		break;
																		IL_092f:
																		if (19 >= b)
																		{
																			goto IL_093d;
																		}
																		goto IL_0bf3;
																		IL_093d:
																		if (19 <= b)
																		{
																			goto IL_0948;
																		}
																		goto IL_09ae;
																		IL_0948:
																		array[num6 - 1] = 0;
																		goto IL_095c;
																		IL_095c:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)GeneratedTypeNamePostfixResourceFallbackCulture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_099b;
																		IL_099b:
																		ptr2 += 8;
																		break;
																		IL_09ae:
																		if (16 >= b)
																		{
																			goto IL_09bc;
																		}
																		goto IL_0b0f;
																		IL_09bc:
																		if (16 > b)
																		{
																			goto IL_09ca;
																		}
																		num = 194;
																		goto IL_0ae7;
																		IL_09ca:
																		if (14 >= b)
																		{
																			goto IL_09d5;
																		}
																		goto IL_0a54;
																		IL_09d5:
																		if (14 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_09e3;
																		IL_09e3:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																		num = 54;
																		goto IL_0a2d;
																		IL_0a2d:
																		array[num6 - 2] = 0;
																		goto IL_0a41;
																		IL_0a41:
																		num6--;
																		break;
																		IL_0a54:
																		if (15 < b)
																		{
																			goto end_IL_03cd;
																		}
																		num = 199;
																		goto IL_0a6b;
																		IL_0de2:
																		ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0e40;
																		IL_0a6b:
																		if (15 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0a79;
																		IL_0a79:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0acb;
																		IL_0acb:
																		num6--;
																		break;
																		IL_0dd7:
																		if (21 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0de2;
																		IL_0ae7:
																		((delegate*<void>)GeneratedTypeNamePostfixResourceFallbackCulture[*(int*)(ptr2 + num3)])();
																		goto IL_0afc;
																		IL_0afc:
																		ptr2 += 8;
																		break;
																		IL_0b0f:
																		if (17 >= b)
																		{
																			goto IL_0b1a;
																		}
																		goto IL_0b70;
																		IL_0b1a:
																		if (17 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0b28;
																		IL_0b28:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0b41;
																		IL_0b41:
																		array[num6] = 3;
																		goto IL_0b4f;
																		IL_0b4f:
																		num6++;
																		goto IL_0b5d;
																		IL_0b5d:
																		ptr2 += 16;
																		break;
																		IL_0b70:
																		if (18 < b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0b7e;
																		IL_0b7e:
																		if (18 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0b8c;
																		IL_0b8c:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0bcc;
																		IL_0bcc:
																		array[num6 - 2] = 3;
																		goto IL_0be0;
																		IL_0be0:
																		num6--;
																		break;
																		IL_0bf3:
																		if (22 < b)
																		{
																			goto IL_0c01;
																		}
																		goto IL_0cda;
																		IL_0c01:
																		if (24 >= b)
																		{
																			goto IL_0c0f;
																		}
																		goto IL_0cb9;
																		IL_0c0f:
																		if (24 <= b)
																		{
																			goto IL_0c1a;
																		}
																		goto IL_0c36;
																		IL_0c1a:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		break;
																		IL_0c36:
																		if (23 < b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0c44;
																		IL_0c44:
																		if (23 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0c52;
																		IL_0c52:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0c92;
																		IL_0c92:
																		array[num6 - 2] = 3;
																		goto IL_0ca6;
																		IL_0ca6:
																		num6--;
																		break;
																		IL_0cb9:
																		if (25 < b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0cc7;
																		IL_0cc7:
																		if (25 > b)
																		{
																		}
																		goto end_IL_03cd;
																		IL_0cda:
																		if (22 <= b)
																		{
																			goto IL_0ce5;
																		}
																		goto IL_0d4b;
																		IL_0ce5:
																		array[num6 - 1] = 3;
																		goto IL_0cf9;
																		IL_0cf9:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GeneratedTypeNamePostfixResourceFallbackCulture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0d38;
																		IL_0d38:
																		ptr2 += 8;
																		break;
																		IL_0d4b:
																		if (20 >= b)
																		{
																			goto IL_0d56;
																		}
																		goto IL_0dc0;
																		IL_0d56:
																		if (20 > b)
																		{
																			goto end_IL_03cd;
																		}
																		goto IL_0d64;
																		IL_0d64:
																		array[num6] = 0;
																		goto IL_0d72;
																		IL_0d72:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)GeneratedTypeNamePostfixResourceFallbackCulture[*(int*)(ptr2 + num3)])() ? 1 : 0);
																		num = 83;
																		goto IL_0d9f;
																		IL_0d9f:
																		num6++;
																		goto IL_0dad;
																		IL_0dad:
																		ptr2 += 8;
																		break;
																		IL_0dc0:
																		if (21 < b)
																		{
																			goto end_IL_03cd;
																		}
																		num = 209;
																		goto IL_0dd7;
																	}
																	goto end_IL_03dd;
																	continue;
																	end_IL_03cd:
																	break;
																	IL_03cd:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															continue;
															end_IL_03dd:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_0e63:
												break;
											}
											continue;
											end_IL_0e76:
											break;
										}
										continue;
										end_IL_0e80:
										break;
									}
									continue;
									end_IL_0e8b:
									break;
								}
								continue;
								end_IL_0e9b:
								break;
							}
							continue;
							end_IL_0eab:
							break;
						}
						continue;
						end_IL_0ebb:
						break;
					}
					continue;
					end_IL_0ecb:
					break;
				}
				continue;
				end_IL_0edb:
				break;
			}
		}
	}

	private static Rigidbody BoxedGetHashFromBlob(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rigidbody;
	}

	private static VRRig UnsafeDeserializeMethodResponseELEMDESC()
	{
		return VRRig.LocalRig;
	}

	private static Transform NameCacheCspParameters(Component component_0)
	{
		return component_0.transform;
	}

	private static GorillaTagger EnsureCurrentThreadHasQueuePrograms()
	{
		return GorillaTagger.Instance;
	}

	private static Quaternion TaskContinuationEnum(Transform transform_0)
	{
		return transform_0.rotation;
	}

	private unsafe static int smethod_7()
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 48;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getLinuxCMSENTRYPOINTFLAGCUSTOMUX.RegisterInteropXmlElementGetRect);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_03a2:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0385:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_0375:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_0365:
																							if (13 > b)
																							{
																								while (true)
																								{
																									IL_0355:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0345:
																											if (11 > b)
																											{
																												while (true)
																												{
																													IL_0335:
																													if (10 >= b)
																													{
																														while (10 <= b)
																														{
																															while (true)
																															{
																																IL_0315:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_02f0:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_02db:
																																		array2[num5] = null;
																																		num = 9;
																																		while (true)
																																		{
																																			IL_02c2:
																																			num5++;
																																			num = 168;
																																			while (true)
																																			{
																																				if (num != 168)
																																				{
																																					if (num != 1149)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 9:
																																						goto IL_02c2;
																																					case 75:
																																						goto IL_02db;
																																					case 110:
																																						goto IL_02f0;
																																					case 18:
																																					case 83:
																																						goto IL_0315;
																																					case 147:
																																						goto IL_0325;
																																					case 133:
																																						goto IL_0335;
																																					case 60:
																																						goto IL_0345;
																																					case 5:
																																					case 79:
																																						goto IL_0355;
																																					case 42:
																																						goto IL_0365;
																																					case 36:
																																						goto IL_0375;
																																					case 138:
																																						goto IL_0385;
																																					case 159:
																																						goto IL_0392;
																																					case 53:
																																						goto IL_03a2;
																																					case 51:
																																						goto end_IL_03a2;
																																					case 11:
																																					case 106:
																																						goto end_IL_03b2;
																																					case 113:
																																						goto IL_03db;
																																					case 40:
																																					case 112:
																																						goto IL_03e9;
																																					case 99:
																																						goto IL_03f7;
																																					case 91:
																																						goto IL_0402;
																																					case 98:
																																						goto IL_040d;
																																					case 94:
																																						goto IL_041b;
																																					case 33:
																																						goto IL_0429;
																																					case 4:
																																					case 97:
																																						goto IL_043c;
																																					case 86:
																																						goto IL_045a;
																																					case 55:
																																						goto IL_0468;
																																					case 3:
																																					case 124:
																																						goto IL_047b;
																																					case 80:
																																						goto IL_0486;
																																					case 30:
																																					case 136:
																																						goto IL_04a4;
																																					case 134:
																																						goto IL_04e4;
																																					case 109:
																																						goto IL_04f8;
																																					case 17:
																																					case 140:
																																						goto IL_050b;
																																					case 103:
																																						goto IL_0534;
																																					case 71:
																																					case 146:
																																						goto IL_054d;
																																					case 63:
																																						goto IL_0566;
																																					case 104:
																																						goto end_IL_02af;
																																					case 35:
																																						goto IL_058b;
																																					case 127:
																																					case 153:
																																						goto IL_059e;
																																					case 100:
																																						goto IL_05a9;
																																					case 72:
																																					case 119:
																																						goto IL_05b4;
																																					case 27:
																																						goto IL_05f3;
																																					case 20:
																																					case 131:
																																						goto IL_0606;
																																					case 107:
																																						goto IL_0614;
																																					case 74:
																																						goto IL_0627;
																																					case 31:
																																						goto IL_0632;
																																					case 69:
																																					case 139:
																																						goto IL_0640;
																																					case 92:
																																						goto IL_0669;
																																					case 1:
																																						goto IL_0677;
																																					case 47:
																																					case 156:
																																						goto IL_068a;
																																					case 150:
																																						goto IL_0698;
																																					case 57:
																																					case 68:
																																						goto IL_06af;
																																					case 116:
																																					case 158:
																																						goto IL_06c7;
																																					case 95:
																																						goto IL_070b;
																																					case 2:
																																						goto IL_071f;
																																					case 82:
																																					case 161:
																																						goto IL_0732;
																																					case 108:
																																						goto IL_0740;
																																					case 101:
																																						goto IL_0758;
																																					case 65:
																																						goto IL_076f;
																																					case 24:
																																						goto IL_0795;
																																					case 43:
																																						goto IL_07a3;
																																					case 26:
																																					case 85:
																																						goto IL_07b1;
																																					case 34:
																																						goto IL_07f1;
																																					case 62:
																																						goto IL_0805;
																																					case 87:
																																					case 154:
																																						goto IL_0818;
																																					case 49:
																																						goto IL_087a;
																																					case 10:
																																						goto IL_088d;
																																					case 84:
																																					case 89:
																																						goto IL_0898;
																																					case 122:
																																						goto IL_08a3;
																																					case 25:
																																					case 41:
																																						goto IL_08b1;
																																					case 45:
																																						goto IL_08cd;
																																					case 67:
																																						goto IL_08db;
																																					case 76:
																																						goto IL_08ee;
																																					case 56:
																																					case 142:
																																						goto IL_08f9;
																																					case 105:
																																						goto IL_0904;
																																					case 21:
																																					case 125:
																																						goto IL_090f;
																																					case 157:
																																						goto IL_0923;
																																					case 145:
																																						goto IL_0962;
																																					case 13:
																																					case 23:
																																						goto IL_0972;
																																					case 0:
																																					case 7:
																																					case 8:
																																					case 15:
																																					case 19:
																																					case 22:
																																					case 46:
																																					case 50:
																																					case 54:
																																					case 58:
																																					case 61:
																																					case 66:
																																					case 70:
																																					case 73:
																																					case 81:
																																					case 90:
																																					case 102:
																																					case 115:
																																					case 118:
																																					case 120:
																																					case 121:
																																					case 129:
																																					case 135:
																																					case 141:
																																					case 144:
																																					case 149:
																																					case 152:
																																					case 160:
																																						goto end_IL_0325;
																																					case 6:
																																					case 16:
																																					case 29:
																																					case 39:
																																					case 44:
																																					case 59:
																																					case 64:
																																					case 77:
																																					case 78:
																																					case 88:
																																					case 96:
																																					case 114:
																																					case 117:
																																					case 123:
																																					case 126:
																																					case 130:
																																					case 137:
																																					case 143:
																																					case 148:
																																					case 151:
																																						goto end_IL_03c2;
																																					case 155:
																																						goto end_IL_099e;
																																					case 128:
																																						goto end_IL_09b1;
																																					case 12:
																																						goto end_IL_09bb;
																																					case 14:
																																						goto end_IL_09c6;
																																					case 52:
																																					case 111:
																																						goto end_IL_09d6;
																																					case 93:
																																						goto end_IL_09e6;
																																					case 32:
																																					case 48:
																																						goto end_IL_09f6;
																																					case 37:
																																						goto end_IL_0a06;
																																					case 38:
																																						goto end_IL_0a16;
																																					case 28:
																																					case 132:
																																						goto IL_0a3a;
																																					}
																																					continue;
																																				}
																																				ptr2 += 8;
																																				goto end_IL_03c2;
																																				continue;
																																				end_IL_02af:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_057d;
																															continue;
																															end_IL_0325:
																															break;
																															IL_0325:;
																														}
																													}
																													else
																													{
																														num = 15;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_06c7;
																											IL_071f:
																											num5--;
																											goto end_IL_03c2;
																											IL_06c7:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_070b;
																											IL_070b:
																											array[num5 - 2] = 0;
																											goto IL_071f;
																										}
																										break;
																									}
																									goto IL_0795;
																									IL_0805:
																									num5--;
																									goto end_IL_03c2;
																									IL_0795:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_07a3;
																									IL_07a3:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_07b1;
																									IL_07b1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_07f1;
																									IL_07f1:
																									array[num5 - 2] = 0;
																									goto IL_0805;
																								}
																								break;
																							}
																							goto IL_0818;
																							IL_087a:
																							num5 -= 2;
																							goto end_IL_03c2;
																							IL_0818:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_087a;
																						}
																						break;
																					}
																					goto IL_088d;
																					IL_0972:
																					num5--;
																					goto end_IL_03c2;
																					IL_088d:
																					if (15 < b)
																					{
																						goto IL_0898;
																					}
																					goto IL_08ee;
																					IL_0898:
																					if (16 >= b)
																					{
																						goto IL_08a3;
																					}
																					goto IL_08cd;
																					IL_08a3:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_08b1;
																					IL_08b1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_03c2;
																					IL_08cd:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_08db;
																					IL_08db:
																					if (17 <= b)
																					{
																					}
																					break;
																					IL_08ee:
																					if (15 > b)
																					{
																						goto IL_08f9;
																					}
																					goto IL_0972;
																					IL_08f9:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_0904;
																					IL_0904:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_090f;
																					IL_090f:
																					array[num5 - 1] = 0;
																					goto IL_0923;
																					IL_0923:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)opDivisionFinal[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0962;
																					IL_0962:
																					ptr2 += 8;
																					goto end_IL_03c2;
																				}
																				break;
																			}
																			goto IL_03db;
																			IL_0698:
																			if (8 > b)
																			{
																				break;
																			}
																			num = 68;
																			goto IL_06af;
																			IL_03db:
																			if (9 <= b)
																			{
																				goto end_IL_03c2;
																			}
																			goto IL_03e9;
																			IL_03e9:
																			if (4 >= b)
																			{
																				goto IL_03f7;
																			}
																			goto IL_059e;
																			IL_03f7:
																			if (4 > b)
																			{
																				goto IL_0402;
																			}
																			goto IL_043c;
																			IL_0402:
																			if (2 >= b)
																			{
																				goto IL_040d;
																			}
																			goto IL_047b;
																			IL_040d:
																			if (2 > b)
																			{
																				goto IL_041b;
																			}
																			goto IL_04a4;
																			IL_041b:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0429;
																			IL_0429:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_054d;
																			IL_054d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0566;
																			IL_0566:
																			array[num5] = 0;
																			num = 104;
																			goto IL_057d;
																			IL_057d:
																			num5++;
																			goto IL_058b;
																			IL_058b:
																			ptr2 += 8;
																			goto end_IL_03c2;
																			IL_04a4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e4;
																			IL_04e4:
																			array[num5 - 2] = 0;
																			goto IL_04f8;
																			IL_04f8:
																			num5--;
																			goto end_IL_03c2;
																			IL_047b:
																			if (3 < b)
																			{
																				num = 19;
																				break;
																			}
																			goto IL_0486;
																			IL_0486:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_050b;
																			IL_050b:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0534;
																			IL_0534:
																			array[num5 - 1] = 5;
																			goto end_IL_03c2;
																			IL_06af:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_03c2;
																			IL_043c:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_045a;
																			IL_045a:
																			ptr2 += 8;
																			goto IL_0468;
																			IL_0468:
																			num5--;
																			goto end_IL_03c2;
																			IL_059e:
																			if (6 >= b)
																			{
																				goto IL_05a9;
																			}
																			goto IL_0627;
																			IL_05a9:
																			if (6 <= b)
																			{
																				goto IL_05b4;
																			}
																			goto IL_0606;
																			IL_05b4:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05f3;
																			IL_05f3:
																			num5 -= 3;
																			goto end_IL_03c2;
																			IL_0606:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0614;
																			IL_0614:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0732;
																			IL_0732:
																			array[num5] = 5;
																			goto IL_0740;
																			IL_0740:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0758;
																			IL_0758:
																			num5++;
																			num = 65;
																			goto IL_076f;
																			IL_076f:
																			ptr2 += 8;
																			goto end_IL_03c2;
																			IL_0627:
																			if (7 >= b)
																			{
																				goto IL_0632;
																			}
																			goto IL_068a;
																			IL_0632:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0640;
																			IL_0640:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0669;
																			IL_0669:
																			ptr2 += 8;
																			goto IL_0677;
																			IL_0677:
																			num5--;
																			goto end_IL_03c2;
																			IL_068a:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0698;
																		}
																		break;
																		IL_0392:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 44;
																goto end_IL_03c2;
																continue;
																end_IL_03a2:
																break;
															}
															continue;
															end_IL_03b2:
															break;
														}
														continue;
														end_IL_03c2:
														break;
													}
													continue;
												}
												goto IL_0a3a;
												IL_0a3a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_099e:
												break;
											}
											continue;
											end_IL_09b1:
											break;
										}
										continue;
										end_IL_09bb:
										break;
									}
									continue;
									end_IL_09c6:
									break;
								}
								continue;
								end_IL_09d6:
								break;
							}
							continue;
							end_IL_09e6:
							break;
						}
						continue;
						end_IL_09f6:
						break;
					}
					continue;
					end_IL_0a06:
					break;
				}
				continue;
				end_IL_0a16:
				break;
			}
		}
	}

	private static int TextElementEnumeratorHashValue()
	{
		return Screen.height;
	}

	private static bool smethod_8(IInputSystem iinputSystem_0, KeyCode keyCode_0)
	{
		return iinputSystem_0.GetKey(keyCode_0);
	}

	private static bool getPathsLoadAssemblyFromString()
	{
		return global::_003CModule_003E.OaEST_003CmJfB;
	}

	private static GorillaTagger smethod_9()
	{
		return GorillaTagger.Instance;
	}

	private static GorillaTagger getKeyAvailableCompatibilitySwitches()
	{
		return GorillaTagger.Instance;
	}

	private static Vector2Control getTotalHoursIsOutputRedirected(Pointer pointer_0)
	{
		return pointer_0.position;
	}

	private static object MoveNextRunnerToTicks(float float_8, float float_9, float float_10)
	{
		return new Vector3(float_8, float_9, float_10);
	}

	private static bool ICustomAdapterGetLogicalDrives(IInputSystem iinputSystem_0, KeyCode keyCode_0)
	{
		return iinputSystem_0.GetKey(keyCode_0);
	}

	private static float BooleanTypeInfogetIsStatic()
	{
		return global::_003CModule_003E.float_100;
	}

	private static ButtonControl RealErrorObjectPausing(Mouse mouse_0)
	{
		return mouse_0.rightButton;
	}

	private static int AccessViolationExceptionVerificationException()
	{
		return Screen.width;
	}

	private static Vector3 getCallingConventiongetAsR()
	{
		return Vector3.zero;
	}

	private static Transform GetDayOfMonthBrowserStop(Component component_0)
	{
		return component_0.transform;
	}

	private static void HasLocalValuesSZGenericArrayEnumerator(Transform transform_0, Vector3 vector3_1)
	{
		transform_0.position = vector3_1;
	}

	unsafe static Class141()
	{
		int num = 145;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 159;
					while (true)
					{
						int num2 = 1;
						num = 127;
						while (true)
						{
							int num3 = num2 * 4;
							while (true)
							{
								byte[] array = new byte[6];
								while (true)
								{
									object[] array2 = new object[6];
									while (true)
									{
										int[] array3 = new int[6];
										while (true)
										{
											long[] array4 = new long[6];
											while (true)
											{
												object[] array5 = new object[1];
												num = 118;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetRemoveOnMethodGetCachedSoapAttribute.dictionaryEnumApplicationPrivateFiles);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		num = 90;
																		while (true)
																		{
																			IL_038d:
																			if (b >= 1)
																			{
																				while (b <= 20)
																				{
																					while (true)
																					{
																						IL_036d:
																						if (10 < b)
																						{
																							while (true)
																							{
																								IL_035a:
																								if (15 >= b)
																								{
																									num = 180;
																									while (true)
																									{
																										IL_034a:
																										if (15 > b)
																										{
																											while (true)
																											{
																												IL_033d:
																												if (12 < b)
																												{
																													while (true)
																													{
																														IL_032a:
																														if (13 >= b)
																														{
																															num = 187;
																															while (true)
																															{
																																if (num != 187)
																																{
																																	if (num != 1168)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 87:
																																		goto IL_032a;
																																	case 9:
																																		goto IL_033d;
																																	case 180:
																																		goto IL_034a;
																																	case 173:
																																		goto IL_035a;
																																	case 169:
																																		goto IL_036d;
																																	case 170:
																																		goto IL_037d;
																																	case 90:
																																		goto IL_038d;
																																	case 108:
																																		goto end_IL_038d;
																																	case 28:
																																	case 92:
																																		goto end_IL_039d;
																																	case 48:
																																		goto IL_03c1;
																																	case 55:
																																		goto IL_03cf;
																																	case 5:
																																		goto IL_03e6;
																																	case 80:
																																		goto IL_03f9;
																																	case 99:
																																		goto IL_0407;
																																	case 19:
																																	case 50:
																																		goto IL_0412;
																																	case 56:
																																		goto IL_0431;
																																	case 10:
																																		goto IL_043f;
																																	case 103:
																																		goto IL_0458;
																																	case 57:
																																	case 106:
																																		goto IL_046b;
																																	case 11:
																																	case 116:
																																		goto IL_0484;
																																	case 105:
																																		goto IL_04be;
																																	case 119:
																																		goto IL_04d1;
																																	case 3:
																																	case 60:
																																		goto IL_04df;
																																	case 130:
																																		goto IL_04fd;
																																	case 41:
																																		goto IL_0508;
																																	case 129:
																																		goto IL_051b;
																																	case 78:
																																		goto IL_0532;
																																	case 30:
																																	case 112:
																																		goto IL_0540;
																																	case 132:
																																		goto IL_055c;
																																	case 131:
																																		goto IL_0594;
																																	case 142:
																																		goto IL_05a7;
																																	case 17:
																																	case 47:
																																		goto IL_05b5;
																																	case 86:
																																		goto IL_05c3;
																																	case 37:
																																		goto IL_05e6;
																																	case 71:
																																		goto IL_05f4;
																																	case 149:
																																		goto IL_0610;
																																	case 150:
																																		goto IL_0623;
																																	case 54:
																																	case 76:
																																		goto IL_0631;
																																	case 26:
																																		goto IL_064b;
																																	case 152:
																																		goto IL_065e;
																																	case 156:
																																	case 157:
																																		goto IL_0671;
																																	case 125:
																																		goto IL_068b;
																																	case 158:
																																		goto IL_069e;
																																	case 29:
																																	case 53:
																																		goto IL_06a9;
																																	case 100:
																																		goto IL_06e9;
																																	case 6:
																																		goto IL_06fd;
																																	case 32:
																																		goto IL_0710;
																																	case 66:
																																		goto IL_071b;
																																	case 74:
																																	case 85:
																																		goto IL_0729;
																																	case 52:
																																		goto IL_0742;
																																	case 25:
																																		goto IL_0750;
																																	case 12:
																																		goto IL_075e;
																																	case 107:
																																		goto IL_0771;
																																	case 148:
																																		goto IL_077c;
																																	case 162:
																																		goto IL_078c;
																																	case 14:
																																		goto IL_079a;
																																	case 165:
																																		goto IL_07ad;
																																	case 166:
																																		goto IL_07c0;
																																	case 45:
																																		goto IL_07cb;
																																	case 101:
																																		goto IL_07d9;
																																	case 67:
																																	case 133:
																																		goto IL_07e7;
																																	case 38:
																																		goto IL_0803;
																																	case 24:
																																	case 79:
																																		goto IL_0811;
																																	case 97:
																																		goto IL_082f;
																																	case 135:
																																		goto IL_083d;
																																	case 110:
																																	case 167:
																																		goto IL_0850;
																																	case 114:
																																		goto IL_0873;
																																	case 172:
																																		goto IL_0886;
																																	case 153:
																																		goto IL_0891;
																																	case 146:
																																	case 168:
																																		goto IL_089c;
																																	case 83:
																																		goto IL_08b6;
																																	case 104:
																																		goto IL_08c4;
																																	case 113:
																																		goto IL_08d7;
																																	case 137:
																																		goto IL_08e2;
																																	case 31:
																																	case 65:
																																		goto IL_08f0;
																																	case 61:
																																		goto IL_0905;
																																	case 0:
																																		goto IL_0918;
																																	case 72:
																																		goto IL_0926;
																																	case 77:
																																	case 89:
																																		goto IL_093d;
																																	case 64:
																																		goto IL_094b;
																																	case 49:
																																		goto IL_095e;
																																	case 121:
																																		goto IL_096c;
																																	case 175:
																																		goto IL_097f;
																																	case 1:
																																		goto IL_0997;
																																	case 27:
																																		goto IL_09a5;
																																	case 91:
																																	case 176:
																																		goto IL_09b8;
																																	case 2:
																																		goto IL_09d0;
																																	case 22:
																																		goto IL_09ee;
																																	case 96:
																																		goto IL_0a12;
																																	case 164:
																																		goto IL_0a2a;
																																	case 177:
																																		goto IL_0a3d;
																																	case 7:
																																	case 59:
																																		goto IL_0a4b;
																																	case 160:
																																		goto IL_0a74;
																																	case 178:
																																		goto IL_0a8d;
																																	case 20:
																																	case 111:
																																		goto IL_0aab;
																																	case 155:
																																		goto IL_0b06;
																																	case 4:
																																	case 42:
																																	case 43:
																																	case 44:
																																	case 46:
																																	case 51:
																																	case 58:
																																	case 62:
																																	case 63:
																																	case 69:
																																	case 73:
																																	case 84:
																																	case 102:
																																	case 115:
																																	case 120:
																																	case 122:
																																	case 123:
																																	case 138:
																																	case 139:
																																	case 141:
																																	case 147:
																																	case 163:
																																	case 174:
																																		goto end_IL_0317;
																																	case 151:
																																		goto IL_0b2b;
																																	case 13:
																																	case 15:
																																	case 16:
																																	case 18:
																																	case 23:
																																	case 33:
																																	case 34:
																																	case 40:
																																	case 70:
																																	case 75:
																																	case 81:
																																	case 88:
																																	case 94:
																																	case 98:
																																	case 117:
																																	case 124:
																																	case 126:
																																	case 128:
																																	case 140:
																																	case 154:
																																	case 171:
																																	case 179:
																																		goto end_IL_03b6;
																																	case 36:
																																		goto end_IL_0b39;
																																	case 118:
																																		goto end_IL_0b4c;
																																	case 93:
																																		goto end_IL_0b56;
																																	case 8:
																																		goto end_IL_0b61;
																																	case 109:
																																		goto end_IL_0b7a;
																																	case 21:
																																		goto end_IL_0b8a;
																																	case 39:
																																	case 161:
																																		goto end_IL_0b9a;
																																	case 127:
																																		goto end_IL_0baa;
																																	case 159:
																																		goto end_IL_0bba;
																																	case 35:
																																	case 68:
																																	case 95:
																																	case 136:
																																	case 143:
																																		goto end_IL_0bca;
																																	case 144:
																																		goto end_IL_0bde;
																																	case 145:
																																		goto end_IL_0bf6;
																																	case 82:
																																	case 134:
																																		return;
																																	}
																																	continue;
																																}
																																if (13 > b)
																																{
																																	break;
																																}
																																goto IL_0aab;
																																IL_0aab:
																																((delegate*<object, IntPtr, object[], ref string>)RectgetInitializationFlags[array3[num5 - 2]])(array2[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])), array5) = (string)array2[num5 - 1];
																																goto IL_0b06;
																																IL_0b06:
																																num5 -= 2;
																																goto end_IL_03b6;
																																continue;
																																end_IL_0317:
																																break;
																															}
																															break;
																														}
																														goto IL_0458;
																														IL_078c:
																														num5++;
																														goto IL_079a;
																														IL_079a:
																														ptr2 += 8;
																														goto end_IL_03b6;
																														IL_0458:
																														if (14 < b)
																														{
																															break;
																														}
																														goto IL_0623;
																														IL_0623:
																														if (14 > b)
																														{
																															break;
																														}
																														goto IL_0631;
																														IL_0631:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																														goto IL_064b;
																														IL_064b:
																														array[num5] = 3;
																														goto IL_078c;
																													}
																													break;
																												}
																												goto IL_03c1;
																												IL_055c:
																												array2[num5 - 1] = ((delegate*<char[], string>)RectgetInitializationFlags[*(int*)(ptr2 + num3)])((char[])array2[num5 - 1]);
																												goto IL_0594;
																												IL_03c1:
																												if (12 > b)
																												{
																													goto IL_03cf;
																												}
																												goto IL_046b;
																												IL_03cf:
																												if (11 < b)
																												{
																													break;
																												}
																												num = 5;
																												goto IL_03e6;
																												IL_0594:
																												ptr2 += 8;
																												goto end_IL_03b6;
																												IL_03e6:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_0484;
																												IL_0484:
																												((short[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = (short)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																												goto IL_04be;
																												IL_04be:
																												num5 -= 3;
																												goto end_IL_03b6;
																												IL_046b:
																												array[num5 - 1] = 5;
																												goto IL_055c;
																											}
																											break;
																										}
																										goto IL_0850;
																										IL_0873:
																										num5--;
																										goto end_IL_03b6;
																										IL_0850:
																										float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										num = 114;
																										goto IL_0873;
																									}
																									break;
																								}
																								goto IL_03f9;
																								IL_051b:
																								if (20 < b)
																								{
																									break;
																								}
																								num = 78;
																								goto IL_0532;
																								IL_0540:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_03b6;
																								IL_03f9:
																								if (18 >= b)
																								{
																									goto IL_0407;
																								}
																								goto IL_04fd;
																								IL_0407:
																								if (18 <= b)
																								{
																									goto IL_0412;
																								}
																								goto IL_0431;
																								IL_0412:
																								float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_065e;
																								IL_065e:
																								num5--;
																								goto end_IL_03b6;
																								IL_0431:
																								if (16 < b)
																								{
																									goto IL_043f;
																								}
																								goto IL_05a7;
																								IL_043f:
																								if (17 < b)
																								{
																									break;
																								}
																								num = 119;
																								goto IL_04d1;
																								IL_0532:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_0540;
																								IL_04d1:
																								if (17 > b)
																								{
																									break;
																								}
																								goto IL_04df;
																								IL_04df:
																								vector3_0 = (Vector3)array2[num5 - 1];
																								goto IL_0610;
																								IL_0610:
																								num5--;
																								goto end_IL_03b6;
																								IL_05a7:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_05b5;
																								IL_05b5:
																								array[num5] = 4;
																								goto IL_05c3;
																								IL_05c3:
																								array2[num5] = ((delegate*<Vector3>)RectgetInitializationFlags[*(int*)(ptr2 + num3)])();
																								goto IL_05e6;
																								IL_05e6:
																								num5++;
																								goto IL_05f4;
																								IL_05f4:
																								ptr2 += 8;
																								num = 117;
																								goto end_IL_03b6;
																								IL_04fd:
																								if (19 >= b)
																								{
																									goto IL_0508;
																								}
																								goto IL_051b;
																								IL_0508:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_0671;
																								IL_0671:
																								float_2 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_068b;
																								IL_068b:
																								num5--;
																								goto end_IL_03b6;
																							}
																							break;
																						}
																						goto IL_069e;
																						IL_0811:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_082f;
																						IL_069e:
																						if (10 <= b)
																						{
																							goto IL_06a9;
																						}
																						goto IL_0710;
																						IL_06a9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_06e9;
																						IL_06e9:
																						array[num5 - 2] = 0;
																						goto IL_06fd;
																						IL_06fd:
																						num5--;
																						goto end_IL_03b6;
																						IL_0710:
																						if (5 >= b)
																						{
																							goto IL_071b;
																						}
																						goto IL_0771;
																						IL_071b:
																						if (5 <= b)
																						{
																							goto IL_0729;
																						}
																						goto IL_0886;
																						IL_0729:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0742;
																						IL_0742:
																						array[num5] = 0;
																						goto IL_0750;
																						IL_0750:
																						num5++;
																						goto IL_075e;
																						IL_075e:
																						ptr2 += 8;
																						goto end_IL_03b6;
																						IL_0886:
																						if (2 >= b)
																						{
																							goto IL_0891;
																						}
																						goto IL_08d7;
																						IL_0891:
																						if (2 <= b)
																						{
																							goto IL_089c;
																						}
																						goto IL_08b6;
																						IL_089c:
																						((delegate*<void>)RectgetInitializationFlags[*(int*)(ptr2 + num3)])();
																						goto IL_0a8d;
																						IL_0a8d:
																						ptr2 += 8;
																						goto end_IL_03b6;
																						IL_08b6:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_08c4;
																						IL_08c4:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_08d7:
																						if (3 >= b)
																						{
																							goto IL_08e2;
																						}
																						goto IL_0918;
																						IL_08e2:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_08f0;
																						IL_08f0:
																						((delegate*<void>)RectgetInitializationFlags[*(int*)(ptr2 + num3)])();
																						goto IL_0905;
																						IL_0905:
																						ptr2 += 8;
																						goto end_IL_03b6;
																						IL_0918:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0926;
																						IL_0926:
																						if (4 > b)
																						{
																							break;
																						}
																						num = 89;
																						goto IL_093d;
																						IL_082f:
																						ptr2 += 8;
																						goto IL_083d;
																						IL_093d:
																						array[num5] = 15;
																						goto IL_094b;
																						IL_094b:
																						array3[num5] = *(int*)(ptr2 + num3);
																						goto IL_095e;
																						IL_095e:
																						ptr2 += 8;
																						goto IL_096c;
																						IL_096c:
																						num5++;
																						goto end_IL_03b6;
																						IL_0771:
																						if (7 >= b)
																						{
																							goto IL_077c;
																						}
																						goto IL_07c0;
																						IL_077c:
																						if (7 > b)
																						{
																							goto IL_07ad;
																						}
																						goto IL_09b8;
																						IL_07ad:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0a3d;
																						IL_0a3d:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0a4b;
																						IL_0a4b:
																						array2[num5 - 1] = new char[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0a74;
																						IL_0a74:
																						array[num5 - 1] = 5;
																						goto end_IL_03b6;
																						IL_09b8:
																						array[num5] = array[num5 - 1];
																						goto IL_09d0;
																						IL_09d0:
																						array3[num5 - 0] = array3[num5 - 1];
																						goto IL_09ee;
																						IL_09ee:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0a12;
																						IL_0a12:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0a2a;
																						IL_0a2a:
																						num5++;
																						goto end_IL_03b6;
																						IL_07c0:
																						if (8 < b)
																						{
																							goto IL_07cb;
																						}
																						num = 38;
																						goto IL_0803;
																						IL_07cb:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_07d9;
																						IL_07d9:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_07e7;
																						IL_07e7:
																						array[num5] = 5;
																						goto IL_097f;
																						IL_097f:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0997;
																						IL_0997:
																						num5++;
																						goto IL_09a5;
																						IL_09a5:
																						ptr2 += 8;
																						goto end_IL_03b6;
																						IL_083d:
																						num5--;
																						goto end_IL_03b6;
																						IL_0803:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0811;
																					}
																					break;
																					IL_037d:;
																				}
																			}
																			((delegate*<void>)RectgetInitializationFlags[*(int*)(ptr2 + num3)])();
																			goto IL_0b2b;
																			IL_0b2b:
																			ptr2 += 8;
																			goto end_IL_03b6;
																			continue;
																			end_IL_038d:
																			break;
																		}
																		continue;
																		end_IL_039d:
																		break;
																	}
																	continue;
																	end_IL_03b6:
																	break;
																}
																continue;
															}
															num = 134;
															return;
															continue;
															end_IL_0b39:
															break;
														}
														continue;
														end_IL_0b4c:
														break;
													}
													continue;
													end_IL_0b56:
													break;
												}
												continue;
												end_IL_0b61:
												break;
											}
											continue;
											end_IL_0b7a:
											break;
										}
										continue;
										end_IL_0b8a:
										break;
									}
									continue;
									end_IL_0b9a:
									break;
								}
								continue;
								end_IL_0baa:
								break;
							}
							continue;
							end_IL_0bba:
							break;
						}
						continue;
						end_IL_0bca:
						break;
					}
					continue;
					end_IL_0bde:
					break;
				}
				continue;
				end_IL_0bf6:
				break;
			}
		}
	}

	private static int XdrStringdwReserved(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static GorillaTagger getDeclaredMethodsdefaultPermissionSetID()
	{
		return GorillaTagger.Instance;
	}

	private static bool asyncResultFromDays()
	{
		return global::_003CModule_003E.bool_37;
	}

	private static float IsSubsetOfEmptyHandle()
	{
		return global::_003CModule_003E.float_98;
	}

	private static double setCalendarTypeSetWinContextInIDispatchAttribute(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private unsafe static int smethod_10(int int_2)
	{
		int num = 75;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 33;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref COMServerTypeLibraryToday.DefinitionLinkDemand);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0679:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 124;
												while (true)
												{
													if (num != 124)
													{
														if (num != 1105)
														{
															break;
														}
														switch (num)
														{
														case 26:
														case 51:
															break;
														case 73:
															goto IL_0017;
														case 66:
															goto IL_002e;
														case 88:
															goto IL_003c;
														case 54:
															goto IL_004a;
														case 94:
															goto IL_0058;
														case 5:
														case 50:
															goto IL_0066;
														case 113:
															goto IL_0074;
														case 41:
														case 103:
															goto IL_0082;
														case 21:
															goto IL_008d;
														case 95:
														case 100:
															goto IL_009b;
														case 57:
															goto IL_00b4;
														case 24:
															goto end_IL_0666;
														case 48:
															goto IL_00d0;
														case 13:
														case 77:
															goto IL_00e3;
														case 76:
															goto IL_00f1;
														case 9:
														case 19:
															goto IL_00ff;
														case 61:
															goto IL_0128;
														case 82:
															goto IL_0136;
														case 3:
														case 65:
															goto IL_0149;
														case 56:
														case 104:
															goto IL_0161;
														case 20:
														case 34:
															goto IL_016c;
														case 46:
															goto IL_017a;
														case 22:
														case 89:
															goto IL_0188;
														case 17:
															goto IL_0196;
														case 44:
															goto IL_01b9;
														case 64:
															goto IL_01c3;
														case 107:
															goto IL_01d1;
														case 2:
															goto IL_01e4;
														case 30:
														case 43:
															goto IL_01f7;
														case 71:
															goto IL_0237;
														case 108:
															goto IL_024b;
														case 12:
															goto IL_025e;
														case 4:
															goto IL_026c;
														case 60:
														case 69:
															goto IL_027a;
														case 25:
															goto IL_0285;
														case 62:
														case 101:
															goto IL_0293;
														case 98:
															goto IL_02d3;
														case 10:
															goto IL_02f0;
														case 72:
															goto IL_0303;
														case 55:
															goto IL_0311;
														case 87:
														case 91:
															goto IL_032a;
														case 68:
															goto IL_034d;
														case 86:
															goto IL_035b;
														case 111:
															goto IL_0372;
														case 1:
														case 58:
															goto IL_0385;
														case 96:
															goto IL_03e7;
														case 40:
														case 52:
															goto IL_03fa;
														case 67:
														case 78:
															goto IL_0405;
														case 8:
															goto IL_0410;
														case 81:
															goto IL_0428;
														case 16:
														case 92:
															goto IL_0433;
														case 6:
														case 7:
														case 14:
														case 15:
														case 18:
														case 29:
														case 31:
														case 32:
														case 35:
														case 36:
														case 42:
														case 49:
														case 59:
														case 80:
														case 83:
														case 84:
														case 90:
														case 93:
														case 97:
														case 102:
														case 112:
														case 117:
															goto IL_044f;
														default:
															continue;
														case 0:
														case 11:
														case 23:
														case 27:
														case 28:
														case 38:
														case 39:
														case 63:
														case 105:
														case 106:
														case 109:
														case 110:
														case 114:
														case 115:
															goto IL_0679;
														case 37:
															goto end_IL_0679;
														case 70:
															goto end_IL_068c;
														case 47:
															goto end_IL_0696;
														case 33:
															goto end_IL_06a1;
														case 79:
														case 116:
															goto end_IL_06b6;
														case 53:
															goto end_IL_06c6;
														case 85:
														case 99:
															goto end_IL_06df;
														case 74:
															goto end_IL_06ef;
														case 75:
															goto end_IL_06ff;
														case 45:
															goto IL_071a;
														}
														goto IL_000e;
													}
													goto IL_071a;
													IL_071a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0666:
													break;
												}
												goto IL_00c2;
												IL_044f:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_0428:
												if (10 <= b)
												{
													goto IL_0433;
												}
												goto IL_044f;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												num = 66;
												goto IL_002e;
												IL_002e:
												if (b >= 1)
												{
													goto IL_003c;
												}
												goto IL_044f;
												IL_003c:
												if (b <= 11)
												{
													goto IL_004a;
												}
												goto IL_044f;
												IL_004a:
												if (6 >= b)
												{
													goto IL_0058;
												}
												goto IL_025e;
												IL_0058:
												if (6 > b)
												{
													goto IL_0066;
												}
												goto IL_01f7;
												IL_0066:
												if (3 >= b)
												{
													goto IL_0074;
												}
												goto IL_0161;
												IL_0074:
												if (3 > b)
												{
													goto IL_0082;
												}
												goto IL_0149;
												IL_0082:
												if (1 >= b)
												{
													goto IL_008d;
												}
												goto IL_00e3;
												IL_008d:
												if (1 <= b)
												{
													goto IL_009b;
												}
												goto IL_044f;
												IL_009b:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_00b4;
												IL_00b4:
												array[num5] = 0;
												goto IL_00c2;
												IL_00c2:
												num5++;
												goto IL_00d0;
												IL_00d0:
												ptr2 += 8;
												continue;
												IL_00e3:
												if (2 >= b)
												{
													goto IL_00f1;
												}
												goto IL_044f;
												IL_00f1:
												if (2 <= b)
												{
													goto IL_00ff;
												}
												goto IL_044f;
												IL_00ff:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0128;
												IL_0128:
												ptr2 += 8;
												goto IL_0136;
												IL_0136:
												num5--;
												continue;
												IL_0149:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_0161:
												if (4 < b)
												{
													goto IL_016c;
												}
												goto IL_01e4;
												IL_016c:
												if (5 >= b)
												{
													goto IL_017a;
												}
												goto IL_044f;
												IL_017a:
												if (5 <= b)
												{
													goto IL_0188;
												}
												goto IL_044f;
												IL_0188:
												array[num5] = 0;
												goto IL_0196;
												IL_0196:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_01b9;
												IL_01b9:
												array2[num5] = null;
												goto IL_01c3;
												IL_01c3:
												num5++;
												goto IL_01d1;
												IL_01d1:
												ptr2 += 8;
												continue;
												IL_01e4:
												if (4 <= b)
												{
													continue;
												}
												goto IL_044f;
												IL_01f7:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0237;
												IL_0237:
												array[num5 - 2] = 0;
												goto IL_024b;
												IL_024b:
												num5--;
												continue;
												IL_025e:
												if (9 >= b)
												{
													goto IL_026c;
												}
												goto IL_03fa;
												IL_026c:
												if (9 > b)
												{
													goto IL_027a;
												}
												goto IL_0385;
												IL_027a:
												if (7 >= b)
												{
													goto IL_0285;
												}
												goto IL_0303;
												IL_0285:
												if (7 <= b)
												{
													goto IL_0293;
												}
												goto IL_044f;
												IL_0293:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_02d3;
												IL_02d3:
												array[num5 - 2] = 0;
												num = 10;
												goto IL_02f0;
												IL_02f0:
												num5--;
												continue;
												IL_0303:
												if (8 >= b)
												{
													goto IL_0311;
												}
												goto IL_044f;
												IL_0311:
												if (8 <= b)
												{
													goto IL_032a;
												}
												num = 29;
												goto IL_044f;
												IL_0433:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_032a:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_034d;
												IL_034d:
												array[num5] = 0;
												goto IL_035b;
												IL_035b:
												num5++;
												num = 111;
												goto IL_0372;
												IL_0372:
												ptr2 += 8;
												continue;
												IL_0385:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_03e7;
												IL_03e7:
												num5 -= 2;
												continue;
												IL_03fa:
												if (10 < b)
												{
													goto IL_0405;
												}
												goto IL_0428;
												IL_0405:
												if (11 >= b)
												{
													goto IL_0410;
												}
												num = 112;
												goto IL_044f;
												IL_0410:
												if (11 <= b)
												{
												}
												goto IL_044f;
												continue;
												end_IL_0679:
												break;
											}
											continue;
											end_IL_068c:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06a1:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06df:
						break;
					}
					continue;
					end_IL_06ef:
					break;
				}
				continue;
				end_IL_06ff:
				break;
			}
		}
	}

	private static Vector3 UnboxIsVirtual(Transform transform_0)
	{
		return transform_0.position;
	}

	private static IInputSystem SuppressMessageAttributeCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGVISIBLE()
	{
		return UnityInput.Current;
	}

	private static Transform getIsStaticMutexTryCodeHelper(Component component_0)
	{
		return component_0.transform;
	}

	private unsafe static int smethod_11(int int_2)
	{
		int num = 112;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setKeyPasswordsetHelpLink.CreateSHAgetUseLegacyPathHandling);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02de:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02be:
																			if (7 < b)
																			{
																				goto IL_0556;
																			}
																			while (true)
																			{
																				IL_02ae:
																				if (7 > b)
																				{
																					while (true)
																					{
																						IL_02a1:
																						if (3 < b)
																						{
																							while (true)
																							{
																								IL_0294:
																								if (5 >= b)
																								{
																									while (true)
																									{
																										IL_0284:
																										if (5 <= b)
																										{
																											while (true)
																											{
																												IL_0274:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_0246:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 137;
																													while (true)
																													{
																														if (num != 137)
																														{
																															if (num != 1118)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 96:
																																goto IL_0246;
																															case 5:
																															case 64:
																																goto IL_0274;
																															case 32:
																																goto IL_0284;
																															case 33:
																																goto IL_0294;
																															case 51:
																															case 108:
																																goto IL_02a1;
																															case 80:
																																goto IL_02ae;
																															case 23:
																																goto IL_02be;
																															case 20:
																																goto end_IL_02be;
																															case 61:
																																goto IL_02de;
																															case 79:
																																goto end_IL_02de;
																															case 78:
																															case 101:
																																goto end_IL_02ee;
																															case 11:
																																goto IL_0309;
																															case 48:
																															case 49:
																																goto IL_0319;
																															case 65:
																																goto IL_0329;
																															case 17:
																															case 47:
																																goto IL_0334;
																															case 24:
																																goto IL_0342;
																															case 57:
																																goto IL_0355;
																															case 77:
																																goto IL_036e;
																															case 44:
																															case 81:
																																goto IL_037e;
																															case 60:
																																goto IL_0397;
																															case 15:
																																goto IL_03a5;
																															case 82:
																																goto IL_03b3;
																															case 28:
																															case 84:
																																goto IL_03c6;
																															case 70:
																																goto IL_0406;
																															case 6:
																															case 86:
																																goto IL_0425;
																															case 58:
																																goto IL_044e;
																															case 41:
																																goto IL_0465;
																															case 95:
																																goto IL_0478;
																															case 63:
																															case 104:
																																goto IL_048b;
																															case 46:
																																goto IL_04ad;
																															case 126:
																																goto IL_04bb;
																															case 68:
																																goto IL_04ce;
																															case 103:
																																goto IL_04dc;
																															case 22:
																															case 122:
																																goto IL_04ef;
																															case 102:
																																goto IL_052f;
																															case 123:
																																goto IL_0543;
																															case 91:
																																goto IL_0556;
																															case 99:
																																goto end_IL_0233;
																															case 94:
																															case 121:
																																goto IL_056f;
																															case 16:
																																goto IL_057d;
																															case 59:
																																goto IL_05a1;
																															case 13:
																																goto IL_05af;
																															case 35:
																																goto IL_05c2;
																															case 2:
																															case 114:
																																goto IL_05d0;
																															case 127:
																																goto IL_05de;
																															case 110:
																															case 113:
																																goto IL_05ec;
																															case 56:
																																goto IL_064e;
																															case 83:
																																goto IL_0661;
																															case 76:
																															case 129:
																																goto IL_066f;
																															case 87:
																																goto IL_0692;
																															case 50:
																																goto IL_06a0;
																															case 119:
																																goto IL_06ae;
																															case 52:
																															case 105:
																																goto IL_06c1;
																															case 1:
																															case 73:
																																goto IL_06cc;
																															case 55:
																																goto IL_06d7;
																															case 92:
																																goto IL_06e4;
																															case 8:
																															case 98:
																																goto IL_06ef;
																															case 9:
																																goto IL_06fa;
																															case 54:
																															case 90:
																																goto IL_0705;
																															case 36:
																															case 71:
																																goto IL_0715;
																															case 12:
																															case 18:
																															case 19:
																															case 25:
																															case 26:
																															case 29:
																															case 30:
																															case 37:
																															case 40:
																															case 43:
																															case 66:
																															case 69:
																															case 72:
																															case 75:
																															case 89:
																															case 93:
																															case 109:
																															case 116:
																															case 117:
																															case 118:
																															case 120:
																															case 125:
																															case 128:
																																goto end_IL_02ce;
																															case 3:
																															case 4:
																															case 10:
																															case 14:
																															case 27:
																															case 31:
																															case 34:
																															case 39:
																															case 42:
																															case 74:
																															case 97:
																															case 100:
																															case 106:
																															case 115:
																															case 124:
																															case 130:
																																goto end_IL_02fe;
																															case 7:
																																goto end_IL_0741;
																															case 21:
																																goto end_IL_0754;
																															case 53:
																																goto end_IL_075e;
																															case 45:
																																goto end_IL_0769;
																															case 38:
																															case 62:
																																goto end_IL_077e;
																															case 85:
																																goto end_IL_078e;
																															case 0:
																															case 67:
																																goto end_IL_079e;
																															case 111:
																																goto end_IL_07ae;
																															case 112:
																																goto end_IL_07be;
																															case 88:
																															case 107:
																																goto IL_07d9;
																															}
																															continue;
																														}
																														array2[num5] = null;
																														goto IL_04ad;
																														IL_04ad:
																														num5++;
																														goto IL_04bb;
																														IL_04bb:
																														ptr2 += 8;
																														goto end_IL_02fe;
																														continue;
																														end_IL_0233:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_04ce;
																										IL_04dc:
																										if (4 > b)
																										{
																											goto end_IL_02ce;
																										}
																										goto end_IL_02fe;
																										IL_04ce:
																										if (4 < b)
																										{
																											goto end_IL_02ce;
																										}
																										goto IL_04dc;
																									}
																									break;
																								}
																								goto IL_0319;
																								IL_0478:
																								num5--;
																								goto end_IL_02fe;
																								IL_0319:
																								if (6 < b)
																								{
																									goto end_IL_02ce;
																								}
																								goto IL_036e;
																								IL_036e:
																								if (6 > b)
																								{
																									goto end_IL_02ce;
																								}
																								goto IL_03c6;
																								IL_03c6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0406;
																								IL_0406:
																								array[num5 - 2] = 0;
																								num = 95;
																								goto IL_0478;
																							}
																							break;
																						}
																						goto IL_0309;
																						IL_03a5:
																						num5++;
																						goto IL_03b3;
																						IL_0309:
																						if (3 > b)
																						{
																							goto IL_0329;
																						}
																						goto IL_048b;
																						IL_048b:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02fe;
																						IL_0329:
																						if (1 < b)
																						{
																							goto IL_0334;
																						}
																						goto IL_0355;
																						IL_0334:
																						if (2 < b)
																						{
																							goto end_IL_02ce;
																						}
																						goto IL_0342;
																						IL_0342:
																						if (2 > b)
																						{
																							goto end_IL_02ce;
																						}
																						goto IL_0425;
																						IL_0425:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_044e;
																						IL_044e:
																						ptr2 += 8;
																						num = 41;
																						goto IL_0465;
																						IL_0465:
																						num5--;
																						goto end_IL_02fe;
																						IL_0355:
																						if (1 > b)
																						{
																							num = 26;
																							goto end_IL_02ce;
																						}
																						goto IL_037e;
																						IL_03b3:
																						ptr2 += 8;
																						goto end_IL_02fe;
																						IL_037e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0397;
																						IL_0397:
																						array[num5] = 0;
																						goto IL_03a5;
																					}
																					break;
																				}
																				goto IL_04ef;
																				IL_0543:
																				num5--;
																				goto end_IL_02fe;
																				IL_04ef:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_052f;
																				IL_052f:
																				array[num5 - 2] = 0;
																				goto IL_0543;
																			}
																			goto IL_0564;
																			IL_0715:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02fe;
																			IL_0556:
																			if (10 >= b)
																			{
																				goto IL_0564;
																			}
																			goto IL_06c1;
																			IL_0564:
																			if (10 <= b)
																			{
																				goto IL_056f;
																			}
																			goto IL_05c2;
																			IL_056f:
																			array[num5] = 0;
																			goto IL_057d;
																			IL_057d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)OpenNamespaceArray[*(int*)(ptr2 + num3)])();
																			goto IL_05a1;
																			IL_05a1:
																			num5++;
																			goto IL_05af;
																			IL_05af:
																			ptr2 += 8;
																			goto end_IL_02fe;
																			IL_05c2:
																			if (8 < b)
																			{
																				goto IL_05d0;
																			}
																			goto IL_0661;
																			IL_05d0:
																			if (9 < b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_05de;
																			IL_05de:
																			if (9 > b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_05ec;
																			IL_05ec:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_064e;
																			IL_064e:
																			num5 -= 2;
																			goto end_IL_02fe;
																			IL_0661:
																			if (8 > b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_066f;
																			IL_066f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0692;
																			IL_0692:
																			array[num5] = 0;
																			goto IL_06a0;
																			IL_06a0:
																			num5++;
																			goto IL_06ae;
																			IL_06ae:
																			ptr2 += 8;
																			goto end_IL_02fe;
																			IL_06c1:
																			if (12 < b)
																			{
																				goto IL_06cc;
																			}
																			goto IL_06e4;
																			IL_06cc:
																			if (13 < b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_06d7;
																			IL_06d7:
																			if (13 > b)
																			{
																			}
																			goto end_IL_02ce;
																			IL_06e4:
																			if (12 > b)
																			{
																				goto IL_06ef;
																			}
																			goto IL_0715;
																			IL_06ef:
																			if (11 < b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_06fa;
																			IL_06fa:
																			if (11 > b)
																			{
																				goto end_IL_02ce;
																			}
																			goto IL_0705;
																			IL_0705:
																			num5--;
																			goto end_IL_02fe;
																			continue;
																			end_IL_02be:
																			break;
																		}
																		continue;
																		end_IL_02ce:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02fe;
																continue;
																end_IL_02de:
																break;
															}
															continue;
															end_IL_02ee:
															break;
														}
														continue;
														end_IL_02fe:
														break;
													}
													continue;
												}
												goto IL_07d9;
												IL_07d9:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0741:
												break;
											}
											continue;
											end_IL_0754:
											break;
										}
										continue;
										end_IL_075e:
										break;
									}
									continue;
									end_IL_0769:
									break;
								}
								continue;
								end_IL_077e:
								break;
							}
							continue;
							end_IL_078e:
							break;
						}
						continue;
						end_IL_079e:
						break;
					}
					continue;
					end_IL_07ae:
					break;
				}
				continue;
				end_IL_07be:
				break;
			}
		}
	}

	private static int UserPolicyLevelgetPath()
	{
		return Screen.height;
	}

	private static IInputSystem GetLongLengthgetFallback()
	{
		return UnityInput.Current;
	}

	private static float ExponentClientContextTerminatorSink()
	{
		return float_3;
	}

	private static float GetFramesRightAltPressed(Vector3 vector3_1)
	{
		return vector3_1.y;
	}

	private static bool RangeCausalitySource()
	{
		return global::_003CModule_003E.bool_36;
	}

	private static float getLogicalCallContextForceLibrarySemantics()
	{
		return Time.deltaTime;
	}

	private static Vector3 TasksSetActivityIdsConsole(Transform transform_0)
	{
		return transform_0.position;
	}

	private static Vector3 Homemvalue()
	{
		return vector3_0;
	}

	private static Mouse GetPublicKeyKeyStore()
	{
		return Mouse.current;
	}

	private static SphereCollider objSequence(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.headCollider;
	}

	private static VRMap AssemblySuppliedAsyncVoidMethodBuilder(VRRig vrrig_0)
	{
		return vrrig_0.head;
	}

	private static Rigidbody DllLoaderMaximum(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rigidbody;
	}

	private static float FUNCSTATICSetAccessControl()
	{
		return float_1;
	}

	private static double setObjectAceTypeBaseFormattingOptions(double double_1)
	{
		return Math.Log(double_1);
	}

	private static float PushrReleaseAssemblyPath(ref Vector2 vector2_0)
	{
		return vector2_0.x;
	}

	private static bool DesignerNamespaceResolveEventArgsLeftAltPressed()
	{
		return global::_003CModule_003E.bool_38;
	}

	private static Vector3 CanBeOrphanInvalidOperationRegRemoveSubKey(Vector3 vector3_1, float float_8)
	{
		return vector3_1 * float_8;
	}

	private static int DeploymentMetadataEntrySizedReference()
	{
		return Screen.width;
	}

	private static Quaternion BadSignaturePermitOnlySetInstance(float float_8, float float_9, float float_10)
	{
		return Quaternion.Euler(float_8, float_9, float_10);
	}

	private static Transform getAsBoolCharSetNotSpec(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.rightHandTransform;
	}

	private static Transform ISectionEntryNoContext(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 ReflectionMemberAccessHResult(ref Quaternion quaternion_0)
	{
		return quaternion_0.eulerAngles;
	}

	private unsafe static int smethod_13()
	{
		int num = 112;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 61;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FromBaseCharArrayGlobalSwitch.getCurrentValueAppDomainPauseManager);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0335:
														byte b = *ptr2;
														while (true)
														{
															IL_0325:
															ptr2++;
															while (true)
															{
																IL_0315:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02f8:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02eb:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02db:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_02cb:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (13 <= b)
																											{
																												num = 158;
																												while (true)
																												{
																													if (num != 158)
																													{
																														if (num != 1139)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 50:
																															goto IL_02a8;
																														case 27:
																														case 46:
																															goto IL_02bb;
																														case 85:
																															goto IL_02cb;
																														case 95:
																															goto IL_02db;
																														case 134:
																															goto IL_02eb;
																														case 60:
																															goto IL_02f8;
																														case 117:
																															goto IL_0305;
																														case 18:
																															goto IL_0315;
																														case 126:
																															goto IL_0325;
																														case 0:
																														case 144:
																															goto IL_0335;
																														case 15:
																															goto IL_0340;
																														case 23:
																															goto IL_0350;
																														case 6:
																														case 66:
																															goto IL_035b;
																														case 14:
																														case 89:
																															goto IL_0373;
																														case 96:
																														case 131:
																															goto IL_03b8;
																														case 75:
																														case 127:
																															goto IL_03c6;
																														case 48:
																															goto IL_03d1;
																														case 39:
																															goto IL_03dc;
																														case 8:
																														case 22:
																															goto IL_03ef;
																														case 124:
																															goto IL_0433;
																														case 9:
																															goto IL_0441;
																														case 114:
																															goto IL_0454;
																														case 70:
																														case 122:
																															goto IL_045f;
																														case 82:
																															goto IL_047d;
																														case 68:
																															goto IL_048b;
																														case 32:
																															goto IL_049e;
																														case 2:
																														case 47:
																															goto IL_04a9;
																														case 129:
																															goto IL_04bc;
																														case 3:
																														case 54:
																															goto IL_04c7;
																														case 25:
																															goto IL_04d5;
																														case 43:
																														case 92:
																															goto IL_04e3;
																														case 17:
																															goto IL_0505;
																														case 5:
																															goto IL_0513;
																														case 28:
																															goto IL_0521;
																														case 62:
																														case 76:
																															goto IL_053d;
																														case 58:
																															goto IL_057d;
																														case 79:
																															goto IL_0591;
																														case 132:
																															goto IL_05a4;
																														case 7:
																														case 20:
																															goto IL_05b2;
																														case 78:
																															goto IL_05db;
																														case 125:
																														case 137:
																															goto IL_05f4;
																														case 1:
																															goto IL_061d;
																														case 10:
																															goto IL_062b;
																														case 139:
																															goto IL_0647;
																														case 49:
																														case 100:
																															goto IL_0655;
																														case 72:
																															goto IL_0663;
																														case 65:
																															goto IL_067b;
																														case 74:
																															goto IL_0689;
																														case 21:
																														case 145:
																															goto IL_069c;
																														case 71:
																															goto IL_06a7;
																														case 80:
																														case 143:
																															goto IL_06b5;
																														case 44:
																															goto IL_06c3;
																														case 73:
																															goto IL_06e6;
																														case 57:
																															goto IL_06f0;
																														case 42:
																															goto IL_06fe;
																														case 109:
																															goto IL_0711;
																														case 87:
																															goto IL_071f;
																														case 91:
																														case 142:
																															goto IL_072d;
																														case 52:
																															goto IL_0771;
																														case 77:
																															goto IL_0785;
																														case 108:
																														case 147:
																															goto IL_07a1;
																														case 128:
																															goto IL_07af;
																														case 149:
																															goto IL_07c2;
																														case 151:
																															goto IL_07de;
																														case 116:
																															goto IL_07f2;
																														case 99:
																															goto IL_0805;
																														case 93:
																															goto IL_0867;
																														case 104:
																														case 136:
																															goto IL_0877;
																														case 19:
																														case 150:
																															goto IL_0899;
																														case 51:
																															goto IL_08a4;
																														case 11:
																														case 12:
																														case 24:
																														case 34:
																														case 37:
																														case 41:
																														case 45:
																														case 53:
																														case 55:
																														case 56:
																														case 59:
																														case 64:
																														case 67:
																														case 69:
																														case 81:
																														case 86:
																														case 90:
																														case 94:
																														case 97:
																														case 98:
																														case 102:
																														case 121:
																														case 123:
																														case 130:
																														case 133:
																														case 135:
																														case 140:
																														case 141:
																														case 146:
																														case 148:
																															goto end_IL_02a8;
																														case 4:
																														case 16:
																														case 26:
																														case 31:
																														case 35:
																														case 36:
																														case 38:
																														case 40:
																														case 84:
																														case 88:
																														case 101:
																														case 103:
																														case 105:
																														case 106:
																														case 110:
																														case 113:
																														case 120:
																														case 138:
																															goto end_IL_0295;
																														case 115:
																															goto end_IL_08c2;
																														case 63:
																															goto end_IL_08d5;
																														case 33:
																															goto end_IL_08df;
																														case 107:
																															goto end_IL_08ea;
																														case 61:
																														case 119:
																															goto end_IL_08fa;
																														case 118:
																															goto end_IL_090a;
																														case 29:
																														case 30:
																															goto end_IL_091a;
																														case 111:
																															goto end_IL_0933;
																														case 112:
																															goto end_IL_0943;
																														case 13:
																														case 83:
																															goto IL_095e;
																														}
																														continue;
																													}
																													goto IL_0805;
																													IL_0805:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0867;
																													IL_0867:
																													num5 -= 2;
																													break;
																													continue;
																													end_IL_0295:
																													break;
																												}
																												goto end_IL_0315;
																												continue;
																												end_IL_02a8:
																												break;
																												IL_02a8:;
																											}
																											break;
																											IL_02bb:;
																										}
																										break;
																									}
																									goto IL_0877;
																									IL_0877:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0315;
																								}
																								break;
																							}
																							num = 150;
																							goto IL_0899;
																							IL_0899:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_08a4;
																							IL_08a4:
																							if (15 <= b)
																							{
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0340;
																					IL_0785:
																					num5--;
																					num = 106;
																					goto end_IL_0315;
																					IL_0340:
																					if (12 <= b)
																					{
																						goto IL_0373;
																					}
																					goto IL_069c;
																					IL_0373:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_07de;
																					IL_07de:
																					array[num5 - 2] = 0;
																					goto IL_07f2;
																					IL_07f2:
																					num5--;
																					goto end_IL_0315;
																					IL_069c:
																					if (10 >= b)
																					{
																						goto IL_06a7;
																					}
																					goto IL_0711;
																					IL_06a7:
																					if (10 <= b)
																					{
																						goto IL_06b5;
																					}
																					goto IL_07a1;
																					IL_06b5:
																					array[num5] = 0;
																					goto IL_06c3;
																					IL_06c3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_06e6;
																					IL_06e6:
																					array2[num5] = null;
																					goto IL_06f0;
																					IL_06f0:
																					num5++;
																					goto IL_06fe;
																					IL_06fe:
																					ptr2 += 8;
																					goto end_IL_0315;
																					IL_07a1:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_07af;
																					IL_07af:
																					if (9 <= b)
																					{
																						goto end_IL_0315;
																					}
																					break;
																					IL_0711:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_071f;
																					IL_071f:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_072d;
																					IL_072d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_0771;
																					IL_0771:
																					array[num5 - 2] = 0;
																					goto IL_0785;
																				}
																				break;
																			}
																			goto IL_0350;
																			IL_0591:
																			num5--;
																			goto end_IL_0315;
																			IL_0350:
																			if (8 <= b)
																			{
																				goto IL_035b;
																			}
																			goto IL_03b8;
																			IL_035b:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0315;
																			IL_03b8:
																			if (4 < b)
																			{
																				goto IL_03c6;
																			}
																			goto IL_0454;
																			IL_03c6:
																			if (6 >= b)
																			{
																				goto IL_03d1;
																			}
																			goto IL_0433;
																			IL_03d1:
																			if (6 > b)
																			{
																				goto IL_03dc;
																			}
																			goto IL_03ef;
																			IL_03dc:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0647;
																			IL_0647:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0655;
																			IL_0655:
																			array[num5] = 5;
																			goto IL_0663;
																			IL_0663:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_067b;
																			IL_067b:
																			num5++;
																			goto IL_0689;
																			IL_0689:
																			ptr2 += 8;
																			goto end_IL_0315;
																			IL_03ef:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07c2;
																			IL_07c2:
																			num5 -= 3;
																			num = 138;
																			goto end_IL_0315;
																			IL_0433:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0441;
																			IL_0441:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05f4;
																			IL_05f4:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_061d;
																			IL_061d:
																			ptr2 += 8;
																			goto IL_062b;
																			IL_062b:
																			num5--;
																			num = 35;
																			goto end_IL_0315;
																			IL_0454:
																			if (4 <= b)
																			{
																				goto IL_045f;
																			}
																			goto IL_049e;
																			IL_045f:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_047d;
																			IL_047d:
																			ptr2 += 8;
																			goto IL_048b;
																			IL_048b:
																			num5--;
																			goto end_IL_0315;
																			IL_049e:
																			if (2 < b)
																			{
																				goto IL_04a9;
																			}
																			goto IL_04bc;
																			IL_04a9:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_05a4;
																			IL_05a4:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_05b2;
																			IL_05b2:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_05db;
																			IL_05db:
																			array[num5 - 1] = 5;
																			goto end_IL_0315;
																			IL_04bc:
																			if (2 > b)
																			{
																				goto IL_04c7;
																			}
																			goto IL_053d;
																			IL_04c7:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04d5;
																			IL_04d5:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04e3;
																			IL_04e3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 17;
																			goto IL_0505;
																			IL_0505:
																			array[num5] = 0;
																			goto IL_0513;
																			IL_0513:
																			num5++;
																			goto IL_0521;
																			IL_0521:
																			ptr2 += 8;
																			num = 110;
																			goto end_IL_0315;
																			IL_053d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_057d;
																			IL_057d:
																			array[num5 - 2] = 0;
																			goto IL_0591;
																		}
																		break;
																		IL_0305:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0315:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_095e;
												IL_095e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c2:
												break;
											}
											continue;
											end_IL_08d5:
											break;
										}
										continue;
										end_IL_08df:
										break;
									}
									continue;
									end_IL_08ea:
									break;
								}
								continue;
								end_IL_08fa:
								break;
							}
							continue;
							end_IL_090a:
							break;
						}
						continue;
						end_IL_091a:
						break;
					}
					continue;
					end_IL_0933:
					break;
				}
				continue;
				end_IL_0943:
				break;
			}
		}
	}

	private static float SkipSetUserEntryPoint(Vector3 vector3_1)
	{
		return vector3_1.z;
	}

	private static int setKeyUIPermissionAttribute(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool TryEnterGetNestedTypes()
	{
		return global::_003CModule_003E.jblwWvIj_003E_003C;
	}

	private static float DataCollectorGetEncoder(ref Vector2 vector2_0)
	{
		return vector2_0.y;
	}

	private static Transform InterfaceForwardingSupportPlay(Transform transform_0)
	{
		return transform_0.parent;
	}

	private static Vector3 MemberEventName(Vector3 vector3_1, Vector3 vector3_2)
	{
		return vector3_1 + vector3_2;
	}

	private static Vector3 MaxBinaryLengthGetUserStoreForSite()
	{
		return Vector3.zero;
	}

	private static Vector3 UsageAllowedTaskWaitEnd(Transform transform_0)
	{
		return transform_0.right;
	}

	private static double XmlIMembershipCondition(double double_1)
	{
		return Math.Round(double_1);
	}

	private static void NumUTCTimeMarkgetUIFamilyCodePage(Transform transform_0, Quaternion quaternion_0)
	{
		transform_0.rotation = quaternion_0;
	}

	private static void ASCIIEncodingEnumInstallationReferences(Rigidbody rigidbody_0, Vector3 vector3_1)
	{
		rigidbody_0.linearVelocity = vector3_1;
	}

	private static float HasCustomAttributegetFullyQualifiedName()
	{
		return float_4;
	}

	private static double QWordgetEras(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static double FormatWithParameterIChannelDataStore(double double_1)
	{
		return Math.Round(double_1);
	}

	private static void FILETIMEIsSddlConversionSupported(Transform transform_0, Vector3 vector3_1)
	{
		transform_0.position = vector3_1;
	}

	private static Mouse ArgIteratorBuiltinIncomingForestTrustBuildersSid()
	{
		return Mouse.current;
	}

	private static float ToCharArrayStartNew()
	{
		return float_2;
	}

	private static float smethod_14()
	{
		return global::_003CModule_003E.float_99;
	}

	private static Transform IBindableVectorStelemI(Transform transform_0)
	{
		return transform_0.parent;
	}
}
