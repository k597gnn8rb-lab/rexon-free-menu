using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Laser Eyes", "Super Infection/Casual [MASTERCLIENT]", "Shoots lasers from your eyes.", false, 28, ModType.const_0, false)]
internal class Class121 : MonoBehaviour
{
	private float float_0;

	private static int int_0;

	private static double double_0;

	private static float float_1;

	private static float float_2;

	private static float float_3;

	private static float float_4;

	private static int int_1;

	private static IntPtr[] getUIContextReturnType;

	private static IntPtr[] DisableOptimizationsgetEmbedded;

	private static IntPtr[] ParagraphSeparatorgetLongTimePattern;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_143f, IL_1452, IL_149c, IL_14b2, IL_14c2, IL_14d2, IL_14e2, IL_14f2, IL_1502, IL_1512, IL_1522, IL_1532, IL_1542, IL_1552, IL_1562, IL_1572, IL_1582, IL_1592, IL_159d, IL_15bb, IL_15ce, IL_15d9, IL_15f3, IL_1606, IL_1611, IL_161c, IL_162f, IL_163f, IL_165a, IL_166d, IL_1680, IL_168b, IL_1699, IL_16ac, IL_16bf, IL_16cd, IL_16db, IL_16e9, IL_16f7, IL_1705, IL_1710, IL_1723, IL_1731, IL_173a, IL_1748, IL_1788, IL_179c, IL_17af, IL_17bd, IL_17c8, IL_17d6, IL_17e9, IL_17f4, IL_1807, IL_1815, IL_1823, IL_183c, IL_184a, IL_1858, IL_1866, IL_1874, IL_187f, IL_188d, IL_189b, IL_18ae, IL_18bc, IL_18ca, IL_18ed, IL_1900, IL_190e, IL_191c, IL_1927, IL_193b, IL_197a, IL_198d, IL_19a0, IL_19ae, IL_19bc, IL_19ca, IL_19e2, IL_19ed, IL_1a18, IL_1a31, IL_1a3f, IL_1a48, IL_1a56, IL_1a64, IL_1a87, IL_1ac7, IL_1adb, IL_1aee, IL_1afc, IL_1b0a, IL_1b18, IL_1b2b, IL_1b36, IL_1b64, IL_1b6f, IL_1b7a, IL_1b8d, IL_1b9b, IL_1ba9, IL_1bb2, IL_1bd2, IL_1bdb, IL_1bee, IL_1c05, IL_1c18, IL_1c2b, IL_1c39, IL_1c4c, IL_1c5c, IL_1c99, IL_1ca4, IL_1cb2, IL_1cc5, IL_1d0e, IL_1d22, IL_1d35, IL_1d43, IL_1d56, IL_1d61, IL_1d7a, IL_1d8d, IL_1d9b, IL_1da9, IL_1db2, IL_1de2, IL_1df0, IL_1e03, IL_1e1c, IL_1e2a, IL_1e38, IL_1e4b, IL_1e59, IL_1e6c, IL_1e8f, IL_1e9d, IL_1eba, IL_1ed3, IL_1ee1, IL_1eef, IL_1f02, IL_1f1b, IL_1f29, IL_1f42, IL_1f55, IL_1f68, IL_1f7c, IL_1fd4, IL_1fdf, IL_1ff3, IL_2032, IL_2045, IL_2053, IL_2061, IL_206f, IL_2093, IL_20a1, IL_20b4, IL_20f4, IL_2108, IL_211b, IL_213f, IL_214d, IL_215b, IL_216e, IL_2187, IL_2195, IL_21a3, IL_21b6, IL_21d4, IL_21e2, IL_21f5, IL_2200, IL_220e, IL_2227, IL_223a, IL_2245, IL_2253, IL_2261, IL_227f, IL_228d, IL_22a4, IL_22b7, IL_22c0, IL_22ce, IL_22e2, IL_2321, IL_233d, IL_235c, IL_23a3, IL_23b6, IL_23ca, IL_2421, IL_2448, IL_246c, IL_2484, IL_2497, IL_24a5, IL_24b8, IL_24cb, IL_250b, IL_251f, IL_2532, IL_2540, IL_254e, IL_25b0, IL_25c3, IL_25e0, IL_262f, IL_2639, IL_2666, IL_267a, IL_2688, IL_269b, IL_26a9, IL_26bc, IL_26ca, IL_26d8, IL_26e6, IL_26f4, IL_270e, IL_2721, IL_272f, IL_2752, IL_275c, IL_276a, IL_277d, IL_278b, IL_27a2, IL_27b5, IL_27c3, IL_27db, IL_27e9, IL_2805, IL_2813, IL_2821, IL_282f, IL_284d, IL_2864, IL_2877, IL_2885, IL_2893, IL_28a1, IL_28b5, IL_28f4, IL_2910, IL_291e, IL_2938, IL_294b, IL_2956, IL_2964, IL_2972, IL_298e, IL_299c, IL_29af, IL_29c2, IL_2a5c, IL_2a6a, IL_2a7d, IL_2a91, IL_2ad0, IL_2ae3, IL_2af1, IL_2aff, IL_2b1b, IL_2b29, IL_2b34, IL_2b3d, IL_2b51, IL_2b90, IL_2ba3, IL_2bb1, IL_2bbc, IL_2be0, IL_2bee, IL_2bfc, IL_2c0f, IL_2c1d, IL_2c28, IL_2c36, IL_2c44, IL_2c4d, IL_2c65, IL_2ca6, IL_2cc3, IL_2cd6, IL_2ce1, IL_2cea, IL_2cf8, IL_2d4a, IL_2d5d, IL_2d6b, IL_2d74, IL_2d82, IL_2da0, IL_2dae, IL_2dbc, IL_2dd8, IL_2de6, IL_2df1, IL_2e0a, IL_2e18, IL_2e26, IL_2e39, IL_2e47, IL_2e50, IL_2e5e, IL_2e9c, IL_2eaa, IL_2ebd, IL_2ec8, IL_2ed6, IL_2eea, IL_2f29, IL_2f3c, IL_2f4a, IL_2f58, IL_2f98, IL_2fac, IL_2fc8, IL_2fd6, IL_2fe1, IL_2fff, IL_300d, IL_301b, IL_302e, IL_303c, IL_3047, IL_3055, IL_3063, IL_3071, IL_308f, IL_309d, IL_30b0, IL_30d2, IL_30e5, IL_30f0, IL_30fe, IL_3117, IL_3125, IL_3133, IL_317c, IL_3190, IL_31a3, IL_31b1, IL_31bc, IL_31d0, IL_320e, IL_3221, IL_322f, IL_323d, IL_3260, IL_326e, IL_327c, IL_328f, IL_329a, IL_32a8, IL_32e6, IL_32f4, IL_3307, IL_3315, IL_331e, IL_332c, IL_3340, IL_3388, IL_339b, IL_33bf, IL_33cd, IL_33db, IL_33ee, IL_340c, IL_341a, IL_3428, IL_343b, IL_3455, IL_3468, IL_34a8, IL_34bc, IL_34d8, IL_34e6, IL_3502, IL_3541, IL_3554, IL_3562, IL_3576, IL_35b5, IL_35c8, IL_35f3, IL_360c, IL_3635, IL_3643, IL_3656, IL_3669, IL_3677, IL_3682, IL_36a6, IL_36b4, IL_36cb, IL_36de, IL_36ec, IL_36fa, IL_3718, IL_3726, IL_3734, IL_3747, IL_3752, IL_3760, IL_376a, IL_3778, IL_378b, IL_3799, IL_37a2, IL_37b0, IL_37c4, IL_3811, IL_381f, IL_3832, IL_3840, IL_384b, IL_3854, IL_386d, IL_3880, IL_388e, IL_389c, IL_38b0, IL_3902, IL_3910, IL_3923, IL_3931, IL_393f, IL_394a, IL_3953, IL_3961, IL_3985, IL_3993, IL_39a6, IL_39b4, IL_39c2, IL_39d0, IL_39de, IL_39f2, IL_3a31, IL_3a44, IL_3a4d, IL_3a5b, IL_3a7d, IL_3a90, IL_3a9e, IL_3ab2, IL_3b03, IL_3b11, IL_3b24, IL_3b32, IL_3b40, IL_3b54, IL_3bbc, IL_3bca, IL_3bdd, IL_3beb, IL_3bf6, IL_3c04, IL_3c28, IL_3c36, IL_3c49, IL_3c57, IL_3c65, IL_3c7d, IL_3c8b, IL_3c99, IL_3cac, IL_3cb7, IL_3cc5, IL_3cf3, IL_3d06, IL_3d14, IL_3d22, IL_3d45, IL_3d53, IL_3d61, IL_3d74, IL_3d7d, IL_3d8b, IL_3d99, IL_3da4, IL_3dc7, IL_3dd5, IL_3de3, IL_3df6, IL_3e04, IL_3e0f, IL_3e24, IL_3e37, IL_3e45, IL_3e4e, IL_3e5c, IL_3e80, IL_3e8e, IL_3e9c, IL_3eaf, IL_3ebd, IL_3ecb, IL_3ef7, IL_3f05, IL_3f13, IL_3f26, IL_3f34, IL_3f42, IL_3f56, IL_3fb1, IL_3fbf, IL_3fd2, IL_3fe0, IL_3fee, IL_4012, IL_4020, IL_402e, IL_4041, IL_404f, IL_405d, IL_4071, IL_40c2, IL_40d0, IL_40ec, IL_40fa, IL_4108, IL_4121, IL_4134, IL_4151, IL_418e, IL_41a1, IL_41af, IL_41bd, IL_41d1, IL_422d, IL_423b, IL_424e, IL_425c, IL_4267, IL_428a, IL_4298, IL_42a6, IL_42b9, IL_42c4, IL_42cf, IL_42dd, IL_42f9, IL_4307, IL_4315, IL_432a, IL_433d, IL_4348, IL_4361, IL_4374, IL_4382, IL_4390, IL_43aa, IL_43bd, IL_43cb, IL_43d6, IL_43e4, IL_4438, IL_444b, IL_4459, IL_4467, IL_448a, IL_4498, IL_44a6, IL_44b9, IL_44c2, IL_44cd, IL_44db, IL_44e9, IL_4502, IL_4515, IL_4533, IL_4541, IL_454f, IL_456b, IL_4579, IL_4584, IL_4598, IL_45d0, IL_45e3, IL_45f1, IL_45fc, IL_4610, IL_464f, IL_466b, IL_4679, IL_4687, IL_4690, IL_46aa, IL_46bd, IL_46cb, IL_46d9, IL_46e2, IL_46f0, IL_4728, IL_4745, IL_4758, IL_4761, IL_476f, IL_477d, IL_479b, IL_47a9, IL_47bc, IL_47ca, IL_47d5, IL_47e3, IL_4801, IL_480f, IL_4822, IL_4830, IL_483e, IL_4852, IL_488f, IL_48a2, IL_48ad, IL_48bb, IL_48cf, IL_4907, IL_491a, IL_4928, IL_4936, IL_494a, IL_4987, IL_499a, IL_49a8, IL_49b3, IL_49c7, IL_4a0f, IL_4a1d, IL_4a30, IL_4a3e, IL_4a49, IL_4a81, IL_4a95, IL_4aa8, IL_4ab6, IL_4ac4, IL_4ad8, IL_4b29, IL_4b37, IL_4b4a, IL_4b58, IL_4b63, IL_4b81, IL_4b8f, IL_4ba6, IL_4bb9, IL_4bc7, IL_4bd5, IL_4bee, IL_4c01, IL_4c0c, IL_4c1a, IL_4c3d, IL_4c4b, IL_4c59, IL_4c6c, IL_4c7a, IL_4c88, IL_4ca5, IL_4cf6, IL_4d04, IL_4d17, IL_4d25, IL_4d30, IL_4d53, IL_4d61, IL_4d6f, IL_4d82, IL_4d90, IL_4d9e, IL_4db7, IL_4dca, IL_4dd8, IL_4de6, IL_4e03, IL_4e54, IL_4e62, IL_4e75, IL_4e83, IL_4e91, IL_4eaa, IL_4ebd, IL_4ecb, IL_4ed6, IL_4ef4, IL_4f02, IL_4f10, IL_4f23, IL_4f31, IL_4f3c, IL_4f4a, IL_4f58, IL_4f81, IL_4f8f, IL_4fa2, IL_4fb0, IL_4fdd, IL_4feb, IL_4ffe, IL_5009, IL_5017, IL_5055, IL_5069, IL_5085, IL_5093, IL_50a1, IL_510f, IL_5122, IL_5130, IL_513b, IL_514f, IL_518d, IL_51a0, IL_51ae, IL_51bc, IL_51c5, IL_51e8, IL_51f6, IL_5204, IL_5217, IL_5222, IL_5230, IL_5254, IL_5262, IL_5270, IL_5283, IL_5291, IL_529f, IL_52a8, IL_52bc, IL_5309, IL_5317, IL_532a, IL_5338, IL_5343, IL_5360, IL_539f, IL_53b2, IL_53c0, IL_53ce, IL_53d9, IL_5402, IL_5424, IL_5432, IL_5440, IL_5454, IL_5493, IL_54af, IL_54ba, IL_54c8, IL_54e5, IL_551d, IL_5530, IL_553e, IL_554c, IL_558a, IL_559d, IL_55a8, IL_55bc, IL_55fb, IL_560e, IL_561c, IL_5627, IL_5685, IL_5698, IL_56a6, IL_56b4, IL_56c2, IL_56e6, IL_56f4, IL_5707, IL_5715, IL_5723, IL_5737, IL_5789, IL_5797, IL_57aa, IL_57b8, IL_57c6, IL_57fe, IL_5812, IL_5825, IL_5833, IL_583e, IL_5852, IL_5891, IL_58a4, IL_58b2, IL_58bd, IL_58d1, IL_5909, IL_591c, IL_592a, IL_5938, IL_594c, IL_598b, IL_599e, IL_59a9, IL_59b7, IL_59f5, IL_5a11, IL_5a1f, IL_5a28, IL_5a36, IL_5a4a, IL_5a89, IL_5a9c, IL_5aaa, IL_5ab5, IL_5ac9, IL_5b08, IL_5b1b, IL_5b29, IL_5b37, IL_5b4b, IL_5bcf, IL_5bdd, IL_5bf0, IL_5bfb, IL_5c09, IL_5c47, IL_5c5e, IL_5c6e, IL_5c79, IL_5c84, IL_5c8d, IL_5ca0, IL_5cb3, IL_5cbe, IL_5cc8, IL_5cd3, IL_5ce3, IL_5cf3, IL_5d0c, IL_5d1c, IL_5d2c, IL_5d3c, IL_5d4c, IL_5d5c, IL_5d6c are reachable both inside and outside the pinned region starting at IL_5d81. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 184;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef32 = default(int);
			ref int reference = ref __rxRef32;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_5d6c:
					num2 = 1;
					while (true)
					{
						IL_5d5c:
						num3 = num2 * 4;
						while (true)
						{
							IL_5d4c:
							num4 = num2 * 8;
							while (true)
							{
								IL_5d3c:
								array2 = new byte[7];
								while (true)
								{
									IL_5d2c:
									array3 = new object[7];
									while (true)
									{
										IL_5d1c:
										array4 = new int[7];
										while (true)
										{
											IL_5d0c:
											array5 = new int[7];
											while (true)
											{
												IL_5cf3:
												array6 = new long[7];
												num = 128;
												while (true)
												{
													IL_5ce3:
													array7 = new object[24];
													while (true)
													{
														IL_5cd3:
														array7[0] = this;
														while (true)
														{
															IL_5cc8:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateNodegetInterfaceType.IsApplicationTrustedToRunGenericSecurityDescriptor);
															while (true)
															{
																IL_5cbe:
																ptr2 = ptr;
																while (true)
																{
																	IL_5cb3:
																	num = 485;
																	while (true)
																	{
																		IL_5ca0:
																		if (num5 == 1)
																		{
																			return;
																		}
																		while (true)
																		{
																			IL_1592:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_1582:
																				ptr2++;
																				while (true)
																				{
																					IL_1572:
																					if (b >= 1)
																					{
																						while (b <= 156)
																						{
																							while (true)
																							{
																								IL_1552:
																								if (78 >= b)
																								{
																									while (true)
																									{
																										IL_1542:
																										if (78 > b)
																										{
																											while (true)
																											{
																												IL_1532:
																												if (39 < b)
																												{
																													while (true)
																													{
																														IL_1522:
																														if (58 < b)
																														{
																															while (true)
																															{
																																IL_1512:
																																if (68 < b)
																																{
																																	while (true)
																																	{
																																		IL_1502:
																																		if (73 >= b)
																																		{
																																			while (true)
																																			{
																																				IL_14f2:
																																				if (73 > b)
																																				{
																																					while (true)
																																					{
																																						IL_14e2:
																																						if (70 < b)
																																						{
																																							while (true)
																																							{
																																								IL_14d2:
																																								if (71 < b)
																																								{
																																									while (72 >= b)
																																									{
																																										while (72 <= b)
																																										{
																																											while (true)
																																											{
																																												IL_149c:
																																												array2[num6 - 1] = 3;
																																												while (true)
																																												{
																																													IL_1452:
																																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																													num = 1292;
																																													while (true)
																																													{
																																														if (num != 1292)
																																														{
																																															if (num != 2273)
																																															{
																																																break;
																																															}
																																															switch (num)
																																															{
																																															case 184:
																																																break;
																																															default:
																																																continue;
																																															case 105:
																																																goto IL_1452;
																																															case 808:
																																															case 948:
																																																goto IL_149c;
																																															case 574:
																																																goto IL_14b2;
																																															case 815:
																																																goto IL_14c2;
																																															case 361:
																																																goto IL_14d2;
																																															case 996:
																																																goto IL_14e2;
																																															case 517:
																																																goto IL_14f2;
																																															case 365:
																																																goto IL_1502;
																																															case 90:
																																																goto IL_1512;
																																															case 9:
																																																goto IL_1522;
																																															case 1138:
																																																goto IL_1532;
																																															case 1276:
																																																goto IL_1542;
																																															case 317:
																																																goto IL_1552;
																																															case 1013:
																																																goto IL_1562;
																																															case 223:
																																																goto IL_1572;
																																															case 992:
																																																goto IL_1582;
																																															case 563:
																																															case 1189:
																																																goto IL_1592;
																																															case 107:
																																															case 280:
																																																goto IL_159d;
																																															case 590:
																																																goto IL_15bb;
																																															case 650:
																																																goto IL_15ce;
																																															case 189:
																																															case 209:
																																																goto IL_15d9;
																																															case 558:
																																																goto IL_15f3;
																																															case 147:
																																																goto IL_1606;
																																															case 357:
																																																goto IL_1611;
																																															case 336:
																																																goto IL_161c;
																																															case 234:
																																																goto IL_162f;
																																															case 235:
																																															case 657:
																																																goto IL_163f;
																																															case 682:
																																																goto IL_165a;
																																															case 712:
																																																goto IL_166d;
																																															case 739:
																																																goto IL_1680;
																																															case 174:
																																																goto IL_168b;
																																															case 27:
																																																goto IL_1699;
																																															case 761:
																																																goto IL_16ac;
																																															case 825:
																																																goto IL_16bf;
																																															case 159:
																																																goto IL_16cd;
																																															case 323:
																																																goto IL_16db;
																																															case 411:
																																																goto IL_16e9;
																																															case 483:
																																																goto IL_16f7;
																																															case 688:
																																																goto IL_1705;
																																															case 423:
																																																goto IL_1710;
																																															case 796:
																																																goto IL_1723;
																																															case 470:
																																																goto IL_173a;
																																															case 239:
																																															case 380:
																																																goto IL_1748;
																																															case 59:
																																																goto IL_1788;
																																															case 328:
																																																goto IL_179c;
																																															case 78:
																																																goto IL_17af;
																																															case 813:
																																																goto IL_17bd;
																																															case 489:
																																																goto IL_17c8;
																																															case 820:
																																																goto IL_17d6;
																																															case 14:
																																																goto IL_17e9;
																																															case 779:
																																																goto IL_17f4;
																																															case 138:
																																																goto IL_1807;
																																															case 172:
																																																goto IL_1815;
																																															case 551:
																																															case 625:
																																																goto IL_1823;
																																															case 843:
																																																goto IL_183c;
																																															case 617:
																																																goto IL_184a;
																																															case 427:
																																																goto IL_1858;
																																															case 422:
																																																goto IL_1866;
																																															case 167:
																																																goto IL_1874;
																																															case 462:
																																																goto IL_187f;
																																															case 298:
																																																goto IL_188d;
																																															case 276:
																																																goto IL_189b;
																																															case 493:
																																																goto IL_18ae;
																																															case 546:
																																																goto IL_18bc;
																																															case 197:
																																															case 401:
																																																goto IL_18ca;
																																															case 669:
																																																goto IL_18ed;
																																															case 789:
																																																goto IL_1900;
																																															case 344:
																																																goto IL_190e;
																																															case 410:
																																																goto IL_191c;
																																															case 93:
																																															case 362:
																																																goto IL_1927;
																																															case 390:
																																																goto IL_193b;
																																															case 687:
																																																goto IL_197a;
																																															case 261:
																																																goto IL_198d;
																																															case 319:
																																																goto IL_19a0;
																																															case 117:
																																																goto IL_19ae;
																																															case 637:
																																															case 788:
																																																goto IL_19bc;
																																															case 271:
																																																goto IL_19ca;
																																															case 857:
																																																goto IL_19e2;
																																															case 371:
																																															case 541:
																																																goto IL_19ed;
																																															case 528:
																																																goto IL_1a18;
																																															case 499:
																																																goto IL_1a31;
																																															case 492:
																																																goto IL_1a48;
																																															case 116:
																																															case 864:
																																																goto IL_1a64;
																																															case 251:
																																															case 896:
																																																goto IL_1a87;
																																															case 822:
																																																goto IL_1ac7;
																																															case 501:
																																																goto IL_1adb;
																																															case 923:
																																																goto IL_1aee;
																																															case 391:
																																																goto IL_1afc;
																																															case 697:
																																																goto IL_1b0a;
																																															case 426:
																																															case 663:
																																																goto IL_1b18;
																																															case 937:
																																																goto IL_1b2b;
																																															case 212:
																																															case 662:
																																																goto IL_1b36;
																																															case 100:
																																																goto IL_1b64;
																																															case 289:
																																																goto IL_1b6f;
																																															case 506:
																																																goto IL_1b7a;
																																															case 39:
																																																goto IL_1b8d;
																																															case 396:
																																																goto IL_1b9b;
																																															case 461:
																																															case 828:
																																																goto IL_1bb2;
																																															case 721:
																																																goto IL_1bdb;
																																															case 962:
																																																goto IL_1bee;
																																															case 450:
																																																goto IL_1c05;
																																															case 969:
																																																goto IL_1c18;
																																															case 971:
																																																goto IL_1c2b;
																																															case 301:
																																																goto IL_1c39;
																																															case 984:
																																																goto IL_1c4c;
																																															case 986:
																																																goto IL_1c5c;
																																															case 1006:
																																																goto IL_1c99;
																																															case 731:
																																																goto IL_1ca4;
																																															case 955:
																																																goto IL_1cb2;
																																															case 99:
																																															case 606:
																																																goto IL_1cc5;
																																															case 153:
																																																goto IL_1d0e;
																																															case 351:
																																																goto IL_1d22;
																																															case 1015:
																																																goto IL_1d35;
																																															case 613:
																																																goto IL_1d43;
																																															case 1018:
																																																goto IL_1d56;
																																															case 168:
																																															case 325:
																																																goto IL_1d61;
																																															case 926:
																																																goto IL_1d7a;
																																															case 270:
																																																goto IL_1d8d;
																																															case 320:
																																																goto IL_1d9b;
																																															case 68:
																																															case 124:
																																																goto IL_1db2;
																																															case 1029:
																																																goto IL_1de2;
																																															case 118:
																																															case 524:
																																																goto IL_1df0;
																																															case 341:
																																															case 1050:
																																																goto IL_1e03;
																																															case 694:
																																																goto IL_1e1c;
																																															case 292:
																																																goto IL_1e2a;
																																															case 801:
																																																goto IL_1e38;
																																															case 1061:
																																																goto IL_1e4b;
																																															case 851:
																																																goto IL_1e59;
																																															case 1043:
																																															case 1067:
																																																goto IL_1e6c;
																																															case 1068:
																																																goto IL_1e8f;
																																															case 41:
																																															case 353:
																																																goto IL_1e9d;
																																															case 1069:
																																																goto IL_1eba;
																																															case 1076:
																																																goto IL_1ed3;
																																															case 928:
																																																goto IL_1ee1;
																																															case 603:
																																																goto IL_1eef;
																																															case 1077:
																																																goto IL_1f02;
																																															case 1087:
																																																goto IL_1f1b;
																																															case 203:
																																															case 405:
																																																goto IL_1f29;
																																															case 631:
																																																goto IL_1f42;
																																															case 1090:
																																																goto IL_1f55;
																																															case 1031:
																																															case 1093:
																																																goto IL_1f68;
																																															case 865:
																																																goto IL_1f7c;
																																															case 1098:
																																																goto IL_1fd4;
																																															case 245:
																																															case 567:
																																																goto IL_1fdf;
																																															case 269:
																																																goto IL_1ff3;
																																															case 706:
																																																goto IL_2032;
																																															case 475:
																																																goto IL_2045;
																																															case 346:
																																																goto IL_2053;
																																															case 781:
																																															case 817:
																																																goto IL_2061;
																																															case 484:
																																																goto IL_206f;
																																															case 751:
																																																goto IL_2093;
																																															case 225:
																																																goto IL_20a1;
																																															case 977:
																																															case 1103:
																																																goto IL_20b4;
																																															case 171:
																																																goto IL_20f4;
																																															case 481:
																																																goto IL_2108;
																																															case 395:
																																															case 1112:
																																																goto IL_211b;
																																															case 375:
																																																goto IL_213f;
																																															case 1020:
																																																goto IL_214d;
																																															case 111:
																																																goto IL_215b;
																																															case 74:
																																															case 1113:
																																																goto IL_216e;
																																															case 1023:
																																																goto IL_2187;
																																															case 1042:
																																																goto IL_2195;
																																															case 862:
																																																goto IL_21a3;
																																															case 1120:
																																																goto IL_21b6;
																																															case 127:
																																																goto IL_21d4;
																																															case 783:
																																																goto IL_21e2;
																																															case 1129:
																																																goto IL_21f5;
																																															case 18:
																																																goto IL_2200;
																																															case 445:
																																															case 737:
																																																goto IL_220e;
																																															case 800:
																																																goto IL_2227;
																																															case 185:
																																																goto IL_223a;
																																															case 661:
																																																goto IL_2245;
																																															case 973:
																																																goto IL_2253;
																																															case 19:
																																															case 467:
																																																goto IL_2261;
																																															case 175:
																																																goto IL_227f;
																																															case 628:
																																																goto IL_228d;
																																															case 229:
																																																goto IL_22a4;
																																															case 335:
																																																goto IL_22c0;
																																															case 726:
																																															case 790:
																																																goto IL_22ce;
																																															case 990:
																																																goto IL_22e2;
																																															case 464:
																																																goto IL_2321;
																																															case 916:
																																															case 1137:
																																																goto IL_233d;
																																															case 377:
																																															case 1140:
																																																goto IL_235c;
																																															case 559:
																																																goto IL_23a3;
																																															case 1046:
																																															case 1151:
																																																goto IL_23b6;
																																															case 856:
																																																goto IL_23ca;
																																															case 1152:
																																																goto IL_2421;
																																															case 21:
																																																goto IL_2448;
																																															case 87:
																																																goto IL_246c;
																																															case 155:
																																																goto IL_2484;
																																															case 1159:
																																																goto IL_2497;
																																															case 477:
																																																goto IL_24a5;
																																															case 1170:
																																																goto IL_24b8;
																																															case 659:
																																															case 1171:
																																																goto IL_24cb;
																																															case 86:
																																																goto IL_250b;
																																															case 133:
																																																goto IL_251f;
																																															case 1173:
																																																goto IL_2532;
																																															case 805:
																																																goto IL_2540;
																																															case 736:
																																															case 1123:
																																																goto IL_254e;
																																															case 868:
																																																goto IL_25b0;
																																															case 600:
																																															case 1178:
																																																goto IL_25c3;
																																															case 782:
																																																goto IL_267a;
																																															case 386:
																																																goto IL_2688;
																																															case 1180:
																																																goto IL_269b;
																																															case 1019:
																																																goto IL_26a9;
																																															case 1192:
																																																goto IL_26bc;
																																															case 67:
																																																goto IL_26ca;
																																															case 29:
																																																goto IL_26d8;
																																															case 917:
																																																goto IL_26e6;
																																															case 324:
																																															case 702:
																																																goto IL_26f4;
																																															case 255:
																																																goto IL_270e;
																																															case 369:
																																															case 1205:
																																																goto IL_2721;
																																															case 575:
																																																goto IL_272f;
																																															case 870:
																																																goto IL_2752;
																																															case 987:
																																																goto IL_275c;
																																															case 112:
																																																goto IL_276a;
																																															case 1213:
																																																goto IL_277d;
																																															case 307:
																																																goto IL_278b;
																																															case 507:
																																																goto IL_27a2;
																																															case 36:
																																															case 1216:
																																																goto IL_27b5;
																																															case 367:
																																																goto IL_27c3;
																																															case 226:
																																																goto IL_27db;
																																															case 1167:
																																																goto IL_27e9;
																																															case 1224:
																																																goto IL_2805;
																																															case 218:
																																																goto IL_2813;
																																															case 152:
																																															case 1139:
																																																goto IL_2821;
																																															case 1153:
																																																goto IL_282f;
																																															case 121:
																																																goto IL_284d;
																																															case 552:
																																																goto IL_2864;
																																															case 1242:
																																																goto IL_2877;
																																															case 416:
																																																goto IL_2885;
																																															case 272:
																																																goto IL_2893;
																																															case 376:
																																															case 816:
																																																goto IL_28a1;
																																															case 780:
																																																goto IL_28b5;
																																															case 273:
																																																goto IL_28f4;
																																															case 1246:
																																																goto IL_2910;
																																															case 934:
																																															case 956:
																																																goto IL_291e;
																																															case 96:
																																																goto IL_2938;
																																															case 1247:
																																																goto IL_294b;
																																															case 1209:
																																																goto IL_2956;
																																															case 439:
																																															case 1001:
																																																goto IL_2964;
																																															case 904:
																																																goto IL_2972;
																																															case 1187:
																																																goto IL_298e;
																																															case 785:
																																																goto IL_299c;
																																															case 286:
																																																goto IL_29af;
																																															case 1101:
																																															case 1251:
																																																goto IL_29c2;
																																															case 670:
																																																goto IL_2a5c;
																																															case 1165:
																																																goto IL_2a6a;
																																															case 1014:
																																															case 1252:
																																																goto IL_2a7d;
																																															case 140:
																																																goto IL_2a91;
																																															case 1092:
																																																goto IL_2ad0;
																																															case 1254:
																																																goto IL_2ae3;
																																															case 1032:
																																																goto IL_2af1;
																																															case 80:
																																																goto IL_2aff;
																																															case 1255:
																																																goto IL_2b1b;
																																															case 24:
																																																goto IL_2b29;
																																															case 42:
																																															case 394:
																																																goto IL_2b3d;
																																															case 897:
																																																goto IL_2b51;
																																															case 1155:
																																																goto IL_2b90;
																																															case 855:
																																																goto IL_2ba3;
																																															case 258:
																																																goto IL_2bb1;
																																															case 402:
																																															case 495:
																																																goto IL_2bbc;
																																															case 967:
																																																goto IL_2be0;
																																															case 995:
																																																goto IL_2bee;
																																															case 810:
																																																goto IL_2bfc;
																																															case 907:
																																																goto IL_2c0f;
																																															case 838:
																																																goto IL_2c1d;
																																															case 466:
																																																goto IL_2c28;
																																															case 993:
																																																goto IL_2c36;
																																															case 314:
																																															case 830:
																																																goto IL_2c4d;
																																															case 449:
																																															case 566:
																																																goto IL_2c65;
																																															case 503:
																																																goto IL_2ca6;
																																															case 550:
																																																goto IL_2cc3;
																																															case 957:
																																																goto IL_2cd6;
																																															case 409:
																																																goto IL_2cea;
																																															case 131:
																																															case 459:
																																																goto IL_2cf8;
																																															case 177:
																																																goto IL_2d4a;
																																															case 1215:
																																																goto IL_2d5d;
																																															case 895:
																																																goto IL_2d74;
																																															case 373:
																																															case 874:
																																																goto IL_2d82;
																																															case 863:
																																																goto IL_2da0;
																																															case 66:
																																																goto IL_2dae;
																																															case 684:
																																																goto IL_2dbc;
																																															case 1149:
																																																goto IL_2dd8;
																																															case 1034:
																																																goto IL_2de6;
																																															case 430:
																																															case 1131:
																																																goto IL_2df1;
																																															case 676:
																																																goto IL_2e0a;
																																															case 958:
																																																goto IL_2e18;
																																															case 343:
																																																goto IL_2e26;
																																															case 812:
																																																goto IL_2e39;
																																															case 561:
																																																goto IL_2e50;
																																															case 40:
																																															case 906:
																																																goto IL_2e5e;
																																															case 192:
																																																goto IL_2e9c;
																																															case 1108:
																																																goto IL_2eaa;
																																															case 5:
																																																goto IL_2ebd;
																																															case 1204:
																																																goto IL_2ec8;
																																															case 839:
																																															case 1177:
																																																goto IL_2ed6;
																																															case 584:
																																																goto IL_2eea;
																																															case 446:
																																																goto IL_2f29;
																																															case 170:
																																																goto IL_2f3c;
																																															case 1058:
																																																goto IL_2f4a;
																																															case 340:
																																															case 1100:
																																																goto IL_2f58;
																																															case 332:
																																																goto IL_2f98;
																																															case 443:
																																																goto IL_2fac;
																																															case 727:
																																																goto IL_2fc8;
																																															case 7:
																																																goto IL_2fd6;
																																															case 48:
																																															case 797:
																																																goto IL_2fe1;
																																															case 719:
																																																goto IL_2fff;
																																															case 988:
																																																goto IL_300d;
																																															case 311:
																																																goto IL_301b;
																																															case 714:
																																																goto IL_302e;
																																															case 106:
																																																goto IL_303c;
																																															case 997:
																																																goto IL_3047;
																																															case 263:
																																																goto IL_3055;
																																															case 478:
																																															case 583:
																																																goto IL_3063;
																																															case 442:
																																																goto IL_3071;
																																															case 347:
																																																goto IL_308f;
																																															case 1089:
																																																goto IL_309d;
																																															case 927:
																																															case 1227:
																																																goto IL_30b0;
																																															case 850:
																																																goto IL_30d2;
																																															case 88:
																																																goto IL_30e5;
																																															case 135:
																																																goto IL_30f0;
																																															case 161:
																																															case 768:
																																																goto IL_30fe;
																																															case 114:
																																																goto IL_3117;
																																															case 844:
																																																goto IL_3125;
																																															case 692:
																																															case 1156:
																																																goto IL_3133;
																																															case 498:
																																																goto IL_317c;
																																															case 288:
																																																goto IL_3190;
																																															case 425:
																																																goto IL_31a3;
																																															case 213:
																																																goto IL_31b1;
																																															case 146:
																																															case 778:
																																																goto IL_31bc;
																																															case 1190:
																																																goto IL_31d0;
																																															case 451:
																																																goto IL_320e;
																																															case 110:
																																																goto IL_3221;
																																															case 82:
																																																goto IL_322f;
																																															case 666:
																																															case 1234:
																																																goto IL_323d;
																																															case 648:
																																																goto IL_3260;
																																															case 1072:
																																																goto IL_326e;
																																															case 888:
																																																goto IL_327c;
																																															case 1079:
																																																goto IL_328f;
																																															case 431:
																																																goto IL_329a;
																																															case 623:
																																															case 756:
																																																goto IL_32a8;
																																															case 647:
																																																goto IL_32e6;
																																															case 465:
																																																goto IL_32f4;
																																															case 198:
																																																goto IL_3307;
																																															case 372:
																																																goto IL_331e;
																																															case 966:
																																															case 1104:
																																																goto IL_332c;
																																															case 452:
																																																goto IL_3340;
																																															case 527:
																																																goto IL_3388;
																																															case 1097:
																																															case 1257:
																																																goto IL_339b;
																																															case 378:
																																																goto IL_33bf;
																																															case 486:
																																																goto IL_33cd;
																																															case 840:
																																																goto IL_33db;
																																															case 142:
																																															case 1260:
																																																goto IL_33ee;
																																															case 57:
																																																goto IL_340c;
																																															case 854:
																																																goto IL_341a;
																																															case 1143:
																																																goto IL_3428;
																																															case 356:
																																															case 1263:
																																																goto IL_343b;
																																															case 1111:
																																																goto IL_3455;
																																															case 282:
																																															case 1265:
																																																goto IL_3468;
																																															case 1071:
																																																goto IL_34a8;
																																															case 829:
																																																goto IL_34bc;
																																															case 1267:
																																																goto IL_34d8;
																																															case 241:
																																																goto IL_34e6;
																																															case 1271:
																																																goto IL_3502;
																																															case 173:
																																																goto IL_3541;
																																															case 1277:
																																																goto IL_3554;
																																															case 61:
																																															case 1099:
																																																goto IL_3562;
																																															case 582:
																																																goto IL_3576;
																																															case 1056:
																																																goto IL_35b5;
																																															case 180:
																																															case 1283:
																																																goto IL_35c8;
																																															case 103:
																																																goto IL_35f3;
																																															case 129:
																																															case 1284:
																																																goto IL_360c;
																																															case 945:
																																																goto IL_3635;
																																															case 474:
																																																goto IL_3643;
																																															case 866:
																																																goto IL_3669;
																																															case 905:
																																																goto IL_3677;
																																															case 368:
																																															case 571:
																																																goto IL_3682;
																																															case 521:
																																																goto IL_36a6;
																																															case 744:
																																																goto IL_36b4;
																																															case 1086:
																																																goto IL_36cb;
																																															case 741:
																																																goto IL_36de;
																																															case 1261:
																																																goto IL_36ec;
																																															case 1026:
																																															case 1210:
																																																goto IL_36fa;
																																															case 759:
																																																goto IL_3718;
																																															case 941:
																																																goto IL_3726;
																																															case 509:
																																																goto IL_3734;
																																															case 227:
																																																goto IL_3747;
																																															case 20:
																																																goto IL_3752;
																																															case 15:
																																															case 725:
																																																goto IL_3760;
																																															case 8:
																																																goto IL_376a;
																																															case 79:
																																																goto IL_3778;
																																															case 252:
																																																goto IL_378b;
																																															case 569:
																																																goto IL_37a2;
																																															case 188:
																																															case 1220:
																																																goto IL_37b0;
																																															case 614:
																																																goto IL_37c4;
																																															case 11:
																																																goto IL_3811;
																																															case 1049:
																																																goto IL_381f;
																																															case 1160:
																																																goto IL_3832;
																																															case 658:
																																																goto IL_3840;
																																															case 193:
																																															case 244:
																																																goto IL_3854;
																																															case 925:
																																																goto IL_386d;
																																															case 287:
																																																goto IL_3880;
																																															case 211:
																																																goto IL_388e;
																																															case 1003:
																																															case 1237:
																																																goto IL_389c;
																																															case 587:
																																																goto IL_38b0;
																																															case 77:
																																																goto IL_3902;
																																															case 72:
																																																goto IL_3910;
																																															case 823:
																																																goto IL_3923;
																																															case 1136:
																																																goto IL_3931;
																																															case 31:
																																																goto IL_393f;
																																															case 433:
																																															case 901:
																																																goto IL_3953;
																																															case 677:
																																																goto IL_3961;
																																															case 1269:
																																																goto IL_3985;
																																															case 268:
																																																goto IL_3993;
																																															case 728:
																																																goto IL_39a6;
																																															case 186:
																																																goto IL_39b4;
																																															case 398:
																																																goto IL_39c2;
																																															case 849:
																																																goto IL_39d0;
																																															case 73:
																																															case 108:
																																																goto IL_39de;
																																															case 281:
																																																goto IL_39f2;
																																															case 327:
																																																goto IL_3a31;
																																															case 693:
																																																goto IL_3a4d;
																																															case 284:
																																															case 1122:
																																																goto IL_3a5b;
																																															case 909:
																																																goto IL_3a7d;
																																															case 1241:
																																																goto IL_3a90;
																																															case 675:
																																															case 982:
																																																goto IL_3a9e;
																																															case 407:
																																																goto IL_3ab2;
																																															case 1148:
																																																goto IL_3b03;
																																															case 544:
																																																goto IL_3b11;
																																															case 1245:
																																																goto IL_3b24;
																																															case 1183:
																																																goto IL_3b32;
																																															case 545:
																																															case 1233:
																																																goto IL_3b40;
																																															case 265:
																																																goto IL_3b54;
																																															case 968:
																																																goto IL_3bbc;
																																															case 420:
																																																goto IL_3bca;
																																															case 208:
																																																goto IL_3bdd;
																																															case 893:
																																																goto IL_3beb;
																																															case 699:
																																															case 991:
																																																goto IL_3bf6;
																																															case 228:
																																																goto IL_3c04;
																																															case 983:
																																																goto IL_3c28;
																																															case 749:
																																																goto IL_3c36;
																																															case 529:
																																																goto IL_3c49;
																																															case 803:
																																																goto IL_3c57;
																																															case 17:
																																															case 210:
																																																goto IL_3c65;
																																															case 256:
																																																goto IL_3c7d;
																																															case 1011:
																																																goto IL_3c8b;
																																															case 302:
																																																goto IL_3c99;
																																															case 513:
																																																goto IL_3cac;
																																															case 912:
																																																goto IL_3cb7;
																																															case 85:
																																															case 911:
																																																goto IL_3cc5;
																																															case 605:
																																																goto IL_3cf3;
																																															case 166:
																																																goto IL_3d06;
																																															case 1142:
																																																goto IL_3d14;
																																															case 162:
																																															case 1073:
																																																goto IL_3d22;
																																															case 1070:
																																																goto IL_3d45;
																																															case 1110:
																																																goto IL_3d53;
																																															case 360:
																																																goto IL_3d61;
																																															case 981:
																																																goto IL_3d7d;
																																															case 802:
																																																goto IL_3d8b;
																																															case 1054:
																																																goto IL_3d99;
																																															case 700:
																																															case 1229:
																																																goto IL_3da4;
																																															case 596:
																																																goto IL_3dc7;
																																															case 1172:
																																																goto IL_3dd5;
																																															case 626:
																																																goto IL_3de3;
																																															case 1199:
																																																goto IL_3df6;
																																															case 921:
																																																goto IL_3e04;
																																															case 764:
																																															case 807:
																																																goto IL_3e0f;
																																															case 522:
																																																goto IL_3e24;
																																															case 95:
																																																goto IL_3e37;
																																															case 953:
																																																goto IL_3e4e;
																																															case 488:
																																															case 632:
																																																goto IL_3e5c;
																																															case 299:
																																																goto IL_3e80;
																																															case 309:
																																																goto IL_3e8e;
																																															case 160:
																																																goto IL_3e9c;
																																															case 83:
																																																goto IL_3eaf;
																																															case 187:
																																																goto IL_3ebd;
																																															case 366:
																																															case 792:
																																																goto IL_3ecb;
																																															case 1232:
																																																goto IL_3ef7;
																																															case 1270:
																																																goto IL_3f05;
																																															case 156:
																																																goto IL_3f13;
																																															case 910:
																																																goto IL_3f26;
																																															case 385:
																																																goto IL_3f34;
																																															case 109:
																																															case 914:
																																																goto IL_3f42;
																																															case 758:
																																																goto IL_3f56;
																																															case 1009:
																																																goto IL_3fb1;
																																															case 858:
																																																goto IL_3fbf;
																																															case 1214:
																																																goto IL_3fd2;
																																															case 691:
																																																goto IL_3fe0;
																																															case 894:
																																															case 1226:
																																																goto IL_3fee;
																																															case 646:
																																																goto IL_4012;
																																															case 1164:
																																																goto IL_4020;
																																															case 1201:
																																																goto IL_402e;
																																															case 1041:
																																																goto IL_4041;
																																															case 765:
																																																goto IL_404f;
																																															case 884:
																																															case 915:
																																																goto IL_405d;
																																															case 746:
																																																goto IL_4071;
																																															case 1:
																																																goto IL_40c2;
																																															case 1005:
																																																goto IL_40d0;
																																															case 305:
																																																goto IL_40ec;
																																															case 194:
																																																goto IL_40fa;
																																															case 867:
																																															case 980:
																																																goto IL_4108;
																																															case 845:
																																																goto IL_4121;
																																															case 262:
																																															case 447:
																																																goto IL_4134;
																																															case 179:
																																																goto IL_4151;
																																															case 468:
																																																goto IL_418e;
																																															case 428:
																																																goto IL_41a1;
																																															case 130:
																																																goto IL_41af;
																																															case 141:
																																															case 704:
																																																goto IL_41bd;
																																															case 698:
																																																goto IL_41d1;
																																															case 51:
																																																goto IL_422d;
																																															case 50:
																																																goto IL_423b;
																																															case 757:
																																																goto IL_424e;
																																															case 1002:
																																																goto IL_425c;
																																															case 818:
																																															case 1085:
																																																goto IL_4267;
																																															case 743:
																																																goto IL_428a;
																																															case 1045:
																																																goto IL_4298;
																																															case 1228:
																																																goto IL_42a6;
																																															case 871:
																																																goto IL_42b9;
																																															case 2:
																																																goto IL_42c4;
																																															case 219:
																																																goto IL_42cf;
																																															case 793:
																																															case 1083:
																																																goto IL_42dd;
																																															case 531:
																																																goto IL_42f9;
																																															case 875:
																																																goto IL_4307;
																																															case 123:
																																															case 457:
																																																goto IL_4315;
																																															case 557:
																																																goto IL_432a;
																																															case 1274:
																																																goto IL_433d;
																																															case 144:
																																															case 549:
																																																goto IL_4348;
																																															case 26:
																																																goto IL_4361;
																																															case 961:
																																																goto IL_4374;
																																															case 1119:
																																																goto IL_4382;
																																															case 1039:
																																															case 1223:
																																																goto IL_4390;
																																															case 1082:
																																																goto IL_43aa;
																																															case 1212:
																																																goto IL_43bd;
																																															case 312:
																																																goto IL_43cb;
																																															case 304:
																																																goto IL_43d6;
																																															case 1163:
																																															case 1211:
																																																goto IL_43e4;
																																															case 217:
																																																goto IL_4438;
																																															case 919:
																																																goto IL_444b;
																																															case 892:
																																																goto IL_4459;
																																															case 122:
																																															case 753:
																																																goto IL_4467;
																																															case 1197:
																																																goto IL_448a;
																																															case 200:
																																																goto IL_4498;
																																															case 151:
																																																goto IL_44a6;
																																															case 1135:
																																																goto IL_44c2;
																																															case 418:
																																																goto IL_44cd;
																																															case 656:
																																																goto IL_44db;
																																															case 918:
																																															case 1051:
																																																goto IL_44e9;
																																															case 482:
																																																goto IL_4502;
																																															case 47:
																																															case 1200:
																																																goto IL_4515;
																																															case 1166:
																																																goto IL_4533;
																																															case 943:
																																																goto IL_4541;
																																															case 607:
																																																goto IL_454f;
																																															case 232:
																																																goto IL_456b;
																																															case 642:
																																																goto IL_4579;
																																															case 23:
																																															case 1080:
																																																goto IL_4584;
																																															case 827:
																																																goto IL_4598;
																																															case 76:
																																																goto IL_45d0;
																																															case 400:
																																																goto IL_45e3;
																																															case 339:
																																																goto IL_45f1;
																																															case 832:
																																															case 944:
																																																goto IL_45fc;
																																															case 296:
																																																goto IL_4610;
																																															case 671:
																																																goto IL_464f;
																																															case 998:
																																																goto IL_466b;
																																															case 139:
																																																goto IL_4679;
																																															case 364:
																																															case 970:
																																																goto IL_4690;
																																															case 1025:
																																																goto IL_46aa;
																																															case 70:
																																																goto IL_46bd;
																																															case 471:
																																																goto IL_46cb;
																																															case 735:
																																																goto IL_46e2;
																																															case 487:
																																															case 592:
																																																goto IL_46f0;
																																															case 333:
																																																goto IL_4728;
																																															case 1280:
																																																goto IL_4745;
																																															case 723:
																																																goto IL_4761;
																																															case 872:
																																															case 1048:
																																																goto IL_476f;
																																															case 293:
																																																goto IL_477d;
																																															case 1117:
																																																goto IL_479b;
																																															case 1064:
																																																goto IL_47a9;
																																															case 924:
																																																goto IL_47bc;
																																															case 774:
																																																goto IL_47ca;
																																															case 6:
																																															case 641:
																																																goto IL_47d5;
																																															case 938:
																																																goto IL_47e3;
																																															case 1188:
																																																goto IL_4801;
																																															case 763:
																																																goto IL_480f;
																																															case 534:
																																																goto IL_4822;
																																															case 877:
																																																goto IL_4830;
																																															case 826:
																																															case 1250:
																																																goto IL_483e;
																																															case 999:
																																																goto IL_4852;
																																															case 236:
																																																goto IL_488f;
																																															case 939:
																																																goto IL_48a2;
																																															case 1115:
																																																goto IL_48ad;
																																															case 811:
																																															case 1035:
																																																goto IL_48bb;
																																															case 1012:
																																																goto IL_48cf;
																																															case 519:
																																																goto IL_4907;
																																															case 773:
																																																goto IL_491a;
																																															case 337:
																																																goto IL_4928;
																																															case 315:
																																															case 891:
																																																goto IL_4936;
																																															case 71:
																																																goto IL_494a;
																																															case 620:
																																																goto IL_4987;
																																															case 56:
																																																goto IL_499a;
																																															case 649:
																																																goto IL_49a8;
																																															case 190:
																																															case 1208:
																																																goto IL_49b3;
																																															case 1278:
																																																goto IL_49c7;
																																															case 806:
																																																goto IL_4a0f;
																																															case 1141:
																																																goto IL_4a1d;
																																															case 1219:
																																																goto IL_4a30;
																																															case 985:
																																																goto IL_4a3e;
																																															case 672:
																																															case 777:
																																																goto IL_4a49;
																																															case 414:
																																																goto IL_4a81;
																																															case 881:
																																																goto IL_4a95;
																																															case 247:
																																																goto IL_4aa8;
																																															case 959:
																																																goto IL_4ab6;
																																															case 120:
																																															case 381:
																																																goto IL_4ac4;
																																															case 696:
																																																goto IL_4ad8;
																																															case 69:
																																																goto IL_4b29;
																																															case 651:
																																																goto IL_4b37;
																																															case 510:
																																																goto IL_4b4a;
																																															case 389:
																																																goto IL_4b58;
																																															case 497:
																																															case 1075:
																																																goto IL_4b63;
																																															case 136:
																																																goto IL_4b81;
																																															case 908:
																																																goto IL_4b8f;
																																															case 349:
																																																goto IL_4ba6;
																																															case 321:
																																																goto IL_4bb9;
																																															case 178:
																																																goto IL_4bc7;
																																															case 432:
																																															case 490:
																																																goto IL_4bd5;
																																															case 403:
																																																goto IL_4bee;
																																															case 220:
																																																goto IL_4c01;
																																															case 963:
																																																goto IL_4c0c;
																																															case 63:
																																															case 115:
																																																goto IL_4c1a;
																																															case 1095:
																																																goto IL_4c3d;
																																															case 511:
																																																goto IL_4c4b;
																																															case 595:
																																																goto IL_4c59;
																																															case 564:
																																																goto IL_4c6c;
																																															case 253:
																																																goto IL_4c7a;
																																															case 767:
																																															case 1078:
																																																goto IL_4c88;
																																															case 1038:
																																																goto IL_4ca5;
																																															case 645:
																																																goto IL_4cf6;
																																															case 633:
																																																goto IL_4d04;
																																															case 717:
																																																goto IL_4d17;
																																															case 1186:
																																																goto IL_4d25;
																																															case 238:
																																															case 382:
																																																goto IL_4d30;
																																															case 643:
																																																goto IL_4d53;
																																															case 619:
																																																goto IL_4d61;
																																															case 883:
																																																goto IL_4d6f;
																																															case 1057:
																																																goto IL_4d82;
																																															case 1174:
																																																goto IL_4d90;
																																															case 285:
																																															case 523:
																																																goto IL_4d9e;
																																															case 920:
																																																goto IL_4db7;
																																															case 204:
																																																goto IL_4dca;
																																															case 556:
																																																goto IL_4dd8;
																																															case 535:
																																															case 846:
																																																goto IL_4de6;
																																															case 547:
																																																goto IL_4e03;
																																															case 60:
																																																goto IL_4e54;
																																															case 195:
																																																goto IL_4e62;
																																															case 1179:
																																																goto IL_4e75;
																																															case 536:
																																																goto IL_4e83;
																																															case 799:
																																															case 1184:
																																																goto IL_4e91;
																																															case 379:
																																																goto IL_4eaa;
																																															case 660:
																																																goto IL_4ebd;
																																															case 352:
																																																goto IL_4ecb;
																																															case 776:
																																															case 965:
																																																goto IL_4ed6;
																																															case 1262:
																																																goto IL_4ef4;
																																															case 543:
																																																goto IL_4f02;
																																															case 84:
																																																goto IL_4f10;
																																															case 1185:
																																																goto IL_4f23;
																																															case 469:
																																																goto IL_4f31;
																																															case 494:
																																																goto IL_4f3c;
																																															case 1150:
																																																goto IL_4f4a;
																																															case 215:
																																															case 313:
																																																goto IL_4f58;
																																															case 690:
																																																goto IL_4f81;
																																															case 775:
																																																goto IL_4f8f;
																																															case 554:
																																															case 578:
																																																goto IL_4fa2;
																																															case 1127:
																																																goto IL_4fb0;
																																															case 165:
																																																goto IL_4fdd;
																																															case 616:
																																																goto IL_4feb;
																																															case 520:
																																																goto IL_4ffe;
																																															case 49:
																																																goto IL_5009;
																																															case 65:
																																															case 1105:
																																																goto IL_5017;
																																															case 1146:
																																																goto IL_5055;
																																															case 819:
																																																goto IL_5069;
																																															case 137:
																																																goto IL_5085;
																																															case 1037:
																																																goto IL_5093;
																																															case 181:
																																															case 598:
																																																goto IL_50a1;
																																															case 786:
																																																goto IL_510f;
																																															case 681:
																																																goto IL_5122;
																																															case 359:
																																																goto IL_5130;
																																															case 1081:
																																															case 1158:
																																																goto IL_513b;
																																															case 1094:
																																																goto IL_514f;
																																															case 28:
																																																goto IL_518d;
																																															case 1074:
																																																goto IL_51a0;
																																															case 1109:
																																																goto IL_51ae;
																																															case 532:
																																															case 766:
																																																goto IL_51c5;
																																															case 936:
																																																goto IL_51e8;
																																															case 132:
																																																goto IL_51f6;
																																															case 1134:
																																																goto IL_5204;
																																															case 835:
																																																goto IL_5217;
																																															case 814:
																																																goto IL_5222;
																																															case 126:
																																															case 143:
																																																goto IL_5230;
																																															case 560:
																																																goto IL_5254;
																																															case 639:
																																																goto IL_5262;
																																															case 413:
																																																goto IL_5270;
																																															case 695:
																																																goto IL_5283;
																																															case 326:
																																																goto IL_5291;
																																															case 222:
																																															case 460:
																																																goto IL_52a8;
																																															case 283:
																																																goto IL_52bc;
																																															case 954:
																																																goto IL_5309;
																																															case 994:
																																																goto IL_5317;
																																															case 1116:
																																																goto IL_532a;
																																															case 54:
																																																goto IL_5338;
																																															case 861:
																																															case 1033:
																																																goto IL_5343;
																																															case 887:
																																																goto IL_5360;
																																															case 94:
																																																goto IL_539f;
																																															case 636:
																																																goto IL_53b2;
																																															case 176:
																																																goto IL_53c0;
																																															case 668:
																																																goto IL_53ce;
																																															case 1000:
																																															case 1154:
																																																goto IL_53d9;
																																															case 434:
																																																goto IL_5402;
																																															case 1217:
																																																goto IL_5424;
																																															case 922:
																																																goto IL_5432;
																																															case 540:
																																															case 1007:
																																																goto IL_5440;
																																															case 942:
																																																goto IL_5454;
																																															case 824:
																																																goto IL_5493;
																																															case 1275:
																																																goto IL_54af;
																																															case 1282:
																																																goto IL_54ba;
																																															case 392:
																																															case 1059:
																																																goto IL_54c8;
																																															case 1040:
																																																goto IL_54e5;
																																															case 610:
																																																goto IL_551d;
																																															case 274:
																																																goto IL_5530;
																																															case 585:
																																																goto IL_553e;
																																															case 393:
																																															case 1191:
																																																goto IL_554c;
																																															case 555:
																																																goto IL_558a;
																																															case 950:
																																																goto IL_559d;
																																															case 254:
																																															case 473:
																																																goto IL_55a8;
																																															case 134:
																																																goto IL_55bc;
																																															case 673:
																																																goto IL_55fb;
																																															case 145:
																																																goto end_IL_143f;
																																															case 599:
																																																goto IL_561c;
																																															case 35:
																																															case 1196:
																																																goto IL_5627;
																																															case 754:
																																																goto IL_5685;
																																															case 898:
																																																goto IL_5698;
																																															case 345:
																																																goto IL_56a6;
																																															case 206:
																																															case 1175:
																																																goto IL_56b4;
																																															case 629:
																																																goto IL_56c2;
																																															case 975:
																																																goto IL_56e6;
																																															case 836:
																																																goto IL_56f4;
																																															case 196:
																																																goto IL_5707;
																																															case 900:
																																																goto IL_5715;
																																															case 154:
																																															case 1198:
																																																goto IL_5723;
																																															case 1231:
																																																goto IL_5737;
																																															case 157:
																																																goto IL_5789;
																																															case 611:
																																																goto IL_5797;
																																															case 1181:
																																																goto IL_57aa;
																																															case 794:
																																																goto IL_57b8;
																																															case 597:
																																															case 747:
																																																goto IL_57c6;
																																															case 295:
																																																goto IL_57fe;
																																															case 383:
																																																goto IL_5812;
																																															case 384:
																																																goto IL_5825;
																																															case 581:
																																																goto IL_5833;
																																															case 279:
																																															case 1281:
																																																goto IL_583e;
																																															case 709:
																																																goto IL_5852;
																																															case 237:
																																																goto IL_5891;
																																															case 842:
																																																goto IL_58a4;
																																															case 601:
																																																goto IL_58b2;
																																															case 257:
																																															case 752:
																																																goto IL_58bd;
																																															case 1008:
																																																goto IL_58d1;
																																															case 1248:
																																																goto IL_5909;
																																															case 1128:
																																																goto IL_591c;
																																															case 150:
																																																goto IL_592a;
																																															case 387:
																																															case 859:
																																																goto IL_5938;
																																															case 724:
																																																goto IL_594c;
																																															case 1144:
																																																goto IL_598b;
																																															case 787:
																																																goto IL_599e;
																																															case 1016:
																																																goto IL_59a9;
																																															case 1047:
																																															case 1157:
																																																goto IL_59b7;
																																															case 508:
																																																goto IL_59f5;
																																															case 769:
																																																goto IL_5a11;
																																															case 1065:
																																																goto IL_5a28;
																																															case 53:
																																															case 589:
																																																goto IL_5a36;
																																															case 512:
																																																goto IL_5a4a;
																																															case 591:
																																																goto IL_5a89;
																																															case 448:
																																																goto IL_5a9c;
																																															case 1021:
																																																goto IL_5aaa;
																																															case 453:
																																															case 734:
																																																goto IL_5ab5;
																																															case 615:
																																																goto IL_5ac9;
																																															case 1206:
																																																goto IL_5b08;
																																															case 627:
																																																goto IL_5b1b;
																																															case 1036:
																																																goto IL_5b29;
																																															case 231:
																																															case 809:
																																																goto IL_5b37;
																																															case 730:
																																																goto IL_5b4b;
																																															case 12:
																																																goto IL_5bcf;
																																															case 710:
																																																goto IL_5bdd;
																																															case 576:
																																																goto IL_5bf0;
																																															case 795:
																																																goto IL_5bfb;
																																															case 102:
																																															case 889:
																																																goto IL_5c09;
																																															case 455:
																																																goto IL_5c47;
																																															case 653:
																																																goto IL_5c5e;
																																															case 318:
																																																goto IL_5c6e;
																																															case 514:
																																																goto IL_5c79;
																																															case 25:
																																															case 30:
																																															case 33:
																																															case 34:
																																															case 38:
																																															case 43:
																																															case 52:
																																															case 97:
																																															case 98:
																																															case 101:
																																															case 125:
																																															case 148:
																																															case 158:
																																															case 164:
																																															case 169:
																																															case 182:
																																															case 191:
																																															case 199:
																																															case 201:
																																															case 205:
																																															case 216:
																																															case 230:
																																															case 233:
																																															case 246:
																																															case 248:
																																															case 250:
																																															case 264:
																																															case 275:
																																															case 277:
																																															case 294:
																																															case 297:
																																															case 300:
																																															case 310:
																																															case 330:
																																															case 338:
																																															case 350:
																																															case 374:
																																															case 388:
																																															case 397:
																																															case 406:
																																															case 408:
																																															case 415:
																																															case 417:
																																															case 419:
																																															case 421:
																																															case 424:
																																															case 429:
																																															case 438:
																																															case 454:
																																															case 456:
																																															case 458:
																																															case 463:
																																															case 476:
																																															case 480:
																																															case 496:
																																															case 502:
																																															case 504:
																																															case 516:
																																															case 525:
																																															case 526:
																																															case 530:
																																															case 533:
																																															case 537:
																																															case 538:
																																															case 570:
																																															case 572:
																																															case 577:
																																															case 579:
																																															case 588:
																																															case 608:
																																															case 609:
																																															case 622:
																																															case 624:
																																															case 644:
																																															case 652:
																																															case 654:
																																															case 655:
																																															case 664:
																																															case 665:
																																															case 667:
																																															case 674:
																																															case 680:
																																															case 686:
																																															case 689:
																																															case 703:
																																															case 705:
																																															case 707:
																																															case 708:
																																															case 711:
																																															case 713:
																																															case 716:
																																															case 718:
																																															case 722:
																																															case 729:
																																															case 732:
																																															case 738:
																																															case 745:
																																															case 748:
																																															case 760:
																																															case 762:
																																															case 772:
																																															case 791:
																																															case 798:
																																															case 804:
																																															case 833:
																																															case 834:
																																															case 841:
																																															case 852:
																																															case 860:
																																															case 869:
																																															case 876:
																																															case 879:
																																															case 885:
																																															case 886:
																																															case 899:
																																															case 902:
																																															case 903:
																																															case 913:
																																															case 930:
																																															case 931:
																																															case 932:
																																															case 933:
																																															case 940:
																																															case 949:
																																															case 960:
																																															case 972:
																																															case 974:
																																															case 976:
																																															case 978:
																																															case 1004:
																																															case 1017:
																																															case 1027:
																																															case 1028:
																																															case 1084:
																																															case 1088:
																																															case 1091:
																																															case 1096:
																																															case 1102:
																																															case 1106:
																																															case 1107:
																																															case 1124:
																																															case 1125:
																																															case 1130:
																																															case 1132:
																																															case 1168:
																																															case 1176:
																																															case 1182:
																																															case 1193:
																																															case 1194:
																																															case 1195:
																																															case 1218:
																																															case 1225:
																																															case 1240:
																																															case 1243:
																																															case 1244:
																																															case 1249:
																																															case 1256:
																																															case 1258:
																																															case 1273:
																																																goto end_IL_14b2;
																																															case 0:
																																															case 3:
																																															case 4:
																																															case 10:
																																															case 13:
																																															case 22:
																																															case 32:
																																															case 37:
																																															case 45:
																																															case 46:
																																															case 55:
																																															case 58:
																																															case 62:
																																															case 64:
																																															case 75:
																																															case 81:
																																															case 89:
																																															case 91:
																																															case 92:
																																															case 104:
																																															case 113:
																																															case 119:
																																															case 149:
																																															case 163:
																																															case 202:
																																															case 207:
																																															case 214:
																																															case 221:
																																															case 224:
																																															case 242:
																																															case 243:
																																															case 249:
																																															case 259:
																																															case 260:
																																															case 266:
																																															case 267:
																																															case 278:
																																															case 290:
																																															case 291:
																																															case 303:
																																															case 306:
																																															case 316:
																																															case 322:
																																															case 329:
																																															case 334:
																																															case 354:
																																															case 355:
																																															case 358:
																																															case 363:
																																															case 370:
																																															case 399:
																																															case 404:
																																															case 412:
																																															case 435:
																																															case 437:
																																															case 440:
																																															case 441:
																																															case 444:
																																															case 472:
																																															case 479:
																																															case 485:
																																															case 491:
																																															case 500:
																																															case 505:
																																															case 515:
																																															case 518:
																																															case 539:
																																															case 542:
																																															case 548:
																																															case 553:
																																															case 562:
																																															case 565:
																																															case 568:
																																															case 573:
																																															case 580:
																																															case 586:
																																															case 593:
																																															case 602:
																																															case 604:
																																															case 618:
																																															case 621:
																																															case 630:
																																															case 634:
																																															case 635:
																																															case 638:
																																															case 640:
																																															case 679:
																																															case 683:
																																															case 685:
																																															case 701:
																																															case 715:
																																															case 720:
																																															case 740:
																																															case 742:
																																															case 750:
																																															case 755:
																																															case 770:
																																															case 771:
																																															case 784:
																																															case 821:
																																															case 831:
																																															case 837:
																																															case 847:
																																															case 853:
																																															case 873:
																																															case 878:
																																															case 880:
																																															case 882:
																																															case 890:
																																															case 929:
																																															case 935:
																																															case 946:
																																															case 947:
																																															case 951:
																																															case 952:
																																															case 964:
																																															case 979:
																																															case 989:
																																															case 1010:
																																															case 1022:
																																															case 1024:
																																															case 1030:
																																															case 1044:
																																															case 1052:
																																															case 1053:
																																															case 1055:
																																															case 1060:
																																															case 1062:
																																															case 1063:
																																															case 1066:
																																															case 1114:
																																															case 1118:
																																															case 1121:
																																															case 1126:
																																															case 1133:
																																															case 1145:
																																															case 1147:
																																															case 1161:
																																															case 1162:
																																															case 1169:
																																															case 1202:
																																															case 1203:
																																															case 1207:
																																															case 1221:
																																															case 1222:
																																															case 1230:
																																															case 1235:
																																															case 1236:
																																															case 1238:
																																															case 1239:
																																															case 1253:
																																															case 1259:
																																															case 1264:
																																															case 1266:
																																															case 1268:
																																															case 1272:
																																															case 1279:
																																															case 1285:
																																																goto IL_5ca0;
																																															case 308:
																																																goto IL_5cb3;
																																															case 678:
																																																goto IL_5cbe;
																																															case 348:
																																																goto IL_5cc8;
																																															case 44:
																																																goto IL_5cd3;
																																															case 128:
																																																goto IL_5ce3;
																																															case 612:
																																																goto IL_5cf3;
																																															case 594:
																																																goto IL_5d0c;
																																															case 733:
																																																goto IL_5d1c;
																																															case 331:
																																																goto IL_5d2c;
																																															case 16:
																																																goto IL_5d3c;
																																															case 240:
																																																goto IL_5d4c;
																																															case 342:
																																																goto IL_5d5c;
																																															case 183:
																																																goto IL_5d6c;
																																															case 436:
																																															case 848:
																																																return;
																																															}
																																															goto end_IL_1572;
																																														}
																																														ptr2 += 8;
																																														goto IL_5ca0;
																																														continue;
																																														end_IL_143f:
																																														break;
																																													}
																																													break;
																																												}
																																												break;
																																											}
																																											goto IL_560e;
																																											continue;
																																											end_IL_14b2:
																																											break;
																																											IL_14b2:;
																																										}
																																										break;
																																										IL_14c2:;
																																									}
																																									break;
																																								}
																																								goto IL_15bb;
																																								IL_3455:
																																								num6--;
																																								goto IL_5ca0;
																																								IL_15bb:
																																								if (71 > b)
																																								{
																																									break;
																																								}
																																								goto IL_343b;
																																								IL_343b:
																																								global::_003CModule_003E.float_95 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																								goto IL_3455;
																																							}
																																							break;
																																						}
																																						goto IL_19e2;
																																						IL_213f:
																																						array2[num6] = 0;
																																						goto IL_214d;
																																						IL_19e2:
																																						if (70 <= b)
																																						{
																																							goto IL_19ed;
																																						}
																																						goto IL_1a31;
																																						IL_19ed:
																																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (float)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																						goto IL_1a18;
																																						IL_1a18:
																																						array2[num6 - 1] = 3;
																																						goto IL_5ca0;
																																						IL_1a31:
																																						if (69 < b)
																																						{
																																							break;
																																						}
																																						num = 492;
																																						goto IL_1a48;
																																						IL_214d:
																																						num6++;
																																						goto IL_215b;
																																						IL_1a48:
																																						if (69 > b)
																																						{
																																							break;
																																						}
																																						num = 395;
																																						goto IL_211b;
																																						IL_215b:
																																						ptr2 += 8;
																																						goto IL_5ca0;
																																						IL_211b:
																																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																																						goto IL_213f;
																																					}
																																					break;
																																				}
																																				goto IL_159d;
																																				IL_1c18:
																																				num6--;
																																				goto IL_5ca0;
																																				IL_159d:
																																				global::_003CModule_003E.list_13 = (List<long>)array3[num6 - 1];
																																				goto IL_1c18;
																																			}
																																			break;
																																		}
																																		goto IL_3669;
																																		IL_3811:
																																		num6--;
																																		goto IL_381f;
																																		IL_3669:
																																		if (75 >= b)
																																		{
																																			goto IL_3677;
																																		}
																																		goto IL_3747;
																																		IL_3677:
																																		if (75 <= b)
																																		{
																																			goto IL_3682;
																																		}
																																		goto IL_36de;
																																		IL_3682:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																																		goto IL_36a6;
																																		IL_36a6:
																																		array2[num6] = 0;
																																		goto IL_36b4;
																																		IL_36b4:
																																		num6++;
																																		num = 1086;
																																		goto IL_36cb;
																																		IL_36cb:
																																		ptr2 += 8;
																																		goto IL_5ca0;
																																		IL_36de:
																																		if (74 < b)
																																		{
																																			break;
																																		}
																																		goto IL_36ec;
																																		IL_36ec:
																																		if (74 > b)
																																		{
																																			break;
																																		}
																																		goto IL_36fa;
																																		IL_36fa:
																																		array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																																		goto IL_3718;
																																		IL_3718:
																																		array2[num6] = 5;
																																		goto IL_3726;
																																		IL_3726:
																																		num6++;
																																		goto IL_3734;
																																		IL_3734:
																																		ptr2 += 8;
																																		goto IL_5ca0;
																																		IL_3747:
																																		if (76 >= b)
																																		{
																																			goto IL_3752;
																																		}
																																		goto IL_378b;
																																		IL_3752:
																																		if (76 > b)
																																		{
																																			break;
																																		}
																																		goto IL_3760;
																																		IL_3760:
																																		array3[num6] = null;
																																		goto IL_376a;
																																		IL_376a:
																																		array2[num6] = 5;
																																		goto IL_3778;
																																		IL_3778:
																																		num6++;
																																		goto IL_5ca0;
																																		IL_378b:
																																		if (77 < b)
																																		{
																																			break;
																																		}
																																		num = 569;
																																		goto IL_37a2;
																																		IL_381f:
																																		ptr2 += 8;
																																		goto IL_5ca0;
																																		IL_37a2:
																																		if (77 > b)
																																		{
																																			break;
																																		}
																																		goto IL_37b0;
																																		IL_37b0:
																																		array2[num6 - 2] = 0;
																																		goto IL_37c4;
																																		IL_37c4:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(GameEntityManager)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																																		goto IL_3811;
																																	}
																																	break;
																																}
																																goto IL_15ce;
																																IL_1ee1:
																																num6++;
																																goto IL_1eef;
																																IL_15ce:
																																if (68 <= b)
																																{
																																	goto IL_15d9;
																																}
																																goto IL_1606;
																																IL_15d9:
																																global::_003CModule_003E.int_202 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_15f3;
																																IL_15f3:
																																num6--;
																																goto IL_5ca0;
																																IL_1606:
																																if (63 >= b)
																																{
																																	goto IL_1611;
																																}
																																goto IL_162f;
																																IL_1611:
																																if (63 > b)
																																{
																																	goto IL_161c;
																																}
																																goto IL_163f;
																																IL_161c:
																																if (60 >= b)
																																{
																																	goto IL_1fd4;
																																}
																																goto IL_294b;
																																IL_1fd4:
																																if (60 <= b)
																																{
																																	goto IL_1fdf;
																																}
																																goto IL_2045;
																																IL_1fdf:
																																array2[num6 - 1] = 3;
																																goto IL_1ff3;
																																IL_1ff3:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																goto IL_2032;
																																IL_2032:
																																ptr2 += 8;
																																goto IL_5ca0;
																																IL_2045:
																																if (59 < b)
																																{
																																	break;
																																}
																																goto IL_2053;
																																IL_2053:
																																if (59 > b)
																																{
																																	break;
																																}
																																goto IL_2061;
																																IL_2061:
																																array2[num6] = 0;
																																goto IL_206f;
																																IL_206f:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																goto IL_2093;
																																IL_2093:
																																num6++;
																																goto IL_20a1;
																																IL_20a1:
																																ptr2 += 8;
																																goto IL_5ca0;
																																IL_294b:
																																if (61 >= b)
																																{
																																	goto IL_2956;
																																}
																																goto IL_29af;
																																IL_2956:
																																if (61 > b)
																																{
																																	break;
																																}
																																goto IL_2964;
																																IL_2964:
																																array2[num6] = 15;
																																goto IL_2972;
																																IL_2972:
																																array4[num6] = *(int*)(ptr2 + num3);
																																num = 1187;
																																goto IL_298e;
																																IL_298e:
																																ptr2 += 8;
																																goto IL_299c;
																																IL_299c:
																																num6++;
																																goto IL_5ca0;
																																IL_29af:
																																if (62 < b)
																																{
																																	break;
																																}
																																goto IL_3554;
																																IL_3554:
																																if (62 > b)
																																{
																																	break;
																																}
																																goto IL_3562;
																																IL_3562:
																																array2[num6 - 1] = 3;
																																goto IL_3576;
																																IL_3576:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																goto IL_35b5;
																																IL_35b5:
																																ptr2 += 8;
																																goto IL_5ca0;
																																IL_163f:
																																global::_003CModule_003E.list_12 = (List<int>)array3[num6 - 1];
																																goto IL_166d;
																																IL_166d:
																																num6--;
																																goto IL_5ca0;
																																IL_162f:
																																if (65 < b)
																																{
																																	goto IL_1680;
																																}
																																goto IL_1d56;
																																IL_1d56:
																																if (65 <= b)
																																{
																																	goto IL_1d61;
																																}
																																goto IL_1d8d;
																																IL_1d61:
																																global::_003CModule_003E.oCPITugY_007B_002D = (List<int>)array3[num6 - 1];
																																goto IL_1d7a;
																																IL_1d7a:
																																num6--;
																																goto IL_5ca0;
																																IL_1d8d:
																																if (64 < b)
																																{
																																	break;
																																}
																																goto IL_1d9b;
																																IL_1d9b:
																																if (64 > b)
																																{
																																	break;
																																}
																																num = 68;
																																goto IL_1db2;
																																IL_1eef:
																																ptr2 += 8;
																																goto IL_5ca0;
																																IL_1db2:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_1eba;
																																IL_1eba:
																																array2[num6 - 1] = 0;
																																goto IL_5ca0;
																																IL_1680:
																																if (66 < b)
																																{
																																	goto IL_168b;
																																}
																																goto IL_16ac;
																																IL_168b:
																																if (67 < b)
																																{
																																	break;
																																}
																																goto IL_1699;
																																IL_1699:
																																if (67 > b)
																																{
																																	break;
																																}
																																goto IL_35c8;
																																IL_35c8:
																																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_35f3;
																																IL_35f3:
																																array2[num6 - 1] = 1;
																																goto IL_5ca0;
																																IL_16ac:
																																if (66 > b)
																																{
																																	break;
																																}
																																goto IL_1a64;
																																IL_1a64:
																																array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																																goto IL_1ed3;
																																IL_1ed3:
																																array2[num6] = 5;
																																goto IL_1ee1;
																															}
																															break;
																														}
																														goto IL_165a;
																														IL_291e:
																														global::_003CModule_003E.int_201 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_2938;
																														IL_165a:
																														if (58 > b)
																														{
																															goto IL_183c;
																														}
																														goto IL_29c2;
																														IL_29c2:
																														((delegate*<ref Vector3, float, float, float, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)getUIContextReturnType[array4[num6 - 4]])(array3[num6 - 4], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), array7, array5), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																														goto IL_2a5c;
																														IL_2a5c:
																														num6 -= 4;
																														goto IL_2a6a;
																														IL_2a6a:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_183c:
																														if (48 >= b)
																														{
																															goto IL_184a;
																														}
																														goto IL_1900;
																														IL_184a:
																														if (48 > b)
																														{
																															goto IL_1858;
																														}
																														goto IL_23b6;
																														IL_1858:
																														if (43 >= b)
																														{
																															goto IL_1866;
																														}
																														goto IL_21f5;
																														IL_1866:
																														if (43 > b)
																														{
																															goto IL_1874;
																														}
																														goto IL_20b4;
																														IL_1874:
																														if (41 >= b)
																														{
																															goto IL_187f;
																														}
																														goto IL_18ae;
																														IL_187f:
																														if (41 > b)
																														{
																															goto IL_188d;
																														}
																														goto IL_1f68;
																														IL_188d:
																														if (40 < b)
																														{
																															break;
																														}
																														goto IL_189b;
																														IL_189b:
																														if (40 > b)
																														{
																															break;
																														}
																														goto IL_339b;
																														IL_339b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																														goto IL_33bf;
																														IL_33bf:
																														array2[num6] = 0;
																														goto IL_33cd;
																														IL_33cd:
																														num6++;
																														goto IL_33db;
																														IL_33db:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_1f68:
																														array2[num6 - 2] = 0;
																														goto IL_1f7c;
																														IL_1f7c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, int, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_2497;
																														IL_2497:
																														num6--;
																														goto IL_24a5;
																														IL_24a5:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_18ae:
																														if (42 < b)
																														{
																															break;
																														}
																														goto IL_18bc;
																														IL_18bc:
																														if (42 > b)
																														{
																															break;
																														}
																														goto IL_18ca;
																														IL_18ca:
																														global::_003CModule_003E.int_199 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														num = 669;
																														goto IL_18ed;
																														IL_18ed:
																														num6--;
																														goto IL_5ca0;
																														IL_20b4:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_20f4;
																														IL_20f4:
																														array2[num6 - 2] = 3;
																														goto IL_2108;
																														IL_2108:
																														num6--;
																														goto IL_5ca0;
																														IL_21f5:
																														if (45 >= b)
																														{
																															goto IL_2200;
																														}
																														goto IL_223a;
																														IL_2200:
																														if (45 <= b)
																														{
																															goto IL_220e;
																														}
																														goto IL_2805;
																														IL_220e:
																														global::_003CModule_003E.gameEntityManager_3 = (GameEntityManager)array3[num6 - 1];
																														goto IL_2227;
																														IL_2227:
																														num6--;
																														goto IL_5ca0;
																														IL_2805:
																														if (44 < b)
																														{
																															break;
																														}
																														goto IL_2813;
																														IL_2813:
																														if (44 > b)
																														{
																															break;
																														}
																														goto IL_2821;
																														IL_2821:
																														array2[num6] = 5;
																														goto IL_282f;
																														IL_282f:
																														array3[num6] = ((delegate*<GameEntityManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																														goto IL_284d;
																														IL_284d:
																														num6++;
																														num = 552;
																														goto IL_2864;
																														IL_2864:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_223a:
																														if (46 < b)
																														{
																															goto IL_2245;
																														}
																														num = 335;
																														goto IL_22c0;
																														IL_2245:
																														if (47 < b)
																														{
																															break;
																														}
																														goto IL_2253;
																														IL_2253:
																														if (47 > b)
																														{
																															break;
																														}
																														goto IL_2261;
																														IL_2261:
																														array3[num6] = ((delegate*<Dictionary<string, int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																														goto IL_227f;
																														IL_227f:
																														array2[num6] = 5;
																														goto IL_228d;
																														IL_228d:
																														num6++;
																														num = 229;
																														goto IL_22a4;
																														IL_22a4:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_2938:
																														num6--;
																														goto IL_5ca0;
																														IL_22c0:
																														if (46 > b)
																														{
																															break;
																														}
																														goto IL_22ce;
																														IL_22ce:
																														array2[num6 - 1] = 3;
																														goto IL_22e2;
																														IL_22e2:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_2321;
																														IL_2321:
																														ptr2 += 8;
																														num = 303;
																														goto IL_5ca0;
																														IL_23b6:
																														array2[num6 - 2] = 0;
																														goto IL_23ca;
																														IL_23ca:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]);
																														goto IL_34d8;
																														IL_34d8:
																														num6--;
																														goto IL_34e6;
																														IL_34e6:
																														ptr2 += 8;
																														num = 214;
																														goto IL_5ca0;
																														IL_1900:
																														if (53 < b)
																														{
																															goto IL_190e;
																														}
																														goto IL_1de2;
																														IL_190e:
																														if (55 >= b)
																														{
																															goto IL_191c;
																														}
																														goto IL_19a0;
																														IL_191c:
																														if (55 <= b)
																														{
																															goto IL_1927;
																														}
																														goto IL_198d;
																														IL_1927:
																														array2[num6 - 1] = 3;
																														goto IL_193b;
																														IL_193b:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_197a;
																														IL_197a:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_198d:
																														if (54 < b)
																														{
																															break;
																														}
																														goto IL_1f1b;
																														IL_1f1b:
																														if (54 > b)
																														{
																															break;
																														}
																														goto IL_1f29;
																														IL_1f29:
																														global::_003CModule_003E.list_11 = (List<long>)array3[num6 - 1];
																														goto IL_1f42;
																														IL_1f42:
																														num6--;
																														goto IL_5ca0;
																														IL_19a0:
																														if (56 >= b)
																														{
																															goto IL_19ae;
																														}
																														goto IL_1e4b;
																														IL_19ae:
																														if (56 > b)
																														{
																															break;
																														}
																														goto IL_19bc;
																														IL_19bc:
																														array2[num6] = 15;
																														goto IL_19ca;
																														IL_19ca:
																														array4[num6] = *(int*)(ptr2 + num3);
																														goto IL_1d35;
																														IL_1d35:
																														ptr2 += 8;
																														goto IL_1d43;
																														IL_1d43:
																														num6++;
																														goto IL_5ca0;
																														IL_1e4b:
																														if (57 < b)
																														{
																															break;
																														}
																														goto IL_1e59;
																														IL_1e59:
																														if (57 > b)
																														{
																															break;
																														}
																														goto IL_233d;
																														IL_233d:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																														goto IL_2ae3;
																														IL_2ae3:
																														array2[num6] = 3;
																														goto IL_2af1;
																														IL_2af1:
																														num6++;
																														goto IL_2aff;
																														IL_2aff:
																														ptr2 += 8;
																														num = 562;
																														goto IL_5ca0;
																														IL_1de2:
																														if (53 <= b)
																														{
																															goto IL_1df0;
																														}
																														goto IL_26bc;
																														IL_1df0:
																														array2[num6] = 5;
																														goto IL_21b6;
																														IL_21b6:
																														array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																														goto IL_21d4;
																														IL_21d4:
																														num6++;
																														goto IL_21e2;
																														IL_21e2:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_26bc:
																														if (50 >= b)
																														{
																															goto IL_26ca;
																														}
																														goto IL_2877;
																														IL_26ca:
																														if (50 > b)
																														{
																															goto IL_26d8;
																														}
																														goto IL_2a7d;
																														IL_26d8:
																														if (49 < b)
																														{
																															break;
																														}
																														goto IL_26e6;
																														IL_26e6:
																														if (49 > b)
																														{
																															break;
																														}
																														goto IL_26f4;
																														IL_26f4:
																														global::_003CModule_003E.int_200 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_270e;
																														IL_270e:
																														num6--;
																														goto IL_5ca0;
																														IL_2a7d:
																														array2[num6 - 1] = 3;
																														goto IL_2a91;
																														IL_2a91:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_2ad0;
																														IL_2ad0:
																														ptr2 += 8;
																														goto IL_5ca0;
																														IL_2877:
																														if (51 < b)
																														{
																															goto IL_2885;
																														}
																														goto IL_2910;
																														IL_2885:
																														if (52 < b)
																														{
																															break;
																														}
																														goto IL_2893;
																														IL_2893:
																														if (52 > b)
																														{
																															break;
																														}
																														goto IL_28a1;
																														IL_28a1:
																														array2[num6 - 1] = 3;
																														goto IL_28b5;
																														IL_28b5:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_28f4;
																														IL_28f4:
																														ptr2 += 8;
																														num = 322;
																														goto IL_5ca0;
																														IL_2910:
																														if (51 > b)
																														{
																															break;
																														}
																														goto IL_291e;
																													}
																													break;
																												}
																												goto IL_16bf;
																												IL_32a8:
																												((delegate*<List<long>, long, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<long>)array3[num6 - 2], *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_32e6;
																												IL_16bf:
																												if (39 > b)
																												{
																													goto IL_16cd;
																												}
																												goto IL_1e6c;
																												IL_16cd:
																												if (19 >= b)
																												{
																													goto IL_16db;
																												}
																												goto IL_2b1b;
																												IL_16db:
																												if (19 > b)
																												{
																													goto IL_16e9;
																												}
																												goto IL_1e03;
																												IL_16e9:
																												if (9 >= b)
																												{
																													goto IL_16f7;
																												}
																												goto IL_17af;
																												IL_16f7:
																												if (9 > b)
																												{
																													goto IL_1705;
																												}
																												goto IL_1a87;
																												IL_1705:
																												if (4 >= b)
																												{
																													goto IL_1710;
																												}
																												goto IL_1723;
																												IL_1710:
																												if (4 > b)
																												{
																													goto IL_1c4c;
																												}
																												goto IL_2721;
																												IL_2721:
																												array2[num6] = 0;
																												goto IL_272f;
																												IL_272f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												goto IL_2752;
																												IL_2752:
																												array3[num6] = null;
																												goto IL_275c;
																												IL_275c:
																												num6++;
																												goto IL_276a;
																												IL_276a:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_1c4c:
																												if (2 >= b)
																												{
																													goto IL_1c99;
																												}
																												goto IL_269b;
																												IL_1c99:
																												if (2 > b)
																												{
																													goto IL_1ca4;
																												}
																												goto IL_1cc5;
																												IL_1ca4:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_1cb2;
																												IL_1cb2:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_216e;
																												IL_216e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																												goto IL_2187;
																												IL_2187:
																												array2[num6] = 0;
																												goto IL_2195;
																												IL_2195:
																												num6++;
																												goto IL_21a3;
																												IL_21a3:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_1cc5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 153;
																												goto IL_1d0e;
																												IL_1d0e:
																												array2[num6 - 2] = 0;
																												goto IL_1d22;
																												IL_1d22:
																												num6--;
																												goto IL_5ca0;
																												IL_269b:
																												if (3 < b)
																												{
																													break;
																												}
																												goto IL_26a9;
																												IL_26a9:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_360c;
																												IL_360c:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_3635;
																												IL_3635:
																												ptr2 += 8;
																												goto IL_3643;
																												IL_3643:
																												num6--;
																												goto IL_5ca0;
																												IL_1723:
																												if (6 >= b)
																												{
																													num = 470;
																													goto IL_173a;
																												}
																												goto IL_1aee;
																												IL_32e6:
																												num6 -= 2;
																												goto IL_32f4;
																												IL_173a:
																												if (6 <= b)
																												{
																													goto IL_1748;
																												}
																												goto IL_1c2b;
																												IL_1748:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_1788;
																												IL_1788:
																												array2[num6 - 2] = 0;
																												goto IL_179c;
																												IL_179c:
																												num6--;
																												goto IL_5ca0;
																												IL_1c2b:
																												if (5 < b)
																												{
																													break;
																												}
																												goto IL_1c39;
																												IL_1c39:
																												if (5 > b)
																												{
																													break;
																												}
																												goto IL_24cb;
																												IL_24cb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_250b;
																												IL_250b:
																												array2[num6 - 2] = 0;
																												goto IL_251f;
																												IL_251f:
																												num6--;
																												goto IL_5ca0;
																												IL_1aee:
																												if (7 < b)
																												{
																													goto IL_1afc;
																												}
																												goto IL_1f55;
																												IL_1afc:
																												if (8 < b)
																												{
																													break;
																												}
																												goto IL_1b0a;
																												IL_1b0a:
																												if (8 > b)
																												{
																													break;
																												}
																												goto IL_1b18;
																												IL_1b18:
																												num6--;
																												goto IL_5ca0;
																												IL_1f55:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_3468;
																												IL_3468:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_34a8;
																												IL_34a8:
																												array2[num6 - 2] = 0;
																												goto IL_34bc;
																												IL_34bc:
																												num6--;
																												num = 329;
																												goto IL_5ca0;
																												IL_1a87:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_1ac7;
																												IL_1ac7:
																												array2[num6 - 2] = 0;
																												goto IL_1adb;
																												IL_1adb:
																												num6--;
																												goto IL_5ca0;
																												IL_17af:
																												if (14 < b)
																												{
																													goto IL_17bd;
																												}
																												goto IL_1b2b;
																												IL_17bd:
																												if (16 >= b)
																												{
																													goto IL_17c8;
																												}
																												goto IL_17e9;
																												IL_17c8:
																												if (16 > b)
																												{
																													goto IL_17d6;
																												}
																												goto IL_27b5;
																												IL_17d6:
																												if (15 < b)
																												{
																													break;
																												}
																												goto IL_1e8f;
																												IL_1e8f:
																												if (15 > b)
																												{
																													break;
																												}
																												goto IL_1e9d;
																												IL_1e9d:
																												array2[num6] = array2[num6 - 1];
																												goto IL_2421;
																												IL_2421:
																												array4[num6 - 0] = array4[num6 - 1];
																												num = 21;
																												goto IL_2448;
																												IL_2448:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_246c;
																												IL_246c:
																												array3[num6] = array3[num6 - 1];
																												goto IL_2484;
																												IL_2484:
																												num6++;
																												goto IL_5ca0;
																												IL_27b5:
																												array2[num6] = 5;
																												goto IL_27c3;
																												IL_27c3:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_27db;
																												IL_27db:
																												num6++;
																												goto IL_27e9;
																												IL_27e9:
																												ptr2 += 8;
																												num = 1230;
																												goto IL_5ca0;
																												IL_17e9:
																												if (17 >= b)
																												{
																													goto IL_17f4;
																												}
																												goto IL_1807;
																												IL_17f4:
																												if (17 > b)
																												{
																													break;
																												}
																												goto IL_235c;
																												IL_235c:
																												((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																												num = 559;
																												goto IL_23a3;
																												IL_23a3:
																												num6 -= 3;
																												goto IL_5ca0;
																												IL_1807:
																												if (18 < b)
																												{
																													break;
																												}
																												goto IL_1815;
																												IL_1815:
																												if (18 > b)
																												{
																													break;
																												}
																												goto IL_1823;
																												IL_1823:
																												array2[num6 - 1] = 5;
																												goto IL_1c5c;
																												IL_1c5c:
																												array3[num6 - 1] = ((delegate*<string[], string>)getUIContextReturnType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																												goto IL_24b8;
																												IL_24b8:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_1b2b:
																												if (14 <= b)
																												{
																													goto IL_1b36;
																												}
																												goto IL_1b64;
																												IL_1b36:
																												array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																												goto IL_1f02;
																												IL_1f02:
																												array2[num6 - 1] = 5;
																												goto IL_5ca0;
																												IL_1b64:
																												if (11 < b)
																												{
																													goto IL_1b6f;
																												}
																												num = 721;
																												goto IL_1bdb;
																												IL_1b6f:
																												if (12 >= b)
																												{
																													goto IL_1b7a;
																												}
																												goto IL_1b8d;
																												IL_1b7a:
																												if (12 > b)
																												{
																													break;
																												}
																												goto IL_25c3;
																												IL_25c3:
																												array8 = array3;
																												num7 = num6;
																												if (array == null)
																												{
																													goto IL_25d2;
																												}
																												num8 = ptr2;
																												byte b2 = *num8;
																												ptr2 = num8 + 4;
																												int num9 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num9;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_267a;
																												IL_3307:
																												if (38 < b)
																												{
																													break;
																												}
																												num = 372;
																												goto IL_331e;
																												IL_27a2:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_331e:
																												if (38 > b)
																												{
																													break;
																												}
																												goto IL_332c;
																												IL_267a:
																												array2[num6] = 5;
																												goto IL_2688;
																												IL_2688:
																												num6++;
																												goto IL_5ca0;
																												IL_1b8d:
																												if (13 < b)
																												{
																													break;
																												}
																												goto IL_1b9b;
																												IL_1b9b:
																												if (13 > b)
																												{
																													break;
																												}
																												num = 461;
																												goto IL_1bb2;
																												IL_332c:
																												array2[num6 - 1] = 3;
																												goto IL_3340;
																												IL_1bb2:
																												array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																												goto IL_1bee;
																												IL_1bee:
																												ptr2 += 8;
																												num = 450;
																												goto IL_1c05;
																												IL_1c05:
																												num6--;
																												goto IL_5ca0;
																												IL_32f4:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_1bdb:
																												if (11 <= b)
																												{
																													goto IL_5ca0;
																												}
																												goto IL_2532;
																												IL_2532:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_2540;
																												IL_2540:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_254e;
																												IL_254e:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_25b0;
																												IL_25b0:
																												num6 -= 2;
																												goto IL_5ca0;
																												IL_1e03:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																												goto IL_1e1c;
																												IL_1e1c:
																												array2[num6] = 1;
																												goto IL_1e2a;
																												IL_1e2a:
																												num6++;
																												goto IL_1e38;
																												IL_1e38:
																												ptr2 += 16;
																												goto IL_5ca0;
																												IL_2b1b:
																												if (29 >= b)
																												{
																													goto IL_2b29;
																												}
																												goto IL_2fc8;
																												IL_2b29:
																												if (29 <= b)
																												{
																													num = 394;
																													goto IL_2b3d;
																												}
																												goto IL_2ba3;
																												IL_3340:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												num = 527;
																												goto IL_3388;
																												IL_2b3d:
																												array2[num6 - 1] = 0;
																												goto IL_2b51;
																												IL_2b51:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_2b90;
																												IL_2b90:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_2ba3:
																												if (24 >= b)
																												{
																													goto IL_2bb1;
																												}
																												goto IL_2dd8;
																												IL_2bb1:
																												if (24 <= b)
																												{
																													goto IL_2bbc;
																												}
																												goto IL_2c0f;
																												IL_2bbc:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_2be0;
																												IL_2be0:
																												array2[num6] = 0;
																												goto IL_2bee;
																												IL_2bee:
																												num6++;
																												goto IL_2bfc;
																												IL_2bfc:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_2c0f:
																												if (21 >= b)
																												{
																													goto IL_2c1d;
																												}
																												goto IL_2cd6;
																												IL_2c1d:
																												if (21 > b)
																												{
																													goto IL_2c28;
																												}
																												goto IL_2c65;
																												IL_2c28:
																												if (20 < b)
																												{
																													break;
																												}
																												goto IL_2c36;
																												IL_2c36:
																												if (20 > b)
																												{
																													break;
																												}
																												num = 314;
																												goto IL_2c4d;
																												IL_3388:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_2c4d:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_5ca0;
																												IL_2c65:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																												goto IL_2ca6;
																												IL_2ca6:
																												array2[num6 - 2] = 0;
																												num = 550;
																												goto IL_2cc3;
																												IL_2cc3:
																												num6--;
																												goto IL_5ca0;
																												IL_2cd6:
																												if (22 >= b)
																												{
																													num = 409;
																													goto IL_2cea;
																												}
																												goto IL_2d5d;
																												IL_1e6c:
																												array3[num6] = ((delegate*<GameEntityManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_277d;
																												IL_2cea:
																												if (22 > b)
																												{
																													break;
																												}
																												goto IL_2cf8;
																												IL_2cf8:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_2d4a;
																												IL_2d4a:
																												num6--;
																												goto IL_5ca0;
																												IL_2d5d:
																												if (23 < b)
																												{
																													break;
																												}
																												num = 895;
																												goto IL_2d74;
																												IL_277d:
																												array2[num6] = 5;
																												goto IL_278b;
																												IL_2d74:
																												if (23 > b)
																												{
																													break;
																												}
																												goto IL_2d82;
																												IL_2d82:
																												array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_2da0;
																												IL_2da0:
																												array2[num6] = 5;
																												goto IL_2dae;
																												IL_2dae:
																												num6++;
																												goto IL_2dbc;
																												IL_2dbc:
																												ptr2 += 8;
																												num = 1279;
																												goto IL_5ca0;
																												IL_2dd8:
																												if (26 >= b)
																												{
																													goto IL_2de6;
																												}
																												goto IL_2ebd;
																												IL_2de6:
																												if (26 <= b)
																												{
																													goto IL_2df1;
																												}
																												goto IL_2e39;
																												IL_2df1:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																												goto IL_2e0a;
																												IL_2e0a:
																												array2[num6] = 3;
																												goto IL_2e18;
																												IL_2e18:
																												num6++;
																												goto IL_2e26;
																												IL_2e26:
																												ptr2 += 16;
																												goto IL_5ca0;
																												IL_2e39:
																												if (25 < b)
																												{
																													break;
																												}
																												num = 561;
																												goto IL_2e50;
																												IL_278b:
																												num6++;
																												num = 507;
																												goto IL_27a2;
																												IL_2e50:
																												if (25 > b)
																												{
																													break;
																												}
																												goto IL_2e5e;
																												IL_2e5e:
																												((delegate*<List<int>, int, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<int>)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_2e9c;
																												IL_2e9c:
																												num6 -= 2;
																												goto IL_2eaa;
																												IL_2eaa:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_2ebd:
																												if (27 >= b)
																												{
																													goto IL_2ec8;
																												}
																												goto IL_2f3c;
																												IL_2ec8:
																												if (27 > b)
																												{
																													break;
																												}
																												goto IL_2ed6;
																												IL_2ed6:
																												array2[num6 - 1] = 3;
																												goto IL_2eea;
																												IL_2eea:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_2f29;
																												IL_2f29:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_2f3c:
																												if (28 < b)
																												{
																													break;
																												}
																												goto IL_2f4a;
																												IL_2f4a:
																												if (28 > b)
																												{
																													break;
																												}
																												goto IL_2f58;
																												IL_2f58:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_2f98;
																												IL_2f98:
																												array2[num6 - 2] = 3;
																												goto IL_2fac;
																												IL_2fac:
																												num6--;
																												num = 163;
																												goto IL_5ca0;
																												IL_2fc8:
																												if (34 >= b)
																												{
																													goto IL_2fd6;
																												}
																												goto IL_31a3;
																												IL_2fd6:
																												if (34 <= b)
																												{
																													goto IL_2fe1;
																												}
																												goto IL_302e;
																												IL_2fe1:
																												array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_2fff;
																												IL_2fff:
																												array2[num6] = 5;
																												goto IL_300d;
																												IL_300d:
																												num6++;
																												goto IL_301b;
																												IL_301b:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_302e:
																												if (31 >= b)
																												{
																													goto IL_303c;
																												}
																												goto IL_30e5;
																												IL_303c:
																												if (31 > b)
																												{
																													goto IL_3047;
																												}
																												goto IL_30b0;
																												IL_3047:
																												if (30 < b)
																												{
																													break;
																												}
																												goto IL_3055;
																												IL_3055:
																												if (30 > b)
																												{
																													break;
																												}
																												goto IL_3063;
																												IL_3063:
																												array2[num6] = 5;
																												goto IL_3071;
																												IL_3071:
																												array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_308f;
																												IL_308f:
																												num6++;
																												goto IL_309d;
																												IL_309d:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_30b0:
																												global::_003CModule_003E.list_10 = (List<int>)array3[num6 - 1];
																												num = 850;
																												goto IL_30d2;
																												IL_30d2:
																												num6--;
																												goto IL_5ca0;
																												IL_30e5:
																												if (32 >= b)
																												{
																													goto IL_30f0;
																												}
																												goto IL_3117;
																												IL_30f0:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_30fe;
																												IL_30fe:
																												array2[num6 - 1] = 3;
																												goto IL_3502;
																												IL_3502:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_3541;
																												IL_3541:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_3117:
																												if (33 < b)
																												{
																													break;
																												}
																												goto IL_3125;
																												IL_3125:
																												if (33 > b)
																												{
																													break;
																												}
																												goto IL_3133;
																												IL_3133:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 498;
																												goto IL_317c;
																												IL_317c:
																												array2[num6 - 2] = 3;
																												goto IL_3190;
																												IL_3190:
																												num6--;
																												goto IL_5ca0;
																												IL_31a3:
																												if (36 >= b)
																												{
																													goto IL_31b1;
																												}
																												goto IL_328f;
																												IL_31b1:
																												if (36 <= b)
																												{
																													goto IL_31bc;
																												}
																												goto IL_3221;
																												IL_31bc:
																												array2[num6 - 1] = 1;
																												goto IL_31d0;
																												IL_31d0:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, long>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																												goto IL_320e;
																												IL_320e:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_3221:
																												if (35 < b)
																												{
																													break;
																												}
																												goto IL_322f;
																												IL_322f:
																												if (35 > b)
																												{
																													break;
																												}
																												goto IL_323d;
																												IL_323d:
																												array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_3260;
																												IL_3260:
																												array2[num6] = 4;
																												goto IL_326e;
																												IL_326e:
																												num6++;
																												goto IL_327c;
																												IL_327c:
																												ptr2 += 8;
																												goto IL_5ca0;
																												IL_328f:
																												if (37 >= b)
																												{
																													goto IL_329a;
																												}
																												goto IL_3307;
																												IL_329a:
																												if (37 > b)
																												{
																													break;
																												}
																												goto IL_32a8;
																											}
																											break;
																										}
																										goto IL_33ee;
																										IL_3428:
																										ptr2 += 8;
																										goto IL_5ca0;
																										IL_33ee:
																										array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																										goto IL_340c;
																										IL_340c:
																										array2[num6] = 5;
																										goto IL_341a;
																										IL_341a:
																										num6++;
																										goto IL_3428;
																									}
																									break;
																								}
																								goto IL_3832;
																								IL_5b1b:
																								if (153 < b)
																								{
																									break;
																								}
																								goto IL_5b29;
																								IL_3832:
																								if (117 >= b)
																								{
																									goto IL_3840;
																								}
																								goto IL_499a;
																								IL_3840:
																								if (117 <= b)
																								{
																									num = 193;
																									goto IL_3854;
																								}
																								goto IL_3880;
																								IL_5b29:
																								if (153 > b)
																								{
																									break;
																								}
																								goto IL_5b37;
																								IL_3854:
																								global::_003CModule_003E.vector3_106 = (Vector3)array3[num6 - 1];
																								goto IL_386d;
																								IL_386d:
																								num6--;
																								goto IL_5ca0;
																								IL_3880:
																								if (97 >= b)
																								{
																									goto IL_388e;
																								}
																								goto IL_41a1;
																								IL_388e:
																								if (97 <= b)
																								{
																									goto IL_389c;
																								}
																								goto IL_3923;
																								IL_389c:
																								array2[num6 - 2] = 0;
																								goto IL_38b0;
																								IL_38b0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, GameEntityId, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], (GameEntityId)array3[num6 - 1]);
																								goto IL_3902;
																								IL_3902:
																								num6--;
																								goto IL_3910;
																								IL_3910:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3923:
																								if (87 < b)
																								{
																									goto IL_3931;
																								}
																								num = 981;
																								goto IL_3d7d;
																								IL_3931:
																								if (92 >= b)
																								{
																									goto IL_393f;
																								}
																								goto IL_3bdd;
																								IL_393f:
																								if (92 <= b)
																								{
																									num = 433;
																									goto IL_3953;
																								}
																								goto IL_39a6;
																								IL_5b4b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
																								num = 12;
																								goto IL_5bcf;
																								IL_3953:
																								array2[num6] = 0;
																								goto IL_3961;
																								IL_3961:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_3985;
																								IL_3985:
																								num6++;
																								goto IL_3993;
																								IL_3993:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_39a6:
																								if (89 < b)
																								{
																									goto IL_39b4;
																								}
																								goto IL_3a90;
																								IL_39b4:
																								if (90 < b)
																								{
																									goto IL_39c2;
																								}
																								num = 693;
																								goto IL_3a4d;
																								IL_39c2:
																								if (91 < b)
																								{
																									break;
																								}
																								goto IL_39d0;
																								IL_39d0:
																								if (91 > b)
																								{
																									break;
																								}
																								goto IL_39de;
																								IL_39de:
																								array2[num6 - 1] = 3;
																								goto IL_39f2;
																								IL_39f2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_3a31;
																								IL_3a31:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5bcf:
																								num6 -= 3;
																								goto IL_5bdd;
																								IL_3a4d:
																								if (90 > b)
																								{
																									break;
																								}
																								goto IL_3a5b;
																								IL_3a5b:
																								global::_003CModule_003E.quaternion_3 = (Quaternion)array3[num6 - 1];
																								num = 909;
																								goto IL_3a7d;
																								IL_3a7d:
																								num6--;
																								goto IL_5ca0;
																								IL_3a90:
																								if (89 <= b)
																								{
																									goto IL_3a9e;
																								}
																								goto IL_3b24;
																								IL_3a9e:
																								array2[num6 - 2] = 4;
																								goto IL_3ab2;
																								IL_3ab2:
																								array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																								goto IL_3b03;
																								IL_3b03:
																								num6--;
																								goto IL_3b11;
																								IL_3b11:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3b24:
																								if (88 < b)
																								{
																									break;
																								}
																								goto IL_3b32;
																								IL_3b32:
																								if (88 > b)
																								{
																									break;
																								}
																								goto IL_3b40;
																								IL_3b40:
																								array2[num6 - 3] = 4;
																								goto IL_3b54;
																								IL_3b54:
																								array3[num6 - 3] = ((delegate*<float, float, float, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_3bbc;
																								IL_3bbc:
																								num6 -= 2;
																								goto IL_3bca;
																								IL_3bca:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3bdd:
																								if (94 >= b)
																								{
																									goto IL_3beb;
																								}
																								goto IL_3cac;
																								IL_3beb:
																								if (94 <= b)
																								{
																									goto IL_3bf6;
																								}
																								goto IL_3c49;
																								IL_3bf6:
																								array2[num6] = 3;
																								goto IL_3c04;
																								IL_3c04:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3c28;
																								IL_3c28:
																								num6++;
																								goto IL_3c36;
																								IL_3c36:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3c49:
																								if (93 < b)
																								{
																									break;
																								}
																								goto IL_3c57;
																								IL_3c57:
																								if (93 > b)
																								{
																									break;
																								}
																								goto IL_3c65;
																								IL_3c65:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_3c7d;
																								IL_3c7d:
																								array2[num6] = 5;
																								goto IL_3c8b;
																								IL_3c8b:
																								num6++;
																								goto IL_3c99;
																								IL_3c99:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3cac:
																								if (95 >= b)
																								{
																									goto IL_3cb7;
																								}
																								goto IL_3d06;
																								IL_3cb7:
																								if (95 > b)
																								{
																									break;
																								}
																								goto IL_3cc5;
																								IL_3cc5:
																								((Class121)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_3cf3;
																								IL_3cf3:
																								num6 -= 2;
																								goto IL_5ca0;
																								IL_3d06:
																								if (96 < b)
																								{
																									break;
																								}
																								goto IL_3d14;
																								IL_3d14:
																								if (96 > b)
																								{
																									break;
																								}
																								goto IL_3d22;
																								IL_3d22:
																								array3[num6] = ((delegate*<GameEntityId>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3d45;
																								IL_3d45:
																								array2[num6] = 4;
																								goto IL_3d53;
																								IL_3d53:
																								num6++;
																								goto IL_3d61;
																								IL_3d61:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5b37:
																								array2[num6 - 4] = 0;
																								goto IL_5b4b;
																								IL_3d7d:
																								if (87 > b)
																								{
																									goto IL_3d8b;
																								}
																								goto IL_4134;
																								IL_3d8b:
																								if (82 >= b)
																								{
																									goto IL_3d99;
																								}
																								goto IL_3f26;
																								IL_3d99:
																								if (82 <= b)
																								{
																									goto IL_3da4;
																								}
																								goto IL_3df6;
																								IL_3da4:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3dc7;
																								IL_3dc7:
																								array2[num6] = 4;
																								goto IL_3dd5;
																								IL_3dd5:
																								num6++;
																								goto IL_3de3;
																								IL_3de3:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3df6:
																								if (80 >= b)
																								{
																									goto IL_3e04;
																								}
																								goto IL_3eaf;
																								IL_3e04:
																								if (80 <= b)
																								{
																									goto IL_3e0f;
																								}
																								goto IL_3e37;
																								IL_3e0f:
																								((delegate*<void>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3e24;
																								IL_3e24:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3e37:
																								if (79 < b)
																								{
																									break;
																								}
																								num = 953;
																								goto IL_3e4e;
																								IL_5bdd:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3e4e:
																								if (79 > b)
																								{
																									break;
																								}
																								goto IL_3e5c;
																								IL_3e5c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3e80;
																								IL_3e80:
																								array2[num6] = 0;
																								goto IL_3e8e;
																								IL_3e8e:
																								num6++;
																								goto IL_3e9c;
																								IL_3e9c:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3eaf:
																								if (81 < b)
																								{
																									break;
																								}
																								goto IL_3ebd;
																								IL_3ebd:
																								if (81 > b)
																								{
																									break;
																								}
																								goto IL_3ecb;
																								IL_3ecb:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								num = 1232;
																								goto IL_3ef7;
																								IL_3ef7:
																								array2[num6] = 4;
																								goto IL_3f05;
																								IL_3f05:
																								num6++;
																								goto IL_3f13;
																								IL_3f13:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3f26:
																								if (84 >= b)
																								{
																									goto IL_3f34;
																								}
																								goto IL_4041;
																								IL_3f34:
																								if (84 <= b)
																								{
																									goto IL_3f42;
																								}
																								goto IL_3fd2;
																								IL_3f42:
																								array2[num6 - 2] = 4;
																								goto IL_3f56;
																								IL_3f56:
																								array3[num6 - 2] = ((delegate*<Vector3, float, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								num = 1009;
																								goto IL_3fb1;
																								IL_3fb1:
																								num6--;
																								goto IL_3fbf;
																								IL_3fbf:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_3fd2:
																								if (83 < b)
																								{
																									break;
																								}
																								goto IL_3fe0;
																								IL_3fe0:
																								if (83 > b)
																								{
																									break;
																								}
																								goto IL_3fee;
																								IL_3fee:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4012;
																								IL_4012:
																								array2[num6] = 3;
																								goto IL_4020;
																								IL_4020:
																								num6++;
																								goto IL_402e;
																								IL_402e:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4041:
																								if (85 >= b)
																								{
																									goto IL_404f;
																								}
																								goto IL_40ec;
																								IL_404f:
																								if (85 > b)
																								{
																									break;
																								}
																								goto IL_405d;
																								IL_405d:
																								array2[num6 - 2] = 4;
																								goto IL_4071;
																								IL_4071:
																								array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_40c2;
																								IL_40c2:
																								num6--;
																								goto IL_40d0;
																								IL_40d0:
																								ptr2 += 8;
																								num = 602;
																								goto IL_5ca0;
																								IL_40ec:
																								if (86 < b)
																								{
																									break;
																								}
																								goto IL_40fa;
																								IL_40fa:
																								if (86 > b)
																								{
																									break;
																								}
																								goto IL_4108;
																								IL_4108:
																								global::_003CModule_003E.vector3_102 = (Vector3)array3[num6 - 1];
																								goto IL_4121;
																								IL_4121:
																								num6--;
																								goto IL_5ca0;
																								IL_4134:
																								array2[num6 - 1] = 4;
																								num = 179;
																								goto IL_4151;
																								IL_4151:
																								array3[num6 - 1] = ((delegate*<Vector3, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																								goto IL_418e;
																								IL_418e:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_41a1:
																								if (107 >= b)
																								{
																									goto IL_41af;
																								}
																								goto IL_456b;
																								IL_41af:
																								if (107 <= b)
																								{
																									goto IL_41bd;
																								}
																								goto IL_424e;
																								IL_41bd:
																								array2[num6 - 2] = 0;
																								goto IL_41d1;
																								IL_41d1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, int, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								num = 51;
																								goto IL_422d;
																								IL_422d:
																								num6--;
																								goto IL_423b;
																								IL_423b:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_424e:
																								if (102 >= b)
																								{
																									goto IL_425c;
																								}
																								goto IL_43bd;
																								IL_425c:
																								if (102 <= b)
																								{
																									goto IL_4267;
																								}
																								goto IL_42b9;
																								IL_4267:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_428a;
																								IL_428a:
																								array2[num6] = 4;
																								goto IL_4298;
																								IL_4298:
																								num6++;
																								goto IL_42a6;
																								IL_42a6:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_42b9:
																								if (99 < b)
																								{
																									goto IL_42c4;
																								}
																								goto IL_433d;
																								IL_42c4:
																								if (100 >= b)
																								{
																									goto IL_42cf;
																								}
																								goto IL_42f9;
																								IL_42cf:
																								if (100 > b)
																								{
																									break;
																								}
																								goto IL_42dd;
																								IL_42dd:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_5ca0;
																								IL_42f9:
																								if (101 < b)
																								{
																									break;
																								}
																								goto IL_4307;
																								IL_4307:
																								if (101 > b)
																								{
																									break;
																								}
																								goto IL_4315;
																								IL_4315:
																								((delegate*<void>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_432a;
																								IL_432a:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_433d:
																								if (99 <= b)
																								{
																									goto IL_4348;
																								}
																								goto IL_4374;
																								IL_4348:
																								global::_003CModule_003E.list_14 = (List<int>)array3[num6 - 1];
																								goto IL_4361;
																								IL_4361:
																								num6--;
																								goto IL_5ca0;
																								IL_4374:
																								if (98 < b)
																								{
																									break;
																								}
																								goto IL_4382;
																								IL_4382:
																								if (98 > b)
																								{
																									break;
																								}
																								goto IL_4390;
																								IL_4390:
																								global::_003CModule_003E.int_197 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_43aa;
																								IL_43aa:
																								num6--;
																								goto IL_5ca0;
																								IL_43bd:
																								if (104 < b)
																								{
																									goto IL_43cb;
																								}
																								num = 1135;
																								goto IL_44c2;
																								IL_43cb:
																								if (105 >= b)
																								{
																									goto IL_43d6;
																								}
																								goto IL_444b;
																								IL_43d6:
																								if (105 > b)
																								{
																									break;
																								}
																								goto IL_43e4;
																								IL_43e4:
																								ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_4438;
																								IL_4438:
																								num6--;
																								goto IL_5ca0;
																								IL_444b:
																								if (106 < b)
																								{
																									break;
																								}
																								goto IL_4459;
																								IL_4459:
																								if (106 > b)
																								{
																									break;
																								}
																								goto IL_4467;
																								IL_4467:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_448a;
																								IL_448a:
																								array2[num6] = 4;
																								goto IL_4498;
																								IL_4498:
																								num6++;
																								goto IL_44a6;
																								IL_44a6:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5bf0:
																								if (155 >= b)
																								{
																									goto IL_5bfb;
																								}
																								goto IL_5c6e;
																								IL_44c2:
																								if (104 > b)
																								{
																									goto IL_44cd;
																								}
																								goto IL_4515;
																								IL_44cd:
																								if (103 < b)
																								{
																									break;
																								}
																								goto IL_44db;
																								IL_44db:
																								if (103 > b)
																								{
																									break;
																								}
																								goto IL_44e9;
																								IL_44e9:
																								global::_003CModule_003E.vector3_108 = (Vector3)array3[num6 - 1];
																								goto IL_4502;
																								IL_4502:
																								num6--;
																								goto IL_5ca0;
																								IL_4515:
																								array3[num6] = ((delegate*<SuperInfectionManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4533;
																								IL_4533:
																								array2[num6] = 5;
																								goto IL_4541;
																								IL_4541:
																								num6++;
																								goto IL_454f;
																								IL_454f:
																								ptr2 += 8;
																								num = 1272;
																								goto IL_5ca0;
																								IL_456b:
																								if (112 >= b)
																								{
																									goto IL_4579;
																								}
																								goto IL_47bc;
																								IL_4579:
																								if (112 <= b)
																								{
																									goto IL_4584;
																								}
																								goto IL_45e3;
																								IL_4584:
																								array2[num6 - 1] = 5;
																								goto IL_4598;
																								IL_4598:
																								array3[num6 - 1] = ((delegate*<Component, Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SphereCollider)array3[num6 - 1]);
																								goto IL_45d0;
																								IL_45d0:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_45e3:
																								if (109 >= b)
																								{
																									goto IL_45f1;
																								}
																								goto IL_46bd;
																								IL_45f1:
																								if (109 <= b)
																								{
																									goto IL_45fc;
																								}
																								goto IL_466b;
																								IL_45fc:
																								array2[num6 - 1] = 3;
																								goto IL_4610;
																								IL_4610:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_464f;
																								IL_464f:
																								ptr2 += 8;
																								num = 1235;
																								goto IL_5ca0;
																								IL_466b:
																								if (108 < b)
																								{
																									break;
																								}
																								goto IL_4679;
																								IL_4679:
																								if (108 > b)
																								{
																									break;
																								}
																								num = 970;
																								goto IL_4690;
																								IL_5bfb:
																								if (155 > b)
																								{
																									break;
																								}
																								goto IL_5c09;
																								IL_4690:
																								global::_003CModule_003E.int_198 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_46aa;
																								IL_46aa:
																								num6--;
																								goto IL_5ca0;
																								IL_46bd:
																								if (110 < b)
																								{
																									goto IL_46cb;
																								}
																								num = 723;
																								goto IL_4761;
																								IL_46cb:
																								if (111 < b)
																								{
																									break;
																								}
																								num = 735;
																								goto IL_46e2;
																								IL_5c47:
																								num6 -= 2;
																								num = 653;
																								goto IL_5c5e;
																								IL_46e2:
																								if (111 > b)
																								{
																									break;
																								}
																								goto IL_46f0;
																								IL_46f0:
																								array3[num6 - 1] = ((delegate*<GTPlayer, SphereCollider>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GTPlayer)array3[num6 - 1]);
																								goto IL_4728;
																								IL_4728:
																								array2[num6 - 1] = 5;
																								num = 1280;
																								goto IL_4745;
																								IL_4745:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5c09:
																								((delegate*<GameEntityManager, GameEntityManager.ZoneState, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(GameEntityManager.ZoneState*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_5c47;
																								IL_4761:
																								if (110 > b)
																								{
																									break;
																								}
																								goto IL_476f;
																								IL_476f:
																								array2[num6] = 5;
																								goto IL_477d;
																								IL_477d:
																								array3[num6] = ((delegate*<GTPlayer>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_479b;
																								IL_479b:
																								num6++;
																								goto IL_47a9;
																								IL_47a9:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_47bc:
																								if (114 >= b)
																								{
																									goto IL_47ca;
																								}
																								goto IL_48a2;
																								IL_47ca:
																								if (114 <= b)
																								{
																									goto IL_47d5;
																								}
																								goto IL_4822;
																								IL_47d5:
																								array2[num6] = 5;
																								goto IL_47e3;
																								IL_47e3:
																								array3[num6] = ((delegate*<GTPlayer>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4801;
																								IL_4801:
																								num6++;
																								goto IL_480f;
																								IL_480f:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4822:
																								if (113 < b)
																								{
																									break;
																								}
																								goto IL_4830;
																								IL_4830:
																								if (113 > b)
																								{
																									break;
																								}
																								goto IL_483e;
																								IL_483e:
																								array2[num6 - 1] = 4;
																								goto IL_4852;
																								IL_4852:
																								array3[num6 - 1] = ((delegate*<Transform, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																								goto IL_488f;
																								IL_488f:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_48a2:
																								if (115 >= b)
																								{
																									goto IL_48ad;
																								}
																								goto IL_491a;
																								IL_48ad:
																								if (115 > b)
																								{
																									break;
																								}
																								goto IL_48bb;
																								IL_48bb:
																								array2[num6 - 1] = 5;
																								goto IL_48cf;
																								IL_48cf:
																								array3[num6 - 1] = ((delegate*<Component, Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SphereCollider)array3[num6 - 1]);
																								goto IL_4907;
																								IL_4907:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_491a:
																								if (116 < b)
																								{
																									break;
																								}
																								goto IL_4928;
																								IL_4928:
																								if (116 > b)
																								{
																									break;
																								}
																								goto IL_4936;
																								IL_4936:
																								array2[num6 - 1] = 4;
																								goto IL_494a;
																								IL_494a:
																								array3[num6 - 1] = ((delegate*<Transform, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																								goto IL_4987;
																								IL_4987:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_499a:
																								if (137 >= b)
																								{
																									goto IL_49a8;
																								}
																								goto IL_532a;
																								IL_49a8:
																								if (137 <= b)
																								{
																									goto IL_49b3;
																								}
																								goto IL_4a30;
																								IL_49b3:
																								array2[num6 - 2] = 0;
																								goto IL_49c7;
																								IL_49c7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((UnityEngine.Object)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																								goto IL_4a0f;
																								IL_4a0f:
																								num6--;
																								goto IL_4a1d;
																								IL_4a1d:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4a30:
																								if (127 >= b)
																								{
																									goto IL_4a3e;
																								}
																								goto IL_4ebd;
																								IL_4a3e:
																								if (127 <= b)
																								{
																									goto IL_4a49;
																								}
																								goto IL_4aa8;
																								IL_4a49:
																								array3[num6 - 1] = ((delegate*<SuperInfectionManager, SuperInfection>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfectionManager)array3[num6 - 1]);
																								goto IL_4a81;
																								IL_4a81:
																								array2[num6 - 1] = 5;
																								goto IL_4a95;
																								IL_4a95:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4aa8:
																								if (122 >= b)
																								{
																									goto IL_4ab6;
																								}
																								goto IL_4d17;
																								IL_4ab6:
																								if (122 <= b)
																								{
																									goto IL_4ac4;
																								}
																								goto IL_4b4a;
																								IL_4ac4:
																								array2[num6 - 2] = 4;
																								goto IL_4ad8;
																								IL_4ad8:
																								array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_4b29;
																								IL_4b29:
																								num6--;
																								goto IL_4b37;
																								IL_4b37:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4b4a:
																								if (119 >= b)
																								{
																									goto IL_4b58;
																								}
																								goto IL_4c01;
																								IL_4b58:
																								if (119 <= b)
																								{
																									goto IL_4b63;
																								}
																								goto IL_4bb9;
																								IL_4b63:
																								array3[num6] = ((delegate*<Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4b81;
																								IL_4b81:
																								array2[num6] = 5;
																								goto IL_4b8f;
																								IL_4b8f:
																								num6++;
																								num = 349;
																								goto IL_4ba6;
																								IL_4ba6:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4bb9:
																								if (118 < b)
																								{
																									break;
																								}
																								goto IL_4bc7;
																								IL_4bc7:
																								if (118 > b)
																								{
																									break;
																								}
																								goto IL_4bd5;
																								IL_4bd5:
																								global::_003CModule_003E.transform_12 = (Transform)array3[num6 - 1];
																								goto IL_4bee;
																								IL_4bee:
																								num6--;
																								goto IL_5ca0;
																								IL_4c01:
																								if (120 >= b)
																								{
																									goto IL_4c0c;
																								}
																								goto IL_4c6c;
																								IL_4c0c:
																								if (120 > b)
																								{
																									break;
																								}
																								goto IL_4c1a;
																								IL_4c1a:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4c3d;
																								IL_4c3d:
																								array2[num6] = 4;
																								goto IL_4c4b;
																								IL_4c4b:
																								num6++;
																								goto IL_4c59;
																								IL_4c59:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4c6c:
																								if (121 < b)
																								{
																									break;
																								}
																								goto IL_4c7a;
																								IL_4c7a:
																								if (121 > b)
																								{
																									break;
																								}
																								goto IL_4c88;
																								IL_4c88:
																								array2[num6 - 2] = 4;
																								num = 1038;
																								goto IL_4ca5;
																								IL_4ca5:
																								array3[num6 - 2] = ((delegate*<Transform, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_4cf6;
																								IL_4cf6:
																								num6--;
																								goto IL_4d04;
																								IL_4d04:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4d17:
																								if (124 >= b)
																								{
																									goto IL_4d25;
																								}
																								goto IL_4dca;
																								IL_4d25:
																								if (124 <= b)
																								{
																									goto IL_4d30;
																								}
																								goto IL_4d82;
																								IL_4d30:
																								array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4d53;
																								IL_4d53:
																								array2[num6] = 4;
																								goto IL_4d61;
																								IL_4d61:
																								num6++;
																								goto IL_4d6f;
																								IL_4d6f:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4d82:
																								if (123 < b)
																								{
																									break;
																								}
																								goto IL_4d90;
																								IL_4d90:
																								if (123 > b)
																								{
																									break;
																								}
																								goto IL_4d9e;
																								IL_4d9e:
																								global::_003CModule_003E.vector3_107 = (Vector3)array3[num6 - 1];
																								goto IL_4db7;
																								IL_4db7:
																								num6--;
																								goto IL_5ca0;
																								IL_4dca:
																								if (125 >= b)
																								{
																									goto IL_4dd8;
																								}
																								goto IL_4e75;
																								IL_4dd8:
																								if (125 > b)
																								{
																									break;
																								}
																								goto IL_4de6;
																								IL_4de6:
																								array2[num6 - 2] = 4;
																								num = 547;
																								goto IL_4e03;
																								IL_4e03:
																								array3[num6 - 2] = ((delegate*<Transform, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_4e54;
																								IL_4e54:
																								num6--;
																								goto IL_4e62;
																								IL_4e62:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4e75:
																								if (126 < b)
																								{
																									break;
																								}
																								goto IL_4e83;
																								IL_4e83:
																								if (126 > b)
																								{
																									break;
																								}
																								goto IL_4e91;
																								IL_4e91:
																								global::_003CModule_003E.vector3_105 = (Vector3)array3[num6 - 1];
																								goto IL_4eaa;
																								IL_4eaa:
																								num6--;
																								goto IL_5ca0;
																								IL_4ebd:
																								if (132 >= b)
																								{
																									goto IL_4ecb;
																								}
																								goto IL_5122;
																								IL_4ecb:
																								if (132 <= b)
																								{
																									goto IL_4ed6;
																								}
																								goto IL_4f23;
																								IL_4ed6:
																								array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_4ef4;
																								IL_4ef4:
																								array2[num6] = 5;
																								goto IL_4f02;
																								IL_4f02:
																								num6++;
																								goto IL_4f10;
																								IL_4f10:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4f23:
																								if (129 >= b)
																								{
																									goto IL_4f31;
																								}
																								goto IL_4ffe;
																								IL_4f31:
																								if (129 > b)
																								{
																									goto IL_4f3c;
																								}
																								goto IL_4fa2;
																								IL_4f3c:
																								if (128 < b)
																								{
																									break;
																								}
																								goto IL_4f4a;
																								IL_4f4a:
																								if (128 > b)
																								{
																									break;
																								}
																								goto IL_4f58;
																								IL_4f58:
																								((delegate*<SuperInfection, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfection)array3[num6 - 1]);
																								goto IL_4f81;
																								IL_4f81:
																								num6--;
																								goto IL_4f8f;
																								IL_4f8f:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4fa2:
																								array2[num6] = 3;
																								goto IL_4fb0;
																								IL_4fb0:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								num = 165;
																								goto IL_4fdd;
																								IL_4fdd:
																								num6++;
																								goto IL_4feb;
																								IL_4feb:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_4ffe:
																								if (130 >= b)
																								{
																									goto IL_5009;
																								}
																								goto IL_5085;
																								IL_5009:
																								if (130 > b)
																								{
																									break;
																								}
																								goto IL_5017;
																								IL_5017:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class121, float>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Class121)array3[num6 - 1]);
																								goto IL_5055;
																								IL_5055:
																								array2[num6 - 1] = 3;
																								goto IL_5069;
																								IL_5069:
																								ptr2 += 8;
																								num = 1161;
																								goto IL_5ca0;
																								IL_5085:
																								if (131 < b)
																								{
																									break;
																								}
																								goto IL_5093;
																								IL_5093:
																								if (131 > b)
																								{
																									break;
																								}
																								goto IL_50a1;
																								IL_50a1:
																								ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_510f;
																								IL_510f:
																								num6 -= 2;
																								goto IL_5ca0;
																								IL_5122:
																								if (134 >= b)
																								{
																									goto IL_5130;
																								}
																								goto IL_5217;
																								IL_5130:
																								if (134 <= b)
																								{
																									goto IL_513b;
																								}
																								goto IL_51a0;
																								IL_513b:
																								array2[num6 - 1] = 0;
																								goto IL_514f;
																								IL_514f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Quaternion, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 1]);
																								goto IL_518d;
																								IL_518d:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_51a0:
																								if (133 < b)
																								{
																									break;
																								}
																								goto IL_51ae;
																								IL_51ae:
																								if (133 > b)
																								{
																									break;
																								}
																								num = 532;
																								goto IL_51c5;
																								IL_5c5e:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_51c5:
																								array3[num6] = ((delegate*<Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_51e8;
																								IL_51e8:
																								array2[num6] = 4;
																								goto IL_51f6;
																								IL_51f6:
																								num6++;
																								goto IL_5204;
																								IL_5204:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5217:
																								if (135 >= b)
																								{
																									goto IL_5222;
																								}
																								goto IL_5283;
																								IL_5222:
																								if (135 > b)
																								{
																									break;
																								}
																								goto IL_5230;
																								IL_5230:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_5254;
																								IL_5254:
																								array2[num6] = 0;
																								goto IL_5262;
																								IL_5262:
																								num6++;
																								goto IL_5270;
																								IL_5270:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5283:
																								if (136 < b)
																								{
																									break;
																								}
																								goto IL_5291;
																								IL_5291:
																								if (136 > b)
																								{
																									break;
																								}
																								num = 460;
																								goto IL_52a8;
																								IL_5c6e:
																								if (156 < b)
																								{
																									break;
																								}
																								goto IL_5c79;
																								IL_52a8:
																								array2[num6 - 2] = 0;
																								goto IL_52bc;
																								IL_52bc:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfection)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																								goto IL_5309;
																								IL_5309:
																								num6--;
																								goto IL_5317;
																								IL_5317:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_532a:
																								if (147 >= b)
																								{
																									goto IL_5338;
																								}
																								goto IL_5825;
																								IL_5338:
																								if (147 <= b)
																								{
																									goto IL_5343;
																								}
																								goto IL_53b2;
																								IL_5343:
																								array2[num6 - 1] = 3;
																								num = 887;
																								goto IL_5360;
																								IL_5360:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_539f;
																								IL_539f:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_53b2:
																								if (142 < b)
																								{
																									goto IL_53c0;
																								}
																								goto IL_559d;
																								IL_53c0:
																								if (144 >= b)
																								{
																									goto IL_53ce;
																								}
																								goto IL_54af;
																								IL_53ce:
																								if (144 <= b)
																								{
																									goto IL_53d9;
																								}
																								goto IL_5424;
																								IL_53d9:
																								array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_5402;
																								IL_5402:
																								array2[num6 - 1] = 5;
																								num = 62;
																								goto IL_5ca0;
																								IL_5424:
																								if (143 < b)
																								{
																									break;
																								}
																								goto IL_5432;
																								IL_5432:
																								if (143 > b)
																								{
																									break;
																								}
																								goto IL_5440;
																								IL_5440:
																								array2[num6 - 1] = 0;
																								goto IL_5454;
																								IL_5454:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_5493;
																								IL_5493:
																								ptr2 += 8;
																								num = 1203;
																								goto IL_5ca0;
																								IL_54af:
																								if (145 >= b)
																								{
																									goto IL_54ba;
																								}
																								goto IL_5530;
																								IL_54ba:
																								if (145 > b)
																								{
																									break;
																								}
																								goto IL_54c8;
																								IL_54c8:
																								array2[num6 - 1] = 5;
																								num = 1040;
																								goto IL_54e5;
																								IL_54e5:
																								array3[num6 - 1] = ((delegate*<List<int>, int[]>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<int>)array3[num6 - 1]);
																								goto IL_551d;
																								IL_551d:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5530:
																								if (146 < b)
																								{
																									break;
																								}
																								goto IL_553e;
																								IL_553e:
																								if (146 > b)
																								{
																									break;
																								}
																								goto IL_554c;
																								IL_554c:
																								((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (int[])array3[num6 - 1];
																								goto IL_558a;
																								IL_558a:
																								num6 -= 3;
																								goto IL_5ca0;
																								IL_559d:
																								if (142 <= b)
																								{
																									goto IL_55a8;
																								}
																								goto IL_560e;
																								IL_55a8:
																								array2[num6 - 1] = 3;
																								goto IL_55bc;
																								IL_55bc:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_55fb;
																								IL_55fb:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_560e:
																								if (139 >= b)
																								{
																									goto IL_561c;
																								}
																								goto IL_5707;
																								IL_561c:
																								if (139 <= b)
																								{
																									goto IL_5627;
																								}
																								goto IL_5698;
																								IL_5627:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_5685;
																								IL_5685:
																								num6--;
																								goto IL_5ca0;
																								IL_5698:
																								if (138 < b)
																								{
																									break;
																								}
																								goto IL_56a6;
																								IL_56a6:
																								if (138 > b)
																								{
																									break;
																								}
																								goto IL_56b4;
																								IL_56b4:
																								array2[num6] = 0;
																								goto IL_56c2;
																								IL_56c2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_56e6;
																								IL_56e6:
																								num6++;
																								goto IL_56f4;
																								IL_56f4:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5707:
																								if (140 >= b)
																								{
																									goto IL_5715;
																								}
																								goto IL_57aa;
																								IL_5715:
																								if (140 > b)
																								{
																									break;
																								}
																								goto IL_5723;
																								IL_5723:
																								array2[num6 - 2] = 0;
																								goto IL_5737;
																								IL_5737:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																								goto IL_5789;
																								IL_5789:
																								num6--;
																								goto IL_5797;
																								IL_5797:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_57aa:
																								if (141 < b)
																								{
																									break;
																								}
																								goto IL_57b8;
																								IL_57b8:
																								if (141 > b)
																								{
																									break;
																								}
																								goto IL_57c6;
																								IL_57c6:
																								array3[num6 - 1] = ((delegate*<GameEntityManager, PhotonView>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 1]);
																								goto IL_57fe;
																								IL_57fe:
																								array2[num6 - 1] = 5;
																								goto IL_5812;
																								IL_5812:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5825:
																								if (152 >= b)
																								{
																									goto IL_5833;
																								}
																								goto IL_5a9c;
																								IL_5833:
																								if (152 <= b)
																								{
																									goto IL_583e;
																								}
																								goto IL_58a4;
																								IL_583e:
																								array2[num6 - 1] = 3;
																								goto IL_5852;
																								IL_5852:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_5891;
																								IL_5891:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_58a4:
																								if (149 >= b)
																								{
																									goto IL_58b2;
																								}
																								goto IL_599e;
																								IL_58b2:
																								if (149 <= b)
																								{
																									goto IL_58bd;
																								}
																								goto IL_591c;
																								IL_58bd:
																								array2[num6 - 1] = 5;
																								goto IL_58d1;
																								IL_58d1:
																								array3[num6 - 1] = ((delegate*<List<long>, long[]>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<long>)array3[num6 - 1]);
																								goto IL_5909;
																								IL_5909:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_591c:
																								if (148 < b)
																								{
																									break;
																								}
																								goto IL_592a;
																								IL_592a:
																								if (148 > b)
																								{
																									break;
																								}
																								goto IL_5938;
																								IL_5938:
																								array2[num6 - 1] = 0;
																								goto IL_594c;
																								IL_594c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_598b;
																								IL_598b:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_599e:
																								if (150 >= b)
																								{
																									goto IL_59a9;
																								}
																								goto IL_5a11;
																								IL_59a9:
																								if (150 > b)
																								{
																									break;
																								}
																								goto IL_59b7;
																								IL_59b7:
																								((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (long[])array3[num6 - 1];
																								goto IL_59f5;
																								IL_59f5:
																								num6 -= 3;
																								num = 1264;
																								goto IL_5ca0;
																								IL_5a11:
																								if (151 < b)
																								{
																									break;
																								}
																								num = 1065;
																								goto IL_5a28;
																								IL_5c79:
																								if (156 <= b)
																								{
																									num = 417;
																								}
																								break;
																								IL_5a28:
																								if (151 > b)
																								{
																									break;
																								}
																								goto IL_5a36;
																								IL_5a36:
																								array2[num6 - 1] = 3;
																								goto IL_5a4a;
																								IL_5a4a:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_5a89;
																								IL_5a89:
																								ptr2 += 8;
																								goto IL_5ca0;
																								IL_5a9c:
																								if (154 >= b)
																								{
																									goto IL_5aaa;
																								}
																								goto IL_5bf0;
																								IL_5aaa:
																								if (154 <= b)
																								{
																									goto IL_5ab5;
																								}
																								goto IL_5b1b;
																								IL_5ab5:
																								array2[num6 - 1] = 0;
																								goto IL_5ac9;
																								IL_5ac9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_5b08;
																								IL_5b08:
																								ptr2 += 8;
																								goto IL_5ca0;
																							}
																							break;
																							IL_1562:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_5ca0;
																					continue;
																					end_IL_1572:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_25d2:
			while (true)
			{
				IL_25d2_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_267a_2:
						array2[num6] = 5;
						while (true)
						{
							IL_2688_2:
							num6++;
							while (true)
							{
								IL_5ca0_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_1572_2:
											if (b >= 1)
											{
												while (b <= 156)
												{
													while (true)
													{
														IL_1552_2:
														if (78 >= b)
														{
															while (true)
															{
																IL_1542_2:
																if (78 > b)
																{
																	while (true)
																	{
																		IL_1532_2:
																		if (39 < b)
																		{
																			while (true)
																			{
																				IL_1522_2:
																				if (58 < b)
																				{
																					while (true)
																					{
																						IL_1512_2:
																						if (68 < b)
																						{
																							while (true)
																							{
																								IL_1502_2:
																								if (73 >= b)
																								{
																									while (true)
																									{
																										IL_14f2_2:
																										if (73 > b)
																										{
																											while (true)
																											{
																												IL_14e2_2:
																												if (70 < b)
																												{
																													while (true)
																													{
																														IL_14d2_2:
																														if (71 < b)
																														{
																															while (72 >= b)
																															{
																																while (72 <= b)
																																{
																																	while (true)
																																	{
																																		IL_149c_2:
																																		array2[num6 - 1] = 3;
																																		while (true)
																																		{
																																			IL_1452_2:
																																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																			num = 1292;
																																			while (true)
																																			{
																																				if (num != 1292)
																																				{
																																					if (num != 2273)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 105:
																																						goto IL_1452_2;
																																					case 808:
																																					case 948:
																																						goto IL_149c_2;
																																					case 574:
																																						goto IL_14b2_2;
																																					case 815:
																																						goto IL_14c2_2;
																																					case 361:
																																						goto IL_14d2_2;
																																					case 996:
																																						goto IL_14e2_2;
																																					case 517:
																																						goto IL_14f2_2;
																																					case 365:
																																						goto IL_1502_2;
																																					case 90:
																																						goto IL_1512_2;
																																					case 9:
																																						goto IL_1522_2;
																																					case 1138:
																																						goto IL_1532_2;
																																					case 1276:
																																						goto IL_1542_2;
																																					case 317:
																																						goto IL_1552_2;
																																					case 1013:
																																						goto IL_1562_2;
																																					case 223:
																																						goto IL_1572_2;
																																					case 992:
																																						goto end_IL_1572_2;
																																					case 563:
																																					case 1189:
																																						goto end_IL_1582;
																																					case 107:
																																					case 280:
																																						goto IL_159d_2;
																																					case 590:
																																						goto IL_15bb_2;
																																					case 650:
																																						goto IL_15ce_2;
																																					case 189:
																																					case 209:
																																						goto IL_15d9_2;
																																					case 558:
																																						goto IL_15f3_2;
																																					case 147:
																																						goto IL_1606_2;
																																					case 357:
																																						goto IL_1611_2;
																																					case 336:
																																						goto IL_161c_2;
																																					case 234:
																																						goto IL_162f_2;
																																					case 235:
																																					case 657:
																																						goto IL_163f_2;
																																					case 682:
																																						goto IL_165a_2;
																																					case 712:
																																						goto IL_166d_2;
																																					case 739:
																																						goto IL_1680_2;
																																					case 174:
																																						goto IL_168b_2;
																																					case 27:
																																						goto IL_1699_2;
																																					case 761:
																																						goto IL_16ac_2;
																																					case 825:
																																						goto IL_16bf_2;
																																					case 159:
																																						goto IL_16cd_2;
																																					case 323:
																																						goto IL_16db_2;
																																					case 411:
																																						goto IL_16e9_2;
																																					case 483:
																																						goto IL_16f7_2;
																																					case 688:
																																						goto IL_1705_2;
																																					case 423:
																																						goto IL_1710_2;
																																					case 796:
																																						goto IL_1723_2;
																																					case 470:
																																						goto IL_173a_2;
																																					case 239:
																																					case 380:
																																						goto IL_1748_2;
																																					case 59:
																																						goto IL_1788_2;
																																					case 328:
																																						goto IL_179c_2;
																																					case 78:
																																						goto IL_17af_2;
																																					case 813:
																																						goto IL_17bd_2;
																																					case 489:
																																						goto IL_17c8_2;
																																					case 820:
																																						goto IL_17d6_2;
																																					case 14:
																																						goto IL_17e9_2;
																																					case 779:
																																						goto IL_17f4_2;
																																					case 138:
																																						goto IL_1807_2;
																																					case 172:
																																						goto IL_1815_2;
																																					case 551:
																																					case 625:
																																						goto IL_1823_2;
																																					case 843:
																																						goto IL_183c_2;
																																					case 617:
																																						goto IL_184a_2;
																																					case 427:
																																						goto IL_1858_2;
																																					case 422:
																																						goto IL_1866_2;
																																					case 167:
																																						goto IL_1874_2;
																																					case 462:
																																						goto IL_187f_2;
																																					case 298:
																																						goto IL_188d_2;
																																					case 276:
																																						goto IL_189b_2;
																																					case 493:
																																						goto IL_18ae_2;
																																					case 546:
																																						goto IL_18bc_2;
																																					case 197:
																																					case 401:
																																						goto IL_18ca_2;
																																					case 669:
																																						goto IL_18ed_2;
																																					case 789:
																																						goto IL_1900_2;
																																					case 344:
																																						goto IL_190e_2;
																																					case 410:
																																						goto IL_191c_2;
																																					case 93:
																																					case 362:
																																						goto IL_1927_2;
																																					case 390:
																																						goto IL_193b_2;
																																					case 687:
																																						goto IL_197a_2;
																																					case 261:
																																						goto IL_198d_2;
																																					case 319:
																																						goto IL_19a0_2;
																																					case 117:
																																						goto IL_19ae_2;
																																					case 637:
																																					case 788:
																																						goto IL_19bc_2;
																																					case 271:
																																						goto IL_19ca_2;
																																					case 857:
																																						goto IL_19e2_2;
																																					case 371:
																																					case 541:
																																						goto IL_19ed_2;
																																					case 528:
																																						goto IL_1a18_2;
																																					case 499:
																																						goto IL_1a31_2;
																																					case 492:
																																						goto IL_1a48_2;
																																					case 116:
																																					case 864:
																																						goto IL_1a64_2;
																																					case 251:
																																					case 896:
																																						goto IL_1a87_2;
																																					case 822:
																																						goto IL_1ac7_2;
																																					case 501:
																																						goto IL_1adb_2;
																																					case 923:
																																						goto IL_1aee_2;
																																					case 391:
																																						goto IL_1afc_2;
																																					case 697:
																																						goto IL_1b0a_2;
																																					case 426:
																																					case 663:
																																						goto IL_1b18_2;
																																					case 937:
																																						goto IL_1b2b_2;
																																					case 212:
																																					case 662:
																																						goto IL_1b36_2;
																																					case 100:
																																						goto IL_1b64_2;
																																					case 289:
																																						goto IL_1b6f_2;
																																					case 506:
																																						goto IL_1b7a_2;
																																					case 39:
																																						goto IL_1b8d_2;
																																					case 396:
																																						goto IL_1b9b_2;
																																					case 461:
																																					case 828:
																																						goto IL_1bb2_2;
																																					case 721:
																																						goto IL_1bdb_2;
																																					case 962:
																																						goto IL_1bee_2;
																																					case 450:
																																						goto IL_1c05_2;
																																					case 969:
																																						goto IL_1c18_2;
																																					case 971:
																																						goto IL_1c2b_2;
																																					case 301:
																																						goto IL_1c39_2;
																																					case 984:
																																						goto IL_1c4c_2;
																																					case 986:
																																						goto IL_1c5c_2;
																																					case 1006:
																																						goto IL_1c99_2;
																																					case 731:
																																						goto IL_1ca4_2;
																																					case 955:
																																						goto IL_1cb2_2;
																																					case 99:
																																					case 606:
																																						goto IL_1cc5_2;
																																					case 153:
																																						goto IL_1d0e_2;
																																					case 351:
																																						goto IL_1d22_2;
																																					case 1015:
																																						goto IL_1d35_2;
																																					case 613:
																																						goto IL_1d43_2;
																																					case 1018:
																																						goto IL_1d56_2;
																																					case 168:
																																					case 325:
																																						goto IL_1d61_2;
																																					case 926:
																																						goto IL_1d7a_2;
																																					case 270:
																																						goto IL_1d8d_2;
																																					case 320:
																																						goto IL_1d9b_2;
																																					case 68:
																																					case 124:
																																						goto IL_1db2_2;
																																					case 1029:
																																						goto IL_1de2_2;
																																					case 118:
																																					case 524:
																																						goto IL_1df0_2;
																																					case 341:
																																					case 1050:
																																						goto IL_1e03_2;
																																					case 694:
																																						goto IL_1e1c_2;
																																					case 292:
																																						goto IL_1e2a_2;
																																					case 801:
																																						goto IL_1e38_2;
																																					case 1061:
																																						goto IL_1e4b_2;
																																					case 851:
																																						goto IL_1e59_2;
																																					case 1043:
																																					case 1067:
																																						goto IL_1e6c_2;
																																					case 1068:
																																						goto IL_1e8f_2;
																																					case 41:
																																					case 353:
																																						goto IL_1e9d_2;
																																					case 1069:
																																						goto IL_1eba_2;
																																					case 1076:
																																						goto IL_1ed3_2;
																																					case 928:
																																						goto IL_1ee1_2;
																																					case 603:
																																						goto IL_1eef_2;
																																					case 1077:
																																						goto IL_1f02_2;
																																					case 1087:
																																						goto IL_1f1b_2;
																																					case 203:
																																					case 405:
																																						goto IL_1f29_2;
																																					case 631:
																																						goto IL_1f42_2;
																																					case 1090:
																																						goto IL_1f55_2;
																																					case 1031:
																																					case 1093:
																																						goto IL_1f68_2;
																																					case 865:
																																						goto IL_1f7c_2;
																																					case 1098:
																																						goto IL_1fd4_2;
																																					case 245:
																																					case 567:
																																						goto IL_1fdf_2;
																																					case 269:
																																						goto IL_1ff3_2;
																																					case 706:
																																						goto IL_2032_2;
																																					case 475:
																																						goto IL_2045_2;
																																					case 346:
																																						goto IL_2053_2;
																																					case 781:
																																					case 817:
																																						goto IL_2061_2;
																																					case 484:
																																						goto IL_206f_2;
																																					case 751:
																																						goto IL_2093_2;
																																					case 225:
																																						goto IL_20a1_2;
																																					case 977:
																																					case 1103:
																																						goto IL_20b4_2;
																																					case 171:
																																						goto IL_20f4_2;
																																					case 481:
																																						goto IL_2108_2;
																																					case 395:
																																					case 1112:
																																						goto IL_211b_2;
																																					case 375:
																																						goto IL_213f_2;
																																					case 1020:
																																						goto IL_214d_2;
																																					case 111:
																																						goto IL_215b_2;
																																					case 74:
																																					case 1113:
																																						goto IL_216e_2;
																																					case 1023:
																																						goto IL_2187_2;
																																					case 1042:
																																						goto IL_2195_2;
																																					case 862:
																																						goto IL_21a3_2;
																																					case 1120:
																																						goto IL_21b6_2;
																																					case 127:
																																						goto IL_21d4_2;
																																					case 783:
																																						goto IL_21e2_2;
																																					case 1129:
																																						goto IL_21f5_2;
																																					case 18:
																																						goto IL_2200_2;
																																					case 445:
																																					case 737:
																																						goto IL_220e_2;
																																					case 800:
																																						goto IL_2227_2;
																																					case 185:
																																						goto IL_223a_2;
																																					case 661:
																																						goto IL_2245_2;
																																					case 973:
																																						goto IL_2253_2;
																																					case 19:
																																					case 467:
																																						goto IL_2261_2;
																																					case 175:
																																						goto IL_227f_2;
																																					case 628:
																																						goto IL_228d_2;
																																					case 229:
																																						goto IL_22a4_2;
																																					case 335:
																																						goto IL_22c0_2;
																																					case 726:
																																					case 790:
																																						goto IL_22ce_2;
																																					case 990:
																																						goto IL_22e2_2;
																																					case 464:
																																						goto IL_2321_2;
																																					case 916:
																																					case 1137:
																																						goto IL_233d_2;
																																					case 377:
																																					case 1140:
																																						goto IL_235c_2;
																																					case 559:
																																						goto IL_23a3_2;
																																					case 1046:
																																					case 1151:
																																						goto IL_23b6_2;
																																					case 856:
																																						goto IL_23ca_2;
																																					case 1152:
																																						goto IL_2421_2;
																																					case 21:
																																						goto IL_2448_2;
																																					case 87:
																																						goto IL_246c_2;
																																					case 155:
																																						goto IL_2484_2;
																																					case 1159:
																																						goto IL_2497_2;
																																					case 477:
																																						goto IL_24a5_2;
																																					case 1170:
																																						goto IL_24b8_2;
																																					case 659:
																																					case 1171:
																																						goto IL_24cb_2;
																																					case 86:
																																						goto IL_250b_2;
																																					case 133:
																																						goto IL_251f_2;
																																					case 1173:
																																						goto IL_2532_2;
																																					case 805:
																																						goto IL_2540_2;
																																					case 736:
																																					case 1123:
																																						goto IL_254e_2;
																																					case 868:
																																						goto IL_25b0_2;
																																					case 600:
																																					case 1178:
																																						goto end_IL_1592;
																																					case 782:
																																						goto IL_267a_2;
																																					case 386:
																																						goto IL_2688_2;
																																					case 1180:
																																						goto IL_269b_2;
																																					case 1019:
																																						goto IL_26a9_2;
																																					case 1192:
																																						goto IL_26bc_2;
																																					case 67:
																																						goto IL_26ca_2;
																																					case 29:
																																						goto IL_26d8_2;
																																					case 917:
																																						goto IL_26e6_2;
																																					case 324:
																																					case 702:
																																						goto IL_26f4_2;
																																					case 255:
																																						goto IL_270e_2;
																																					case 369:
																																					case 1205:
																																						goto IL_2721_2;
																																					case 575:
																																						goto IL_272f_2;
																																					case 870:
																																						goto IL_2752_2;
																																					case 987:
																																						goto IL_275c_2;
																																					case 112:
																																						goto IL_276a_2;
																																					case 1213:
																																						goto IL_277d_2;
																																					case 307:
																																						goto IL_278b_2;
																																					case 507:
																																						goto IL_27a2_2;
																																					case 36:
																																					case 1216:
																																						goto IL_27b5_2;
																																					case 367:
																																						goto IL_27c3_2;
																																					case 226:
																																						goto IL_27db_2;
																																					case 1167:
																																						goto IL_27e9_2;
																																					case 1224:
																																						goto IL_2805_2;
																																					case 218:
																																						goto IL_2813_2;
																																					case 152:
																																					case 1139:
																																						goto IL_2821_2;
																																					case 1153:
																																						goto IL_282f_2;
																																					case 121:
																																						goto IL_284d_2;
																																					case 552:
																																						goto IL_2864_2;
																																					case 1242:
																																						goto IL_2877_2;
																																					case 416:
																																						goto IL_2885_2;
																																					case 272:
																																						goto IL_2893_2;
																																					case 376:
																																					case 816:
																																						goto IL_28a1_2;
																																					case 780:
																																						goto IL_28b5_2;
																																					case 273:
																																						goto IL_28f4_2;
																																					case 1246:
																																						goto IL_2910_2;
																																					case 934:
																																					case 956:
																																						goto IL_291e_2;
																																					case 96:
																																						goto IL_2938_2;
																																					case 1247:
																																						goto IL_294b_2;
																																					case 1209:
																																						goto IL_2956_2;
																																					case 439:
																																					case 1001:
																																						goto IL_2964_2;
																																					case 904:
																																						goto IL_2972_2;
																																					case 1187:
																																						goto IL_298e_2;
																																					case 785:
																																						goto IL_299c_2;
																																					case 286:
																																						goto IL_29af_2;
																																					case 1101:
																																					case 1251:
																																						goto IL_29c2_2;
																																					case 670:
																																						goto IL_2a5c_2;
																																					case 1165:
																																						goto IL_2a6a_2;
																																					case 1014:
																																					case 1252:
																																						goto IL_2a7d_2;
																																					case 140:
																																						goto IL_2a91_2;
																																					case 1092:
																																						goto IL_2ad0_2;
																																					case 1254:
																																						goto IL_2ae3_2;
																																					case 1032:
																																						goto IL_2af1_2;
																																					case 80:
																																						goto IL_2aff_2;
																																					case 1255:
																																						goto IL_2b1b_2;
																																					case 24:
																																						goto IL_2b29_2;
																																					case 42:
																																					case 394:
																																						goto IL_2b3d_2;
																																					case 897:
																																						goto IL_2b51_2;
																																					case 1155:
																																						goto IL_2b90_2;
																																					case 855:
																																						goto IL_2ba3_2;
																																					case 258:
																																						goto IL_2bb1_2;
																																					case 402:
																																					case 495:
																																						goto IL_2bbc_2;
																																					case 967:
																																						goto IL_2be0_2;
																																					case 995:
																																						goto IL_2bee_2;
																																					case 810:
																																						goto IL_2bfc_2;
																																					case 907:
																																						goto IL_2c0f_2;
																																					case 838:
																																						goto IL_2c1d_2;
																																					case 466:
																																						goto IL_2c28_2;
																																					case 993:
																																						goto IL_2c36_2;
																																					case 314:
																																					case 830:
																																						goto IL_2c4d_2;
																																					case 449:
																																					case 566:
																																						goto IL_2c65_2;
																																					case 503:
																																						goto IL_2ca6_2;
																																					case 550:
																																						goto IL_2cc3_2;
																																					case 957:
																																						goto IL_2cd6_2;
																																					case 409:
																																						goto IL_2cea_2;
																																					case 131:
																																					case 459:
																																						goto IL_2cf8_2;
																																					case 177:
																																						goto IL_2d4a_2;
																																					case 1215:
																																						goto IL_2d5d_2;
																																					case 895:
																																						goto IL_2d74_2;
																																					case 373:
																																					case 874:
																																						goto IL_2d82_2;
																																					case 863:
																																						goto IL_2da0_2;
																																					case 66:
																																						goto IL_2dae_2;
																																					case 684:
																																						goto IL_2dbc_2;
																																					case 1149:
																																						goto IL_2dd8_2;
																																					case 1034:
																																						goto IL_2de6_2;
																																					case 430:
																																					case 1131:
																																						goto IL_2df1_2;
																																					case 676:
																																						goto IL_2e0a_2;
																																					case 958:
																																						goto IL_2e18_2;
																																					case 343:
																																						goto IL_2e26_2;
																																					case 812:
																																						goto IL_2e39_2;
																																					case 561:
																																						goto IL_2e50_2;
																																					case 40:
																																					case 906:
																																						goto IL_2e5e_2;
																																					case 192:
																																						goto IL_2e9c_2;
																																					case 1108:
																																						goto IL_2eaa_2;
																																					case 5:
																																						goto IL_2ebd_2;
																																					case 1204:
																																						goto IL_2ec8_2;
																																					case 839:
																																					case 1177:
																																						goto IL_2ed6_2;
																																					case 584:
																																						goto IL_2eea_2;
																																					case 446:
																																						goto IL_2f29_2;
																																					case 170:
																																						goto IL_2f3c_2;
																																					case 1058:
																																						goto IL_2f4a_2;
																																					case 340:
																																					case 1100:
																																						goto IL_2f58_2;
																																					case 332:
																																						goto IL_2f98_2;
																																					case 443:
																																						goto IL_2fac_2;
																																					case 727:
																																						goto IL_2fc8_2;
																																					case 7:
																																						goto IL_2fd6_2;
																																					case 48:
																																					case 797:
																																						goto IL_2fe1_2;
																																					case 719:
																																						goto IL_2fff_2;
																																					case 988:
																																						goto IL_300d_2;
																																					case 311:
																																						goto IL_301b_2;
																																					case 714:
																																						goto IL_302e_2;
																																					case 106:
																																						goto IL_303c_2;
																																					case 997:
																																						goto IL_3047_2;
																																					case 263:
																																						goto IL_3055_2;
																																					case 478:
																																					case 583:
																																						goto IL_3063_2;
																																					case 442:
																																						goto IL_3071_2;
																																					case 347:
																																						goto IL_308f_2;
																																					case 1089:
																																						goto IL_309d_2;
																																					case 927:
																																					case 1227:
																																						goto IL_30b0_2;
																																					case 850:
																																						goto IL_30d2_2;
																																					case 88:
																																						goto IL_30e5_2;
																																					case 135:
																																						goto IL_30f0_2;
																																					case 161:
																																					case 768:
																																						goto IL_30fe_2;
																																					case 114:
																																						goto IL_3117_2;
																																					case 844:
																																						goto IL_3125_2;
																																					case 692:
																																					case 1156:
																																						goto IL_3133_2;
																																					case 498:
																																						goto IL_317c_2;
																																					case 288:
																																						goto IL_3190_2;
																																					case 425:
																																						goto IL_31a3_2;
																																					case 213:
																																						goto IL_31b1_2;
																																					case 146:
																																					case 778:
																																						goto IL_31bc_2;
																																					case 1190:
																																						goto IL_31d0_2;
																																					case 451:
																																						goto IL_320e_2;
																																					case 110:
																																						goto IL_3221_2;
																																					case 82:
																																						goto IL_322f_2;
																																					case 666:
																																					case 1234:
																																						goto IL_323d_2;
																																					case 648:
																																						goto IL_3260_2;
																																					case 1072:
																																						goto IL_326e_2;
																																					case 888:
																																						goto IL_327c_2;
																																					case 1079:
																																						goto IL_328f_2;
																																					case 431:
																																						goto IL_329a_2;
																																					case 623:
																																					case 756:
																																						goto IL_32a8_2;
																																					case 647:
																																						goto IL_32e6_2;
																																					case 465:
																																						goto IL_32f4_2;
																																					case 198:
																																						goto IL_3307_2;
																																					case 372:
																																						goto IL_331e_2;
																																					case 966:
																																					case 1104:
																																						goto IL_332c_2;
																																					case 452:
																																						goto IL_3340_2;
																																					case 527:
																																						goto IL_3388_2;
																																					case 1097:
																																					case 1257:
																																						goto IL_339b_2;
																																					case 378:
																																						goto IL_33bf_2;
																																					case 486:
																																						goto IL_33cd_2;
																																					case 840:
																																						goto IL_33db_2;
																																					case 142:
																																					case 1260:
																																						goto IL_33ee_2;
																																					case 57:
																																						goto IL_340c_2;
																																					case 854:
																																						goto IL_341a_2;
																																					case 1143:
																																						goto IL_3428_2;
																																					case 356:
																																					case 1263:
																																						goto IL_343b_2;
																																					case 1111:
																																						goto IL_3455_2;
																																					case 282:
																																					case 1265:
																																						goto IL_3468_2;
																																					case 1071:
																																						goto IL_34a8_2;
																																					case 829:
																																						goto IL_34bc_2;
																																					case 1267:
																																						goto IL_34d8_2;
																																					case 241:
																																						goto IL_34e6_2;
																																					case 1271:
																																						goto IL_3502_2;
																																					case 173:
																																						goto IL_3541_2;
																																					case 1277:
																																						goto IL_3554_2;
																																					case 61:
																																					case 1099:
																																						goto IL_3562_2;
																																					case 582:
																																						goto IL_3576_2;
																																					case 1056:
																																						goto IL_35b5_2;
																																					case 180:
																																					case 1283:
																																						goto IL_35c8_2;
																																					case 103:
																																						goto IL_35f3_2;
																																					case 129:
																																					case 1284:
																																						goto IL_360c_2;
																																					case 945:
																																						goto IL_3635_2;
																																					case 474:
																																						goto IL_3643_2;
																																					case 866:
																																						goto IL_3669_2;
																																					case 905:
																																						goto IL_3677_2;
																																					case 368:
																																					case 571:
																																						goto IL_3682_2;
																																					case 521:
																																						goto IL_36a6_2;
																																					case 744:
																																						goto IL_36b4_2;
																																					case 1086:
																																						goto IL_36cb_2;
																																					case 741:
																																						goto IL_36de_2;
																																					case 1261:
																																						goto IL_36ec_2;
																																					case 1026:
																																					case 1210:
																																						goto IL_36fa_2;
																																					case 759:
																																						goto IL_3718_2;
																																					case 941:
																																						goto IL_3726_2;
																																					case 509:
																																						goto IL_3734_2;
																																					case 227:
																																						goto IL_3747_2;
																																					case 20:
																																						goto IL_3752_2;
																																					case 15:
																																					case 725:
																																						goto IL_3760_2;
																																					case 8:
																																						goto IL_376a_2;
																																					case 79:
																																						goto IL_3778_2;
																																					case 252:
																																						goto IL_378b_2;
																																					case 569:
																																						goto IL_37a2_2;
																																					case 188:
																																					case 1220:
																																						goto IL_37b0_2;
																																					case 614:
																																						goto IL_37c4_2;
																																					case 11:
																																						goto IL_3811_2;
																																					case 1049:
																																						goto IL_381f_2;
																																					case 1160:
																																						goto IL_3832_2;
																																					case 658:
																																						goto IL_3840_2;
																																					case 193:
																																					case 244:
																																						goto IL_3854_2;
																																					case 925:
																																						goto IL_386d_2;
																																					case 287:
																																						goto IL_3880_2;
																																					case 211:
																																						goto IL_388e_2;
																																					case 1003:
																																					case 1237:
																																						goto IL_389c_2;
																																					case 587:
																																						goto IL_38b0_2;
																																					case 77:
																																						goto IL_3902_2;
																																					case 72:
																																						goto IL_3910_2;
																																					case 823:
																																						goto IL_3923_2;
																																					case 1136:
																																						goto IL_3931_2;
																																					case 31:
																																						goto IL_393f_2;
																																					case 433:
																																					case 901:
																																						goto IL_3953_2;
																																					case 677:
																																						goto IL_3961_2;
																																					case 1269:
																																						goto IL_3985_2;
																																					case 268:
																																						goto IL_3993_2;
																																					case 728:
																																						goto IL_39a6_2;
																																					case 186:
																																						goto IL_39b4_2;
																																					case 398:
																																						goto IL_39c2_2;
																																					case 849:
																																						goto IL_39d0_2;
																																					case 73:
																																					case 108:
																																						goto IL_39de_2;
																																					case 281:
																																						goto IL_39f2_2;
																																					case 327:
																																						goto IL_3a31_2;
																																					case 693:
																																						goto IL_3a4d_2;
																																					case 284:
																																					case 1122:
																																						goto IL_3a5b_2;
																																					case 909:
																																						goto IL_3a7d_2;
																																					case 1241:
																																						goto IL_3a90_2;
																																					case 675:
																																					case 982:
																																						goto IL_3a9e_2;
																																					case 407:
																																						goto IL_3ab2_2;
																																					case 1148:
																																						goto IL_3b03_2;
																																					case 544:
																																						goto IL_3b11_2;
																																					case 1245:
																																						goto IL_3b24_2;
																																					case 1183:
																																						goto IL_3b32_2;
																																					case 545:
																																					case 1233:
																																						goto IL_3b40_2;
																																					case 265:
																																						goto IL_3b54_2;
																																					case 968:
																																						goto IL_3bbc_2;
																																					case 420:
																																						goto IL_3bca_2;
																																					case 208:
																																						goto IL_3bdd_2;
																																					case 893:
																																						goto IL_3beb_2;
																																					case 699:
																																					case 991:
																																						goto IL_3bf6_2;
																																					case 228:
																																						goto IL_3c04_2;
																																					case 983:
																																						goto IL_3c28_2;
																																					case 749:
																																						goto IL_3c36_2;
																																					case 529:
																																						goto IL_3c49_2;
																																					case 803:
																																						goto IL_3c57_2;
																																					case 17:
																																					case 210:
																																						goto IL_3c65_2;
																																					case 256:
																																						goto IL_3c7d_2;
																																					case 1011:
																																						goto IL_3c8b_2;
																																					case 302:
																																						goto IL_3c99_2;
																																					case 513:
																																						goto IL_3cac_2;
																																					case 912:
																																						goto IL_3cb7_2;
																																					case 85:
																																					case 911:
																																						goto IL_3cc5_2;
																																					case 605:
																																						goto IL_3cf3_2;
																																					case 166:
																																						goto IL_3d06_2;
																																					case 1142:
																																						goto IL_3d14_2;
																																					case 162:
																																					case 1073:
																																						goto IL_3d22_2;
																																					case 1070:
																																						goto IL_3d45_2;
																																					case 1110:
																																						goto IL_3d53_2;
																																					case 360:
																																						goto IL_3d61_2;
																																					case 981:
																																						goto IL_3d7d_2;
																																					case 802:
																																						goto IL_3d8b_2;
																																					case 1054:
																																						goto IL_3d99_2;
																																					case 700:
																																					case 1229:
																																						goto IL_3da4_2;
																																					case 596:
																																						goto IL_3dc7_2;
																																					case 1172:
																																						goto IL_3dd5_2;
																																					case 626:
																																						goto IL_3de3_2;
																																					case 1199:
																																						goto IL_3df6_2;
																																					case 921:
																																						goto IL_3e04_2;
																																					case 764:
																																					case 807:
																																						goto IL_3e0f_2;
																																					case 522:
																																						goto IL_3e24_2;
																																					case 95:
																																						goto IL_3e37_2;
																																					case 953:
																																						goto IL_3e4e_2;
																																					case 488:
																																					case 632:
																																						goto IL_3e5c_2;
																																					case 299:
																																						goto IL_3e80_2;
																																					case 309:
																																						goto IL_3e8e_2;
																																					case 160:
																																						goto IL_3e9c_2;
																																					case 83:
																																						goto IL_3eaf_2;
																																					case 187:
																																						goto IL_3ebd_2;
																																					case 366:
																																					case 792:
																																						goto IL_3ecb_2;
																																					case 1232:
																																						goto IL_3ef7_2;
																																					case 1270:
																																						goto IL_3f05_2;
																																					case 156:
																																						goto IL_3f13_2;
																																					case 910:
																																						goto IL_3f26_2;
																																					case 385:
																																						goto IL_3f34_2;
																																					case 109:
																																					case 914:
																																						goto IL_3f42_2;
																																					case 758:
																																						goto IL_3f56_2;
																																					case 1009:
																																						goto IL_3fb1_2;
																																					case 858:
																																						goto IL_3fbf_2;
																																					case 1214:
																																						goto IL_3fd2_2;
																																					case 691:
																																						goto IL_3fe0_2;
																																					case 894:
																																					case 1226:
																																						goto IL_3fee_2;
																																					case 646:
																																						goto IL_4012_2;
																																					case 1164:
																																						goto IL_4020_2;
																																					case 1201:
																																						goto IL_402e_2;
																																					case 1041:
																																						goto IL_4041_2;
																																					case 765:
																																						goto IL_404f_2;
																																					case 884:
																																					case 915:
																																						goto IL_405d_2;
																																					case 746:
																																						goto IL_4071_2;
																																					case 1:
																																						goto IL_40c2_2;
																																					case 1005:
																																						goto IL_40d0_2;
																																					case 305:
																																						goto IL_40ec_2;
																																					case 194:
																																						goto IL_40fa_2;
																																					case 867:
																																					case 980:
																																						goto IL_4108_2;
																																					case 845:
																																						goto IL_4121_2;
																																					case 262:
																																					case 447:
																																						goto IL_4134_2;
																																					case 179:
																																						goto IL_4151_2;
																																					case 468:
																																						goto IL_418e_2;
																																					case 428:
																																						goto IL_41a1_2;
																																					case 130:
																																						goto IL_41af_2;
																																					case 141:
																																					case 704:
																																						goto IL_41bd_2;
																																					case 698:
																																						goto IL_41d1_2;
																																					case 51:
																																						goto IL_422d_2;
																																					case 50:
																																						goto IL_423b_2;
																																					case 757:
																																						goto IL_424e_2;
																																					case 1002:
																																						goto IL_425c_2;
																																					case 818:
																																					case 1085:
																																						goto IL_4267_2;
																																					case 743:
																																						goto IL_428a_2;
																																					case 1045:
																																						goto IL_4298_2;
																																					case 1228:
																																						goto IL_42a6_2;
																																					case 871:
																																						goto IL_42b9_2;
																																					case 2:
																																						goto IL_42c4_2;
																																					case 219:
																																						goto IL_42cf_2;
																																					case 793:
																																					case 1083:
																																						goto IL_42dd_2;
																																					case 531:
																																						goto IL_42f9_2;
																																					case 875:
																																						goto IL_4307_2;
																																					case 123:
																																					case 457:
																																						goto IL_4315_2;
																																					case 557:
																																						goto IL_432a_2;
																																					case 1274:
																																						goto IL_433d_2;
																																					case 144:
																																					case 549:
																																						goto IL_4348_2;
																																					case 26:
																																						goto IL_4361_2;
																																					case 961:
																																						goto IL_4374_2;
																																					case 1119:
																																						goto IL_4382_2;
																																					case 1039:
																																					case 1223:
																																						goto IL_4390_2;
																																					case 1082:
																																						goto IL_43aa_2;
																																					case 1212:
																																						goto IL_43bd_2;
																																					case 312:
																																						goto IL_43cb_2;
																																					case 304:
																																						goto IL_43d6_2;
																																					case 1163:
																																					case 1211:
																																						goto IL_43e4_2;
																																					case 217:
																																						goto IL_4438_2;
																																					case 919:
																																						goto IL_444b_2;
																																					case 892:
																																						goto IL_4459_2;
																																					case 122:
																																					case 753:
																																						goto IL_4467_2;
																																					case 1197:
																																						goto IL_448a_2;
																																					case 200:
																																						goto IL_4498_2;
																																					case 151:
																																						goto IL_44a6_2;
																																					case 1135:
																																						goto IL_44c2_2;
																																					case 418:
																																						goto IL_44cd_2;
																																					case 656:
																																						goto IL_44db_2;
																																					case 918:
																																					case 1051:
																																						goto IL_44e9_2;
																																					case 482:
																																						goto IL_4502_2;
																																					case 47:
																																					case 1200:
																																						goto IL_4515_2;
																																					case 1166:
																																						goto IL_4533_2;
																																					case 943:
																																						goto IL_4541_2;
																																					case 607:
																																						goto IL_454f_2;
																																					case 232:
																																						goto IL_456b_2;
																																					case 642:
																																						goto IL_4579_2;
																																					case 23:
																																					case 1080:
																																						goto IL_4584_2;
																																					case 827:
																																						goto IL_4598_2;
																																					case 76:
																																						goto IL_45d0_2;
																																					case 400:
																																						goto IL_45e3_2;
																																					case 339:
																																						goto IL_45f1_2;
																																					case 832:
																																					case 944:
																																						goto IL_45fc_2;
																																					case 296:
																																						goto IL_4610_2;
																																					case 671:
																																						goto IL_464f_2;
																																					case 998:
																																						goto IL_466b_2;
																																					case 139:
																																						goto IL_4679_2;
																																					case 364:
																																					case 970:
																																						goto IL_4690_2;
																																					case 1025:
																																						goto IL_46aa_2;
																																					case 70:
																																						goto IL_46bd_2;
																																					case 471:
																																						goto IL_46cb_2;
																																					case 735:
																																						goto IL_46e2_2;
																																					case 487:
																																					case 592:
																																						goto IL_46f0_2;
																																					case 333:
																																						goto IL_4728_2;
																																					case 1280:
																																						goto IL_4745_2;
																																					case 723:
																																						goto IL_4761_2;
																																					case 872:
																																					case 1048:
																																						goto IL_476f_2;
																																					case 293:
																																						goto IL_477d_2;
																																					case 1117:
																																						goto IL_479b_2;
																																					case 1064:
																																						goto IL_47a9_2;
																																					case 924:
																																						goto IL_47bc_2;
																																					case 774:
																																						goto IL_47ca_2;
																																					case 6:
																																					case 641:
																																						goto IL_47d5_2;
																																					case 938:
																																						goto IL_47e3_2;
																																					case 1188:
																																						goto IL_4801_2;
																																					case 763:
																																						goto IL_480f_2;
																																					case 534:
																																						goto IL_4822_2;
																																					case 877:
																																						goto IL_4830_2;
																																					case 826:
																																					case 1250:
																																						goto IL_483e_2;
																																					case 999:
																																						goto IL_4852_2;
																																					case 236:
																																						goto IL_488f_2;
																																					case 939:
																																						goto IL_48a2_2;
																																					case 1115:
																																						goto IL_48ad_2;
																																					case 811:
																																					case 1035:
																																						goto IL_48bb_2;
																																					case 1012:
																																						goto IL_48cf_2;
																																					case 519:
																																						goto IL_4907_2;
																																					case 773:
																																						goto IL_491a_2;
																																					case 337:
																																						goto IL_4928_2;
																																					case 315:
																																					case 891:
																																						goto IL_4936_2;
																																					case 71:
																																						goto IL_494a_2;
																																					case 620:
																																						goto IL_4987_2;
																																					case 56:
																																						goto IL_499a_2;
																																					case 649:
																																						goto IL_49a8_2;
																																					case 190:
																																					case 1208:
																																						goto IL_49b3_2;
																																					case 1278:
																																						goto IL_49c7_2;
																																					case 806:
																																						goto IL_4a0f_2;
																																					case 1141:
																																						goto IL_4a1d_2;
																																					case 1219:
																																						goto IL_4a30_2;
																																					case 985:
																																						goto IL_4a3e_2;
																																					case 672:
																																					case 777:
																																						goto IL_4a49_2;
																																					case 414:
																																						goto IL_4a81_2;
																																					case 881:
																																						goto IL_4a95_2;
																																					case 247:
																																						goto IL_4aa8_2;
																																					case 959:
																																						goto IL_4ab6_2;
																																					case 120:
																																					case 381:
																																						goto IL_4ac4_2;
																																					case 696:
																																						goto IL_4ad8_2;
																																					case 69:
																																						goto IL_4b29_2;
																																					case 651:
																																						goto IL_4b37_2;
																																					case 510:
																																						goto IL_4b4a_2;
																																					case 389:
																																						goto IL_4b58_2;
																																					case 497:
																																					case 1075:
																																						goto IL_4b63_2;
																																					case 136:
																																						goto IL_4b81_2;
																																					case 908:
																																						goto IL_4b8f_2;
																																					case 349:
																																						goto IL_4ba6_2;
																																					case 321:
																																						goto IL_4bb9_2;
																																					case 178:
																																						goto IL_4bc7_2;
																																					case 432:
																																					case 490:
																																						goto IL_4bd5_2;
																																					case 403:
																																						goto IL_4bee_2;
																																					case 220:
																																						goto IL_4c01_2;
																																					case 963:
																																						goto IL_4c0c_2;
																																					case 63:
																																					case 115:
																																						goto IL_4c1a_2;
																																					case 1095:
																																						goto IL_4c3d_2;
																																					case 511:
																																						goto IL_4c4b_2;
																																					case 595:
																																						goto IL_4c59_2;
																																					case 564:
																																						goto IL_4c6c_2;
																																					case 253:
																																						goto IL_4c7a_2;
																																					case 767:
																																					case 1078:
																																						goto IL_4c88_2;
																																					case 1038:
																																						goto IL_4ca5_2;
																																					case 645:
																																						goto IL_4cf6_2;
																																					case 633:
																																						goto IL_4d04_2;
																																					case 717:
																																						goto IL_4d17_2;
																																					case 1186:
																																						goto IL_4d25_2;
																																					case 238:
																																					case 382:
																																						goto IL_4d30_2;
																																					case 643:
																																						goto IL_4d53_2;
																																					case 619:
																																						goto IL_4d61_2;
																																					case 883:
																																						goto IL_4d6f_2;
																																					case 1057:
																																						goto IL_4d82_2;
																																					case 1174:
																																						goto IL_4d90_2;
																																					case 285:
																																					case 523:
																																						goto IL_4d9e_2;
																																					case 920:
																																						goto IL_4db7_2;
																																					case 204:
																																						goto IL_4dca_2;
																																					case 556:
																																						goto IL_4dd8_2;
																																					case 535:
																																					case 846:
																																						goto IL_4de6_2;
																																					case 547:
																																						goto IL_4e03_2;
																																					case 60:
																																						goto IL_4e54_2;
																																					case 195:
																																						goto IL_4e62_2;
																																					case 1179:
																																						goto IL_4e75_2;
																																					case 536:
																																						goto IL_4e83_2;
																																					case 799:
																																					case 1184:
																																						goto IL_4e91_2;
																																					case 379:
																																						goto IL_4eaa_2;
																																					case 660:
																																						goto IL_4ebd_2;
																																					case 352:
																																						goto IL_4ecb_2;
																																					case 776:
																																					case 965:
																																						goto IL_4ed6_2;
																																					case 1262:
																																						goto IL_4ef4_2;
																																					case 543:
																																						goto IL_4f02_2;
																																					case 84:
																																						goto IL_4f10_2;
																																					case 1185:
																																						goto IL_4f23_2;
																																					case 469:
																																						goto IL_4f31_2;
																																					case 494:
																																						goto IL_4f3c_2;
																																					case 1150:
																																						goto IL_4f4a_2;
																																					case 215:
																																					case 313:
																																						goto IL_4f58_2;
																																					case 690:
																																						goto IL_4f81_2;
																																					case 775:
																																						goto IL_4f8f_2;
																																					case 554:
																																					case 578:
																																						goto IL_4fa2_2;
																																					case 1127:
																																						goto IL_4fb0_2;
																																					case 165:
																																						goto IL_4fdd_2;
																																					case 616:
																																						goto IL_4feb_2;
																																					case 520:
																																						goto IL_4ffe_2;
																																					case 49:
																																						goto IL_5009_2;
																																					case 65:
																																					case 1105:
																																						goto IL_5017_2;
																																					case 1146:
																																						goto IL_5055_2;
																																					case 819:
																																						goto IL_5069_2;
																																					case 137:
																																						goto IL_5085_2;
																																					case 1037:
																																						goto IL_5093_2;
																																					case 181:
																																					case 598:
																																						goto IL_50a1_2;
																																					case 786:
																																						goto IL_510f_2;
																																					case 681:
																																						goto IL_5122_2;
																																					case 359:
																																						goto IL_5130_2;
																																					case 1081:
																																					case 1158:
																																						goto IL_513b_2;
																																					case 1094:
																																						goto IL_514f_2;
																																					case 28:
																																						goto IL_518d_2;
																																					case 1074:
																																						goto IL_51a0_2;
																																					case 1109:
																																						goto IL_51ae_2;
																																					case 532:
																																					case 766:
																																						goto IL_51c5_2;
																																					case 936:
																																						goto IL_51e8_2;
																																					case 132:
																																						goto IL_51f6_2;
																																					case 1134:
																																						goto IL_5204_2;
																																					case 835:
																																						goto IL_5217_2;
																																					case 814:
																																						goto IL_5222_2;
																																					case 126:
																																					case 143:
																																						goto IL_5230_2;
																																					case 560:
																																						goto IL_5254_2;
																																					case 639:
																																						goto IL_5262_2;
																																					case 413:
																																						goto IL_5270_2;
																																					case 695:
																																						goto IL_5283_2;
																																					case 326:
																																						goto IL_5291_2;
																																					case 222:
																																					case 460:
																																						goto IL_52a8_2;
																																					case 283:
																																						goto IL_52bc_2;
																																					case 954:
																																						goto IL_5309_2;
																																					case 994:
																																						goto IL_5317_2;
																																					case 1116:
																																						goto IL_532a_2;
																																					case 54:
																																						goto IL_5338_2;
																																					case 861:
																																					case 1033:
																																						goto IL_5343_2;
																																					case 887:
																																						goto IL_5360_2;
																																					case 94:
																																						goto IL_539f_2;
																																					case 636:
																																						goto IL_53b2_2;
																																					case 176:
																																						goto IL_53c0_2;
																																					case 668:
																																						goto IL_53ce_2;
																																					case 1000:
																																					case 1154:
																																						goto IL_53d9_2;
																																					case 434:
																																						goto IL_5402_2;
																																					case 1217:
																																						goto IL_5424_2;
																																					case 922:
																																						goto IL_5432_2;
																																					case 540:
																																					case 1007:
																																						goto IL_5440_2;
																																					case 942:
																																						goto IL_5454_2;
																																					case 824:
																																						goto IL_5493_2;
																																					case 1275:
																																						goto IL_54af_2;
																																					case 1282:
																																						goto IL_54ba_2;
																																					case 392:
																																					case 1059:
																																						goto IL_54c8_2;
																																					case 1040:
																																						goto IL_54e5_2;
																																					case 610:
																																						goto IL_551d_2;
																																					case 274:
																																						goto IL_5530_2;
																																					case 585:
																																						goto IL_553e_2;
																																					case 393:
																																					case 1191:
																																						goto IL_554c_2;
																																					case 555:
																																						goto IL_558a_2;
																																					case 950:
																																						goto IL_559d_2;
																																					case 254:
																																					case 473:
																																						goto IL_55a8_2;
																																					case 134:
																																						goto IL_55bc_2;
																																					case 673:
																																						goto IL_55fb_2;
																																					case 145:
																																						goto end_IL_143f_2;
																																					case 599:
																																						goto IL_561c_2;
																																					case 35:
																																					case 1196:
																																						goto IL_5627_2;
																																					case 754:
																																						goto IL_5685_2;
																																					case 898:
																																						goto IL_5698_2;
																																					case 345:
																																						goto IL_56a6_2;
																																					case 206:
																																					case 1175:
																																						goto IL_56b4_2;
																																					case 629:
																																						goto IL_56c2_2;
																																					case 975:
																																						goto IL_56e6_2;
																																					case 836:
																																						goto IL_56f4_2;
																																					case 196:
																																						goto IL_5707_2;
																																					case 900:
																																						goto IL_5715_2;
																																					case 154:
																																					case 1198:
																																						goto IL_5723_2;
																																					case 1231:
																																						goto IL_5737_2;
																																					case 157:
																																						goto IL_5789_2;
																																					case 611:
																																						goto IL_5797_2;
																																					case 1181:
																																						goto IL_57aa_2;
																																					case 794:
																																						goto IL_57b8_2;
																																					case 597:
																																					case 747:
																																						goto IL_57c6_2;
																																					case 295:
																																						goto IL_57fe_2;
																																					case 383:
																																						goto IL_5812_2;
																																					case 384:
																																						goto IL_5825_2;
																																					case 581:
																																						goto IL_5833_2;
																																					case 279:
																																					case 1281:
																																						goto IL_583e_2;
																																					case 709:
																																						goto IL_5852_2;
																																					case 237:
																																						goto IL_5891_2;
																																					case 842:
																																						goto IL_58a4_2;
																																					case 601:
																																						goto IL_58b2_2;
																																					case 257:
																																					case 752:
																																						goto IL_58bd_2;
																																					case 1008:
																																						goto IL_58d1_2;
																																					case 1248:
																																						goto IL_5909_2;
																																					case 1128:
																																						goto IL_591c_2;
																																					case 150:
																																						goto IL_592a_2;
																																					case 387:
																																					case 859:
																																						goto IL_5938_2;
																																					case 724:
																																						goto IL_594c_2;
																																					case 1144:
																																						goto IL_598b_2;
																																					case 787:
																																						goto IL_599e_2;
																																					case 1016:
																																						goto IL_59a9_2;
																																					case 1047:
																																					case 1157:
																																						goto IL_59b7_2;
																																					case 508:
																																						goto IL_59f5_2;
																																					case 769:
																																						goto IL_5a11_2;
																																					case 1065:
																																						goto IL_5a28_2;
																																					case 53:
																																					case 589:
																																						goto IL_5a36_2;
																																					case 512:
																																						goto IL_5a4a_2;
																																					case 591:
																																						goto IL_5a89_2;
																																					case 448:
																																						goto IL_5a9c_2;
																																					case 1021:
																																						goto IL_5aaa_2;
																																					case 453:
																																					case 734:
																																						goto IL_5ab5_2;
																																					case 615:
																																						goto IL_5ac9_2;
																																					case 1206:
																																						goto IL_5b08_2;
																																					case 627:
																																						goto IL_5b1b_2;
																																					case 1036:
																																						goto IL_5b29_2;
																																					case 231:
																																					case 809:
																																						goto IL_5b37_2;
																																					case 730:
																																						goto IL_5b4b_2;
																																					case 12:
																																						goto IL_5bcf_2;
																																					case 710:
																																						goto IL_5bdd_2;
																																					case 576:
																																						goto IL_5bf0_2;
																																					case 795:
																																						goto IL_5bfb_2;
																																					case 102:
																																					case 889:
																																						goto IL_5c09_2;
																																					case 455:
																																						goto IL_5c47_2;
																																					case 653:
																																						goto IL_5c5e_2;
																																					case 318:
																																						goto IL_5c6e_2;
																																					case 514:
																																						goto IL_5c79_2;
																																					case 25:
																																					case 30:
																																					case 33:
																																					case 34:
																																					case 38:
																																					case 43:
																																					case 52:
																																					case 97:
																																					case 98:
																																					case 101:
																																					case 125:
																																					case 148:
																																					case 158:
																																					case 164:
																																					case 169:
																																					case 182:
																																					case 191:
																																					case 199:
																																					case 201:
																																					case 205:
																																					case 216:
																																					case 230:
																																					case 233:
																																					case 246:
																																					case 248:
																																					case 250:
																																					case 264:
																																					case 275:
																																					case 277:
																																					case 294:
																																					case 297:
																																					case 300:
																																					case 310:
																																					case 330:
																																					case 338:
																																					case 350:
																																					case 374:
																																					case 388:
																																					case 397:
																																					case 406:
																																					case 408:
																																					case 415:
																																					case 417:
																																					case 419:
																																					case 421:
																																					case 424:
																																					case 429:
																																					case 438:
																																					case 454:
																																					case 456:
																																					case 458:
																																					case 463:
																																					case 476:
																																					case 480:
																																					case 496:
																																					case 502:
																																					case 504:
																																					case 516:
																																					case 525:
																																					case 526:
																																					case 530:
																																					case 533:
																																					case 537:
																																					case 538:
																																					case 570:
																																					case 572:
																																					case 577:
																																					case 579:
																																					case 588:
																																					case 608:
																																					case 609:
																																					case 622:
																																					case 624:
																																					case 644:
																																					case 652:
																																					case 654:
																																					case 655:
																																					case 664:
																																					case 665:
																																					case 667:
																																					case 674:
																																					case 680:
																																					case 686:
																																					case 689:
																																					case 703:
																																					case 705:
																																					case 707:
																																					case 708:
																																					case 711:
																																					case 713:
																																					case 716:
																																					case 718:
																																					case 722:
																																					case 729:
																																					case 732:
																																					case 738:
																																					case 745:
																																					case 748:
																																					case 760:
																																					case 762:
																																					case 772:
																																					case 791:
																																					case 798:
																																					case 804:
																																					case 833:
																																					case 834:
																																					case 841:
																																					case 852:
																																					case 860:
																																					case 869:
																																					case 876:
																																					case 879:
																																					case 885:
																																					case 886:
																																					case 899:
																																					case 902:
																																					case 903:
																																					case 913:
																																					case 930:
																																					case 931:
																																					case 932:
																																					case 933:
																																					case 940:
																																					case 949:
																																					case 960:
																																					case 972:
																																					case 974:
																																					case 976:
																																					case 978:
																																					case 1004:
																																					case 1017:
																																					case 1027:
																																					case 1028:
																																					case 1084:
																																					case 1088:
																																					case 1091:
																																					case 1096:
																																					case 1102:
																																					case 1106:
																																					case 1107:
																																					case 1124:
																																					case 1125:
																																					case 1130:
																																					case 1132:
																																					case 1168:
																																					case 1176:
																																					case 1182:
																																					case 1193:
																																					case 1194:
																																					case 1195:
																																					case 1218:
																																					case 1225:
																																					case 1240:
																																					case 1243:
																																					case 1244:
																																					case 1249:
																																					case 1256:
																																					case 1258:
																																					case 1273:
																																						goto end_IL_14b2_2;
																																					case 0:
																																					case 3:
																																					case 4:
																																					case 10:
																																					case 13:
																																					case 22:
																																					case 32:
																																					case 37:
																																					case 45:
																																					case 46:
																																					case 55:
																																					case 58:
																																					case 62:
																																					case 64:
																																					case 75:
																																					case 81:
																																					case 89:
																																					case 91:
																																					case 92:
																																					case 104:
																																					case 113:
																																					case 119:
																																					case 149:
																																					case 163:
																																					case 202:
																																					case 207:
																																					case 214:
																																					case 221:
																																					case 224:
																																					case 242:
																																					case 243:
																																					case 249:
																																					case 259:
																																					case 260:
																																					case 266:
																																					case 267:
																																					case 278:
																																					case 290:
																																					case 291:
																																					case 303:
																																					case 306:
																																					case 316:
																																					case 322:
																																					case 329:
																																					case 334:
																																					case 354:
																																					case 355:
																																					case 358:
																																					case 363:
																																					case 370:
																																					case 399:
																																					case 404:
																																					case 412:
																																					case 435:
																																					case 437:
																																					case 440:
																																					case 441:
																																					case 444:
																																					case 472:
																																					case 479:
																																					case 485:
																																					case 491:
																																					case 500:
																																					case 505:
																																					case 515:
																																					case 518:
																																					case 539:
																																					case 542:
																																					case 548:
																																					case 553:
																																					case 562:
																																					case 565:
																																					case 568:
																																					case 573:
																																					case 580:
																																					case 586:
																																					case 593:
																																					case 602:
																																					case 604:
																																					case 618:
																																					case 621:
																																					case 630:
																																					case 634:
																																					case 635:
																																					case 638:
																																					case 640:
																																					case 679:
																																					case 683:
																																					case 685:
																																					case 701:
																																					case 715:
																																					case 720:
																																					case 740:
																																					case 742:
																																					case 750:
																																					case 755:
																																					case 770:
																																					case 771:
																																					case 784:
																																					case 821:
																																					case 831:
																																					case 837:
																																					case 847:
																																					case 853:
																																					case 873:
																																					case 878:
																																					case 880:
																																					case 882:
																																					case 890:
																																					case 929:
																																					case 935:
																																					case 946:
																																					case 947:
																																					case 951:
																																					case 952:
																																					case 964:
																																					case 979:
																																					case 989:
																																					case 1010:
																																					case 1022:
																																					case 1024:
																																					case 1030:
																																					case 1044:
																																					case 1052:
																																					case 1053:
																																					case 1055:
																																					case 1060:
																																					case 1062:
																																					case 1063:
																																					case 1066:
																																					case 1114:
																																					case 1118:
																																					case 1121:
																																					case 1126:
																																					case 1133:
																																					case 1145:
																																					case 1147:
																																					case 1161:
																																					case 1162:
																																					case 1169:
																																					case 1202:
																																					case 1203:
																																					case 1207:
																																					case 1221:
																																					case 1222:
																																					case 1230:
																																					case 1235:
																																					case 1236:
																																					case 1238:
																																					case 1239:
																																					case 1253:
																																					case 1259:
																																					case 1264:
																																					case 1266:
																																					case 1268:
																																					case 1272:
																																					case 1279:
																																					case 1285:
																																						goto IL_5ca0_2;
																																					case 308:
																																						num = 485;
																																						goto IL_5ca0_2;
																																					case 678:
																																						ptr2 = ptr;
																																						goto case 308;
																																					case 348:
																																						ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateNodegetInterfaceType.IsApplicationTrustedToRunGenericSecurityDescriptor);
																																						goto case 678;
																																					case 44:
																																						array7[0] = this;
																																						goto case 348;
																																					case 128:
																																						array7 = new object[24];
																																						goto case 44;
																																					case 612:
																																						array6 = new long[7];
																																						num = 128;
																																						goto case 128;
																																					case 594:
																																						array5 = new int[7];
																																						goto case 612;
																																					case 733:
																																						array4 = new int[7];
																																						goto case 594;
																																					case 331:
																																						array3 = new object[7];
																																						goto case 733;
																																					case 16:
																																						array2 = new byte[7];
																																						goto case 331;
																																					case 240:
																																						num4 = num2 * 8;
																																						goto case 16;
																																					case 342:
																																						num3 = num2 * 4;
																																						goto case 240;
																																					case 183:
																																						num2 = 1;
																																						goto case 342;
																																					case 184:
																																						goto end_IL_25e0;
																																					case 436:
																																					case 848:
																																						return;
																																					}
																																					continue;
																																				}
																																				ptr2 += 8;
																																				goto IL_5ca0_2;
																																				continue;
																																				end_IL_143f_2:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_560e_2;
																																	continue;
																																	end_IL_14b2_2:
																																	break;
																																	IL_14b2_2:;
																																}
																																break;
																																IL_14c2_2:;
																															}
																															break;
																														}
																														goto IL_15bb_2;
																														IL_3455_2:
																														num6--;
																														goto IL_5ca0_2;
																														IL_15bb_2:
																														if (71 > b)
																														{
																															break;
																														}
																														goto IL_343b_2;
																														IL_343b_2:
																														global::_003CModule_003E.float_95 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_3455_2;
																													}
																													break;
																												}
																												goto IL_19e2_2;
																												IL_213f_2:
																												array2[num6] = 0;
																												goto IL_214d_2;
																												IL_19e2_2:
																												if (70 <= b)
																												{
																													goto IL_19ed_2;
																												}
																												goto IL_1a31_2;
																												IL_19ed_2:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (float)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_1a18_2;
																												IL_1a18_2:
																												array2[num6 - 1] = 3;
																												goto IL_5ca0_2;
																												IL_1a31_2:
																												if (69 < b)
																												{
																													break;
																												}
																												num = 492;
																												goto IL_1a48_2;
																												IL_214d_2:
																												num6++;
																												goto IL_215b_2;
																												IL_1a48_2:
																												if (69 > b)
																												{
																													break;
																												}
																												num = 395;
																												goto IL_211b_2;
																												IL_215b_2:
																												ptr2 += 8;
																												goto IL_5ca0_2;
																												IL_211b_2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																												goto IL_213f_2;
																											}
																											break;
																										}
																										goto IL_159d_2;
																										IL_1c18_2:
																										num6--;
																										goto IL_5ca0_2;
																										IL_159d_2:
																										global::_003CModule_003E.list_13 = (List<long>)array3[num6 - 1];
																										goto IL_1c18_2;
																									}
																									break;
																								}
																								goto IL_3669_2;
																								IL_3811_2:
																								num6--;
																								goto IL_381f_2;
																								IL_3669_2:
																								if (75 >= b)
																								{
																									goto IL_3677_2;
																								}
																								goto IL_3747_2;
																								IL_3677_2:
																								if (75 <= b)
																								{
																									goto IL_3682_2;
																								}
																								goto IL_36de_2;
																								IL_3682_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_36a6_2;
																								IL_36a6_2:
																								array2[num6] = 0;
																								goto IL_36b4_2;
																								IL_36b4_2:
																								num6++;
																								num = 1086;
																								goto IL_36cb_2;
																								IL_36cb_2:
																								ptr2 += 8;
																								goto IL_5ca0_2;
																								IL_36de_2:
																								if (74 < b)
																								{
																									break;
																								}
																								goto IL_36ec_2;
																								IL_36ec_2:
																								if (74 > b)
																								{
																									break;
																								}
																								goto IL_36fa_2;
																								IL_36fa_2:
																								array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																								goto IL_3718_2;
																								IL_3718_2:
																								array2[num6] = 5;
																								goto IL_3726_2;
																								IL_3726_2:
																								num6++;
																								goto IL_3734_2;
																								IL_3734_2:
																								ptr2 += 8;
																								goto IL_5ca0_2;
																								IL_3747_2:
																								if (76 >= b)
																								{
																									goto IL_3752_2;
																								}
																								goto IL_378b_2;
																								IL_3752_2:
																								if (76 > b)
																								{
																									break;
																								}
																								goto IL_3760_2;
																								IL_3760_2:
																								array3[num6] = null;
																								goto IL_376a_2;
																								IL_376a_2:
																								array2[num6] = 5;
																								goto IL_3778_2;
																								IL_3778_2:
																								num6++;
																								goto IL_5ca0_2;
																								IL_378b_2:
																								if (77 < b)
																								{
																									break;
																								}
																								num = 569;
																								goto IL_37a2_2;
																								IL_381f_2:
																								ptr2 += 8;
																								goto IL_5ca0_2;
																								IL_37a2_2:
																								if (77 > b)
																								{
																									break;
																								}
																								goto IL_37b0_2;
																								IL_37b0_2:
																								array2[num6 - 2] = 0;
																								goto IL_37c4_2;
																								IL_37c4_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((UnityEngine.Object)(object)(GameEntityManager)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																								goto IL_3811_2;
																							}
																							break;
																						}
																						goto IL_15ce_2;
																						IL_1ee1_2:
																						num6++;
																						goto IL_1eef_2;
																						IL_15ce_2:
																						if (68 <= b)
																						{
																							goto IL_15d9_2;
																						}
																						goto IL_1606_2;
																						IL_15d9_2:
																						global::_003CModule_003E.int_202 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_15f3_2;
																						IL_15f3_2:
																						num6--;
																						goto IL_5ca0_2;
																						IL_1606_2:
																						if (63 >= b)
																						{
																							goto IL_1611_2;
																						}
																						goto IL_162f_2;
																						IL_1611_2:
																						if (63 > b)
																						{
																							goto IL_161c_2;
																						}
																						goto IL_163f_2;
																						IL_161c_2:
																						if (60 >= b)
																						{
																							goto IL_1fd4_2;
																						}
																						goto IL_294b_2;
																						IL_1fd4_2:
																						if (60 <= b)
																						{
																							goto IL_1fdf_2;
																						}
																						goto IL_2045_2;
																						IL_1fdf_2:
																						array2[num6 - 1] = 3;
																						goto IL_1ff3_2;
																						IL_1ff3_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_2032_2;
																						IL_2032_2:
																						ptr2 += 8;
																						goto IL_5ca0_2;
																						IL_2045_2:
																						if (59 < b)
																						{
																							break;
																						}
																						goto IL_2053_2;
																						IL_2053_2:
																						if (59 > b)
																						{
																							break;
																						}
																						goto IL_2061_2;
																						IL_2061_2:
																						array2[num6] = 0;
																						goto IL_206f_2;
																						IL_206f_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_2093_2;
																						IL_2093_2:
																						num6++;
																						goto IL_20a1_2;
																						IL_20a1_2:
																						ptr2 += 8;
																						goto IL_5ca0_2;
																						IL_294b_2:
																						if (61 >= b)
																						{
																							goto IL_2956_2;
																						}
																						goto IL_29af_2;
																						IL_2956_2:
																						if (61 > b)
																						{
																							break;
																						}
																						goto IL_2964_2;
																						IL_2964_2:
																						array2[num6] = 15;
																						goto IL_2972_2;
																						IL_2972_2:
																						array4[num6] = *(int*)(ptr2 + num3);
																						num = 1187;
																						goto IL_298e_2;
																						IL_298e_2:
																						ptr2 += 8;
																						goto IL_299c_2;
																						IL_299c_2:
																						num6++;
																						goto IL_5ca0_2;
																						IL_29af_2:
																						if (62 < b)
																						{
																							break;
																						}
																						goto IL_3554_2;
																						IL_3554_2:
																						if (62 > b)
																						{
																							break;
																						}
																						goto IL_3562_2;
																						IL_3562_2:
																						array2[num6 - 1] = 3;
																						goto IL_3576_2;
																						IL_3576_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_35b5_2;
																						IL_35b5_2:
																						ptr2 += 8;
																						goto IL_5ca0_2;
																						IL_163f_2:
																						global::_003CModule_003E.list_12 = (List<int>)array3[num6 - 1];
																						goto IL_166d_2;
																						IL_166d_2:
																						num6--;
																						goto IL_5ca0_2;
																						IL_162f_2:
																						if (65 < b)
																						{
																							goto IL_1680_2;
																						}
																						goto IL_1d56_2;
																						IL_1d56_2:
																						if (65 <= b)
																						{
																							goto IL_1d61_2;
																						}
																						goto IL_1d8d_2;
																						IL_1d61_2:
																						global::_003CModule_003E.oCPITugY_007B_002D = (List<int>)array3[num6 - 1];
																						goto IL_1d7a_2;
																						IL_1d7a_2:
																						num6--;
																						goto IL_5ca0_2;
																						IL_1d8d_2:
																						if (64 < b)
																						{
																							break;
																						}
																						goto IL_1d9b_2;
																						IL_1d9b_2:
																						if (64 > b)
																						{
																							break;
																						}
																						num = 68;
																						goto IL_1db2_2;
																						IL_1eef_2:
																						ptr2 += 8;
																						goto IL_5ca0_2;
																						IL_1db2_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1eba_2;
																						IL_1eba_2:
																						array2[num6 - 1] = 0;
																						goto IL_5ca0_2;
																						IL_1680_2:
																						if (66 < b)
																						{
																							goto IL_168b_2;
																						}
																						goto IL_16ac_2;
																						IL_168b_2:
																						if (67 < b)
																						{
																							break;
																						}
																						goto IL_1699_2;
																						IL_1699_2:
																						if (67 > b)
																						{
																							break;
																						}
																						goto IL_35c8_2;
																						IL_35c8_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_35f3_2;
																						IL_35f3_2:
																						array2[num6 - 1] = 1;
																						goto IL_5ca0_2;
																						IL_16ac_2:
																						if (66 > b)
																						{
																							break;
																						}
																						goto IL_1a64_2;
																						IL_1a64_2:
																						array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																						goto IL_1ed3_2;
																						IL_1ed3_2:
																						array2[num6] = 5;
																						goto IL_1ee1_2;
																					}
																					break;
																				}
																				goto IL_165a_2;
																				IL_291e_2:
																				global::_003CModule_003E.int_201 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_2938_2;
																				IL_165a_2:
																				if (58 > b)
																				{
																					goto IL_183c_2;
																				}
																				goto IL_29c2_2;
																				IL_29c2_2:
																				((delegate*<ref Vector3, float, float, float, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)getUIContextReturnType[array4[num6 - 4]])(array3[num6 - 4], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), array7, array5), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																				goto IL_2a5c_2;
																				IL_2a5c_2:
																				num6 -= 4;
																				goto IL_2a6a_2;
																				IL_2a6a_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_183c_2:
																				if (48 >= b)
																				{
																					goto IL_184a_2;
																				}
																				goto IL_1900_2;
																				IL_184a_2:
																				if (48 > b)
																				{
																					goto IL_1858_2;
																				}
																				goto IL_23b6_2;
																				IL_1858_2:
																				if (43 >= b)
																				{
																					goto IL_1866_2;
																				}
																				goto IL_21f5_2;
																				IL_1866_2:
																				if (43 > b)
																				{
																					goto IL_1874_2;
																				}
																				goto IL_20b4_2;
																				IL_1874_2:
																				if (41 >= b)
																				{
																					goto IL_187f_2;
																				}
																				goto IL_18ae_2;
																				IL_187f_2:
																				if (41 > b)
																				{
																					goto IL_188d_2;
																				}
																				goto IL_1f68_2;
																				IL_188d_2:
																				if (40 < b)
																				{
																					break;
																				}
																				goto IL_189b_2;
																				IL_189b_2:
																				if (40 > b)
																				{
																					break;
																				}
																				goto IL_339b_2;
																				IL_339b_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																				goto IL_33bf_2;
																				IL_33bf_2:
																				array2[num6] = 0;
																				goto IL_33cd_2;
																				IL_33cd_2:
																				num6++;
																				goto IL_33db_2;
																				IL_33db_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_1f68_2:
																				array2[num6 - 2] = 0;
																				goto IL_1f7c_2;
																				IL_1f7c_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, int, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_2497_2;
																				IL_2497_2:
																				num6--;
																				goto IL_24a5_2;
																				IL_24a5_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_18ae_2:
																				if (42 < b)
																				{
																					break;
																				}
																				goto IL_18bc_2;
																				IL_18bc_2:
																				if (42 > b)
																				{
																					break;
																				}
																				goto IL_18ca_2;
																				IL_18ca_2:
																				global::_003CModule_003E.int_199 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				num = 669;
																				goto IL_18ed_2;
																				IL_18ed_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_20b4_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_20f4_2;
																				IL_20f4_2:
																				array2[num6 - 2] = 3;
																				goto IL_2108_2;
																				IL_2108_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_21f5_2:
																				if (45 >= b)
																				{
																					goto IL_2200_2;
																				}
																				goto IL_223a_2;
																				IL_2200_2:
																				if (45 <= b)
																				{
																					goto IL_220e_2;
																				}
																				goto IL_2805_2;
																				IL_220e_2:
																				global::_003CModule_003E.gameEntityManager_3 = (GameEntityManager)array3[num6 - 1];
																				goto IL_2227_2;
																				IL_2227_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_2805_2:
																				if (44 < b)
																				{
																					break;
																				}
																				goto IL_2813_2;
																				IL_2813_2:
																				if (44 > b)
																				{
																					break;
																				}
																				goto IL_2821_2;
																				IL_2821_2:
																				array2[num6] = 5;
																				goto IL_282f_2;
																				IL_282f_2:
																				array3[num6] = ((delegate*<GameEntityManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																				goto IL_284d_2;
																				IL_284d_2:
																				num6++;
																				num = 552;
																				goto IL_2864_2;
																				IL_2864_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_223a_2:
																				if (46 < b)
																				{
																					goto IL_2245_2;
																				}
																				num = 335;
																				goto IL_22c0_2;
																				IL_2245_2:
																				if (47 < b)
																				{
																					break;
																				}
																				goto IL_2253_2;
																				IL_2253_2:
																				if (47 > b)
																				{
																					break;
																				}
																				goto IL_2261_2;
																				IL_2261_2:
																				array3[num6] = ((delegate*<Dictionary<string, int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																				goto IL_227f_2;
																				IL_227f_2:
																				array2[num6] = 5;
																				goto IL_228d_2;
																				IL_228d_2:
																				num6++;
																				num = 229;
																				goto IL_22a4_2;
																				IL_22a4_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_2938_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_22c0_2:
																				if (46 > b)
																				{
																					break;
																				}
																				goto IL_22ce_2;
																				IL_22ce_2:
																				array2[num6 - 1] = 3;
																				goto IL_22e2_2;
																				IL_22e2_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_2321_2;
																				IL_2321_2:
																				ptr2 += 8;
																				num = 303;
																				goto IL_5ca0_2;
																				IL_23b6_2:
																				array2[num6 - 2] = 0;
																				goto IL_23ca_2;
																				IL_23ca_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]);
																				goto IL_34d8_2;
																				IL_34d8_2:
																				num6--;
																				goto IL_34e6_2;
																				IL_34e6_2:
																				ptr2 += 8;
																				num = 214;
																				goto IL_5ca0_2;
																				IL_1900_2:
																				if (53 < b)
																				{
																					goto IL_190e_2;
																				}
																				goto IL_1de2_2;
																				IL_190e_2:
																				if (55 >= b)
																				{
																					goto IL_191c_2;
																				}
																				goto IL_19a0_2;
																				IL_191c_2:
																				if (55 <= b)
																				{
																					goto IL_1927_2;
																				}
																				goto IL_198d_2;
																				IL_1927_2:
																				array2[num6 - 1] = 3;
																				goto IL_193b_2;
																				IL_193b_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_197a_2;
																				IL_197a_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_198d_2:
																				if (54 < b)
																				{
																					break;
																				}
																				goto IL_1f1b_2;
																				IL_1f1b_2:
																				if (54 > b)
																				{
																					break;
																				}
																				goto IL_1f29_2;
																				IL_1f29_2:
																				global::_003CModule_003E.list_11 = (List<long>)array3[num6 - 1];
																				goto IL_1f42_2;
																				IL_1f42_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_19a0_2:
																				if (56 >= b)
																				{
																					goto IL_19ae_2;
																				}
																				goto IL_1e4b_2;
																				IL_19ae_2:
																				if (56 > b)
																				{
																					break;
																				}
																				goto IL_19bc_2;
																				IL_19bc_2:
																				array2[num6] = 15;
																				goto IL_19ca_2;
																				IL_19ca_2:
																				array4[num6] = *(int*)(ptr2 + num3);
																				goto IL_1d35_2;
																				IL_1d35_2:
																				ptr2 += 8;
																				goto IL_1d43_2;
																				IL_1d43_2:
																				num6++;
																				goto IL_5ca0_2;
																				IL_1e4b_2:
																				if (57 < b)
																				{
																					break;
																				}
																				goto IL_1e59_2;
																				IL_1e59_2:
																				if (57 > b)
																				{
																					break;
																				}
																				goto IL_233d_2;
																				IL_233d_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																				goto IL_2ae3_2;
																				IL_2ae3_2:
																				array2[num6] = 3;
																				goto IL_2af1_2;
																				IL_2af1_2:
																				num6++;
																				goto IL_2aff_2;
																				IL_2aff_2:
																				ptr2 += 8;
																				num = 562;
																				goto IL_5ca0_2;
																				IL_1de2_2:
																				if (53 <= b)
																				{
																					goto IL_1df0_2;
																				}
																				goto IL_26bc_2;
																				IL_1df0_2:
																				array2[num6] = 5;
																				goto IL_21b6_2;
																				IL_21b6_2:
																				array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																				goto IL_21d4_2;
																				IL_21d4_2:
																				num6++;
																				goto IL_21e2_2;
																				IL_21e2_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_26bc_2:
																				if (50 >= b)
																				{
																					goto IL_26ca_2;
																				}
																				goto IL_2877_2;
																				IL_26ca_2:
																				if (50 > b)
																				{
																					goto IL_26d8_2;
																				}
																				goto IL_2a7d_2;
																				IL_26d8_2:
																				if (49 < b)
																				{
																					break;
																				}
																				goto IL_26e6_2;
																				IL_26e6_2:
																				if (49 > b)
																				{
																					break;
																				}
																				goto IL_26f4_2;
																				IL_26f4_2:
																				global::_003CModule_003E.int_200 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_270e_2;
																				IL_270e_2:
																				num6--;
																				goto IL_5ca0_2;
																				IL_2a7d_2:
																				array2[num6 - 1] = 3;
																				goto IL_2a91_2;
																				IL_2a91_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_2ad0_2;
																				IL_2ad0_2:
																				ptr2 += 8;
																				goto IL_5ca0_2;
																				IL_2877_2:
																				if (51 < b)
																				{
																					goto IL_2885_2;
																				}
																				goto IL_2910_2;
																				IL_2885_2:
																				if (52 < b)
																				{
																					break;
																				}
																				goto IL_2893_2;
																				IL_2893_2:
																				if (52 > b)
																				{
																					break;
																				}
																				goto IL_28a1_2;
																				IL_28a1_2:
																				array2[num6 - 1] = 3;
																				goto IL_28b5_2;
																				IL_28b5_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_28f4_2;
																				IL_28f4_2:
																				ptr2 += 8;
																				num = 322;
																				goto IL_5ca0_2;
																				IL_2910_2:
																				if (51 > b)
																				{
																					break;
																				}
																				goto IL_291e_2;
																			}
																			break;
																		}
																		goto IL_16bf_2;
																		IL_3307_2:
																		if (38 < b)
																		{
																			break;
																		}
																		num = 372;
																		goto IL_331e_2;
																		IL_16bf_2:
																		if (39 > b)
																		{
																			goto IL_16cd_2;
																		}
																		goto IL_1e6c_2;
																		IL_16cd_2:
																		if (19 >= b)
																		{
																			goto IL_16db_2;
																		}
																		goto IL_2b1b_2;
																		IL_16db_2:
																		if (19 > b)
																		{
																			goto IL_16e9_2;
																		}
																		goto IL_1e03_2;
																		IL_16e9_2:
																		if (9 >= b)
																		{
																			goto IL_16f7_2;
																		}
																		goto IL_17af_2;
																		IL_16f7_2:
																		if (9 > b)
																		{
																			goto IL_1705_2;
																		}
																		goto IL_1a87_2;
																		IL_1705_2:
																		if (4 >= b)
																		{
																			goto IL_1710_2;
																		}
																		goto IL_1723_2;
																		IL_1710_2:
																		if (4 > b)
																		{
																			goto IL_1c4c_2;
																		}
																		goto IL_2721_2;
																		IL_2721_2:
																		array2[num6] = 0;
																		goto IL_272f_2;
																		IL_272f_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_2752_2;
																		IL_2752_2:
																		array3[num6] = null;
																		goto IL_275c_2;
																		IL_275c_2:
																		num6++;
																		goto IL_276a_2;
																		IL_276a_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_1c4c_2:
																		if (2 >= b)
																		{
																			goto IL_1c99_2;
																		}
																		goto IL_269b_2;
																		IL_1c99_2:
																		if (2 > b)
																		{
																			goto IL_1ca4_2;
																		}
																		goto IL_1cc5_2;
																		IL_1ca4_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_1cb2_2;
																		IL_1cb2_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_216e_2;
																		IL_216e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_2187_2;
																		IL_2187_2:
																		array2[num6] = 0;
																		goto IL_2195_2;
																		IL_2195_2:
																		num6++;
																		goto IL_21a3_2;
																		IL_21a3_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_1cc5_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 153;
																		goto IL_1d0e_2;
																		IL_1d0e_2:
																		array2[num6 - 2] = 0;
																		goto IL_1d22_2;
																		IL_1d22_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_269b_2:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_26a9_2;
																		IL_26a9_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_360c_2;
																		IL_360c_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_3635_2;
																		IL_3635_2:
																		ptr2 += 8;
																		goto IL_3643_2;
																		IL_3643_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_1723_2:
																		if (6 >= b)
																		{
																			num = 470;
																			goto IL_173a_2;
																		}
																		goto IL_1aee_2;
																		IL_27a2_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_173a_2:
																		if (6 <= b)
																		{
																			goto IL_1748_2;
																		}
																		goto IL_1c2b_2;
																		IL_1748_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1788_2;
																		IL_1788_2:
																		array2[num6 - 2] = 0;
																		goto IL_179c_2;
																		IL_179c_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_1c2b_2:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_1c39_2;
																		IL_1c39_2:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_24cb_2;
																		IL_24cb_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_250b_2;
																		IL_250b_2:
																		array2[num6 - 2] = 0;
																		goto IL_251f_2;
																		IL_251f_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_1aee_2:
																		if (7 < b)
																		{
																			goto IL_1afc_2;
																		}
																		goto IL_1f55_2;
																		IL_1afc_2:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_1b0a_2;
																		IL_1b0a_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_1b18_2;
																		IL_1b18_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_1f55_2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_3468_2;
																		IL_3468_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_34a8_2;
																		IL_34a8_2:
																		array2[num6 - 2] = 0;
																		goto IL_34bc_2;
																		IL_34bc_2:
																		num6--;
																		num = 329;
																		goto IL_5ca0_2;
																		IL_1a87_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1ac7_2;
																		IL_1ac7_2:
																		array2[num6 - 2] = 0;
																		goto IL_1adb_2;
																		IL_1adb_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_17af_2:
																		if (14 < b)
																		{
																			goto IL_17bd_2;
																		}
																		goto IL_1b2b_2;
																		IL_17bd_2:
																		if (16 >= b)
																		{
																			goto IL_17c8_2;
																		}
																		goto IL_17e9_2;
																		IL_17c8_2:
																		if (16 > b)
																		{
																			goto IL_17d6_2;
																		}
																		goto IL_27b5_2;
																		IL_17d6_2:
																		if (15 < b)
																		{
																			break;
																		}
																		goto IL_1e8f_2;
																		IL_1e8f_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_1e9d_2;
																		IL_1e9d_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_2421_2;
																		IL_2421_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		num = 21;
																		goto IL_2448_2;
																		IL_2448_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_246c_2;
																		IL_246c_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_2484_2;
																		IL_2484_2:
																		num6++;
																		goto IL_5ca0_2;
																		IL_27b5_2:
																		array2[num6] = 5;
																		goto IL_27c3_2;
																		IL_27c3_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_27db_2;
																		IL_27db_2:
																		num6++;
																		goto IL_27e9_2;
																		IL_27e9_2:
																		ptr2 += 8;
																		num = 1230;
																		goto IL_5ca0_2;
																		IL_17e9_2:
																		if (17 >= b)
																		{
																			goto IL_17f4_2;
																		}
																		goto IL_1807_2;
																		IL_17f4_2:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_235c_2;
																		IL_235c_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		num = 559;
																		goto IL_23a3_2;
																		IL_23a3_2:
																		num6 -= 3;
																		goto IL_5ca0_2;
																		IL_1807_2:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_1815_2;
																		IL_1815_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_1823_2;
																		IL_1823_2:
																		array2[num6 - 1] = 5;
																		goto IL_1c5c_2;
																		IL_1c5c_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)getUIContextReturnType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_24b8_2;
																		IL_24b8_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_1b2b_2:
																		if (14 <= b)
																		{
																			goto IL_1b36_2;
																		}
																		goto IL_1b64_2;
																		IL_1b36_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_1f02_2;
																		IL_1f02_2:
																		array2[num6 - 1] = 5;
																		goto IL_5ca0_2;
																		IL_1b64_2:
																		if (11 < b)
																		{
																			goto IL_1b6f_2;
																		}
																		num = 721;
																		goto IL_1bdb_2;
																		IL_1b6f_2:
																		if (12 >= b)
																		{
																			goto IL_1b7a_2;
																		}
																		goto IL_1b8d_2;
																		IL_1b7a_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto end_IL_1592;
																		IL_1b8d_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_1b9b_2;
																		IL_1b9b_2:
																		if (13 > b)
																		{
																			break;
																		}
																		num = 461;
																		goto IL_1bb2_2;
																		IL_332c_2:
																		array2[num6 - 1] = 3;
																		goto IL_3340_2;
																		IL_1bb2_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_1bee_2;
																		IL_1bee_2:
																		ptr2 += 8;
																		num = 450;
																		goto IL_1c05_2;
																		IL_1c05_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_331e_2:
																		if (38 > b)
																		{
																			break;
																		}
																		goto IL_332c_2;
																		IL_1bdb_2:
																		if (11 <= b)
																		{
																			goto IL_5ca0_2;
																		}
																		goto IL_2532_2;
																		IL_2532_2:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_2540_2;
																		IL_2540_2:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_254e_2;
																		IL_254e_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_25b0_2;
																		IL_25b0_2:
																		num6 -= 2;
																		goto IL_5ca0_2;
																		IL_1e03_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_1e1c_2;
																		IL_1e1c_2:
																		array2[num6] = 1;
																		goto IL_1e2a_2;
																		IL_1e2a_2:
																		num6++;
																		goto IL_1e38_2;
																		IL_1e38_2:
																		ptr2 += 16;
																		goto IL_5ca0_2;
																		IL_2b1b_2:
																		if (29 >= b)
																		{
																			goto IL_2b29_2;
																		}
																		goto IL_2fc8_2;
																		IL_2b29_2:
																		if (29 <= b)
																		{
																			num = 394;
																			goto IL_2b3d_2;
																		}
																		goto IL_2ba3_2;
																		IL_3340_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		num = 527;
																		goto IL_3388_2;
																		IL_2b3d_2:
																		array2[num6 - 1] = 0;
																		goto IL_2b51_2;
																		IL_2b51_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_2b90_2;
																		IL_2b90_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_2ba3_2:
																		if (24 >= b)
																		{
																			goto IL_2bb1_2;
																		}
																		goto IL_2dd8_2;
																		IL_2bb1_2:
																		if (24 <= b)
																		{
																			goto IL_2bbc_2;
																		}
																		goto IL_2c0f_2;
																		IL_2bbc_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_2be0_2;
																		IL_2be0_2:
																		array2[num6] = 0;
																		goto IL_2bee_2;
																		IL_2bee_2:
																		num6++;
																		goto IL_2bfc_2;
																		IL_2bfc_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_2c0f_2:
																		if (21 >= b)
																		{
																			goto IL_2c1d_2;
																		}
																		goto IL_2cd6_2;
																		IL_2c1d_2:
																		if (21 > b)
																		{
																			goto IL_2c28_2;
																		}
																		goto IL_2c65_2;
																		IL_2c28_2:
																		if (20 < b)
																		{
																			break;
																		}
																		goto IL_2c36_2;
																		IL_2c36_2:
																		if (20 > b)
																		{
																			break;
																		}
																		num = 314;
																		goto IL_2c4d_2;
																		IL_3388_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_2c4d_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_5ca0_2;
																		IL_2c65_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																		goto IL_2ca6_2;
																		IL_2ca6_2:
																		array2[num6 - 2] = 0;
																		num = 550;
																		goto IL_2cc3_2;
																		IL_2cc3_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_2cd6_2:
																		if (22 >= b)
																		{
																			num = 409;
																			goto IL_2cea_2;
																		}
																		goto IL_2d5d_2;
																		IL_1e6c_2:
																		array3[num6] = ((delegate*<GameEntityManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_277d_2;
																		IL_2cea_2:
																		if (22 > b)
																		{
																			break;
																		}
																		goto IL_2cf8_2;
																		IL_2cf8_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_2d4a_2;
																		IL_2d4a_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_2d5d_2:
																		if (23 < b)
																		{
																			break;
																		}
																		num = 895;
																		goto IL_2d74_2;
																		IL_277d_2:
																		array2[num6] = 5;
																		goto IL_278b_2;
																		IL_2d74_2:
																		if (23 > b)
																		{
																			break;
																		}
																		goto IL_2d82_2;
																		IL_2d82_2:
																		array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_2da0_2;
																		IL_2da0_2:
																		array2[num6] = 5;
																		goto IL_2dae_2;
																		IL_2dae_2:
																		num6++;
																		goto IL_2dbc_2;
																		IL_2dbc_2:
																		ptr2 += 8;
																		num = 1279;
																		goto IL_5ca0_2;
																		IL_2dd8_2:
																		if (26 >= b)
																		{
																			goto IL_2de6_2;
																		}
																		goto IL_2ebd_2;
																		IL_2de6_2:
																		if (26 <= b)
																		{
																			goto IL_2df1_2;
																		}
																		goto IL_2e39_2;
																		IL_2df1_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																		goto IL_2e0a_2;
																		IL_2e0a_2:
																		array2[num6] = 3;
																		goto IL_2e18_2;
																		IL_2e18_2:
																		num6++;
																		goto IL_2e26_2;
																		IL_2e26_2:
																		ptr2 += 16;
																		goto IL_5ca0_2;
																		IL_2e39_2:
																		if (25 < b)
																		{
																			break;
																		}
																		num = 561;
																		goto IL_2e50_2;
																		IL_278b_2:
																		num6++;
																		num = 507;
																		goto IL_27a2_2;
																		IL_2e50_2:
																		if (25 > b)
																		{
																			break;
																		}
																		goto IL_2e5e_2;
																		IL_2e5e_2:
																		((delegate*<List<int>, int, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<int>)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_2e9c_2;
																		IL_2e9c_2:
																		num6 -= 2;
																		goto IL_2eaa_2;
																		IL_2eaa_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_2ebd_2:
																		if (27 >= b)
																		{
																			goto IL_2ec8_2;
																		}
																		goto IL_2f3c_2;
																		IL_2ec8_2:
																		if (27 > b)
																		{
																			break;
																		}
																		goto IL_2ed6_2;
																		IL_2ed6_2:
																		array2[num6 - 1] = 3;
																		goto IL_2eea_2;
																		IL_2eea_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_2f29_2;
																		IL_2f29_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_2f3c_2:
																		if (28 < b)
																		{
																			break;
																		}
																		goto IL_2f4a_2;
																		IL_2f4a_2:
																		if (28 > b)
																		{
																			break;
																		}
																		goto IL_2f58_2;
																		IL_2f58_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_2f98_2;
																		IL_2f98_2:
																		array2[num6 - 2] = 3;
																		goto IL_2fac_2;
																		IL_2fac_2:
																		num6--;
																		num = 163;
																		goto IL_5ca0_2;
																		IL_2fc8_2:
																		if (34 >= b)
																		{
																			goto IL_2fd6_2;
																		}
																		goto IL_31a3_2;
																		IL_2fd6_2:
																		if (34 <= b)
																		{
																			goto IL_2fe1_2;
																		}
																		goto IL_302e_2;
																		IL_2fe1_2:
																		array3[num6] = ((delegate*<List<long>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_2fff_2;
																		IL_2fff_2:
																		array2[num6] = 5;
																		goto IL_300d_2;
																		IL_300d_2:
																		num6++;
																		goto IL_301b_2;
																		IL_301b_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_302e_2:
																		if (31 >= b)
																		{
																			goto IL_303c_2;
																		}
																		goto IL_30e5_2;
																		IL_303c_2:
																		if (31 > b)
																		{
																			goto IL_3047_2;
																		}
																		goto IL_30b0_2;
																		IL_3047_2:
																		if (30 < b)
																		{
																			break;
																		}
																		goto IL_3055_2;
																		IL_3055_2:
																		if (30 > b)
																		{
																			break;
																		}
																		goto IL_3063_2;
																		IL_3063_2:
																		array2[num6] = 5;
																		goto IL_3071_2;
																		IL_3071_2:
																		array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_308f_2;
																		IL_308f_2:
																		num6++;
																		goto IL_309d_2;
																		IL_309d_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_30b0_2:
																		global::_003CModule_003E.list_10 = (List<int>)array3[num6 - 1];
																		num = 850;
																		goto IL_30d2_2;
																		IL_30d2_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_30e5_2:
																		if (32 >= b)
																		{
																			goto IL_30f0_2;
																		}
																		goto IL_3117_2;
																		IL_30f0_2:
																		if (32 > b)
																		{
																			break;
																		}
																		goto IL_30fe_2;
																		IL_30fe_2:
																		array2[num6 - 1] = 3;
																		goto IL_3502_2;
																		IL_3502_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_3541_2;
																		IL_3541_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_3117_2:
																		if (33 < b)
																		{
																			break;
																		}
																		goto IL_3125_2;
																		IL_3125_2:
																		if (33 > b)
																		{
																			break;
																		}
																		goto IL_3133_2;
																		IL_3133_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 498;
																		goto IL_317c_2;
																		IL_317c_2:
																		array2[num6 - 2] = 3;
																		goto IL_3190_2;
																		IL_3190_2:
																		num6--;
																		goto IL_5ca0_2;
																		IL_31a3_2:
																		if (36 >= b)
																		{
																			goto IL_31b1_2;
																		}
																		goto IL_328f_2;
																		IL_31b1_2:
																		if (36 <= b)
																		{
																			goto IL_31bc_2;
																		}
																		goto IL_3221_2;
																		IL_31bc_2:
																		array2[num6 - 1] = 1;
																		goto IL_31d0_2;
																		IL_31d0_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Vector3, long>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																		goto IL_320e_2;
																		IL_320e_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_3221_2:
																		if (35 < b)
																		{
																			break;
																		}
																		goto IL_322f_2;
																		IL_322f_2:
																		if (35 > b)
																		{
																			break;
																		}
																		goto IL_323d_2;
																		IL_323d_2:
																		array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																		goto IL_3260_2;
																		IL_3260_2:
																		array2[num6] = 4;
																		goto IL_326e_2;
																		IL_326e_2:
																		num6++;
																		goto IL_327c_2;
																		IL_327c_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																		IL_328f_2:
																		if (37 >= b)
																		{
																			goto IL_329a_2;
																		}
																		goto IL_3307_2;
																		IL_329a_2:
																		if (37 > b)
																		{
																			break;
																		}
																		goto IL_32a8_2;
																		IL_32a8_2:
																		((delegate*<List<long>, long, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<long>)array3[num6 - 2], *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_32e6_2;
																		IL_32e6_2:
																		num6 -= 2;
																		goto IL_32f4_2;
																		IL_32f4_2:
																		ptr2 += 8;
																		goto IL_5ca0_2;
																	}
																	break;
																}
																goto IL_33ee_2;
																IL_3428_2:
																ptr2 += 8;
																goto IL_5ca0_2;
																IL_33ee_2:
																array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
																goto IL_340c_2;
																IL_340c_2:
																array2[num6] = 5;
																goto IL_341a_2;
																IL_341a_2:
																num6++;
																goto IL_3428_2;
															}
															break;
														}
														goto IL_3832_2;
														IL_5b1b_2:
														if (153 < b)
														{
															break;
														}
														goto IL_5b29_2;
														IL_3832_2:
														if (117 >= b)
														{
															goto IL_3840_2;
														}
														goto IL_499a_2;
														IL_3840_2:
														if (117 <= b)
														{
															num = 193;
															goto IL_3854_2;
														}
														goto IL_3880_2;
														IL_5b29_2:
														if (153 > b)
														{
															break;
														}
														goto IL_5b37_2;
														IL_3854_2:
														global::_003CModule_003E.vector3_106 = (Vector3)array3[num6 - 1];
														goto IL_386d_2;
														IL_386d_2:
														num6--;
														goto IL_5ca0_2;
														IL_3880_2:
														if (97 >= b)
														{
															goto IL_388e_2;
														}
														goto IL_41a1_2;
														IL_388e_2:
														if (97 <= b)
														{
															goto IL_389c_2;
														}
														goto IL_3923_2;
														IL_389c_2:
														array2[num6 - 2] = 0;
														goto IL_38b0_2;
														IL_38b0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, GameEntityId, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], (GameEntityId)array3[num6 - 1]);
														goto IL_3902_2;
														IL_3902_2:
														num6--;
														goto IL_3910_2;
														IL_3910_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3923_2:
														if (87 < b)
														{
															goto IL_3931_2;
														}
														num = 981;
														goto IL_3d7d_2;
														IL_3931_2:
														if (92 >= b)
														{
															goto IL_393f_2;
														}
														goto IL_3bdd_2;
														IL_393f_2:
														if (92 <= b)
														{
															num = 433;
															goto IL_3953_2;
														}
														goto IL_39a6_2;
														IL_5b4b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4]) = (((delegate*<PhotonView, string, RpcTarget, object[], bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((PhotonView)array3[num6 - 4], (string)array3[num6 - 3], *(RpcTarget*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), (object[])array3[num6 - 1]) ? 1 : 0);
														num = 12;
														goto IL_5bcf_2;
														IL_3953_2:
														array2[num6] = 0;
														goto IL_3961_2;
														IL_3961_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_3985_2;
														IL_3985_2:
														num6++;
														goto IL_3993_2;
														IL_3993_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_39a6_2:
														if (89 < b)
														{
															goto IL_39b4_2;
														}
														goto IL_3a90_2;
														IL_39b4_2:
														if (90 < b)
														{
															goto IL_39c2_2;
														}
														num = 693;
														goto IL_3a4d_2;
														IL_39c2_2:
														if (91 < b)
														{
															break;
														}
														goto IL_39d0_2;
														IL_39d0_2:
														if (91 > b)
														{
															break;
														}
														goto IL_39de_2;
														IL_39de_2:
														array2[num6 - 1] = 3;
														goto IL_39f2_2;
														IL_39f2_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_3a31_2;
														IL_3a31_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5bcf_2:
														num6 -= 3;
														goto IL_5bdd_2;
														IL_3a4d_2:
														if (90 > b)
														{
															break;
														}
														goto IL_3a5b_2;
														IL_3a5b_2:
														global::_003CModule_003E.quaternion_3 = (Quaternion)array3[num6 - 1];
														num = 909;
														goto IL_3a7d_2;
														IL_3a7d_2:
														num6--;
														goto IL_5ca0_2;
														IL_3a90_2:
														if (89 <= b)
														{
															goto IL_3a9e_2;
														}
														goto IL_3b24_2;
														IL_3a9e_2:
														array2[num6 - 2] = 4;
														goto IL_3ab2_2;
														IL_3ab2_2:
														array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
														goto IL_3b03_2;
														IL_3b03_2:
														num6--;
														goto IL_3b11_2;
														IL_3b11_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3b24_2:
														if (88 < b)
														{
															break;
														}
														goto IL_3b32_2;
														IL_3b32_2:
														if (88 > b)
														{
															break;
														}
														goto IL_3b40_2;
														IL_3b40_2:
														array2[num6 - 3] = 4;
														goto IL_3b54_2;
														IL_3b54_2:
														array3[num6 - 3] = ((delegate*<float, float, float, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
														goto IL_3bbc_2;
														IL_3bbc_2:
														num6 -= 2;
														goto IL_3bca_2;
														IL_3bca_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3bdd_2:
														if (94 >= b)
														{
															goto IL_3beb_2;
														}
														goto IL_3cac_2;
														IL_3beb_2:
														if (94 <= b)
														{
															goto IL_3bf6_2;
														}
														goto IL_3c49_2;
														IL_3bf6_2:
														array2[num6] = 3;
														goto IL_3c04_2;
														IL_3c04_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_3c28_2;
														IL_3c28_2:
														num6++;
														goto IL_3c36_2;
														IL_3c36_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3c49_2:
														if (93 < b)
														{
															break;
														}
														goto IL_3c57_2;
														IL_3c57_2:
														if (93 > b)
														{
															break;
														}
														goto IL_3c65_2;
														IL_3c65_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_3c7d_2;
														IL_3c7d_2:
														array2[num6] = 5;
														goto IL_3c8b_2;
														IL_3c8b_2:
														num6++;
														goto IL_3c99_2;
														IL_3c99_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3cac_2:
														if (95 >= b)
														{
															goto IL_3cb7_2;
														}
														goto IL_3d06_2;
														IL_3cb7_2:
														if (95 > b)
														{
															break;
														}
														goto IL_3cc5_2;
														IL_3cc5_2:
														((Class121)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_3cf3_2;
														IL_3cf3_2:
														num6 -= 2;
														goto IL_5ca0_2;
														IL_3d06_2:
														if (96 < b)
														{
															break;
														}
														goto IL_3d14_2;
														IL_3d14_2:
														if (96 > b)
														{
															break;
														}
														goto IL_3d22_2;
														IL_3d22_2:
														array3[num6] = ((delegate*<GameEntityId>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_3d45_2;
														IL_3d45_2:
														array2[num6] = 4;
														goto IL_3d53_2;
														IL_3d53_2:
														num6++;
														goto IL_3d61_2;
														IL_3d61_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5b37_2:
														array2[num6 - 4] = 0;
														goto IL_5b4b_2;
														IL_3d7d_2:
														if (87 > b)
														{
															goto IL_3d8b_2;
														}
														goto IL_4134_2;
														IL_3d8b_2:
														if (82 >= b)
														{
															goto IL_3d99_2;
														}
														goto IL_3f26_2;
														IL_3d99_2:
														if (82 <= b)
														{
															goto IL_3da4_2;
														}
														goto IL_3df6_2;
														IL_3da4_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_3dc7_2;
														IL_3dc7_2:
														array2[num6] = 4;
														goto IL_3dd5_2;
														IL_3dd5_2:
														num6++;
														goto IL_3de3_2;
														IL_3de3_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3df6_2:
														if (80 >= b)
														{
															goto IL_3e04_2;
														}
														goto IL_3eaf_2;
														IL_3e04_2:
														if (80 <= b)
														{
															goto IL_3e0f_2;
														}
														goto IL_3e37_2;
														IL_3e0f_2:
														((delegate*<void>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_3e24_2;
														IL_3e24_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3e37_2:
														if (79 < b)
														{
															break;
														}
														num = 953;
														goto IL_3e4e_2;
														IL_5bdd_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3e4e_2:
														if (79 > b)
														{
															break;
														}
														goto IL_3e5c_2;
														IL_3e5c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_3e80_2;
														IL_3e80_2:
														array2[num6] = 0;
														goto IL_3e8e_2;
														IL_3e8e_2:
														num6++;
														goto IL_3e9c_2;
														IL_3e9c_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3eaf_2:
														if (81 < b)
														{
															break;
														}
														goto IL_3ebd_2;
														IL_3ebd_2:
														if (81 > b)
														{
															break;
														}
														goto IL_3ecb_2;
														IL_3ecb_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														num = 1232;
														goto IL_3ef7_2;
														IL_3ef7_2:
														array2[num6] = 4;
														goto IL_3f05_2;
														IL_3f05_2:
														num6++;
														goto IL_3f13_2;
														IL_3f13_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3f26_2:
														if (84 >= b)
														{
															goto IL_3f34_2;
														}
														goto IL_4041_2;
														IL_3f34_2:
														if (84 <= b)
														{
															goto IL_3f42_2;
														}
														goto IL_3fd2_2;
														IL_3f42_2:
														array2[num6 - 2] = 4;
														goto IL_3f56_2;
														IL_3f56_2:
														array3[num6 - 2] = ((delegate*<Vector3, float, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
														num = 1009;
														goto IL_3fb1_2;
														IL_3fb1_2:
														num6--;
														goto IL_3fbf_2;
														IL_3fbf_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_3fd2_2:
														if (83 < b)
														{
															break;
														}
														goto IL_3fe0_2;
														IL_3fe0_2:
														if (83 > b)
														{
															break;
														}
														goto IL_3fee_2;
														IL_3fee_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4012_2;
														IL_4012_2:
														array2[num6] = 3;
														goto IL_4020_2;
														IL_4020_2:
														num6++;
														goto IL_402e_2;
														IL_402e_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4041_2:
														if (85 >= b)
														{
															goto IL_404f_2;
														}
														goto IL_40ec_2;
														IL_404f_2:
														if (85 > b)
														{
															break;
														}
														goto IL_405d_2;
														IL_405d_2:
														array2[num6 - 2] = 4;
														goto IL_4071_2;
														IL_4071_2:
														array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
														goto IL_40c2_2;
														IL_40c2_2:
														num6--;
														goto IL_40d0_2;
														IL_40d0_2:
														ptr2 += 8;
														num = 602;
														goto IL_5ca0_2;
														IL_40ec_2:
														if (86 < b)
														{
															break;
														}
														goto IL_40fa_2;
														IL_40fa_2:
														if (86 > b)
														{
															break;
														}
														goto IL_4108_2;
														IL_4108_2:
														global::_003CModule_003E.vector3_102 = (Vector3)array3[num6 - 1];
														goto IL_4121_2;
														IL_4121_2:
														num6--;
														goto IL_5ca0_2;
														IL_4134_2:
														array2[num6 - 1] = 4;
														num = 179;
														goto IL_4151_2;
														IL_4151_2:
														array3[num6 - 1] = ((delegate*<Vector3, Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
														goto IL_418e_2;
														IL_418e_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_41a1_2:
														if (107 >= b)
														{
															goto IL_41af_2;
														}
														goto IL_456b_2;
														IL_41af_2:
														if (107 <= b)
														{
															goto IL_41bd_2;
														}
														goto IL_424e_2;
														IL_41bd_2:
														array2[num6 - 2] = 0;
														goto IL_41d1_2;
														IL_41d1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<GameEntityManager, int, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 51;
														goto IL_422d_2;
														IL_422d_2:
														num6--;
														goto IL_423b_2;
														IL_423b_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_424e_2:
														if (102 >= b)
														{
															goto IL_425c_2;
														}
														goto IL_43bd_2;
														IL_425c_2:
														if (102 <= b)
														{
															goto IL_4267_2;
														}
														goto IL_42b9_2;
														IL_4267_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_428a_2;
														IL_428a_2:
														array2[num6] = 4;
														goto IL_4298_2;
														IL_4298_2:
														num6++;
														goto IL_42a6_2;
														IL_42a6_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_42b9_2:
														if (99 < b)
														{
															goto IL_42c4_2;
														}
														goto IL_433d_2;
														IL_42c4_2:
														if (100 >= b)
														{
															goto IL_42cf_2;
														}
														goto IL_42f9_2;
														IL_42cf_2:
														if (100 > b)
														{
															break;
														}
														goto IL_42dd_2;
														IL_42dd_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_5ca0_2;
														IL_42f9_2:
														if (101 < b)
														{
															break;
														}
														goto IL_4307_2;
														IL_4307_2:
														if (101 > b)
														{
															break;
														}
														goto IL_4315_2;
														IL_4315_2:
														((delegate*<void>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_432a_2;
														IL_432a_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_433d_2:
														if (99 <= b)
														{
															goto IL_4348_2;
														}
														goto IL_4374_2;
														IL_4348_2:
														global::_003CModule_003E.list_14 = (List<int>)array3[num6 - 1];
														goto IL_4361_2;
														IL_4361_2:
														num6--;
														goto IL_5ca0_2;
														IL_4374_2:
														if (98 < b)
														{
															break;
														}
														goto IL_4382_2;
														IL_4382_2:
														if (98 > b)
														{
															break;
														}
														goto IL_4390_2;
														IL_4390_2:
														global::_003CModule_003E.int_197 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_43aa_2;
														IL_43aa_2:
														num6--;
														goto IL_5ca0_2;
														IL_43bd_2:
														if (104 < b)
														{
															goto IL_43cb_2;
														}
														num = 1135;
														goto IL_44c2_2;
														IL_43cb_2:
														if (105 >= b)
														{
															goto IL_43d6_2;
														}
														goto IL_444b_2;
														IL_43d6_2:
														if (105 > b)
														{
															break;
														}
														goto IL_43e4_2;
														IL_43e4_2:
														ptr2 = (((array3[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_4438_2;
														IL_4438_2:
														num6--;
														goto IL_5ca0_2;
														IL_444b_2:
														if (106 < b)
														{
															break;
														}
														goto IL_4459_2;
														IL_4459_2:
														if (106 > b)
														{
															break;
														}
														goto IL_4467_2;
														IL_4467_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_448a_2;
														IL_448a_2:
														array2[num6] = 4;
														goto IL_4498_2;
														IL_4498_2:
														num6++;
														goto IL_44a6_2;
														IL_44a6_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5bf0_2:
														if (155 >= b)
														{
															goto IL_5bfb_2;
														}
														goto IL_5c6e_2;
														IL_44c2_2:
														if (104 > b)
														{
															goto IL_44cd_2;
														}
														goto IL_4515_2;
														IL_44cd_2:
														if (103 < b)
														{
															break;
														}
														goto IL_44db_2;
														IL_44db_2:
														if (103 > b)
														{
															break;
														}
														goto IL_44e9_2;
														IL_44e9_2:
														global::_003CModule_003E.vector3_108 = (Vector3)array3[num6 - 1];
														goto IL_4502_2;
														IL_4502_2:
														num6--;
														goto IL_5ca0_2;
														IL_4515_2:
														array3[num6] = ((delegate*<SuperInfectionManager>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4533_2;
														IL_4533_2:
														array2[num6] = 5;
														goto IL_4541_2;
														IL_4541_2:
														num6++;
														goto IL_454f_2;
														IL_454f_2:
														ptr2 += 8;
														num = 1272;
														goto IL_5ca0_2;
														IL_456b_2:
														if (112 >= b)
														{
															goto IL_4579_2;
														}
														goto IL_47bc_2;
														IL_4579_2:
														if (112 <= b)
														{
															goto IL_4584_2;
														}
														goto IL_45e3_2;
														IL_4584_2:
														array2[num6 - 1] = 5;
														goto IL_4598_2;
														IL_4598_2:
														array3[num6 - 1] = ((delegate*<Component, Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SphereCollider)array3[num6 - 1]);
														goto IL_45d0_2;
														IL_45d0_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_45e3_2:
														if (109 >= b)
														{
															goto IL_45f1_2;
														}
														goto IL_46bd_2;
														IL_45f1_2:
														if (109 <= b)
														{
															goto IL_45fc_2;
														}
														goto IL_466b_2;
														IL_45fc_2:
														array2[num6 - 1] = 3;
														goto IL_4610_2;
														IL_4610_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_464f_2;
														IL_464f_2:
														ptr2 += 8;
														num = 1235;
														goto IL_5ca0_2;
														IL_466b_2:
														if (108 < b)
														{
															break;
														}
														goto IL_4679_2;
														IL_4679_2:
														if (108 > b)
														{
															break;
														}
														num = 970;
														goto IL_4690_2;
														IL_5bfb_2:
														if (155 > b)
														{
															break;
														}
														goto IL_5c09_2;
														IL_4690_2:
														global::_003CModule_003E.int_198 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_46aa_2;
														IL_46aa_2:
														num6--;
														goto IL_5ca0_2;
														IL_46bd_2:
														if (110 < b)
														{
															goto IL_46cb_2;
														}
														num = 723;
														goto IL_4761_2;
														IL_46cb_2:
														if (111 < b)
														{
															break;
														}
														num = 735;
														goto IL_46e2_2;
														IL_5c47_2:
														num6 -= 2;
														num = 653;
														goto IL_5c5e_2;
														IL_46e2_2:
														if (111 > b)
														{
															break;
														}
														goto IL_46f0_2;
														IL_46f0_2:
														array3[num6 - 1] = ((delegate*<GTPlayer, SphereCollider>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GTPlayer)array3[num6 - 1]);
														goto IL_4728_2;
														IL_4728_2:
														array2[num6 - 1] = 5;
														num = 1280;
														goto IL_4745_2;
														IL_4745_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5c09_2:
														((delegate*<GameEntityManager, GameEntityManager.ZoneState, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 2], *(GameEntityManager.ZoneState*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_5c47_2;
														IL_4761_2:
														if (110 > b)
														{
															break;
														}
														goto IL_476f_2;
														IL_476f_2:
														array2[num6] = 5;
														goto IL_477d_2;
														IL_477d_2:
														array3[num6] = ((delegate*<GTPlayer>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_479b_2;
														IL_479b_2:
														num6++;
														goto IL_47a9_2;
														IL_47a9_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_47bc_2:
														if (114 >= b)
														{
															goto IL_47ca_2;
														}
														goto IL_48a2_2;
														IL_47ca_2:
														if (114 <= b)
														{
															goto IL_47d5_2;
														}
														goto IL_4822_2;
														IL_47d5_2:
														array2[num6] = 5;
														goto IL_47e3_2;
														IL_47e3_2:
														array3[num6] = ((delegate*<GTPlayer>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4801_2;
														IL_4801_2:
														num6++;
														goto IL_480f_2;
														IL_480f_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4822_2:
														if (113 < b)
														{
															break;
														}
														goto IL_4830_2;
														IL_4830_2:
														if (113 > b)
														{
															break;
														}
														goto IL_483e_2;
														IL_483e_2:
														array2[num6 - 1] = 4;
														goto IL_4852_2;
														IL_4852_2:
														array3[num6 - 1] = ((delegate*<Transform, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
														goto IL_488f_2;
														IL_488f_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_48a2_2:
														if (115 >= b)
														{
															goto IL_48ad_2;
														}
														goto IL_491a_2;
														IL_48ad_2:
														if (115 > b)
														{
															break;
														}
														goto IL_48bb_2;
														IL_48bb_2:
														array2[num6 - 1] = 5;
														goto IL_48cf_2;
														IL_48cf_2:
														array3[num6 - 1] = ((delegate*<Component, Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SphereCollider)array3[num6 - 1]);
														goto IL_4907_2;
														IL_4907_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_491a_2:
														if (116 < b)
														{
															break;
														}
														goto IL_4928_2;
														IL_4928_2:
														if (116 > b)
														{
															break;
														}
														goto IL_4936_2;
														IL_4936_2:
														array2[num6 - 1] = 4;
														goto IL_494a_2;
														IL_494a_2:
														array3[num6 - 1] = ((delegate*<Transform, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
														goto IL_4987_2;
														IL_4987_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_499a_2:
														if (137 >= b)
														{
															goto IL_49a8_2;
														}
														goto IL_532a_2;
														IL_49a8_2:
														if (137 <= b)
														{
															goto IL_49b3_2;
														}
														goto IL_4a30_2;
														IL_49b3_2:
														array2[num6 - 2] = 0;
														goto IL_49c7_2;
														IL_49c7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((UnityEngine.Object)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														goto IL_4a0f_2;
														IL_4a0f_2:
														num6--;
														goto IL_4a1d_2;
														IL_4a1d_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4a30_2:
														if (127 >= b)
														{
															goto IL_4a3e_2;
														}
														goto IL_4ebd_2;
														IL_4a3e_2:
														if (127 <= b)
														{
															goto IL_4a49_2;
														}
														goto IL_4aa8_2;
														IL_4a49_2:
														array3[num6 - 1] = ((delegate*<SuperInfectionManager, SuperInfection>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfectionManager)array3[num6 - 1]);
														goto IL_4a81_2;
														IL_4a81_2:
														array2[num6 - 1] = 5;
														goto IL_4a95_2;
														IL_4a95_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4aa8_2:
														if (122 >= b)
														{
															goto IL_4ab6_2;
														}
														goto IL_4d17_2;
														IL_4ab6_2:
														if (122 <= b)
														{
															goto IL_4ac4_2;
														}
														goto IL_4b4a_2;
														IL_4ac4_2:
														array2[num6 - 2] = 4;
														goto IL_4ad8_2;
														IL_4ad8_2:
														array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
														goto IL_4b29_2;
														IL_4b29_2:
														num6--;
														goto IL_4b37_2;
														IL_4b37_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4b4a_2:
														if (119 >= b)
														{
															goto IL_4b58_2;
														}
														goto IL_4c01_2;
														IL_4b58_2:
														if (119 <= b)
														{
															goto IL_4b63_2;
														}
														goto IL_4bb9_2;
														IL_4b63_2:
														array3[num6] = ((delegate*<Transform>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4b81_2;
														IL_4b81_2:
														array2[num6] = 5;
														goto IL_4b8f_2;
														IL_4b8f_2:
														num6++;
														num = 349;
														goto IL_4ba6_2;
														IL_4ba6_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4bb9_2:
														if (118 < b)
														{
															break;
														}
														goto IL_4bc7_2;
														IL_4bc7_2:
														if (118 > b)
														{
															break;
														}
														goto IL_4bd5_2;
														IL_4bd5_2:
														global::_003CModule_003E.transform_12 = (Transform)array3[num6 - 1];
														goto IL_4bee_2;
														IL_4bee_2:
														num6--;
														goto IL_5ca0_2;
														IL_4c01_2:
														if (120 >= b)
														{
															goto IL_4c0c_2;
														}
														goto IL_4c6c_2;
														IL_4c0c_2:
														if (120 > b)
														{
															break;
														}
														goto IL_4c1a_2;
														IL_4c1a_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4c3d_2;
														IL_4c3d_2:
														array2[num6] = 4;
														goto IL_4c4b_2;
														IL_4c4b_2:
														num6++;
														goto IL_4c59_2;
														IL_4c59_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4c6c_2:
														if (121 < b)
														{
															break;
														}
														goto IL_4c7a_2;
														IL_4c7a_2:
														if (121 > b)
														{
															break;
														}
														goto IL_4c88_2;
														IL_4c88_2:
														array2[num6 - 2] = 4;
														num = 1038;
														goto IL_4ca5_2;
														IL_4ca5_2:
														array3[num6 - 2] = ((delegate*<Transform, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
														goto IL_4cf6_2;
														IL_4cf6_2:
														num6--;
														goto IL_4d04_2;
														IL_4d04_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4d17_2:
														if (124 >= b)
														{
															goto IL_4d25_2;
														}
														goto IL_4dca_2;
														IL_4d25_2:
														if (124 <= b)
														{
															goto IL_4d30_2;
														}
														goto IL_4d82_2;
														IL_4d30_2:
														array3[num6] = ((delegate*<Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4d53_2;
														IL_4d53_2:
														array2[num6] = 4;
														goto IL_4d61_2;
														IL_4d61_2:
														num6++;
														goto IL_4d6f_2;
														IL_4d6f_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4d82_2:
														if (123 < b)
														{
															break;
														}
														goto IL_4d90_2;
														IL_4d90_2:
														if (123 > b)
														{
															break;
														}
														goto IL_4d9e_2;
														IL_4d9e_2:
														global::_003CModule_003E.vector3_107 = (Vector3)array3[num6 - 1];
														goto IL_4db7_2;
														IL_4db7_2:
														num6--;
														goto IL_5ca0_2;
														IL_4dca_2:
														if (125 >= b)
														{
															goto IL_4dd8_2;
														}
														goto IL_4e75_2;
														IL_4dd8_2:
														if (125 > b)
														{
															break;
														}
														goto IL_4de6_2;
														IL_4de6_2:
														array2[num6 - 2] = 4;
														num = 547;
														goto IL_4e03_2;
														IL_4e03_2:
														array3[num6 - 2] = ((delegate*<Transform, Vector3, Vector3>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Vector3)array3[num6 - 1]);
														goto IL_4e54_2;
														IL_4e54_2:
														num6--;
														goto IL_4e62_2;
														IL_4e62_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4e75_2:
														if (126 < b)
														{
															break;
														}
														goto IL_4e83_2;
														IL_4e83_2:
														if (126 > b)
														{
															break;
														}
														goto IL_4e91_2;
														IL_4e91_2:
														global::_003CModule_003E.vector3_105 = (Vector3)array3[num6 - 1];
														goto IL_4eaa_2;
														IL_4eaa_2:
														num6--;
														goto IL_5ca0_2;
														IL_4ebd_2:
														if (132 >= b)
														{
															goto IL_4ecb_2;
														}
														goto IL_5122_2;
														IL_4ecb_2:
														if (132 <= b)
														{
															goto IL_4ed6_2;
														}
														goto IL_4f23_2;
														IL_4ed6_2:
														array3[num6] = ((delegate*<List<int>>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_4ef4_2;
														IL_4ef4_2:
														array2[num6] = 5;
														goto IL_4f02_2;
														IL_4f02_2:
														num6++;
														goto IL_4f10_2;
														IL_4f10_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4f23_2:
														if (129 >= b)
														{
															goto IL_4f31_2;
														}
														goto IL_4ffe_2;
														IL_4f31_2:
														if (129 > b)
														{
															goto IL_4f3c_2;
														}
														goto IL_4fa2_2;
														IL_4f3c_2:
														if (128 < b)
														{
															break;
														}
														goto IL_4f4a_2;
														IL_4f4a_2:
														if (128 > b)
														{
															break;
														}
														goto IL_4f58_2;
														IL_4f58_2:
														((delegate*<SuperInfection, void>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfection)array3[num6 - 1]);
														goto IL_4f81_2;
														IL_4f81_2:
														num6--;
														goto IL_4f8f_2;
														IL_4f8f_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4fa2_2:
														array2[num6] = 3;
														goto IL_4fb0_2;
														IL_4fb0_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														num = 165;
														goto IL_4fdd_2;
														IL_4fdd_2:
														num6++;
														goto IL_4feb_2;
														IL_4feb_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_4ffe_2:
														if (130 >= b)
														{
															goto IL_5009_2;
														}
														goto IL_5085_2;
														IL_5009_2:
														if (130 > b)
														{
															break;
														}
														goto IL_5017_2;
														IL_5017_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class121, float>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Class121)array3[num6 - 1]);
														goto IL_5055_2;
														IL_5055_2:
														array2[num6 - 1] = 3;
														goto IL_5069_2;
														IL_5069_2:
														ptr2 += 8;
														num = 1161;
														goto IL_5ca0_2;
														IL_5085_2:
														if (131 < b)
														{
															break;
														}
														goto IL_5093_2;
														IL_5093_2:
														if (131 > b)
														{
															break;
														}
														goto IL_50a1_2;
														IL_50a1_2:
														ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_510f_2;
														IL_510f_2:
														num6 -= 2;
														goto IL_5ca0_2;
														IL_5122_2:
														if (134 >= b)
														{
															goto IL_5130_2;
														}
														goto IL_5217_2;
														IL_5130_2:
														if (134 <= b)
														{
															goto IL_513b_2;
														}
														goto IL_51a0_2;
														IL_513b_2:
														array2[num6 - 1] = 0;
														goto IL_514f_2;
														IL_514f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Quaternion, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 1]);
														goto IL_518d_2;
														IL_518d_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_51a0_2:
														if (133 < b)
														{
															break;
														}
														goto IL_51ae_2;
														IL_51ae_2:
														if (133 > b)
														{
															break;
														}
														num = 532;
														goto IL_51c5_2;
														IL_5c5e_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_51c5_2:
														array3[num6] = ((delegate*<Quaternion>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_51e8_2;
														IL_51e8_2:
														array2[num6] = 4;
														goto IL_51f6_2;
														IL_51f6_2:
														num6++;
														goto IL_5204_2;
														IL_5204_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5217_2:
														if (135 >= b)
														{
															goto IL_5222_2;
														}
														goto IL_5283_2;
														IL_5222_2:
														if (135 > b)
														{
															break;
														}
														goto IL_5230_2;
														IL_5230_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getUIContextReturnType[*(int*)(ptr2 + num3)])();
														goto IL_5254_2;
														IL_5254_2:
														array2[num6] = 0;
														goto IL_5262_2;
														IL_5262_2:
														num6++;
														goto IL_5270_2;
														IL_5270_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5283_2:
														if (136 < b)
														{
															break;
														}
														goto IL_5291_2;
														IL_5291_2:
														if (136 > b)
														{
															break;
														}
														num = 460;
														goto IL_52a8_2;
														IL_5c6e_2:
														if (156 < b)
														{
															break;
														}
														goto IL_5c79_2;
														IL_52a8_2:
														array2[num6 - 2] = 0;
														goto IL_52bc_2;
														IL_52bc_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((SuperInfection)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														goto IL_5309_2;
														IL_5309_2:
														num6--;
														goto IL_5317_2;
														IL_5317_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_532a_2:
														if (147 >= b)
														{
															goto IL_5338_2;
														}
														goto IL_5825_2;
														IL_5338_2:
														if (147 <= b)
														{
															goto IL_5343_2;
														}
														goto IL_53b2_2;
														IL_5343_2:
														array2[num6 - 1] = 3;
														num = 887;
														goto IL_5360_2;
														IL_5360_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_539f_2;
														IL_539f_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_53b2_2:
														if (142 < b)
														{
															goto IL_53c0_2;
														}
														goto IL_559d_2;
														IL_53c0_2:
														if (144 >= b)
														{
															goto IL_53ce_2;
														}
														goto IL_54af_2;
														IL_53ce_2:
														if (144 <= b)
														{
															goto IL_53d9_2;
														}
														goto IL_5424_2;
														IL_53d9_2:
														array3[num6 - 1] = new object[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_5402_2;
														IL_5402_2:
														array2[num6 - 1] = 5;
														num = 62;
														goto IL_5ca0_2;
														IL_5424_2:
														if (143 < b)
														{
															break;
														}
														goto IL_5432_2;
														IL_5432_2:
														if (143 > b)
														{
															break;
														}
														goto IL_5440_2;
														IL_5440_2:
														array2[num6 - 1] = 0;
														goto IL_5454_2;
														IL_5454_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_5493_2;
														IL_5493_2:
														ptr2 += 8;
														num = 1203;
														goto IL_5ca0_2;
														IL_54af_2:
														if (145 >= b)
														{
															goto IL_54ba_2;
														}
														goto IL_5530_2;
														IL_54ba_2:
														if (145 > b)
														{
															break;
														}
														goto IL_54c8_2;
														IL_54c8_2:
														array2[num6 - 1] = 5;
														num = 1040;
														goto IL_54e5_2;
														IL_54e5_2:
														array3[num6 - 1] = ((delegate*<List<int>, int[]>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<int>)array3[num6 - 1]);
														goto IL_551d_2;
														IL_551d_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5530_2:
														if (146 < b)
														{
															break;
														}
														goto IL_553e_2;
														IL_553e_2:
														if (146 > b)
														{
															break;
														}
														goto IL_554c_2;
														IL_554c_2:
														((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (int[])array3[num6 - 1];
														goto IL_558a_2;
														IL_558a_2:
														num6 -= 3;
														goto IL_5ca0_2;
														IL_559d_2:
														if (142 <= b)
														{
															goto IL_55a8_2;
														}
														goto IL_560e_2;
														IL_55a8_2:
														array2[num6 - 1] = 3;
														goto IL_55bc_2;
														IL_55bc_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_55fb_2;
														IL_55fb_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_560e_2:
														if (139 >= b)
														{
															goto IL_561c_2;
														}
														goto IL_5707_2;
														IL_561c_2:
														if (139 <= b)
														{
															goto IL_5627_2;
														}
														goto IL_5698_2;
														IL_5627_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_5685_2;
														IL_5685_2:
														num6--;
														goto IL_5ca0_2;
														IL_5698_2:
														if (138 < b)
														{
															break;
														}
														goto IL_56a6_2;
														IL_56a6_2:
														if (138 > b)
														{
															break;
														}
														goto IL_56b4_2;
														IL_56b4_2:
														array2[num6] = 0;
														goto IL_56c2_2;
														IL_56c2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_56e6_2;
														IL_56e6_2:
														num6++;
														goto IL_56f4_2;
														IL_56f4_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5707_2:
														if (140 >= b)
														{
															goto IL_5715_2;
														}
														goto IL_57aa_2;
														IL_5715_2:
														if (140 > b)
														{
															break;
														}
														goto IL_5723_2;
														IL_5723_2:
														array2[num6 - 2] = 0;
														goto IL_5737_2;
														IL_5737_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)getUIContextReturnType[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
														goto IL_5789_2;
														IL_5789_2:
														num6--;
														goto IL_5797_2;
														IL_5797_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_57aa_2:
														if (141 < b)
														{
															break;
														}
														goto IL_57b8_2;
														IL_57b8_2:
														if (141 > b)
														{
															break;
														}
														goto IL_57c6_2;
														IL_57c6_2:
														array3[num6 - 1] = ((delegate*<GameEntityManager, PhotonView>)getUIContextReturnType[*(int*)(ptr2 + num3)])((GameEntityManager)array3[num6 - 1]);
														goto IL_57fe_2;
														IL_57fe_2:
														array2[num6 - 1] = 5;
														goto IL_5812_2;
														IL_5812_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5825_2:
														if (152 >= b)
														{
															goto IL_5833_2;
														}
														goto IL_5a9c_2;
														IL_5833_2:
														if (152 <= b)
														{
															goto IL_583e_2;
														}
														goto IL_58a4_2;
														IL_583e_2:
														array2[num6 - 1] = 3;
														goto IL_5852_2;
														IL_5852_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_5891_2;
														IL_5891_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_58a4_2:
														if (149 >= b)
														{
															goto IL_58b2_2;
														}
														goto IL_599e_2;
														IL_58b2_2:
														if (149 <= b)
														{
															goto IL_58bd_2;
														}
														goto IL_591c_2;
														IL_58bd_2:
														array2[num6 - 1] = 5;
														goto IL_58d1_2;
														IL_58d1_2:
														array3[num6 - 1] = ((delegate*<List<long>, long[]>)getUIContextReturnType[*(int*)(ptr2 + num3)])((List<long>)array3[num6 - 1]);
														goto IL_5909_2;
														IL_5909_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_591c_2:
														if (148 < b)
														{
															break;
														}
														goto IL_592a_2;
														IL_592a_2:
														if (148 > b)
														{
															break;
														}
														goto IL_5938_2;
														IL_5938_2:
														array2[num6 - 1] = 0;
														goto IL_594c_2;
														IL_594c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_598b_2;
														IL_598b_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_599e_2:
														if (150 >= b)
														{
															goto IL_59a9_2;
														}
														goto IL_5a11_2;
														IL_59a9_2:
														if (150 > b)
														{
															break;
														}
														goto IL_59b7_2;
														IL_59b7_2:
														((object[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (long[])array3[num6 - 1];
														goto IL_59f5_2;
														IL_59f5_2:
														num6 -= 3;
														num = 1264;
														goto IL_5ca0_2;
														IL_5a11_2:
														if (151 < b)
														{
															break;
														}
														num = 1065;
														goto IL_5a28_2;
														IL_5c79_2:
														if (156 <= b)
														{
															num = 417;
														}
														break;
														IL_5a28_2:
														if (151 > b)
														{
															break;
														}
														goto IL_5a36_2;
														IL_5a36_2:
														array2[num6 - 1] = 3;
														goto IL_5a4a_2;
														IL_5a4a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_5a89_2;
														IL_5a89_2:
														ptr2 += 8;
														goto IL_5ca0_2;
														IL_5a9c_2:
														if (154 >= b)
														{
															goto IL_5aaa_2;
														}
														goto IL_5bf0_2;
														IL_5aaa_2:
														if (154 <= b)
														{
															goto IL_5ab5_2;
														}
														goto IL_5b1b_2;
														IL_5ab5_2:
														array2[num6 - 1] = 0;
														goto IL_5ac9_2;
														IL_5ac9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getUIContextReturnType[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_5b08_2;
														IL_5b08_2:
														ptr2 += 8;
														goto IL_5ca0_2;
													}
													break;
													IL_1562_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_5ca0_2;
											continue;
											end_IL_1572_2:
											break;
										}
										continue;
										end_IL_1582:
										break;
									}
									continue;
									end_IL_1592:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_25d2_2;
					}
					continue;
					end_IL_25e0:
					break;
				}
				break;
			}
		}
	}

	private void OnDisable()
	{
		Class9.smethod_49();
	}

	private unsafe void method_0()
	{
		int num = 17;
		byte[] array = default(byte[]);
		byte b = default(byte);
		byte* ptr = default(byte*);
		int num6 = default(int);
		object[] array2 = default(object[]);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num7 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 127;
				while (true)
				{
					int num4 = num2 * 8;
					num = 192;
					while (true)
					{
						if (num != 192)
						{
							if (num != 1173)
							{
								goto IL_0c82;
							}
							switch (num)
							{
							case 127:
								goto end_IL_030f;
							case 16:
								goto end_IL_031f;
							case 17:
								goto end_IL_0338;
							case 2:
								goto IL_036a;
							case 61:
							case 106:
								goto IL_0378;
							case 170:
								goto IL_0386;
							case 146:
								goto IL_0394;
							case 162:
								goto IL_039d;
							case 65:
							case 161:
								goto IL_03aa;
							case 63:
								goto IL_03bc;
							case 55:
								goto IL_03ca;
							case 73:
								goto IL_03d8;
							case 155:
								goto IL_03e6;
							case 139:
								goto IL_03f4;
							case 48:
								goto IL_0402;
							case 122:
								goto IL_0410;
							case 44:
								goto IL_041e;
							case 8:
								goto IL_042c;
							case 182:
								goto IL_0437;
							case 137:
							case 150:
								goto IL_0445;
							case 117:
								goto IL_0485;
							case 6:
								goto IL_0499;
							case 156:
								goto IL_04ac;
							case 58:
								goto IL_04ba;
							case 36:
							case 121:
								goto IL_04c8;
							case 26:
								goto IL_0508;
							case 91:
								goto IL_051c;
							case 41:
							case 157:
								goto IL_052f;
							case 50:
								goto IL_0542;
							case 5:
								goto IL_054d;
							case 14:
							case 145:
								goto IL_0564;
							case 126:
								goto IL_05a4;
							case 11:
								goto IL_05b8;
							case 71:
								goto IL_05cb;
							case 59:
								goto IL_05e2;
							case 25:
							case 164:
								goto IL_05f0;
							case 152:
								goto IL_065b;
							case 178:
								goto IL_066e;
							case 84:
							case 124:
								goto IL_0679;
							case 7:
								goto IL_06b9;
							case 54:
								goto IL_06cd;
							case 77:
								goto IL_06e0;
							case 92:
								goto IL_06ee;
							case 10:
							case 68:
								goto IL_06f9;
							case 132:
								goto IL_0739;
							case 62:
								goto IL_074d;
							case 51:
								goto IL_0760;
							case 183:
								goto IL_076e;
							case 113:
							case 134:
								goto IL_077c;
							case 147:
								goto IL_0795;
							case 133:
								goto IL_07a3;
							case 179:
								goto IL_07b1;
							case 108:
								goto IL_07c4;
							case 119:
								goto IL_07d2;
							case 104:
								goto IL_07e0;
							case 60:
							case 176:
								goto IL_07ee;
							case 66:
								goto IL_07fc;
							case 184:
								goto IL_081f;
							case 135:
								goto IL_0832;
							case 98:
								goto IL_0840;
							case 153:
								goto IL_085c;
							case 23:
							case 82:
								goto IL_086a;
							case 43:
								goto IL_0893;
							case 166:
								goto IL_08a1;
							case 169:
								goto IL_08b4;
							case 172:
								goto IL_08c2;
							case 46:
							case 151:
								goto IL_08cd;
							case 140:
								goto IL_08e6;
							case 97:
								goto IL_08fd;
							case 72:
								goto IL_090b;
							case 130:
								goto IL_091e;
							case 22:
								goto IL_092c;
							case 40:
							case 87:
								goto IL_0937;
							case 141:
								goto IL_0978;
							case 109:
								goto IL_098c;
							case 144:
								goto IL_099f;
							case 102:
								goto IL_09aa;
							case 1:
							case 101:
								goto IL_09b8;
							case 28:
								goto IL_09d1;
							case 89:
								goto IL_09df;
							case 185:
								goto IL_09ed;
							case 88:
								goto IL_0a00;
							case 75:
								goto IL_0a0e;
							case 67:
							case 180:
								goto IL_0a1c;
							case 125:
								goto IL_0a34;
							case 95:
								goto IL_0a3f;
							case 42:
							case 57:
								goto IL_0a4d;
							case 177:
								goto IL_0aa8;
							case 114:
								goto IL_0abb;
							case 118:
								goto IL_0ac9;
							case 39:
							case 115:
								goto IL_0ad7;
							case 96:
								goto IL_0aec;
							case 165:
								goto IL_0aff;
							case 99:
								goto IL_0b0d;
							case 128:
								goto IL_0b1b;
							case 148:
								goto IL_0b26;
							case 15:
							case 107:
								goto IL_0b34;
							case 129:
								goto IL_0b48;
							case 110:
								goto IL_0b87;
							case 111:
								goto IL_0ba3;
							case 142:
								goto IL_0bb1;
							case 0:
							case 94:
								goto IL_0bbf;
							case 38:
								goto IL_0bff;
							case 47:
								goto IL_0c13;
							case 9:
							case 158:
								goto IL_0c26;
							case 100:
								goto IL_0c43;
							case 86:
								goto IL_0c82;
							case 49:
								goto IL_0c92;
							case 167:
								goto IL_0c9d;
							case 29:
							case 45:
								goto IL_0ca8;
							case 18:
								goto IL_0cca;
							case 90:
								goto IL_0cd5;
							case 12:
							case 20:
							case 24:
							case 30:
							case 31:
							case 35:
							case 37:
							case 53:
							case 56:
							case 64:
							case 76:
							case 78:
							case 83:
							case 103:
							case 123:
							case 131:
							case 136:
							case 138:
							case 143:
							case 159:
							case 160:
							case 163:
							case 168:
							case 173:
							case 174:
								goto IL_0ce0;
							case 3:
							case 4:
							case 13:
							case 21:
							case 27:
							case 32:
							case 33:
							case 34:
							case 52:
							case 69:
							case 74:
							case 79:
							case 80:
							case 81:
							case 85:
							case 93:
							case 105:
							case 112:
							case 116:
							case 120:
							case 149:
							case 154:
							case 171:
							case 175:
							case 181:
								goto IL_0cfc;
							case 19:
							case 70:
								return;
							}
							continue;
						}
						array = new byte[3];
						goto IL_036a;
						IL_0c92:
						if (21 >= b)
						{
							goto IL_0c9d;
						}
						goto IL_0cca;
						IL_0ca8:
						byte* num5 = ptr;
						num6 = 1;
						ptr = num5 + -200;
						num = 171;
						goto IL_0cfc;
						IL_0c9d:
						if (21 <= b)
						{
							goto IL_0ca8;
						}
						goto IL_0ce0;
						IL_036a:
						array2 = new object[3];
						goto IL_0378;
						IL_0378:
						array3 = new int[7];
						goto IL_0386;
						IL_0386:
						array4 = new long[3];
						goto IL_0394;
						IL_0394:
						ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetCreationTimepromise.VoidTaskResultTokenPrimary);
						goto IL_039d;
						IL_039d:
						ptr = ptr2;
						goto IL_0cfc;
						IL_0cfc:
						if (num6 == 1)
						{
							return;
						}
						goto IL_03aa;
						IL_03aa:
						b = *ptr;
						num = 63;
						goto IL_03bc;
						IL_03bc:
						ptr++;
						goto IL_03ca;
						IL_03ca:
						if (b >= 1)
						{
							goto IL_03d8;
						}
						goto IL_0ce0;
						IL_03d8:
						if (b <= 22)
						{
							goto IL_03e6;
						}
						goto IL_0ce0;
						IL_03e6:
						if (11 >= b)
						{
							goto IL_03f4;
						}
						goto IL_08b4;
						IL_03f4:
						if (11 > b)
						{
							goto IL_0402;
						}
						goto IL_0cfc;
						IL_0402:
						if (5 < b)
						{
							goto IL_0410;
						}
						goto IL_066e;
						IL_0410:
						if (8 >= b)
						{
							goto IL_041e;
						}
						goto IL_0542;
						IL_041e:
						if (8 > b)
						{
							goto IL_042c;
						}
						goto IL_052f;
						IL_042c:
						if (6 >= b)
						{
							goto IL_0437;
						}
						goto IL_04ac;
						IL_0437:
						if (6 <= b)
						{
							goto IL_0445;
						}
						goto IL_0ce0;
						IL_0445:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_0485;
						IL_0485:
						array[num7 - 2] = 0;
						goto IL_0499;
						IL_0499:
						num7--;
						goto IL_0cfc;
						IL_04ac:
						if (7 >= b)
						{
							goto IL_04ba;
						}
						goto IL_0ce0;
						IL_04ba:
						if (7 <= b)
						{
							goto IL_04c8;
						}
						goto IL_0ce0;
						IL_04c8:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_0508;
						IL_0508:
						array[num7 - 2] = 0;
						goto IL_051c;
						IL_051c:
						num7--;
						goto IL_0cfc;
						IL_052f:
						num7--;
						goto IL_0cfc;
						IL_0542:
						if (9 >= b)
						{
							goto IL_054d;
						}
						goto IL_05cb;
						IL_054d:
						if (9 <= b)
						{
							num = 14;
							goto IL_0564;
						}
						goto IL_0ce0;
						IL_0cca:
						if (22 >= b)
						{
							goto IL_0cd5;
						}
						goto IL_0ce0;
						IL_0564:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_05a4;
						IL_05a4:
						array[num7 - 2] = 0;
						goto IL_05b8;
						IL_05b8:
						num7--;
						goto IL_0cfc;
						IL_05cb:
						if (10 >= b)
						{
							num = 59;
							goto IL_05e2;
						}
						goto IL_0ce0;
						IL_0cd5:
						if (22 <= b)
						{
						}
						goto IL_0ce0;
						IL_05e2:
						if (10 <= b)
						{
							goto IL_05f0;
						}
						goto IL_0ce0;
						IL_05f0:
						ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						num = 152;
						goto IL_065b;
						IL_065b:
						num7 -= 2;
						goto IL_0cfc;
						IL_066e:
						if (5 <= b)
						{
							goto IL_0679;
						}
						goto IL_06e0;
						IL_0679:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_06b9;
						IL_06b9:
						array[num7 - 2] = 0;
						goto IL_06cd;
						IL_06cd:
						num7--;
						goto IL_0cfc;
						IL_06e0:
						if (2 >= b)
						{
							goto IL_06ee;
						}
						goto IL_07c4;
						IL_06ee:
						if (2 <= b)
						{
							goto IL_06f9;
						}
						goto IL_0760;
						IL_06f9:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_0739;
						IL_0739:
						array[num7 - 2] = 0;
						goto IL_074d;
						IL_074d:
						num7--;
						goto IL_0cfc;
						IL_0760:
						if (1 >= b)
						{
							goto IL_076e;
						}
						goto IL_0ce0;
						IL_076e:
						if (1 <= b)
						{
							goto IL_077c;
						}
						goto IL_0ce0;
						IL_077c:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(int*)(ptr + num3);
						goto IL_0795;
						IL_0795:
						array[num7] = 0;
						goto IL_07a3;
						IL_07a3:
						num7++;
						goto IL_07b1;
						IL_07b1:
						ptr += 8;
						goto IL_0cfc;
						IL_07c4:
						if (3 < b)
						{
							goto IL_07d2;
						}
						num = 153;
						goto IL_085c;
						IL_07d2:
						if (4 >= b)
						{
							goto IL_07e0;
						}
						goto IL_0ce0;
						IL_07e0:
						if (4 <= b)
						{
							goto IL_07ee;
						}
						goto IL_0ce0;
						IL_07ee:
						array[num7] = 0;
						goto IL_07fc;
						IL_07fc:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = array3[*(int*)(ptr + num3)];
						goto IL_081f;
						IL_081f:
						array2[num7] = null;
						num = 135;
						goto IL_0832;
						IL_0832:
						num7++;
						goto IL_0840;
						IL_0840:
						ptr += 8;
						goto IL_0cfc;
						IL_0ce0:
						ptr = ptr2 + *(int*)(ptr + num3);
						num = 81;
						goto IL_0cfc;
						IL_085c:
						if (3 <= b)
						{
							goto IL_086a;
						}
						goto IL_0ce0;
						IL_086a:
						ref int reference = ref array3[*(int*)(ptr + num3)];
						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_0893;
						IL_0893:
						ptr += 8;
						goto IL_08a1;
						IL_08a1:
						num7--;
						goto IL_0cfc;
						IL_08b4:
						if (17 >= b)
						{
							goto IL_08c2;
						}
						goto IL_0aff;
						IL_08c2:
						if (17 <= b)
						{
							goto IL_08cd;
						}
						goto IL_091e;
						IL_08cd:
						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(double*)(ptr + num4);
						goto IL_08e6;
						IL_08e6:
						array[num7] = 3;
						num = 97;
						goto IL_08fd;
						IL_08fd:
						num7++;
						goto IL_090b;
						IL_090b:
						ptr += 16;
						goto IL_0cfc;
						IL_091e:
						if (14 >= b)
						{
							goto IL_092c;
						}
						goto IL_0a34;
						IL_092c:
						if (14 <= b)
						{
							goto IL_0937;
						}
						goto IL_099f;
						IL_0937:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0);
						goto IL_0978;
						IL_0978:
						array[num7 - 2] = 0;
						goto IL_098c;
						IL_098c:
						num7--;
						goto IL_0cfc;
						IL_099f:
						if (12 >= b)
						{
							goto IL_09aa;
						}
						goto IL_0a00;
						IL_09aa:
						if (12 <= b)
						{
							goto IL_09b8;
						}
						goto IL_0ce0;
						IL_09b8:
						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(long*)(ptr + num4);
						goto IL_09d1;
						IL_09d1:
						array[num7] = 1;
						goto IL_09df;
						IL_09df:
						num7++;
						goto IL_09ed;
						IL_09ed:
						ptr += 16;
						goto IL_0cfc;
						IL_0a00:
						if (13 >= b)
						{
							goto IL_0a0e;
						}
						goto IL_0ce0;
						IL_0a0e:
						if (13 <= b)
						{
							goto IL_0a1c;
						}
						goto IL_0ce0;
						IL_0a1c:
						ptr = ptr2 + *(int*)(ptr + num3);
						goto IL_0cfc;
						IL_0a34:
						if (15 >= b)
						{
							goto IL_0a3f;
						}
						goto IL_0abb;
						IL_0a3f:
						if (15 <= b)
						{
							goto IL_0a4d;
						}
						goto IL_0ce0;
						IL_0a4d:
						ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
						num = 177;
						goto IL_0aa8;
						IL_0aa8:
						num7--;
						goto IL_0cfc;
						IL_0abb:
						if (16 >= b)
						{
							goto IL_0ac9;
						}
						goto IL_0ce0;
						IL_0ac9:
						if (16 <= b)
						{
							goto IL_0ad7;
						}
						goto IL_0ce0;
						IL_0ad7:
						((delegate*<void>)DisableOptimizationsgetEmbedded[*(int*)(ptr + num3)])();
						goto IL_0aec;
						IL_0aec:
						ptr += 8;
						goto IL_0cfc;
						IL_0aff:
						if (20 >= b)
						{
							goto IL_0b0d;
						}
						goto IL_0c92;
						IL_0b0d:
						if (20 > b)
						{
							goto IL_0b1b;
						}
						goto IL_0c26;
						IL_0b1b:
						if (18 >= b)
						{
							goto IL_0b26;
						}
						goto IL_0ba3;
						IL_0b26:
						if (18 <= b)
						{
							goto IL_0b34;
						}
						goto IL_0ce0;
						IL_0b34:
						array[num7 - 1] = 3;
						goto IL_0b48;
						IL_0b48:
						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, double>)DisableOptimizationsgetEmbedded[*(int*)(ptr + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
						goto IL_0b87;
						IL_0b87:
						ptr += 8;
						num = 85;
						goto IL_0cfc;
						IL_0ba3:
						if (19 >= b)
						{
							goto IL_0bb1;
						}
						goto IL_0ce0;
						IL_0bb1:
						if (19 <= b)
						{
							goto IL_0bbf;
						}
						goto IL_0ce0;
						IL_0bbf:
						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
						goto IL_0bff;
						IL_0bff:
						array[num7 - 2] = 3;
						goto IL_0c13;
						IL_0c13:
						num7--;
						goto IL_0cfc;
						IL_0c26:
						array[num7 - 1] = 0;
						num = 100;
						goto IL_0c43;
						IL_0c43:
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, int>)DisableOptimizationsgetEmbedded[*(int*)(ptr + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
						goto IL_0c82;
						IL_0c82:
						ptr += 8;
						goto IL_0cfc;
						continue;
						end_IL_030f:
						break;
					}
					continue;
					end_IL_031f:
					break;
				}
				continue;
				end_IL_0338:
				break;
			}
		}
	}

	public Class121()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 65;
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		int num6 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						IL_0200:
						object[] array2 = new object[2];
						while (true)
						{
							IL_01f0:
							int[] array3 = new int[3];
							while (true)
							{
								IL_01e0:
								long[] array4 = new long[2];
								while (true)
								{
									IL_01cb:
									array3[0] = int_2;
									while (true)
									{
										IL_01b6:
										array3[1] = int_3;
										while (true)
										{
											IL_01a2:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PfxsetArgs.RemotingProfilerEventTypeRef);
											num = 96;
											while (true)
											{
												if (num != 96)
												{
													if (num != 1077)
													{
														break;
													}
													switch (num)
													{
													case 76:
														goto IL_01a2;
													case 75:
														goto IL_01b6;
													case 16:
														goto IL_01cb;
													case 36:
														goto IL_01e0;
													case 78:
													case 86:
														goto IL_01f0;
													case 6:
														goto IL_0200;
													case 8:
													case 63:
														goto end_IL_018f;
													case 64:
														goto end_IL_0210;
													case 65:
														goto end_IL_0220;
													case 17:
													case 18:
													case 21:
													case 30:
													case 34:
													case 46:
													case 53:
													case 55:
													case 73:
													case 79:
													case 80:
														goto IL_0243;
													case 12:
													case 68:
														goto IL_0253;
													case 71:
														goto IL_025c;
													case 85:
														goto IL_026a;
													case 49:
														goto IL_0278;
													case 33:
														goto IL_0286;
													case 84:
														goto IL_0294;
													case 25:
													case 45:
														goto IL_02a2;
													case 60:
														goto IL_02b0;
													case 47:
														goto IL_02bb;
													case 38:
														goto IL_02c6;
													case 56:
													case 82:
														goto IL_02f0;
													case 74:
														goto IL_035e;
													case 28:
														goto IL_0371;
													case 15:
														goto IL_037f;
													case 7:
													case 66:
														goto IL_038d;
													case 88:
														goto IL_03cd;
													case 70:
														goto IL_03e1;
													case 10:
													case 57:
														goto IL_03f4;
													case 3:
														goto IL_0426;
													case 9:
														goto IL_0434;
													case 5:
														goto IL_0447;
													case 32:
														goto IL_0452;
													case 87:
														goto IL_0460;
													case 2:
														goto IL_046e;
													case 11:
													case 41:
														goto IL_047c;
													case 22:
														goto IL_0494;
													case 40:
														goto IL_049f;
													case 24:
													case 39:
														goto IL_04ad;
													case 59:
														goto IL_04bb;
													case 81:
														goto IL_04de;
													case 37:
														goto IL_04e8;
													case 51:
														goto IL_04f6;
													case 54:
														goto IL_0509;
													case 48:
														goto IL_0514;
													case 61:
													case 69:
														goto IL_051f;
													case 27:
														goto IL_053b;
													case 31:
														goto IL_0549;
													case 19:
														goto IL_0557;
													case 1:
													case 4:
													case 13:
													case 14:
													case 20:
													case 23:
													case 26:
													case 29:
													case 35:
													case 42:
													case 43:
													case 44:
													case 50:
													case 52:
													case 58:
													case 62:
													case 67:
													case 77:
													case 83:
													case 89:
														goto IL_056a;
													case 0:
													case 72:
														goto IL_058f;
													}
													continue;
												}
												ptr2 = ptr;
												goto IL_0243;
												IL_051f:
												byte* num4 = ptr2;
												num5 = 1;
												ptr2 = num4 + -200;
												goto IL_0243;
												IL_053b:
												array[num6] = 0;
												goto IL_0549;
												IL_056a:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
												goto IL_053b;
												IL_0243:
												if (num5 != 1)
												{
													goto IL_0253;
												}
												goto IL_058f;
												IL_058f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												IL_0253:
												b = *ptr2;
												goto IL_025c;
												IL_025c:
												ptr2++;
												goto IL_026a;
												IL_026a:
												if (b >= 1)
												{
													goto IL_0278;
												}
												goto IL_056a;
												IL_0278:
												if (b <= 8)
												{
													goto IL_0286;
												}
												goto IL_056a;
												IL_0286:
												if (4 >= b)
												{
													goto IL_0294;
												}
												goto IL_0447;
												IL_0294:
												if (4 > b)
												{
													goto IL_02a2;
												}
												goto IL_03f4;
												IL_02a2:
												if (2 >= b)
												{
													goto IL_02b0;
												}
												goto IL_0371;
												IL_02b0:
												if (2 > b)
												{
													goto IL_02bb;
												}
												num = 56;
												goto IL_02f0;
												IL_02bb:
												if (1 >= b)
												{
													goto IL_02c6;
												}
												num = 77;
												goto IL_056a;
												IL_02c6:
												if (1 <= b)
												{
												}
												goto IL_056a;
												IL_0557:
												ptr2 += 8;
												goto IL_0243;
												IL_0549:
												num6++;
												goto IL_0557;
												IL_02f0:
												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_035e;
												IL_035e:
												num6 -= 2;
												goto IL_0243;
												IL_0371:
												if (3 >= b)
												{
													goto IL_037f;
												}
												goto IL_056a;
												IL_037f:
												if (3 <= b)
												{
													goto IL_038d;
												}
												goto IL_056a;
												IL_038d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												goto IL_03cd;
												IL_03cd:
												array[num6 - 2] = 0;
												goto IL_03e1;
												IL_03e1:
												num6--;
												goto IL_0243;
												IL_03f4:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												num = 3;
												goto IL_0426;
												IL_0426:
												ptr2 += 8;
												goto IL_0434;
												IL_0434:
												num6--;
												goto IL_0243;
												IL_0447:
												if (6 >= b)
												{
													goto IL_0452;
												}
												goto IL_0494;
												IL_0452:
												if (6 <= b)
												{
													goto IL_0243;
												}
												goto IL_0460;
												IL_0460:
												if (5 >= b)
												{
													goto IL_046e;
												}
												goto IL_056a;
												IL_046e:
												if (5 <= b)
												{
													goto IL_047c;
												}
												goto IL_056a;
												IL_047c:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0243;
												IL_0494:
												if (7 >= b)
												{
													goto IL_049f;
												}
												goto IL_0509;
												IL_049f:
												if (7 <= b)
												{
													goto IL_04ad;
												}
												goto IL_056a;
												IL_04ad:
												array[num6] = 0;
												goto IL_04bb;
												IL_04bb:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
												goto IL_04de;
												IL_04de:
												array2[num6] = null;
												goto IL_04e8;
												IL_04e8:
												num6++;
												goto IL_04f6;
												IL_04f6:
												ptr2 += 8;
												goto IL_0243;
												IL_0509:
												if (8 >= b)
												{
													goto IL_0514;
												}
												goto IL_056a;
												IL_0514:
												if (8 <= b)
												{
													goto IL_051f;
												}
												goto IL_056a;
												continue;
												end_IL_018f:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_0210:
					break;
				}
				continue;
				end_IL_0220:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 44;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AwaitTaskContinuationScheduledProgressStatics.ReplyCATEGORYINSTANCE);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 61;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0248:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0228:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0218:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0208:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_01fb:
																										if (6 < b)
																										{
																											while (true)
																											{
																												IL_01e8:
																												if (7 < b)
																												{
																													num = 110;
																													while (num != 110)
																													{
																														if (num != 1091)
																														{
																															goto IL_047d;
																														}
																														switch (num)
																														{
																														case 10:
																															goto IL_01e8;
																														case 66:
																															goto IL_01fb;
																														case 60:
																															goto IL_0208;
																														case 1:
																														case 93:
																															goto IL_0218;
																														case 48:
																															goto IL_0228;
																														case 101:
																															goto IL_0238;
																														case 99:
																															goto IL_0248;
																														case 50:
																															goto end_IL_0248;
																														case 61:
																															goto end_IL_0258;
																														case 46:
																															goto end_IL_0268;
																														case 9:
																															goto IL_027e;
																														case 25:
																															goto IL_0291;
																														case 6:
																														case 59:
																															goto IL_029f;
																														case 33:
																															goto IL_02c2;
																														case 17:
																															goto IL_02d0;
																														case 15:
																														case 92:
																															goto IL_02e0;
																														case 12:
																															goto IL_0342;
																														case 100:
																															goto IL_0355;
																														case 51:
																														case 102:
																															goto IL_0371;
																														case 69:
																															goto IL_03b1;
																														case 47:
																															goto IL_03c5;
																														case 52:
																															goto IL_03d8;
																														case 77:
																															goto IL_03e3;
																														case 54:
																														case 83:
																															goto IL_03f1;
																														case 85:
																														case 86:
																															goto IL_0416;
																														case 24:
																															goto IL_0424;
																														case 2:
																															goto IL_0437;
																														case 19:
																														case 97:
																															goto IL_0442;
																														case 16:
																															goto IL_0450;
																														case 39:
																															goto IL_0473;
																														case 18:
																															goto IL_047d;
																														case 26:
																															goto IL_048b;
																														case 103:
																															goto IL_049e;
																														case 53:
																															goto IL_04ac;
																														case 13:
																														case 14:
																															goto IL_04b7;
																														case 49:
																															goto IL_04e0;
																														case 72:
																															goto IL_04ee;
																														case 82:
																															goto IL_0501;
																														case 35:
																															goto IL_050f;
																														case 45:
																														case 84:
																															goto IL_051d;
																														case 40:
																															goto IL_0536;
																														case 91:
																															goto IL_0544;
																														case 65:
																															goto IL_0552;
																														case 70:
																															goto IL_0562;
																														case 64:
																															goto IL_056d;
																														case 42:
																														case 87:
																															goto IL_0578;
																														case 68:
																															goto IL_058d;
																														case 38:
																															goto IL_0598;
																														case 4:
																														case 8:
																														case 11:
																														case 21:
																														case 22:
																														case 30:
																														case 31:
																														case 32:
																														case 34:
																														case 36:
																														case 71:
																														case 73:
																														case 74:
																														case 76:
																														case 80:
																														case 88:
																														case 89:
																														case 95:
																														case 96:
																														case 98:
																															goto end_IL_01d5;
																														case 3:
																														case 5:
																														case 7:
																														case 27:
																														case 28:
																														case 29:
																														case 37:
																														case 41:
																														case 55:
																														case 67:
																														case 78:
																														case 79:
																														case 90:
																															goto end_IL_0273;
																														case 56:
																															goto end_IL_05b6;
																														case 81:
																															goto end_IL_05c9;
																														case 62:
																															goto end_IL_05d3;
																														case 75:
																															goto end_IL_05de;
																														case 23:
																														case 57:
																															goto end_IL_05f3;
																														case 63:
																															goto end_IL_0603;
																														case 58:
																														case 94:
																															goto end_IL_0613;
																														case 43:
																															goto end_IL_0623;
																														case 44:
																															goto end_IL_0633;
																														case 0:
																														case 20:
																															goto IL_064e;
																														}
																														continue;
																														end_IL_01d5:
																														break;
																													}
																													break;
																												}
																												goto IL_0291;
																												IL_02d0:
																												num5++;
																												goto IL_0355;
																												IL_0355:
																												ptr2 += 8;
																												num = 28;
																												goto end_IL_0273;
																												IL_0291:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_029f;
																												IL_029f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_02c2;
																												IL_02c2:
																												array[num5] = 0;
																												goto IL_02d0;
																											}
																											break;
																										}
																										goto IL_027e;
																										IL_03c5:
																										num5--;
																										goto end_IL_0273;
																										IL_027e:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_0371;
																										IL_0371:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03b1;
																										IL_03b1:
																										array[num5 - 2] = 0;
																										goto IL_03c5;
																									}
																									break;
																								}
																								goto IL_02e0;
																								IL_0342:
																								num5 -= 2;
																								goto end_IL_0273;
																								IL_02e0:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0342;
																							}
																							break;
																						}
																						goto IL_03d8;
																						IL_0416:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0424;
																						IL_03d8:
																						if (9 >= b)
																						{
																							goto IL_03e3;
																						}
																						num = 85;
																						goto IL_0416;
																						IL_03e3:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_03f1;
																						IL_03f1:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0273;
																						IL_0424:
																						if (10 <= b)
																						{
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_0437;
																				IL_0598:
																				if (4 <= b)
																				{
																					goto end_IL_0273;
																				}
																				break;
																				IL_0437:
																				if (5 <= b)
																				{
																					goto IL_0442;
																				}
																				goto IL_049e;
																				IL_0442:
																				array[num5] = 0;
																				goto IL_0450;
																				IL_0450:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0473;
																				IL_0473:
																				array2[num5] = null;
																				goto IL_047d;
																				IL_047d:
																				num5++;
																				goto IL_048b;
																				IL_048b:
																				ptr2 += 8;
																				goto end_IL_0273;
																				IL_049e:
																				if (2 >= b)
																				{
																					goto IL_04ac;
																				}
																				goto IL_0562;
																				IL_04ac:
																				if (2 <= b)
																				{
																					goto IL_04b7;
																				}
																				goto IL_0501;
																				IL_04b7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e0;
																				IL_04e0:
																				ptr2 += 8;
																				goto IL_04ee;
																				IL_04ee:
																				num5--;
																				goto end_IL_0273;
																				IL_0501:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_050f;
																				IL_050f:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_051d;
																				IL_051d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0536;
																				IL_0536:
																				array[num5] = 0;
																				goto IL_0544;
																				IL_0544:
																				num5++;
																				goto IL_0552;
																				IL_0552:
																				ptr2 += 8;
																				goto end_IL_0273;
																				IL_0562:
																				if (3 >= b)
																				{
																					goto IL_056d;
																				}
																				goto IL_058d;
																				IL_056d:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0578;
																				IL_0578:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0273;
																				IL_058d:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0598;
																			}
																			break;
																			IL_0238:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0273;
																	continue;
																	end_IL_0248:
																	break;
																}
																continue;
																end_IL_0258:
																break;
															}
															continue;
															end_IL_0268:
															break;
														}
														continue;
														end_IL_0273:
														break;
													}
													continue;
												}
												goto IL_064e;
												IL_064e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b6:
												break;
											}
											continue;
											end_IL_05c9:
											break;
										}
										continue;
										end_IL_05d3:
										break;
									}
									continue;
									end_IL_05de:
									break;
								}
								continue;
								end_IL_05f3:
								break;
							}
							continue;
							end_IL_0603:
							break;
						}
						continue;
						end_IL_0613:
						break;
					}
					continue;
					end_IL_0623:
					break;
				}
				continue;
				end_IL_0633:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ActivityInfoIsGranted.CMSUSAGEPATTERNSCOPEPROCESSgetIsClass);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0218:
														byte b = *ptr2;
														while (true)
														{
															IL_0208:
															ptr2++;
															while (true)
															{
																IL_01f8:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_01e8:
																		if (b > 10)
																		{
																			num = 110;
																			while (num != 110)
																			{
																				if (num != 1091)
																				{
																					goto end_IL_01f8;
																				}
																				switch (num)
																				{
																				case 90:
																					goto IL_01e8;
																				case 70:
																					goto IL_01f8;
																				case 44:
																					goto IL_0208;
																				case 76:
																				case 78:
																					goto IL_0218;
																				case 89:
																					goto IL_0223;
																				case 32:
																					goto IL_0231;
																				case 34:
																				case 79:
																					goto IL_023c;
																				case 6:
																					goto IL_024a;
																				case 15:
																					goto IL_026d;
																				case 83:
																					goto IL_0277;
																				case 38:
																					goto IL_0285;
																				case 72:
																					goto IL_0298;
																				case 58:
																					goto IL_02a3;
																				case 14:
																				case 87:
																					goto IL_02ae;
																				case 65:
																					goto IL_02bc;
																				case 91:
																					goto IL_02d8;
																				case 28:
																				case 74:
																					goto IL_02e3;
																				case 56:
																					goto IL_0309;
																				case 20:
																				case 99:
																					goto IL_031d;
																				case 73:
																					goto IL_032b;
																				case 4:
																				case 9:
																					goto IL_0339;
																				case 77:
																					goto IL_0352;
																				case 21:
																					goto IL_0360;
																				case 84:
																					goto IL_036e;
																				case 30:
																				case 42:
																					goto IL_038a;
																				case 71:
																					goto IL_03b3;
																				case 36:
																					goto IL_03ca;
																				case 64:
																				case 95:
																					goto IL_03e6;
																				case 43:
																					goto IL_03f4;
																				case 1:
																				case 92:
																					goto IL_03ff;
																				case 60:
																					goto IL_0461;
																				case 18:
																					goto IL_0474;
																				case 23:
																					goto IL_047f;
																				case 46:
																					goto IL_048d;
																				case 0:
																				case 2:
																					goto IL_049b;
																				case 55:
																					goto IL_04be;
																				case 94:
																					goto IL_04cc;
																				case 13:
																					goto IL_04da;
																				case 16:
																					goto IL_04ed;
																				case 48:
																				case 50:
																					goto IL_0506;
																				case 82:
																					goto IL_0546;
																				case 37:
																					goto IL_0563;
																				case 53:
																					goto IL_0573;
																				case 45:
																					goto IL_057e;
																				case 11:
																				case 103:
																					goto IL_0589;
																				case 80:
																					goto IL_05a2;
																				case 35:
																					goto IL_05ad;
																				case 8:
																				case 10:
																				case 12:
																				case 17:
																				case 19:
																				case 27:
																				case 31:
																				case 39:
																				case 59:
																				case 61:
																				case 62:
																				case 67:
																				case 68:
																				case 75:
																				case 86:
																				case 88:
																				case 96:
																				case 98:
																				case 102:
																					goto end_IL_01d5;
																				case 3:
																				case 22:
																				case 26:
																				case 29:
																				case 41:
																				case 47:
																				case 51:
																				case 54:
																				case 57:
																				case 63:
																				case 69:
																				case 81:
																				case 85:
																					goto end_IL_01f8;
																				case 40:
																					goto end_IL_05cb;
																				case 24:
																					goto end_IL_05de;
																				case 7:
																					goto end_IL_05e8;
																				case 66:
																					goto end_IL_05f3;
																				case 25:
																				case 33:
																					goto end_IL_0608;
																				case 93:
																					goto end_IL_0618;
																				case 5:
																				case 97:
																					goto end_IL_0628;
																				case 100:
																					goto end_IL_0638;
																				case 101:
																					goto end_IL_0648;
																				case 49:
																				case 52:
																					goto IL_0663;
																				}
																				continue;
																				end_IL_01d5:
																				break;
																			}
																			break;
																		}
																		goto IL_0223;
																		IL_0546:
																		array[num5 - 2] = 0;
																		num = 37;
																		goto IL_0563;
																		IL_0563:
																		num5--;
																		goto end_IL_01f8;
																		IL_0223:
																		if (5 >= b)
																		{
																			goto IL_0231;
																		}
																		num = 95;
																		goto IL_03e6;
																		IL_0231:
																		if (5 <= b)
																		{
																			goto IL_023c;
																		}
																		goto IL_0298;
																		IL_023c:
																		array[num5] = 0;
																		goto IL_024a;
																		IL_024a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_026d;
																		IL_026d:
																		array2[num5] = null;
																		goto IL_0277;
																		IL_0277:
																		num5++;
																		goto IL_0285;
																		IL_0285:
																		ptr2 += 8;
																		goto end_IL_01f8;
																		IL_0298:
																		if (2 < b)
																		{
																			goto IL_02a3;
																		}
																		goto IL_0309;
																		IL_02a3:
																		if (3 < b)
																		{
																			goto IL_02ae;
																		}
																		goto IL_02d8;
																		IL_02ae:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_02bc;
																		IL_02bc:
																		if (4 > b)
																		{
																			break;
																		}
																		num = 57;
																		goto end_IL_01f8;
																		IL_057e:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_0589;
																		IL_02d8:
																		if (3 > b)
																		{
																			num = 39;
																			break;
																		}
																		goto IL_02e3;
																		IL_02e3:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_01f8;
																		IL_0589:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_01f8;
																		IL_0309:
																		if (2 > b)
																		{
																			num = 20;
																			goto IL_031d;
																		}
																		goto IL_038a;
																		IL_05a2:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_05ad;
																		IL_031d:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_032b;
																		IL_032b:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0339;
																		IL_0339:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0352;
																		IL_0352:
																		array[num5] = 0;
																		goto IL_0360;
																		IL_0360:
																		num5++;
																		goto IL_036e;
																		IL_036e:
																		ptr2 += 8;
																		num = 3;
																		goto end_IL_01f8;
																		IL_038a:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_03b3;
																		IL_03b3:
																		ptr2 += 8;
																		num = 36;
																		goto IL_03ca;
																		IL_03ca:
																		num5--;
																		goto end_IL_01f8;
																		IL_0573:
																		if (9 >= b)
																		{
																			goto IL_057e;
																		}
																		goto IL_05a2;
																		IL_03e6:
																		if (8 >= b)
																		{
																			goto IL_03f4;
																		}
																		goto IL_0573;
																		IL_03f4:
																		if (8 <= b)
																		{
																			goto IL_03ff;
																		}
																		goto IL_0474;
																		IL_03ff:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0461;
																		IL_0461:
																		num5 -= 2;
																		goto end_IL_01f8;
																		IL_0474:
																		if (6 < b)
																		{
																			goto IL_047f;
																		}
																		goto IL_04ed;
																		IL_047f:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_048d;
																		IL_048d:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_049b;
																		IL_049b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04be;
																		IL_04be:
																		array[num5] = 0;
																		goto IL_04cc;
																		IL_04cc:
																		num5++;
																		goto IL_04da;
																		IL_04da:
																		ptr2 += 8;
																		goto end_IL_01f8;
																		IL_04ed:
																		if (6 > b)
																		{
																			num = 67;
																			break;
																		}
																		goto IL_0506;
																		IL_05ad:
																		if (10 <= b)
																		{
																		}
																		break;
																		IL_0506:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0546;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_01f8:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0663;
												IL_0663:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05cb:
												break;
											}
											continue;
											end_IL_05de:
											break;
										}
										continue;
										end_IL_05e8:
										break;
									}
									continue;
									end_IL_05f3:
									break;
								}
								continue;
								end_IL_0608:
								break;
							}
							continue;
							end_IL_0618:
							break;
						}
						continue;
						end_IL_0628:
						break;
					}
					continue;
					end_IL_0638:
					break;
				}
				continue;
				end_IL_0648:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 67;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 35;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CookiesDefineVersionInfoResource.AppDomainUnloadedExceptionFileSystemEnumerableIterator);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 133;
												while (true)
												{
													if (num == 133)
													{
														goto IL_02cf;
													}
													if (num != 1114)
													{
														goto IL_067e;
													}
													switch (num)
													{
													case 64:
														goto end_IL_0223;
													case 2:
														goto end_IL_0236;
													case 121:
														goto end_IL_0249;
													case 75:
														goto end_IL_0254;
													case 35:
														goto end_IL_0269;
													case 78:
														goto end_IL_0279;
													case 44:
														goto end_IL_0289;
													case 19:
													case 53:
														goto end_IL_0294;
													case 66:
														goto end_IL_02a4;
													case 67:
														goto end_IL_02b4;
													case 4:
													case 8:
													case 34:
													case 37:
													case 46:
													case 52:
													case 56:
													case 57:
													case 59:
													case 60:
													case 73:
													case 99:
													case 113:
													case 122:
													case 126:
														goto IL_02cf;
													case 27:
													case 48:
														goto IL_02df;
													case 74:
														goto IL_02e8;
													case 94:
														goto IL_02f6;
													case 43:
														goto IL_0304;
													case 30:
														goto IL_0312;
													case 106:
														goto IL_0320;
													case 23:
														goto IL_032e;
													case 51:
													case 54:
														goto IL_033c;
													case 82:
														goto IL_034a;
													case 20:
													case 28:
														goto IL_0358;
													case 13:
														goto IL_03ba;
													case 7:
													case 41:
														goto IL_03cd;
													case 31:
														goto IL_03db;
													case 77:
													case 95:
														goto IL_03e9;
													case 114:
														goto IL_0429;
													case 119:
														goto IL_043d;
													case 69:
													case 98:
														goto IL_0450;
													case 24:
														goto IL_0464;
													case 15:
														goto IL_04a3;
													case 65:
													case 92:
														goto IL_04b6;
													case 70:
														goto IL_04c1;
													case 50:
														goto IL_04cc;
													case 47:
														goto IL_04da;
													case 22:
													case 100:
														goto IL_04e8;
													case 112:
													case 123:
														goto IL_0504;
													case 49:
														goto IL_0520;
													case 120:
														goto IL_052e;
													case 12:
														goto IL_0541;
													case 85:
														goto IL_054f;
													case 83:
														goto IL_0566;
													case 87:
														goto IL_0574;
													case 38:
													case 71:
														goto IL_057f;
													case 76:
														goto IL_058d;
													case 96:
													case 111:
														goto IL_059b;
													case 9:
														goto IL_05cd;
													case 0:
														goto IL_05db;
													case 91:
														goto IL_05ee;
													case 10:
													case 45:
														goto IL_05fc;
													case 21:
														goto IL_0615;
													case 79:
														goto IL_0623;
													case 103:
														goto IL_0631;
													case 97:
													case 116:
														goto IL_0644;
													case 14:
														goto IL_0665;
													case 11:
														goto IL_0673;
													case 25:
													case 68:
														goto IL_067e;
													case 18:
														goto IL_068c;
													case 55:
													case 108:
														goto IL_069f;
													case 17:
														goto IL_06ad;
													case 63:
														goto IL_06d0;
													case 124:
														goto IL_06da;
													case 89:
														goto IL_06e8;
													case 115:
														goto IL_06fb;
													case 40:
														goto IL_0709;
													case 58:
													case 81:
														goto IL_0717;
													case 1:
														goto IL_0757;
													case 84:
														goto IL_076b;
													case 80:
													case 86:
														goto IL_077e;
													case 118:
														goto IL_07a1;
													case 72:
														goto IL_07af;
													case 101:
														goto IL_07bd;
													case 3:
													case 5:
													case 6:
													case 16:
													case 26:
													case 29:
													case 32:
													case 33:
													case 36:
													case 39:
													case 42:
													case 62:
													case 88:
													case 90:
													case 102:
													case 104:
													case 105:
													case 107:
													case 109:
													case 110:
													case 117:
													case 125:
														goto IL_07d0;
													case 61:
													case 93:
														goto IL_07f1;
													}
													continue;
													IL_07af:
													num4++;
													goto IL_07bd;
													IL_07bd:
													ptr2 += 8;
													goto IL_02cf;
													IL_02cf:
													if (num5 != 1)
													{
														goto IL_02df;
													}
													goto IL_07f1;
													IL_07f1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_02df:
													b = *ptr2;
													goto IL_02e8;
													IL_02e8:
													ptr2++;
													goto IL_02f6;
													IL_02f6:
													if (b >= 1)
													{
														goto IL_0304;
													}
													goto IL_07d0;
													IL_0304:
													if (b <= 13)
													{
														goto IL_0312;
													}
													goto IL_07d0;
													IL_0312:
													if (7 < b)
													{
														goto IL_0320;
													}
													goto IL_0541;
													IL_0320:
													if (10 >= b)
													{
														goto IL_032e;
													}
													goto IL_04b6;
													IL_032e:
													if (10 > b)
													{
														goto IL_033c;
													}
													goto IL_0450;
													IL_033c:
													if (8 >= b)
													{
														goto IL_034a;
													}
													goto IL_03cd;
													IL_034a:
													if (8 <= b)
													{
														goto IL_0358;
													}
													goto IL_07d0;
													IL_0358:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_03ba;
													IL_03ba:
													num4 -= 2;
													goto IL_02cf;
													IL_03cd:
													if (9 >= b)
													{
														goto IL_03db;
													}
													goto IL_07d0;
													IL_03db:
													if (9 <= b)
													{
														goto IL_03e9;
													}
													goto IL_07d0;
													IL_03e9:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0429;
													IL_0429:
													array[num4 - 2] = 0;
													goto IL_043d;
													IL_043d:
													num4--;
													goto IL_02cf;
													IL_0450:
													array[num4 - 1] = 0;
													goto IL_0464;
													IL_0464:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]) = ((delegate*<int, int>)ParagraphSeparatorgetLongTimePattern[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
													goto IL_04a3;
													IL_04a3:
													ptr2 += 8;
													goto IL_02cf;
													IL_04b6:
													if (12 >= b)
													{
														goto IL_04c1;
													}
													goto IL_0520;
													IL_04c1:
													if (12 > b)
													{
														goto IL_04cc;
													}
													goto IL_0504;
													IL_04cc:
													if (11 >= b)
													{
														goto IL_04da;
													}
													goto IL_07d0;
													IL_04da:
													if (11 <= b)
													{
														goto IL_04e8;
													}
													goto IL_07d0;
													IL_04e8:
													num4--;
													num = 73;
													goto IL_02cf;
													IL_0504:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_02cf;
													IL_0520:
													if (13 >= b)
													{
														goto IL_052e;
													}
													goto IL_07d0;
													IL_052e:
													if (13 <= b)
													{
													}
													goto IL_07d0;
													IL_0541:
													if (7 > b)
													{
														goto IL_054f;
													}
													goto IL_077e;
													IL_054f:
													if (3 >= b)
													{
														num = 83;
														goto IL_0566;
													}
													goto IL_0665;
													IL_07d0:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													num = 99;
													goto IL_02cf;
													IL_0566:
													if (3 > b)
													{
														goto IL_0574;
													}
													goto IL_0644;
													IL_0574:
													if (1 < b)
													{
														goto IL_057f;
													}
													goto IL_05ee;
													IL_057f:
													if (2 >= b)
													{
														goto IL_058d;
													}
													goto IL_07d0;
													IL_058d:
													if (2 <= b)
													{
														goto IL_059b;
													}
													goto IL_07d0;
													IL_059b:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													num = 9;
													goto IL_05cd;
													IL_05cd:
													ptr2 += 8;
													goto IL_05db;
													IL_05db:
													num4--;
													goto IL_02cf;
													IL_05ee:
													if (1 <= b)
													{
														goto IL_05fc;
													}
													goto IL_07d0;
													IL_05fc:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_0615;
													IL_0615:
													array[num4] = 0;
													goto IL_0623;
													IL_0623:
													num4++;
													goto IL_0631;
													IL_0631:
													ptr2 += 8;
													goto IL_02cf;
													IL_0644:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													num = 52;
													goto IL_02cf;
													IL_0665:
													if (5 >= b)
													{
														goto IL_0673;
													}
													goto IL_06fb;
													IL_0673:
													if (5 > b)
													{
														goto IL_067e;
													}
													goto IL_069f;
													IL_067e:
													if (4 >= b)
													{
														goto IL_068c;
													}
													goto IL_07d0;
													IL_068c:
													if (4 <= b)
													{
														goto IL_02cf;
													}
													goto IL_07d0;
													IL_069f:
													array[num4] = 0;
													goto IL_06ad;
													IL_06ad:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_06d0;
													IL_06d0:
													array2[num4] = null;
													goto IL_06da;
													IL_06da:
													num4++;
													goto IL_06e8;
													IL_06e8:
													ptr2 += 8;
													goto IL_02cf;
													IL_06fb:
													if (6 >= b)
													{
														goto IL_0709;
													}
													goto IL_07d0;
													IL_0709:
													if (6 <= b)
													{
														goto IL_0717;
													}
													goto IL_07d0;
													IL_0717:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0757;
													IL_0757:
													array[num4 - 2] = 0;
													goto IL_076b;
													IL_076b:
													num4--;
													goto IL_02cf;
													IL_077e:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_07a1;
													IL_07a1:
													array[num4] = 0;
													goto IL_07af;
													continue;
													end_IL_0223:
													break;
												}
												continue;
												end_IL_0236:
												break;
											}
											continue;
											end_IL_0249:
											break;
										}
										continue;
										end_IL_0254:
										break;
									}
									continue;
									end_IL_0269:
									break;
								}
								continue;
								end_IL_0279:
								break;
							}
							continue;
							end_IL_0289:
							break;
						}
						continue;
						end_IL_0294:
						break;
					}
					continue;
					end_IL_02a4:
					break;
				}
				continue;
				end_IL_02b4:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 56;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 80;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MAJORVERSIONRuntimeInformation.DynDataTraceGuidQueryList);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_026a:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_024a:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_023a:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_022d:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_021a:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_019e:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												num = 95;
																												while (true)
																												{
																													if (num != 95)
																													{
																														if (num != 1076)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 3:
																														case 40:
																															goto IL_019e;
																														case 34:
																															goto IL_021a;
																														case 76:
																														case 87:
																															goto IL_022d;
																														case 32:
																															goto IL_023a;
																														case 71:
																															goto IL_024a;
																														case 46:
																															goto end_IL_018b;
																														case 73:
																															goto IL_026a;
																														case 61:
																															goto end_IL_026a;
																														case 11:
																														case 88:
																															goto end_IL_027a;
																														case 35:
																														case 39:
																															goto IL_0295;
																														case 78:
																															goto IL_02a3;
																														case 33:
																														case 52:
																															goto IL_02b1;
																														case 48:
																															goto IL_02f1;
																														case 51:
																															goto IL_0305;
																														case 43:
																															goto IL_032b;
																														case 86:
																															goto IL_0339;
																														case 14:
																														case 67:
																															goto IL_034c;
																														case 16:
																															goto IL_0375;
																														case 27:
																															goto IL_0383;
																														case 41:
																															goto IL_0396;
																														case 19:
																															goto IL_03a1;
																														case 42:
																															goto IL_03af;
																														case 68:
																															goto IL_03bd;
																														case 5:
																														case 15:
																															goto IL_03cb;
																														case 45:
																															goto IL_03e3;
																														case 2:
																															goto IL_03ee;
																														case 49:
																															goto IL_03fc;
																														case 20:
																														case 74:
																															goto IL_040a;
																														case 12:
																															goto IL_042f;
																														case 4:
																														case 18:
																															goto IL_043a;
																														case 55:
																															goto IL_0448;
																														case 85:
																															goto IL_046b;
																														case 26:
																															goto IL_0475;
																														case 77:
																															goto IL_0483;
																														case 0:
																														case 8:
																														case 10:
																														case 22:
																														case 23:
																														case 25:
																														case 28:
																														case 29:
																														case 31:
																														case 36:
																														case 47:
																														case 53:
																														case 54:
																														case 58:
																														case 60:
																														case 66:
																														case 72:
																														case 79:
																															goto end_IL_025a;
																														case 6:
																															goto IL_04b6;
																														case 50:
																															goto IL_04c4;
																														case 83:
																															goto IL_04d2;
																														case 1:
																														case 13:
																														case 21:
																														case 24:
																														case 38:
																														case 63:
																														case 69:
																														case 70:
																														case 75:
																														case 81:
																														case 84:
																															goto end_IL_028a;
																														case 37:
																															goto end_IL_04e0;
																														case 64:
																															goto end_IL_04f3;
																														case 44:
																															goto end_IL_04fd;
																														case 30:
																															goto end_IL_0508;
																														case 80:
																															goto end_IL_051d;
																														case 62:
																														case 65:
																															goto end_IL_0532;
																														case 82:
																															goto end_IL_0542;
																														case 17:
																														case 59:
																															goto end_IL_055b;
																														case 56:
																															goto end_IL_056b;
																														case 57:
																															goto end_IL_057b;
																														case 7:
																														case 9:
																															goto IL_059f;
																														}
																														continue;
																													}
																													num5 -= 2;
																													goto end_IL_028a;
																													continue;
																													end_IL_018b:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_032b;
																										IL_0339:
																										if (1 <= b)
																										{
																										}
																										goto end_IL_025a;
																										IL_032b:
																										if (1 < b)
																										{
																											goto end_IL_025a;
																										}
																										goto IL_0339;
																									}
																									break;
																								}
																								goto IL_0295;
																								IL_0305:
																								num5--;
																								goto end_IL_028a;
																								IL_0295:
																								if (3 < b)
																								{
																									goto end_IL_025a;
																								}
																								goto IL_02a3;
																								IL_02a3:
																								if (3 > b)
																								{
																									goto end_IL_025a;
																								}
																								goto IL_02b1;
																								IL_02b1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02f1;
																								IL_02f1:
																								array[num5 - 2] = 0;
																								goto IL_0305;
																							}
																							break;
																						}
																						goto IL_034c;
																						IL_0383:
																						num5--;
																						goto end_IL_028a;
																						IL_034c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0375;
																						IL_0375:
																						ptr2 += 8;
																						goto IL_0383;
																					}
																					break;
																				}
																				goto IL_0396;
																				IL_0475:
																				num5++;
																				goto IL_0483;
																				IL_0396:
																				if (6 >= b)
																				{
																					goto IL_03a1;
																				}
																				goto IL_03e3;
																				IL_03a1:
																				if (6 <= b)
																				{
																					goto end_IL_028a;
																				}
																				goto IL_03af;
																				IL_03af:
																				if (5 < b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_03bd;
																				IL_03bd:
																				if (5 > b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_03cb;
																				IL_03cb:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_028a;
																				IL_03e3:
																				if (7 < b)
																				{
																					goto IL_03ee;
																				}
																				num = 12;
																				goto IL_042f;
																				IL_03ee:
																				if (8 < b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_03fc;
																				IL_03fc:
																				if (8 > b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_040a;
																				IL_040a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_028a;
																				IL_0483:
																				ptr2 += 8;
																				goto end_IL_028a;
																				IL_042f:
																				if (7 > b)
																				{
																					goto end_IL_025a;
																				}
																				goto IL_043a;
																				IL_043a:
																				array[num5] = 0;
																				goto IL_0448;
																				IL_0448:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_046b;
																				IL_046b:
																				array2[num5] = null;
																				goto IL_0475;
																			}
																			continue;
																			end_IL_025a:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b6;
																	IL_04d2:
																	ptr2 += 8;
																	goto end_IL_028a;
																	IL_04c4:
																	num5++;
																	goto IL_04d2;
																	IL_04b6:
																	array[num5] = 0;
																	goto IL_04c4;
																	continue;
																	end_IL_026a:
																	break;
																}
																continue;
																end_IL_027a:
																break;
															}
															continue;
															end_IL_028a:
															break;
														}
														continue;
													}
													goto IL_059f;
													IL_059f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e0:
													break;
												}
												continue;
												end_IL_04f3:
												break;
											}
											continue;
											end_IL_04fd:
											break;
										}
										continue;
										end_IL_0508:
										break;
									}
									continue;
									end_IL_051d:
									break;
								}
								continue;
								end_IL_0532:
								break;
							}
							continue;
							end_IL_0542:
							break;
						}
						continue;
						end_IL_055b:
						break;
					}
					continue;
					end_IL_056b:
					break;
				}
				continue;
				end_IL_057b:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 55;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WriteAsyncIgnoreWidth.writeAsyncIgnoreWidth_0);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 20;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0228:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0208:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_01fb:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_01e2:
																							array[num5] = 0;
																							num = 112;
																							while (true)
																							{
																								if (num != 112)
																								{
																									if (num != 1093)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 24:
																									case 84:
																										goto IL_01e2;
																									case 4:
																										goto IL_01fb;
																									case 104:
																										goto IL_0208;
																									case 27:
																										goto IL_0218;
																									case 42:
																										goto IL_0228;
																									case 47:
																										goto end_IL_0228;
																									case 10:
																									case 72:
																										goto end_IL_0238;
																									case 46:
																									case 63:
																										goto IL_0253;
																									case 70:
																										goto IL_0261;
																									case 11:
																									case 58:
																										goto IL_026c;
																									case 57:
																										goto IL_0295;
																									case 22:
																										goto IL_02a3;
																									case 52:
																										goto IL_02b6;
																									case 59:
																									case 81:
																										goto IL_02c9;
																									case 12:
																										goto IL_02d7;
																									case 7:
																									case 45:
																										goto IL_02e5;
																									case 38:
																										goto IL_0347;
																									case 39:
																										goto IL_035a;
																									case 25:
																										goto IL_0368;
																									case 5:
																									case 8:
																										goto IL_0376;
																									case 90:
																										goto IL_0392;
																									case 35:
																									case 43:
																										goto IL_039d;
																									case 87:
																										goto IL_03ab;
																									case 64:
																										goto IL_03be;
																									case 9:
																									case 83:
																										goto IL_03d5;
																									case 95:
																										goto IL_03ed;
																									case 32:
																									case 88:
																										goto IL_0404;
																									case 48:
																										goto IL_041d;
																									case 66:
																										goto IL_042b;
																									case 69:
																										goto IL_0439;
																									case 2:
																									case 97:
																										goto IL_044c;
																									case 15:
																										goto IL_045a;
																									case 98:
																										goto IL_046d;
																									case 89:
																										goto IL_0478;
																									case 28:
																									case 33:
																										goto IL_0486;
																									case 23:
																										goto IL_04c6;
																									case 30:
																										goto IL_04da;
																									case 75:
																										goto IL_04ed;
																									case 31:
																										goto IL_04fb;
																									case 37:
																									case 79:
																										goto IL_0509;
																									case 14:
																										goto IL_052c;
																									case 91:
																										goto IL_053a;
																									case 62:
																										goto IL_0548;
																									case 51:
																										goto IL_057b;
																									case 74:
																										goto IL_0585;
																									case 56:
																										goto IL_0593;
																									case 6:
																									case 16:
																									case 17:
																									case 18:
																									case 19:
																									case 29:
																									case 34:
																									case 40:
																									case 50:
																									case 65:
																									case 67:
																									case 68:
																									case 73:
																									case 76:
																									case 78:
																									case 80:
																									case 85:
																									case 92:
																									case 96:
																									case 99:
																									case 101:
																										goto end_IL_01cf;
																									case 0:
																									case 3:
																									case 13:
																									case 20:
																									case 26:
																									case 36:
																									case 41:
																									case 49:
																									case 60:
																									case 61:
																									case 71:
																									case 93:
																									case 100:
																										goto end_IL_0248;
																									case 21:
																										goto end_IL_05b6;
																									case 86:
																										goto end_IL_05c9;
																									case 53:
																										goto end_IL_05dc;
																									case 44:
																										goto end_IL_05e7;
																									case 102:
																									case 103:
																										goto end_IL_05fc;
																									case 77:
																										goto end_IL_060c;
																									case 82:
																									case 94:
																										goto end_IL_061c;
																									case 54:
																										goto end_IL_062c;
																									case 55:
																										goto end_IL_063c;
																									case 1:
																									case 105:
																										goto IL_0657;
																									}
																									continue;
																								}
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_057b;
																								IL_057b:
																								array2[num5] = null;
																								goto IL_0585;
																								IL_0593:
																								ptr2 += 8;
																								goto end_IL_0248;
																								IL_0585:
																								num5++;
																								goto IL_0593;
																								continue;
																								end_IL_01cf:
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0253;
																					IL_03be:
																					if (3 > b)
																					{
																						break;
																					}
																					num = 83;
																					goto IL_03d5;
																					IL_0253:
																					if (2 >= b)
																					{
																						goto IL_0261;
																					}
																					goto IL_0392;
																					IL_0261:
																					if (2 <= b)
																					{
																						goto IL_026c;
																					}
																					goto IL_02b6;
																					IL_026c:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0295;
																					IL_0295:
																					ptr2 += 8;
																					goto IL_02a3;
																					IL_02a3:
																					num5--;
																					goto end_IL_0248;
																					IL_02b6:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_03ed;
																					IL_03ed:
																					if (1 > b)
																					{
																						break;
																					}
																					num = 88;
																					goto IL_0404;
																					IL_03d5:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0248;
																					IL_0404:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_041d;
																					IL_041d:
																					array[num5] = 0;
																					goto IL_042b;
																					IL_042b:
																					num5++;
																					goto IL_0439;
																					IL_0439:
																					ptr2 += 8;
																					goto end_IL_0248;
																					IL_0392:
																					if (3 < b)
																					{
																						goto IL_039d;
																					}
																					goto IL_03be;
																					IL_039d:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_03ab;
																					IL_03ab:
																					if (4 <= b)
																					{
																						goto end_IL_0248;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_02c9;
																			IL_045a:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_02c9:
																			if (8 >= b)
																			{
																				goto IL_02d7;
																			}
																			goto IL_035a;
																			IL_02d7:
																			if (8 <= b)
																			{
																				goto IL_02e5;
																			}
																			goto IL_046d;
																			IL_02e5:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0347;
																			IL_0347:
																			num5 -= 2;
																			goto end_IL_0248;
																			IL_046d:
																			if (6 >= b)
																			{
																				goto IL_0478;
																			}
																			goto IL_04ed;
																			IL_0478:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0486;
																			IL_0486:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04c6;
																			IL_04c6:
																			array[num5 - 2] = 0;
																			goto IL_04da;
																			IL_04da:
																			num5--;
																			goto end_IL_0248;
																			IL_04ed:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04fb;
																			IL_04fb:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0509;
																			IL_0509:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_052c;
																			IL_052c:
																			array[num5] = 0;
																			goto IL_053a;
																			IL_053a:
																			num5++;
																			goto IL_0548;
																			IL_0548:
																			ptr2 += 8;
																			goto end_IL_0248;
																			IL_035a:
																			if (9 >= b)
																			{
																				goto IL_0368;
																			}
																			goto IL_044c;
																			IL_0368:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0376;
																			IL_0376:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0248;
																			IL_044c:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_045a;
																		}
																		break;
																		IL_0218:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0248;
																continue;
																end_IL_0228:
																break;
															}
															continue;
															end_IL_0238:
															break;
														}
														continue;
														end_IL_0248:
														break;
													}
													continue;
												}
												goto IL_0657;
												IL_0657:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b6:
												break;
											}
											continue;
											end_IL_05c9:
											break;
										}
										continue;
										end_IL_05dc:
										break;
									}
									continue;
									end_IL_05e7:
									break;
								}
								continue;
								end_IL_05fc:
								break;
							}
							continue;
							end_IL_060c:
							break;
						}
						continue;
						end_IL_061c:
						break;
					}
					continue;
					end_IL_062c:
					break;
				}
				continue;
				end_IL_063c:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PoprefpopipoprProcessMessage.grfStateBitsLdlen);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_030a:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ed:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02e0:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02d3:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02c3:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02b3:
																											if (6 > b)
																											{
																												while (5 >= b)
																												{
																													while (5 <= b)
																													{
																														num = 152;
																														while (true)
																														{
																															if (num != 152)
																															{
																																if (num != 1133)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 68:
																																	goto IL_0290;
																																case 28:
																																case 128:
																																	goto IL_02a3;
																																case 131:
																																	goto IL_02b3;
																																case 50:
																																	goto IL_02c3;
																																case 129:
																																	goto IL_02d3;
																																case 80:
																																	goto IL_02e0;
																																case 39:
																																	goto IL_02ed;
																																case 107:
																																	goto IL_02fa;
																																case 11:
																																	goto IL_030a;
																																case 84:
																																	goto end_IL_030a;
																																case 73:
																																case 119:
																																	goto end_IL_031a;
																																case 24:
																																case 52:
																																	goto IL_0335;
																																case 26:
																																case 75:
																																	goto IL_034d;
																																case 90:
																																	goto IL_035d;
																																case 59:
																																case 102:
																																	goto IL_036b;
																																case 104:
																																	goto IL_037b;
																																case 106:
																																	goto IL_038b;
																																case 77:
																																case 81:
																																	goto IL_0399;
																																case 49:
																																	goto end_IL_027d;
																																case 110:
																																case 112:
																																	goto IL_03f2;
																																case 74:
																																	goto IL_0432;
																																case 40:
																																	goto IL_0446;
																																case 15:
																																case 113:
																																	goto IL_0459;
																																case 53:
																																	goto IL_0464;
																																case 45:
																																case 108:
																																	goto IL_046f;
																																case 63:
																																	goto IL_047d;
																																case 12:
																																	goto IL_0490;
																																case 34:
																																case 115:
																																	goto IL_04a3;
																																case 5:
																																	goto IL_04b1;
																																case 25:
																																	goto IL_04d4;
																																case 0:
																																	goto IL_04de;
																																case 41:
																																	goto IL_04ec;
																																case 130:
																																	goto IL_04ff;
																																case 17:
																																	goto IL_050d;
																																case 132:
																																	goto IL_0520;
																																case 21:
																																case 88:
																																	goto IL_052e;
																																case 32:
																																	goto IL_0572;
																																case 55:
																																	goto IL_0586;
																																case 135:
																																	goto IL_05a2;
																																case 124:
																																	goto IL_05b0;
																																case 54:
																																case 92:
																																	goto IL_05bb;
																																case 89:
																																	goto IL_05d7;
																																case 57:
																																	goto IL_05e5;
																																case 1:
																																case 99:
																																	goto IL_05f3;
																																case 86:
																																	goto IL_0655;
																																case 95:
																																	goto IL_0668;
																																case 23:
																																	goto IL_0676;
																																case 44:
																																case 139:
																																	goto IL_0689;
																																case 133:
																																	goto IL_06a7;
																																case 79:
																																	goto IL_06b5;
																																case 58:
																																case 141:
																																	goto IL_06c8;
																																case 27:
																																	goto IL_06d6;
																																case 83:
																																case 118:
																																	goto IL_06e4;
																																case 126:
																																	goto IL_06fd;
																																case 56:
																																	goto IL_070b;
																																case 64:
																																	goto IL_0719;
																																case 18:
																																case 142:
																																	goto IL_072c;
																																case 69:
																																	goto IL_075e;
																																case 101:
																																case 144:
																																	goto IL_0777;
																																case 9:
																																	goto IL_0785;
																																case 22:
																																case 121:
																																	goto IL_0793;
																																case 87:
																																	goto IL_07bc;
																																case 125:
																																	goto IL_07ca;
																																case 145:
																																	goto IL_07dd;
																																case 72:
																																	goto IL_07f0;
																																case 61:
																																	goto IL_07fe;
																																case 51:
																																	goto IL_0816;
																																case 31:
																																	goto IL_0824;
																																case 37:
																																case 120:
																																	goto IL_0834;
																																case 67:
																																	goto IL_0873;
																																case 3:
																																case 6:
																																case 10:
																																case 13:
																																case 20:
																																case 35:
																																case 36:
																																case 42:
																																case 43:
																																case 62:
																																case 65:
																																case 71:
																																case 85:
																																case 91:
																																case 96:
																																case 98:
																																case 100:
																																case 103:
																																case 111:
																																case 117:
																																case 122:
																																case 127:
																																case 136:
																																case 137:
																																case 143:
																																	goto end_IL_0290;
																																case 2:
																																case 7:
																																case 8:
																																case 29:
																																case 30:
																																case 33:
																																case 38:
																																case 48:
																																case 78:
																																case 82:
																																case 93:
																																case 94:
																																case 105:
																																case 114:
																																case 116:
																																case 123:
																																case 134:
																																case 138:
																																	goto end_IL_032a;
																																case 19:
																																	goto end_IL_0896;
																																case 14:
																																	goto end_IL_08a9;
																																case 16:
																																	goto end_IL_08b3;
																																case 60:
																																	goto end_IL_08be;
																																case 109:
																																case 140:
																																	goto end_IL_08ce;
																																case 66:
																																	goto end_IL_08de;
																																case 4:
																																case 70:
																																	goto end_IL_08ee;
																																case 46:
																																	goto end_IL_08fe;
																																case 47:
																																	goto end_IL_090e;
																																case 76:
																																case 97:
																																	goto IL_0932;
																																}
																																continue;
																															}
																															goto IL_07f0;
																															IL_0816:
																															num5++;
																															goto IL_0824;
																															IL_0824:
																															ptr2 += 8;
																															goto end_IL_032a;
																															IL_07f0:
																															array[num5] = 5;
																															goto IL_07fe;
																															IL_07fe:
																															array2[num5] = array5[*(int*)(ptr2 + num3)];
																															goto IL_0816;
																															continue;
																															end_IL_027d:
																															break;
																														}
																														goto IL_03d9;
																														continue;
																														end_IL_0290:
																														break;
																														IL_0290:;
																													}
																													break;
																													IL_02a3:;
																												}
																												break;
																											}
																											goto IL_0834;
																											IL_0873:
																											num5 -= 3;
																											goto end_IL_032a;
																											IL_0834:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0873;
																										}
																										break;
																									}
																									goto IL_0777;
																									IL_07ca:
																									num5--;
																									goto end_IL_032a;
																									IL_0777:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0785;
																									IL_0785:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0793;
																									IL_0793:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_07bc;
																									IL_07bc:
																									ptr2 += 8;
																									goto IL_07ca;
																								}
																								break;
																							}
																							goto IL_035d;
																							IL_06b5:
																							num5--;
																							goto end_IL_032a;
																							IL_035d:
																							if (4 > b)
																							{
																								goto IL_036b;
																							}
																							goto IL_0689;
																							IL_036b:
																							if (2 >= b)
																							{
																								goto IL_038b;
																							}
																							goto IL_04ff;
																							IL_038b:
																							if (2 <= b)
																							{
																								goto IL_0399;
																							}
																							goto IL_06c8;
																							IL_0399:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03d9;
																							IL_03d9:
																							array[num5 - 2] = 0;
																							goto IL_07dd;
																							IL_07dd:
																							num5--;
																							goto end_IL_032a;
																							IL_06c8:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_06d6;
																							IL_06d6:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_06e4;
																							IL_06e4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_06fd;
																							IL_06fd:
																							array[num5] = 0;
																							goto IL_070b;
																							IL_070b:
																							num5++;
																							goto IL_0719;
																							IL_0719:
																							ptr2 += 8;
																							goto end_IL_032a;
																							IL_04ff:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_050d;
																							IL_050d:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_072c;
																							IL_072c:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							num = 69;
																							goto IL_075e;
																							IL_075e:
																							array[num5 - 1] = 5;
																							goto end_IL_032a;
																							IL_0689:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_06a7;
																							IL_06a7:
																							ptr2 += 8;
																							goto IL_06b5;
																						}
																						break;
																					}
																					goto IL_0335;
																					IL_0335:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_032a;
																				}
																				break;
																			}
																			goto IL_034d;
																			IL_0676:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_034d:
																			if (12 >= b)
																			{
																				goto IL_037b;
																			}
																			goto IL_05a2;
																			IL_037b:
																			if (12 <= b)
																			{
																				goto IL_03f2;
																			}
																			goto IL_0459;
																			IL_0459:
																			if (10 >= b)
																			{
																				goto IL_0464;
																			}
																			goto IL_0490;
																			IL_0464:
																			if (10 > b)
																			{
																				goto IL_046f;
																			}
																			goto IL_04a3;
																			IL_046f:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_047d;
																			IL_047d:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_032a;
																			IL_04a3:
																			array[num5] = 0;
																			goto IL_04b1;
																			IL_04b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04d4;
																			IL_04d4:
																			array2[num5] = null;
																			goto IL_04de;
																			IL_04de:
																			num5++;
																			goto IL_04ec;
																			IL_04ec:
																			ptr2 += 8;
																			goto end_IL_032a;
																			IL_0490:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0520;
																			IL_0520:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_052e;
																			IL_052e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0572;
																			IL_0572:
																			array[num5 - 2] = 0;
																			goto IL_0586;
																			IL_0586:
																			num5--;
																			num = 82;
																			goto end_IL_032a;
																			IL_03f2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0432;
																			IL_0432:
																			array[num5 - 2] = 0;
																			goto IL_0446;
																			IL_0446:
																			num5--;
																			goto end_IL_032a;
																			IL_05a2:
																			if (14 >= b)
																			{
																				goto IL_05b0;
																			}
																			goto IL_0668;
																			IL_05b0:
																			if (14 <= b)
																			{
																				goto IL_05bb;
																			}
																			goto IL_05d7;
																			IL_05bb:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_032a;
																			IL_05d7:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_05e5;
																			IL_05e5:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_05f3;
																			IL_05f3:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0655;
																			IL_0655:
																			num5 -= 2;
																			goto end_IL_032a;
																			IL_0668:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0676;
																		}
																		break;
																		IL_02fa:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_032a;
																continue;
																end_IL_030a:
																break;
															}
															continue;
															end_IL_031a:
															break;
														}
														continue;
														end_IL_032a:
														break;
													}
													continue;
												}
												goto IL_0932;
												IL_0932:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0896:
												break;
											}
											continue;
											end_IL_08a9:
											break;
										}
										continue;
										end_IL_08b3:
										break;
									}
									continue;
									end_IL_08be:
									break;
								}
								continue;
								end_IL_08ce:
								break;
							}
							continue;
							end_IL_08de:
							break;
						}
						continue;
						end_IL_08ee:
						break;
					}
					continue;
					end_IL_08fe:
					break;
				}
				continue;
				end_IL_090e:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 143;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 147;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LogonIdsSidOtherPunctuation.WeekCommonNumberSeparator);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 119;
												while (true)
												{
													num = 11;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 144;
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_02a4:
																			if (b >= 1)
																			{
																				goto IL_02da;
																			}
																			num = 157;
																			while (num != 157)
																			{
																				if (num != 1138)
																				{
																					goto IL_0763;
																				}
																				switch (num)
																				{
																				case 26:
																					goto IL_02a4;
																				case 91:
																					goto end_IL_02a4;
																				case 144:
																					goto end_IL_02b4;
																				case 93:
																					goto end_IL_02c4;
																				case 45:
																					goto IL_02da;
																				case 138:
																					goto IL_02e8;
																				case 20:
																				case 150:
																					goto IL_02f6;
																				case 109:
																				case 136:
																					goto IL_0304;
																				case 9:
																				case 73:
																					goto IL_030f;
																				case 63:
																					goto IL_031d;
																				case 50:
																					goto IL_0330;
																				case 35:
																				case 95:
																					goto IL_033e;
																				case 47:
																					goto IL_034c;
																				case 31:
																				case 133:
																					goto IL_035a;
																				case 51:
																					goto IL_03bc;
																				case 12:
																				case 108:
																					goto IL_03cf;
																				case 105:
																					goto IL_03eb;
																				case 34:
																				case 114:
																					goto IL_03f6;
																				case 0:
																					goto IL_0436;
																				case 64:
																					goto IL_044a;
																				case 120:
																					goto IL_045d;
																				case 115:
																				case 121:
																					goto IL_046b;
																				case 123:
																					goto IL_0479;
																				case 68:
																				case 74:
																					goto IL_0487;
																				case 10:
																					goto IL_04cb;
																				case 99:
																					goto IL_04df;
																				case 112:
																					goto IL_04f2;
																				case 78:
																				case 98:
																					goto IL_04fd;
																				case 77:
																					goto IL_050b;
																				case 129:
																					goto IL_052e;
																				case 111:
																					goto IL_0538;
																				case 148:
																					goto IL_0546;
																				case 40:
																					goto IL_0562;
																				case 67:
																					goto IL_0570;
																				case 134:
																					goto IL_0583;
																				case 18:
																				case 58:
																					goto IL_058e;
																				case 1:
																					goto IL_05a6;
																				case 54:
																				case 90:
																					goto IL_05b4;
																				case 66:
																				case 84:
																					goto IL_05bf;
																				case 128:
																					goto IL_05cd;
																				case 23:
																				case 117:
																					goto IL_05db;
																				case 38:
																					goto IL_0604;
																				case 132:
																					goto IL_061b;
																				case 70:
																					goto IL_062e;
																				case 29:
																				case 94:
																					goto IL_0639;
																				case 139:
																					goto IL_0678;
																				case 83:
																					goto IL_068b;
																				case 82:
																					goto IL_0699;
																				case 13:
																				case 65:
																					goto IL_06a7;
																				case 5:
																					goto IL_06b5;
																				case 76:
																					goto IL_06cd;
																				case 22:
																					goto IL_06e4;
																				case 110:
																					goto IL_0700;
																				case 27:
																				case 43:
																					goto IL_070b;
																				case 140:
																					goto IL_0729;
																				case 118:
																					goto IL_0737;
																				case 145:
																					goto IL_074a;
																				case 28:
																					goto IL_0758;
																				case 25:
																					goto IL_0763;
																				case 8:
																					goto IL_0771;
																				case 4:
																				case 87:
																					goto IL_077f;
																				case 17:
																					goto IL_0798;
																				case 53:
																					goto IL_07a6;
																				case 61:
																					goto IL_07b4;
																				case 16:
																				case 59:
																					goto IL_07c7;
																				case 32:
																					goto IL_0807;
																				case 79:
																					goto IL_081b;
																				case 21:
																					goto IL_0834;
																				case 41:
																					goto IL_083f;
																				case 100:
																				case 103:
																					goto IL_084a;
																				case 52:
																					goto IL_087c;
																				case 3:
																				case 6:
																				case 14:
																				case 19:
																				case 24:
																				case 30:
																				case 33:
																				case 37:
																				case 39:
																				case 49:
																				case 55:
																				case 56:
																				case 57:
																				case 62:
																				case 72:
																				case 80:
																				case 86:
																				case 88:
																				case 89:
																				case 96:
																				case 102:
																				case 107:
																				case 113:
																				case 122:
																				case 125:
																				case 126:
																				case 127:
																				case 135:
																				case 141:
																					goto end_IL_0291;
																				case 2:
																				case 7:
																				case 11:
																				case 15:
																				case 36:
																				case 42:
																				case 44:
																				case 46:
																				case 69:
																				case 71:
																				case 85:
																				case 106:
																				case 116:
																				case 130:
																				case 131:
																				case 137:
																				case 146:
																					goto end_IL_02cf;
																				case 119:
																					goto end_IL_08a5;
																				case 60:
																					goto end_IL_08b8;
																				case 92:
																					goto end_IL_08c3;
																				case 124:
																					goto end_IL_08d6;
																				case 48:
																					goto end_IL_08e1;
																				case 97:
																				case 149:
																					goto end_IL_08f1;
																				case 81:
																					goto end_IL_0901;
																				case 147:
																					goto end_IL_0911;
																				case 75:
																					goto end_IL_0921;
																				case 142:
																					goto end_IL_0931;
																				case 143:
																					goto end_IL_093c;
																				case 101:
																				case 104:
																					goto IL_0957;
																				}
																				continue;
																				end_IL_0291:
																				break;
																			}
																			goto IL_0892;
																			IL_087c:
																			array[num5 - 1] = 5;
																			goto end_IL_02cf;
																			IL_0892:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02cf;
																			IL_02da:
																			if (b <= 15)
																			{
																				goto IL_02e8;
																			}
																			goto IL_0892;
																			IL_02e8:
																			if (8 < b)
																			{
																				goto IL_02f6;
																			}
																			goto IL_0583;
																			IL_02f6:
																			if (12 < b)
																			{
																				goto IL_0304;
																			}
																			goto IL_03eb;
																			IL_0304:
																			if (14 < b)
																			{
																				goto IL_030f;
																			}
																			goto IL_0330;
																			IL_030f:
																			if (15 >= b)
																			{
																				goto IL_031d;
																			}
																			goto IL_0892;
																			IL_031d:
																			if (15 <= b)
																			{
																			}
																			goto IL_0892;
																			IL_0330:
																			if (14 > b)
																			{
																				goto IL_033e;
																			}
																			goto IL_03cf;
																			IL_033e:
																			if (13 >= b)
																			{
																				goto IL_034c;
																			}
																			goto IL_0892;
																			IL_034c:
																			if (13 <= b)
																			{
																				goto IL_035a;
																			}
																			goto IL_0892;
																			IL_035a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03bc;
																			IL_03bc:
																			num5 -= 2;
																			goto end_IL_02cf;
																			IL_03cf:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02cf;
																			IL_03eb:
																			if (12 <= b)
																			{
																				goto IL_03f6;
																			}
																			goto IL_045d;
																			IL_03f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0436;
																			IL_0436:
																			array[num5 - 2] = 0;
																			goto IL_044a;
																			IL_044a:
																			num5--;
																			goto end_IL_02cf;
																			IL_045d:
																			if (10 < b)
																			{
																				goto IL_046b;
																			}
																			goto IL_04f2;
																			IL_046b:
																			if (11 >= b)
																			{
																				goto IL_0479;
																			}
																			goto IL_0892;
																			IL_0479:
																			if (11 <= b)
																			{
																				goto IL_0487;
																			}
																			goto IL_0892;
																			IL_0487:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04cb;
																			IL_04cb:
																			array[num5 - 2] = 0;
																			goto IL_04df;
																			IL_04df:
																			num5--;
																			goto end_IL_02cf;
																			IL_04f2:
																			if (10 <= b)
																			{
																				goto IL_04fd;
																			}
																			goto IL_0562;
																			IL_04fd:
																			array[num5] = 0;
																			goto IL_050b;
																			IL_050b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_052e;
																			IL_052e:
																			array2[num5] = null;
																			goto IL_0538;
																			IL_0538:
																			num5++;
																			goto IL_0546;
																			IL_0546:
																			ptr2 += 8;
																			num = 42;
																			goto end_IL_02cf;
																			IL_0562:
																			if (9 >= b)
																			{
																				goto IL_0570;
																			}
																			goto IL_0892;
																			IL_0570:
																			if (9 <= b)
																			{
																				goto end_IL_02cf;
																			}
																			goto IL_0892;
																			IL_0583:
																			if (8 <= b)
																			{
																				goto IL_058e;
																			}
																			goto IL_05a6;
																			IL_058e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02cf;
																			IL_05a6:
																			if (4 < b)
																			{
																				goto IL_05b4;
																			}
																			goto IL_0700;
																			IL_05b4:
																			if (6 < b)
																			{
																				goto IL_05bf;
																			}
																			goto IL_062e;
																			IL_05bf:
																			if (7 >= b)
																			{
																				goto IL_05cd;
																			}
																			goto IL_0892;
																			IL_05cd:
																			if (7 <= b)
																			{
																				goto IL_05db;
																			}
																			goto IL_0892;
																			IL_05db:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0604;
																			IL_0604:
																			ptr2 += 8;
																			num = 132;
																			goto IL_061b;
																			IL_061b:
																			num5--;
																			goto end_IL_02cf;
																			IL_062e:
																			if (6 <= b)
																			{
																				goto IL_0639;
																			}
																			goto IL_068b;
																			IL_0639:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0678;
																			IL_0678:
																			num5 -= 3;
																			goto end_IL_02cf;
																			IL_068b:
																			if (5 >= b)
																			{
																				goto IL_0699;
																			}
																			goto IL_0892;
																			IL_0699:
																			if (5 <= b)
																			{
																				goto IL_06a7;
																			}
																			goto IL_0892;
																			IL_06a7:
																			array[num5] = 5;
																			goto IL_06b5;
																			IL_06b5:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_06cd;
																			IL_06cd:
																			num5++;
																			num = 22;
																			goto IL_06e4;
																			IL_06e4:
																			ptr2 += 8;
																			num = 46;
																			goto end_IL_02cf;
																			IL_0700:
																			if (4 <= b)
																			{
																				goto IL_070b;
																			}
																			goto IL_074a;
																			IL_070b:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0729;
																			IL_0729:
																			ptr2 += 8;
																			goto IL_0737;
																			IL_0737:
																			num5--;
																			goto end_IL_02cf;
																			IL_074a:
																			if (2 >= b)
																			{
																				goto IL_0758;
																			}
																			goto IL_0834;
																			IL_0758:
																			if (2 > b)
																			{
																				goto IL_0763;
																			}
																			goto IL_07c7;
																			IL_0763:
																			if (1 >= b)
																			{
																				goto IL_0771;
																			}
																			goto IL_0892;
																			IL_0771:
																			if (1 <= b)
																			{
																				goto IL_077f;
																			}
																			goto IL_0892;
																			IL_077f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0798;
																			IL_0798:
																			array[num5] = 0;
																			goto IL_07a6;
																			IL_07a6:
																			num5++;
																			goto IL_07b4;
																			IL_07b4:
																			ptr2 += 8;
																			goto end_IL_02cf;
																			IL_07c7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0807;
																			IL_0807:
																			array[num5 - 2] = 0;
																			goto IL_081b;
																			IL_081b:
																			num5--;
																			num = 130;
																			goto end_IL_02cf;
																			IL_0834:
																			if (3 >= b)
																			{
																				goto IL_083f;
																			}
																			goto IL_0892;
																			IL_083f:
																			if (3 <= b)
																			{
																				goto IL_084a;
																			}
																			goto IL_0892;
																			IL_084a:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 52;
																			goto IL_087c;
																			continue;
																			end_IL_02a4:
																			break;
																		}
																		continue;
																		end_IL_02b4:
																		break;
																	}
																	continue;
																	end_IL_02c4:
																	break;
																}
																continue;
																end_IL_02cf:
																break;
															}
															continue;
														}
														goto IL_0957;
														IL_0957:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_08a5:
														break;
													}
													continue;
													end_IL_08b8:
													break;
												}
												continue;
												end_IL_08c3:
												break;
											}
											continue;
											end_IL_08d6:
											break;
										}
										continue;
										end_IL_08e1:
										break;
									}
									continue;
									end_IL_08f1:
									break;
								}
								continue;
								end_IL_0901:
								break;
							}
							continue;
							end_IL_0911:
							break;
						}
						continue;
						end_IL_0921:
						break;
					}
					continue;
					end_IL_0931:
					break;
				}
				continue;
				end_IL_093c:
				break;
			}
		}
	}

	static Class121()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 4:
							case 5:
								goto end_IL_003d;
							case 2:
								goto end_IL_004a;
							case 3:
								goto end_IL_005c;
							case 1:
								return;
							case 6:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_005c:
				break;
			}
		}
	}
}
