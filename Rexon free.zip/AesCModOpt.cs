using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 85)]
internal struct AesCModOpt
{
	internal static AesCModOpt SecurityEnabledsetHostCanGenerate/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 01 01 00 00 00 03 00 00 00 01 01 00 00 00 04 00 00 00 00 00 00 00 00 05 06 00 00 00 01 01 00 00 00 03 00 00 00 01 01 00 00 00 07 08 00 00 00 02 02 00 00 00 09 00 00 00 03 03 00 00 00 0A 00 00 00 00 00 00 00 00 0B 0C) */;
}
