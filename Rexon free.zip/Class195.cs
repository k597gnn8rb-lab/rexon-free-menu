using System;
using System.Runtime.CompilerServices;
using GorillaLocomotion;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.XR;

[Mod("Punch Boost", "Rig", "Swing your hands fast to boost forward.", false, 23, ModType.const_0, false)]
internal class Class195 : MonoBehaviour
{
	private Vector3 vector3_0;

	private Vector3 vector3_1;

	private float float_0;

	private Rigidbody rigidbody_0;

	private static float float_1;

	private static int int_0;

	private static int int_1;

	private static float float_2;

	private static float float_3;

	private static int int_2;

	private static double double_0;

	private static IntPtr[] getWindowClassSectionIsVerified;

	private static IntPtr[] BuildVersionCultureAwareRandomizedComparer;

	private static IntPtr[] ParallelJoincPropertiesToSet;

	private static IntPtr[] ResolveTypeSingleProducerSingleConsumerQueue;

	private static IntPtr[] ContentTypeSetURI;

	private void Start()
	{
		object obj = this;
		GTPlayer instance = GTPlayer.Instance;
		object obj2 = instance;
		Rigidbody component = ((GTPlayer)obj2).GetComponent<Rigidbody>();
		obj2 = component;
		((Class195)obj).rigidbody_0 = (Rigidbody)obj2;
		obj = this;
		GorillaTagger instance2 = GorillaTagger.Instance;
		obj2 = instance2;
		obj2 = ((GorillaTagger)obj2).leftHandTransform;
		Vector3 position = ((Transform)obj2).position;
		obj2 = position;
		((Class195)obj).vector3_0 = (Vector3)obj2;
		obj = this;
		GorillaTagger instance3 = GorillaTagger.Instance;
		obj2 = instance3;
		obj2 = ((GorillaTagger)obj2).rightHandTransform;
		Vector3 position2 = ((Transform)obj2).position;
		obj2 = position2;
		((Class195)obj).vector3_1 = (Vector3)obj2;
	}

	private unsafe void Update()
	{
		int num = 501;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[4];
										while (true)
										{
											object[] array6 = new object[1];
											while (true)
											{
												array6[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LocalizedModeJIS.getSchedulerPairgetIsAllocated);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																num = 198;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_09d3:
																		if (b >= 1)
																		{
																			while (b <= 68)
																			{
																				while (true)
																				{
																					if (34 >= b)
																					{
																						while (true)
																						{
																							if (34 > b)
																							{
																								while (true)
																								{
																									IL_0996:
																									if (17 < b)
																									{
																										goto IL_221a;
																									}
																									while (true)
																									{
																										IL_0986:
																										if (17 > b)
																										{
																											while (true)
																											{
																												IL_0976:
																												if (8 < b)
																												{
																													while (true)
																													{
																														IL_0966:
																														if (12 >= b)
																														{
																															while (true)
																															{
																																IL_0956:
																																if (12 <= b)
																																{
																																	while (true)
																																	{
																																		IL_093b:
																																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																																		while (true)
																																		{
																																			IL_092b:
																																			array[num6] = 1;
																																			while (true)
																																			{
																																				IL_0912:
																																				num6++;
																																				num = 572;
																																				while (true)
																																				{
																																					if (num != 572)
																																					{
																																						if (num != 1553)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 16:
																																							goto IL_0912;
																																						case 289:
																																							goto IL_092b;
																																						case 308:
																																						case 366:
																																							goto IL_093b;
																																						case 413:
																																							goto IL_0956;
																																						case 479:
																																							goto IL_0966;
																																						case 351:
																																							goto IL_0976;
																																						case 60:
																																							goto IL_0986;
																																						case 283:
																																							goto IL_0996;
																																						case 502:
																																							goto end_IL_0996;
																																						case 101:
																																							goto end_IL_09a6;
																																						case 126:
																																							goto end_IL_09b3;
																																						case 186:
																																							goto IL_09d3;
																																						case 198:
																																							goto end_IL_09d3;
																																						case 50:
																																						case 162:
																																							goto end_IL_09e3;
																																						case 15:
																																						case 42:
																																							goto IL_0a07;
																																						case 83:
																																							goto IL_0a74;
																																						case 120:
																																							goto IL_0a84;
																																						case 38:
																																							goto IL_0a8f;
																																						case 35:
																																							goto IL_0a9d;
																																						case 237:
																																							goto IL_0ab9;
																																						case 139:
																																							goto IL_0ac7;
																																						case 245:
																																							goto IL_0ae3;
																																						case 95:
																																							goto IL_0af1;
																																						case 88:
																																							goto IL_0afc;
																																						case 74:
																																							goto IL_0b0a;
																																						case 156:
																																							goto IL_0b18;
																																						case 62:
																																						case 79:
																																							goto IL_0b28;
																																						case 18:
																																							goto IL_0b3c;
																																						case 214:
																																							goto IL_0b7b;
																																						case 249:
																																							goto IL_0b8e;
																																						case 163:
																																							goto IL_0b9c;
																																						case 264:
																																							goto IL_0baf;
																																						case 11:
																																						case 196:
																																							goto IL_0bbd;
																																						case 157:
																																							goto IL_0bd1;
																																						case 177:
																																							goto IL_0c10;
																																						case 304:
																																							goto IL_0c23;
																																						case 165:
																																							goto IL_0c31;
																																						case 314:
																																							goto IL_0c44;
																																						case 129:
																																						case 261:
																																							goto IL_0c4f;
																																						case 250:
																																							goto IL_0c68;
																																						case 200:
																																						case 323:
																																							goto IL_0c7b;
																																						case 84:
																																							goto IL_0c89;
																																						case 243:
																																							goto IL_0ca7;
																																						case 339:
																																							goto IL_0cba;
																																						case 224:
																																							goto IL_0cc8;
																																						case 46:
																																							goto IL_0cd6;
																																						case 284:
																																							goto IL_0ce4;
																																						case 58:
																																						case 311:
																																							goto IL_0cf2;
																																						case 86:
																																							goto IL_0d06;
																																						case 102:
																																							goto IL_0d57;
																																						case 226:
																																							goto IL_0d65;
																																						case 350:
																																							goto IL_0d78;
																																						case 358:
																																							goto IL_0d8b;
																																						case 337:
																																							goto IL_0d99;
																																						case 179:
																																						case 316:
																																							goto IL_0da7;
																																						case 280:
																																							goto IL_0de4;
																																						case 372:
																																							goto IL_0dfa;
																																						case 375:
																																							goto IL_0e0d;
																																						case 391:
																																							goto IL_0e20;
																																						case 272:
																																							goto IL_0e2b;
																																						case 377:
																																							goto IL_0e3b;
																																						case 43:
																																							goto IL_0e49;
																																						case 257:
																																						case 396:
																																							goto IL_0e59;
																																						case 400:
																																							goto IL_0e9b;
																																						case 37:
																																						case 420:
																																							goto IL_0eae;
																																						case 121:
																																							goto IL_0eee;
																																						case 65:
																																							goto IL_0f02;
																																						case 445:
																																							goto IL_0f15;
																																						case 99:
																																							goto IL_0f29;
																																						case 448:
																																							goto IL_0f3c;
																																						case 89:
																																						case 302:
																																							goto IL_0f47;
																																						case 268:
																																							goto IL_0f5b;
																																						case 364:
																																							goto IL_0f98;
																																						case 140:
																																							goto IL_0fab;
																																						case 325:
																																							goto IL_0fb9;
																																						case 56:
																																						case 116:
																																							goto IL_0fc4;
																																						case 207:
																																							goto IL_0fd8;
																																						case 20:
																																							goto IL_1017;
																																						case 398:
																																							goto IL_102a;
																																						case 397:
																																							goto IL_1038;
																																						case 229:
																																							goto IL_1054;
																																						case 253:
																																							goto IL_1062;
																																						case 106:
																																						case 382:
																																							goto IL_1070;
																																						case 40:
																																							goto IL_10a8;
																																						case 117:
																																							goto IL_10bc;
																																						case 10:
																																						case 450:
																																							goto IL_10cf;
																																						case 301:
																																							goto IL_1131;
																																						case 454:
																																							goto IL_1144;
																																						case 32:
																																						case 456:
																																							goto IL_1157;
																																						case 154:
																																							goto IL_1170;
																																						case 482:
																																							goto IL_1183;
																																						case 23:
																																						case 238:
																																							goto IL_1191;
																																						case 244:
																																						case 497:
																																							goto IL_11d3;
																																						case 504:
																																							goto IL_11e6;
																																						case 305:
																																						case 349:
																																							goto IL_11f1;
																																						case 342:
																																							goto IL_1205;
																																						case 436:
																																							goto IL_1244;
																																						case 149:
																																							goto IL_1257;
																																						case 135:
																																							goto IL_1265;
																																						case 508:
																																							goto IL_1278;
																																						case 77:
																																							goto IL_128c;
																																						case 520:
																																							goto IL_129f;
																																						case 67:
																																						case 109:
																																							goto IL_12ad;
																																						case 122:
																																							goto IL_12c1;
																																						case 334:
																																							goto IL_1312;
																																						case 54:
																																							goto IL_1320;
																																						case 533:
																																							goto IL_1333;
																																						case 299:
																																							goto IL_1341;
																																						case 160:
																																						case 360:
																																							goto IL_134c;
																																						case 97:
																																							goto IL_1360;
																																						case 217:
																																							goto IL_139d;
																																						case 426:
																																							goto IL_13b0;
																																						case 477:
																																							goto IL_13be;
																																						case 258:
																																						case 437:
																																							goto IL_13c9;
																																						case 357:
																																							goto IL_1401;
																																						case 494:
																																							goto IL_1415;
																																						case 449:
																																							goto IL_1428;
																																						case 443:
																																							goto IL_1436;
																																						case 7:
																																						case 171:
																																							goto IL_1444;
																																						case 321:
																																							goto IL_1484;
																																						case 429:
																																							goto IL_1498;
																																						case 309:
																																							goto IL_14ab;
																																						case 98:
																																							goto IL_14b9;
																																						case 205:
																																						case 256:
																																							goto IL_14c7;
																																						case 471:
																																							goto IL_14df;
																																						case 511:
																																							goto IL_14fd;
																																						case 344:
																																							goto IL_1521;
																																						case 52:
																																							goto IL_1539;
																																						case 92:
																																							goto IL_154c;
																																						case 499:
																																							goto IL_1557;
																																						case 209:
																																						case 343:
																																							goto IL_1562;
																																						case 26:
																																							goto IL_157b;
																																						case 212:
																																							goto IL_1589;
																																						case 175:
																																						case 432:
																																							goto IL_1597;
																																						case 352:
																																							goto IL_15aa;
																																						case 536:
																																							goto IL_15bd;
																																						case 70:
																																							goto IL_15cb;
																																						case 185:
																																						case 433:
																																							goto IL_15d6;
																																						case 345:
																																							goto IL_15ea;
																																						case 111:
																																							goto IL_162e;
																																						case 490:
																																							goto IL_163c;
																																						case 33:
																																						case 218:
																																							goto IL_164a;
																																						case 145:
																																							goto IL_165e;
																																						case 47:
																																							goto IL_16ce;
																																						case 463:
																																							goto IL_16e1;
																																						case 235:
																																							goto IL_16ef;
																																						case 39:
																																						case 41:
																																							goto IL_16fd;
																																						case 472:
																																							goto IL_170b;
																																						case 260:
																																							goto IL_171e;
																																						case 313:
																																							goto IL_172c;
																																						case 4:
																																							goto IL_173f;
																																						case 376:
																																							goto IL_174d;
																																						case 180:
																																						case 242:
																																							goto IL_175b;
																																						case 498:
																																							goto IL_1778;
																																						case 72:
																																							goto IL_17b7;
																																						case 75:
																																							goto IL_17d3;
																																						case 142:
																																							goto IL_17de;
																																						case 28:
																																						case 276:
																																							goto IL_17e9;
																																						case 329:
																																							goto IL_1802;
																																						case 466:
																																							goto IL_1810;
																																						case 233:
																																						case 518:
																																							goto IL_181e;
																																						case 124:
																																							goto IL_1828;
																																						case 338:
																																							goto IL_1836;
																																						case 147:
																																							goto IL_1849;
																																						case 8:
																																							goto IL_1854;
																																						case 275:
																																						case 412:
																																							goto IL_1862;
																																						case 167:
																																							goto IL_1876;
																																						case 408:
																																							goto IL_18b5;
																																						case 223:
																																							goto IL_18d1;
																																						case 446:
																																							goto IL_18df;
																																						case 537:
																																							goto IL_18f2;
																																						case 447:
																																							goto IL_193f;
																																						case 492:
																																							goto IL_1956;
																																						case 541:
																																							goto IL_1969;
																																						case 488:
																																						case 531:
																																							goto IL_1977;
																																						case 513:
																																							goto IL_198b;
																																						case 100:
																																							goto IL_19dd;
																																						case 495:
																																							goto IL_19eb;
																																						case 544:
																																							goto IL_19fe;
																																						case 282:
																																							goto IL_1a6d;
																																						case 547:
																																							goto IL_1a80;
																																						case 85:
																																							goto IL_1a8e;
																																						case 107:
																																						case 409:
																																							goto IL_1aa5;
																																						case 298:
																																							goto IL_1ae5;
																																						case 312:
																																							goto IL_1af9;
																																						case 551:
																																							goto IL_1b0c;
																																						case 496:
																																							goto IL_1b1a;
																																						case 192:
																																						case 341:
																																							goto IL_1b25;
																																						case 21:
																																							goto IL_1b33;
																																						case 347:
																																							goto IL_1b57;
																																						case 51:
																																							goto IL_1b65;
																																						case 317:
																																							goto IL_1b78;
																																						case 348:
																																							goto IL_1b86;
																																						case 82:
																																						case 213:
																																							goto IL_1b94;
																																						case 378:
																																							goto IL_1bbf;
																																						case 274:
																																							goto IL_1bd8;
																																						case 113:
																																							goto IL_1be6;
																																						case 240:
																																						case 486:
																																							goto IL_1bf4;
																																						case 468:
																																							goto IL_1c22;
																																						case 553:
																																							goto IL_1c35;
																																						case 480:
																																							goto IL_1c48;
																																						case 24:
																																							goto IL_1c56;
																																						case 527:
																																						case 555:
																																							goto IL_1c69;
																																						case 415:
																																							goto IL_1ca6;
																																						case 365:
																																							goto IL_1cb4;
																																						case 556:
																																							goto IL_1cc7;
																																						case 469:
																																							goto IL_1cd5;
																																						case 273:
																																							goto IL_1ce3;
																																						case 183:
																																							goto IL_1cee;
																																						case 326:
																																							goto IL_1cfc;
																																						case 136:
																																						case 387:
																																							goto IL_1d0a;
																																						case 25:
																																							goto IL_1d23;
																																						case 407:
																																							goto IL_1d31;
																																						case 405:
																																							goto IL_1d3f;
																																						case 402:
																																						case 470:
																																							goto IL_1d52;
																																						case 510:
																																							goto IL_1d9b;
																																						case 138:
																																							goto IL_1daf;
																																						case 190:
																																							goto IL_1dc2;
																																						case 141:
																																							goto IL_1dd0;
																																						case 19:
																																						case 516:
																																							goto IL_1dde;
																																						case 29:
																																							goto IL_1e07;
																																						case 152:
																																							goto IL_1e15;
																																						case 5:
																																						case 291:
																																							goto IL_1e28;
																																						case 465:
																																							goto IL_1e36;
																																						case 91:
																																							goto IL_1e59;
																																						case 269:
																																							goto IL_1e6c;
																																						case 13:
																																							goto IL_1e7a;
																																						case 558:
																																							goto IL_1e8d;
																																						case 318:
																																							goto IL_1e98;
																																						case 483:
																																						case 517:
																																							goto IL_1ea6;
																																						case 189:
																																							goto IL_1eb4;
																																						case 45:
																																							goto IL_1ed8;
																																						case 173:
																																							goto IL_1ee6;
																																						case 53:
																																							goto IL_1ef9;
																																						case 411:
																																							goto IL_1f07;
																																						case 187:
																																						case 455:
																																							goto IL_1f15;
																																						case 110:
																																							goto IL_1f29;
																																						case 303:
																																							goto IL_1f7b;
																																						case 540:
																																							goto IL_1f89;
																																						case 560:
																																							goto IL_1f9c;
																																						case 208:
																																						case 563:
																																							goto IL_1faf;
																																						case 178:
																																							goto IL_1fdc;
																																						case 227:
																																						case 564:
																																							goto IL_1fef;
																																						case 315:
																																							goto IL_202f;
																																						case 168:
																																							goto IL_2043;
																																						case 459:
																																							goto IL_2072;
																																						case 66:
																																							goto IL_2080;
																																						case 0:
																																						case 132:
																																							goto IL_208b;
																																						case 435:
																																							goto IL_20cc;
																																						case 181:
																																							goto IL_20e0;
																																						case 481:
																																							goto IL_20f3;
																																						case 532:
																																							goto IL_2101;
																																						case 388:
																																						case 530:
																																							goto IL_210f;
																																						case 287:
																																							goto IL_2127;
																																						case 416:
																																							goto IL_2132;
																																						case 222:
																																						case 367:
																																							goto IL_2140;
																																						case 169:
																																							goto IL_219b;
																																						case 425:
																																							goto IL_21ae;
																																						case 12:
																																							goto IL_21bc;
																																						case 199:
																																						case 234:
																																							goto IL_21d3;
																																						case 57:
																																							goto IL_21eb;
																																						case 442:
																																							goto IL_21f9;
																																						case 55:
																																							goto IL_2207;
																																						case 203:
																																							goto IL_221a;
																																						case 155:
																																							goto IL_2228;
																																						case 285:
																																						case 401:
																																							goto IL_2233;
																																						case 266:
																																							goto IL_2241;
																																						case 307:
																																							goto IL_2265;
																																						case 193:
																																							goto IL_2273;
																																						case 419:
																																							goto IL_2286;
																																						case 130:
																																							goto IL_2294;
																																						case 159:
																																							goto IL_22a2;
																																						case 507:
																																							goto IL_22b0;
																																						case 493:
																																						case 523:
																																							goto IL_22be;
																																						case 31:
																																							goto IL_22d2;
																																						case 457:
																																							goto IL_2311;
																																						case 550:
																																							goto IL_2324;
																																						case 204:
																																						case 306:
																																							goto IL_232f;
																																						case 418:
																																							goto IL_236f;
																																						case 1:
																																							goto IL_2383;
																																						case 195:
																																							goto IL_2396;
																																						case 246:
																																							goto IL_23a4;
																																						case 395:
																																						case 561:
																																							goto IL_23b2;
																																						case 191:
																																							goto IL_23c6;
																																						case 458:
																																							goto IL_2405;
																																						case 297:
																																							goto IL_242a;
																																						case 225:
																																						case 332:
																																							goto IL_2435;
																																						case 161:
																																							goto IL_244e;
																																						case 150:
																																							goto IL_245c;
																																						case 438:
																																							goto IL_246a;
																																						case 422:
																																							goto IL_247d;
																																						case 49:
																																							goto IL_248b;
																																						case 265:
																																							goto IL_2499;
																																						case 3:
																																							goto IL_24a7;
																																						case 134:
																																						case 379:
																																							goto end_IL_08ff;
																																						case 386:
																																							goto IL_24f6;
																																						case 73:
																																							goto IL_250a;
																																						case 535:
																																						case 552:
																																							goto IL_251d;
																																						case 64:
																																							goto IL_2531;
																																						case 114:
																																							goto IL_256e;
																																						case 293:
																																							goto IL_2581;
																																						case 144:
																																							goto IL_2598;
																																						case 14:
																																						case 380:
																																							goto IL_25a6;
																																						case 534:
																																							goto IL_25dc;
																																						case 441:
																																							goto IL_25ef;
																																						case 239:
																																							goto IL_25fd;
																																						case 557:
																																							goto IL_260b;
																																						case 206:
																																						case 559:
																																							goto IL_2616;
																																						case 514:
																																							goto IL_262a;
																																						case 259:
																																							goto IL_2672;
																																						case 363:
																																							goto IL_2685;
																																						case 444:
																																							goto IL_2693;
																																						case 252:
																																						case 354:
																																							goto IL_26a1;
																																						case 215:
																																							goto IL_26af;
																																						case 506:
																																							goto IL_26cd;
																																						case 30:
																																							goto IL_26db;
																																						case 526:
																																							goto IL_26ee;
																																						case 371:
																																							goto IL_26f9;
																																						case 148:
																																						case 194:
																																							goto IL_2707;
																																						case 529:
																																							goto IL_271b;
																																						case 484:
																																							goto IL_275a;
																																						case 115:
																																							goto IL_276d;
																																						case 34:
																																							goto IL_277b;
																																						case 6:
																																						case 548:
																																							goto IL_2789;
																																						case 255:
																																							goto IL_27a3;
																																						case 462:
																																							goto IL_27b1;
																																						case 474:
																																							goto IL_27bf;
																																						case 565:
																																							goto IL_27db;
																																						case 373:
																																							goto IL_27e9;
																																						case 369:
																																							goto IL_27f7;
																																						case 353:
																																							goto IL_2805;
																																						case 512:
																																							goto IL_2813;
																																						case 197:
																																						case 562:
																																							goto IL_2821;
																																						case 59:
																																							goto IL_285f;
																																						case 48:
																																							goto IL_2873;
																																						case 247:
																																						case 410:
																																							goto IL_2886;
																																						case 525:
																																							goto IL_28f4;
																																						case 478:
																																							goto IL_2907;
																																						case 277:
																																							goto IL_2915;
																																						case 36:
																																						case 294:
																																							goto IL_2923;
																																						case 327:
																																							goto IL_2963;
																																						case 108:
																																							goto IL_2977;
																																						case 393:
																																						case 549:
																																							goto IL_2987;
																																						case 9:
																																						case 27:
																																						case 61:
																																						case 68:
																																						case 71:
																																						case 80:
																																						case 87:
																																						case 93:
																																						case 96:
																																						case 103:
																																						case 104:
																																						case 105:
																																						case 123:
																																						case 127:
																																						case 137:
																																						case 176:
																																						case 184:
																																						case 188:
																																						case 220:
																																						case 228:
																																						case 232:
																																						case 248:
																																						case 251:
																																						case 254:
																																						case 270:
																																						case 278:
																																						case 286:
																																						case 288:
																																						case 290:
																																						case 295:
																																						case 296:
																																						case 320:
																																						case 322:
																																						case 331:
																																						case 333:
																																						case 336:
																																						case 355:
																																						case 361:
																																						case 362:
																																						case 368:
																																						case 370:
																																						case 374:
																																						case 383:
																																						case 384:
																																						case 385:
																																						case 389:
																																						case 390:
																																						case 404:
																																						case 414:
																																						case 421:
																																						case 427:
																																						case 430:
																																						case 434:
																																						case 439:
																																						case 451:
																																						case 460:
																																						case 464:
																																						case 473:
																																						case 475:
																																						case 485:
																																						case 487:
																																						case 489:
																																						case 505:
																																						case 509:
																																						case 515:
																																						case 519:
																																						case 522:
																																						case 524:
																																						case 538:
																																						case 543:
																																						case 546:
																																							goto end_IL_09c3;
																																						case 2:
																																						case 17:
																																						case 22:
																																						case 44:
																																						case 63:
																																						case 69:
																																						case 76:
																																						case 78:
																																						case 81:
																																						case 90:
																																						case 94:
																																						case 118:
																																						case 119:
																																						case 125:
																																						case 128:
																																						case 131:
																																						case 133:
																																						case 143:
																																						case 146:
																																						case 153:
																																						case 158:
																																						case 164:
																																						case 166:
																																						case 170:
																																						case 174:
																																						case 182:
																																						case 202:
																																						case 210:
																																						case 211:
																																						case 216:
																																						case 219:
																																						case 221:
																																						case 231:
																																						case 236:
																																						case 241:
																																						case 262:
																																						case 263:
																																						case 267:
																																						case 271:
																																						case 281:
																																						case 292:
																																						case 310:
																																						case 324:
																																						case 328:
																																						case 330:
																																						case 335:
																																						case 340:
																																						case 346:
																																						case 356:
																																						case 359:
																																						case 381:
																																						case 392:
																																						case 394:
																																						case 403:
																																						case 417:
																																						case 423:
																																						case 428:
																																						case 431:
																																						case 440:
																																						case 452:
																																						case 453:
																																						case 461:
																																						case 467:
																																						case 476:
																																						case 491:
																																						case 503:
																																						case 521:
																																						case 528:
																																						case 539:
																																						case 542:
																																						case 545:
																																							goto end_IL_09f3;
																																						case 230:
																																							goto end_IL_29bc;
																																						case 406:
																																							goto end_IL_29cf;
																																						case 300:
																																							goto end_IL_29d9;
																																						case 424:
																																							goto end_IL_29e4;
																																						case 399:
																																							goto end_IL_29f4;
																																						case 112:
																																							goto end_IL_2a04;
																																						case 172:
																																							goto end_IL_2a14;
																																						case 151:
																																							goto end_IL_2a24;
																																						case 201:
																																							goto end_IL_2a34;
																																						case 554:
																																							goto end_IL_2a44;
																																						case 500:
																																							goto end_IL_2a54;
																																						case 501:
																																							goto end_IL_2a64;
																																						case 279:
																																						case 319:
																																							return;
																																						}
																																						continue;
																																					}
																																					ptr2 += 16;
																																					num = 219;
																																					goto end_IL_09f3;
																																					continue;
																																					end_IL_08ff:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0a84;
																																IL_0ab9:
																																if (11 < b)
																																{
																																	goto end_IL_09c3;
																																}
																																goto IL_0ac7;
																																IL_0a84:
																																if (10 >= b)
																																{
																																	goto IL_0a8f;
																																}
																																goto IL_0ab9;
																																IL_0a8f:
																																if (10 > b)
																																{
																																	goto IL_0a9d;
																																}
																																goto IL_10cf;
																																IL_0a9d:
																																if (9 < b)
																																{
																																	goto end_IL_09c3;
																																}
																																num = 372;
																																goto IL_0dfa;
																																IL_0ac7:
																																if (11 > b)
																																{
																																	goto end_IL_09c3;
																																}
																																num = 118;
																																goto end_IL_09f3;
																																IL_0dfa:
																																if (9 > b)
																																{
																																	goto end_IL_09c3;
																																}
																																goto IL_1fef;
																																IL_1fef:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																goto IL_202f;
																																IL_202f:
																																array[num6 - 2] = 0;
																																goto IL_2043;
																																IL_2043:
																																num6--;
																																goto end_IL_09f3;
																																IL_10cf:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																goto IL_1131;
																																IL_1131:
																																num6 -= 2;
																																goto end_IL_09f3;
																															}
																															break;
																														}
																														goto IL_2072;
																														IL_21f9:
																														num6++;
																														goto IL_2207;
																														IL_2072:
																														if (14 >= b)
																														{
																															goto IL_2080;
																														}
																														goto IL_2127;
																														IL_2080:
																														if (14 <= b)
																														{
																															goto IL_208b;
																														}
																														goto IL_20f3;
																														IL_208b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																														goto IL_20cc;
																														IL_20cc:
																														array[num6 - 2] = 0;
																														goto IL_20e0;
																														IL_20e0:
																														num6--;
																														goto end_IL_09f3;
																														IL_20f3:
																														if (13 < b)
																														{
																															goto end_IL_09c3;
																														}
																														goto IL_2101;
																														IL_2101:
																														if (13 > b)
																														{
																															goto end_IL_09c3;
																														}
																														goto IL_210f;
																														IL_210f:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														goto end_IL_09f3;
																														IL_2127:
																														if (15 >= b)
																														{
																															goto IL_2132;
																														}
																														goto IL_21ae;
																														IL_2132:
																														if (15 > b)
																														{
																															goto end_IL_09c3;
																														}
																														goto IL_2140;
																														IL_2140:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														num = 169;
																														goto IL_219b;
																														IL_219b:
																														num6--;
																														goto end_IL_09f3;
																														IL_21ae:
																														if (16 < b)
																														{
																															goto end_IL_09c3;
																														}
																														goto IL_21bc;
																														IL_21bc:
																														if (16 > b)
																														{
																															goto end_IL_09c3;
																														}
																														num = 234;
																														goto IL_21d3;
																														IL_2207:
																														ptr2 += 8;
																														goto end_IL_09f3;
																														IL_21d3:
																														array2[num6] = array6[*(int*)(ptr2 + num3)];
																														goto IL_21eb;
																														IL_21eb:
																														array[num6] = 5;
																														goto IL_21f9;
																													}
																													break;
																												}
																												goto IL_0c23;
																												IL_0f02:
																												num6--;
																												goto end_IL_09f3;
																												IL_0c23:
																												if (8 > b)
																												{
																													goto IL_0c31;
																												}
																												goto IL_11d3;
																												IL_0c31:
																												if (4 < b)
																												{
																													goto IL_0e20;
																												}
																												goto IL_1cc7;
																												IL_1cc7:
																												if (4 > b)
																												{
																													goto IL_1cd5;
																												}
																												goto IL_1e28;
																												IL_1cd5:
																												if (2 >= b)
																												{
																													goto IL_1ce3;
																												}
																												goto IL_1dc2;
																												IL_1ce3:
																												if (2 > b)
																												{
																													goto IL_1cee;
																												}
																												goto IL_1d52;
																												IL_1cee:
																												if (1 < b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_1cfc;
																												IL_1cfc:
																												if (1 > b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_1d0a;
																												IL_1d0a:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																												goto IL_1d23;
																												IL_1d23:
																												array[num6] = 0;
																												goto IL_1d31;
																												IL_1d31:
																												num6++;
																												goto IL_1d3f;
																												IL_1d3f:
																												ptr2 += 8;
																												goto end_IL_09f3;
																												IL_1d52:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												num = 510;
																												goto IL_1d9b;
																												IL_1d9b:
																												array[num6 - 2] = 0;
																												goto IL_1daf;
																												IL_1daf:
																												num6--;
																												goto end_IL_09f3;
																												IL_1dc2:
																												if (3 < b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_1dd0;
																												IL_1dd0:
																												if (3 > b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_1dde;
																												IL_1dde:
																												ref int reference = ref array4[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_1e07;
																												IL_1e07:
																												ptr2 += 8;
																												goto IL_1e15;
																												IL_1e15:
																												num6--;
																												goto end_IL_09f3;
																												IL_1e28:
																												array[num6] = 0;
																												goto IL_1e36;
																												IL_1e36:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																												goto IL_1e59;
																												IL_1e59:
																												array2[num6] = null;
																												num = 269;
																												goto IL_1e6c;
																												IL_1e6c:
																												num6++;
																												goto IL_1e7a;
																												IL_1e7a:
																												ptr2 += 8;
																												goto end_IL_09f3;
																												IL_0e20:
																												if (6 >= b)
																												{
																													goto IL_0e2b;
																												}
																												goto IL_0e3b;
																												IL_0e2b:
																												if (6 <= b)
																												{
																													goto IL_0e59;
																												}
																												goto IL_1a80;
																												IL_0e59:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_0f15;
																												IL_0f15:
																												array[num6 - 2] = 0;
																												goto IL_0f29;
																												IL_0f29:
																												num6--;
																												goto end_IL_09f3;
																												IL_1a80:
																												if (5 < b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_1a8e;
																												IL_1a8e:
																												if (5 > b)
																												{
																													goto end_IL_09c3;
																												}
																												num = 107;
																												goto IL_1aa5;
																												IL_11d3:
																												num6--;
																												goto end_IL_09f3;
																												IL_1aa5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_1ae5;
																												IL_1ae5:
																												array[num6 - 2] = 0;
																												goto IL_1af9;
																												IL_1af9:
																												num6--;
																												goto end_IL_09f3;
																												IL_0e3b:
																												if (7 < b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_0e49;
																												IL_0e49:
																												if (7 > b)
																												{
																													goto end_IL_09c3;
																												}
																												goto IL_0eae;
																												IL_0eae:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_0eee;
																												IL_0eee:
																												array[num6 - 2] = 0;
																												goto IL_0f02;
																											}
																											break;
																										}
																										goto IL_0c7b;
																										IL_1144:
																										ptr2 += 8;
																										goto end_IL_09f3;
																										IL_0c7b:
																										array[num6] = 5;
																										goto IL_0c89;
																										IL_0c89:
																										array2[num6] = ((delegate*<GorillaTagger>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])();
																										goto IL_0ca7;
																										IL_0ca7:
																										num6++;
																										goto IL_1144;
																									}
																									goto IL_24be;
																									IL_2915:
																									if (28 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2923;
																									IL_221a:
																									if (25 >= b)
																									{
																										goto IL_2228;
																									}
																									goto IL_25ef;
																									IL_2228:
																									if (25 <= b)
																									{
																										goto IL_2233;
																									}
																									goto IL_2286;
																									IL_2233:
																									array[num6] = 3;
																									goto IL_2241;
																									IL_2241:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])();
																									goto IL_2265;
																									IL_2265:
																									num6++;
																									goto IL_2273;
																									IL_2273:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2286:
																									if (21 < b)
																									{
																										goto IL_2294;
																									}
																									num = 297;
																									goto IL_242a;
																									IL_2294:
																									if (23 < b)
																									{
																										goto IL_22a2;
																									}
																									goto IL_2324;
																									IL_22a2:
																									if (24 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_22b0;
																									IL_22b0:
																									if (24 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_22be;
																									IL_22be:
																									array[num6 - 1] = 0;
																									goto IL_22d2;
																									IL_22d2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_2311;
																									IL_2311:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2324:
																									if (23 <= b)
																									{
																										goto IL_232f;
																									}
																									goto IL_2396;
																									IL_232f:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_236f;
																									IL_236f:
																									array[num6 - 2] = 3;
																									goto IL_2383;
																									IL_2383:
																									num6--;
																									goto end_IL_09f3;
																									IL_2396:
																									if (22 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_23a4;
																									IL_23a4:
																									if (22 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_23b2;
																									IL_23b2:
																									array[num6 - 1] = 3;
																									goto IL_23c6;
																									IL_23c6:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_2405;
																									IL_2405:
																									ptr2 += 8;
																									num = 467;
																									goto end_IL_09f3;
																									IL_2923:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_2963;
																									IL_242a:
																									if (21 <= b)
																									{
																										goto IL_2435;
																									}
																									goto IL_247d;
																									IL_2435:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																									goto IL_244e;
																									IL_244e:
																									array[num6] = 3;
																									goto IL_245c;
																									IL_245c:
																									num6++;
																									goto IL_246a;
																									IL_246a:
																									ptr2 += 16;
																									goto end_IL_09f3;
																									IL_247d:
																									if (19 >= b)
																									{
																										goto IL_248b;
																									}
																									goto IL_2581;
																									IL_248b:
																									if (19 > b)
																									{
																										goto IL_2499;
																									}
																									goto IL_251d;
																									IL_2499:
																									if (18 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_24a7;
																									IL_24a7:
																									if (18 > b)
																									{
																										goto end_IL_09c3;
																									}
																									num = 379;
																									goto IL_24be;
																									IL_2963:
																									array[num6 - 2] = 3;
																									goto IL_2977;
																									IL_24be:
																									array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																									goto IL_24f6;
																									IL_24f6:
																									array[num6 - 1] = 5;
																									goto IL_250a;
																									IL_250a:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_251d:
																									array[num6 - 1] = 4;
																									goto IL_2531;
																									IL_2531:
																									array2[num6 - 1] = ((delegate*<Transform, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																									goto IL_256e;
																									IL_256e:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2581:
																									if (20 < b)
																									{
																										goto end_IL_09c3;
																									}
																									num = 144;
																									goto IL_2598;
																									IL_2977:
																									num6--;
																									goto end_IL_09f3;
																									IL_2598:
																									if (20 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_25a6;
																									IL_25a6:
																									((Class195)array2[num6 - 2]).vector3_1 = (Vector3)array2[num6 - 1];
																									num = 534;
																									goto IL_25dc;
																									IL_25dc:
																									num6 -= 2;
																									goto end_IL_09f3;
																									IL_25ef:
																									if (29 < b)
																									{
																										goto IL_25fd;
																									}
																									num = 565;
																									goto IL_27db;
																									IL_25fd:
																									if (31 >= b)
																									{
																										goto IL_260b;
																									}
																									goto IL_26ee;
																									IL_260b:
																									if (31 <= b)
																									{
																										goto IL_2616;
																									}
																									goto IL_2685;
																									IL_2616:
																									array[num6 - 1] = 3;
																									goto IL_262a;
																									IL_262a:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									num = 259;
																									goto IL_2672;
																									IL_2672:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2685:
																									if (30 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2693;
																									IL_2693:
																									if (30 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_26a1;
																									IL_26a1:
																									array[num6] = 5;
																									goto IL_26af;
																									IL_26af:
																									array2[num6] = ((delegate*<GorillaTagger>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])();
																									goto IL_26cd;
																									IL_26cd:
																									num6++;
																									goto IL_26db;
																									IL_26db:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_26ee:
																									if (32 >= b)
																									{
																										goto IL_26f9;
																									}
																									goto IL_276d;
																									IL_26f9:
																									if (32 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2707;
																									IL_2707:
																									array[num6 - 1] = 0;
																									goto IL_271b;
																									IL_271b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																									goto IL_275a;
																									IL_275a:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_276d:
																									if (33 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_277b;
																									IL_277b:
																									if (33 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2789;
																									IL_2789:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																									goto IL_27a3;
																									IL_27a3:
																									array[num6] = 3;
																									goto IL_27b1;
																									IL_27b1:
																									num6++;
																									goto IL_27bf;
																									IL_27bf:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2987:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									num = 44;
																									goto end_IL_09f3;
																									IL_27db:
																									if (29 > b)
																									{
																										goto IL_27e9;
																									}
																									goto IL_2987;
																									IL_27e9:
																									if (27 >= b)
																									{
																										goto IL_27f7;
																									}
																									goto IL_2907;
																									IL_27f7:
																									if (27 > b)
																									{
																										goto IL_2805;
																									}
																									goto IL_2886;
																									IL_2805:
																									if (26 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2813;
																									IL_2813:
																									if (26 > b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2821;
																									IL_2821:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<Class195, float>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Class195)array2[num6 - 1]);
																									goto IL_285f;
																									IL_285f:
																									array[num6 - 1] = 3;
																									goto IL_2873;
																									IL_2873:
																									ptr2 += 8;
																									goto end_IL_09f3;
																									IL_2886:
																									ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_28f4;
																									IL_28f4:
																									num6 -= 2;
																									goto end_IL_09f3;
																									IL_2907:
																									if (28 < b)
																									{
																										goto end_IL_09c3;
																									}
																									goto IL_2915;
																									continue;
																									end_IL_0996:
																									break;
																								}
																								continue;
																							}
																							goto IL_0a07;
																							IL_0e9b:
																							ptr2 += 8;
																							goto end_IL_09f3;
																							IL_0a07:
																							((delegate*<GorillaTagger, XRNode, float, float, void>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 4], *(XRNode*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3]), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																							goto IL_0d78;
																							IL_0d78:
																							num6 -= 4;
																							goto IL_0e9b;
																							continue;
																							end_IL_09a6:
																							break;
																						}
																						continue;
																					}
																					goto IL_0a74;
																					IL_18d1:
																					if (68 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_18df;
																					IL_0a74:
																					if (51 < b)
																					{
																						goto IL_0ae3;
																					}
																					goto IL_0c44;
																					IL_0c44:
																					if (51 <= b)
																					{
																						goto IL_0c4f;
																					}
																					goto IL_0cba;
																					IL_0c4f:
																					global::_003CModule_003E.vector3_155 = (Vector3)array2[num6 - 1];
																					goto IL_0c68;
																					IL_0c68:
																					num6--;
																					goto end_IL_09f3;
																					IL_0cba:
																					if (42 < b)
																					{
																						goto IL_0cc8;
																					}
																					goto IL_129f;
																					IL_0cc8:
																					if (46 < b)
																					{
																						goto IL_0cd6;
																					}
																					goto IL_0f3c;
																					IL_0cd6:
																					if (48 >= b)
																					{
																						goto IL_0ce4;
																					}
																					goto IL_1e8d;
																					IL_0ce4:
																					if (48 <= b)
																					{
																						goto IL_0cf2;
																					}
																					goto IL_0d8b;
																					IL_0cf2:
																					array[num6 - 2] = 4;
																					goto IL_0d06;
																					IL_0d06:
																					array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_0d57;
																					IL_0d57:
																					num6--;
																					goto IL_0d65;
																					IL_0d65:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_0d8b:
																					if (47 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_0d99;
																					IL_0d99:
																					if (47 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_0da7;
																					IL_0da7:
																					array2[num6 - 1] = ((delegate*<Class195, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Class195)array2[num6 - 1]);
																					goto IL_0de4;
																					IL_0de4:
																					array[num6 - 1] = 4;
																					goto IL_0e0d;
																					IL_0e0d:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1e8d:
																					if (49 >= b)
																					{
																						goto IL_1e98;
																					}
																					goto IL_1ef9;
																					IL_1e98:
																					if (49 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1ea6;
																					IL_1ea6:
																					array[num6] = 3;
																					goto IL_1eb4;
																					IL_1eb4:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])();
																					goto IL_1ed8;
																					IL_1ed8:
																					num6++;
																					goto IL_1ee6;
																					IL_1ee6:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1ef9:
																					if (50 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1f07;
																					IL_1f07:
																					if (50 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1f15;
																					IL_1f15:
																					array[num6 - 2] = 4;
																					goto IL_1f29;
																					IL_1f29:
																					array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																					goto IL_1f7b;
																					IL_1f7b:
																					num6--;
																					goto IL_1f89;
																					IL_1f89:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_0f3c:
																					if (46 <= b)
																					{
																						goto IL_0f47;
																					}
																					goto IL_0fab;
																					IL_0f47:
																					array[num6 - 1] = 4;
																					goto IL_0f5b;
																					IL_0f5b:
																					array2[num6 - 1] = ((delegate*<Transform, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																					goto IL_0f98;
																					IL_0f98:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_0fab:
																					if (44 >= b)
																					{
																						goto IL_0fb9;
																					}
																					goto IL_1054;
																					IL_0fb9:
																					if (44 <= b)
																					{
																						goto IL_0fc4;
																					}
																					goto IL_102a;
																					IL_0fc4:
																					array[num6 - 1] = 3;
																					goto IL_0fd8;
																					IL_0fd8:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_1017;
																					IL_1017:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_102a:
																					if (43 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1038;
																					IL_1038:
																					if (43 > b)
																					{
																						goto end_IL_09c3;
																					}
																					num = 527;
																					goto IL_1c69;
																					IL_18df:
																					if (68 > b)
																					{
																					}
																					goto end_IL_09c3;
																					IL_1c69:
																					((delegate*<Rigidbody, Vector3, void>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_1ca6;
																					IL_1ca6:
																					num6 -= 2;
																					goto IL_1cb4;
																					IL_1cb4:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1054:
																					if (45 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1062;
																					IL_1062:
																					if (45 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1070;
																					IL_1070:
																					array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																					goto IL_10a8;
																					IL_10a8:
																					array[num6 - 1] = 5;
																					goto IL_10bc;
																					IL_10bc:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_129f:
																					if (42 <= b)
																					{
																						goto IL_12ad;
																					}
																					goto IL_1333;
																					IL_12ad:
																					array[num6 - 2] = 4;
																					goto IL_12c1;
																					IL_12c1:
																					array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_1312;
																					IL_1312:
																					num6--;
																					goto IL_1320;
																					IL_1320:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1333:
																					if (38 >= b)
																					{
																						goto IL_1341;
																					}
																					goto IL_154c;
																					IL_1341:
																					if (38 <= b)
																					{
																						goto IL_134c;
																					}
																					goto IL_13b0;
																					IL_134c:
																					array[num6 - 1] = 4;
																					goto IL_1360;
																					IL_1360:
																					array2[num6 - 1] = ((delegate*<Rigidbody, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 1]);
																					goto IL_139d;
																					IL_139d:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_13b0:
																					if (36 >= b)
																					{
																						goto IL_13be;
																					}
																					goto IL_14ab;
																					IL_13be:
																					if (36 <= b)
																					{
																						goto IL_13c9;
																					}
																					goto IL_1428;
																					IL_13c9:
																					array2[num6 - 1] = ((delegate*<Class195, Rigidbody>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Class195)array2[num6 - 1]);
																					goto IL_1401;
																					IL_1401:
																					array[num6 - 1] = 5;
																					goto IL_1415;
																					IL_1415:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1428:
																					if (35 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1436;
																					IL_1436:
																					if (35 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1444;
																					IL_1444:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_1484;
																					IL_1484:
																					array[num6 - 2] = 3;
																					goto IL_1498;
																					IL_1498:
																					num6--;
																					goto end_IL_09f3;
																					IL_14ab:
																					if (37 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_14b9;
																					IL_14b9:
																					if (37 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_14c7;
																					IL_14c7:
																					array[num6] = array[num6 - 1];
																					goto IL_14df;
																					IL_14df:
																					array3[num6 - 0] = array3[num6 - 1];
																					goto IL_14fd;
																					IL_14fd:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_1521;
																					IL_1521:
																					array2[num6] = array2[num6 - 1];
																					goto IL_1539;
																					IL_1539:
																					num6++;
																					goto end_IL_09f3;
																					IL_154c:
																					if (40 >= b)
																					{
																						goto IL_1557;
																					}
																					goto IL_15aa;
																					IL_1557:
																					if (40 <= b)
																					{
																						goto IL_1562;
																					}
																					goto IL_157b;
																					IL_1562:
																					array[num6 - 1] = 4;
																					goto IL_19fe;
																					IL_19fe:
																					array2[num6 - 1] = ((delegate*<ref Vector3, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)getWindowClassSectionIsVerified[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																					goto IL_1a6d;
																					IL_1a6d:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_157b:
																					if (39 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1589;
																					IL_1589:
																					if (39 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1597;
																					IL_1597:
																					array[num6] = 15;
																					goto IL_1c35;
																					IL_1c35:
																					array3[num6] = *(int*)(ptr2 + num3);
																					goto IL_1c48;
																					IL_1c48:
																					ptr2 += 8;
																					goto IL_1c56;
																					IL_1c56:
																					num6++;
																					goto end_IL_09f3;
																					IL_15aa:
																					if (41 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1969;
																					IL_1969:
																					if (41 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1977;
																					IL_1977:
																					array[num6 - 2] = 4;
																					goto IL_198b;
																					IL_198b:
																					array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																					goto IL_19dd;
																					IL_19dd:
																					num6--;
																					goto IL_19eb;
																					IL_19eb:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_0ae3:
																					if (60 >= b)
																					{
																						goto IL_0af1;
																					}
																					goto IL_15bd;
																					IL_0af1:
																					if (60 > b)
																					{
																						goto IL_0afc;
																					}
																					goto IL_0b28;
																					IL_0afc:
																					if (55 < b)
																					{
																						goto IL_0b0a;
																					}
																					goto IL_0baf;
																					IL_0b0a:
																					if (57 < b)
																					{
																						goto IL_0b18;
																					}
																					goto IL_11e6;
																					IL_0b18:
																					if (58 < b)
																					{
																						goto IL_0b8e;
																					}
																					goto IL_1183;
																					IL_1183:
																					if (58 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1191;
																					IL_1191:
																					array2[num6 - 1] = ((delegate*<Class195, Vector3>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Class195)array2[num6 - 1]);
																					goto IL_1278;
																					IL_1278:
																					array[num6 - 1] = 4;
																					goto IL_128c;
																					IL_128c:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_0b8e:
																					if (59 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_0b9c;
																					IL_0b9c:
																					if (59 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1157;
																					IL_1157:
																					global::_003CModule_003E.j_007Dk_BATwUW = (Vector3)array2[num6 - 1];
																					goto IL_1170;
																					IL_1170:
																					num6--;
																					goto end_IL_09f3;
																					IL_11e6:
																					if (57 <= b)
																					{
																						goto IL_11f1;
																					}
																					goto IL_1257;
																					IL_11f1:
																					array[num6 - 1] = 3;
																					goto IL_1205;
																					IL_1205:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_1244;
																					IL_1244:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1257:
																					if (56 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1265;
																					IL_1265:
																					if (56 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1faf;
																					IL_1faf:
																					((Class195)array2[num6 - 2]).vector3_0 = (Vector3)array2[num6 - 1];
																					goto IL_1fdc;
																					IL_1fdc:
																					num6 -= 2;
																					goto end_IL_09f3;
																					IL_0baf:
																					if (55 <= b)
																					{
																						goto IL_0bbd;
																					}
																					goto IL_1b0c;
																					IL_0bbd:
																					array[num6 - 1] = 3;
																					goto IL_0bd1;
																					IL_0bd1:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_0c10;
																					IL_0c10:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1b0c:
																					if (53 >= b)
																					{
																						goto IL_1b1a;
																					}
																					goto IL_1bd8;
																					IL_1b1a:
																					if (53 <= b)
																					{
																						goto IL_1b25;
																					}
																					goto IL_1b78;
																					IL_1b25:
																					array[num6] = 3;
																					goto IL_1b33;
																					IL_1b33:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])();
																					goto IL_1b57;
																					IL_1b57:
																					num6++;
																					goto IL_1b65;
																					IL_1b65:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1b78:
																					if (52 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1b86;
																					IL_1b86:
																					if (52 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1b94;
																					IL_1b94:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_1bbf;
																					IL_1bbf:
																					array[num6 - 1] = 0;
																					goto end_IL_09f3;
																					IL_1bd8:
																					if (54 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1be6;
																					IL_1be6:
																					if (54 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1bf4;
																					IL_1bf4:
																					((Class195)array2[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_1c22;
																					IL_1c22:
																					num6 -= 2;
																					goto end_IL_09f3;
																					IL_0b28:
																					array[num6 - 1] = 3;
																					goto IL_0b3c;
																					IL_0b3c:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_0b7b;
																					IL_0b7b:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_15bd:
																					if (64 >= b)
																					{
																						goto IL_15cb;
																					}
																					goto IL_17d3;
																					IL_15cb:
																					if (64 <= b)
																					{
																						goto IL_15d6;
																					}
																					goto IL_162e;
																					IL_15d6:
																					array[num6 - 1] = 3;
																					goto IL_15ea;
																					IL_15ea:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_1f9c;
																					IL_1f9c:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_162e:
																					if (62 >= b)
																					{
																						goto IL_163c;
																					}
																					goto IL_173f;
																					IL_163c:
																					if (62 <= b)
																					{
																						goto IL_164a;
																					}
																					goto IL_16e1;
																					IL_164a:
																					array[num6 - 1] = 3;
																					goto IL_165e;
																					IL_165e:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<ref Vector3, float>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)getWindowClassSectionIsVerified[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																					goto IL_16ce;
																					IL_16ce:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_16e1:
																					if (61 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_16ef;
																					IL_16ef:
																					if (61 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_16fd;
																					IL_16fd:
																					array[num6] = 15;
																					goto IL_170b;
																					IL_170b:
																					array3[num6] = *(int*)(ptr2 + num3);
																					goto IL_171e;
																					IL_171e:
																					ptr2 += 8;
																					goto IL_172c;
																					IL_172c:
																					num6++;
																					goto end_IL_09f3;
																					IL_173f:
																					if (63 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_174d;
																					IL_174d:
																					if (63 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_175b;
																					IL_175b:
																					array[num6 - 1] = 3;
																					num = 498;
																					goto IL_1778;
																					IL_1778:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_17b7;
																					IL_17b7:
																					ptr2 += 8;
																					num = 428;
																					goto end_IL_09f3;
																					IL_17d3:
																					if (66 >= b)
																					{
																						goto IL_17de;
																					}
																					goto IL_1849;
																					IL_17de:
																					if (66 <= b)
																					{
																						goto IL_17e9;
																					}
																					goto IL_1802;
																					IL_17e9:
																					array[num6 - 2] = 0;
																					goto IL_18f2;
																					IL_18f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])((Rigidbody)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_193f;
																					IL_193f:
																					num6--;
																					num = 492;
																					goto IL_1956;
																					IL_1956:
																					ptr2 += 8;
																					goto end_IL_09f3;
																					IL_1802:
																					if (65 < b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1810;
																					IL_1810:
																					if (65 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_181e;
																					IL_181e:
																					array2[num6] = null;
																					goto IL_1828;
																					IL_1828:
																					array[num6] = 5;
																					goto IL_1836;
																					IL_1836:
																					num6++;
																					goto end_IL_09f3;
																					IL_1849:
																					if (67 >= b)
																					{
																						goto IL_1854;
																					}
																					goto IL_18d1;
																					IL_1854:
																					if (67 > b)
																					{
																						goto end_IL_09c3;
																					}
																					goto IL_1862;
																					IL_1862:
																					array[num6 - 1] = 3;
																					goto IL_1876;
																					IL_1876:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)getWindowClassSectionIsVerified[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_18b5;
																					IL_18b5:
																					ptr2 += 8;
																					num = 539;
																					goto end_IL_09f3;
																					continue;
																					end_IL_09b3:
																					break;
																				}
																				continue;
																				end_IL_09c3:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_09f3;
																		continue;
																		end_IL_09d3:
																		break;
																	}
																	continue;
																	end_IL_09e3:
																	break;
																}
																continue;
																end_IL_09f3:
																break;
															}
															continue;
															end_IL_29bc:
															break;
														}
														continue;
														end_IL_29cf:
														break;
													}
													continue;
													end_IL_29d9:
													break;
												}
												continue;
												end_IL_29e4:
												break;
											}
											continue;
											end_IL_29f4:
											break;
										}
										continue;
										end_IL_2a04:
										break;
									}
									continue;
									end_IL_2a14:
									break;
								}
								continue;
								end_IL_2a24:
								break;
							}
							continue;
							end_IL_2a34:
							break;
						}
						continue;
						end_IL_2a44:
						break;
					}
					continue;
					end_IL_2a54:
					break;
				}
				continue;
				end_IL_2a64:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 80;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							IL_09e5:
							int[] array3 = new int[6];
							while (true)
							{
								IL_09cc:
								long[] array4 = new long[3];
								num = 125;
								while (true)
								{
									IL_09bc:
									object[] array5 = new object[1];
									while (true)
									{
										IL_09ac:
										array5[0] = this;
										while (true)
										{
											IL_09a1:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OgetWindowHeight.CurrencyGroupSeparatorStandardName);
											while (true)
											{
												IL_0997:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_098c:
													num = 99;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															IL_02fd:
															byte b = *ptr2;
															while (true)
															{
																IL_02ed:
																ptr2++;
																while (true)
																{
																	IL_02dd:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_02bd:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02ad:
																						if (12 >= b)
																						{
																							num = 61;
																							while (true)
																							{
																								IL_029a:
																								if (12 <= b)
																								{
																									num = 151;
																									while (num != 151)
																									{
																										if (num != 1132)
																										{
																											goto end_IL_0979;
																										}
																										switch (num)
																										{
																										case 61:
																											goto IL_029a;
																										case 42:
																											goto IL_02ad;
																										case 143:
																											goto IL_02bd;
																										case 51:
																											goto IL_02cd;
																										case 135:
																											goto IL_02dd;
																										case 22:
																											goto IL_02ed;
																										case 63:
																										case 133:
																											goto IL_02fd;
																										case 139:
																											goto IL_0308;
																										case 36:
																											goto IL_0316;
																										case 57:
																										case 120:
																											goto IL_0321;
																										case 37:
																											goto IL_033b;
																										case 117:
																											goto IL_0349;
																										case 7:
																											goto IL_0357;
																										case 52:
																											goto IL_036a;
																										case 48:
																											goto IL_0378;
																										case 18:
																										case 111:
																											goto IL_0386;
																										case 136:
																											goto IL_039e;
																										case 23:
																											goto IL_03ac;
																										case 50:
																											goto IL_03ba;
																										case 54:
																											goto IL_03cd;
																										case 91:
																											goto IL_03d8;
																										case 70:
																										case 132:
																											goto IL_03e6;
																										case 76:
																											goto IL_0414;
																										case 69:
																											goto IL_0427;
																										case 68:
																											goto IL_0435;
																										case 34:
																										case 141:
																											goto IL_0443;
																										case 100:
																											goto IL_045f;
																										case 102:
																											goto IL_046d;
																										case 13:
																										case 14:
																											goto IL_0478;
																										case 31:
																											goto IL_04e3;
																										case 106:
																											goto IL_04f6;
																										case 90:
																											goto IL_0504;
																										case 46:
																										case 84:
																											goto IL_0512;
																										case 94:
																											goto IL_0552;
																										case 53:
																											goto IL_0566;
																										case 28:
																											goto IL_0582;
																										case 77:
																											goto IL_0590;
																										case 5:
																										case 71:
																											goto IL_059e;
																										case 112:
																											goto IL_05b2;
																										case 0:
																											goto IL_05f1;
																										case 21:
																											goto IL_060d;
																										case 19:
																										case 128:
																											goto IL_0618;
																										case 110:
																											goto IL_062b;
																										case 67:
																											goto IL_0639;
																										case 39:
																										case 97:
																											goto IL_0644;
																										case 87:
																											goto IL_0652;
																										case 138:
																											goto IL_0675;
																										case 73:
																											goto IL_067f;
																										case 35:
																											goto IL_068d;
																										case 113:
																											goto IL_06a0;
																										case 2:
																											goto IL_06ae;
																										case 27:
																										case 32:
																											goto IL_06b9;
																										case 131:
																											goto IL_06f9;
																										case 95:
																											goto IL_070d;
																										case 134:
																											goto IL_0720;
																										case 107:
																											goto IL_072e;
																										case 1:
																											goto IL_0741;
																										case 122:
																											goto IL_074f;
																										case 3:
																										case 66:
																											goto IL_075d;
																										case 15:
																											goto IL_0786;
																										case 64:
																											goto IL_0794;
																										case 29:
																											goto IL_07b0;
																										case 103:
																											goto IL_07be;
																										case 8:
																										case 10:
																											goto IL_07c9;
																										case 49:
																											goto IL_0809;
																										case 96:
																											goto IL_081d;
																										case 60:
																											goto IL_0830;
																										case 16:
																											goto IL_083e;
																										case 59:
																										case 108:
																											goto IL_084c;
																										case 116:
																											goto IL_088c;
																										case 58:
																											goto IL_08a0;
																										case 83:
																											goto IL_08b3;
																										case 88:
																											goto IL_08be;
																										case 44:
																										case 89:
																											goto IL_08c9;
																										case 129:
																											goto IL_0909;
																										case 127:
																											goto IL_091d;
																										case 9:
																										case 24:
																										case 25:
																										case 41:
																										case 45:
																										case 55:
																										case 56:
																										case 62:
																										case 72:
																										case 74:
																										case 81:
																										case 86:
																										case 93:
																										case 98:
																										case 104:
																										case 109:
																										case 114:
																										case 142:
																										case 144:
																											goto end_IL_02cd;
																										case 82:
																											goto IL_094f;
																										case 26:
																											goto IL_095d;
																										case 65:
																											goto IL_096b;
																										case 4:
																										case 6:
																										case 12:
																										case 17:
																										case 33:
																										case 38:
																										case 43:
																										case 85:
																										case 92:
																										case 99:
																										case 101:
																										case 118:
																										case 123:
																										case 124:
																										case 130:
																										case 137:
																										case 140:
																											goto end_IL_0287;
																										case 11:
																											goto IL_098c;
																										case 121:
																											goto IL_0997;
																										case 40:
																											goto IL_09a1;
																										case 30:
																											goto IL_09ac;
																										case 125:
																											goto IL_09bc;
																										case 78:
																											goto IL_09cc;
																										case 47:
																										case 119:
																											goto IL_09e5;
																										case 75:
																											goto end_IL_0979;
																										case 105:
																										case 115:
																											goto end_IL_09f5;
																										case 79:
																											goto end_IL_0a05;
																										case 80:
																											goto end_IL_0a15;
																										case 20:
																										case 126:
																											return;
																										}
																										continue;
																										end_IL_0287:
																										break;
																									}
																									break;
																								}
																								goto IL_045f;
																								IL_05b2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)BuildVersionCultureAwareRandomizedComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_05f1;
																								IL_05f1:
																								ptr2 += 8;
																								break;
																								IL_045f:
																								if (10 >= b)
																								{
																									goto IL_046d;
																								}
																								goto IL_0582;
																								IL_046d:
																								if (10 <= b)
																								{
																									goto IL_0478;
																								}
																								goto IL_04f6;
																								IL_0478:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 31;
																								goto IL_04e3;
																								IL_04e3:
																								num5 -= 2;
																								break;
																								IL_04f6:
																								if (9 < b)
																								{
																									goto end_IL_02cd;
																								}
																								goto IL_0504;
																								IL_0504:
																								if (9 > b)
																								{
																									goto end_IL_02cd;
																								}
																								goto IL_0512;
																								IL_0512:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0552;
																								IL_0552:
																								array[num5 - 2] = 0;
																								goto IL_0566;
																								IL_0566:
																								num5--;
																								num = 38;
																								break;
																								IL_0582:
																								if (11 < b)
																								{
																									goto end_IL_02cd;
																								}
																								goto IL_0590;
																								IL_0590:
																								if (11 > b)
																								{
																									goto end_IL_02cd;
																								}
																								goto IL_059e;
																								IL_059e:
																								array[num5 - 1] = 0;
																								goto IL_05b2;
																							}
																							break;
																						}
																						goto IL_0308;
																						IL_0435:
																						if (16 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_0443;
																						IL_0443:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_0308:
																						if (14 >= b)
																						{
																							goto IL_0316;
																						}
																						goto IL_03cd;
																						IL_0316:
																						if (14 <= b)
																						{
																							goto IL_0321;
																						}
																						goto IL_036a;
																						IL_0321:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																						goto IL_033b;
																						IL_033b:
																						array[num5] = 3;
																						goto IL_0349;
																						IL_0349:
																						num5++;
																						goto IL_0357;
																						IL_0357:
																						ptr2 += 8;
																						break;
																						IL_036a:
																						if (13 < b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_0378;
																						IL_0378:
																						if (13 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_0386;
																						IL_0386:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_039e;
																						IL_039e:
																						array[num5] = 5;
																						goto IL_03ac;
																						IL_03ac:
																						num5++;
																						goto IL_03ba;
																						IL_03ba:
																						ptr2 += 8;
																						break;
																						IL_03cd:
																						if (15 >= b)
																						{
																							goto IL_03d8;
																						}
																						goto IL_0427;
																						IL_03d8:
																						if (15 > b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_03e6;
																						IL_03e6:
																						((Class195)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_0414;
																						IL_0414:
																						num5 -= 2;
																						break;
																						IL_0427:
																						if (16 < b)
																						{
																							goto end_IL_02cd;
																						}
																						goto IL_0435;
																					}
																					break;
																				}
																				num = 21;
																				goto IL_060d;
																				IL_0909:
																				array[num5 - 2] = 0;
																				goto IL_091d;
																				IL_091d:
																				num5--;
																				break;
																				IL_060d:
																				if (8 <= b)
																				{
																					goto IL_0618;
																				}
																				goto IL_062b;
																				IL_0618:
																				num5--;
																				break;
																				IL_062b:
																				if (4 >= b)
																				{
																					goto IL_0639;
																				}
																				goto IL_07b0;
																				IL_0639:
																				if (4 <= b)
																				{
																					goto IL_0644;
																				}
																				goto IL_06a0;
																				IL_0644:
																				array[num5] = 0;
																				goto IL_0652;
																				IL_0652:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0675;
																				IL_0675:
																				array2[num5] = null;
																				goto IL_067f;
																				IL_067f:
																				num5++;
																				goto IL_068d;
																				IL_068d:
																				ptr2 += 8;
																				break;
																				IL_06a0:
																				if (2 >= b)
																				{
																					goto IL_06ae;
																				}
																				goto IL_0741;
																				IL_06ae:
																				if (2 <= b)
																				{
																					goto IL_06b9;
																				}
																				goto IL_0720;
																				IL_06b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06f9;
																				IL_06f9:
																				array[num5 - 2] = 0;
																				goto IL_070d;
																				IL_070d:
																				num5--;
																				break;
																				IL_0720:
																				if (1 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_072e;
																				IL_072e:
																				if (1 > b)
																				{
																				}
																				goto end_IL_02cd;
																				IL_0741:
																				if (3 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_074f;
																				IL_074f:
																				if (3 > b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_075d;
																				IL_075d:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0786;
																				IL_0786:
																				ptr2 += 8;
																				goto IL_0794;
																				IL_0794:
																				num5--;
																				num = 85;
																				break;
																				IL_07b0:
																				if (6 >= b)
																				{
																					goto IL_07be;
																				}
																				goto IL_08b3;
																				IL_07be:
																				if (6 <= b)
																				{
																					goto IL_07c9;
																				}
																				goto IL_0830;
																				IL_07c9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0809;
																				IL_0809:
																				array[num5 - 2] = 0;
																				goto IL_081d;
																				IL_081d:
																				num5--;
																				break;
																				IL_0830:
																				if (5 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_083e;
																				IL_083e:
																				if (5 > b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_084c;
																				IL_084c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_088c;
																				IL_088c:
																				array[num5 - 2] = 0;
																				goto IL_08a0;
																				IL_08a0:
																				num5--;
																				break;
																				IL_08b3:
																				if (7 < b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_08be;
																				IL_08be:
																				if (7 > b)
																				{
																					goto end_IL_02cd;
																				}
																				goto IL_08c9;
																				IL_08c9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0909;
																			}
																			goto end_IL_02dd;
																			continue;
																			end_IL_02cd:
																			break;
																			IL_02cd:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	num = 82;
																	goto IL_094f;
																	IL_096b:
																	ptr2 += 8;
																	break;
																	IL_095d:
																	num5++;
																	goto IL_096b;
																	IL_094f:
																	array[num5] = 0;
																	goto IL_095d;
																	continue;
																	end_IL_02dd:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0979:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_09f5:
						break;
					}
					continue;
					end_IL_0a05:
					break;
				}
				continue;
				end_IL_0a15:
				break;
			}
		}
	}

	public Class195()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3)
	{
		int num = 111;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_07b0:
						object[] array2 = new object[3];
						while (true)
						{
							IL_07a0:
							int[] array3 = new int[4];
							while (true)
							{
								IL_0790:
								long[] array4 = new long[3];
								while (true)
								{
									IL_077b:
									array3[0] = int_3;
									while (true)
									{
										IL_0770:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenerateKeyXmlElementName.ModuleBuilderNumberGroupSizes);
										while (true)
										{
											IL_0766:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0753:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d3:
														byte b = *ptr2;
														while (true)
														{
															IL_02c3:
															ptr2++;
															while (true)
															{
																IL_02b3:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02a6:
																		if (b <= 13)
																		{
																			while (true)
																			{
																				IL_0296:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_0289:
																						if (7 <= b)
																						{
																							while (true)
																							{
																								IL_023e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 135;
																								while (true)
																								{
																									if (num != 135)
																									{
																										if (num != 1116)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 116:
																										case 119:
																											goto IL_023e;
																										case 15:
																											goto IL_0289;
																										case 89:
																											goto IL_0296;
																										case 3:
																											goto IL_02a6;
																										case 51:
																											goto IL_02b3;
																										case 73:
																											goto IL_02c3;
																										case 65:
																										case 100:
																											goto IL_02d3;
																										case 63:
																										case 77:
																											goto IL_02ec;
																										case 84:
																											goto IL_02fa;
																										case 74:
																										case 97:
																											goto IL_0308;
																										case 14:
																											goto IL_0316;
																										case 1:
																										case 103:
																											goto IL_0324;
																										case 101:
																											goto IL_0364;
																										case 94:
																											goto IL_0378;
																										case 107:
																											goto IL_038b;
																										case 22:
																										case 80:
																											goto IL_0396;
																										case 76:
																											goto IL_03a4;
																										case 57:
																											goto IL_03d0;
																										case 61:
																											goto IL_03da;
																										case 59:
																											goto IL_03e8;
																										case 5:
																											goto IL_0404;
																										case 4:
																											goto IL_0412;
																										case 113:
																											goto IL_042e;
																										case 28:
																										case 106:
																											goto IL_043c;
																										case 93:
																											goto IL_0447;
																										case 7:
																										case 40:
																											goto IL_0455;
																										case 39:
																											goto IL_046e;
																										case 78:
																											goto IL_047c;
																										case 98:
																											goto IL_048a;
																										case 2:
																											goto IL_04a6;
																										case 12:
																											goto IL_04b4;
																										case 47:
																										case 120:
																											goto IL_04c4;
																										case 17:
																										case 127:
																											goto IL_04dc;
																										case 125:
																											goto IL_0505;
																										case 83:
																											goto IL_0513;
																										case 36:
																											goto IL_053a;
																										case 115:
																										case 124:
																											goto IL_054d;
																										case 43:
																											goto IL_055b;
																										case 35:
																										case 95:
																											goto IL_0569;
																										case 37:
																											goto IL_0574;
																										case 23:
																										case 102:
																											goto IL_0582;
																										case 24:
																											goto IL_05a5;
																										case 66:
																											goto IL_05b3;
																										case 45:
																											goto IL_05c1;
																										case 11:
																											goto IL_05d4;
																										case 75:
																											goto IL_05e2;
																										case 31:
																										case 54:
																											goto IL_05f0;
																										case 38:
																											goto IL_0652;
																										case 42:
																										case 49:
																											goto IL_0665;
																										case 13:
																											goto IL_0673;
																										case 53:
																											goto IL_06a0;
																										case 41:
																											goto IL_06ae;
																										case 86:
																										case 123:
																											goto IL_06ca;
																										case 0:
																											goto IL_06d5;
																										case 114:
																											goto IL_06e0;
																										case 99:
																											goto IL_06f6;
																										case 21:
																										case 44:
																											goto IL_0701;
																										case 25:
																											goto IL_070c;
																										case 19:
																										case 96:
																											goto IL_0717;
																										case 6:
																										case 8:
																										case 9:
																										case 10:
																										case 18:
																										case 30:
																										case 46:
																										case 48:
																										case 58:
																										case 62:
																										case 70:
																										case 72:
																										case 79:
																										case 82:
																										case 85:
																										case 88:
																										case 90:
																										case 105:
																										case 109:
																										case 117:
																										case 126:
																											goto end_IL_02a6;
																										case 34:
																										case 71:
																											goto IL_073c;
																										case 20:
																										case 27:
																										case 33:
																										case 50:
																										case 55:
																										case 60:
																										case 64:
																										case 67:
																										case 68:
																										case 69:
																										case 81:
																										case 87:
																										case 112:
																										case 118:
																										case 122:
																										case 128:
																											goto IL_0753;
																										case 56:
																											goto IL_0766;
																										case 32:
																											goto IL_0770;
																										case 16:
																											goto IL_077b;
																										case 121:
																											goto IL_0790;
																										case 26:
																										case 52:
																											goto IL_07a0;
																										case 29:
																											goto IL_07b0;
																										case 91:
																										case 104:
																											goto end_IL_022b;
																										case 110:
																											goto end_IL_07c0;
																										case 111:
																											goto end_IL_07d0;
																										case 92:
																										case 108:
																											goto IL_07f4;
																										}
																										continue;
																									}
																									array[num5 - 2] = 0;
																									goto IL_053a;
																									IL_053a:
																									num5--;
																									goto IL_0753;
																									continue;
																									end_IL_022b:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02ec;
																						IL_0513:
																						num5--;
																						goto IL_0753;
																						IL_02ec:
																						if (3 < b)
																						{
																							goto IL_02fa;
																						}
																						goto IL_042e;
																						IL_02fa:
																						if (5 < b)
																						{
																							goto IL_0308;
																						}
																						goto IL_038b;
																						IL_0308:
																						if (6 < b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_0316;
																						IL_0316:
																						if (6 > b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_0324;
																						IL_0324:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0364;
																						IL_0364:
																						array[num5 - 2] = 0;
																						goto IL_0378;
																						IL_0378:
																						num5--;
																						goto IL_0753;
																						IL_038b:
																						if (5 <= b)
																						{
																							goto IL_0396;
																						}
																						goto IL_0404;
																						IL_0396:
																						array[num5] = 0;
																						goto IL_03a4;
																						IL_03a4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						num = 57;
																						goto IL_03d0;
																						IL_03d0:
																						array2[num5] = null;
																						goto IL_03da;
																						IL_03da:
																						num5++;
																						goto IL_03e8;
																						IL_03e8:
																						ptr2 += 8;
																						num = 60;
																						goto IL_0753;
																						IL_0404:
																						if (4 < b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_0412;
																						IL_0412:
																						if (4 > b)
																						{
																							goto end_IL_02a6;
																						}
																						num = 68;
																						goto IL_0753;
																						IL_04c4:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_0753;
																						IL_042e:
																						if (3 > b)
																						{
																							goto IL_043c;
																						}
																						goto IL_04c4;
																						IL_043c:
																						if (1 >= b)
																						{
																							goto IL_0447;
																						}
																						goto IL_04a6;
																						IL_0447:
																						if (1 > b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_0455;
																						IL_0455:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_046e;
																						IL_046e:
																						array[num5] = 0;
																						goto IL_047c;
																						IL_047c:
																						num5++;
																						goto IL_048a;
																						IL_048a:
																						ptr2 += 8;
																						num = 27;
																						goto IL_0753;
																						IL_04a6:
																						if (2 < b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_04b4;
																						IL_04b4:
																						if (2 > b)
																						{
																							goto end_IL_02a6;
																						}
																						goto IL_04dc;
																						IL_04dc:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0505;
																						IL_0505:
																						ptr2 += 8;
																						goto IL_0513;
																					}
																					break;
																				}
																				goto IL_054d;
																				IL_070c:
																				if (11 > b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_0717;
																				IL_054d:
																				if (10 >= b)
																				{
																					goto IL_055b;
																				}
																				num = 123;
																				goto IL_06ca;
																				IL_055b:
																				if (10 > b)
																				{
																					goto IL_0569;
																				}
																				goto IL_0665;
																				IL_0569:
																				if (8 >= b)
																				{
																					goto IL_0574;
																				}
																				goto IL_05d4;
																				IL_0574:
																				if (8 > b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_0582;
																				IL_0582:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05a5;
																				IL_05a5:
																				array[num5] = 0;
																				goto IL_05b3;
																				IL_05b3:
																				num5++;
																				goto IL_05c1;
																				IL_05c1:
																				ptr2 += 8;
																				goto IL_0753;
																				IL_05d4:
																				if (9 < b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_05e2;
																				IL_05e2:
																				if (9 > b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_05f0;
																				IL_05f0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0652;
																				IL_0652:
																				num5 -= 2;
																				goto IL_0753;
																				IL_0665:
																				array[num5] = 0;
																				goto IL_0673;
																				IL_0673:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)ParallelJoincPropertiesToSet[*(int*)(ptr2 + num3)])();
																				num = 53;
																				goto IL_06a0;
																				IL_06a0:
																				num5++;
																				goto IL_06ae;
																				IL_06ae:
																				ptr2 += 8;
																				goto IL_0753;
																				IL_0717:
																				num5--;
																				goto IL_0753;
																				IL_06ca:
																				if (12 < b)
																				{
																					goto IL_06d5;
																				}
																				num = 99;
																				goto IL_06f6;
																				IL_06d5:
																				if (13 < b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_06e0;
																				IL_06e0:
																				if (13 > b)
																				{
																				}
																				goto end_IL_02a6;
																				IL_073c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_0753;
																				IL_06f6:
																				if (12 > b)
																				{
																					goto IL_0701;
																				}
																				goto IL_073c;
																				IL_0701:
																				if (11 < b)
																				{
																					goto end_IL_02a6;
																				}
																				goto IL_070c;
																			}
																			goto end_IL_02b3;
																		}
																		num = 18;
																		break;
																		continue;
																		end_IL_02a6:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0753;
																continue;
																end_IL_02b3:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												num = 92;
												goto IL_07f4;
												IL_07f4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_07c0:
					break;
				}
				continue;
				end_IL_07d0:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NameSpaceExtractorTrailingNewLine.IgnorePortablePDBsInStackTracesTargetException);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 29;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0304:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02e4:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02d4:
																						if (12 < b)
																						{
																							while (true)
																							{
																								IL_02c7:
																								if (14 >= b)
																								{
																									while (true)
																									{
																										IL_02b7:
																										if (14 > b)
																										{
																											while (13 >= b)
																											{
																												while (13 <= b)
																												{
																													num = 153;
																													while (true)
																													{
																														if (num != 153)
																														{
																															if (num != 1134)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 7:
																																goto IL_0294;
																															case 89:
																															case 116:
																																goto IL_02a7;
																															case 66:
																																goto IL_02b7;
																															case 97:
																															case 126:
																																goto IL_02c7;
																															case 16:
																															case 18:
																																goto IL_02d4;
																															case 53:
																																goto IL_02e4;
																															case 128:
																																goto IL_02f4;
																															case 55:
																																goto IL_0304;
																															case 41:
																																goto end_IL_0304;
																															case 12:
																															case 62:
																																goto end_IL_0314;
																															case 132:
																															case 142:
																																goto IL_032f;
																															case 73:
																																goto IL_033d;
																															case 136:
																																goto IL_0350;
																															case 59:
																																goto IL_03bb;
																															case 68:
																															case 71:
																																goto IL_03ce;
																															case 106:
																																goto IL_03f3;
																															case 38:
																																goto IL_0401;
																															case 98:
																																goto IL_040f;
																															case 40:
																																goto IL_041a;
																															case 45:
																																goto IL_0428;
																															case 2:
																															case 13:
																																goto IL_0444;
																															case 102:
																																goto IL_0452;
																															case 60:
																																goto IL_0475;
																															case 107:
																																goto IL_047f;
																															case 131:
																																goto IL_048d;
																															case 0:
																																goto IL_04a0;
																															case 47:
																																goto IL_04ae;
																															case 48:
																															case 103:
																																goto IL_04bc;
																															case 4:
																																goto IL_0500;
																															case 50:
																																goto IL_0514;
																															case 9:
																															case 83:
																																goto IL_0527;
																															case 121:
																																goto IL_0567;
																															case 51:
																																goto IL_0584;
																															case 56:
																																goto IL_0597;
																															case 80:
																															case 95:
																																goto IL_05a5;
																															case 36:
																																goto IL_05b3;
																															case 8:
																																goto IL_05be;
																															case 124:
																																goto IL_05cc;
																															case 44:
																															case 110:
																																goto IL_05da;
																															case 33:
																																goto IL_0603;
																															case 20:
																																goto IL_0611;
																															case 108:
																																goto IL_062d;
																															case 19:
																															case 37:
																																goto IL_0638;
																															case 35:
																																goto IL_0646;
																															case 75:
																															case 90:
																																goto IL_0654;
																															case 76:
																																goto IL_0662;
																															case 28:
																																goto IL_067a;
																															case 101:
																																goto IL_0688;
																															case 31:
																															case 105:
																																goto end_IL_0281;
																															case 54:
																																goto IL_06da;
																															case 139:
																																goto IL_06f6;
																															case 65:
																															case 74:
																																goto IL_0701;
																															case 127:
																																goto IL_071f;
																															case 58:
																																goto IL_072d;
																															case 22:
																																goto IL_0740;
																															case 94:
																																goto IL_074e;
																															case 72:
																															case 78:
																																goto IL_0759;
																															case 91:
																																goto IL_0799;
																															case 123:
																																goto IL_07ad;
																															case 61:
																															case 145:
																																goto IL_07c9;
																															case 81:
																																goto IL_07d7;
																															case 67:
																															case 92:
																																goto IL_07e5;
																															case 57:
																																goto IL_07fe;
																															case 63:
																																goto IL_080c;
																															case 49:
																																goto IL_081a;
																															case 43:
																																goto IL_082a;
																															case 114:
																																goto IL_0835;
																															case 26:
																															case 141:
																																goto IL_0840;
																															case 79:
																																goto IL_0869;
																															case 10:
																															case 70:
																																goto IL_087f;
																															case 3:
																															case 6:
																															case 11:
																															case 14:
																															case 15:
																															case 17:
																															case 25:
																															case 27:
																															case 32:
																															case 34:
																															case 39:
																															case 69:
																															case 88:
																															case 99:
																															case 109:
																															case 111:
																															case 112:
																															case 113:
																															case 115:
																															case 119:
																															case 125:
																															case 130:
																															case 134:
																															case 135:
																															case 140:
																															case 146:
																																goto end_IL_0294;
																															case 5:
																															case 24:
																															case 29:
																															case 30:
																															case 42:
																															case 46:
																															case 64:
																															case 77:
																															case 82:
																															case 84:
																															case 87:
																															case 100:
																															case 104:
																															case 117:
																															case 120:
																															case 138:
																															case 143:
																																goto end_IL_0324;
																															case 118:
																																goto end_IL_08a7;
																															case 1:
																																goto end_IL_08ba;
																															case 93:
																																goto end_IL_08c5;
																															case 23:
																																goto end_IL_08cf;
																															case 137:
																																goto end_IL_08da;
																															case 52:
																															case 122:
																																goto end_IL_08ea;
																															case 133:
																																goto end_IL_08fa;
																															case 21:
																															case 144:
																																goto end_IL_090a;
																															case 85:
																																goto end_IL_091a;
																															case 86:
																																goto end_IL_092a;
																															case 96:
																															case 129:
																																goto IL_0945;
																															}
																															continue;
																														}
																														goto IL_0350;
																														IL_0350:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														num = 59;
																														goto IL_03bb;
																														IL_03bb:
																														num5 -= 2;
																														goto end_IL_0324;
																														continue;
																														end_IL_0281:
																														break;
																													}
																													goto IL_069b;
																													continue;
																													end_IL_0294:
																													break;
																													IL_0294:;
																												}
																												break;
																												IL_02a7:;
																											}
																											break;
																										}
																										goto IL_03ce;
																										IL_03ce:
																										byte* num6 = ptr2;
																										num4 = 1;
																										ptr2 = num6 + -200;
																										num = 100;
																										goto end_IL_0324;
																									}
																									break;
																								}
																								goto IL_032f;
																								IL_033d:
																								if (15 > b)
																								{
																								}
																								break;
																								IL_032f:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_033d;
																							}
																							break;
																						}
																						goto IL_03f3;
																						IL_0567:
																						array[num5 - 2] = 0;
																						num = 51;
																						goto IL_0584;
																						IL_03f3:
																						if (12 > b)
																						{
																							goto IL_0401;
																						}
																						goto IL_0527;
																						IL_0401:
																						if (10 >= b)
																						{
																							goto IL_040f;
																						}
																						goto IL_04a0;
																						IL_040f:
																						if (10 > b)
																						{
																							goto IL_041a;
																						}
																						num = 13;
																						goto IL_0444;
																						IL_041a:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0428;
																						IL_0428:
																						if (9 > b)
																						{
																							break;
																						}
																						goto end_IL_0324;
																						IL_0584:
																						num5--;
																						goto end_IL_0324;
																						IL_0444:
																						array[num5] = 0;
																						goto IL_0452;
																						IL_0452:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0475;
																						IL_0475:
																						array2[num5] = null;
																						goto IL_047f;
																						IL_047f:
																						num5++;
																						goto IL_048d;
																						IL_048d:
																						ptr2 += 8;
																						goto end_IL_0324;
																						IL_04a0:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_04ae;
																						IL_04ae:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_04bc;
																						IL_04bc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0500;
																						IL_0500:
																						array[num5 - 2] = 0;
																						goto IL_0514;
																						IL_0514:
																						num5--;
																						goto end_IL_0324;
																						IL_0527:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0567;
																					}
																					break;
																				}
																				goto IL_0597;
																				IL_0835:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0840;
																				IL_0597:
																				if (8 > b)
																				{
																					goto IL_05a5;
																				}
																				goto IL_087f;
																				IL_05a5:
																				if (4 < b)
																				{
																					goto IL_05b3;
																				}
																				num = 139;
																				goto IL_06f6;
																				IL_05b3:
																				if (6 < b)
																				{
																					goto IL_05be;
																				}
																				num = 108;
																				goto IL_062d;
																				IL_05be:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_05cc;
																				IL_05cc:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05da;
																				IL_05da:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0603;
																				IL_0603:
																				ptr2 += 8;
																				goto IL_0611;
																				IL_0611:
																				num5--;
																				goto end_IL_0324;
																				IL_0869:
																				array[num5 - 1] = 5;
																				goto end_IL_0324;
																				IL_062d:
																				if (6 > b)
																				{
																					goto IL_0638;
																				}
																				goto IL_069b;
																				IL_0638:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0646;
																				IL_0646:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0654;
																				IL_0654:
																				array[num5] = 5;
																				goto IL_0662;
																				IL_0662:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_067a;
																				IL_067a:
																				num5++;
																				goto IL_0688;
																				IL_0688:
																				ptr2 += 8;
																				goto end_IL_0324;
																				IL_069b:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06da;
																				IL_06da:
																				num5 -= 3;
																				goto end_IL_0324;
																				IL_0840:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0869;
																				IL_06f6:
																				if (4 <= b)
																				{
																					goto IL_0701;
																				}
																				goto IL_0740;
																				IL_0701:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_071f;
																				IL_071f:
																				ptr2 += 8;
																				goto IL_072d;
																				IL_072d:
																				num5--;
																				goto end_IL_0324;
																				IL_0740:
																				if (2 >= b)
																				{
																					goto IL_074e;
																				}
																				goto IL_082a;
																				IL_074e:
																				if (2 <= b)
																				{
																					goto IL_0759;
																				}
																				num = 145;
																				goto IL_07c9;
																				IL_0759:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0799;
																				IL_0799:
																				array[num5 - 2] = 0;
																				goto IL_07ad;
																				IL_07ad:
																				num5--;
																				goto end_IL_0324;
																				IL_087f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0324;
																				IL_07c9:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_07d7;
																				IL_07d7:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_07e5;
																				IL_07e5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_07fe;
																				IL_07fe:
																				array[num5] = 0;
																				goto IL_080c;
																				IL_080c:
																				num5++;
																				goto IL_081a;
																				IL_081a:
																				ptr2 += 8;
																				goto end_IL_0324;
																				IL_082a:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0835;
																			}
																			break;
																			IL_02f4:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0324;
																	continue;
																	end_IL_0304:
																	break;
																}
																continue;
																end_IL_0314:
																break;
															}
															continue;
															end_IL_0324:
															break;
														}
														continue;
													}
													goto IL_0945;
													IL_0945:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a7:
													break;
												}
												continue;
												end_IL_08ba:
												break;
											}
											continue;
											end_IL_08c5:
											break;
										}
										continue;
										end_IL_08cf:
										break;
									}
									continue;
									end_IL_08da:
									break;
								}
								continue;
								end_IL_08ea:
								break;
							}
							continue;
							end_IL_08fa:
							break;
						}
						continue;
						end_IL_090a:
						break;
					}
					continue;
					end_IL_091a:
					break;
				}
				continue;
				end_IL_092a:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 147;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAllInternalsVisibleCanSeek.EnumCategoryInstancesFlagsConsole);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f8:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02e8:
																		if (b > 17)
																		{
																			num = 174;
																			while (num != 174 && num == 1155)
																			{
																				switch (num)
																				{
																				case 155:
																					goto IL_02e8;
																				case 71:
																					goto IL_02f8;
																				case 58:
																					goto end_IL_02f8;
																				case 59:
																				case 86:
																					goto end_IL_0308;
																				case 43:
																					goto IL_0323;
																				case 9:
																					goto IL_032e;
																				case 52:
																					goto IL_033c;
																				case 110:
																				case 133:
																					goto IL_034f;
																				case 18:
																					goto IL_035d;
																				case 19:
																				case 74:
																					goto IL_036b;
																				case 95:
																					goto IL_03cd;
																				case 100:
																					goto IL_03e0;
																				case 24:
																				case 79:
																					goto IL_03eb;
																				case 45:
																					goto IL_03f9;
																				case 44:
																				case 113:
																					goto IL_0407;
																				case 63:
																					goto IL_0423;
																				case 88:
																				case 99:
																					goto IL_042e;
																				case 60:
																				case 104:
																					goto IL_044a;
																				case 41:
																					goto IL_0458;
																				case 36:
																				case 124:
																					goto IL_0466;
																				case 120:
																					goto IL_047a;
																				case 116:
																					goto IL_04b9;
																				case 142:
																					goto IL_04cc;
																				case 26:
																					goto IL_04da;
																				case 10:
																				case 39:
																					goto IL_04e5;
																				case 8:
																					goto IL_0529;
																				case 37:
																					goto IL_053d;
																				case 62:
																					goto IL_0550;
																				case 50:
																					goto IL_0563;
																				case 42:
																					goto IL_0571;
																				case 0:
																				case 82:
																					goto IL_057f;
																				case 107:
																					goto IL_05bf;
																				case 3:
																					goto IL_05d3;
																				case 75:
																				case 153:
																					goto IL_05e6;
																				case 29:
																				case 46:
																					goto IL_05f4;
																				case 61:
																					goto IL_05ff;
																				case 66:
																				case 80:
																					goto IL_060d;
																				case 20:
																					goto IL_0636;
																				case 143:
																					goto IL_0644;
																				case 101:
																					goto IL_0657;
																				case 11:
																					goto IL_0665;
																				case 112:
																				case 131:
																					goto IL_0673;
																				case 97:
																					goto IL_068b;
																				case 84:
																				case 127:
																					goto IL_0696;
																				case 31:
																					goto IL_06d5;
																				case 106:
																					goto IL_06e8;
																				case 93:
																					goto IL_06f6;
																				case 129:
																				case 130:
																					goto IL_0704;
																				case 121:
																					goto IL_0712;
																				case 73:
																					goto IL_072a;
																				case 105:
																					goto IL_0738;
																				case 157:
																					goto IL_074b;
																				case 22:
																				case 148:
																					goto IL_0759;
																				case 17:
																					goto IL_0767;
																				case 137:
																					goto IL_078a;
																				case 115:
																					goto IL_0794;
																				case 128:
																					goto IL_07a2;
																				case 158:
																					goto IL_07b5;
																				case 13:
																				case 56:
																					goto IL_07c0;
																				case 53:
																					goto IL_07de;
																				case 70:
																					goto IL_07f5;
																				case 35:
																					goto IL_0808;
																				case 27:
																				case 145:
																					goto IL_0813;
																				case 96:
																					goto IL_0821;
																				case 94:
																				case 132:
																					goto IL_082f;
																				case 87:
																					goto IL_0858;
																				case 54:
																					goto IL_0871;
																				case 4:
																				case 32:
																					goto IL_087c;
																				case 6:
																					goto IL_08bc;
																				case 57:
																					goto IL_08d0;
																				case 77:
																				case 90:
																					goto IL_08ec;
																				case 30:
																					goto IL_08f7;
																				case 72:
																				case 111:
																					goto IL_0902;
																				case 65:
																					goto IL_091b;
																				case 144:
																					goto IL_0929;
																				case 16:
																					goto IL_0937;
																				case 149:
																				case 159:
																					goto IL_0947;
																				case 23:
																					goto IL_0952;
																				case 2:
																				case 12:
																				case 15:
																				case 21:
																				case 25:
																				case 33:
																				case 34:
																				case 38:
																				case 40:
																				case 47:
																				case 64:
																				case 83:
																				case 85:
																				case 92:
																				case 98:
																				case 102:
																				case 103:
																				case 109:
																				case 114:
																				case 118:
																				case 123:
																				case 134:
																				case 136:
																				case 138:
																				case 139:
																				case 140:
																				case 150:
																				case 152:
																				case 154:
																				case 156:
																				case 160:
																				case 163:
																				case 164:
																					goto end_IL_02d5;
																				case 5:
																				case 7:
																				case 14:
																				case 49:
																				case 55:
																				case 68:
																				case 69:
																				case 76:
																				case 78:
																				case 89:
																				case 91:
																				case 119:
																				case 122:
																				case 125:
																				case 126:
																				case 151:
																				case 161:
																				case 162:
																				case 165:
																				case 166:
																					goto end_IL_0318;
																				case 117:
																					goto end_IL_0970;
																				case 135:
																					goto end_IL_0983;
																				case 1:
																					goto end_IL_098d;
																				case 51:
																					goto end_IL_0998;
																				case 67:
																				case 141:
																					goto end_IL_09a8;
																				case 81:
																					goto end_IL_09b8;
																				case 28:
																				case 108:
																					goto end_IL_09c8;
																				case 146:
																					goto end_IL_09d8;
																				case 147:
																					goto end_IL_09e8;
																				case 48:
																				case 167:
																					goto IL_0a03;
																				}
																				continue;
																				end_IL_02d5:
																				break;
																			}
																			break;
																		}
																		goto IL_0323;
																		IL_0458:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_0466;
																		IL_0466:
																		array[num5 - 1] = 0;
																		goto IL_047a;
																		IL_0323:
																		if (9 >= b)
																		{
																			goto IL_032e;
																		}
																		goto IL_034f;
																		IL_032e:
																		if (9 <= b)
																		{
																			goto end_IL_0318;
																		}
																		goto IL_033c;
																		IL_033c:
																		if (4 < b)
																		{
																			goto IL_05e6;
																		}
																		goto IL_07b5;
																		IL_05e6:
																		if (6 < b)
																		{
																			goto IL_05f4;
																		}
																		goto IL_068b;
																		IL_05f4:
																		if (7 >= b)
																		{
																			goto IL_05ff;
																		}
																		goto IL_0657;
																		IL_05ff:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_060d;
																		IL_060d:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0636;
																		IL_0636:
																		ptr2 += 8;
																		goto IL_0644;
																		IL_0644:
																		num5--;
																		goto end_IL_0318;
																		IL_0657:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0665;
																		IL_0665:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0673;
																		IL_0673:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_0318;
																		IL_068b:
																		if (6 <= b)
																		{
																			goto IL_0696;
																		}
																		goto IL_06e8;
																		IL_0696:
																		((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_06d5;
																		IL_06d5:
																		num5 -= 3;
																		goto end_IL_0318;
																		IL_06e8:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_06f6;
																		IL_06f6:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_0704;
																		IL_0704:
																		array[num5] = 5;
																		goto IL_0712;
																		IL_0712:
																		array2[num5] = array5[*(int*)(ptr2 + num3)];
																		goto IL_072a;
																		IL_072a:
																		num5++;
																		goto IL_0738;
																		IL_0738:
																		ptr2 += 8;
																		goto end_IL_0318;
																		IL_07b5:
																		if (4 <= b)
																		{
																			goto IL_07c0;
																		}
																		goto IL_0808;
																		IL_07c0:
																		array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																		goto IL_07de;
																		IL_07de:
																		ptr2 += 8;
																		num = 70;
																		goto IL_07f5;
																		IL_07f5:
																		num5--;
																		goto end_IL_0318;
																		IL_0808:
																		if (2 < b)
																		{
																			goto IL_0813;
																		}
																		goto IL_0871;
																		IL_0813:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_0821;
																		IL_0821:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_082f;
																		IL_082f:
																		array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																		goto IL_0858;
																		IL_0858:
																		array[num5 - 1] = 5;
																		goto end_IL_0318;
																		IL_0871:
																		if (2 <= b)
																		{
																			goto IL_087c;
																		}
																		num = 77;
																		goto IL_08ec;
																		IL_087c:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_08bc;
																		IL_08bc:
																		array[num5 - 2] = 0;
																		goto IL_08d0;
																		IL_08d0:
																		num5--;
																		goto end_IL_0318;
																		IL_047a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ResolveTypeSingleProducerSingleConsumerQueue[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																		goto IL_04b9;
																		IL_08ec:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_08f7;
																		IL_08f7:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0902;
																		IL_0902:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_091b;
																		IL_091b:
																		array[num5] = 0;
																		goto IL_0929;
																		IL_0929:
																		num5++;
																		goto IL_0937;
																		IL_0937:
																		ptr2 += 8;
																		goto end_IL_0318;
																		IL_034f:
																		if (13 >= b)
																		{
																			goto IL_035d;
																		}
																		goto IL_03e0;
																		IL_035d:
																		if (13 <= b)
																		{
																			goto IL_036b;
																		}
																		goto IL_04cc;
																		IL_036b:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_03cd;
																		IL_03cd:
																		num5 -= 2;
																		goto end_IL_0318;
																		IL_04cc:
																		if (11 >= b)
																		{
																			goto IL_04da;
																		}
																		goto IL_0563;
																		IL_04da:
																		if (11 <= b)
																		{
																			goto IL_04e5;
																		}
																		goto IL_0550;
																		IL_04e5:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																		goto IL_0529;
																		IL_0529:
																		array[num5 - 2] = 0;
																		goto IL_053d;
																		IL_053d:
																		num5--;
																		goto end_IL_0318;
																		IL_0550:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_074b;
																		IL_074b:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_0759;
																		IL_0759:
																		array[num5] = 0;
																		goto IL_0767;
																		IL_0767:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_078a;
																		IL_078a:
																		array2[num5] = null;
																		goto IL_0794;
																		IL_0794:
																		num5++;
																		goto IL_07a2;
																		IL_07a2:
																		ptr2 += 8;
																		goto end_IL_0318;
																		IL_0563:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_0571;
																		IL_0571:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_057f;
																		IL_057f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05bf;
																		IL_05bf:
																		array[num5 - 2] = 0;
																		goto IL_05d3;
																		IL_05d3:
																		num5--;
																		goto end_IL_0318;
																		IL_03e0:
																		if (15 < b)
																		{
																			goto IL_03eb;
																		}
																		goto IL_0423;
																		IL_03eb:
																		if (16 >= b)
																		{
																			goto IL_03f9;
																		}
																		goto IL_0947;
																		IL_03f9:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_0407;
																		IL_0407:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_0318;
																		IL_0947:
																		if (17 < b)
																		{
																			break;
																		}
																		goto IL_0952;
																		IL_0952:
																		if (17 > b)
																		{
																		}
																		break;
																		IL_0423:
																		if (15 <= b)
																		{
																			goto IL_042e;
																		}
																		num = 104;
																		goto IL_044a;
																		IL_042e:
																		num5--;
																		goto end_IL_0318;
																		IL_04b9:
																		ptr2 += 8;
																		goto end_IL_0318;
																		IL_044a:
																		if (14 < b)
																		{
																			break;
																		}
																		goto IL_0458;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0318;
																continue;
																end_IL_02f8:
																break;
															}
															continue;
															end_IL_0308:
															break;
														}
														continue;
														end_IL_0318:
														break;
													}
													continue;
												}
												goto IL_0a03;
												IL_0a03:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0970:
												break;
											}
											continue;
											end_IL_0983:
											break;
										}
										continue;
										end_IL_098d:
										break;
									}
									continue;
									end_IL_0998:
									break;
								}
								continue;
								end_IL_09a8:
								break;
							}
							continue;
							end_IL_09b8:
							break;
						}
						continue;
						end_IL_09c8:
						break;
					}
					continue;
					end_IL_09d8:
					break;
				}
				continue;
				end_IL_09e8:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 17;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MissingMethodExceptiongetIsSecurityTransparent.CleanupWorkListgetInformationalVersion);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 80;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0224:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0207:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_01f4:
																							if (7 >= b)
																							{
																								num = 113;
																								while (true)
																								{
																									if (num != 113)
																									{
																										if (num != 1094)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 76:
																											goto IL_01f4;
																										case 99:
																											goto IL_0207;
																										case 91:
																											goto IL_0214;
																										case 67:
																											goto IL_0224;
																										case 103:
																											goto end_IL_0224;
																										case 1:
																										case 41:
																											goto end_IL_0234;
																										case 10:
																											goto IL_024f;
																										case 7:
																										case 33:
																											goto IL_0263;
																										case 3:
																										case 40:
																											goto IL_0273;
																										case 18:
																											goto IL_0281;
																										case 65:
																											goto IL_02a9;
																										case 29:
																											goto IL_02b4;
																										case 26:
																											goto IL_02c2;
																										case 22:
																										case 72:
																											goto IL_02d5;
																										case 23:
																											goto IL_0315;
																										case 68:
																											goto IL_0329;
																										case 94:
																											goto IL_0345;
																										case 39:
																											goto IL_034f;
																										case 34:
																											goto IL_035d;
																										case 63:
																										case 105:
																											goto IL_0370;
																										case 64:
																											goto IL_037b;
																										case 53:
																										case 74:
																											goto IL_0389;
																										case 15:
																											goto IL_03b2;
																										case 96:
																											goto IL_03c0;
																										case 14:
																										case 98:
																											goto IL_03d3;
																										case 100:
																											goto IL_03e1;
																										case 32:
																										case 81:
																											goto IL_03ef;
																										case 62:
																											goto IL_042f;
																										case 45:
																											goto IL_0443;
																										case 0:
																										case 38:
																											goto IL_046d;
																										case 19:
																											goto IL_047b;
																										case 27:
																										case 56:
																											goto IL_0494;
																										case 28:
																											goto IL_04d4;
																										case 70:
																											goto IL_04e8;
																										case 35:
																										case 89:
																											goto IL_04fb;
																										case 12:
																											goto IL_0514;
																										case 21:
																											goto IL_0522;
																										case 95:
																											goto IL_0530;
																										case 43:
																											goto IL_0543;
																										case 48:
																										case 75:
																											goto IL_054e;
																										case 11:
																											goto IL_055c;
																										case 83:
																										case 87:
																											goto IL_056a;
																										case 31:
																											goto IL_0586;
																										case 5:
																										case 6:
																											goto IL_0591;
																										case 106:
																											goto IL_05d1;
																										case 79:
																											goto IL_05e5;
																										case 8:
																										case 30:
																										case 44:
																										case 49:
																										case 51:
																										case 52:
																										case 54:
																										case 58:
																										case 60:
																										case 66:
																										case 69:
																										case 73:
																										case 77:
																										case 84:
																										case 86:
																										case 93:
																										case 97:
																										case 101:
																										case 104:
																											goto end_IL_01e1;
																										case 13:
																											goto IL_0618;
																										case 61:
																											goto IL_062f;
																										case 78:
																											goto IL_063d;
																										case 2:
																										case 4:
																										case 9:
																										case 20:
																										case 36:
																										case 42:
																										case 57:
																										case 80:
																										case 82:
																										case 88:
																										case 90:
																											goto end_IL_0244;
																										case 25:
																											goto end_IL_064b;
																										case 59:
																											goto end_IL_065e;
																										case 24:
																											goto end_IL_0671;
																										case 50:
																											goto end_IL_067c;
																										case 92:
																											goto end_IL_0691;
																										case 16:
																										case 37:
																											goto end_IL_06a6;
																										case 55:
																											goto end_IL_06b6;
																										case 17:
																											goto end_IL_06c6;
																										case 85:
																											goto end_IL_06d6;
																										case 46:
																											goto end_IL_06e6;
																										case 47:
																											goto end_IL_06f1;
																										case 71:
																										case 102:
																											goto IL_070c;
																										}
																										continue;
																									}
																									if (7 > b)
																									{
																										goto IL_046d;
																									}
																									goto IL_04fb;
																									IL_04fb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0514;
																									IL_0522:
																									num5++;
																									goto IL_0530;
																									IL_0514:
																									array[num5] = 0;
																									goto IL_0522;
																									IL_046d:
																									if (6 < b)
																									{
																										break;
																									}
																									goto IL_047b;
																									IL_047b:
																									if (6 > b)
																									{
																										num = 97;
																										break;
																									}
																									goto IL_0494;
																									IL_0530:
																									ptr2 += 8;
																									goto end_IL_0244;
																									IL_0494:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04d4;
																									IL_04d4:
																									array[num5 - 2] = 0;
																									goto IL_04e8;
																									IL_04e8:
																									num5--;
																									goto end_IL_0244;
																									continue;
																									end_IL_01e1:
																									break;
																								}
																								break;
																							}
																							goto IL_0543;
																							IL_05d1:
																							array[num5 - 2] = 0;
																							goto IL_05e5;
																							IL_05e5:
																							num5--;
																							goto end_IL_0244;
																							IL_0543:
																							if (8 < b)
																							{
																								goto IL_054e;
																							}
																							goto IL_0586;
																							IL_054e:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_055c;
																							IL_055c:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_056a;
																							IL_056a:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0244;
																							IL_0586:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_0591;
																							IL_0591:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05d1;
																						}
																						break;
																					}
																					goto IL_024f;
																					IL_034f:
																					num5++;
																					goto IL_035d;
																					IL_024f:
																					if (5 > b)
																					{
																						num = 33;
																						goto IL_0263;
																					}
																					goto IL_0273;
																					IL_035d:
																					ptr2 += 8;
																					goto end_IL_0244;
																					IL_0263:
																					if (2 >= b)
																					{
																						goto IL_02a9;
																					}
																					goto IL_0370;
																					IL_0370:
																					if (3 >= b)
																					{
																						goto IL_037b;
																					}
																					goto IL_03d3;
																					IL_037b:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0389;
																					IL_0389:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03b2;
																					IL_03b2:
																					ptr2 += 8;
																					goto IL_03c0;
																					IL_03c0:
																					num5--;
																					goto end_IL_0244;
																					IL_03d3:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_03e1;
																					IL_03e1:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_03ef;
																					IL_03ef:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_042f;
																					IL_042f:
																					array[num5 - 2] = 0;
																					goto IL_0443;
																					IL_0443:
																					num5--;
																					num = 82;
																					goto end_IL_0244;
																					IL_02a9:
																					if (2 > b)
																					{
																						goto IL_02b4;
																					}
																					goto IL_02d5;
																					IL_02b4:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_02c2;
																					IL_02c2:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_02d5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0315;
																					IL_0315:
																					array[num5 - 2] = 0;
																					goto IL_0329;
																					IL_0329:
																					num5--;
																					num = 42;
																					goto end_IL_0244;
																					IL_0273:
																					array[num5] = 0;
																					goto IL_0281;
																					IL_0281:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0345;
																					IL_0345:
																					array2[num5] = null;
																					goto IL_034f;
																				}
																				break;
																				IL_0214:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0618;
																		IL_063d:
																		ptr2 += 8;
																		goto end_IL_0244;
																		IL_062f:
																		num5++;
																		goto IL_063d;
																		IL_0618:
																		array[num5] = 0;
																		num = 61;
																		goto IL_062f;
																		continue;
																		end_IL_0224:
																		break;
																	}
																	continue;
																	end_IL_0234:
																	break;
																}
																continue;
																end_IL_0244:
																break;
															}
															continue;
														}
														goto IL_070c;
														IL_070c:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_064b:
														break;
													}
													continue;
													end_IL_065e:
													break;
												}
												continue;
												end_IL_0671:
												break;
											}
											continue;
											end_IL_067c:
											break;
										}
										continue;
										end_IL_0691:
										break;
									}
									continue;
									end_IL_06a6:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06d6:
						break;
					}
					continue;
					end_IL_06e6:
					break;
				}
				continue;
				end_IL_06f1:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3)
	{
		int num = 12;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 50;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UniversalTimesetRenewalTime.ThreadStateParallelLoopBegin);
											num = 7;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0274:
															num = 70;
															while (true)
															{
																IL_0269:
																byte b = *ptr2;
																while (true)
																{
																	IL_0259:
																	ptr2++;
																	while (true)
																	{
																		IL_0249:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_0229:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_021c:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_020c:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_01fc:
																											if (3 >= b)
																											{
																												while (3 <= b)
																												{
																													while (true)
																													{
																														IL_01ce:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														num = 107;
																														while (num != 107 && num == 1088)
																														{
																															switch (num)
																															{
																															case 61:
																															case 68:
																																goto IL_01ce;
																															case 24:
																																goto IL_01ec;
																															case 37:
																																goto IL_01fc;
																															case 81:
																																goto IL_020c;
																															case 72:
																																goto IL_021c;
																															case 91:
																																goto IL_0229;
																															case 35:
																																goto IL_0239;
																															case 85:
																																goto IL_0249;
																															case 63:
																																goto IL_0259;
																															case 70:
																																goto IL_0269;
																															case 42:
																																goto IL_0274;
																															case 29:
																															case 59:
																																goto IL_027f;
																															case 90:
																																goto IL_0296;
																															case 5:
																																goto IL_02b9;
																															case 76:
																																goto IL_02c3;
																															case 23:
																																goto IL_02d1;
																															case 38:
																															case 97:
																																goto IL_02e4;
																															case 60:
																																goto IL_02f2;
																															case 39:
																																goto IL_030e;
																															case 41:
																															case 46:
																																goto IL_0322;
																															case 44:
																																goto IL_034b;
																															case 55:
																																goto IL_0359;
																															case 74:
																																goto IL_036c;
																															case 79:
																																goto IL_0383;
																															case 33:
																															case 51:
																																goto IL_038e;
																															case 30:
																																goto IL_03a7;
																															case 84:
																																goto IL_03b5;
																															case 10:
																																goto IL_03c3;
																															case 64:
																															case 94:
																																goto IL_03ed;
																															case 25:
																																goto IL_03fb;
																															case 52:
																																goto IL_0409;
																															case 57:
																															case 96:
																																goto IL_0414;
																															case 8:
																																goto IL_0422;
																															case 36:
																															case 49:
																																goto IL_0430;
																															case 71:
																																goto IL_0453;
																															case 95:
																																goto IL_0461;
																															case 69:
																																goto IL_046f;
																															case 93:
																																goto IL_0482;
																															case 22:
																															case 78:
																																goto IL_0490;
																															case 21:
																																goto IL_04d0;
																															case 15:
																																goto IL_04e4;
																															case 19:
																															case 77:
																																goto IL_04f7;
																															case 34:
																																goto IL_0559;
																															case 83:
																																goto IL_0569;
																															case 31:
																															case 45:
																																goto IL_0574;
																															case 27:
																																goto IL_057f;
																															case 3:
																																goto IL_058c;
																															case 54:
																															case 58:
																																goto IL_0597;
																															case 0:
																															case 1:
																															case 9:
																															case 16:
																															case 18:
																															case 20:
																															case 26:
																															case 32:
																															case 53:
																															case 56:
																															case 62:
																															case 65:
																															case 82:
																															case 87:
																															case 88:
																															case 89:
																																goto end_IL_01ec;
																															case 2:
																															case 14:
																															case 28:
																															case 43:
																															case 47:
																															case 66:
																															case 67:
																															case 80:
																															case 86:
																															case 92:
																															case 98:
																															case 99:
																																goto end_IL_01bb;
																															case 7:
																																goto end_IL_05c3;
																															case 6:
																																goto end_IL_05d6;
																															case 75:
																																goto end_IL_05e0;
																															case 4:
																																goto end_IL_05f4;
																															case 17:
																															case 48:
																																goto end_IL_0609;
																															case 73:
																																goto end_IL_0619;
																															case 50:
																																goto end_IL_0629;
																															case 100:
																																goto end_IL_0639;
																															case 11:
																																goto end_IL_0649;
																															case 12:
																																goto end_IL_0654;
																															case 13:
																															case 40:
																																goto IL_066f;
																															}
																															continue;
																															end_IL_01bb:
																															break;
																														}
																														break;
																													}
																													goto end_IL_0249;
																													continue;
																													end_IL_01ec:
																													break;
																													IL_01ec:;
																												}
																												break;
																											}
																											goto IL_02e4;
																											IL_02f2:
																											if (4 <= b)
																											{
																												goto end_IL_0249;
																											}
																											break;
																											IL_02e4:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_02f2;
																										}
																										break;
																									}
																									num = 39;
																									goto IL_030e;
																									IL_038e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_03a7;
																									IL_03a7:
																									array[num5] = 0;
																									goto IL_03b5;
																									IL_030e:
																									if (2 <= b)
																									{
																										num = 41;
																										goto IL_0322;
																									}
																									goto IL_036c;
																									IL_03b5:
																									num5++;
																									goto IL_03c3;
																									IL_0322:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_034b;
																									IL_034b:
																									ptr2 += 8;
																									goto IL_0359;
																									IL_0359:
																									num5--;
																									goto end_IL_0249;
																									IL_036c:
																									if (1 < b)
																									{
																										break;
																									}
																									num = 79;
																									goto IL_0383;
																									IL_03c3:
																									ptr2 += 8;
																									num = 47;
																									goto end_IL_0249;
																									IL_0383:
																									if (1 > b)
																									{
																										num = 18;
																										break;
																									}
																									goto IL_038e;
																								}
																								break;
																							}
																							goto IL_027f;
																							IL_02d1:
																							ptr2 += 8;
																							goto end_IL_0249;
																							IL_027f:
																							array[num5] = 0;
																							num = 90;
																							goto IL_0296;
																							IL_0296:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_02b9;
																							IL_02b9:
																							array2[num5] = null;
																							goto IL_02c3;
																							IL_02c3:
																							num5++;
																							goto IL_02d1;
																						}
																						break;
																					}
																					goto IL_03ed;
																					IL_0597:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0249;
																					IL_03ed:
																					if (8 >= b)
																					{
																						goto IL_03fb;
																					}
																					goto IL_0569;
																					IL_03fb:
																					if (8 > b)
																					{
																						goto IL_0409;
																					}
																					goto IL_04f7;
																					IL_0409:
																					if (6 < b)
																					{
																						goto IL_0414;
																					}
																					goto IL_0482;
																					IL_0414:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0422;
																					IL_0422:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0430;
																					IL_0430:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0453;
																					IL_0453:
																					array[num5] = 0;
																					goto IL_0461;
																					IL_0461:
																					num5++;
																					goto IL_046f;
																					IL_046f:
																					ptr2 += 8;
																					goto end_IL_0249;
																					IL_0482:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0490;
																					IL_0490:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04d0;
																					IL_04d0:
																					array[num5 - 2] = 0;
																					goto IL_04e4;
																					IL_04e4:
																					num5--;
																					goto end_IL_0249;
																					IL_04f7:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0559;
																					IL_0559:
																					num5 -= 2;
																					goto end_IL_0249;
																					IL_0569:
																					if (9 < b)
																					{
																						goto IL_0574;
																					}
																					goto IL_058c;
																					IL_0574:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_057f;
																					IL_057f:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_058c:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0597;
																				}
																				break;
																				IL_0239:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0249:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_066f;
													IL_066f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05c3:
													break;
												}
												continue;
												end_IL_05d6:
												break;
											}
											continue;
											end_IL_05e0:
											break;
										}
										continue;
										end_IL_05f4:
										break;
									}
									continue;
									end_IL_0609:
									break;
								}
								continue;
								end_IL_0619:
								break;
							}
							continue;
							end_IL_0629:
							break;
						}
						continue;
						end_IL_0639:
						break;
					}
					continue;
					end_IL_0649:
					break;
				}
				continue;
				end_IL_0654:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 115;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetRaiseMethodPermissionSetEnumeratorInternal.DictionaryEnumeratorByKeysMembershipCondition);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 46;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03a0:
														byte b = *ptr2;
														while (true)
														{
															IL_0390:
															ptr2++;
															while (true)
															{
																IL_0380:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0363:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_0353:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_0343:
																							if (13 <= b)
																							{
																								while (true)
																								{
																									IL_02df:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									while (true)
																									{
																										IL_02c6:
																										num5 -= 2;
																										num = 169;
																										while (num != 169 && num == 1150)
																										{
																											switch (num)
																											{
																											case 57:
																												goto IL_02c6;
																											case 3:
																											case 98:
																												goto IL_02df;
																											case 127:
																												goto IL_0343;
																											case 159:
																												goto IL_0353;
																											case 80:
																												goto IL_0363;
																											case 130:
																												goto IL_0370;
																											case 125:
																												goto IL_0380;
																											case 60:
																												goto IL_0390;
																											case 103:
																											case 108:
																												goto IL_03a0;
																											case 58:
																												goto IL_03ab;
																											case 23:
																												goto IL_03b9;
																											case 96:
																												goto IL_03d2;
																											case 72:
																												goto IL_03e0;
																											case 65:
																												goto IL_03ee;
																											case 26:
																											case 27:
																												goto IL_03f9;
																											case 71:
																												goto IL_0439;
																											case 40:
																												goto IL_044d;
																											case 95:
																											case 99:
																												goto IL_0477;
																											case 123:
																												goto IL_0485;
																											case 0:
																											case 109:
																												goto IL_0493;
																											case 17:
																												goto IL_04d2;
																											case 77:
																											case 129:
																												goto IL_04e5;
																											case 13:
																												goto IL_0503;
																											case 47:
																												goto IL_0511;
																											case 133:
																												goto IL_0524;
																											case 25:
																												goto IL_0532;
																											case 15:
																											case 148:
																												goto IL_0545;
																											case 124:
																												goto IL_055c;
																											case 30:
																											case 142:
																												goto IL_056a;
																											case 39:
																												goto IL_0583;
																											case 101:
																												goto IL_0591;
																											case 6:
																												goto IL_059f;
																											case 56:
																											case 151:
																												goto IL_05b2;
																											case 75:
																											case 106:
																												goto IL_05bd;
																											case 128:
																												goto IL_05cb;
																											case 1:
																											case 48:
																												goto IL_05d9;
																											case 69:
																												goto IL_05f1;
																											case 93:
																											case 104:
																												goto IL_05ff;
																											case 53:
																												goto IL_0628;
																											case 10:
																												goto IL_0636;
																											case 158:
																												goto IL_0649;
																											case 12:
																												goto IL_0657;
																											case 44:
																											case 66:
																												goto IL_0665;
																											case 100:
																												goto IL_0673;
																											case 120:
																												goto IL_068b;
																											case 102:
																												goto IL_0699;
																											case 92:
																											case 160:
																												goto IL_06ac;
																											case 132:
																												goto IL_06d5;
																											case 97:
																												goto IL_06ee;
																											case 2:
																												goto IL_06fc;
																											case 150:
																												goto IL_070a;
																											case 76:
																											case 144:
																												goto IL_0718;
																											case 63:
																												goto IL_0758;
																											case 110:
																												goto IL_076c;
																											case 107:
																												goto IL_0788;
																											case 9:
																											case 73:
																												goto IL_0796;
																											case 20:
																												goto IL_07ad;
																											case 38:
																											case 78:
																												goto IL_07bb;
																											case 153:
																												goto IL_07c9;
																											case 14:
																												goto IL_07ec;
																											case 134:
																												goto IL_07f6;
																											case 11:
																												goto IL_0804;
																											case 8:
																											case 155:
																												goto IL_0817;
																											case 113:
																												goto IL_085b;
																											case 81:
																												goto IL_086f;
																											case 74:
																												goto IL_0882;
																											case 143:
																												goto IL_0890;
																											case 59:
																											case 118:
																												goto IL_089b;
																											case 61:
																												goto IL_08ae;
																											case 126:
																												goto IL_08bc;
																											case 45:
																											case 137:
																												goto IL_08ca;
																											case 88:
																												goto IL_08d8;
																											case 94:
																												goto IL_08fc;
																											case 145:
																												goto IL_090a;
																											case 50:
																												goto IL_091a;
																											case 82:
																											case 117:
																												goto IL_0925;
																											case 83:
																												goto IL_0930;
																											case 31:
																												goto IL_093d;
																											case 54:
																											case 84:
																												goto IL_0948;
																											case 5:
																											case 19:
																											case 22:
																											case 24:
																											case 34:
																											case 36:
																											case 42:
																											case 43:
																											case 49:
																											case 51:
																											case 64:
																											case 67:
																											case 68:
																											case 70:
																											case 79:
																											case 85:
																											case 87:
																											case 89:
																											case 105:
																											case 112:
																											case 131:
																											case 135:
																											case 136:
																											case 139:
																											case 140:
																											case 141:
																											case 149:
																											case 156:
																											case 157:
																											case 161:
																												goto end_IL_0370;
																											case 4:
																											case 7:
																											case 16:
																											case 18:
																											case 21:
																											case 28:
																											case 29:
																											case 33:
																											case 46:
																											case 62:
																											case 90:
																											case 111:
																											case 116:
																											case 121:
																											case 138:
																											case 147:
																											case 152:
																											case 154:
																											case 162:
																												goto end_IL_02b3;
																											case 119:
																												goto end_IL_0974;
																											case 35:
																												goto end_IL_0987;
																											case 52:
																												goto end_IL_099a;
																											case 32:
																												goto end_IL_09a5;
																											case 91:
																											case 122:
																												goto end_IL_09b5;
																											case 55:
																												goto end_IL_09c5;
																											case 41:
																											case 146:
																												goto end_IL_09d5;
																											case 114:
																												goto end_IL_09e5;
																											case 115:
																												goto end_IL_09f5;
																											case 37:
																											case 86:
																												goto IL_0a10;
																											}
																											continue;
																											end_IL_02b3:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_06ee;
																							IL_0817:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_085b;
																							IL_06ee:
																							if (11 < b)
																							{
																								goto IL_06fc;
																							}
																							num = 107;
																							goto IL_0788;
																							IL_06fc:
																							if (12 < b)
																							{
																								goto end_IL_0370;
																							}
																							goto IL_070a;
																							IL_070a:
																							if (12 > b)
																							{
																								goto end_IL_0370;
																							}
																							goto IL_0718;
																							IL_0718:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0758;
																							IL_0758:
																							array[num5 - 2] = 0;
																							goto IL_076c;
																							IL_076c:
																							num5--;
																							break;
																							IL_085b:
																							array[num5 - 2] = 0;
																							goto IL_086f;
																							IL_0788:
																							if (11 > b)
																							{
																								goto IL_0796;
																							}
																							goto IL_0817;
																							IL_0796:
																							if (10 < b)
																							{
																								goto end_IL_0370;
																							}
																							num = 20;
																							goto IL_07ad;
																							IL_086f:
																							num5--;
																							break;
																							IL_07ad:
																							if (10 > b)
																							{
																								goto end_IL_0370;
																							}
																							goto IL_07bb;
																							IL_07bb:
																							array[num5] = 0;
																							goto IL_07c9;
																							IL_07c9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_07ec;
																							IL_07ec:
																							array2[num5] = null;
																							goto IL_07f6;
																							IL_07f6:
																							num5++;
																							goto IL_0804;
																							IL_0804:
																							ptr2 += 8;
																							break;
																						}
																						break;
																					}
																					goto IL_0882;
																					IL_0948:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0882:
																					if (15 >= b)
																					{
																						goto IL_0890;
																					}
																					goto IL_091a;
																					IL_0890:
																					if (15 <= b)
																					{
																						goto IL_089b;
																					}
																					goto IL_08ae;
																					IL_089b:
																					num5--;
																					break;
																					IL_08ae:
																					if (14 < b)
																					{
																						goto end_IL_0370;
																					}
																					goto IL_08bc;
																					IL_08bc:
																					if (14 > b)
																					{
																						goto end_IL_0370;
																					}
																					goto IL_08ca;
																					IL_08ca:
																					array[num5] = 0;
																					goto IL_08d8;
																					IL_08d8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)ContentTypeSetURI[*(int*)(ptr2 + num3)])();
																					goto IL_08fc;
																					IL_08fc:
																					num5++;
																					goto IL_090a;
																					IL_090a:
																					ptr2 += 8;
																					break;
																					IL_091a:
																					if (16 < b)
																					{
																						goto IL_0925;
																					}
																					goto IL_093d;
																					IL_0925:
																					if (17 < b)
																					{
																						goto end_IL_0370;
																					}
																					goto IL_0930;
																					IL_0930:
																					if (17 > b)
																					{
																					}
																					goto end_IL_0370;
																					IL_093d:
																					if (16 > b)
																					{
																						goto end_IL_0370;
																					}
																					goto IL_0948;
																				}
																				break;
																			}
																			goto IL_03ab;
																			IL_06d5:
																			array[num5 - 1] = 5;
																			break;
																			IL_03ab:
																			if (9 <= b)
																			{
																				break;
																			}
																			goto IL_03b9;
																			IL_03b9:
																			if (4 >= b)
																			{
																				goto IL_03d2;
																			}
																			num = 95;
																			goto IL_0477;
																			IL_04e5:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0503;
																			IL_0477:
																			if (6 >= b)
																			{
																				goto IL_0485;
																			}
																			goto IL_05b2;
																			IL_0485:
																			if (6 <= b)
																			{
																				goto IL_0493;
																			}
																			goto IL_0649;
																			IL_0493:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04d2;
																			IL_04d2:
																			num5 -= 3;
																			break;
																			IL_0649:
																			if (5 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0657;
																			IL_0657:
																			if (5 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0665;
																			IL_0665:
																			array[num5] = 5;
																			goto IL_0673;
																			IL_0673:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_068b;
																			IL_068b:
																			num5++;
																			goto IL_0699;
																			IL_0699:
																			ptr2 += 8;
																			break;
																			IL_05b2:
																			if (7 < b)
																			{
																				goto IL_05bd;
																			}
																			goto IL_05f1;
																			IL_05bd:
																			if (8 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_05cb;
																			IL_05cb:
																			if (8 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_05d9;
																			IL_05d9:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_05f1:
																			if (7 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_05ff;
																			IL_05ff:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0628;
																			IL_0628:
																			ptr2 += 8;
																			goto IL_0636;
																			IL_0636:
																			num5--;
																			break;
																			IL_03d2:
																			if (4 > b)
																			{
																				goto IL_03e0;
																			}
																			goto IL_04e5;
																			IL_03e0:
																			if (2 >= b)
																			{
																				goto IL_03ee;
																			}
																			goto IL_0524;
																			IL_03ee:
																			if (2 <= b)
																			{
																				goto IL_03f9;
																			}
																			num = 148;
																			goto IL_0545;
																			IL_03f9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0439;
																			IL_0439:
																			array[num5 - 2] = 0;
																			goto IL_044d;
																			IL_044d:
																			num5--;
																			num = 154;
																			break;
																			IL_0503:
																			ptr2 += 8;
																			goto IL_0511;
																			IL_0545:
																			if (1 < b)
																			{
																				goto end_IL_0370;
																			}
																			num = 124;
																			goto IL_055c;
																			IL_0511:
																			num5--;
																			break;
																			IL_055c:
																			if (1 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_056a;
																			IL_056a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0583;
																			IL_0583:
																			array[num5] = 0;
																			goto IL_0591;
																			IL_0591:
																			num5++;
																			goto IL_059f;
																			IL_059f:
																			ptr2 += 8;
																			break;
																			IL_0524:
																			if (3 < b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_0532;
																			IL_0532:
																			if (3 > b)
																			{
																				goto end_IL_0370;
																			}
																			goto IL_06ac;
																			IL_06ac:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06d5;
																		}
																		goto end_IL_0380;
																		continue;
																		end_IL_0370:
																		break;
																		IL_0370:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0380:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a10;
												IL_0a10:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0974:
												break;
											}
											continue;
											end_IL_0987:
											break;
										}
										continue;
										end_IL_099a:
										break;
									}
									continue;
									end_IL_09a5:
									break;
								}
								continue;
								end_IL_09b5:
								break;
							}
							continue;
							end_IL_09c5:
							break;
						}
						continue;
						end_IL_09d5:
						break;
					}
					continue;
					end_IL_09e5:
					break;
				}
				continue;
				end_IL_09f5:
				break;
			}
		}
	}

	private static int smethod_6(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		if (num <= num2)
		{
			num = int_4;
			num2 = int_3;
			return num - num2;
		}
		num = int_3;
		num2 = int_4;
		return num - num2;
	}

	private static int smethod_7(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	static Class195()
	{
		int num = 7;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 15;
			while (true)
			{
				if (num != 15)
				{
					if (num == 996)
					{
						switch (num)
						{
						case 7:
							goto end_IL_0045;
						case 0:
						case 1:
						case 3:
						case 4:
						case 5:
						case 6:
						case 8:
							goto IL_006d;
						case 2:
							return;
						}
						continue;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				goto IL_006d;
				IL_006d:
				num = 2;
				return;
				continue;
				end_IL_0045:
				break;
			}
		}
	}
}
