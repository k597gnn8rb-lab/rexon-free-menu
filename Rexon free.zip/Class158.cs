using System;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Spoof Leaderboard Name", "Safety", "Changes your displayed name on the scoreboard.", false, 10, ModType.const_0, false)]
internal class Class158 : MonoBehaviour
{
	private string string_0;

	private string string_1;

	private bool bool_0;

	private static int int_0;

	private static bool bool_1;

	private static bool bool_2;

	private static bool bool_3;

	private static float float_0;

	private static float float_1;

	private static int int_1;

	private static IntPtr[] getPermissionSetsetDataPointer;

	private static IntPtr[] getTypeLibraryCustomErrorsEnabled;

	private static IntPtr[] ExponentBigMul;

	private static IntPtr[] IAppIdAuthoritygetThreadContextChanged;

	private static IntPtr[] CreateAttributegetViewAccessControl;

	private static NetworkView getIsParamDefIsEnabled(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.myVRRig;
	}

	private static bool GetFramesgetCommandLine(string string_2)
	{
		return string.IsNullOrEmpty(string_2);
	}

	private static GorillaComputer CreateActContextParameterstdesc()
	{
		return GorillaComputer.instance;
	}

	private void Update()
	{
		int num = 143;
		num = 11;
		num = 123;
		num = 41;
		num = 11;
		num = 34;
		num = 43;
		num = 43;
		num = 189;
		num = 27;
		num = 98;
		num = 49;
		num = 27;
		num = 76;
		num = 1383;
		num = 1383;
		num = 1426;
		num = 744;
		num = 186;
		object obj = this;
		if (!((Class158)obj).bool_0)
		{
			return;
		}
		try
		{
			Player localPlayer = PhotonNetwork.LocalPlayer;
			obj = localPlayer;
			string nickName = ((Player)obj).NickName;
			obj = nickName;
			object obj2 = this;
			obj2 = ((Class158)obj2).string_1;
			if ((string)obj != (string)obj2)
			{
				Player localPlayer2 = PhotonNetwork.LocalPlayer;
				obj = localPlayer2;
				obj2 = this;
				obj2 = ((Class158)obj2).string_1;
				((Player)obj).NickName = (string)obj2;
			}
		}
		catch
		{
		}
	}

	private static bool CreateProxyStartMenu()
	{
		return PhotonNetwork.InRoom;
	}

	private static string IsHideBySigISymbolDocument(Class158 class158_1)
	{
		return class158_1.string_0;
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 16;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DependentOSMetadataMajorVersionOpenSave.LIBFLAGFCONTROLIMPNOFLOW);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 94;
															while (true)
															{
																IL_02a2:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0285:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0275:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0265:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0258:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													array[num5] = 0;
																													while (true)
																													{
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 118;
																														while (true)
																														{
																															if (num != 118)
																															{
																																if (num != 1099)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 97:
																																	goto end_IL_01e7;
																																case 49:
																																case 106:
																																	goto end_IL_01fa;
																																case 75:
																																	goto end_IL_0228;
																																case 60:
																																case 77:
																																	goto IL_0248;
																																case 15:
																																	goto IL_0258;
																																case 33:
																																case 46:
																																	goto IL_0265;
																																case 63:
																																	goto IL_0275;
																																case 19:
																																	goto IL_0285;
																																case 55:
																																	goto IL_0292;
																																case 94:
																																	goto IL_02a2;
																																case 85:
																																	goto end_IL_02a2;
																																case 20:
																																case 36:
																																	goto end_IL_02b2;
																																case 4:
																																	goto IL_02d6;
																																case 1:
																																case 22:
																																	goto IL_02e9;
																																case 7:
																																	goto IL_02f4;
																																case 35:
																																case 68:
																																	goto IL_0302;
																																case 66:
																																	goto IL_0310;
																																case 81:
																																	goto IL_0323;
																																case 45:
																																	goto IL_0331;
																																case 24:
																																	goto IL_033c;
																																case 38:
																																	goto IL_034f;
																																case 69:
																																	goto IL_035d;
																																case 8:
																																case 65:
																																	goto IL_036b;
																																case 47:
																																	goto IL_038e;
																																case 51:
																																	goto IL_039c;
																																case 87:
																																	goto IL_03aa;
																																case 88:
																																	goto IL_03bd;
																																case 58:
																																case 79:
																																	goto IL_03cb;
																																case 17:
																																case 90:
																																	goto IL_03e7;
																																case 91:
																																	goto IL_0449;
																																case 78:
																																case 103:
																																	goto IL_045c;
																																case 56:
																																	goto IL_049c;
																																case 54:
																																	goto IL_04b0;
																																case 89:
																																	goto IL_04cd;
																																case 109:
																																	goto IL_04e4;
																																case 70:
																																	goto IL_04f7;
																																case 23:
																																case 105:
																																	goto IL_0505;
																																case 3:
																																case 72:
																																	goto IL_0510;
																																case 39:
																																	goto IL_051e;
																																case 21:
																																case 111:
																																	goto IL_052c;
																																case 67:
																																	goto IL_0555;
																																case 2:
																																	goto IL_0563;
																																case 12:
																																	goto IL_0576;
																																case 43:
																																case 44:
																																	goto IL_0584;
																																case 86:
																																	goto IL_059d;
																																case 11:
																																	goto IL_05ab;
																																case 42:
																																	goto IL_05b9;
																																case 53:
																																case 82:
																																	goto IL_05cc;
																																case 10:
																																case 71:
																																	goto IL_05e4;
																																case 59:
																																	goto IL_062d;
																																case 34:
																																	goto IL_0641;
																																case 5:
																																case 6:
																																case 13:
																																case 26:
																																case 30:
																																case 41:
																																case 48:
																																case 52:
																																case 73:
																																case 84:
																																case 92:
																																case 95:
																																case 96:
																																case 98:
																																case 99:
																																case 104:
																																case 108:
																																case 110:
																																	goto end_IL_0238;
																																case 9:
																																case 14:
																																case 28:
																																case 29:
																																case 31:
																																case 32:
																																case 57:
																																case 64:
																																case 74:
																																case 76:
																																case 80:
																																case 100:
																																case 101:
																																case 102:
																																	goto end_IL_02cb;
																																case 93:
																																	goto end_IL_0664;
																																case 16:
																																	goto end_IL_0677;
																																case 37:
																																	goto end_IL_0681;
																																case 0:
																																	goto end_IL_068c;
																																case 18:
																																case 25:
																																	goto end_IL_06aa;
																																case 107:
																																	goto end_IL_06ba;
																																case 27:
																																case 83:
																																	goto end_IL_06ca;
																																case 61:
																																	goto end_IL_06da;
																																case 62:
																																	goto end_IL_06ea;
																																case 40:
																																case 50:
																																	goto IL_0705;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_04cd;
																															IL_04cd:
																															num5++;
																															num = 109;
																															goto IL_04e4;
																															IL_04e4:
																															ptr2 += 8;
																															goto end_IL_02cb;
																															continue;
																															end_IL_01e7:
																															break;
																														}
																														continue;
																														end_IL_01fa:
																														break;
																													}
																													continue;
																													end_IL_0228:
																													break;
																												}
																												continue;
																												end_IL_0238:
																												break;
																											}
																											break;
																											IL_0248:;
																										}
																										break;
																									}
																									goto IL_02d6;
																									IL_02d6:
																									if (4 <= b)
																									{
																										goto end_IL_02cb;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_04f7;
																							IL_05cc:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02cb;
																							IL_04f7:
																							if (3 > b)
																							{
																								goto IL_0505;
																							}
																							goto IL_05cc;
																							IL_0505:
																							if (1 < b)
																							{
																								goto IL_0510;
																							}
																							goto IL_0576;
																							IL_0510:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_051e;
																							IL_051e:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_052c;
																							IL_052c:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0555;
																							IL_0555:
																							ptr2 += 8;
																							goto IL_0563;
																							IL_0563:
																							num5--;
																							goto end_IL_02cb;
																							IL_0576:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0584;
																							IL_0584:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_059d;
																							IL_059d:
																							array[num5] = 0;
																							goto IL_05ab;
																							IL_05ab:
																							num5++;
																							goto IL_05b9;
																							IL_05b9:
																							ptr2 += 8;
																							goto end_IL_02cb;
																						}
																						break;
																					}
																					goto IL_05e4;
																					IL_0641:
																					num5--;
																					goto end_IL_02cb;
																					IL_05e4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 59;
																					goto IL_062d;
																					IL_062d:
																					array[num5 - 2] = 0;
																					goto IL_0641;
																				}
																				break;
																			}
																			goto IL_02e9;
																			IL_0449:
																			num5 -= 2;
																			goto end_IL_02cb;
																			IL_02e9:
																			if (9 < b)
																			{
																				goto IL_02f4;
																			}
																			goto IL_0323;
																			IL_02f4:
																			if (10 < b)
																			{
																				goto IL_0302;
																			}
																			goto IL_03bd;
																			IL_0302:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0310;
																			IL_0310:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_03bd:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_03cb;
																			IL_03cb:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02cb;
																			IL_0323:
																			if (9 > b)
																			{
																				goto IL_0331;
																			}
																			goto IL_03e7;
																			IL_0331:
																			if (7 >= b)
																			{
																				goto IL_033c;
																			}
																			goto IL_034f;
																			IL_033c:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_045c;
																			IL_045c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_049c;
																			IL_049c:
																			array[num5 - 2] = 0;
																			goto IL_04b0;
																			IL_04b0:
																			num5--;
																			goto end_IL_02cb;
																			IL_034f:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_035d;
																			IL_035d:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_036b;
																			IL_036b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_038e;
																			IL_038e:
																			array[num5] = 0;
																			goto IL_039c;
																			IL_039c:
																			num5++;
																			goto IL_03aa;
																			IL_03aa:
																			ptr2 += 8;
																			goto end_IL_02cb;
																			IL_03e7:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0449;
																		}
																		break;
																		IL_0292:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02cb;
																continue;
																end_IL_02a2:
																break;
															}
															continue;
															end_IL_02b2:
															break;
														}
														continue;
														end_IL_02cb:
														break;
													}
													continue;
												}
												goto IL_0705;
												IL_0705:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0664:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_0681:
										break;
									}
									continue;
									end_IL_068c:
									break;
								}
								continue;
								end_IL_06aa:
								break;
							}
							continue;
							end_IL_06ba:
							break;
						}
						continue;
						end_IL_06ca:
						break;
					}
					continue;
					end_IL_06da:
					break;
				}
				continue;
				end_IL_06ea:
				break;
			}
		}
	}

	private static string getInterfaceTypeTaskCanceledException(string[] string_2)
	{
		return string.Concat(string_2);
	}

	private static GorillaTagger FormIdnaDisallowUnassignedDuplicateIdentityOption()
	{
		return GorillaTagger.Instance;
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DangerousAddRefgetIsThreadOwnerTrackingEnabled.InternalEncoderBestFitFallbackNodeEnumerator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d8:
														byte b = *ptr2;
														while (true)
														{
															IL_02bf:
															ptr2++;
															num = 78;
															while (true)
															{
																IL_02af:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_028f:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_027f:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0272:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0262:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0252:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_0227:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_0217:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_01fe:
																																num5++;
																																num = 119;
																																while (true)
																																{
																																	if (num != 119)
																																	{
																																		if (num != 1100)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 43:
																																			goto IL_01fe;
																																		case 61:
																																			goto IL_0217;
																																		case 8:
																																		case 86:
																																			goto IL_0227;
																																		case 52:
																																			goto IL_0242;
																																		case 11:
																																		case 87:
																																			goto IL_0252;
																																		case 89:
																																			goto IL_0262;
																																		case 0:
																																		case 99:
																																			goto IL_0272;
																																		case 29:
																																			goto IL_027f;
																																		case 31:
																																			goto IL_028f;
																																		case 105:
																																			goto IL_029f;
																																		case 78:
																																			goto IL_02af;
																																		case 17:
																																			goto IL_02bf;
																																		case 1:
																																		case 101:
																																			goto IL_02d8;
																																		case 32:
																																		case 41:
																																			goto IL_02ec;
																																		case 75:
																																		case 79:
																																			goto IL_02f7;
																																		case 16:
																																			goto IL_0305;
																																		case 83:
																																			goto IL_0315;
																																		case 95:
																																			goto IL_0328;
																																		case 48:
																																			goto IL_0336;
																																		case 63:
																																		case 69:
																																			goto IL_034d;
																																		case 73:
																																		case 108:
																																			goto IL_0378;
																																		case 45:
																																			goto IL_0386;
																																		case 55:
																																			goto IL_03a9;
																																		case 109:
																																			goto IL_03b3;
																																		case 21:
																																			goto IL_03c1;
																																		case 110:
																																			goto IL_03d4;
																																		case 56:
																																			goto IL_03e2;
																																		case 68:
																																		case 94:
																																			goto IL_0411;
																																		case 60:
																																		case 70:
																																			goto IL_0429;
																																		case 46:
																																			goto IL_0472;
																																		case 23:
																																			goto IL_048f;
																																		case 34:
																																		case 62:
																																			goto IL_04ab;
																																		case 85:
																																			goto IL_04b9;
																																		case 30:
																																			goto IL_04c7;
																																		case 57:
																																			goto IL_04d2;
																																		case 10:
																																		case 88:
																																			goto IL_04e0;
																																		case 66:
																																			goto IL_0520;
																																		case 2:
																																			goto IL_0534;
																																		case 96:
																																			goto IL_0547;
																																		case 47:
																																			goto IL_0555;
																																		case 81:
																																		case 112:
																																			goto IL_0563;
																																		case 104:
																																			goto IL_058f;
																																		case 106:
																																			goto IL_059d;
																																		case 6:
																																			goto IL_05ab;
																																		case 4:
																																		case 65:
																																			goto IL_05be;
																																		case 64:
																																			goto IL_0620;
																																		case 77:
																																			goto IL_0639;
																																		case 50:
																																			goto IL_0644;
																																		case 3:
																																		case 49:
																																			goto IL_064f;
																																		case 36:
																																			goto IL_0668;
																																		case 92:
																																			goto IL_0673;
																																		case 5:
																																		case 12:
																																		case 15:
																																		case 20:
																																		case 24:
																																		case 25:
																																		case 26:
																																		case 28:
																																		case 35:
																																		case 37:
																																		case 40:
																																		case 42:
																																		case 44:
																																		case 59:
																																		case 67:
																																		case 76:
																																		case 84:
																																		case 93:
																																		case 98:
																																		case 111:
																																			goto end_IL_0242;
																																		case 9:
																																		case 14:
																																		case 22:
																																		case 27:
																																		case 39:
																																		case 58:
																																		case 71:
																																		case 72:
																																		case 74:
																																		case 80:
																																		case 90:
																																		case 91:
																																		case 100:
																																		case 107:
																																			goto end_IL_01eb;
																																		case 7:
																																			goto end_IL_0691;
																																		case 102:
																																			goto end_IL_06a4;
																																		case 38:
																																			goto end_IL_06ae;
																																		case 103:
																																			goto end_IL_06b9;
																																		case 13:
																																		case 33:
																																			goto end_IL_06ce;
																																		case 51:
																																			goto end_IL_06de;
																																		case 18:
																																		case 19:
																																			goto end_IL_06ee;
																																		case 53:
																																			goto end_IL_06fe;
																																		case 54:
																																			goto end_IL_070e;
																																		case 82:
																																		case 97:
																																			goto IL_0729;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	break;
																																	continue;
																																	end_IL_01eb:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02af;
																													continue;
																													end_IL_0242:
																													break;
																													IL_0242:;
																												}
																												break;
																											}
																											goto IL_0328;
																											IL_03d4:
																											ptr2 += 8;
																											goto IL_03e2;
																											IL_0328:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0336;
																											IL_0336:
																											if (2 > b)
																											{
																												break;
																											}
																											num = 63;
																											goto IL_034d;
																											IL_03e2:
																											num5--;
																											num = 80;
																											goto end_IL_02af;
																											IL_034d:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_03d4;
																										}
																										break;
																									}
																									goto IL_0411;
																									IL_0411:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02af;
																								}
																								break;
																							}
																							num = 32;
																							goto IL_02ec;
																							IL_03c1:
																							ptr2 += 8;
																							goto end_IL_02af;
																							IL_0315:
																							if (4 <= b)
																							{
																								goto end_IL_02af;
																							}
																							break;
																							IL_02ec:
																							if (4 < b)
																							{
																								goto IL_02f7;
																							}
																							goto IL_0315;
																							IL_02f7:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0305;
																							IL_0305:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0378;
																							IL_0378:
																							array[num5] = 0;
																							goto IL_0386;
																							IL_0386:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_03a9;
																							IL_03a9:
																							array2[num5] = null;
																							goto IL_03b3;
																							IL_03b3:
																							num5++;
																							goto IL_03c1;
																						}
																						break;
																					}
																					goto IL_0429;
																					IL_048f:
																					num5--;
																					goto end_IL_02af;
																					IL_0429:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 46;
																					goto IL_0472;
																					IL_0472:
																					array[num5 - 2] = 0;
																					num = 23;
																					goto IL_048f;
																				}
																				break;
																			}
																			num = 62;
																			goto IL_04ab;
																			IL_0668:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0673;
																			IL_0673:
																			if (11 > b)
																			{
																			}
																			break;
																			IL_04ab:
																			if (9 >= b)
																			{
																				goto IL_04b9;
																			}
																			goto IL_0639;
																			IL_04b9:
																			if (9 > b)
																			{
																				goto IL_04c7;
																			}
																			goto IL_05be;
																			IL_04c7:
																			if (7 >= b)
																			{
																				goto IL_04d2;
																			}
																			goto IL_0547;
																			IL_04d2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04e0;
																			IL_04e0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0520;
																			IL_0520:
																			array[num5 - 2] = 0;
																			goto IL_0534;
																			IL_0534:
																			num5--;
																			goto end_IL_02af;
																			IL_0547:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0555;
																			IL_0555:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0563;
																			IL_0563:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 104;
																			goto IL_058f;
																			IL_058f:
																			array[num5] = 0;
																			goto IL_059d;
																			IL_059d:
																			num5++;
																			goto IL_05ab;
																			IL_05ab:
																			ptr2 += 8;
																			goto end_IL_02af;
																			IL_05be:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0620;
																			IL_0620:
																			num5 -= 2;
																			num = 58;
																			goto end_IL_02af;
																			IL_0639:
																			if (10 >= b)
																			{
																				goto IL_0644;
																			}
																			goto IL_0668;
																			IL_0644:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_064f;
																			IL_064f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02af;
																		}
																		break;
																		IL_029f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02af:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0729;
												IL_0729:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0691:
												break;
											}
											continue;
											end_IL_06a4:
											break;
										}
										continue;
										end_IL_06ae:
										break;
									}
									continue;
									end_IL_06b9:
									break;
								}
								continue;
								end_IL_06ce:
								break;
							}
							continue;
							end_IL_06de:
							break;
						}
						continue;
						end_IL_06ee:
						break;
					}
					continue;
					end_IL_06fe:
					break;
				}
				continue;
				end_IL_070e:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 39;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetMethodBaseFromMethodMessagegetPrimitiveValue.getMethodBaseFromMethodMessagegetPrimitiveValue_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 3;
														while (true)
														{
															byte b = *ptr2;
															num = 97;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02f0:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02d3:
																				if (7 < b)
																				{
																					while (true)
																					{
																						IL_02c3:
																						if (11 >= b)
																						{
																							while (true)
																							{
																								IL_02b3:
																								if (11 > b)
																								{
																									while (true)
																									{
																										IL_02a3:
																										if (9 >= b)
																										{
																											while (true)
																											{
																												IL_0293:
																												if (9 > b)
																												{
																													while (8 >= b)
																													{
																														while (8 <= b)
																														{
																															num = 144;
																															while (true)
																															{
																																if (num != 144)
																																{
																																	if (num != 1125)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 28:
																																		goto IL_0270;
																																	case 129:
																																	case 136:
																																		goto IL_0283;
																																	case 7:
																																		goto IL_0293;
																																	case 18:
																																	case 40:
																																		goto IL_02a3;
																																	case 5:
																																		goto IL_02b3;
																																	case 128:
																																		goto IL_02c3;
																																	case 16:
																																		goto IL_02d3;
																																	case 17:
																																		goto IL_02e0;
																																	case 92:
																																		goto IL_02f0;
																																	case 97:
																																		goto end_IL_02f0;
																																	case 3:
																																		goto end_IL_0300;
																																	case 88:
																																		goto end_IL_0310;
																																	case 14:
																																		goto IL_032f;
																																	case 10:
																																	case 66:
																																		goto IL_033a;
																																	case 46:
																																		goto IL_037a;
																																	case 52:
																																	case 84:
																																		goto IL_0393;
																																	case 4:
																																	case 21:
																																		goto IL_03a1;
																																	case 74:
																																		goto IL_03ac;
																																	case 32:
																																		goto IL_03b9;
																																	case 55:
																																		goto IL_03c7;
																																	case 43:
																																	case 85:
																																		goto IL_03da;
																																	case 67:
																																		goto IL_03e8;
																																	case 105:
																																		goto IL_040d;
																																	case 33:
																																		goto end_IL_025d;
																																	case 107:
																																		goto IL_042e;
																																	case 110:
																																		goto IL_043a;
																																	case 112:
																																		goto IL_044d;
																																	case 51:
																																		goto IL_0458;
																																	case 63:
																																		goto IL_0466;
																																	case 19:
																																	case 62:
																																		goto IL_0474;
																																	case 71:
																																		goto IL_048d;
																																	case 115:
																																		goto IL_04a0;
																																	case 53:
																																		goto IL_04ae;
																																	case 38:
																																	case 116:
																																		goto IL_04c1;
																																	case 69:
																																	case 119:
																																		goto IL_04d9;
																																	case 125:
																																		goto IL_0519;
																																	case 98:
																																		goto IL_0536;
																																	case 127:
																																		goto IL_0549;
																																	case 49:
																																		goto IL_0557;
																																	case 75:
																																	case 76:
																																		goto IL_0565;
																																	case 121:
																																		goto IL_058e;
																																	case 86:
																																		goto IL_059c;
																																	case 133:
																																		goto IL_05af;
																																	case 60:
																																		goto IL_05bd;
																																	case 77:
																																		goto IL_05d0;
																																	case 54:
																																		goto IL_05fc;
																																	case 20:
																																		goto IL_060a;
																																	case 26:
																																		goto IL_0618;
																																	case 11:
																																	case 118:
																																		goto IL_062b;
																																	case 94:
																																		goto IL_068d;
																																	case 109:
																																		goto IL_06a0;
																																	case 15:
																																		goto IL_06ae;
																																	case 27:
																																	case 65:
																																		goto IL_06bc;
																																	case 132:
																																		goto IL_06fc;
																																	case 131:
																																		goto IL_0710;
																																	case 48:
																																	case 111:
																																		goto IL_0723;
																																	case 57:
																																		goto IL_0737;
																																	case 61:
																																		goto IL_077f;
																																	case 72:
																																		goto IL_0792;
																																	case 68:
																																	case 135:
																																		goto IL_079d;
																																	case 124:
																																		goto IL_07a8;
																																	case 2:
																																		goto IL_07b5;
																																	case 0:
																																	case 30:
																																		goto IL_07c0;
																																	case 90:
																																		goto IL_07d9;
																																	case 89:
																																		goto IL_07e4;
																																	case 56:
																																	case 96:
																																		goto IL_07ef;
																																	case 6:
																																	case 12:
																																	case 13:
																																	case 24:
																																	case 31:
																																	case 34:
																																	case 35:
																																	case 36:
																																	case 37:
																																	case 44:
																																	case 47:
																																	case 58:
																																	case 59:
																																	case 64:
																																	case 70:
																																	case 73:
																																	case 78:
																																	case 80:
																																	case 81:
																																	case 82:
																																	case 83:
																																	case 93:
																																	case 100:
																																	case 106:
																																	case 122:
																																	case 126:
																																		goto end_IL_0270;
																																	case 8:
																																	case 9:
																																	case 23:
																																	case 29:
																																	case 45:
																																	case 50:
																																	case 87:
																																	case 95:
																																	case 99:
																																	case 102:
																																	case 103:
																																	case 108:
																																	case 114:
																																	case 117:
																																	case 123:
																																	case 130:
																																	case 134:
																																		goto end_IL_0324;
																																	case 120:
																																		goto end_IL_0812;
																																	case 91:
																																		goto end_IL_0825;
																																	case 1:
																																		goto end_IL_082f;
																																	case 113:
																																		goto end_IL_083a;
																																	case 39:
																																	case 137:
																																		goto end_IL_084f;
																																	case 22:
																																		goto end_IL_085f;
																																	case 25:
																																	case 104:
																																		goto end_IL_086f;
																																	case 41:
																																		goto end_IL_0888;
																																	case 42:
																																		goto end_IL_0898;
																																	case 79:
																																	case 101:
																																		goto IL_08b3;
																																	}
																																	continue;
																																}
																																goto IL_05d0;
																																IL_060a:
																																num5++;
																																goto IL_0618;
																																IL_0618:
																																ptr2 += 8;
																																goto end_IL_0324;
																																IL_05d0:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																num = 54;
																																goto IL_05fc;
																																IL_05fc:
																																array[num5] = 0;
																																goto IL_060a;
																																continue;
																																end_IL_025d:
																																break;
																															}
																															goto IL_041b;
																															continue;
																															end_IL_0270:
																															break;
																															IL_0270:;
																														}
																														break;
																														IL_0283:;
																													}
																													break;
																												}
																												goto IL_062b;
																												IL_068d:
																												num5 -= 2;
																												goto end_IL_0324;
																												IL_062b:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_068d;
																											}
																											break;
																										}
																										goto IL_06a0;
																										IL_0710:
																										num5--;
																										goto end_IL_0324;
																										IL_06a0:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_06ae;
																										IL_06ae:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_06bc;
																										IL_06bc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_06fc;
																										IL_06fc:
																										array[num5 - 2] = 0;
																										goto IL_0710;
																									}
																									break;
																								}
																								goto IL_0723;
																								IL_077f:
																								ptr2 += 8;
																								goto end_IL_0324;
																								IL_0723:
																								array[num5 - 1] = 0;
																								goto IL_0737;
																								IL_0737:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)CreateAttributegetViewAccessControl[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								num = 61;
																								goto IL_077f;
																							}
																							break;
																						}
																						goto IL_0792;
																						IL_07ef:
																						num5--;
																						goto end_IL_0324;
																						IL_0792:
																						if (13 < b)
																						{
																							goto IL_079d;
																						}
																						goto IL_07b5;
																						IL_079d:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_07a8;
																						IL_07a8:
																						if (14 <= b)
																						{
																						}
																						break;
																						IL_07b5:
																						if (13 <= b)
																						{
																							goto IL_07c0;
																						}
																						goto IL_07d9;
																						IL_07c0:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0324;
																						IL_07d9:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_07e4;
																						IL_07e4:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_07ef;
																					}
																					break;
																				}
																				goto IL_032f;
																				IL_04c1:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0324;
																				IL_032f:
																				if (7 <= b)
																				{
																					goto IL_033a;
																				}
																				goto IL_0393;
																				IL_033a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_037a;
																				IL_037a:
																				array[num5 - 2] = 0;
																				goto IL_043a;
																				IL_043a:
																				num5--;
																				goto end_IL_0324;
																				IL_0393:
																				if (3 < b)
																				{
																					goto IL_03a1;
																				}
																				goto IL_044d;
																				IL_03a1:
																				if (5 >= b)
																				{
																					goto IL_03ac;
																				}
																				goto IL_03b9;
																				IL_03ac:
																				if (5 <= b)
																				{
																					goto IL_03da;
																				}
																				goto IL_040d;
																				IL_03da:
																				array[num5] = 0;
																				goto IL_03e8;
																				IL_03e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_042e;
																				IL_042e:
																				array2[num5] = null;
																				goto IL_04a0;
																				IL_04a0:
																				num5++;
																				goto IL_04ae;
																				IL_04ae:
																				ptr2 += 8;
																				goto end_IL_0324;
																				IL_040d:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_041b;
																				IL_041b:
																				if (4 <= b)
																				{
																					goto end_IL_0324;
																				}
																				break;
																				IL_03b9:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_03c7;
																				IL_03c7:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_04d9;
																				IL_04d9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0519;
																				IL_0519:
																				array[num5 - 2] = 0;
																				num = 98;
																				goto IL_0536;
																				IL_0536:
																				num5--;
																				goto end_IL_0324;
																				IL_044d:
																				if (3 > b)
																				{
																					goto IL_0458;
																				}
																				goto IL_04c1;
																				IL_0458:
																				if (1 >= b)
																				{
																					goto IL_0466;
																				}
																				goto IL_0549;
																				IL_0466:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0474;
																				IL_0474:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_048d;
																				IL_048d:
																				array[num5] = 0;
																				goto IL_05af;
																				IL_05af:
																				num5++;
																				goto IL_05bd;
																				IL_05bd:
																				ptr2 += 8;
																				goto end_IL_0324;
																				IL_0549:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0557;
																				IL_0557:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0565;
																				IL_0565:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_058e;
																				IL_058e:
																				ptr2 += 8;
																				goto IL_059c;
																				IL_059c:
																				num5--;
																				goto end_IL_0324;
																			}
																			break;
																			IL_02e0:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0324;
																	continue;
																	end_IL_02f0:
																	break;
																}
																continue;
																end_IL_0300:
																break;
															}
															continue;
															end_IL_0310:
															break;
														}
														continue;
														end_IL_0324:
														break;
													}
													continue;
												}
												goto IL_08b3;
												IL_08b3:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0812:
												break;
											}
											continue;
											end_IL_0825:
											break;
										}
										continue;
										end_IL_082f:
										break;
									}
									continue;
									end_IL_083a:
									break;
								}
								continue;
								end_IL_084f:
								break;
							}
							continue;
							end_IL_085f:
							break;
						}
						continue;
						end_IL_086f:
						break;
					}
					continue;
					end_IL_0888:
					break;
				}
				continue;
				end_IL_0898:
				break;
			}
		}
	}

	private static bool NotOnFaultedNullableMarshaler(PhotonView photonView_0, string string_2, RpcTarget rpcTarget_0, object[] object_0)
	{
		return photonView_0.smethod_3(string_2, rpcTarget_0, object_0);
	}

	private unsafe static int smethod_3()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								IL_02bb:
								long[] array4 = new long[4];
								while (true)
								{
									IL_02ab:
									object[] array5 = new object[1];
									while (true)
									{
										IL_0297:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CeilingPermissionState.ReferenceHostExecutionContext);
										num = 122;
										while (true)
										{
											IL_028d:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0282:
												num = 152;
												while (true)
												{
													if (num != 152)
													{
														if (num != 1133)
														{
															break;
														}
														switch (num)
														{
														case 86:
															goto IL_0282;
														case 122:
															goto IL_028d;
														case 136:
															goto IL_0297;
														case 104:
															goto IL_02ab;
														case 64:
															goto IL_02bb;
														case 100:
														case 106:
															goto end_IL_026f;
														case 6:
															goto end_IL_02cb;
														case 66:
														case 68:
															goto end_IL_02db;
														case 0:
															goto end_IL_02eb;
														case 1:
															goto end_IL_02fb;
														case 18:
														case 23:
														case 35:
														case 44:
														case 74:
														case 81:
														case 88:
														case 89:
														case 94:
														case 95:
														case 102:
														case 111:
														case 118:
														case 129:
														case 137:
														case 141:
															goto IL_0316;
														case 37:
														case 65:
															goto IL_0326;
														case 75:
															goto IL_0338;
														case 39:
															goto IL_0346;
														case 67:
															goto IL_0354;
														case 127:
															goto IL_0362;
														case 133:
															goto IL_0370;
														case 46:
														case 70:
															goto IL_0384;
														case 109:
															goto IL_039c;
														case 80:
															goto IL_03aa;
														case 128:
															goto IL_03b8;
														case 30:
														case 93:
															goto IL_03c3;
														case 54:
															goto IL_03d1;
														case 29:
														case 130:
															goto IL_03df;
														case 134:
															goto IL_0408;
														case 61:
															goto IL_0421;
														case 84:
														case 115:
															goto IL_042c;
														case 116:
															goto IL_043a;
														case 9:
														case 92:
															goto IL_0451;
														case 31:
															goto IL_046a;
														case 57:
															goto IL_0478;
														case 41:
															goto IL_0486;
														case 69:
														case 126:
															goto IL_0499;
														case 19:
															goto IL_04d9;
														case 58:
															goto IL_04ed;
														case 25:
														case 50:
															goto IL_0500;
														case 47:
															goto IL_051e;
														case 7:
															goto IL_052c;
														case 45:
														case 117:
															goto IL_053f;
														case 124:
															goto IL_054d;
														case 40:
															goto IL_0558;
														case 52:
															goto IL_0566;
														case 16:
														case 98:
															goto IL_0574;
														case 103:
															goto IL_0582;
														case 85:
															goto IL_059a;
														case 71:
															goto IL_05a8;
														case 48:
														case 91:
															goto IL_05bb;
														case 27:
															goto IL_05fa;
														case 123:
															goto IL_0616;
														case 13:
															goto IL_0624;
														case 62:
														case 87:
															goto IL_0632;
														case 49:
															goto IL_065b;
														case 99:
															goto IL_0669;
														case 34:
														case 142:
															goto IL_0685;
														case 114:
															goto IL_0693;
														case 121:
															goto IL_06a1;
														case 4:
															goto IL_06af;
														case 56:
														case 73:
															goto IL_06ba;
														case 10:
															goto IL_06c8;
														case 90:
															goto IL_06eb;
														case 43:
															goto IL_06f5;
														case 125:
															goto IL_0703;
														case 3:
															goto IL_0716;
														case 51:
															goto IL_0724;
														case 108:
															goto IL_0737;
														case 138:
															goto IL_0745;
														case 8:
														case 33:
															goto IL_0753;
														case 140:
															goto IL_0797;
														case 82:
															goto IL_07ab;
														case 78:
														case 105:
															goto IL_07be;
														case 32:
															goto IL_0807;
														case 26:
															goto IL_081b;
														case 21:
															goto IL_082e;
														case 20:
															goto IL_083c;
														case 63:
														case 97:
															goto IL_0847;
														case 113:
															goto IL_0863;
														case 120:
															goto IL_0871;
														case 22:
														case 59:
															goto IL_087f;
														case 17:
															goto IL_08ea;
														case 110:
															goto IL_08fd;
														case 131:
															goto IL_0908;
														case 2:
														case 5:
														case 11:
														case 14:
														case 15:
														case 24:
														case 28:
														case 36:
														case 38:
														case 42:
														case 53:
														case 55:
														case 60:
														case 72:
														case 76:
														case 77:
														case 79:
														case 83:
														case 96:
														case 101:
														case 107:
														case 112:
														case 132:
														case 135:
														case 139:
														case 143:
														case 144:
														case 145:
															goto IL_0913;
														case 12:
														case 119:
															goto IL_092b;
														}
														continue;
													}
													goto IL_0316;
													IL_087f:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													num = 17;
													goto IL_08ea;
													IL_08ea:
													num4 -= 2;
													goto IL_0316;
													IL_0316:
													if (num5 != 1)
													{
														goto IL_0326;
													}
													goto IL_092b;
													IL_092b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0326:
													b = *ptr2;
													num = 75;
													goto IL_0338;
													IL_0338:
													ptr2++;
													goto IL_0346;
													IL_0346:
													if (b >= 1)
													{
														goto IL_0354;
													}
													goto IL_0913;
													IL_0354:
													if (b <= 15)
													{
														goto IL_0362;
													}
													goto IL_0913;
													IL_0362:
													if (8 >= b)
													{
														goto IL_0370;
													}
													num = 34;
													goto IL_0685;
													IL_0370:
													if (8 <= b)
													{
														num = 46;
														goto IL_0384;
													}
													goto IL_039c;
													IL_0908:
													if (15 > b)
													{
													}
													goto IL_0913;
													IL_0384:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0316;
													IL_039c:
													if (4 >= b)
													{
														goto IL_03aa;
													}
													goto IL_053f;
													IL_03aa:
													if (4 > b)
													{
														goto IL_03b8;
													}
													goto IL_0500;
													IL_03b8:
													if (2 < b)
													{
														goto IL_03c3;
													}
													goto IL_0421;
													IL_03c3:
													if (3 >= b)
													{
														goto IL_03d1;
													}
													goto IL_0913;
													IL_03d1:
													if (3 <= b)
													{
														goto IL_03df;
													}
													goto IL_0913;
													IL_03df:
													array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_0408;
													IL_0408:
													array[num4 - 1] = 5;
													goto IL_0316;
													IL_0421:
													if (2 > b)
													{
														goto IL_042c;
													}
													goto IL_0499;
													IL_042c:
													if (1 >= b)
													{
														goto IL_043a;
													}
													goto IL_0913;
													IL_043a:
													if (1 <= b)
													{
														num = 9;
														goto IL_0451;
													}
													goto IL_0913;
													IL_0913:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0316;
													IL_0451:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_046a;
													IL_046a:
													array[num4] = 0;
													goto IL_0478;
													IL_0478:
													num4++;
													goto IL_0486;
													IL_0486:
													ptr2 += 8;
													goto IL_0316;
													IL_0499:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_04d9;
													IL_04d9:
													array[num4 - 2] = 0;
													goto IL_04ed;
													IL_04ed:
													num4--;
													goto IL_0316;
													IL_0500:
													array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
													goto IL_051e;
													IL_051e:
													ptr2 += 8;
													goto IL_052c;
													IL_052c:
													num4--;
													goto IL_0316;
													IL_053f:
													if (6 >= b)
													{
														goto IL_054d;
													}
													goto IL_0616;
													IL_054d:
													if (6 > b)
													{
														goto IL_0558;
													}
													goto IL_05bb;
													IL_0558:
													if (5 >= b)
													{
														goto IL_0566;
													}
													goto IL_0913;
													IL_0566:
													if (5 <= b)
													{
														goto IL_0574;
													}
													goto IL_0913;
													IL_0574:
													array[num4] = 5;
													goto IL_0582;
													IL_0582:
													array2[num4] = array5[*(int*)(ptr2 + num3)];
													goto IL_059a;
													IL_059a:
													num4++;
													goto IL_05a8;
													IL_05a8:
													ptr2 += 8;
													goto IL_0316;
													IL_05bb:
													((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_05fa;
													IL_05fa:
													num4 -= 3;
													num = 88;
													goto IL_0316;
													IL_0616:
													if (7 >= b)
													{
														goto IL_0624;
													}
													goto IL_0913;
													IL_0624:
													if (7 <= b)
													{
														goto IL_0632;
													}
													goto IL_0913;
													IL_0632:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_065b;
													IL_065b:
													ptr2 += 8;
													goto IL_0669;
													IL_0669:
													num4--;
													goto IL_0316;
													IL_08fd:
													if (15 >= b)
													{
														goto IL_0908;
													}
													goto IL_0913;
													IL_0685:
													if (12 >= b)
													{
														goto IL_0693;
													}
													goto IL_082e;
													IL_0693:
													if (12 > b)
													{
														goto IL_06a1;
													}
													goto IL_07be;
													IL_06a1:
													if (10 >= b)
													{
														goto IL_06af;
													}
													goto IL_0737;
													IL_06af:
													if (10 <= b)
													{
														goto IL_06ba;
													}
													goto IL_0716;
													IL_06ba:
													array[num4] = 0;
													goto IL_06c8;
													IL_06c8:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_06eb;
													IL_06eb:
													array2[num4] = null;
													goto IL_06f5;
													IL_06f5:
													num4++;
													goto IL_0703;
													IL_0703:
													ptr2 += 8;
													goto IL_0316;
													IL_0716:
													if (9 >= b)
													{
														goto IL_0724;
													}
													goto IL_0913;
													IL_0724:
													if (9 <= b)
													{
														goto IL_0316;
													}
													goto IL_0913;
													IL_0737:
													if (11 >= b)
													{
														goto IL_0745;
													}
													goto IL_0913;
													IL_0745:
													if (11 <= b)
													{
														goto IL_0753;
													}
													goto IL_0913;
													IL_0753:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
													goto IL_0797;
													IL_0797:
													array[num4 - 2] = 0;
													goto IL_07ab;
													IL_07ab:
													num4--;
													goto IL_0316;
													IL_07be:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													num = 32;
													goto IL_0807;
													IL_0807:
													array[num4 - 2] = 0;
													goto IL_081b;
													IL_081b:
													num4--;
													goto IL_0316;
													IL_082e:
													if (14 >= b)
													{
														goto IL_083c;
													}
													goto IL_08fd;
													IL_083c:
													if (14 <= b)
													{
														goto IL_0847;
													}
													goto IL_0863;
													IL_0847:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0316;
													IL_0863:
													if (13 >= b)
													{
														goto IL_0871;
													}
													goto IL_0913;
													IL_0871:
													if (13 <= b)
													{
														goto IL_087f;
													}
													goto IL_0913;
													continue;
													end_IL_026f:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_02cb:
							break;
						}
						continue;
						end_IL_02db:
						break;
					}
					continue;
					end_IL_02eb:
					break;
				}
				continue;
				end_IL_02fb:
				break;
			}
		}
	}

	private static void matchPurgeAuditRules(Class158 class158_1)
	{
		class158_1.method_1();
	}

	private static PhotonView NumOverflowNlsVersionInfoEx(NetworkView networkView_0)
	{
		return networkView_0.GetView;
	}

	private static void ProcessorFallbackListValidTRACEGUIDINFO()
	{
		Class9.smethod_82();
	}

	private unsafe string method_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_078d, IL_07a0, IL_07b9, IL_07c9, IL_07e4, IL_07f4, IL_0804, IL_0814, IL_0824, IL_0834, IL_0844, IL_0851, IL_0861, IL_0871, IL_0884, IL_0894, IL_08a4, IL_08b4, IL_08bf, IL_08e8, IL_0901, IL_094a, IL_095e, IL_0971, IL_0985, IL_09d9, IL_09f0, IL_0a03, IL_0a11, IL_0a1f, IL_0a2a, IL_0a3e, IL_0a7c, IL_0a8f, IL_0a9d, IL_0aa8, IL_0abc, IL_0afb, IL_0b17, IL_0b22, IL_0b30, IL_0b44, IL_0b88, IL_0b96, IL_0ba9, IL_0bb4, IL_0bc2, IL_0bd0, IL_0be3, IL_0bf1, IL_0bff, IL_0c18, IL_0c2b, IL_0c39, IL_0c44, IL_0c58, IL_0c97, IL_0caa, IL_0cb5, IL_0cc3, IL_0cdc, IL_0cef, IL_0cfa, IL_0d08, IL_0d11, IL_0d1f, IL_0d2d, IL_0d3b, IL_0d44, IL_0d4f, IL_0d7f, IL_0d8d, IL_0d9b, IL_0da9, IL_0db7, IL_0dc2, IL_0dd5, IL_0e1e, IL_0e32, IL_0e45, IL_0e53, IL_0e61, IL_0e75, IL_0ebd, IL_0ed0, IL_0ed9, IL_0f00, IL_0f0e, IL_0f1c, IL_0f2f, IL_0f3d, IL_0f4b, IL_0f56, IL_0f64, IL_0f78, IL_0fb7, IL_0fca, IL_0fd8, IL_0fe6, IL_0ffa, IL_1042, IL_1055, IL_1063, IL_106e, IL_1082, IL_10c1, IL_10d4, IL_10e2, IL_10f5, IL_1108, IL_1113, IL_111e, IL_112c, IL_1145, IL_1153, IL_1161, IL_117a, IL_118d, IL_11af, IL_11bd, IL_11cb, IL_11de, IL_11ec, IL_11ff, IL_1228, IL_1236, IL_1249, IL_125d, IL_129c, IL_12af, IL_131d, IL_1330, IL_133b, IL_1349, IL_135c, IL_136a, IL_13b6, IL_13c4, IL_13d7, IL_13f9, IL_1407, IL_1447, IL_145b, IL_146e, IL_147c, IL_1490, IL_14cf, IL_14e2, IL_14ff, IL_156a, IL_1578, IL_158b, IL_1599, IL_15ad, IL_15ec, IL_15ff, IL_1618, IL_162b, IL_163e, IL_1652, IL_1691, IL_16a4, IL_16e5, IL_16f3, IL_1733, IL_1747, IL_175a, IL_176d, IL_1789, IL_179d, IL_17dc, IL_17ef, IL_1802, IL_1810, IL_181e, IL_185e, IL_1872, IL_1885, IL_1893, IL_189e, IL_18de, IL_18f2, IL_1905, IL_1913, IL_1921, IL_192f, IL_1952, IL_195c, IL_1973, IL_1986, IL_1994, IL_19a2, IL_19e2, IL_19f6, IL_1a09, IL_1a17, IL_1a25, IL_1a33, IL_1a50, IL_1a9f, IL_1aa9, IL_1ad6, IL_1aea, IL_1af8, IL_1b0b, IL_1b19, IL_1b2c, IL_1b3a, IL_1b48, IL_1b66, IL_1b74, IL_1b87, IL_1b90, IL_1b9b, IL_1bfd, IL_1c10, IL_1c1b, IL_1c29, IL_1c3c, IL_1c4a, IL_1c58, IL_1c98, IL_1cac, IL_1cbf, IL_1ccd, IL_1cd8, IL_1d19, IL_1d2d, IL_1d40, IL_1d4e, IL_1d59, IL_1d97, IL_1daa, IL_1db8, IL_1dc6, IL_1dde, IL_1dfc, IL_1e20, IL_1e38, IL_1e4b, IL_1e59, IL_1e67, IL_1e75, IL_1e96, IL_1ea4, IL_1eb7, IL_1ec5, IL_1ed3, IL_1ee1, IL_1eef, IL_1ef8, IL_1f0c, IL_1f44, IL_1f57, IL_1f60, IL_1f79, IL_1f87, IL_1f95, IL_1fb1, IL_1fbf, IL_1fcd, IL_1fe5, IL_1ff3, IL_2001, IL_200f, IL_201a, IL_2038, IL_2046, IL_205d, IL_2070, IL_207e, IL_208c, IL_20de, IL_20f1, IL_20ff, IL_210d, IL_2140, IL_2159, IL_2184, IL_21a6, IL_21b4, IL_21c2, IL_21d0, IL_21de, IL_21f2, IL_2246, IL_2254, IL_2267, IL_22a0, IL_22bd, IL_22cd, IL_22d8, IL_22e3, IL_2301, IL_230f, IL_231d, IL_232d, IL_2340, IL_2353, IL_235d, IL_2368, IL_2378, IL_2388, IL_2398, IL_23a8, IL_23c1, IL_23d1, IL_23e1, IL_23f1, IL_240c are reachable both inside and outside the pinned region starting at IL_2406. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 258;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef69 = default(int);
			ref int reference = ref __rxRef69;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_23f1:
					num2 = 1;
					while (true)
					{
						IL_23e1:
						num3 = num2 * 4;
						while (true)
						{
							IL_23d1:
							num4 = num2 * 8;
							while (true)
							{
								IL_23c1:
								array2 = new byte[5];
								while (true)
								{
									IL_23a8:
									array3 = new object[5];
									num = 266;
									while (true)
									{
										IL_2398:
										array4 = new int[5];
										while (true)
										{
											IL_2388:
											array5 = new int[7];
											while (true)
											{
												IL_2378:
												array6 = new long[5];
												while (true)
												{
													IL_2368:
													array7 = new object[41];
													while (true)
													{
														IL_235d:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResourceManagerNeutralResourcesNotFoundShortInlineBrTarget.AccountDomainAdminsSidReadSubTree);
														while (true)
														{
															IL_2353:
															ptr2 = ptr;
															while (true)
															{
																IL_2340:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_08b4:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_08a4:
																			ptr2++;
																			while (true)
																			{
																				IL_0894:
																				if (b >= 1)
																				{
																					while (b <= 57)
																					{
																						while (true)
																						{
																							IL_0871:
																							if (29 >= b)
																							{
																								num = 210;
																								while (true)
																								{
																									IL_0861:
																									if (29 > b)
																									{
																										while (true)
																										{
																											IL_0851:
																											if (14 >= b)
																											{
																												while (true)
																												{
																													IL_0844:
																													if (14 > b)
																													{
																														while (true)
																														{
																															IL_0834:
																															if (7 >= b)
																															{
																																while (true)
																																{
																																	IL_0824:
																																	if (7 > b)
																																	{
																																		while (true)
																																		{
																																			IL_0814:
																																			if (3 >= b)
																																			{
																																				while (true)
																																				{
																																					IL_0804:
																																					if (3 > b)
																																					{
																																						while (true)
																																						{
																																							IL_07f4:
																																							if (1 >= b)
																																							{
																																								while (1 <= b)
																																								{
																																									while (true)
																																									{
																																										IL_07c9:
																																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																																										while (true)
																																										{
																																											IL_07b9:
																																											array2[num6] = 0;
																																											while (true)
																																											{
																																												IL_07a0:
																																												num6++;
																																												num = 476;
																																												while (true)
																																												{
																																													if (num != 476)
																																													{
																																														if (num != 1457)
																																														{
																																															break;
																																														}
																																														switch (num)
																																														{
																																														case 258:
																																															break;
																																														default:
																																															continue;
																																														case 101:
																																															goto IL_07a0;
																																														case 118:
																																															goto IL_07b9;
																																														case 137:
																																														case 379:
																																															goto IL_07c9;
																																														case 185:
																																															goto IL_07e4;
																																														case 410:
																																															goto IL_07f4;
																																														case 142:
																																															goto IL_0804;
																																														case 447:
																																															goto IL_0814;
																																														case 148:
																																															goto IL_0824;
																																														case 286:
																																															goto IL_0834;
																																														case 422:
																																															goto IL_0844;
																																														case 254:
																																															goto IL_0851;
																																														case 210:
																																															goto IL_0861;
																																														case 130:
																																															goto IL_0871;
																																														case 261:
																																															goto IL_0884;
																																														case 217:
																																															goto IL_0894;
																																														case 190:
																																															goto IL_08a4;
																																														case 2:
																																														case 309:
																																															goto IL_08b4;
																																														case 119:
																																														case 123:
																																															goto IL_08bf;
																																														case 223:
																																															goto IL_08e8;
																																														case 3:
																																														case 276:
																																															goto IL_0901;
																																														case 172:
																																															goto IL_094a;
																																														case 53:
																																															goto IL_095e;
																																														case 247:
																																														case 302:
																																															goto IL_0971;
																																														case 186:
																																															goto IL_0985;
																																														case 19:
																																															goto IL_09d9;
																																														case 215:
																																															goto IL_09f0;
																																														case 401:
																																															goto IL_0a03;
																																														case 307:
																																															goto IL_0a11;
																																														case 69:
																																															goto IL_0a1f;
																																														case 13:
																																														case 95:
																																															goto IL_0a2a;
																																														case 387:
																																															goto IL_0a3e;
																																														case 174:
																																															goto IL_0a7c;
																																														case 189:
																																															goto IL_0a8f;
																																														case 108:
																																															goto IL_0a9d;
																																														case 8:
																																														case 198:
																																															goto IL_0aa8;
																																														case 129:
																																															goto IL_0abc;
																																														case 219:
																																															goto IL_0afb;
																																														case 330:
																																															goto IL_0b17;
																																														case 289:
																																															goto IL_0b22;
																																														case 238:
																																														case 385:
																																															goto IL_0b30;
																																														case 111:
																																															goto IL_0b44;
																																														case 384:
																																															goto IL_0b88;
																																														case 296:
																																															goto IL_0b96;
																																														case 18:
																																															goto IL_0ba9;
																																														case 156:
																																															goto IL_0bb4;
																																														case 234:
																																															goto IL_0bc2;
																																														case 359:
																																															goto IL_0bd0;
																																														case 389:
																																															goto IL_0be3;
																																														case 113:
																																															goto IL_0bf1;
																																														case 85:
																																														case 117:
																																															goto IL_0bff;
																																														case 100:
																																															goto IL_0c18;
																																														case 74:
																																															goto IL_0c2b;
																																														case 259:
																																															goto IL_0c39;
																																														case 70:
																																														case 114:
																																															goto IL_0c44;
																																														case 30:
																																															goto IL_0c58;
																																														case 109:
																																															goto IL_0c97;
																																														case 341:
																																															goto IL_0caa;
																																														case 83:
																																															goto IL_0cb5;
																																														case 43:
																																														case 339:
																																															goto IL_0cc3;
																																														case 231:
																																															goto IL_0cdc;
																																														case 182:
																																															goto IL_0cef;
																																														case 338:
																																															goto IL_0cfa;
																																														case 249:
																																															goto IL_0d11;
																																														case 325:
																																															goto IL_0d44;
																																														case 128:
																																														case 255:
																																															goto IL_0d4f;
																																														case 362:
																																															goto IL_0d7f;
																																														case 301:
																																															goto IL_0d8d;
																																														case 225:
																																															goto IL_0d9b;
																																														case 157:
																																															goto IL_0da9;
																																														case 274:
																																															goto IL_0db7;
																																														case 178:
																																															goto IL_0dc2;
																																														case 370:
																																														case 375:
																																															goto IL_0dd5;
																																														case 318:
																																															goto IL_0e1e;
																																														case 121:
																																															goto IL_0e32;
																																														case 150:
																																															goto IL_0e45;
																																														case 356:
																																															goto IL_0e53;
																																														case 49:
																																														case 92:
																																															goto IL_0e61;
																																														case 213:
																																															goto IL_0e75;
																																														case 59:
																																															goto IL_0ebd;
																																														case 60:
																																														case 170:
																																															goto IL_0ed9;
																																														case 328:
																																															goto IL_0f00;
																																														case 399:
																																															goto IL_0f0e;
																																														case 327:
																																															goto IL_0f1c;
																																														case 392:
																																															goto IL_0f2f;
																																														case 244:
																																															goto IL_0f3d;
																																														case 126:
																																															goto IL_0f4b;
																																														case 282:
																																															goto IL_0f56;
																																														case 343:
																																														case 349:
																																															goto IL_0f64;
																																														case 122:
																																															goto IL_0f78;
																																														case 230:
																																															goto IL_0fb7;
																																														case 394:
																																															goto IL_0fca;
																																														case 221:
																																														case 290:
																																															goto IL_0fe6;
																																														case 187:
																																															goto IL_0ffa;
																																														case 32:
																																															goto IL_1042;
																																														case 191:
																																															goto IL_1055;
																																														case 214:
																																															goto IL_1063;
																																														case 196:
																																														case 239:
																																															goto IL_106e;
																																														case 271:
																																															goto IL_1082;
																																														case 317:
																																															goto IL_10c1;
																																														case 246:
																																															goto IL_10d4;
																																														case 171:
																																															goto IL_10e2;
																																														case 94:
																																															goto IL_10f5;
																																														case 403:
																																															goto IL_1108;
																																														case 396:
																																															goto IL_1113;
																																														case 14:
																																															goto IL_111e;
																																														case 98:
																																														case 331:
																																															goto IL_112c;
																																														case 299:
																																															goto IL_1145;
																																														case 9:
																																															goto IL_1153;
																																														case 146:
																																														case 201:
																																															goto IL_1161;
																																														case 38:
																																															goto IL_117a;
																																														case 80:
																																														case 167:
																																															goto IL_118d;
																																														case 124:
																																															goto IL_11af;
																																														case 206:
																																															goto IL_11bd;
																																														case 166:
																																															goto IL_11cb;
																																														case 405:
																																															goto IL_11de;
																																														case 5:
																																															goto IL_11ec;
																																														case 66:
																																														case 407:
																																															goto IL_11ff;
																																														case 67:
																																															goto IL_1228;
																																														case 371:
																																															goto IL_1236;
																																														case 139:
																																														case 416:
																																															goto IL_1249;
																																														case 28:
																																															goto IL_125d;
																																														case 298:
																																															goto end_IL_078d;
																																														case 42:
																																														case 418:
																																															goto IL_12af;
																																														case 91:
																																															goto IL_131d;
																																														case 425:
																																															goto IL_1330;
																																														case 420:
																																															goto IL_133b;
																																														case 12:
																																															goto IL_1349;
																																														case 426:
																																															goto IL_136a;
																																														case 350:
																																															goto IL_13b6;
																																														case 27:
																																															goto IL_13c4;
																																														case 428:
																																															goto IL_13d7;
																																														case 430:
																																															goto IL_13f9;
																																														case 175:
																																														case 270:
																																															goto IL_1407;
																																														case 235:
																																															goto IL_1447;
																																														case 1:
																																															goto IL_145b;
																																														case 433:
																																															goto IL_146e;
																																														case 264:
																																														case 398:
																																															goto IL_147c;
																																														case 197:
																																															goto IL_1490;
																																														case 84:
																																															goto IL_14cf;
																																														case 33:
																																														case 434:
																																															goto IL_14e2;
																																														case 133:
																																															goto IL_14ff;
																																														case 310:
																																															goto IL_156a;
																																														case 63:
																																															goto IL_1578;
																																														case 452:
																																															goto IL_158b;
																																														case 79:
																																														case 382:
																																															goto IL_1599;
																																														case 378:
																																															goto IL_15ad;
																																														case 205:
																																															goto IL_15ec;
																																														case 56:
																																														case 455:
																																															goto IL_15ff;
																																														case 347:
																																															goto IL_1618;
																																														case 456:
																																															goto IL_162b;
																																														case 199:
																																														case 457:
																																															goto IL_163e;
																																														case 222:
																																															goto IL_1652;
																																														case 361:
																																															goto IL_1691;
																																														case 461:
																																															goto IL_16a4;
																																														case 462:
																																															goto IL_16e5;
																																														case 7:
																																														case 138:
																																															goto IL_16f3;
																																														case 168:
																																															goto IL_1733;
																																														case 438:
																																															goto IL_1747;
																																														case 463:
																																															goto IL_175a;
																																														case 192:
																																														case 466:
																																															goto IL_176d;
																																														case 147:
																																														case 469:
																																															goto IL_1789;
																																														case 314:
																																															goto IL_179d;
																																														case 312:
																																															goto IL_17dc;
																																														case 165:
																																															goto IL_1802;
																																														case 321:
																																															goto IL_1810;
																																														case 26:
																																														case 173:
																																															goto IL_181e;
																																														case 10:
																																															goto IL_185e;
																																														case 402:
																																															goto IL_1872;
																																														case 340:
																																															goto IL_1885;
																																														case 364:
																																															goto IL_1893;
																																														case 383:
																																														case 446:
																																															goto IL_189e;
																																														case 16:
																																															goto IL_18de;
																																														case 40:
																																															goto IL_18f2;
																																														case 41:
																																															goto IL_1905;
																																														case 90:
																																															goto IL_1913;
																																														case 127:
																																														case 441:
																																															goto IL_1921;
																																														case 256:
																																															goto IL_192f;
																																														case 243:
																																															goto IL_1952;
																																														case 423:
																																															goto IL_195c;
																																														case 58:
																																															goto IL_1973;
																																														case 265:
																																															goto IL_1986;
																																														case 208:
																																															goto IL_1994;
																																														case 93:
																																														case 250:
																																															goto IL_19a2;
																																														case 86:
																																															goto IL_19e2;
																																														case 134:
																																															goto IL_19f6;
																																														case 194:
																																															goto IL_1a09;
																																														case 160:
																																															goto IL_1a17;
																																														case 291:
																																															goto IL_1a25;
																																														case 369:
																																														case 395:
																																															goto IL_1a33;
																																														case 181:
																																															goto IL_1aea;
																																														case 226:
																																															goto IL_1af8;
																																														case 391:
																																															goto IL_1b0b;
																																														case 464:
																																															goto IL_1b19;
																																														case 103:
																																															goto IL_1b2c;
																																														case 55:
																																															goto IL_1b3a;
																																														case 31:
																																														case 218:
																																															goto IL_1b48;
																																														case 143:
																																															goto IL_1b66;
																																														case 20:
																																															goto IL_1b74;
																																														case 78:
																																															goto IL_1b90;
																																														case 164:
																																														case 306:
																																															goto IL_1b9b;
																																														case 57:
																																															goto IL_1bfd;
																																														case 61:
																																															goto IL_1c10;
																																														case 233:
																																															goto IL_1c1b;
																																														case 304:
																																														case 332:
																																															goto IL_1c29;
																																														case 351:
																																															goto IL_1c3c;
																																														case 22:
																																															goto IL_1c4a;
																																														case 358:
																																														case 380:
																																															goto IL_1c58;
																																														case 211:
																																															goto IL_1c98;
																																														case 36:
																																															goto IL_1cac;
																																														case 439:
																																															goto IL_1cbf;
																																														case 140:
																																															goto IL_1ccd;
																																														case 65:
																																														case 323:
																																															goto IL_1cd8;
																																														case 363:
																																															goto IL_1d19;
																																														case 135:
																																															goto IL_1d2d;
																																														case 207:
																																															goto IL_1d40;
																																														case 237:
																																															goto IL_1d4e;
																																														case 248:
																																														case 329:
																																															goto IL_1d59;
																																														case 427:
																																															goto IL_1d97;
																																														case 458:
																																															goto IL_1daa;
																																														case 68:
																																															goto IL_1db8;
																																														case 72:
																																														case 292:
																																															goto IL_1dc6;
																																														case 326:
																																															goto IL_1dde;
																																														case 75:
																																															goto IL_1dfc;
																																														case 52:
																																															goto IL_1e20;
																																														case 176:
																																															goto IL_1e38;
																																														case 227:
																																															goto IL_1e4b;
																																														case 203:
																																															goto IL_1e59;
																																														case 324:
																																														case 365:
																																															goto IL_1e67;
																																														case 47:
																																															goto IL_1e75;
																																														case 4:
																																															goto IL_1e96;
																																														case 397:
																																															goto IL_1ea4;
																																														case 25:
																																															goto IL_1eb7;
																																														case 71:
																																															goto IL_1ec5;
																																														case 158:
																																															goto IL_1ed3;
																																														case 162:
																																															goto IL_1ee1;
																																														case 132:
																																														case 381:
																																															goto IL_1ef8;
																																														case 345:
																																															goto IL_1f0c;
																																														case 15:
																																															goto IL_1f44;
																																														case 153:
																																														case 297:
																																															goto IL_1f60;
																																														case 313:
																																															goto IL_1f79;
																																														case 177:
																																															goto IL_1f87;
																																														case 149:
																																															goto IL_1f95;
																																														case 180:
																																															goto IL_1fb1;
																																														case 46:
																																															goto IL_1fbf;
																																														case 96:
																																														case 110:
																																															goto IL_1fcd;
																																														case 366:
																																															goto IL_1fe5;
																																														case 393:
																																															goto IL_1ff3;
																																														case 333:
																																															goto IL_2001;
																																														case 145:
																																															goto IL_200f;
																																														case 159:
																																														case 251:
																																															goto IL_201a;
																																														case 107:
																																															goto IL_2038;
																																														case 390:
																																															goto IL_2046;
																																														case 37:
																																															goto IL_205d;
																																														case 262:
																																															goto IL_2070;
																																														case 48:
																																															goto IL_207e;
																																														case 224:
																																														case 406:
																																															goto IL_208c;
																																														case 242:
																																															goto IL_20de;
																																														case 240:
																																															goto IL_20f1;
																																														case 120:
																																															goto IL_20ff;
																																														case 188:
																																														case 411:
																																															goto IL_210d;
																																														case 344:
																																															goto IL_2140;
																																														case 21:
																																														case 115:
																																															goto IL_2159;
																																														case 195:
																																															goto IL_2184;
																																														case 45:
																																															goto IL_21a6;
																																														case 99:
																																															goto IL_21b4;
																																														case 245:
																																															goto IL_21c2;
																																														case 220:
																																															goto IL_21d0;
																																														case 229:
																																														case 319:
																																															goto IL_21de;
																																														case 348:
																																															goto IL_21f2;
																																														case 44:
																																															goto IL_2246;
																																														case 285:
																																															goto IL_2254;
																																														case 6:
																																														case 155:
																																															goto IL_2267;
																																														case 64:
																																															goto IL_22a0;
																																														case 131:
																																															goto IL_22bd;
																																														case 284:
																																															goto IL_22cd;
																																														case 308:
																																															goto IL_22d8;
																																														case 212:
																																														case 293:
																																															goto IL_22e3;
																																														case 24:
																																															goto IL_2301;
																																														case 419:
																																															goto IL_230f;
																																														case 184:
																																															goto IL_231d;
																																														case 0:
																																														case 23:
																																														case 29:
																																														case 35:
																																														case 62:
																																														case 77:
																																														case 81:
																																														case 82:
																																														case 87:
																																														case 88:
																																														case 104:
																																														case 105:
																																														case 112:
																																														case 125:
																																														case 136:
																																														case 152:
																																														case 154:
																																														case 179:
																																														case 193:
																																														case 200:
																																														case 204:
																																														case 228:
																																														case 232:
																																														case 236:
																																														case 260:
																																														case 268:
																																														case 269:
																																														case 275:
																																														case 277:
																																														case 278:
																																														case 279:
																																														case 287:
																																														case 288:
																																														case 294:
																																														case 300:
																																														case 303:
																																														case 305:
																																														case 311:
																																														case 315:
																																														case 316:
																																														case 335:
																																														case 336:
																																														case 342:
																																														case 346:
																																														case 353:
																																														case 367:
																																														case 372:
																																														case 386:
																																														case 408:
																																														case 409:
																																														case 414:
																																														case 429:
																																														case 435:
																																														case 444:
																																														case 450:
																																														case 453:
																																														case 454:
																																														case 459:
																																														case 460:
																																														case 465:
																																															goto end_IL_07e4;
																																														case 11:
																																														case 17:
																																														case 34:
																																														case 39:
																																														case 50:
																																														case 51:
																																														case 54:
																																														case 73:
																																														case 76:
																																														case 89:
																																														case 97:
																																														case 102:
																																														case 106:
																																														case 116:
																																														case 141:
																																														case 144:
																																														case 151:
																																														case 161:
																																														case 169:
																																														case 183:
																																														case 202:
																																														case 209:
																																														case 216:
																																														case 252:
																																														case 253:
																																														case 263:
																																														case 272:
																																														case 273:
																																														case 280:
																																														case 281:
																																														case 283:
																																														case 295:
																																														case 320:
																																														case 337:
																																														case 352:
																																														case 354:
																																														case 355:
																																														case 357:
																																														case 360:
																																														case 373:
																																														case 374:
																																														case 376:
																																														case 377:
																																														case 388:
																																														case 400:
																																														case 404:
																																														case 415:
																																														case 417:
																																														case 421:
																																														case 424:
																																														case 431:
																																														case 436:
																																														case 437:
																																														case 440:
																																														case 443:
																																														case 445:
																																														case 448:
																																														case 451:
																																														case 467:
																																														case 468:
																																															goto IL_2340;
																																														case 334:
																																															goto IL_2353;
																																														case 432:
																																															goto IL_235d;
																																														case 267:
																																															goto IL_2368;
																																														case 412:
																																															goto IL_2378;
																																														case 442:
																																															goto IL_2388;
																																														case 266:
																																															goto IL_2398;
																																														case 241:
																																															goto IL_23a8;
																																														case 322:
																																															goto IL_23c1;
																																														case 413:
																																															goto IL_23d1;
																																														case 449:
																																															goto IL_23e1;
																																														case 257:
																																															goto IL_23f1;
																																														case 163:
																																														case 368:
																																															goto IL_240c;
																																														}
																																														goto end_IL_0894;
																																													}
																																													ptr2 += 8;
																																													goto IL_2340;
																																													continue;
																																													end_IL_078d:
																																													break;
																																												}
																																												break;
																																											}
																																											break;
																																										}
																																										break;
																																									}
																																									goto IL_129c;
																																									continue;
																																									end_IL_07e4:
																																									break;
																																									IL_07e4:;
																																								}
																																								break;
																																							}
																																							goto IL_1802;
																																							IL_1872:
																																							num6--;
																																							goto IL_2340;
																																							IL_1802:
																																							if (2 < b)
																																							{
																																								break;
																																							}
																																							goto IL_1810;
																																							IL_1810:
																																							if (2 > b)
																																							{
																																								break;
																																							}
																																							goto IL_181e;
																																							IL_181e:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																							goto IL_185e;
																																							IL_185e:
																																							array2[num6 - 2] = 0;
																																							goto IL_1872;
																																						}
																																						break;
																																					}
																																					goto IL_11ff;
																																					IL_1236:
																																					num6--;
																																					goto IL_2340;
																																					IL_11ff:
																																					reference = ref array5[*(int*)(ptr2 + num3)];
																																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																					goto IL_1228;
																																					IL_1228:
																																					ptr2 += 8;
																																					goto IL_1236;
																																				}
																																				break;
																																			}
																																			goto IL_1885;
																																			IL_19f6:
																																			num6--;
																																			goto IL_2340;
																																			IL_1885:
																																			if (5 >= b)
																																			{
																																				goto IL_1893;
																																			}
																																			goto IL_1986;
																																			IL_1893:
																																			if (5 <= b)
																																			{
																																				goto IL_189e;
																																			}
																																			goto IL_1905;
																																			IL_189e:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																			goto IL_18de;
																																			IL_18de:
																																			array2[num6 - 2] = 0;
																																			goto IL_18f2;
																																			IL_18f2:
																																			num6--;
																																			goto IL_2340;
																																			IL_1905:
																																			if (4 < b)
																																			{
																																				break;
																																			}
																																			goto IL_1913;
																																			IL_1913:
																																			if (4 > b)
																																			{
																																				break;
																																			}
																																			goto IL_1921;
																																			IL_1921:
																																			array2[num6] = 0;
																																			goto IL_192f;
																																			IL_192f:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																			goto IL_1952;
																																			IL_1952:
																																			array3[num6] = null;
																																			goto IL_195c;
																																			IL_195c:
																																			num6++;
																																			num = 58;
																																			goto IL_1973;
																																			IL_1973:
																																			ptr2 += 8;
																																			goto IL_2340;
																																			IL_1986:
																																			if (6 < b)
																																			{
																																				break;
																																			}
																																			goto IL_1994;
																																			IL_1994:
																																			if (6 > b)
																																			{
																																				break;
																																			}
																																			goto IL_19a2;
																																			IL_19a2:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																			goto IL_19e2;
																																			IL_19e2:
																																			array2[num6 - 2] = 0;
																																			goto IL_19f6;
																																		}
																																		break;
																																	}
																																	goto IL_0901;
																																	IL_095e:
																																	num6--;
																																	goto IL_2340;
																																	IL_0901:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	num = 172;
																																	goto IL_094a;
																																	IL_094a:
																																	array2[num6 - 2] = 0;
																																	goto IL_095e;
																																}
																																break;
																															}
																															goto IL_1a09;
																															IL_1c3c:
																															if (9 < b)
																															{
																																break;
																															}
																															goto IL_1c4a;
																															IL_1a09:
																															if (10 < b)
																															{
																																goto IL_1a17;
																															}
																															num = 78;
																															goto IL_1b90;
																															IL_1a17:
																															if (12 >= b)
																															{
																																goto IL_1a25;
																															}
																															goto IL_1b2c;
																															IL_1a25:
																															if (12 <= b)
																															{
																																goto IL_1a33;
																															}
																															goto IL_1b0b;
																															IL_1a33:
																															array8 = array3;
																															num7 = num6;
																															if (array == null)
																															{
																																goto IL_1a42;
																															}
																															num8 = ptr2;
																															byte b2 = *num8;
																															ptr2 = num8 + 4;
																															int num9 = *(int*)(ptr2 + num3);
																															ptr2 += 8;
																															byte* ptr3 = ptr2 + num9;
																															byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																															while (ptr2 != ptr3)
																															{
																																*ptr4 = (byte)(*ptr2 ^ b2);
																																ptr2++;
																																ptr4++;
																															}
																															array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																															goto IL_1aea;
																															IL_1c58:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_1c98;
																															IL_1c98:
																															array2[num6 - 2] = 0;
																															goto IL_1cac;
																															IL_1cac:
																															num6--;
																															goto IL_2340;
																															IL_1aea:
																															array2[num6] = 5;
																															goto IL_1af8;
																															IL_1af8:
																															num6++;
																															goto IL_2340;
																															IL_1b0b:
																															if (11 < b)
																															{
																																break;
																															}
																															goto IL_1b19;
																															IL_1b19:
																															if (11 > b)
																															{
																																break;
																															}
																															goto IL_2340;
																															IL_1b2c:
																															if (13 < b)
																															{
																																break;
																															}
																															goto IL_1b3a;
																															IL_1b3a:
																															if (13 > b)
																															{
																																break;
																															}
																															goto IL_1b48;
																															IL_1b48:
																															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																															goto IL_1b66;
																															IL_1b66:
																															ptr2 += 8;
																															goto IL_1b74;
																															IL_1b74:
																															num6--;
																															goto IL_2340;
																															IL_1c4a:
																															if (9 > b)
																															{
																																break;
																															}
																															goto IL_1c58;
																															IL_1b90:
																															if (10 <= b)
																															{
																																goto IL_1b9b;
																															}
																															goto IL_1c10;
																															IL_1b9b:
																															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_1bfd;
																															IL_1bfd:
																															num6 -= 2;
																															goto IL_2340;
																															IL_1c10:
																															if (8 >= b)
																															{
																																goto IL_1c1b;
																															}
																															goto IL_1c3c;
																															IL_1c1b:
																															if (8 > b)
																															{
																																break;
																															}
																															goto IL_1c29;
																															IL_1c29:
																															num6--;
																															goto IL_2340;
																														}
																														break;
																													}
																													goto IL_08bf;
																													IL_08e8:
																													array2[num6 - 1] = 5;
																													goto IL_2340;
																													IL_08bf:
																													array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													goto IL_08e8;
																												}
																												break;
																											}
																											goto IL_1cbf;
																											IL_2301:
																											array2[num6] = 5;
																											goto IL_230f;
																											IL_1cbf:
																											if (21 >= b)
																											{
																												goto IL_1ccd;
																											}
																											goto IL_1fe5;
																											IL_1ccd:
																											if (21 <= b)
																											{
																												goto IL_1cd8;
																											}
																											goto IL_1d40;
																											IL_1cd8:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																											goto IL_1d19;
																											IL_1d19:
																											array2[num6 - 2] = 0;
																											goto IL_1d2d;
																											IL_1d2d:
																											num6--;
																											goto IL_2340;
																											IL_1d40:
																											if (17 >= b)
																											{
																												goto IL_1d4e;
																											}
																											goto IL_1eb7;
																											IL_1d4e:
																											if (17 <= b)
																											{
																												goto IL_1d59;
																											}
																											goto IL_1daa;
																											IL_1d59:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											goto IL_1d97;
																											IL_1d97:
																											num6 -= 3;
																											goto IL_2340;
																											IL_1daa:
																											if (15 >= b)
																											{
																												goto IL_1db8;
																											}
																											goto IL_1e4b;
																											IL_1db8:
																											if (15 > b)
																											{
																												break;
																											}
																											goto IL_1dc6;
																											IL_1dc6:
																											array2[num6] = array2[num6 - 1];
																											goto IL_1dde;
																											IL_1dde:
																											array4[num6 - 0] = array4[num6 - 1];
																											goto IL_1dfc;
																											IL_1dfc:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1e20;
																											IL_1e20:
																											array3[num6] = array3[num6 - 1];
																											goto IL_1e38;
																											IL_1e38:
																											num6++;
																											goto IL_2340;
																											IL_1e4b:
																											if (16 < b)
																											{
																												break;
																											}
																											goto IL_1e59;
																											IL_1e59:
																											if (16 > b)
																											{
																												break;
																											}
																											goto IL_1e67;
																											IL_1e67:
																											array2[num6] = 5;
																											goto IL_1e75;
																											IL_1e75:
																											array3[num6] = array7[*(int*)(ptr2 + num3)];
																											num = 4;
																											goto IL_1e96;
																											IL_1e96:
																											num6++;
																											goto IL_1ea4;
																											IL_1ea4:
																											ptr2 += 8;
																											goto IL_2340;
																											IL_1eb7:
																											if (19 >= b)
																											{
																												goto IL_1ec5;
																											}
																											goto IL_1fb1;
																											IL_1ec5:
																											if (19 > b)
																											{
																												goto IL_1ed3;
																											}
																											num = 153;
																											goto IL_1f60;
																											IL_1ed3:
																											if (18 < b)
																											{
																												break;
																											}
																											goto IL_1ee1;
																											IL_1ee1:
																											if (18 > b)
																											{
																												break;
																											}
																											num = 132;
																											goto IL_1ef8;
																											IL_231d:
																											ptr2 += 8;
																											goto IL_2340;
																											IL_1ef8:
																											array2[num6 - 1] = 5;
																											goto IL_1f0c;
																											IL_1f0c:
																											array3[num6 - 1] = ((delegate*<string[], string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																											goto IL_1f44;
																											IL_1f44:
																											ptr2 += 8;
																											goto IL_2340;
																											IL_230f:
																											num6++;
																											goto IL_231d;
																											IL_1f60:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											goto IL_1f79;
																											IL_1f79:
																											array2[num6] = 1;
																											goto IL_1f87;
																											IL_1f87:
																											num6++;
																											goto IL_1f95;
																											IL_1f95:
																											ptr2 += 16;
																											num = 417;
																											goto IL_2340;
																											IL_1fb1:
																											if (20 < b)
																											{
																												break;
																											}
																											goto IL_1fbf;
																											IL_1fbf:
																											if (20 > b)
																											{
																												break;
																											}
																											goto IL_1fcd;
																											IL_1fcd:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_2340;
																											IL_1fe5:
																											if (25 >= b)
																											{
																												goto IL_1ff3;
																											}
																											goto IL_21a6;
																											IL_1ff3:
																											if (25 > b)
																											{
																												goto IL_2001;
																											}
																											goto IL_2159;
																											IL_2001:
																											if (23 >= b)
																											{
																												goto IL_200f;
																											}
																											goto IL_20f1;
																											IL_200f:
																											if (23 <= b)
																											{
																												goto IL_201a;
																											}
																											goto IL_2070;
																											IL_201a:
																											array3[num6] = ((delegate*<string[]>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
																											goto IL_2038;
																											IL_2038:
																											array2[num6] = 5;
																											goto IL_2046;
																											IL_2046:
																											num6++;
																											num = 37;
																											goto IL_205d;
																											IL_205d:
																											ptr2 += 8;
																											goto IL_2340;
																											IL_2070:
																											if (22 < b)
																											{
																												break;
																											}
																											goto IL_207e;
																											IL_207e:
																											if (22 > b)
																											{
																												break;
																											}
																											goto IL_208c;
																											IL_208c:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_20de;
																											IL_20de:
																											num6--;
																											goto IL_2340;
																											IL_20f1:
																											if (24 < b)
																											{
																												break;
																											}
																											goto IL_20ff;
																											IL_20ff:
																											if (24 > b)
																											{
																												break;
																											}
																											goto IL_210d;
																											IL_210d:
																											*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((string[])array3[num6 - 1]).LongLength;
																											num = 344;
																											goto IL_2140;
																											IL_2140:
																											array2[num6 - 1] = 2;
																											goto IL_2340;
																											IL_2159:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_2184;
																											IL_2184:
																											array2[num6 - 1] = 0;
																											num = 50;
																											goto IL_2340;
																											IL_21a6:
																											if (27 >= b)
																											{
																												goto IL_21b4;
																											}
																											goto IL_22cd;
																											IL_21b4:
																											if (27 > b)
																											{
																												goto IL_21c2;
																											}
																											goto IL_2267;
																											IL_21c2:
																											if (26 < b)
																											{
																												break;
																											}
																											goto IL_21d0;
																											IL_21d0:
																											if (26 > b)
																											{
																												break;
																											}
																											goto IL_21de;
																											IL_21de:
																											array2[num6 - 2] = 0;
																											goto IL_21f2;
																											IL_21f2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_2246;
																											IL_2246:
																											num6--;
																											goto IL_2254;
																											IL_2254:
																											ptr2 += 8;
																											goto IL_2340;
																											IL_2267:
																											array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																											goto IL_22a0;
																											IL_22a0:
																											array2[num6 - 2] = 5;
																											num = 131;
																											goto IL_22bd;
																											IL_22bd:
																											num6--;
																											goto IL_2340;
																											IL_22cd:
																											if (28 < b)
																											{
																												break;
																											}
																											goto IL_22d8;
																											IL_22d8:
																											if (28 > b)
																											{
																												break;
																											}
																											goto IL_22e3;
																											IL_22e3:
																											array3[num6] = ((delegate*<string[]>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
																											goto IL_2301;
																										}
																										break;
																									}
																									goto IL_0971;
																									IL_09f0:
																									ptr2 += 8;
																									goto IL_2340;
																									IL_0971:
																									array2[num6 - 2] = 0;
																									goto IL_0985;
																									IL_0985:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_09d9;
																									IL_09d9:
																									num6--;
																									num = 215;
																									goto IL_09f0;
																								}
																								break;
																							}
																							goto IL_0a03;
																							IL_14e2:
																							array2[num6 - 3] = 5;
																							num = 133;
																							goto IL_14ff;
																							IL_14ff:
																							array3[num6 - 3] = ((delegate*<string, int, int, string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 3], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							num = 310;
																							goto IL_156a;
																							IL_0a03:
																							if (43 < b)
																							{
																								goto IL_0a11;
																							}
																							num = 325;
																							goto IL_0d44;
																							IL_0a11:
																							if (50 >= b)
																							{
																								goto IL_0a1f;
																							}
																							goto IL_0c2b;
																							IL_0a1f:
																							if (50 <= b)
																							{
																								goto IL_0a2a;
																							}
																							goto IL_0a8f;
																							IL_0a2a:
																							array2[num6 - 1] = 0;
																							goto IL_0a3e;
																							IL_0a3e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<string, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																							goto IL_0a7c;
																							IL_0a7c:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0a8f:
																							if (46 >= b)
																							{
																								goto IL_0a9d;
																							}
																							goto IL_0ba9;
																							IL_0a9d:
																							if (46 <= b)
																							{
																								goto IL_0aa8;
																							}
																							goto IL_0b17;
																							IL_0aa8:
																							array2[num6 - 1] = 3;
																							goto IL_0abc;
																							IL_0abc:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0afb;
																							IL_0afb:
																							ptr2 += 8;
																							num = 468;
																							goto IL_2340;
																							IL_0b17:
																							if (44 >= b)
																							{
																								goto IL_0b22;
																							}
																							goto IL_0b88;
																							IL_0b22:
																							if (44 > b)
																							{
																								break;
																							}
																							goto IL_0b30;
																							IL_0b30:
																							array2[num6 - 1] = 3;
																							goto IL_0b44;
																							IL_0b44:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_162b;
																							IL_162b:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0b88:
																							if (45 < b)
																							{
																								break;
																							}
																							goto IL_0b96;
																							IL_0b96:
																							if (45 > b)
																							{
																								break;
																							}
																							goto IL_1249;
																							IL_1249:
																							array2[num6 - 1] = 0;
																							goto IL_125d;
																							IL_125d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_129c;
																							IL_129c:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0ba9:
																							if (48 >= b)
																							{
																								goto IL_0bb4;
																							}
																							goto IL_0be3;
																							IL_0bb4:
																							if (48 > b)
																							{
																								goto IL_0bc2;
																							}
																							goto IL_1789;
																							IL_0bc2:
																							if (47 < b)
																							{
																								break;
																							}
																							goto IL_0bd0;
																							IL_0bd0:
																							if (47 > b)
																							{
																								break;
																							}
																							goto IL_163e;
																							IL_163e:
																							array2[num6 - 1] = 3;
																							goto IL_1652;
																							IL_1652:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1691;
																							IL_1691:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_1789:
																							array2[num6 - 1] = 3;
																							goto IL_179d;
																							IL_179d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_17dc;
																							IL_17dc:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0be3:
																							if (49 < b)
																							{
																								break;
																							}
																							goto IL_0bf1;
																							IL_0bf1:
																							if (49 > b)
																							{
																								break;
																							}
																							goto IL_0bff;
																							IL_0bff:
																							global::_003CModule_003E.string_47 = (string[])array3[num6 - 1];
																							goto IL_0c18;
																							IL_0c18:
																							num6--;
																							goto IL_2340;
																							IL_0c2b:
																							if (54 >= b)
																							{
																								goto IL_0c39;
																							}
																							goto IL_0cef;
																							IL_0c39:
																							if (54 <= b)
																							{
																								goto IL_0c44;
																							}
																							goto IL_0caa;
																							IL_0c44:
																							array2[num6 - 1] = 3;
																							goto IL_0c58;
																							IL_0c58:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0c97;
																							IL_0c97:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0caa:
																							if (52 >= b)
																							{
																								goto IL_0cb5;
																							}
																							goto IL_0cdc;
																							IL_0cb5:
																							if (52 <= b)
																							{
																								goto IL_0cc3;
																							}
																							goto IL_11de;
																							IL_0cc3:
																							array2[num6 - 1] = 3;
																							goto IL_16a4;
																							IL_16a4:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_175a;
																							IL_175a:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_11de:
																							if (51 < b)
																							{
																								break;
																							}
																							goto IL_11ec;
																							IL_11ec:
																							if (51 > b)
																							{
																								break;
																							}
																							goto IL_12af;
																							IL_12af:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_131d;
																							IL_131d:
																							num6 -= 2;
																							goto IL_2340;
																							IL_0cdc:
																							if (53 < b)
																							{
																								break;
																							}
																							goto IL_158b;
																							IL_158b:
																							if (53 > b)
																							{
																								break;
																							}
																							goto IL_1599;
																							IL_1599:
																							array2[num6 - 1] = 3;
																							goto IL_15ad;
																							IL_15ad:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_15ec;
																							IL_15ec:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0cef:
																							if (56 < b)
																							{
																								goto IL_0cfa;
																							}
																							num = 425;
																							goto IL_1330;
																							IL_0cfa:
																							if (57 < b)
																							{
																								break;
																							}
																							num = 249;
																							goto IL_0d11;
																							IL_10f5:
																							if (42 < b)
																							{
																								break;
																							}
																							goto IL_16e5;
																							IL_0d11:
																							if (57 <= b)
																							{
																								num = 342;
																							}
																							break;
																							IL_16e5:
																							if (42 > b)
																							{
																								break;
																							}
																							goto IL_16f3;
																							IL_1578:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_1330:
																							if (56 > b)
																							{
																								goto IL_133b;
																							}
																							num = 466;
																							goto IL_176d;
																							IL_133b:
																							if (55 < b)
																							{
																								break;
																							}
																							goto IL_1349;
																							IL_1349:
																							if (55 > b)
																							{
																								break;
																							}
																							goto IL_15ff;
																							IL_15ff:
																							global::_003CModule_003E.string_46 = (string[])array3[num6 - 1];
																							goto IL_1618;
																							IL_1618:
																							num6--;
																							goto IL_2340;
																							IL_16f3:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1733;
																							IL_176d:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto IL_2340;
																							IL_156a:
																							num6 -= 2;
																							goto IL_1578;
																							IL_0d44:
																							if (43 <= b)
																							{
																								goto IL_0d4f;
																							}
																							goto IL_0d7f;
																							IL_0d4f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_13d7;
																							IL_13d7:
																							array2[num6 - 1] = 0;
																							num = 357;
																							goto IL_2340;
																							IL_0d7f:
																							if (36 >= b)
																							{
																								goto IL_0d8d;
																							}
																							goto IL_0f2f;
																							IL_0d8d:
																							if (36 > b)
																							{
																								goto IL_0d9b;
																							}
																							num = 170;
																							goto IL_0ed9;
																							IL_0d9b:
																							if (32 < b)
																							{
																								goto IL_0da9;
																							}
																							goto IL_1108;
																							IL_0da9:
																							if (34 >= b)
																							{
																								goto IL_0db7;
																							}
																							goto IL_0e45;
																							IL_0db7:
																							if (34 > b)
																							{
																								goto IL_0dc2;
																							}
																							goto IL_0dd5;
																							IL_0dc2:
																							if (33 < b)
																							{
																								break;
																							}
																							goto IL_146e;
																							IL_146e:
																							if (33 > b)
																							{
																								break;
																							}
																							goto IL_147c;
																							IL_147c:
																							array2[num6 - 1] = 3;
																							goto IL_1490;
																							IL_1490:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_14cf;
																							IL_14cf:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0dd5:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 318;
																							goto IL_0e1e;
																							IL_0e1e:
																							array2[num6 - 2] = 3;
																							goto IL_0e32;
																							IL_0e32:
																							num6--;
																							goto IL_2340;
																							IL_0e45:
																							if (35 < b)
																							{
																								break;
																							}
																							goto IL_0e53;
																							IL_0e53:
																							if (35 > b)
																							{
																								break;
																							}
																							goto IL_0e61;
																							IL_0e61:
																							array2[num6 - 1] = 0;
																							goto IL_0e75;
																							IL_0e75:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							num = 59;
																							goto IL_0ebd;
																							IL_0ebd:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_1108:
																							if (32 > b)
																							{
																								goto IL_1113;
																							}
																							goto IL_118d;
																							IL_1113:
																							if (30 >= b)
																							{
																								goto IL_111e;
																							}
																							goto IL_1145;
																							IL_111e:
																							if (30 > b)
																							{
																								break;
																							}
																							goto IL_112c;
																							IL_112c:
																							array2[num6 - 2] = 5;
																							goto IL_136a;
																							IL_136a:
																							array3[num6 - 2] = ((delegate*<string, string, string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																							goto IL_13b6;
																							IL_13b6:
																							num6--;
																							goto IL_13c4;
																							IL_13c4:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_1145:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_1153;
																							IL_1153:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_1161;
																							IL_1161:
																							global::_003CModule_003E.string_48 = (string)array3[num6 - 1];
																							goto IL_117a;
																							IL_117a:
																							num6--;
																							goto IL_2340;
																							IL_118d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							num = 124;
																							goto IL_11af;
																							IL_11af:
																							array2[num6] = 3;
																							goto IL_11bd;
																							IL_11bd:
																							num6++;
																							goto IL_11cb;
																							IL_11cb:
																							ptr2 += 16;
																							goto IL_2340;
																							IL_1733:
																							array2[num6 - 2] = 3;
																							goto IL_1747;
																							IL_0ed9:
																							array3[num6] = ((delegate*<string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
																							num = 328;
																							goto IL_0f00;
																							IL_0f00:
																							array2[num6] = 5;
																							goto IL_0f0e;
																							IL_0f0e:
																							num6++;
																							goto IL_0f1c;
																							IL_0f1c:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0f2f:
																							if (39 >= b)
																							{
																								goto IL_0f3d;
																							}
																							goto IL_1055;
																							IL_0f3d:
																							if (39 > b)
																							{
																								goto IL_0f4b;
																							}
																							goto IL_0fe6;
																							IL_0f4b:
																							if (37 >= b)
																							{
																								goto IL_0f56;
																							}
																							goto IL_0fca;
																							IL_0f56:
																							if (37 > b)
																							{
																								break;
																							}
																							goto IL_0f64;
																							IL_0f64:
																							array2[num6 - 1] = 3;
																							goto IL_0f78;
																							IL_0f78:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_0fb7;
																							IL_0fb7:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_0fca:
																							if (38 < b)
																							{
																								break;
																							}
																							num = 430;
																							goto IL_13f9;
																							IL_1747:
																							num6--;
																							goto IL_2340;
																							IL_13f9:
																							if (38 > b)
																							{
																								break;
																							}
																							goto IL_1407;
																							IL_1407:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1447;
																							IL_1447:
																							array2[num6 - 2] = 3;
																							goto IL_145b;
																							IL_145b:
																							num6--;
																							goto IL_2340;
																							IL_0fe6:
																							array2[num6 - 1] = 0;
																							goto IL_0ffa;
																							IL_0ffa:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							num = 32;
																							goto IL_1042;
																							IL_1042:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_1055:
																							if (41 >= b)
																							{
																								goto IL_1063;
																							}
																							goto IL_10f5;
																							IL_1063:
																							if (41 <= b)
																							{
																								goto IL_106e;
																							}
																							goto IL_10d4;
																							IL_106e:
																							array2[num6 - 1] = 3;
																							goto IL_1082;
																							IL_1082:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_10c1;
																							IL_10c1:
																							ptr2 += 8;
																							goto IL_2340;
																							IL_10d4:
																							if (40 < b)
																							{
																								break;
																							}
																							goto IL_10e2;
																							IL_10e2:
																							if (40 > b)
																							{
																								break;
																							}
																							goto IL_14e2;
																						}
																						break;
																						IL_0884:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_2340;
																				continue;
																				end_IL_0894:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_240c;
																IL_240c:
																return (string)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1a42:
			while (true)
			{
				IL_1a42_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_1aea_2:
						array2[num6] = 5;
						while (true)
						{
							IL_1af8_2:
							num6++;
							while (true)
							{
								IL_2340_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0894_2:
												if (b >= 1)
												{
													while (b <= 57)
													{
														while (true)
														{
															IL_0871_2:
															if (29 >= b)
															{
																num = 210;
																while (true)
																{
																	IL_0861_2:
																	if (29 > b)
																	{
																		while (true)
																		{
																			IL_0851_2:
																			if (14 >= b)
																			{
																				while (true)
																				{
																					IL_0844_2:
																					if (14 > b)
																					{
																						while (true)
																						{
																							IL_0834_2:
																							if (7 >= b)
																							{
																								while (true)
																								{
																									IL_0824_2:
																									if (7 > b)
																									{
																										while (true)
																										{
																											IL_0814_2:
																											if (3 >= b)
																											{
																												while (true)
																												{
																													IL_0804_2:
																													if (3 > b)
																													{
																														while (true)
																														{
																															IL_07f4_2:
																															if (1 >= b)
																															{
																																while (1 <= b)
																																{
																																	while (true)
																																	{
																																		IL_07c9_2:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																																		while (true)
																																		{
																																			IL_07b9_2:
																																			array2[num6] = 0;
																																			while (true)
																																			{
																																				IL_07a0_2:
																																				num6++;
																																				num = 476;
																																				while (true)
																																				{
																																					if (num != 476)
																																					{
																																						if (num != 1457)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 101:
																																							goto IL_07a0_2;
																																						case 118:
																																							goto IL_07b9_2;
																																						case 137:
																																						case 379:
																																							goto IL_07c9_2;
																																						case 185:
																																							goto IL_07e4_2;
																																						case 410:
																																							goto IL_07f4_2;
																																						case 142:
																																							goto IL_0804_2;
																																						case 447:
																																							goto IL_0814_2;
																																						case 148:
																																							goto IL_0824_2;
																																						case 286:
																																							goto IL_0834_2;
																																						case 422:
																																							goto IL_0844_2;
																																						case 254:
																																							goto IL_0851_2;
																																						case 210:
																																							goto IL_0861_2;
																																						case 130:
																																							goto IL_0871_2;
																																						case 261:
																																							goto IL_0884_2;
																																						case 217:
																																							goto IL_0894_2;
																																						case 190:
																																							goto end_IL_0894_2;
																																						case 2:
																																						case 309:
																																							goto end_IL_08a4;
																																						case 119:
																																						case 123:
																																							goto IL_08bf_2;
																																						case 223:
																																							goto IL_08e8_2;
																																						case 3:
																																						case 276:
																																							goto IL_0901_2;
																																						case 172:
																																							goto IL_094a_2;
																																						case 53:
																																							goto IL_095e_2;
																																						case 247:
																																						case 302:
																																							goto IL_0971_2;
																																						case 186:
																																							goto IL_0985_2;
																																						case 19:
																																							goto IL_09d9_2;
																																						case 215:
																																							goto IL_09f0_2;
																																						case 401:
																																							goto IL_0a03_2;
																																						case 307:
																																							goto IL_0a11_2;
																																						case 69:
																																							goto IL_0a1f_2;
																																						case 13:
																																						case 95:
																																							goto IL_0a2a_2;
																																						case 387:
																																							goto IL_0a3e_2;
																																						case 174:
																																							goto IL_0a7c_2;
																																						case 189:
																																							goto IL_0a8f_2;
																																						case 108:
																																							goto IL_0a9d_2;
																																						case 8:
																																						case 198:
																																							goto IL_0aa8_2;
																																						case 129:
																																							goto IL_0abc_2;
																																						case 219:
																																							goto IL_0afb_2;
																																						case 330:
																																							goto IL_0b17_2;
																																						case 289:
																																							goto IL_0b22_2;
																																						case 238:
																																						case 385:
																																							goto IL_0b30_2;
																																						case 111:
																																							goto IL_0b44_2;
																																						case 384:
																																							goto IL_0b88_2;
																																						case 296:
																																							goto IL_0b96_2;
																																						case 18:
																																							goto IL_0ba9_2;
																																						case 156:
																																							goto IL_0bb4_2;
																																						case 234:
																																							goto IL_0bc2_2;
																																						case 359:
																																							goto IL_0bd0_2;
																																						case 389:
																																							goto IL_0be3_2;
																																						case 113:
																																							goto IL_0bf1_2;
																																						case 85:
																																						case 117:
																																							goto IL_0bff_2;
																																						case 100:
																																							goto IL_0c18_2;
																																						case 74:
																																							goto IL_0c2b_2;
																																						case 259:
																																							goto IL_0c39_2;
																																						case 70:
																																						case 114:
																																							goto IL_0c44_2;
																																						case 30:
																																							goto IL_0c58_2;
																																						case 109:
																																							goto IL_0c97_2;
																																						case 341:
																																							goto IL_0caa_2;
																																						case 83:
																																							goto IL_0cb5_2;
																																						case 43:
																																						case 339:
																																							goto IL_0cc3_2;
																																						case 231:
																																							goto IL_0cdc_2;
																																						case 182:
																																							goto IL_0cef_2;
																																						case 338:
																																							goto IL_0cfa_2;
																																						case 249:
																																							goto IL_0d11_2;
																																						case 325:
																																							goto IL_0d44_2;
																																						case 128:
																																						case 255:
																																							goto IL_0d4f_2;
																																						case 362:
																																							goto IL_0d7f_2;
																																						case 301:
																																							goto IL_0d8d_2;
																																						case 225:
																																							goto IL_0d9b_2;
																																						case 157:
																																							goto IL_0da9_2;
																																						case 274:
																																							goto IL_0db7_2;
																																						case 178:
																																							goto IL_0dc2_2;
																																						case 370:
																																						case 375:
																																							goto IL_0dd5_2;
																																						case 318:
																																							goto IL_0e1e_2;
																																						case 121:
																																							goto IL_0e32_2;
																																						case 150:
																																							goto IL_0e45_2;
																																						case 356:
																																							goto IL_0e53_2;
																																						case 49:
																																						case 92:
																																							goto IL_0e61_2;
																																						case 213:
																																							goto IL_0e75_2;
																																						case 59:
																																							goto IL_0ebd_2;
																																						case 60:
																																						case 170:
																																							goto IL_0ed9_2;
																																						case 328:
																																							goto IL_0f00_2;
																																						case 399:
																																							goto IL_0f0e_2;
																																						case 327:
																																							goto IL_0f1c_2;
																																						case 392:
																																							goto IL_0f2f_2;
																																						case 244:
																																							goto IL_0f3d_2;
																																						case 126:
																																							goto IL_0f4b_2;
																																						case 282:
																																							goto IL_0f56_2;
																																						case 343:
																																						case 349:
																																							goto IL_0f64_2;
																																						case 122:
																																							goto IL_0f78_2;
																																						case 230:
																																							goto IL_0fb7_2;
																																						case 394:
																																							goto IL_0fca_2;
																																						case 221:
																																						case 290:
																																							goto IL_0fe6_2;
																																						case 187:
																																							goto IL_0ffa_2;
																																						case 32:
																																							goto IL_1042_2;
																																						case 191:
																																							goto IL_1055_2;
																																						case 214:
																																							goto IL_1063_2;
																																						case 196:
																																						case 239:
																																							goto IL_106e_2;
																																						case 271:
																																							goto IL_1082_2;
																																						case 317:
																																							goto IL_10c1_2;
																																						case 246:
																																							goto IL_10d4_2;
																																						case 171:
																																							goto IL_10e2_2;
																																						case 94:
																																							goto IL_10f5_2;
																																						case 403:
																																							goto IL_1108_2;
																																						case 396:
																																							goto IL_1113_2;
																																						case 14:
																																							goto IL_111e_2;
																																						case 98:
																																						case 331:
																																							goto IL_112c_2;
																																						case 299:
																																							goto IL_1145_2;
																																						case 9:
																																							goto IL_1153_2;
																																						case 146:
																																						case 201:
																																							goto IL_1161_2;
																																						case 38:
																																							goto IL_117a_2;
																																						case 80:
																																						case 167:
																																							goto IL_118d_2;
																																						case 124:
																																							goto IL_11af_2;
																																						case 206:
																																							goto IL_11bd_2;
																																						case 166:
																																							goto IL_11cb_2;
																																						case 405:
																																							goto IL_11de_2;
																																						case 5:
																																							goto IL_11ec_2;
																																						case 66:
																																						case 407:
																																							goto IL_11ff_2;
																																						case 67:
																																							goto IL_1228_2;
																																						case 371:
																																							goto IL_1236_2;
																																						case 139:
																																						case 416:
																																							goto IL_1249_2;
																																						case 28:
																																							goto IL_125d_2;
																																						case 298:
																																							goto end_IL_078d_2;
																																						case 42:
																																						case 418:
																																							goto IL_12af_2;
																																						case 91:
																																							goto IL_131d_2;
																																						case 425:
																																							goto IL_1330_2;
																																						case 420:
																																							goto IL_133b_2;
																																						case 12:
																																							goto IL_1349_2;
																																						case 426:
																																							goto IL_136a_2;
																																						case 350:
																																							goto IL_13b6_2;
																																						case 27:
																																							goto IL_13c4_2;
																																						case 428:
																																							goto IL_13d7_2;
																																						case 430:
																																							goto IL_13f9_2;
																																						case 175:
																																						case 270:
																																							goto IL_1407_2;
																																						case 235:
																																							goto IL_1447_2;
																																						case 1:
																																							goto IL_145b_2;
																																						case 433:
																																							goto IL_146e_2;
																																						case 264:
																																						case 398:
																																							goto IL_147c_2;
																																						case 197:
																																							goto IL_1490_2;
																																						case 84:
																																							goto IL_14cf_2;
																																						case 33:
																																						case 434:
																																							goto IL_14e2_2;
																																						case 133:
																																							goto IL_14ff_2;
																																						case 310:
																																							goto IL_156a_2;
																																						case 63:
																																							goto IL_1578_2;
																																						case 452:
																																							goto IL_158b_2;
																																						case 79:
																																						case 382:
																																							goto IL_1599_2;
																																						case 378:
																																							goto IL_15ad_2;
																																						case 205:
																																							goto IL_15ec_2;
																																						case 56:
																																						case 455:
																																							goto IL_15ff_2;
																																						case 347:
																																							goto IL_1618_2;
																																						case 456:
																																							goto IL_162b_2;
																																						case 199:
																																						case 457:
																																							goto IL_163e_2;
																																						case 222:
																																							goto IL_1652_2;
																																						case 361:
																																							goto IL_1691_2;
																																						case 461:
																																							goto IL_16a4_2;
																																						case 462:
																																							goto IL_16e5_2;
																																						case 7:
																																						case 138:
																																							goto IL_16f3_2;
																																						case 168:
																																							goto IL_1733_2;
																																						case 438:
																																							goto IL_1747_2;
																																						case 463:
																																							goto IL_175a_2;
																																						case 192:
																																						case 466:
																																							goto IL_176d_2;
																																						case 147:
																																						case 469:
																																							goto IL_1789_2;
																																						case 314:
																																							goto IL_179d_2;
																																						case 312:
																																							goto IL_17dc_2;
																																						case 165:
																																							goto IL_1802_2;
																																						case 321:
																																							goto IL_1810_2;
																																						case 26:
																																						case 173:
																																							goto IL_181e_2;
																																						case 10:
																																							goto IL_185e_2;
																																						case 402:
																																							goto IL_1872_2;
																																						case 340:
																																							goto IL_1885_2;
																																						case 364:
																																							goto IL_1893_2;
																																						case 383:
																																						case 446:
																																							goto IL_189e_2;
																																						case 16:
																																							goto IL_18de_2;
																																						case 40:
																																							goto IL_18f2_2;
																																						case 41:
																																							goto IL_1905_2;
																																						case 90:
																																							goto IL_1913_2;
																																						case 127:
																																						case 441:
																																							goto IL_1921_2;
																																						case 256:
																																							goto IL_192f_2;
																																						case 243:
																																							goto IL_1952_2;
																																						case 423:
																																							goto IL_195c_2;
																																						case 58:
																																							goto IL_1973_2;
																																						case 265:
																																							goto IL_1986_2;
																																						case 208:
																																							goto IL_1994_2;
																																						case 93:
																																						case 250:
																																							goto IL_19a2_2;
																																						case 86:
																																							goto IL_19e2_2;
																																						case 134:
																																							goto IL_19f6_2;
																																						case 194:
																																							goto IL_1a09_2;
																																						case 160:
																																							goto IL_1a17_2;
																																						case 291:
																																							goto IL_1a25_2;
																																						case 369:
																																						case 395:
																																							goto end_IL_08b4;
																																						case 181:
																																							goto IL_1aea_2;
																																						case 226:
																																							goto IL_1af8_2;
																																						case 391:
																																							goto IL_1b0b_2;
																																						case 464:
																																							goto IL_1b19_2;
																																						case 103:
																																							goto IL_1b2c_2;
																																						case 55:
																																							goto IL_1b3a_2;
																																						case 31:
																																						case 218:
																																							goto IL_1b48_2;
																																						case 143:
																																							goto IL_1b66_2;
																																						case 20:
																																							goto IL_1b74_2;
																																						case 78:
																																							goto IL_1b90_2;
																																						case 164:
																																						case 306:
																																							goto IL_1b9b_2;
																																						case 57:
																																							goto IL_1bfd_2;
																																						case 61:
																																							goto IL_1c10_2;
																																						case 233:
																																							goto IL_1c1b_2;
																																						case 304:
																																						case 332:
																																							goto IL_1c29_2;
																																						case 351:
																																							goto IL_1c3c_2;
																																						case 22:
																																							goto IL_1c4a_2;
																																						case 358:
																																						case 380:
																																							goto IL_1c58_2;
																																						case 211:
																																							goto IL_1c98_2;
																																						case 36:
																																							goto IL_1cac_2;
																																						case 439:
																																							goto IL_1cbf_2;
																																						case 140:
																																							goto IL_1ccd_2;
																																						case 65:
																																						case 323:
																																							goto IL_1cd8_2;
																																						case 363:
																																							goto IL_1d19_2;
																																						case 135:
																																							goto IL_1d2d_2;
																																						case 207:
																																							goto IL_1d40_2;
																																						case 237:
																																							goto IL_1d4e_2;
																																						case 248:
																																						case 329:
																																							goto IL_1d59_2;
																																						case 427:
																																							goto IL_1d97_2;
																																						case 458:
																																							goto IL_1daa_2;
																																						case 68:
																																							goto IL_1db8_2;
																																						case 72:
																																						case 292:
																																							goto IL_1dc6_2;
																																						case 326:
																																							goto IL_1dde_2;
																																						case 75:
																																							goto IL_1dfc_2;
																																						case 52:
																																							goto IL_1e20_2;
																																						case 176:
																																							goto IL_1e38_2;
																																						case 227:
																																							goto IL_1e4b_2;
																																						case 203:
																																							goto IL_1e59_2;
																																						case 324:
																																						case 365:
																																							goto IL_1e67_2;
																																						case 47:
																																							goto IL_1e75_2;
																																						case 4:
																																							goto IL_1e96_2;
																																						case 397:
																																							goto IL_1ea4_2;
																																						case 25:
																																							goto IL_1eb7_2;
																																						case 71:
																																							goto IL_1ec5_2;
																																						case 158:
																																							goto IL_1ed3_2;
																																						case 162:
																																							goto IL_1ee1_2;
																																						case 132:
																																						case 381:
																																							goto IL_1ef8_2;
																																						case 345:
																																							goto IL_1f0c_2;
																																						case 15:
																																							goto IL_1f44_2;
																																						case 153:
																																						case 297:
																																							goto IL_1f60_2;
																																						case 313:
																																							goto IL_1f79_2;
																																						case 177:
																																							goto IL_1f87_2;
																																						case 149:
																																							goto IL_1f95_2;
																																						case 180:
																																							goto IL_1fb1_2;
																																						case 46:
																																							goto IL_1fbf_2;
																																						case 96:
																																						case 110:
																																							goto IL_1fcd_2;
																																						case 366:
																																							goto IL_1fe5_2;
																																						case 393:
																																							goto IL_1ff3_2;
																																						case 333:
																																							goto IL_2001_2;
																																						case 145:
																																							goto IL_200f_2;
																																						case 159:
																																						case 251:
																																							goto IL_201a_2;
																																						case 107:
																																							goto IL_2038_2;
																																						case 390:
																																							goto IL_2046_2;
																																						case 37:
																																							goto IL_205d_2;
																																						case 262:
																																							goto IL_2070_2;
																																						case 48:
																																							goto IL_207e_2;
																																						case 224:
																																						case 406:
																																							goto IL_208c_2;
																																						case 242:
																																							goto IL_20de_2;
																																						case 240:
																																							goto IL_20f1_2;
																																						case 120:
																																							goto IL_20ff_2;
																																						case 188:
																																						case 411:
																																							goto IL_210d_2;
																																						case 344:
																																							goto IL_2140_2;
																																						case 21:
																																						case 115:
																																							goto IL_2159_2;
																																						case 195:
																																							goto IL_2184_2;
																																						case 45:
																																							goto IL_21a6_2;
																																						case 99:
																																							goto IL_21b4_2;
																																						case 245:
																																							goto IL_21c2_2;
																																						case 220:
																																							goto IL_21d0_2;
																																						case 229:
																																						case 319:
																																							goto IL_21de_2;
																																						case 348:
																																							goto IL_21f2_2;
																																						case 44:
																																							goto IL_2246_2;
																																						case 285:
																																							goto IL_2254_2;
																																						case 6:
																																						case 155:
																																							goto IL_2267_2;
																																						case 64:
																																							goto IL_22a0_2;
																																						case 131:
																																							goto IL_22bd_2;
																																						case 284:
																																							goto IL_22cd_2;
																																						case 308:
																																							goto IL_22d8_2;
																																						case 212:
																																						case 293:
																																							goto IL_22e3_2;
																																						case 24:
																																							goto IL_2301_2;
																																						case 419:
																																							goto IL_230f_2;
																																						case 184:
																																							goto IL_231d_2;
																																						case 0:
																																						case 23:
																																						case 29:
																																						case 35:
																																						case 62:
																																						case 77:
																																						case 81:
																																						case 82:
																																						case 87:
																																						case 88:
																																						case 104:
																																						case 105:
																																						case 112:
																																						case 125:
																																						case 136:
																																						case 152:
																																						case 154:
																																						case 179:
																																						case 193:
																																						case 200:
																																						case 204:
																																						case 228:
																																						case 232:
																																						case 236:
																																						case 260:
																																						case 268:
																																						case 269:
																																						case 275:
																																						case 277:
																																						case 278:
																																						case 279:
																																						case 287:
																																						case 288:
																																						case 294:
																																						case 300:
																																						case 303:
																																						case 305:
																																						case 311:
																																						case 315:
																																						case 316:
																																						case 335:
																																						case 336:
																																						case 342:
																																						case 346:
																																						case 353:
																																						case 367:
																																						case 372:
																																						case 386:
																																						case 408:
																																						case 409:
																																						case 414:
																																						case 429:
																																						case 435:
																																						case 444:
																																						case 450:
																																						case 453:
																																						case 454:
																																						case 459:
																																						case 460:
																																						case 465:
																																							goto end_IL_07e4_2;
																																						case 11:
																																						case 17:
																																						case 34:
																																						case 39:
																																						case 50:
																																						case 51:
																																						case 54:
																																						case 73:
																																						case 76:
																																						case 89:
																																						case 97:
																																						case 102:
																																						case 106:
																																						case 116:
																																						case 141:
																																						case 144:
																																						case 151:
																																						case 161:
																																						case 169:
																																						case 183:
																																						case 202:
																																						case 209:
																																						case 216:
																																						case 252:
																																						case 253:
																																						case 263:
																																						case 272:
																																						case 273:
																																						case 280:
																																						case 281:
																																						case 283:
																																						case 295:
																																						case 320:
																																						case 337:
																																						case 352:
																																						case 354:
																																						case 355:
																																						case 357:
																																						case 360:
																																						case 373:
																																						case 374:
																																						case 376:
																																						case 377:
																																						case 388:
																																						case 400:
																																						case 404:
																																						case 415:
																																						case 417:
																																						case 421:
																																						case 424:
																																						case 431:
																																						case 436:
																																						case 437:
																																						case 440:
																																						case 443:
																																						case 445:
																																						case 448:
																																						case 451:
																																						case 467:
																																						case 468:
																																							goto IL_2340_2;
																																						case 334:
																																							ptr2 = ptr;
																																							goto IL_2340_2;
																																						case 432:
																																							ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResourceManagerNeutralResourcesNotFoundShortInlineBrTarget.AccountDomainAdminsSidReadSubTree);
																																							goto case 334;
																																						case 267:
																																							array7 = new object[41];
																																							goto case 432;
																																						case 412:
																																							array6 = new long[5];
																																							goto case 267;
																																						case 442:
																																							array5 = new int[7];
																																							goto case 412;
																																						case 266:
																																							array4 = new int[5];
																																							goto case 442;
																																						case 241:
																																							array3 = new object[5];
																																							num = 266;
																																							goto case 266;
																																						case 322:
																																							array2 = new byte[5];
																																							goto case 241;
																																						case 413:
																																							num4 = num2 * 8;
																																							goto case 322;
																																						case 449:
																																							num3 = num2 * 4;
																																							goto case 413;
																																						case 257:
																																							num2 = 1;
																																							goto case 449;
																																						case 258:
																																							goto end_IL_1a50;
																																						case 163:
																																						case 368:
																																							goto IL_240c_2;
																																						}
																																						continue;
																																					}
																																					ptr2 += 8;
																																					goto IL_2340_2;
																																					continue;
																																					end_IL_078d_2:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_129c_2;
																																	continue;
																																	end_IL_07e4_2:
																																	break;
																																	IL_07e4_2:;
																																}
																																break;
																															}
																															goto IL_1802_2;
																															IL_1872_2:
																															num6--;
																															goto IL_2340_2;
																															IL_1802_2:
																															if (2 < b)
																															{
																																break;
																															}
																															goto IL_1810_2;
																															IL_1810_2:
																															if (2 > b)
																															{
																																break;
																															}
																															goto IL_181e_2;
																															IL_181e_2:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_185e_2;
																															IL_185e_2:
																															array2[num6 - 2] = 0;
																															goto IL_1872_2;
																														}
																														break;
																													}
																													goto IL_11ff_2;
																													IL_1236_2:
																													num6--;
																													goto IL_2340_2;
																													IL_11ff_2:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_1228_2;
																													IL_1228_2:
																													ptr2 += 8;
																													goto IL_1236_2;
																												}
																												break;
																											}
																											goto IL_1885_2;
																											IL_19f6_2:
																											num6--;
																											goto IL_2340_2;
																											IL_1885_2:
																											if (5 >= b)
																											{
																												goto IL_1893_2;
																											}
																											goto IL_1986_2;
																											IL_1893_2:
																											if (5 <= b)
																											{
																												goto IL_189e_2;
																											}
																											goto IL_1905_2;
																											IL_189e_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_18de_2;
																											IL_18de_2:
																											array2[num6 - 2] = 0;
																											goto IL_18f2_2;
																											IL_18f2_2:
																											num6--;
																											goto IL_2340_2;
																											IL_1905_2:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_1913_2;
																											IL_1913_2:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_1921_2;
																											IL_1921_2:
																											array2[num6] = 0;
																											goto IL_192f_2;
																											IL_192f_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_1952_2;
																											IL_1952_2:
																											array3[num6] = null;
																											goto IL_195c_2;
																											IL_195c_2:
																											num6++;
																											num = 58;
																											goto IL_1973_2;
																											IL_1973_2:
																											ptr2 += 8;
																											goto IL_2340_2;
																											IL_1986_2:
																											if (6 < b)
																											{
																												break;
																											}
																											goto IL_1994_2;
																											IL_1994_2:
																											if (6 > b)
																											{
																												break;
																											}
																											goto IL_19a2_2;
																											IL_19a2_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_19e2_2;
																											IL_19e2_2:
																											array2[num6 - 2] = 0;
																											goto IL_19f6_2;
																										}
																										break;
																									}
																									goto IL_0901_2;
																									IL_095e_2:
																									num6--;
																									goto IL_2340_2;
																									IL_0901_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									num = 172;
																									goto IL_094a_2;
																									IL_094a_2:
																									array2[num6 - 2] = 0;
																									goto IL_095e_2;
																								}
																								break;
																							}
																							goto IL_1a09_2;
																							IL_1c98_2:
																							array2[num6 - 2] = 0;
																							goto IL_1cac_2;
																							IL_1a09_2:
																							if (10 < b)
																							{
																								goto IL_1a17_2;
																							}
																							num = 78;
																							goto IL_1b90_2;
																							IL_1a17_2:
																							if (12 >= b)
																							{
																								goto IL_1a25_2;
																							}
																							goto IL_1b2c_2;
																							IL_1a25_2:
																							if (12 <= b)
																							{
																								goto end_IL_08b4;
																							}
																							goto IL_1b0b_2;
																							IL_1b0b_2:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_1b19_2;
																							IL_1b19_2:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_2340_2;
																							IL_1b2c_2:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_1b3a_2;
																							IL_1b3a_2:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_1b48_2;
																							IL_1b48_2:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_1b66_2;
																							IL_1b66_2:
																							ptr2 += 8;
																							goto IL_1b74_2;
																							IL_1b74_2:
																							num6--;
																							goto IL_2340_2;
																							IL_1cac_2:
																							num6--;
																							goto IL_2340_2;
																							IL_1b90_2:
																							if (10 <= b)
																							{
																								goto IL_1b9b_2;
																							}
																							goto IL_1c10_2;
																							IL_1b9b_2:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_1bfd_2;
																							IL_1bfd_2:
																							num6 -= 2;
																							goto IL_2340_2;
																							IL_1c10_2:
																							if (8 >= b)
																							{
																								goto IL_1c1b_2;
																							}
																							goto IL_1c3c_2;
																							IL_1c1b_2:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_1c29_2;
																							IL_1c29_2:
																							num6--;
																							goto IL_2340_2;
																							IL_1c3c_2:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_1c4a_2;
																							IL_1c4a_2:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_1c58_2;
																							IL_1c58_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1c98_2;
																						}
																						break;
																					}
																					goto IL_08bf_2;
																					IL_08e8_2:
																					array2[num6 - 1] = 5;
																					goto IL_2340_2;
																					IL_08bf_2:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_08e8_2;
																				}
																				break;
																			}
																			goto IL_1cbf_2;
																			IL_2301_2:
																			array2[num6] = 5;
																			goto IL_230f_2;
																			IL_1cbf_2:
																			if (21 >= b)
																			{
																				goto IL_1ccd_2;
																			}
																			goto IL_1fe5_2;
																			IL_1ccd_2:
																			if (21 <= b)
																			{
																				goto IL_1cd8_2;
																			}
																			goto IL_1d40_2;
																			IL_1cd8_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																			goto IL_1d19_2;
																			IL_1d19_2:
																			array2[num6 - 2] = 0;
																			goto IL_1d2d_2;
																			IL_1d2d_2:
																			num6--;
																			goto IL_2340_2;
																			IL_1d40_2:
																			if (17 >= b)
																			{
																				goto IL_1d4e_2;
																			}
																			goto IL_1eb7_2;
																			IL_1d4e_2:
																			if (17 <= b)
																			{
																				goto IL_1d59_2;
																			}
																			goto IL_1daa_2;
																			IL_1d59_2:
																			((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																			goto IL_1d97_2;
																			IL_1d97_2:
																			num6 -= 3;
																			goto IL_2340_2;
																			IL_1daa_2:
																			if (15 >= b)
																			{
																				goto IL_1db8_2;
																			}
																			goto IL_1e4b_2;
																			IL_1db8_2:
																			if (15 > b)
																			{
																				break;
																			}
																			goto IL_1dc6_2;
																			IL_1dc6_2:
																			array2[num6] = array2[num6 - 1];
																			goto IL_1dde_2;
																			IL_1dde_2:
																			array4[num6 - 0] = array4[num6 - 1];
																			goto IL_1dfc_2;
																			IL_1dfc_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_1e20_2;
																			IL_1e20_2:
																			array3[num6] = array3[num6 - 1];
																			goto IL_1e38_2;
																			IL_1e38_2:
																			num6++;
																			goto IL_2340_2;
																			IL_1e4b_2:
																			if (16 < b)
																			{
																				break;
																			}
																			goto IL_1e59_2;
																			IL_1e59_2:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_1e67_2;
																			IL_1e67_2:
																			array2[num6] = 5;
																			goto IL_1e75_2;
																			IL_1e75_2:
																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																			num = 4;
																			goto IL_1e96_2;
																			IL_1e96_2:
																			num6++;
																			goto IL_1ea4_2;
																			IL_1ea4_2:
																			ptr2 += 8;
																			goto IL_2340_2;
																			IL_1eb7_2:
																			if (19 >= b)
																			{
																				goto IL_1ec5_2;
																			}
																			goto IL_1fb1_2;
																			IL_1ec5_2:
																			if (19 > b)
																			{
																				goto IL_1ed3_2;
																			}
																			num = 153;
																			goto IL_1f60_2;
																			IL_1ed3_2:
																			if (18 < b)
																			{
																				break;
																			}
																			goto IL_1ee1_2;
																			IL_1ee1_2:
																			if (18 > b)
																			{
																				break;
																			}
																			num = 132;
																			goto IL_1ef8_2;
																			IL_231d_2:
																			ptr2 += 8;
																			goto IL_2340_2;
																			IL_1ef8_2:
																			array2[num6 - 1] = 5;
																			goto IL_1f0c_2;
																			IL_1f0c_2:
																			array3[num6 - 1] = ((delegate*<string[], string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																			goto IL_1f44_2;
																			IL_1f44_2:
																			ptr2 += 8;
																			goto IL_2340_2;
																			IL_230f_2:
																			num6++;
																			goto IL_231d_2;
																			IL_1f60_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																			goto IL_1f79_2;
																			IL_1f79_2:
																			array2[num6] = 1;
																			goto IL_1f87_2;
																			IL_1f87_2:
																			num6++;
																			goto IL_1f95_2;
																			IL_1f95_2:
																			ptr2 += 16;
																			num = 417;
																			goto IL_2340_2;
																			IL_1fb1_2:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_1fbf_2;
																			IL_1fbf_2:
																			if (20 > b)
																			{
																				break;
																			}
																			goto IL_1fcd_2;
																			IL_1fcd_2:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_2340_2;
																			IL_1fe5_2:
																			if (25 >= b)
																			{
																				goto IL_1ff3_2;
																			}
																			goto IL_21a6_2;
																			IL_1ff3_2:
																			if (25 > b)
																			{
																				goto IL_2001_2;
																			}
																			goto IL_2159_2;
																			IL_2001_2:
																			if (23 >= b)
																			{
																				goto IL_200f_2;
																			}
																			goto IL_20f1_2;
																			IL_200f_2:
																			if (23 <= b)
																			{
																				goto IL_201a_2;
																			}
																			goto IL_2070_2;
																			IL_201a_2:
																			array3[num6] = ((delegate*<string[]>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
																			goto IL_2038_2;
																			IL_2038_2:
																			array2[num6] = 5;
																			goto IL_2046_2;
																			IL_2046_2:
																			num6++;
																			num = 37;
																			goto IL_205d_2;
																			IL_205d_2:
																			ptr2 += 8;
																			goto IL_2340_2;
																			IL_2070_2:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_207e_2;
																			IL_207e_2:
																			if (22 > b)
																			{
																				break;
																			}
																			goto IL_208c_2;
																			IL_208c_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_20de_2;
																			IL_20de_2:
																			num6--;
																			goto IL_2340_2;
																			IL_20f1_2:
																			if (24 < b)
																			{
																				break;
																			}
																			goto IL_20ff_2;
																			IL_20ff_2:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_210d_2;
																			IL_210d_2:
																			*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((string[])array3[num6 - 1]).LongLength;
																			num = 344;
																			goto IL_2140_2;
																			IL_2140_2:
																			array2[num6 - 1] = 2;
																			goto IL_2340_2;
																			IL_2159_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_2184_2;
																			IL_2184_2:
																			array2[num6 - 1] = 0;
																			num = 50;
																			goto IL_2340_2;
																			IL_21a6_2:
																			if (27 >= b)
																			{
																				goto IL_21b4_2;
																			}
																			goto IL_22cd_2;
																			IL_21b4_2:
																			if (27 > b)
																			{
																				goto IL_21c2_2;
																			}
																			goto IL_2267_2;
																			IL_21c2_2:
																			if (26 < b)
																			{
																				break;
																			}
																			goto IL_21d0_2;
																			IL_21d0_2:
																			if (26 > b)
																			{
																				break;
																			}
																			goto IL_21de_2;
																			IL_21de_2:
																			array2[num6 - 2] = 0;
																			goto IL_21f2_2;
																			IL_21f2_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_2246_2;
																			IL_2246_2:
																			num6--;
																			goto IL_2254_2;
																			IL_2254_2:
																			ptr2 += 8;
																			goto IL_2340_2;
																			IL_2267_2:
																			array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																			goto IL_22a0_2;
																			IL_22a0_2:
																			array2[num6 - 2] = 5;
																			num = 131;
																			goto IL_22bd_2;
																			IL_22bd_2:
																			num6--;
																			goto IL_2340_2;
																			IL_22cd_2:
																			if (28 < b)
																			{
																				break;
																			}
																			goto IL_22d8_2;
																			IL_22d8_2:
																			if (28 > b)
																			{
																				break;
																			}
																			goto IL_22e3_2;
																			IL_22e3_2:
																			array3[num6] = ((delegate*<string[]>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
																			goto IL_2301_2;
																		}
																		break;
																	}
																	goto IL_0971_2;
																	IL_09f0_2:
																	ptr2 += 8;
																	goto IL_2340_2;
																	IL_0971_2:
																	array2[num6 - 2] = 0;
																	goto IL_0985_2;
																	IL_0985_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																	goto IL_09d9_2;
																	IL_09d9_2:
																	num6--;
																	num = 215;
																	goto IL_09f0_2;
																}
																break;
															}
															goto IL_0a03_2;
															IL_14e2_2:
															array2[num6 - 3] = 5;
															num = 133;
															goto IL_14ff_2;
															IL_14ff_2:
															array3[num6 - 3] = ((delegate*<string, int, int, string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 3], *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 310;
															goto IL_156a_2;
															IL_0a03_2:
															if (43 < b)
															{
																goto IL_0a11_2;
															}
															num = 325;
															goto IL_0d44_2;
															IL_0a11_2:
															if (50 >= b)
															{
																goto IL_0a1f_2;
															}
															goto IL_0c2b_2;
															IL_0a1f_2:
															if (50 <= b)
															{
																goto IL_0a2a_2;
															}
															goto IL_0a8f_2;
															IL_0a2a_2:
															array2[num6 - 1] = 0;
															goto IL_0a3e_2;
															IL_0a3e_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<string, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
															goto IL_0a7c_2;
															IL_0a7c_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0a8f_2:
															if (46 >= b)
															{
																goto IL_0a9d_2;
															}
															goto IL_0ba9_2;
															IL_0a9d_2:
															if (46 <= b)
															{
																goto IL_0aa8_2;
															}
															goto IL_0b17_2;
															IL_0aa8_2:
															array2[num6 - 1] = 3;
															goto IL_0abc_2;
															IL_0abc_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0afb_2;
															IL_0afb_2:
															ptr2 += 8;
															num = 468;
															goto IL_2340_2;
															IL_0b17_2:
															if (44 >= b)
															{
																goto IL_0b22_2;
															}
															goto IL_0b88_2;
															IL_0b22_2:
															if (44 > b)
															{
																break;
															}
															goto IL_0b30_2;
															IL_0b30_2:
															array2[num6 - 1] = 3;
															goto IL_0b44_2;
															IL_0b44_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_162b_2;
															IL_162b_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0b88_2:
															if (45 < b)
															{
																break;
															}
															goto IL_0b96_2;
															IL_0b96_2:
															if (45 > b)
															{
																break;
															}
															goto IL_1249_2;
															IL_1249_2:
															array2[num6 - 1] = 0;
															goto IL_125d_2;
															IL_125d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_129c_2;
															IL_129c_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0ba9_2:
															if (48 >= b)
															{
																goto IL_0bb4_2;
															}
															goto IL_0be3_2;
															IL_0bb4_2:
															if (48 > b)
															{
																goto IL_0bc2_2;
															}
															goto IL_1789_2;
															IL_0bc2_2:
															if (47 < b)
															{
																break;
															}
															goto IL_0bd0_2;
															IL_0bd0_2:
															if (47 > b)
															{
																break;
															}
															goto IL_163e_2;
															IL_163e_2:
															array2[num6 - 1] = 3;
															goto IL_1652_2;
															IL_1652_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1691_2;
															IL_1691_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_1789_2:
															array2[num6 - 1] = 3;
															goto IL_179d_2;
															IL_179d_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_17dc_2;
															IL_17dc_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0be3_2:
															if (49 < b)
															{
																break;
															}
															goto IL_0bf1_2;
															IL_0bf1_2:
															if (49 > b)
															{
																break;
															}
															goto IL_0bff_2;
															IL_0bff_2:
															global::_003CModule_003E.string_47 = (string[])array3[num6 - 1];
															goto IL_0c18_2;
															IL_0c18_2:
															num6--;
															goto IL_2340_2;
															IL_0c2b_2:
															if (54 >= b)
															{
																goto IL_0c39_2;
															}
															goto IL_0cef_2;
															IL_0c39_2:
															if (54 <= b)
															{
																goto IL_0c44_2;
															}
															goto IL_0caa_2;
															IL_0c44_2:
															array2[num6 - 1] = 3;
															goto IL_0c58_2;
															IL_0c58_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0c97_2;
															IL_0c97_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0caa_2:
															if (52 >= b)
															{
																goto IL_0cb5_2;
															}
															goto IL_0cdc_2;
															IL_0cb5_2:
															if (52 <= b)
															{
																goto IL_0cc3_2;
															}
															goto IL_11de_2;
															IL_0cc3_2:
															array2[num6 - 1] = 3;
															goto IL_16a4_2;
															IL_16a4_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_175a_2;
															IL_175a_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_11de_2:
															if (51 < b)
															{
																break;
															}
															goto IL_11ec_2;
															IL_11ec_2:
															if (51 > b)
															{
																break;
															}
															goto IL_12af_2;
															IL_12af_2:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_131d_2;
															IL_131d_2:
															num6 -= 2;
															goto IL_2340_2;
															IL_0cdc_2:
															if (53 < b)
															{
																break;
															}
															goto IL_158b_2;
															IL_158b_2:
															if (53 > b)
															{
																break;
															}
															goto IL_1599_2;
															IL_1599_2:
															array2[num6 - 1] = 3;
															goto IL_15ad_2;
															IL_15ad_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_15ec_2;
															IL_15ec_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0cef_2:
															if (56 < b)
															{
																goto IL_0cfa_2;
															}
															num = 425;
															goto IL_1330_2;
															IL_0cfa_2:
															if (57 < b)
															{
																break;
															}
															num = 249;
															goto IL_0d11_2;
															IL_10f5_2:
															if (42 < b)
															{
																break;
															}
															goto IL_16e5_2;
															IL_0d11_2:
															if (57 <= b)
															{
																num = 342;
															}
															break;
															IL_16e5_2:
															if (42 > b)
															{
																break;
															}
															goto IL_16f3_2;
															IL_1578_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_1330_2:
															if (56 > b)
															{
																goto IL_133b_2;
															}
															num = 466;
															goto IL_176d_2;
															IL_133b_2:
															if (55 < b)
															{
																break;
															}
															goto IL_1349_2;
															IL_1349_2:
															if (55 > b)
															{
																break;
															}
															goto IL_15ff_2;
															IL_15ff_2:
															global::_003CModule_003E.string_46 = (string[])array3[num6 - 1];
															goto IL_1618_2;
															IL_1618_2:
															num6--;
															goto IL_2340_2;
															IL_16f3_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1733_2;
															IL_176d_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_2340_2;
															IL_156a_2:
															num6 -= 2;
															goto IL_1578_2;
															IL_0d44_2:
															if (43 <= b)
															{
																goto IL_0d4f_2;
															}
															goto IL_0d7f_2;
															IL_0d4f_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_13d7_2;
															IL_13d7_2:
															array2[num6 - 1] = 0;
															num = 357;
															goto IL_2340_2;
															IL_0d7f_2:
															if (36 >= b)
															{
																goto IL_0d8d_2;
															}
															goto IL_0f2f_2;
															IL_0d8d_2:
															if (36 > b)
															{
																goto IL_0d9b_2;
															}
															num = 170;
															goto IL_0ed9_2;
															IL_0d9b_2:
															if (32 < b)
															{
																goto IL_0da9_2;
															}
															goto IL_1108_2;
															IL_0da9_2:
															if (34 >= b)
															{
																goto IL_0db7_2;
															}
															goto IL_0e45_2;
															IL_0db7_2:
															if (34 > b)
															{
																goto IL_0dc2_2;
															}
															goto IL_0dd5_2;
															IL_0dc2_2:
															if (33 < b)
															{
																break;
															}
															goto IL_146e_2;
															IL_146e_2:
															if (33 > b)
															{
																break;
															}
															goto IL_147c_2;
															IL_147c_2:
															array2[num6 - 1] = 3;
															goto IL_1490_2;
															IL_1490_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_14cf_2;
															IL_14cf_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0dd5_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															num = 318;
															goto IL_0e1e_2;
															IL_0e1e_2:
															array2[num6 - 2] = 3;
															goto IL_0e32_2;
															IL_0e32_2:
															num6--;
															goto IL_2340_2;
															IL_0e45_2:
															if (35 < b)
															{
																break;
															}
															goto IL_0e53_2;
															IL_0e53_2:
															if (35 > b)
															{
																break;
															}
															goto IL_0e61_2;
															IL_0e61_2:
															array2[num6 - 1] = 0;
															goto IL_0e75_2;
															IL_0e75_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 59;
															goto IL_0ebd_2;
															IL_0ebd_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_1108_2:
															if (32 > b)
															{
																goto IL_1113_2;
															}
															goto IL_118d_2;
															IL_1113_2:
															if (30 >= b)
															{
																goto IL_111e_2;
															}
															goto IL_1145_2;
															IL_111e_2:
															if (30 > b)
															{
																break;
															}
															goto IL_112c_2;
															IL_112c_2:
															array2[num6 - 2] = 5;
															goto IL_136a_2;
															IL_136a_2:
															array3[num6 - 2] = ((delegate*<string, string, string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
															goto IL_13b6_2;
															IL_13b6_2:
															num6--;
															goto IL_13c4_2;
															IL_13c4_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_1145_2:
															if (31 < b)
															{
																break;
															}
															goto IL_1153_2;
															IL_1153_2:
															if (31 > b)
															{
																break;
															}
															goto IL_1161_2;
															IL_1161_2:
															global::_003CModule_003E.string_48 = (string)array3[num6 - 1];
															goto IL_117a_2;
															IL_117a_2:
															num6--;
															goto IL_2340_2;
															IL_118d_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															num = 124;
															goto IL_11af_2;
															IL_11af_2:
															array2[num6] = 3;
															goto IL_11bd_2;
															IL_11bd_2:
															num6++;
															goto IL_11cb_2;
															IL_11cb_2:
															ptr2 += 16;
															goto IL_2340_2;
															IL_1733_2:
															array2[num6 - 2] = 3;
															goto IL_1747_2;
															IL_0ed9_2:
															array3[num6] = ((delegate*<string>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])();
															num = 328;
															goto IL_0f00_2;
															IL_0f00_2:
															array2[num6] = 5;
															goto IL_0f0e_2;
															IL_0f0e_2:
															num6++;
															goto IL_0f1c_2;
															IL_0f1c_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0f2f_2:
															if (39 >= b)
															{
																goto IL_0f3d_2;
															}
															goto IL_1055_2;
															IL_0f3d_2:
															if (39 > b)
															{
																goto IL_0f4b_2;
															}
															goto IL_0fe6_2;
															IL_0f4b_2:
															if (37 >= b)
															{
																goto IL_0f56_2;
															}
															goto IL_0fca_2;
															IL_0f56_2:
															if (37 > b)
															{
																break;
															}
															goto IL_0f64_2;
															IL_0f64_2:
															array2[num6 - 1] = 3;
															goto IL_0f78_2;
															IL_0f78_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0fb7_2;
															IL_0fb7_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_0fca_2:
															if (38 < b)
															{
																break;
															}
															num = 430;
															goto IL_13f9_2;
															IL_1747_2:
															num6--;
															goto IL_2340_2;
															IL_13f9_2:
															if (38 > b)
															{
																break;
															}
															goto IL_1407_2;
															IL_1407_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1447_2;
															IL_1447_2:
															array2[num6 - 2] = 3;
															goto IL_145b_2;
															IL_145b_2:
															num6--;
															goto IL_2340_2;
															IL_0fe6_2:
															array2[num6 - 1] = 0;
															goto IL_0ffa_2;
															IL_0ffa_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															num = 32;
															goto IL_1042_2;
															IL_1042_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_1055_2:
															if (41 >= b)
															{
																goto IL_1063_2;
															}
															goto IL_10f5_2;
															IL_1063_2:
															if (41 <= b)
															{
																goto IL_106e_2;
															}
															goto IL_10d4_2;
															IL_106e_2:
															array2[num6 - 1] = 3;
															goto IL_1082_2;
															IL_1082_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getTypeLibraryCustomErrorsEnabled[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_10c1_2;
															IL_10c1_2:
															ptr2 += 8;
															goto IL_2340_2;
															IL_10d4_2:
															if (40 < b)
															{
																break;
															}
															goto IL_10e2_2;
															IL_10e2_2:
															if (40 > b)
															{
																break;
															}
															goto IL_14e2_2;
														}
														break;
														IL_0884_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_2340_2;
												continue;
												end_IL_0894_2:
												break;
											}
											continue;
											end_IL_08a4:
											break;
										}
										continue;
										end_IL_08b4:
										break;
									}
									break;
								}
								goto IL_240c_2;
								IL_240c_2:
								return (string)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_1a42_2;
					}
					continue;
					end_IL_1a50:
					break;
				}
				break;
			}
		}
	}

	private static bool getMessageIdsetSystemAcl(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe void method_1()
	{
		RuntimeTypeHandle[] array = new RuntimeTypeHandle[1];
		Type[] array2 = new Type[1];
		array[0] = typeof(object).TypeHandle;
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaskSchedulerIsNewContextOK.InternalSerializerTypeEgetDriveType);
		int num = 4;
		int num2 = 9;
		int num3 = 9;
		num3 = 9;
		int try0033_dispatch = -1;
		object[] array3 = default(object[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num24 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0033_dispatch)
				{
				case 1989:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 144 + num8 * 72 + 32 + num);
							num10 = *(int*)(ptr + 144 + num8 * 72 + 8 + num);
							if (num5 < num9 + num10)
							{
								if (num9 <= num5)
								{
									break;
								}
								num7 = num8 - 1;
							}
							else
							{
								num6 = num8 + 1;
							}
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 144 + num11 * 72 + 56 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array3 != null)
							{
								if ((int)array3[4] == 1)
								{
									int num15 = (int)array3[6];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 24 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 360 + num8 * 56 + 24 + num);
											num6 = *(int*)(ptr + 360 + num8 * 56 + 8 + num);
											if (num17 >= num7 + num6)
											{
												num10 = num8 + 1;
												continue;
											}
											if (num7 <= num17)
											{
												break;
											}
											num9 = num8 - 1;
										}
										num12 = num8;
										num11 = *(int*)(ptr + 360 + num12 * 56 + 40 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array3 = (object[])array3[1];
										continue;
									}
								}
								else
								{
									int num18 = (int)array3[2];
									if (num18 != 2 && num18 != 1 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array3[6];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 24 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 360 + num8 * 56 + 24 + num);
											num10 = *(int*)(ptr + 360 + num8 * 56 + 8 + num);
											if (num5 >= num9 + num10)
											{
												num6 = num8 + 1;
												continue;
											}
											if (num9 <= num5)
											{
												break;
											}
											num7 = num8 - 1;
										}
										num11 = num8;
										num12 = *(int*)(ptr + 360 + num11 * 56 + 40 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array3 = (object[])array3[1];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_07d8;
							}
							num21 = *(int*)(ptr + num13 + 8 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 8 + num);
								if (2 != num7)
								{
									goto IL_071e;
								}
								num6 = *(int*)(ptr + num5 + 56 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 48 + num);
										continue;
									}
								}
								goto IL_0868;
							}
							num13 = *(int*)(ptr + num13 + 32 + num);
							continue;
							IL_071e:
							if (0 != num7)
							{
								num13 = *(int*)(ptr + num13 + 32 + num);
								continue;
							}
							goto IL_080f;
						}
						object[] array4 = array3;
						num4 = *(int*)(ptr + (int)array4[6] + 48 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 8 + num);
							if (2 != num21)
							{
								goto IL_0462;
							}
							num13 = *(int*)(ptr + num4 + 56 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[7]))
								{
									num4 = *(int*)(ptr + num4 + 48 + num);
									continue;
								}
							}
							goto IL_09f5;
						}
						goto IL_046a;
						IL_046a:
						array3 = (object[])array3[1];
						ex = (Exception)array4[7];
						num22 = (int)array4[5];
						continue;
						IL_0868:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 32 + num) + 32 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 56 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 32 + num);
									continue;
								}
								array4 = new object[8];
								array4[4] = 0;
								array4[1] = array3;
								array4[7] = ex;
								array4[5] = num14;
								array4[6] = num8;
								array4[3] = num17;
								array4[2] = 1;
								array3 = array4;
								num2 = *(int*)(ptr + num8 + 24 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[4] = 0;
							array4[1] = array3;
							array4[7] = ex;
							array4[5] = num14;
							array4[6] = num17;
							array4[2] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num17 + 24 + num);
							break;
						}
						break;
						IL_09f5:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 32 + num) + 32 + num);
						num14 = (int)array4[5];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 56 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 32 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 24 + num);
								array3 = (object[])array3[1];
								array5 = new object[8];
								array5[4] = 0;
								array5[1] = array3;
								array5[7] = array4[7];
								array5[5] = (int)array4[5];
								array5[6] = num18;
								array5[3] = num12;
								array5[2] = 1;
								array3 = array5;
								num2 = *(int*)(ptr + num18 + 24 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 24 + num);
							ex2 = (Exception)array4[7];
							array3 = (object[])array3[1];
							array5 = new object[8];
							array5[4] = 0;
							array5[1] = array3;
							array5[7] = array4[7];
							array5[5] = (int)array4[5];
							array5[6] = num12;
							array5[2] = 2;
							array3 = array5;
							num2 = *(int*)(ptr + num12 + 24 + num);
							break;
						}
						break;
						IL_080f:
						ex2 = ex;
						array4 = new object[8];
						array4[4] = 0;
						array4[1] = array3;
						array4[7] = ex;
						array4[5] = num14;
						array4[6] = num5;
						array4[2] = 0;
						array3 = array4;
						num2 = *(int*)(ptr + num5 + 64 + num);
						break;
						IL_07d8:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 56 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 32 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 24 + num);
						array4 = new object[8];
						array4[4] = 0;
						array4[1] = array3;
						array4[7] = ex;
						array4[5] = num14;
						array4[6] = -1;
						array4[3] = -1;
						array4[2] = 2;
						array3 = array4;
						num2 = *(int*)(ptr + num11 + 24 + num);
						break;
						IL_0462:
						if (0 == num21)
						{
							num5 = *(int*)(ptr + num4 + 64 + num);
							ex2 = (Exception)array4[7];
							array3 = (object[])array3[1];
							object[] array5 = new object[8];
							array5[4] = 0;
							array5[1] = array3;
							array5[7] = array4[7];
							array5[5] = (int)array4[5];
							array5[6] = num4;
							array5[2] = 0;
							array3 = array5;
							num2 = *(int*)(ptr + num4 + 64 + num);
							break;
						}
						goto IL_046a;
					}
					break;
				}
				while (true)
				{
					switch (num3)
					{
					case 4:
					{
						num3 = 9;
						int num13 = num24;
						int num31 = num13;
						int num11 = num2;
						int num21 = num11;
						num13 = 0;
						int num4 = 2;
						int num7;
						int num6;
						int num5;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 144 + num5 * 72 + 32 + num);
							num7 = *(int*)(ptr + 144 + num5 * 72 + 8 + num);
							if (num21 < num6 + num7)
							{
								if (num6 <= num21)
								{
									break;
								}
								num4 = num5 - 1;
							}
							else
							{
								num13 = num5 + 1;
							}
						}
						int num14 = num5;
						int num18 = *(int*)(ptr + 144 + num14 * 72 + 56 + num);
						int num12 = num18;
						num7 = num31;
						num6 = 0;
						num5 = 2;
						while (true)
						{
							num4 = (num6 + num5) / 2;
							num13 = *(int*)(ptr + 144 + num4 * 72 + 32 + num);
							num21 = *(int*)(ptr + 144 + num4 * 72 + 8 + num);
							if (num7 < num13 + num21)
							{
								if (num13 <= num7)
								{
									break;
								}
								num5 = num4 - 1;
							}
							else
							{
								num6 = num4 + 1;
							}
						}
						num14 = num4;
						int num8 = *(int*)(ptr + 144 + num14 * 72 + 56 + num);
						num18 = num8;
						num21 = num31;
						num13 = 0;
						num4 = 2;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 360 + num5 * 56 + 24 + num);
							num7 = *(int*)(ptr + 360 + num5 * 56 + 8 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						num14 = num5;
						int num9 = *(int*)(ptr + 360 + num14 * 56 + 40 + num);
						num8 = num9;
						while (true)
						{
							if (array3 == null || (int)array3[4] == 1)
							{
								num21 = num18;
								while (num21 != num12)
								{
									if (num21 != -1)
									{
										num21 = *(int*)(ptr + num21 + 32 + num);
										continue;
									}
									goto IL_01fe;
								}
								num2 = num31;
								break;
							}
							int num32 = (int)array3[6];
							int num33;
							if (num12 == -1)
							{
								num33 = -1;
							}
							else
							{
								int num10 = *(int*)(ptr + num12 + 24 + num);
								num7 = 0;
								num6 = 2;
								while (true)
								{
									num5 = (num7 + num6) / 2;
									num4 = *(int*)(ptr + 360 + num5 * 56 + 24 + num);
									num13 = *(int*)(ptr + 360 + num5 * 56 + 8 + num);
									if (num10 < num4 + num13)
									{
										if (num4 <= num10)
										{
											break;
										}
										num6 = num5 - 1;
									}
									else
									{
										num7 = num5 + 1;
									}
								}
								num9 = num5;
								num14 = *(int*)(ptr + 360 + num9 * 56 + 40 + num);
								num33 = num14;
							}
							if (num32 == num33)
							{
								num14 = num18;
								while (num14 != num12)
								{
									if (num14 != -1)
									{
										num14 = *(int*)(ptr + num14 + 32 + num);
										continue;
									}
									goto IL_02f5;
								}
								num2 = num31;
								break;
							}
							if ((int)array3[6] != num8)
							{
								array3 = (object[])array3[1];
								continue;
							}
							num2 = num31;
							break;
							IL_02f5:
							num9 = *(int*)(ptr + num12 + 56 + num);
							if (num9 == -1)
							{
								num12 = *(int*)(ptr + num12 + 32 + num);
								continue;
							}
							num21 = *(int*)(ptr + num9 + 24 + num);
							object[] array4 = new object[8];
							array4[4] = 1;
							array4[1] = array3;
							array4[0] = num31;
							array4[6] = num9;
							array4[2] = 1;
							array3 = array4;
							num2 = *(int*)(ptr + num9 + 24 + num);
							break;
							IL_01fe:
							num13 = *(int*)(ptr + num12 + 56 + num);
							if (num13 == -1)
							{
								num12 = *(int*)(ptr + num12 + 32 + num);
								continue;
							}
							num4 = *(int*)(ptr + num13 + 24 + num);
							array4 = new object[8];
							array4[4] = 1;
							array4[1] = array3;
							array4[0] = num31;
							array4[6] = num13;
							array4[2] = 1;
							array3 = array4;
							num2 = *(int*)(ptr + num13 + 24 + num);
							break;
						}
						break;
					}
					default:
						((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, Class158, void>)getPermissionSetsetDataPointer[num2])(ref num2, ref num3, ref num24, ex2, ref num25, ref num26, ref num27, ref num28, ref num29, ref num30, this);
						break;
					case 0:
						num3 = 9;
						return;
					}
				}
			}
			catch (Exception ex3)
			{
				if (num23 == 1)
				{
					throw ex3;
				}
				ex = ex3;
				num22 = -1;
				try0033_dispatch = 1989;
			}
		}
	}

	private static int PropertyInfoBindingRedirects(int int_2)
	{
		return smethod_1(int_2);
	}

	private static void PRIExceptionInfoEncodeTags(GorillaComputer gorillaComputer_0, string string_2)
	{
		gorillaComputer_0.SetLocalNameTagText(string_2);
	}

	private static string DefaultIssueraddReflectionOnlyNamespaceResolve(Class158 class158_1)
	{
		return class158_1.method_0();
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 81;
				while (true)
				{
					num = 52;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									num = 40;
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EmitInformationalVersion.COREENDOFSTREAMCustomAttributeFormatException);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02f0:
															byte b = *ptr2;
															while (true)
															{
																IL_02e0:
																ptr2++;
																while (true)
																{
																	IL_02d0:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02b0:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02a0:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0290:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0283:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0273:
																												if (1 >= b)
																												{
																													while (1 <= b)
																													{
																														while (true)
																														{
																															IL_023f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															num = 6;
																															while (true)
																															{
																																IL_022f:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_021f:
																																	num5++;
																																	while (true)
																																	{
																																		IL_0206:
																																		ptr2 += 8;
																																		num = 121;
																																		while (num != 121)
																																		{
																																			if (num != 1102)
																																			{
																																				goto IL_04ad;
																																			}
																																			switch (num)
																																			{
																																			case 53:
																																				goto IL_0206;
																																			case 91:
																																				goto IL_021f;
																																			case 6:
																																				goto IL_022f;
																																			case 70:
																																			case 104:
																																				goto IL_023f;
																																			case 67:
																																				goto IL_0263;
																																			case 88:
																																				goto IL_0273;
																																			case 60:
																																				goto IL_0283;
																																			case 44:
																																				goto IL_0290;
																																			case 22:
																																				goto IL_02a0;
																																			case 92:
																																				goto IL_02b0;
																																			case 58:
																																				goto IL_02c0;
																																			case 14:
																																				goto IL_02d0;
																																			case 54:
																																				goto IL_02e0;
																																			case 68:
																																			case 109:
																																				goto IL_02f0;
																																			case 1:
																																			case 8:
																																				goto IL_02fb;
																																			case 55:
																																			case 113:
																																				goto IL_0313;
																																			case 99:
																																				goto IL_0321;
																																			case 51:
																																			case 80:
																																				goto IL_032f;
																																			case 35:
																																				goto IL_0358;
																																			case 78:
																																				goto IL_0366;
																																			case 45:
																																				goto IL_0379;
																																			case 10:
																																			case 26:
																																				goto IL_0384;
																																			case 96:
																																				goto IL_0392;
																																			case 49:
																																			case 61:
																																				goto IL_03a0;
																																			case 84:
																																				goto IL_03ae;
																																			case 89:
																																				goto IL_03d1;
																																			case 9:
																																				goto IL_03db;
																																			case 24:
																																				goto IL_03e9;
																																			case 5:
																																				goto IL_03fc;
																																			case 23:
																																			case 108:
																																				goto IL_040f;
																																			case 94:
																																				goto IL_044f;
																																			case 114:
																																				goto IL_0463;
																																			case 102:
																																				goto IL_0476;
																																			case 79:
																																			case 110:
																																				goto IL_0481;
																																			case 19:
																																			case 48:
																																				goto IL_048c;
																																			case 41:
																																				goto IL_049a;
																																			case 43:
																																				goto IL_04ad;
																																			case 21:
																																			case 31:
																																				goto IL_04bb;
																																			case 98:
																																				goto IL_04d7;
																																			case 11:
																																			case 15:
																																				goto IL_04e5;
																																			case 27:
																																				goto IL_04f0;
																																			case 16:
																																			case 69:
																																				goto IL_04fe;
																																			case 87:
																																				goto IL_053e;
																																			case 73:
																																				goto IL_0552;
																																			case 97:
																																				goto IL_0565;
																																			case 95:
																																				goto IL_0573;
																																			case 4:
																																			case 111:
																																				goto IL_058c;
																																			case 103:
																																				goto IL_05af;
																																			case 46:
																																				goto IL_05bd;
																																			case 38:
																																				goto IL_05cb;
																																			case 25:
																																			case 30:
																																				goto IL_05de;
																																			case 12:
																																				goto IL_0640;
																																			case 0:
																																			case 2:
																																			case 3:
																																			case 13:
																																			case 32:
																																			case 33:
																																			case 36:
																																			case 37:
																																			case 42:
																																			case 50:
																																			case 57:
																																			case 62:
																																			case 64:
																																			case 65:
																																			case 71:
																																			case 72:
																																			case 82:
																																			case 83:
																																			case 85:
																																			case 100:
																																			case 105:
																																			case 112:
																																				goto end_IL_0263;
																																			case 17:
																																			case 28:
																																			case 29:
																																			case 39:
																																			case 47:
																																			case 59:
																																			case 63:
																																			case 66:
																																			case 86:
																																			case 93:
																																			case 101:
																																			case 106:
																																			case 107:
																																				goto end_IL_01f3;
																																			case 90:
																																				goto end_IL_0663;
																																			case 18:
																																				goto end_IL_0676;
																																			case 40:
																																				goto end_IL_0680;
																																			case 20:
																																				goto end_IL_068b;
																																			case 7:
																																			case 74:
																																				goto end_IL_06a0;
																																			case 56:
																																				goto end_IL_06b9;
																																			case 52:
																																				goto end_IL_06c9;
																																			case 81:
																																				goto end_IL_06d9;
																																			case 75:
																																				goto end_IL_06e9;
																																			case 76:
																																				goto end_IL_06f4;
																																			case 34:
																																			case 77:
																																				goto IL_0718;
																																			}
																																			continue;
																																			end_IL_01f3:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02d0;
																														continue;
																														end_IL_0263:
																														break;
																														IL_0263:;
																													}
																													break;
																												}
																												goto IL_0313;
																												IL_0366:
																												num5--;
																												goto end_IL_02d0;
																												IL_0313:
																												if (2 < b)
																												{
																													break;
																												}
																												goto IL_0321;
																												IL_0321:
																												if (2 > b)
																												{
																													break;
																												}
																												goto IL_032f;
																												IL_032f:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0358;
																												IL_0358:
																												ptr2 += 8;
																												goto IL_0366;
																											}
																											break;
																										}
																										goto IL_02fb;
																										IL_02fb:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02d0;
																									}
																									break;
																								}
																								goto IL_0379;
																								IL_03fc:
																								if (4 <= b)
																								{
																									goto end_IL_02d0;
																								}
																								break;
																								IL_0379:
																								if (4 < b)
																								{
																									goto IL_0384;
																								}
																								goto IL_03fc;
																								IL_0384:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_0392;
																								IL_0392:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_03a0;
																								IL_03a0:
																								array[num5] = 0;
																								goto IL_03ae;
																								IL_03ae:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03d1;
																								IL_03d1:
																								array2[num5] = null;
																								goto IL_03db;
																								IL_03db:
																								num5++;
																								goto IL_03e9;
																								IL_03e9:
																								ptr2 += 8;
																								goto end_IL_02d0;
																							}
																							break;
																						}
																						goto IL_040f;
																						IL_0463:
																						num5--;
																						goto end_IL_02d0;
																						IL_040f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_044f;
																						IL_044f:
																						array[num5 - 2] = 0;
																						goto IL_0463;
																					}
																					break;
																				}
																				goto IL_0476;
																				IL_05de:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0640;
																				IL_0476:
																				if (9 < b)
																				{
																					goto IL_0481;
																				}
																				goto IL_04d7;
																				IL_0481:
																				if (10 < b)
																				{
																					goto IL_048c;
																				}
																				goto IL_04ad;
																				IL_048c:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_049a;
																				IL_049a:
																				if (11 > b)
																				{
																				}
																				break;
																				IL_04ad:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04bb;
																				IL_04bb:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02d0;
																				IL_04d7:
																				if (9 > b)
																				{
																					goto IL_04e5;
																				}
																				goto IL_05de;
																				IL_04e5:
																				if (7 >= b)
																				{
																					goto IL_04f0;
																				}
																				goto IL_0565;
																				IL_04f0:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04fe;
																				IL_04fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_053e;
																				IL_053e:
																				array[num5 - 2] = 0;
																				goto IL_0552;
																				IL_0552:
																				num5--;
																				goto end_IL_02d0;
																				IL_0565:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0573;
																				IL_0573:
																				if (8 > b)
																				{
																					num = 2;
																					break;
																				}
																				goto IL_058c;
																				IL_0640:
																				num5 -= 2;
																				goto end_IL_02d0;
																				IL_058c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05af;
																				IL_05af:
																				array[num5] = 0;
																				goto IL_05bd;
																				IL_05bd:
																				num5++;
																				goto IL_05cb;
																				IL_05cb:
																				ptr2 += 8;
																				goto end_IL_02d0;
																			}
																			break;
																			IL_02c0:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_02d0:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0718;
													IL_0718:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0663:
													break;
												}
												continue;
												end_IL_0676:
												break;
											}
											continue;
											end_IL_0680:
											break;
										}
										continue;
										end_IL_068b:
										break;
									}
									continue;
									end_IL_06a0:
									break;
								}
								continue;
								end_IL_06b9:
								break;
							}
							continue;
							end_IL_06c9:
							break;
						}
						continue;
						end_IL_06d9:
						break;
					}
					continue;
					end_IL_06e9:
					break;
				}
				continue;
				end_IL_06f4:
				break;
			}
		}
	}

	private static Player NotSupportedExceptiongetDisallowApplicationBaseProbing()
	{
		return PhotonNetwork.LocalPlayer;
	}

	private static string setLevelTCEAdapterGenerator(Class158 class158_1)
	{
		return class158_1.string_1;
	}

	private unsafe void method_2()
	{
		int num = 8;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 121;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExceptionTypeAsDispatch.setViewAccessControlMakePointerType);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_0672:
															byte b = *ptr2;
															while (true)
															{
																IL_0662:
																ptr2++;
																while (true)
																{
																	IL_0652:
																	if (b >= 1)
																	{
																		goto IL_0352;
																	}
																	goto IL_0631;
																	IL_0631:
																	while (true)
																	{
																		IL_0631_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 204;
																		while (num != 204)
																		{
																			if (num != 1185)
																			{
																				goto IL_088c;
																			}
																			switch (num)
																			{
																			case 137:
																				goto IL_0352;
																			case 167:
																				goto IL_0369;
																			case 75:
																				goto IL_0377;
																			case 38:
																				goto IL_0385;
																			case 128:
																				goto IL_039e;
																			case 52:
																				goto IL_03a9;
																			case 158:
																				goto IL_03b7;
																			case 153:
																				goto IL_03ca;
																			case 107:
																				goto IL_03d8;
																			case 76:
																				goto IL_03e3;
																			case 59:
																				goto IL_03f6;
																			case 58:
																				goto IL_0409;
																			case 129:
																				goto IL_0414;
																			case 36:
																				goto IL_0427;
																			case 149:
																				goto IL_0432;
																			case 114:
																				goto IL_043d;
																			case 68:
																				goto IL_0450;
																			case 15:
																				goto IL_045e;
																			case 54:
																				goto IL_0471;
																			case 136:
																				goto IL_047f;
																			case 100:
																				goto IL_048d;
																			case 169:
																				goto IL_04a0;
																			case 183:
																				goto IL_04b3;
																			case 184:
																				goto IL_04c6;
																			case 106:
																				goto IL_04d4;
																			case 145:
																				goto IL_04df;
																			case 173:
																				goto IL_04ed;
																			case 73:
																				goto IL_04fb;
																			case 117:
																				goto IL_050e;
																			case 161:
																				goto IL_0519;
																			case 4:
																				goto IL_052c;
																			case 97:
																				goto IL_053a;
																			case 185:
																				goto IL_054d;
																			case 78:
																				goto IL_0558;
																			case 181:
																				goto IL_0566;
																			case 12:
																				goto IL_0571;
																			case 151:
																				goto IL_057f;
																			case 131:
																				goto IL_059b;
																			case 144:
																				goto IL_05ae;
																			case 180:
																				goto IL_05b9;
																			case 88:
																				goto IL_05c9;
																			case 47:
																				goto IL_05d4;
																			case 189:
																				goto IL_05e4;
																			case 11:
																				goto IL_05f8;
																			case 190:
																				goto IL_0608;
																			case 197:
																				goto IL_0618;
																			case 32:
																				goto IL_0623;
																			case 10:
																			case 14:
																			case 24:
																			case 26:
																			case 50:
																			case 51:
																			case 55:
																			case 63:
																			case 66:
																			case 69:
																			case 70:
																			case 77:
																			case 89:
																			case 90:
																			case 95:
																			case 98:
																			case 112:
																			case 127:
																			case 133:
																			case 138:
																			case 141:
																			case 150:
																			case 159:
																			case 174:
																			case 179:
																			case 194:
																				goto IL_0631_2;
																			case 5:
																				goto IL_0652;
																			case 21:
																				goto IL_0662;
																			case 177:
																			case 192:
																				goto IL_0672;
																			case 9:
																			case 31:
																				goto IL_067d;
																			case 46:
																				goto IL_06bd;
																			case 28:
																				goto IL_06d1;
																			case 3:
																			case 35:
																				goto IL_06ed;
																			case 94:
																				goto IL_072d;
																			case 79:
																				goto IL_0741;
																			case 142:
																			case 156:
																				goto IL_0754;
																			case 84:
																				goto IL_076d;
																			case 41:
																			case 148:
																				goto IL_0780;
																			case 123:
																			case 165:
																				goto IL_079c;
																			case 110:
																				goto IL_07b0;
																			case 6:
																				goto IL_07ef;
																			case 27:
																			case 170:
																				goto IL_0810;
																			case 56:
																				goto IL_0829;
																			case 0:
																				goto IL_0837;
																			case 125:
																				goto IL_0845;
																			case 178:
																				goto IL_0858;
																			case 108:
																				goto IL_0866;
																			case 111:
																			case 175:
																				goto IL_0879;
																			case 65:
																			case 109:
																				goto IL_088c;
																			case 147:
																				goto IL_08b5;
																			case 19:
																			case 164:
																				goto IL_08d1;
																			case 134:
																				goto IL_08ea;
																			case 102:
																				goto IL_08f8;
																			case 40:
																				goto IL_0906;
																			case 1:
																			case 113:
																				goto IL_0919;
																			case 30:
																				goto IL_0927;
																			case 20:
																				goto IL_094a;
																			case 57:
																			case 120:
																				goto IL_0959;
																			case 87:
																			case 96:
																				goto IL_09ac;
																			case 61:
																				goto IL_09fe;
																			case 23:
																			case 118:
																				goto IL_0a1a;
																			case 146:
																				goto IL_0a5b;
																			case 42:
																				goto IL_0a6f;
																			case 72:
																			case 85:
																				goto IL_0a82;
																			case 48:
																			case 119:
																				goto IL_0aa3;
																			case 62:
																				goto IL_0abb;
																			case 135:
																				goto IL_0ac9;
																			case 124:
																				goto IL_0ad7;
																			case 152:
																			case 171:
																				goto IL_0aea;
																			case 16:
																				goto IL_0b13;
																			case 33:
																				goto IL_0b21;
																			case 186:
																				goto IL_0b34;
																			case 155:
																				goto IL_0b48;
																			case 122:
																			case 187:
																				goto IL_0b5b;
																			case 130:
																				goto IL_0b6f;
																			case 182:
																				goto IL_0bae;
																			case 22:
																			case 154:
																				goto IL_0bc1;
																			case 74:
																				goto IL_0c01;
																			case 126:
																				goto IL_0c15;
																			case 67:
																			case 163:
																				goto IL_0c31;
																			case 172:
																				goto IL_0c93;
																			case 105:
																			case 191:
																				goto IL_0ca6;
																			case 166:
																				goto IL_0ce6;
																			case 139:
																				goto IL_0cfa;
																			case 195:
																				goto IL_0d0d;
																			case 116:
																				goto IL_0d1b;
																			case 196:
																				goto IL_0d2b;
																			case 160:
																			case 193:
																				goto IL_0d3b;
																			case 13:
																				goto IL_0d7b;
																			case 176:
																				goto IL_0d8f;
																			case 2:
																			case 17:
																			case 25:
																			case 29:
																			case 34:
																			case 39:
																			case 43:
																			case 45:
																			case 49:
																			case 60:
																			case 64:
																			case 71:
																			case 80:
																			case 81:
																			case 86:
																			case 91:
																			case 93:
																			case 101:
																			case 103:
																			case 104:
																			case 115:
																			case 140:
																			case 157:
																			case 168:
																			case 188:
																				goto end_IL_033f;
																			case 99:
																				goto end_IL_0d9d;
																			case 18:
																				goto end_IL_0db0;
																			case 37:
																				goto end_IL_0dba;
																			case 162:
																				goto end_IL_0dc5;
																			case 132:
																				goto end_IL_0dd5;
																			case 53:
																			case 143:
																				goto end_IL_0de5;
																			case 82:
																				goto end_IL_0df5;
																			case 121:
																				goto end_IL_0e05;
																			case 92:
																				goto end_IL_0e15;
																			case 7:
																				goto end_IL_0e25;
																			case 8:
																				goto end_IL_0e3e;
																			case 44:
																			case 83:
																				return;
																			}
																			continue;
																			end_IL_033f:
																			break;
																		}
																		break;
																	}
																	break;
																	IL_0352:
																	if (b <= 23)
																	{
																		num = 167;
																		goto IL_0369;
																	}
																	goto IL_0631;
																	IL_05f8:
																	if (20 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0bc1;
																	IL_0369:
																	if (12 >= b)
																	{
																		goto IL_0377;
																	}
																	goto IL_0409;
																	IL_0377:
																	if (12 > b)
																	{
																		goto IL_0385;
																	}
																	goto IL_0754;
																	IL_0385:
																	if (6 < b)
																	{
																		goto IL_039e;
																	}
																	num = 184;
																	goto IL_04c6;
																	IL_0bc1:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0c01;
																	IL_04c6:
																	if (6 > b)
																	{
																		goto IL_04d4;
																	}
																	num = 105;
																	goto IL_0ca6;
																	IL_04d4:
																	if (3 >= b)
																	{
																		goto IL_04df;
																	}
																	goto IL_050e;
																	IL_04df:
																	if (3 > b)
																	{
																		goto IL_04ed;
																	}
																	goto IL_088c;
																	IL_04ed:
																	if (1 >= b)
																	{
																		goto IL_04fb;
																	}
																	goto IL_0618;
																	IL_04fb:
																	if (1 > b)
																	{
																		goto IL_0631;
																	}
																	num = 164;
																	goto IL_08d1;
																	IL_0c15:
																	num6--;
																	num = 29;
																	break;
																	IL_08d1:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_08ea;
																	IL_08ea:
																	array[num6] = 0;
																	goto IL_08f8;
																	IL_08f8:
																	num6++;
																	goto IL_0906;
																	IL_0906:
																	ptr2 += 8;
																	break;
																	IL_0618:
																	if (2 >= b)
																	{
																		goto IL_0623;
																	}
																	goto IL_0631;
																	IL_0623:
																	if (2 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0d3b;
																	IL_0d3b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0d7b;
																	IL_0d7b:
																	array[num6 - 2] = 0;
																	goto IL_0d8f;
																	IL_0d8f:
																	num6--;
																	break;
																	IL_088c:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_08b5;
																	IL_08b5:
																	ptr2 += 8;
																	goto IL_0d2b;
																	IL_0d2b:
																	num6--;
																	break;
																	IL_050e:
																	if (4 >= b)
																	{
																		goto IL_0519;
																	}
																	goto IL_052c;
																	IL_0519:
																	if (4 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0919;
																	IL_0919:
																	array[num6] = 0;
																	goto IL_0927;
																	IL_0927:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_094a;
																	IL_094a:
																	array2[num6] = null;
																	goto IL_0d0d;
																	IL_0d0d:
																	num6++;
																	goto IL_0d1b;
																	IL_0d1b:
																	ptr2 += 8;
																	break;
																	IL_052c:
																	if (5 >= b)
																	{
																		goto IL_053a;
																	}
																	goto IL_0631;
																	IL_053a:
																	if (5 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0959;
																	IL_0959:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0b34;
																	IL_0b34:
																	array[num6 - 2] = 0;
																	goto IL_0b48;
																	IL_0b48:
																	num6--;
																	break;
																	IL_0c01:
																	array[num6 - 2] = 3;
																	goto IL_0c15;
																	IL_0ca6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_0ce6;
																	IL_0ce6:
																	array[num6 - 2] = 0;
																	goto IL_0cfa;
																	IL_0cfa:
																	num6--;
																	break;
																	IL_039e:
																	if (9 < b)
																	{
																		goto IL_03a9;
																	}
																	goto IL_03ca;
																	IL_03a9:
																	if (10 < b)
																	{
																		goto IL_03b7;
																	}
																	goto IL_0608;
																	IL_03b7:
																	if (11 >= b)
																	{
																		goto IL_04a0;
																	}
																	goto IL_0631;
																	IL_04a0:
																	if (11 <= b)
																	{
																		break;
																	}
																	goto IL_0631;
																	IL_0608:
																	if (10 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0c31;
																	IL_0c31:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_0c93;
																	IL_0c93:
																	num6 -= 2;
																	break;
																	IL_03ca:
																	if (9 > b)
																	{
																		goto IL_03d8;
																	}
																	goto IL_067d;
																	IL_03d8:
																	if (7 >= b)
																	{
																		goto IL_03e3;
																	}
																	goto IL_03f6;
																	IL_03e3:
																	if (7 > b)
																	{
																		goto IL_0631;
																	}
																	num = 3;
																	goto IL_06ed;
																	IL_0b6f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ExponentBigMul[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_0bae;
																	IL_06ed:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_072d;
																	IL_072d:
																	array[num6 - 2] = 0;
																	goto IL_0741;
																	IL_0741:
																	num6--;
																	break;
																	IL_03f6:
																	if (8 >= b)
																	{
																		goto IL_04b3;
																	}
																	goto IL_0631;
																	IL_04b3:
																	if (8 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0879;
																	IL_0879:
																	num6--;
																	break;
																	IL_067d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																	goto IL_06bd;
																	IL_06bd:
																	array[num6 - 2] = 0;
																	goto IL_06d1;
																	IL_06d1:
																	num6--;
																	break;
																	IL_0754:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																	goto IL_076d;
																	IL_076d:
																	array[num6] = 1;
																	goto IL_0858;
																	IL_0858:
																	num6++;
																	goto IL_0866;
																	IL_0866:
																	ptr2 += 16;
																	break;
																	IL_0409:
																	if (18 >= b)
																	{
																		goto IL_0414;
																	}
																	goto IL_0427;
																	IL_0414:
																	if (18 > b)
																	{
																		goto IL_054d;
																	}
																	goto IL_0810;
																	IL_0810:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																	goto IL_0829;
																	IL_0829:
																	array[num6] = 3;
																	goto IL_0837;
																	IL_0837:
																	num6++;
																	goto IL_0845;
																	IL_0845:
																	ptr2 += 16;
																	break;
																	IL_054d:
																	if (15 >= b)
																	{
																		goto IL_0558;
																	}
																	goto IL_05ae;
																	IL_0558:
																	if (15 > b)
																	{
																		goto IL_0566;
																	}
																	goto IL_09ac;
																	IL_0566:
																	if (13 < b)
																	{
																		goto IL_0571;
																	}
																	num = 131;
																	goto IL_059b;
																	IL_0571:
																	if (14 >= b)
																	{
																		goto IL_057f;
																	}
																	goto IL_0631;
																	IL_057f:
																	if (14 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0a1a;
																	IL_0a1a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																	goto IL_0a5b;
																	IL_0a5b:
																	array[num6 - 2] = 0;
																	goto IL_0a6f;
																	IL_0a6f:
																	num6--;
																	break;
																	IL_0b5b:
																	array[num6 - 1] = 0;
																	goto IL_0b6f;
																	IL_059b:
																	if (13 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0a82;
																	IL_0a82:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 45;
																	break;
																	IL_09ac:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_09fe;
																	IL_09fe:
																	num6--;
																	num = 64;
																	break;
																	IL_05ae:
																	if (16 >= b)
																	{
																		goto IL_05b9;
																	}
																	goto IL_05c9;
																	IL_05b9:
																	if (16 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0aa3;
																	IL_0aa3:
																	array2[num6] = array5[*(int*)(ptr2 + num3)];
																	goto IL_0abb;
																	IL_0abb:
																	array[num6] = 5;
																	goto IL_0ac9;
																	IL_0ac9:
																	num6++;
																	goto IL_0ad7;
																	IL_0ad7:
																	ptr2 += 8;
																	break;
																	IL_05c9:
																	if (17 >= b)
																	{
																		goto IL_05d4;
																	}
																	goto IL_0631;
																	IL_05d4:
																	if (17 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0aea;
																	IL_0aea:
																	((delegate*<Class158, void>)ExponentBigMul[*(int*)(ptr2 + num3)])((Class158)array2[num6 - 1]);
																	goto IL_0b13;
																	IL_0b13:
																	num6--;
																	goto IL_0b21;
																	IL_0b21:
																	ptr2 += 8;
																	break;
																	IL_0427:
																	if (21 < b)
																	{
																		goto IL_0432;
																	}
																	goto IL_0471;
																	IL_0432:
																	if (22 >= b)
																	{
																		goto IL_043d;
																	}
																	goto IL_0450;
																	IL_043d:
																	if (22 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_0780;
																	IL_0780:
																	byte* num7 = ptr2;
																	num5 = 1;
																	ptr2 = num7 + -200;
																	break;
																	IL_0450:
																	if (23 >= b)
																	{
																		goto IL_045e;
																	}
																	goto IL_0631;
																	IL_045e:
																	if (23 > b)
																	{
																	}
																	goto IL_0631;
																	IL_0471:
																	if (21 > b)
																	{
																		goto IL_047f;
																	}
																	num = 122;
																	goto IL_0b5b;
																	IL_047f:
																	if (19 >= b)
																	{
																		goto IL_048d;
																	}
																	goto IL_05e4;
																	IL_048d:
																	if (19 > b)
																	{
																		goto IL_0631;
																	}
																	goto IL_079c;
																	IL_079c:
																	array[num6 - 1] = 3;
																	goto IL_07b0;
																	IL_07b0:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ExponentBigMul[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																	goto IL_07ef;
																	IL_07ef:
																	ptr2 += 8;
																	break;
																	IL_05e4:
																	if (20 >= b)
																	{
																		num = 11;
																		goto IL_05f8;
																	}
																	goto IL_0631;
																	IL_0bae:
																	ptr2 += 8;
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0d9d:
														break;
													}
													continue;
													end_IL_0db0:
													break;
												}
												continue;
												end_IL_0dba:
												break;
											}
											continue;
											end_IL_0dc5:
											break;
										}
										continue;
										end_IL_0dd5:
										break;
									}
									continue;
									end_IL_0de5:
									break;
								}
								continue;
								end_IL_0df5:
								break;
							}
							continue;
							end_IL_0e05:
							break;
						}
						continue;
						end_IL_0e15:
						break;
					}
					continue;
					end_IL_0e25:
					break;
				}
				continue;
				end_IL_0e3e:
				break;
			}
		}
	}

	private static GorillaComputer GetVariablesGetXmlNamespaceForMethodResponse()
	{
		return GorillaComputer.instance;
	}

	private unsafe static int smethod_5()
	{
		int num = 129;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 112;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDynamicBaseCreatorsSecurityInfo.GetInterfacesgetParamValues);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_03ac:
															num = 48;
															while (true)
															{
																IL_03a1:
																byte b = *ptr2;
																while (true)
																{
																	IL_0388:
																	ptr2++;
																	num = 90;
																	while (true)
																	{
																		IL_0378:
																		if (b >= 1)
																		{
																			while (b <= 15)
																			{
																				while (true)
																				{
																					IL_0358:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_0348:
																							if (12 >= b)
																							{
																								while (true)
																								{
																									IL_0338:
																									if (12 > b)
																									{
																										while (true)
																										{
																											IL_032b:
																											if (10 < b)
																											{
																												while (11 >= b)
																												{
																													while (11 <= b)
																													{
																														while (true)
																														{
																															IL_02c5:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															while (true)
																															{
																																IL_02af:
																																array[num5 - 2] = 0;
																																while (true)
																																{
																																	IL_0296:
																																	num5--;
																																	num = 157;
																																	while (num != 157)
																																	{
																																		if (num != 1138)
																																		{
																																			goto IL_07e9;
																																		}
																																		switch (num)
																																		{
																																		case 5:
																																			goto IL_0296;
																																		case 108:
																																			goto IL_02af;
																																		case 22:
																																		case 27:
																																			goto IL_02c5;
																																		case 4:
																																			goto IL_030b;
																																		case 34:
																																			goto IL_031b;
																																		case 67:
																																			goto IL_032b;
																																		case 149:
																																			goto IL_0338;
																																		case 75:
																																		case 137:
																																			goto IL_0348;
																																		case 92:
																																			goto IL_0358;
																																		case 86:
																																			goto IL_0368;
																																		case 90:
																																			goto IL_0378;
																																		case 51:
																																			goto IL_0388;
																																		case 48:
																																			goto IL_03a1;
																																		case 104:
																																			goto IL_03ac;
																																		case 12:
																																			goto IL_03b7;
																																		case 81:
																																			goto IL_03c2;
																																		case 39:
																																			goto IL_03d0;
																																		case 41:
																																		case 94:
																																			goto IL_03e3;
																																		case 95:
																																			goto IL_03f1;
																																		case 60:
																																			goto IL_0414;
																																		case 24:
																																			goto IL_041e;
																																		case 109:
																																			goto IL_042c;
																																		case 99:
																																		case 132:
																																			goto IL_043f;
																																		case 26:
																																		case 127:
																																			goto IL_044a;
																																		case 68:
																																			goto IL_0458;
																																		case 105:
																																			goto IL_046b;
																																		case 2:
																																		case 21:
																																			goto IL_0482;
																																		case 107:
																																			goto IL_049b;
																																		case 110:
																																		case 123:
																																			goto IL_04a9;
																																		case 13:
																																			goto IL_050b;
																																		case 88:
																																		case 100:
																																			goto IL_051e;
																																		case 35:
																																		case 143:
																																			goto IL_0543;
																																		case 116:
																																			goto IL_0583;
																																		case 1:
																																			goto IL_0597;
																																		case 25:
																																			goto IL_05aa;
																																		case 46:
																																		case 121:
																																			goto IL_05b8;
																																		case 131:
																																		case 146:
																																			goto IL_05c6;
																																		case 15:
																																			goto IL_05d4;
																																		case 3:
																																		case 8:
																																			goto IL_05df;
																																		case 66:
																																			goto IL_05ed;
																																		case 79:
																																		case 96:
																																			goto IL_05fb;
																																		case 140:
																																			goto IL_0609;
																																		case 150:
																																			goto IL_0621;
																																		case 30:
																																			goto IL_062f;
																																		case 36:
																																		case 87:
																																			goto IL_064b;
																																		case 6:
																																			goto IL_068a;
																																		case 91:
																																			goto IL_069d;
																																		case 134:
																																			goto IL_06ab;
																																		case 28:
																																		case 85:
																																			goto IL_06b9;
																																		case 31:
																																			goto IL_06e2;
																																		case 115:
																																			goto IL_06f0;
																																		case 136:
																																			goto IL_0703;
																																		case 29:
																																		case 74:
																																			goto IL_070e;
																																		case 138:
																																			goto IL_072c;
																																		case 71:
																																			goto IL_073a;
																																		case 120:
																																			goto IL_074d;
																																		case 11:
																																			goto IL_075b;
																																		case 89:
																																		case 122:
																																			goto IL_0766;
																																		case 148:
																																			goto IL_07a6;
																																		case 133:
																																			goto IL_07ba;
																																		case 77:
																																			goto IL_07cd;
																																		case 65:
																																			goto IL_07db;
																																		case 49:
																																		case 63:
																																			goto IL_07e9;
																																		case 126:
																																			goto IL_0802;
																																		case 58:
																																			goto IL_0810;
																																		case 42:
																																			goto IL_081e;
																																		case 82:
																																			goto IL_082e;
																																		case 53:
																																			goto IL_0839;
																																		case 59:
																																		case 97:
																																			goto IL_0844;
																																		case 144:
																																			goto IL_086d;
																																		case 80:
																																		case 118:
																																			goto IL_0883;
																																		case 0:
																																		case 9:
																																		case 10:
																																		case 17:
																																		case 18:
																																		case 19:
																																		case 37:
																																		case 38:
																																		case 40:
																																		case 44:
																																		case 50:
																																		case 52:
																																		case 54:
																																		case 56:
																																		case 61:
																																		case 62:
																																		case 72:
																																		case 73:
																																		case 76:
																																		case 83:
																																		case 93:
																																		case 98:
																																		case 101:
																																		case 102:
																																		case 103:
																																		case 106:
																																		case 141:
																																		case 142:
																																		case 145:
																																		case 147:
																																			goto end_IL_030b;
																																		case 16:
																																		case 20:
																																		case 23:
																																		case 32:
																																		case 33:
																																		case 47:
																																		case 64:
																																		case 69:
																																		case 70:
																																		case 84:
																																		case 111:
																																		case 114:
																																		case 117:
																																		case 124:
																																		case 125:
																																		case 135:
																																		case 139:
																																			goto end_IL_0283;
																																		case 55:
																																			goto end_IL_08ab;
																																		case 78:
																																			goto end_IL_08be;
																																		case 130:
																																			goto end_IL_08c8;
																																		case 113:
																																			goto end_IL_08d3;
																																		case 7:
																																		case 14:
																																			goto end_IL_08e3;
																																		case 119:
																																			goto end_IL_08f3;
																																		case 112:
																																			goto end_IL_0903;
																																		case 57:
																																			goto end_IL_0913;
																																		case 128:
																																			goto end_IL_0923;
																																		case 129:
																																			goto end_IL_092e;
																																		case 43:
																																		case 45:
																																			goto IL_0949;
																																		}
																																		continue;
																																		end_IL_0283:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0378;
																														continue;
																														end_IL_030b:
																														break;
																														IL_030b:;
																													}
																													break;
																													IL_031b:;
																												}
																												break;
																											}
																											goto IL_03b7;
																											IL_042c:
																											ptr2 += 8;
																											goto end_IL_0378;
																											IL_03b7:
																											if (10 > b)
																											{
																												goto IL_03c2;
																											}
																											goto IL_03e3;
																											IL_03c2:
																											if (9 < b)
																											{
																												break;
																											}
																											goto IL_03d0;
																											IL_03d0:
																											if (9 > b)
																											{
																												break;
																											}
																											goto end_IL_0378;
																											IL_03e3:
																											array[num5] = 0;
																											goto IL_03f1;
																											IL_03f1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0414;
																											IL_0414:
																											array2[num5] = null;
																											goto IL_041e;
																											IL_041e:
																											num5++;
																											goto IL_042c;
																										}
																										break;
																									}
																									goto IL_0543;
																									IL_0597:
																									num5--;
																									goto end_IL_0378;
																									IL_0543:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0583;
																									IL_0583:
																									array[num5 - 2] = 0;
																									goto IL_0597;
																								}
																								break;
																							}
																							goto IL_043f;
																							IL_04a9:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_050b;
																							IL_043f:
																							if (14 < b)
																							{
																								goto IL_044a;
																							}
																							goto IL_046b;
																							IL_044a:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_0458;
																							IL_0458:
																							if (15 > b)
																							{
																							}
																							break;
																							IL_046b:
																							if (14 > b)
																							{
																								num = 21;
																								goto IL_0482;
																							}
																							goto IL_051e;
																							IL_050b:
																							num5 -= 2;
																							goto end_IL_0378;
																							IL_0482:
																							if (13 < b)
																							{
																								num = 37;
																								break;
																							}
																							goto IL_049b;
																							IL_051e:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							num = 33;
																							goto end_IL_0378;
																							IL_049b:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_04a9;
																						}
																						break;
																					}
																					goto IL_05aa;
																					IL_0883:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0378;
																					IL_05aa:
																					if (8 > b)
																					{
																						goto IL_05b8;
																					}
																					goto IL_0883;
																					IL_05b8:
																					if (4 < b)
																					{
																						goto IL_05c6;
																					}
																					goto IL_0703;
																					IL_05c6:
																					if (6 >= b)
																					{
																						goto IL_05d4;
																					}
																					goto IL_069d;
																					IL_05d4:
																					if (6 > b)
																					{
																						goto IL_05df;
																					}
																					goto IL_064b;
																					IL_05df:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_05ed;
																					IL_05ed:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_05fb;
																					IL_05fb:
																					array[num5] = 5;
																					goto IL_0609;
																					IL_0609:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0621;
																					IL_0621:
																					num5++;
																					goto IL_062f;
																					IL_062f:
																					ptr2 += 8;
																					num = 23;
																					goto end_IL_0378;
																					IL_064b:
																					((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_068a;
																					IL_068a:
																					num5 -= 3;
																					goto end_IL_0378;
																					IL_069d:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_06ab;
																					IL_06ab:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_06b9;
																					IL_06b9:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06e2;
																					IL_06e2:
																					ptr2 += 8;
																					goto IL_06f0;
																					IL_06f0:
																					num5--;
																					goto end_IL_0378;
																					IL_0703:
																					if (4 <= b)
																					{
																						goto IL_070e;
																					}
																					goto IL_074d;
																					IL_070e:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_072c;
																					IL_072c:
																					ptr2 += 8;
																					goto IL_073a;
																					IL_073a:
																					num5--;
																					goto end_IL_0378;
																					IL_074d:
																					if (2 >= b)
																					{
																						goto IL_075b;
																					}
																					goto IL_082e;
																					IL_075b:
																					if (2 <= b)
																					{
																						goto IL_0766;
																					}
																					goto IL_07cd;
																					IL_0766:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_07a6;
																					IL_07a6:
																					array[num5 - 2] = 0;
																					goto IL_07ba;
																					IL_07ba:
																					num5--;
																					goto end_IL_0378;
																					IL_07cd:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_07db;
																					IL_07db:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_07e9;
																					IL_07e9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0802;
																					IL_0802:
																					array[num5] = 0;
																					goto IL_0810;
																					IL_0810:
																					num5++;
																					goto IL_081e;
																					IL_081e:
																					ptr2 += 8;
																					goto end_IL_0378;
																					IL_082e:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0839;
																					IL_0839:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0844;
																					IL_0844:
																					array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_086d;
																					IL_086d:
																					array[num5 - 1] = 5;
																					goto end_IL_0378;
																				}
																				break;
																				IL_0368:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0378:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0949;
													IL_0949:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08ab:
													break;
												}
												continue;
												end_IL_08be:
												break;
											}
											continue;
											end_IL_08c8:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08e3:
									break;
								}
								continue;
								end_IL_08f3:
								break;
							}
							continue;
							end_IL_0903:
							break;
						}
						continue;
						end_IL_0913:
						break;
					}
					continue;
					end_IL_0923:
					break;
				}
				continue;
				end_IL_092e:
				break;
			}
		}
	}

	private static bool InvalidOperationNoValueIsRightToLeft(Class158 class158_1)
	{
		return class158_1.bool_0;
	}

	private static void ReadObjectInfoPARAMFLAGFOUT(Player player_0, string string_2)
	{
		player_0.NickName = string_2;
	}

	private static void replicasAreQuittingAssertFailure(GorillaComputer gorillaComputer_0, string string_2)
	{
		gorillaComputer_0.SetLocalNameTagText(string_2);
	}

	private static Player ApplicationEvidencegetPositiveInfinitySymbol()
	{
		return PhotonNetwork.LocalPlayer;
	}

	private static int smethod_6(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	public Class158()
	{
		object obj = "y";
		object obj2 = "P";
		object obj3 = "r";
		object obj4 = "e";
		object obj5 = "l";
		object obj6 = "a";
		object obj7 = new string[6];
		((string[])obj7)[0] = (string)obj2;
		((string[])obj7)[1] = (string)obj5;
		((string[])obj7)[2] = (string)obj6;
		((string[])obj7)[3] = (string)obj;
		((string[])obj7)[4] = (string)obj4;
		((string[])obj7)[5] = (string)obj3;
		string text = string.Concat((string[])obj7);
		string_1 = text;
	}

	private void OnDisable()
	{
		matchPurgeAuditRules(this);
	}

	private static int SystemAclPresentgetInvariantInfo(int int_2)
	{
		return smethod_1(int_2);
	}

	private static float AggregateDictionarygetUtc(string string_2, float float_2)
	{
		return PlayerPrefs.GetFloat(string_2, float_2);
	}

	static Class158()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0068:
				Class300.smethod_0();
				num = 1;
				while (true)
				{
					IL_0056:
					num = 16;
					while (true)
					{
						if (num != 16)
						{
							if (num != 997)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 5:
								goto IL_0056;
							case 2:
								goto IL_0068;
							case 3:
								goto end_IL_0049;
							case 4:
								return;
							case 6:
								return;
							case 7:
								return;
							case 8:
								return;
							case 9:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0049:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe void OnEnable()
	{
		RuntimeTypeHandle[] array = new RuntimeTypeHandle[1];
		Type[] array2 = new Type[1];
		array[0] = typeof(object).TypeHandle;
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IInspectableEnumInstallerDeploymentMetadata.EraseEndOfFilebstrSource);
		int num = 4;
		int num2 = 0;
		int num3 = 0;
		num3 = 0;
		int try0030_dispatch = -1;
		object[] array3 = default(object[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num24 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		object obj3 = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		float num31 = default(float);
		float num32 = default(float);
		float num33 = default(float);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0030_dispatch)
				{
				case 2034:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 152 + num8 * 48 + 32 + num);
							num10 = *(int*)(ptr + 152 + num8 * 48 + 8 + num);
							if (num5 >= num9 + num10)
							{
								num6 = num8 + 1;
								continue;
							}
							if (num9 <= num5)
							{
								break;
							}
							num7 = num8 - 1;
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 152 + num11 * 48 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array3 != null)
							{
								if ((int)array3[6] == 1)
								{
									int num15 = (int)array3[2];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 64 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 296 + num8 * 72 + 48 + num);
											num6 = *(int*)(ptr + 296 + num8 * 72 + 16 + num);
											if (num17 >= num7 + num6)
											{
												num10 = num8 + 1;
												continue;
											}
											if (num7 <= num17)
											{
												break;
											}
											num9 = num8 - 1;
										}
										num12 = num8;
										num11 = *(int*)(ptr + 296 + num12 * 72 + 8 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array3 = (object[])array3[1];
										continue;
									}
								}
								else
								{
									int num18 = (int)array3[5];
									if (num18 != 1 && num18 != 2 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array3[2];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 64 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 296 + num8 * 72 + 48 + num);
											num10 = *(int*)(ptr + 296 + num8 * 72 + 16 + num);
											if (num5 >= num9 + num10)
											{
												num6 = num8 + 1;
												continue;
											}
											if (num9 <= num5)
											{
												break;
											}
											num7 = num8 - 1;
										}
										num11 = num8;
										num12 = *(int*)(ptr + 296 + num11 * 72 + 8 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array3 = (object[])array3[1];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_0805;
							}
							num21 = *(int*)(ptr + num13 + 16 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 16 + num);
								if (3 != num7)
								{
									goto IL_074c;
								}
								num6 = *(int*)(ptr + num5 + 8 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 32 + num);
										continue;
									}
								}
								goto IL_0894;
							}
							num13 = *(int*)(ptr + num13 + 56 + num);
							continue;
							IL_074c:
							if (1 != num7)
							{
								num13 = *(int*)(ptr + num13 + 56 + num);
								continue;
							}
							goto IL_083b;
						}
						object[] array4 = array3;
						num4 = *(int*)(ptr + (int)array4[2] + 32 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 16 + num);
							if (3 != num21)
							{
								goto IL_0492;
							}
							num13 = *(int*)(ptr + num4 + 8 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[4]))
								{
									num4 = *(int*)(ptr + num4 + 32 + num);
									continue;
								}
							}
							goto IL_0a20;
						}
						goto IL_049a;
						IL_049a:
						array3 = (object[])array3[1];
						ex = (Exception)array4[4];
						num22 = (int)array4[7];
						continue;
						IL_0894:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 48 + num) + 56 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 8 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 56 + num);
									continue;
								}
								array4 = new object[8];
								array4[6] = 0;
								array4[1] = array3;
								array4[4] = ex;
								array4[7] = num14;
								array4[2] = num8;
								array4[3] = num17;
								array4[5] = 2;
								array3 = array4;
								num2 = *(int*)(ptr + num8 + 56 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[6] = 0;
							array4[1] = array3;
							array4[4] = ex;
							array4[7] = num14;
							array4[2] = num17;
							array4[5] = 1;
							array3 = array4;
							num2 = *(int*)(ptr + num17 + 56 + num);
							break;
						}
						break;
						IL_0a20:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 48 + num) + 56 + num);
						num14 = (int)array4[7];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 8 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 56 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 56 + num);
								array3 = (object[])array3[1];
								array5 = new object[8];
								array5[6] = 0;
								array5[1] = array3;
								array5[4] = array4[4];
								array5[7] = (int)array4[7];
								array5[2] = num18;
								array5[3] = num12;
								array5[5] = 2;
								array3 = array5;
								num2 = *(int*)(ptr + num18 + 56 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 56 + num);
							ex2 = (Exception)array4[4];
							array3 = (object[])array3[1];
							array5 = new object[8];
							array5[6] = 0;
							array5[1] = array3;
							array5[4] = array4[4];
							array5[7] = (int)array4[7];
							array5[2] = num12;
							array5[5] = 1;
							array3 = array5;
							num2 = *(int*)(ptr + num12 + 56 + num);
							break;
						}
						break;
						IL_083b:
						ex2 = ex;
						array4 = new object[8];
						array4[6] = 0;
						array4[1] = array3;
						array4[4] = ex;
						array4[7] = num14;
						array4[2] = num5;
						array4[5] = 0;
						array3 = array4;
						num2 = *(int*)(ptr + num5 + 40 + num);
						break;
						IL_0805:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 8 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 56 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 56 + num);
						array4 = new object[8];
						array4[6] = 0;
						array4[1] = array3;
						array4[4] = ex;
						array4[7] = num14;
						array4[2] = -1;
						array4[3] = -1;
						array4[5] = 1;
						array3 = array4;
						num2 = *(int*)(ptr + num11 + 56 + num);
						break;
						IL_0492:
						if (1 == num21)
						{
							num5 = *(int*)(ptr + num4 + 40 + num);
							ex2 = (Exception)array4[4];
							array3 = (object[])array3[1];
							object[] array5 = new object[8];
							array5[6] = 0;
							array5[1] = array3;
							array5[4] = array4[4];
							array5[7] = (int)array4[7];
							array5[2] = num4;
							array5[5] = 0;
							array3 = array5;
							num2 = *(int*)(ptr + num4 + 40 + num);
							break;
						}
						goto IL_049a;
					}
					break;
				}
				while (true)
				{
					switch (num3)
					{
					case 13:
					{
						num3 = 0;
						int num13 = num24;
						int num34 = num13;
						int num11 = num2;
						int num21 = num11;
						num13 = 0;
						int num4 = 2;
						int num7;
						int num6;
						int num5;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 152 + num5 * 48 + 32 + num);
							num7 = *(int*)(ptr + 152 + num5 * 48 + 8 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						int num14 = num5;
						int num18 = *(int*)(ptr + 152 + num14 * 48 + num);
						int num12 = num18;
						num7 = num34;
						num6 = 0;
						num5 = 2;
						while (true)
						{
							num4 = (num6 + num5) / 2;
							num13 = *(int*)(ptr + 152 + num4 * 48 + 32 + num);
							num21 = *(int*)(ptr + 152 + num4 * 48 + 8 + num);
							if (num7 >= num13 + num21)
							{
								num6 = num4 + 1;
								continue;
							}
							if (num13 <= num7)
							{
								break;
							}
							num5 = num4 - 1;
						}
						num14 = num4;
						int num8 = *(int*)(ptr + 152 + num14 * 48 + num);
						num18 = num8;
						num21 = num34;
						num13 = 0;
						num4 = 2;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 296 + num5 * 72 + 48 + num);
							num7 = *(int*)(ptr + 296 + num5 * 72 + 16 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						num14 = num5;
						int num9 = *(int*)(ptr + 296 + num14 * 72 + 8 + num);
						num8 = num9;
						while (true)
						{
							if (array3 == null || (int)array3[6] == 1)
							{
								num21 = num18;
								while (num21 != num12)
								{
									if (num21 != -1)
									{
										num21 = *(int*)(ptr + num21 + 56 + num);
										continue;
									}
									goto IL_01f6;
								}
								num2 = num34;
								break;
							}
							int num35 = (int)array3[2];
							int num36;
							if (num12 == -1)
							{
								num36 = -1;
							}
							else
							{
								int num10 = *(int*)(ptr + num12 + 64 + num);
								num7 = 0;
								num6 = 2;
								while (true)
								{
									num5 = (num7 + num6) / 2;
									num4 = *(int*)(ptr + 296 + num5 * 72 + 48 + num);
									num13 = *(int*)(ptr + 296 + num5 * 72 + 16 + num);
									if (num10 >= num4 + num13)
									{
										num7 = num5 + 1;
										continue;
									}
									if (num4 <= num10)
									{
										break;
									}
									num6 = num5 - 1;
								}
								num9 = num5;
								num14 = *(int*)(ptr + 296 + num9 * 72 + 8 + num);
								num36 = num14;
							}
							if (num35 == num36)
							{
								num14 = num18;
								while (num14 != num12)
								{
									if (num14 != -1)
									{
										num14 = *(int*)(ptr + num14 + 56 + num);
										continue;
									}
									goto IL_02ec;
								}
								num2 = num34;
								break;
							}
							if ((int)array3[2] != num8)
							{
								array3 = (object[])array3[1];
								continue;
							}
							num2 = num34;
							break;
							IL_02ec:
							num9 = *(int*)(ptr + num12 + 8 + num);
							if (num9 == -1)
							{
								num12 = *(int*)(ptr + num12 + 56 + num);
								continue;
							}
							num21 = *(int*)(ptr + num9 + 56 + num);
							object[] array4 = new object[8];
							array4[6] = 1;
							array4[1] = array3;
							array4[0] = num34;
							array4[2] = num9;
							array4[5] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num9 + 56 + num);
							break;
							IL_01f6:
							num13 = *(int*)(ptr + num12 + 8 + num);
							if (num13 == -1)
							{
								num12 = *(int*)(ptr + num12 + 56 + num);
								continue;
							}
							num4 = *(int*)(ptr + num13 + 56 + num);
							array4 = new object[8];
							array4[6] = 1;
							array4[1] = array3;
							array4[0] = num34;
							array4[2] = num13;
							array4[5] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num13 + 56 + num);
							break;
						}
						break;
					}
					default:
						((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref float, ref float, ref float, Class158, void>)getPermissionSetsetDataPointer[num2])(ref num2, ref num3, ref num24, ex2, ref num25, ref num26, ref num27, ref num28, ref num29, ref num30, ref obj3, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref num31, ref num32, ref num33, this);
						break;
					case 10:
						num3 = 0;
						return;
					}
				}
			}
			catch (Exception ex3)
			{
				if (num23 == 1)
				{
					throw ex3;
				}
				ex = ex3;
				num22 = -1;
				try0030_dispatch = 2034;
			}
		}
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 121;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 76;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EscapedCodeBaseDESCKINDIMPLICITAPPOBJ.LCIDVTFILETIME);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_033f:
														byte b = *ptr2;
														while (true)
														{
															IL_032f:
															ptr2++;
															while (true)
															{
																IL_031f:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02ff:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f2:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02e2:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_02d2:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_02c2:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0277:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_0267:
																																ptr2 += 8;
																																while (true)
																																{
																																	IL_024e:
																																	num5--;
																																	num = 139;
																																	while (num != 139)
																																	{
																																		if (num != 1120)
																																		{
																																			goto IL_041b;
																																		}
																																		switch (num)
																																		{
																																		case 42:
																																			goto IL_024e;
																																		case 105:
																																			goto IL_0267;
																																		case 87:
																																		case 130:
																																			goto IL_0277;
																																		case 101:
																																			goto IL_02a2;
																																		case 30:
																																		case 113:
																																			goto IL_02b2;
																																		case 11:
																																		case 122:
																																			goto IL_02c2;
																																		case 4:
																																			goto IL_02d2;
																																		case 39:
																																			goto IL_02e2;
																																		case 36:
																																			goto IL_02f2;
																																		case 48:
																																			goto IL_02ff;
																																		case 66:
																																			goto IL_030f;
																																		case 8:
																																			goto IL_031f;
																																		case 60:
																																			goto IL_032f;
																																		case 16:
																																		case 86:
																																			goto IL_033f;
																																		case 27:
																																		case 31:
																																			goto IL_034a;
																																		case 46:
																																		case 65:
																																			goto IL_038f;
																																		case 28:
																																			goto IL_039d;
																																		case 24:
																																		case 63:
																																			goto IL_03a8;
																																		case 41:
																																			goto IL_03b8;
																																		case 17:
																																			goto IL_03c6;
																																		case 70:
																																			goto IL_03d9;
																																		case 95:
																																			goto IL_0402;
																																		case 38:
																																			goto IL_0410;
																																		case 37:
																																		case 89:
																																			goto IL_041b;
																																		case 51:
																																			goto IL_0429;
																																		case 54:
																																		case 57:
																																			goto IL_043c;
																																		case 26:
																																			goto IL_044a;
																																		case 55:
																																			goto IL_046d;
																																		case 71:
																																			goto IL_0477;
																																		case 74:
																																			goto IL_0485;
																																		case 5:
																																		case 82:
																																			goto IL_04a1;
																																		case 23:
																																		case 100:
																																			goto IL_04b4;
																																		case 58:
																																			goto IL_04c2;
																																		case 3:
																																		case 56:
																																			goto IL_04d0;
																																		case 15:
																																			goto IL_0532;
																																		case 111:
																																			goto IL_0545;
																																		case 114:
																																			goto IL_0555;
																																		case 62:
																																			goto IL_0569;
																																		case 115:
																																			goto IL_057c;
																																		case 103:
																																			goto IL_058a;
																																		case 32:
																																		case 128:
																																			goto IL_059d;
																																		case 68:
																																			goto IL_05dd;
																																		case 90:
																																			goto IL_05f1;
																																		case 129:
																																			goto IL_0604;
																																		case 67:
																																		case 112:
																																			goto IL_060f;
																																		case 80:
																																			goto IL_061d;
																																		case 52:
																																			goto IL_0630;
																																		case 118:
																																			goto IL_063b;
																																		case 43:
																																			goto IL_0649;
																																		case 45:
																																		case 92:
																																			goto IL_0657;
																																		case 20:
																																		case 98:
																																			goto IL_066a;
																																		case 91:
																																		case 131:
																																			goto IL_0686;
																																		case 2:
																																			goto IL_06b2;
																																		case 10:
																																			goto IL_06c0;
																																		case 21:
																																			goto IL_06ce;
																																		case 126:
																																			goto IL_06e1;
																																		case 64:
																																		case 75:
																																			goto IL_06ec;
																																		case 99:
																																			goto IL_0705;
																																		case 78:
																																			goto IL_071c;
																																		case 73:
																																			goto IL_072a;
																																		case 119:
																																		case 132:
																																			goto IL_073a;
																																		case 0:
																																		case 6:
																																		case 9:
																																		case 12:
																																		case 13:
																																		case 19:
																																		case 29:
																																		case 47:
																																		case 49:
																																		case 50:
																																		case 61:
																																		case 69:
																																		case 77:
																																		case 83:
																																		case 84:
																																		case 85:
																																		case 88:
																																		case 96:
																																		case 104:
																																		case 106:
																																		case 108:
																																		case 109:
																																		case 110:
																																		case 117:
																																		case 124:
																																			goto end_IL_02a2;
																																		case 1:
																																		case 14:
																																		case 18:
																																		case 22:
																																		case 33:
																																		case 34:
																																		case 44:
																																		case 59:
																																		case 79:
																																		case 93:
																																		case 102:
																																		case 107:
																																		case 116:
																																		case 125:
																																		case 127:
																																			goto end_IL_023b;
																																		case 123:
																																			goto end_IL_076b;
																																		case 35:
																																			goto end_IL_077e;
																																		case 76:
																																			goto end_IL_0788;
																																		case 40:
																																			goto end_IL_0793;
																																		case 72:
																																		case 97:
																																			goto end_IL_07a8;
																																		case 94:
																																			goto end_IL_07c1;
																																		case 25:
																																		case 81:
																																			goto end_IL_07d1;
																																		case 120:
																																			goto end_IL_07e1;
																																		case 121:
																																			goto end_IL_07f1;
																																		case 7:
																																		case 53:
																																			goto IL_080c;
																																		}
																																		continue;
																																		end_IL_023b:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_031f;
																														continue;
																														end_IL_02a2:
																														break;
																														IL_02a2:;
																													}
																													break;
																													IL_02b2:;
																												}
																												break;
																											}
																											goto IL_06e1;
																											IL_072a:
																											ptr2 += 8;
																											goto end_IL_031f;
																											IL_06e1:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_06ec;
																											IL_06ec:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0705;
																											IL_0705:
																											array[num5] = 0;
																											num = 78;
																											goto IL_071c;
																											IL_071c:
																											num5++;
																											goto IL_072a;
																										}
																										break;
																									}
																									goto IL_073a;
																									IL_073a:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_031f;
																								}
																								break;
																							}
																							goto IL_0402;
																							IL_05dd:
																							array[num5 - 2] = 0;
																							goto IL_05f1;
																							IL_0402:
																							if (5 >= b)
																							{
																								goto IL_0410;
																							}
																							num = 5;
																							goto IL_04a1;
																							IL_0410:
																							if (5 > b)
																							{
																								goto IL_041b;
																							}
																							goto IL_043c;
																							IL_041b:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0429;
																							IL_0429:
																							if (4 <= b)
																							{
																								goto end_IL_031f;
																							}
																							break;
																							IL_043c:
																							array[num5] = 0;
																							goto IL_044a;
																							IL_044a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_046d;
																							IL_046d:
																							array2[num5] = null;
																							goto IL_0477;
																							IL_0477:
																							num5++;
																							goto IL_0485;
																							IL_0485:
																							ptr2 += 8;
																							goto end_IL_031f;
																							IL_05f1:
																							num5--;
																							goto end_IL_031f;
																							IL_04a1:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0545;
																							IL_0545:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_059d;
																							IL_059d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05dd;
																						}
																						break;
																					}
																					goto IL_034a;
																					IL_0569:
																					num5--;
																					goto end_IL_031f;
																					IL_034a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0555;
																					IL_0555:
																					array[num5 - 2] = 0;
																					goto IL_0569;
																				}
																				break;
																			}
																			goto IL_038f;
																			IL_066a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_031f;
																			IL_038f:
																			if (10 >= b)
																			{
																				goto IL_039d;
																			}
																			goto IL_0604;
																			IL_039d:
																			if (10 <= b)
																			{
																				goto IL_03a8;
																			}
																			goto IL_03b8;
																			IL_03a8:
																			array[num5] = 0;
																			goto IL_03d9;
																			IL_03d9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)IAppIdAuthoritygetThreadContextChanged[*(int*)(ptr2 + num3)])();
																			goto IL_057c;
																			IL_057c:
																			num5++;
																			goto IL_058a;
																			IL_058a:
																			ptr2 += 8;
																			goto end_IL_031f;
																			IL_03b8:
																			if (8 >= b)
																			{
																				goto IL_03c6;
																			}
																			goto IL_04b4;
																			IL_03c6:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0686;
																			IL_0686:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 2;
																			goto IL_06b2;
																			IL_06b2:
																			array[num5] = 0;
																			goto IL_06c0;
																			IL_06c0:
																			num5++;
																			goto IL_06ce;
																			IL_06ce:
																			ptr2 += 8;
																			goto end_IL_031f;
																			IL_04b4:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_04c2;
																			IL_04c2:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_04d0;
																			IL_04d0:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0532;
																			IL_0532:
																			num5 -= 2;
																			goto end_IL_031f;
																			IL_0604:
																			if (12 < b)
																			{
																				goto IL_060f;
																			}
																			goto IL_0630;
																			IL_060f:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_061d;
																			IL_061d:
																			if (13 <= b)
																			{
																			}
																			break;
																			IL_0630:
																			if (12 > b)
																			{
																				goto IL_063b;
																			}
																			goto IL_066a;
																			IL_063b:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0649;
																			IL_0649:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0657;
																			IL_0657:
																			num5--;
																			goto end_IL_031f;
																		}
																		break;
																		IL_030f:;
																	}
																}
																else
																{
																	num = 12;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_031f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_080c;
												IL_080c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_076b:
												break;
											}
											continue;
											end_IL_077e:
											break;
										}
										continue;
										end_IL_0788:
										break;
									}
									continue;
									end_IL_0793:
									break;
								}
								continue;
								end_IL_07a8:
								break;
							}
							continue;
							end_IL_07c1:
							break;
						}
						continue;
						end_IL_07d1:
						break;
					}
					continue;
					end_IL_07e1:
					break;
				}
				continue;
				end_IL_07f1:
				break;
			}
		}
	}

	private static string EnabledForETWIsDBNull(Player player_0)
	{
		return player_0.NickName;
	}

	private static void EnumInstallerDeploymentMetadataPropertiesgetActivator(Player player_0, string string_2)
	{
		player_0.NickName = string_2;
	}

	private static Player FormatPtrWindowsAccountType()
	{
		return PhotonNetwork.LocalPlayer;
	}
}
