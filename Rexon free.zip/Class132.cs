using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;

[Mod("Lag Power", "Settings", "Triggers (VR) / Click (PC) to adjust.", false, 14, ModType.const_0, false)]
internal class Class132 : MonoBehaviour
{
	public static int int_0 = 550;

	private float float_0;

	private int int_1;

	private static bool bool_0;

	private static float float_1;

	private static float float_2;

	private static double double_0;

	private static int int_2;

	private static IntPtr[] GetFaultDemandedResources;

	private static IntPtr[] ICLRSurrogateEntryITokenReader;

	private static IntPtr[] ExportgetRuntimeVersion;

	private static IntPtr[] intptr_0;

	public Class132()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getUseUserOverrideDataPtr.getUseUserOverrideDataPtr_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03d1:
														byte b = *ptr2;
														while (true)
														{
															IL_03c1:
															ptr2++;
															while (true)
															{
																IL_03b1:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0391:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_0381:
																					if (13 >= b)
																					{
																						while (true)
																						{
																							IL_0374:
																							if (13 > b)
																							{
																								while (true)
																								{
																									IL_0364:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0354:
																											if (11 > b)
																											{
																												while (10 >= b)
																												{
																													while (true)
																													{
																														IL_0334:
																														if (10 <= b)
																														{
																															while (true)
																															{
																																IL_0324:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_02ff:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_02f3:
																																		array2[num5] = null;
																																		while (true)
																																		{
																																			IL_02e3:
																																			num5++;
																																			while (true)
																																			{
																																				IL_02ca:
																																				ptr2 += 8;
																																				num = 170;
																																				while (num != 170)
																																				{
																																					if (num != 1151)
																																					{
																																						goto end_IL_0344;
																																					}
																																					switch (num)
																																					{
																																					case 114:
																																						goto IL_02ca;
																																					case 4:
																																						goto IL_02e3;
																																					case 31:
																																						goto IL_02f3;
																																					case 9:
																																						goto IL_02ff;
																																					case 41:
																																					case 96:
																																						goto IL_0324;
																																					case 138:
																																						goto IL_0334;
																																					case 89:
																																						goto IL_0344;
																																					case 127:
																																						goto IL_0354;
																																					case 64:
																																						goto IL_0364;
																																					case 37:
																																						goto IL_0374;
																																					case 48:
																																					case 91:
																																						goto IL_0381;
																																					case 70:
																																						goto IL_0391;
																																					case 28:
																																						goto IL_03a1;
																																					case 155:
																																						goto IL_03b1;
																																					case 81:
																																						goto IL_03c1;
																																					case 121:
																																					case 150:
																																						goto IL_03d1;
																																					case 43:
																																					case 145:
																																						goto IL_03dc;
																																					case 115:
																																						goto IL_043e;
																																					case 39:
																																					case 157:
																																						goto IL_0468;
																																					case 38:
																																						goto IL_04ac;
																																					case 69:
																																						goto IL_04c0;
																																					case 3:
																																					case 79:
																																						goto IL_04d3;
																																					case 156:
																																						goto IL_04e1;
																																					case 88:
																																					case 120:
																																						goto IL_04ef;
																																					case 20:
																																						goto IL_052f;
																																					case 151:
																																						goto IL_0543;
																																					case 125:
																																					case 161:
																																						goto IL_0556;
																																					case 80:
																																					case 105:
																																						goto IL_0561;
																																					case 92:
																																						goto IL_056c;
																																					case 10:
																																					case 60:
																																						goto IL_057a;
																																					case 130:
																																						goto IL_059f;
																																					case 56:
																																						goto IL_05ad;
																																					case 27:
																																						goto IL_05c0;
																																					case 6:
																																					case 78:
																																						goto IL_05ce;
																																					case 137:
																																						goto IL_05dc;
																																					case 17:
																																					case 142:
																																						goto IL_05f3;
																																					case 45:
																																						goto IL_0607;
																																					case 158:
																																						goto IL_0646;
																																					case 122:
																																					case 149:
																																						goto IL_0659;
																																					case 33:
																																						goto IL_066c;
																																					case 18:
																																						goto IL_067a;
																																					case 12:
																																					case 25:
																																						goto IL_0688;
																																					case 23:
																																					case 65:
																																						goto IL_0696;
																																					case 24:
																																						goto IL_06a1;
																																					case 117:
																																						goto IL_06af;
																																					case 90:
																																					case 95:
																																						goto IL_06bd;
																																					case 49:
																																						goto IL_06d5;
																																					case 26:
																																					case 153:
																																						goto IL_06e3;
																																					case 46:
																																						goto IL_070c;
																																					case 54:
																																						goto IL_071a;
																																					case 129:
																																						goto IL_072d;
																																					case 94:
																																					case 97:
																																						goto IL_0738;
																																					case 47:
																																						goto IL_0777;
																																					case 51:
																																					case 87:
																																						goto IL_078a;
																																					case 86:
																																						goto IL_07a1;
																																					case 32:
																																					case 123:
																																						goto IL_07af;
																																					case 110:
																																						goto IL_07bd;
																																					case 7:
																																						goto IL_07d5;
																																					case 16:
																																						goto IL_07e3;
																																					case 133:
																																						goto IL_07f6;
																																					case 11:
																																					case 98:
																																						goto IL_0801;
																																					case 21:
																																						goto IL_081f;
																																					case 93:
																																						goto IL_082d;
																																					case 102:
																																						goto IL_0840;
																																					case 0:
																																						goto IL_084e;
																																					case 104:
																																					case 143:
																																						goto IL_0859;
																																					case 15:
																																						goto IL_0899;
																																					case 148:
																																						goto IL_08b6;
																																					case 63:
																																						goto IL_08c9;
																																					case 84:
																																						goto IL_08d7;
																																					case 131:
																																					case 146:
																																						goto IL_08e5;
																																					case 8:
																																						goto IL_08fe;
																																					case 82:
																																						goto IL_090c;
																																					case 59:
																																						goto IL_091a;
																																					case 57:
																																						goto IL_092a;
																																					case 162:
																																						goto IL_0935;
																																					case 53:
																																					case 152:
																																						goto IL_0940;
																																					case 77:
																																						goto IL_0972;
																																					case 1:
																																					case 19:
																																					case 29:
																																					case 30:
																																					case 35:
																																					case 36:
																																					case 44:
																																					case 55:
																																					case 58:
																																					case 66:
																																					case 67:
																																					case 68:
																																					case 71:
																																					case 72:
																																					case 76:
																																					case 99:
																																					case 100:
																																					case 101:
																																					case 106:
																																					case 108:
																																					case 109:
																																					case 113:
																																					case 116:
																																					case 119:
																																					case 126:
																																					case 139:
																																					case 154:
																																					case 159:
																																					case 160:
																																					case 163:
																																						goto end_IL_0344;
																																					case 5:
																																					case 34:
																																					case 40:
																																					case 42:
																																					case 50:
																																					case 61:
																																					case 62:
																																					case 75:
																																					case 83:
																																					case 85:
																																					case 103:
																																					case 111:
																																					case 112:
																																					case 118:
																																					case 124:
																																					case 128:
																																					case 134:
																																					case 140:
																																					case 144:
																																						goto end_IL_02b7;
																																					case 147:
																																						goto end_IL_09a6;
																																					case 74:
																																						goto end_IL_09b9;
																																					case 107:
																																						goto end_IL_09c3;
																																					case 135:
																																						goto end_IL_09ce;
																																					case 2:
																																					case 52:
																																						goto end_IL_09de;
																																					case 136:
																																						goto end_IL_09ee;
																																					case 22:
																																					case 132:
																																						goto end_IL_09fe;
																																					case 13:
																																						goto end_IL_0a0e;
																																					case 14:
																																						goto end_IL_0a1e;
																																					case 73:
																																					case 141:
																																						goto IL_0a42;
																																					}
																																					continue;
																																					end_IL_02b7:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														num = 119;
																														goto end_IL_0344;
																													}
																													goto end_IL_03b1;
																													continue;
																													end_IL_0344:
																													break;
																													IL_0344:;
																												}
																												break;
																											}
																											num = 157;
																											goto IL_0468;
																											IL_04ac:
																											array[num5 - 2] = 0;
																											goto IL_04c0;
																											IL_04c0:
																											num5--;
																											goto end_IL_03b1;
																											IL_0468:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_04ac;
																										}
																										break;
																									}
																									goto IL_04d3;
																									IL_0543:
																									num5--;
																									goto end_IL_03b1;
																									IL_04d3:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_04e1;
																									IL_04e1:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_04ef;
																									IL_04ef:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_052f;
																									IL_052f:
																									array[num5 - 2] = 0;
																									goto IL_0543;
																								}
																								break;
																							}
																							goto IL_03dc;
																							IL_043e:
																							num5 -= 2;
																							goto end_IL_03b1;
																							IL_03dc:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_043e;
																						}
																						break;
																					}
																					goto IL_0556;
																					IL_0646:
																					ptr2 += 8;
																					goto end_IL_03b1;
																					IL_0556:
																					if (15 < b)
																					{
																						goto IL_0561;
																					}
																					goto IL_05c0;
																					IL_0561:
																					if (16 >= b)
																					{
																						goto IL_056c;
																					}
																					goto IL_059f;
																					IL_056c:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_057a;
																					IL_057a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 34;
																					goto end_IL_03b1;
																					IL_059f:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_05ad;
																					IL_05ad:
																					if (17 <= b)
																					{
																					}
																					break;
																					IL_05c0:
																					if (15 > b)
																					{
																						goto IL_05ce;
																					}
																					goto IL_0659;
																					IL_05ce:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_05dc;
																					IL_05dc:
																					if (14 > b)
																					{
																						break;
																					}
																					num = 142;
																					goto IL_05f3;
																					IL_0659:
																					num5--;
																					goto end_IL_03b1;
																					IL_05f3:
																					array[num5 - 1] = 0;
																					goto IL_0607;
																					IL_0607:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0646;
																				}
																				break;
																			}
																			goto IL_066c;
																			IL_0940:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 77;
																			goto IL_0972;
																			IL_066c:
																			if (9 <= b)
																			{
																				num = 112;
																				goto end_IL_03b1;
																			}
																			goto IL_067a;
																			IL_067a:
																			if (4 < b)
																			{
																				goto IL_0688;
																			}
																			goto IL_07f6;
																			IL_0688:
																			if (6 < b)
																			{
																				goto IL_0696;
																			}
																			goto IL_072d;
																			IL_0696:
																			if (7 < b)
																			{
																				goto IL_06a1;
																			}
																			goto IL_06d5;
																			IL_06a1:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_06af;
																			IL_06af:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_06bd;
																			IL_06bd:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_03b1;
																			IL_06d5:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_06e3;
																			IL_06e3:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_070c;
																			IL_070c:
																			ptr2 += 8;
																			goto IL_071a;
																			IL_071a:
																			num5--;
																			goto end_IL_03b1;
																			IL_072d:
																			if (6 <= b)
																			{
																				goto IL_0738;
																			}
																			goto IL_078a;
																			IL_0738:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0777;
																			IL_0777:
																			num5 -= 3;
																			goto end_IL_03b1;
																			IL_078a:
																			if (5 < b)
																			{
																				break;
																			}
																			num = 86;
																			goto IL_07a1;
																			IL_0972:
																			array[num5 - 1] = 5;
																			goto end_IL_03b1;
																			IL_07a1:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_07af;
																			IL_07af:
																			array[num5] = 5;
																			goto IL_07bd;
																			IL_07bd:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_07d5;
																			IL_07d5:
																			num5++;
																			goto IL_07e3;
																			IL_07e3:
																			ptr2 += 8;
																			goto end_IL_03b1;
																			IL_07f6:
																			if (4 <= b)
																			{
																				goto IL_0801;
																			}
																			goto IL_0840;
																			IL_0801:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_081f;
																			IL_081f:
																			ptr2 += 8;
																			goto IL_082d;
																			IL_082d:
																			num5--;
																			goto end_IL_03b1;
																			IL_0840:
																			if (2 >= b)
																			{
																				goto IL_084e;
																			}
																			goto IL_092a;
																			IL_084e:
																			if (2 <= b)
																			{
																				goto IL_0859;
																			}
																			goto IL_08c9;
																			IL_0859:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0899;
																			IL_0899:
																			array[num5 - 2] = 0;
																			num = 148;
																			goto IL_08b6;
																			IL_08b6:
																			num5--;
																			goto end_IL_03b1;
																			IL_08c9:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_08d7;
																			IL_08d7:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_08e5;
																			IL_08e5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_08fe;
																			IL_08fe:
																			array[num5] = 0;
																			goto IL_090c;
																			IL_090c:
																			num5++;
																			goto IL_091a;
																			IL_091a:
																			ptr2 += 8;
																			goto end_IL_03b1;
																			IL_092a:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0935;
																			IL_0935:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0940;
																		}
																		break;
																		IL_03a1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03b1:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 73;
												goto IL_0a42;
												IL_0a42:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09a6:
												break;
											}
											continue;
											end_IL_09b9:
											break;
										}
										continue;
										end_IL_09c3:
										break;
									}
									continue;
									end_IL_09ce:
									break;
								}
								continue;
								end_IL_09de:
								break;
							}
							continue;
							end_IL_09ee:
							break;
						}
						continue;
						end_IL_09fe:
						break;
					}
					continue;
					end_IL_0a0e:
					break;
				}
				continue;
				end_IL_0a1e:
				break;
			}
		}
	}

	private static double smethod_1(double double_1)
	{
		return Math.Sin(double_1);
	}

	private static double getParameterCustomFormatMask(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static double getIsEventRemotingSurrogateSelector(double double_1)
	{
		return Math.Log10(double_1);
	}

	private static double TraceLoggingMetadataCollectorAnnotation(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private unsafe static int smethod_2(int int_3, int int_4)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 36;
						while (true)
						{
							int[] array3 = new int[3];
							num = 3;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ICollectionRng.STORECATEGORYINSTANCEIsDBNull);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 35;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02db:
																	if (b >= 1)
																	{
																		goto IL_01bb;
																	}
																	goto IL_02b3;
																	IL_02b3:
																	while (true)
																	{
																		IL_02b3_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01a2:
																			array[num5] = 0;
																			num = 96;
																			while (true)
																			{
																				if (num != 96)
																				{
																					if (num != 1077)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 9:
																						goto IL_01a2;
																					case 85:
																						goto IL_01bb;
																					case 64:
																						goto IL_01c9;
																					case 24:
																					case 43:
																						goto IL_01d4;
																					case 42:
																						goto IL_01df;
																					case 32:
																					case 37:
																						goto end_IL_018f;
																					case 70:
																						goto IL_0204;
																					case 41:
																					case 69:
																						goto IL_0217;
																					case 57:
																						goto IL_0222;
																					case 1:
																						goto IL_0235;
																					case 16:
																						goto IL_0240;
																					case 72:
																						goto IL_0250;
																					case 88:
																						goto IL_025e;
																					case 27:
																						goto IL_0269;
																					case 23:
																					case 66:
																						goto IL_0277;
																					case 14:
																						goto IL_0282;
																					case 47:
																						goto IL_029a;
																					case 51:
																						goto IL_02a5;
																					case 5:
																					case 7:
																					case 8:
																					case 10:
																					case 12:
																					case 17:
																					case 18:
																					case 25:
																					case 34:
																					case 44:
																					case 49:
																					case 55:
																					case 77:
																					case 78:
																					case 80:
																					case 86:
																					case 89:
																						goto IL_02b3_2;
																					case 28:
																						goto IL_02db;
																					case 81:
																						goto end_IL_02db;
																					case 71:
																					case 87:
																						goto end_IL_02eb;
																					case 48:
																					case 53:
																						goto IL_0306;
																					case 75:
																					case 83:
																						goto IL_031e;
																					case 59:
																						goto IL_032c;
																					case 56:
																						goto IL_034f;
																					case 84:
																						goto IL_0359;
																					case 22:
																						goto IL_0367;
																					case 11:
																					case 29:
																						goto IL_037a;
																					case 46:
																					case 52:
																						goto IL_0396;
																					case 62:
																						goto IL_03bf;
																					case 39:
																						goto IL_03cd;
																					case 31:
																					case 68:
																						goto IL_03e0;
																					case 79:
																						goto IL_044e;
																					case 20:
																					case 65:
																						goto IL_0461;
																					case 74:
																						goto IL_04a1;
																					case 82:
																						goto IL_04b5;
																					case 13:
																						goto IL_04d3;
																					case 0:
																					case 4:
																					case 26:
																					case 30:
																					case 35:
																					case 38:
																					case 50:
																					case 54:
																					case 63:
																					case 67:
																					case 73:
																						goto end_IL_02fb;
																					case 76:
																						goto end_IL_04e1;
																					case 33:
																						goto end_IL_04f4;
																					case 40:
																						goto end_IL_0507;
																					case 45:
																						goto end_IL_0512;
																					case 3:
																						goto end_IL_0527;
																					case 6:
																					case 36:
																						goto end_IL_053c;
																					case 21:
																						goto end_IL_054c;
																					case 2:
																					case 19:
																						goto end_IL_0565;
																					case 60:
																						goto end_IL_057e;
																					case 61:
																						goto end_IL_058e;
																					case 15:
																					case 58:
																						goto IL_05a9;
																					}
																					continue;
																				}
																				num5++;
																				goto IL_04d3;
																				IL_04d3:
																				ptr2 += 8;
																				goto end_IL_02fb;
																				continue;
																				end_IL_018f:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_01f6;
																	IL_01bb:
																	if (b <= 8)
																	{
																		goto IL_01c9;
																	}
																	goto IL_02b3;
																	IL_01c9:
																	if (4 < b)
																	{
																		goto IL_01d4;
																	}
																	goto IL_0250;
																	IL_01d4:
																	if (6 >= b)
																	{
																		goto IL_01df;
																	}
																	goto IL_0217;
																	IL_01df:
																	if (6 <= b)
																	{
																		goto end_IL_02fb;
																	}
																	num = 37;
																	goto IL_01f6;
																	IL_03bf:
																	ptr2 += 8;
																	goto IL_03cd;
																	IL_01f6:
																	if (5 >= b)
																	{
																		goto IL_0204;
																	}
																	goto IL_02b3;
																	IL_0204:
																	if (5 > b)
																	{
																		goto IL_02b3;
																	}
																	goto IL_0306;
																	IL_0306:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02fb;
																	IL_0217:
																	if (7 >= b)
																	{
																		goto IL_0222;
																	}
																	goto IL_0235;
																	IL_0222:
																	if (7 > b)
																	{
																		goto IL_02b3;
																	}
																	goto IL_031e;
																	IL_031e:
																	array[num5] = 0;
																	goto IL_032c;
																	IL_032c:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_034f;
																	IL_034f:
																	array2[num5] = null;
																	goto IL_0359;
																	IL_0359:
																	num5++;
																	goto IL_0367;
																	IL_0367:
																	ptr2 += 8;
																	goto end_IL_02fb;
																	IL_0235:
																	if (8 >= b)
																	{
																		goto IL_0240;
																	}
																	goto IL_02b3;
																	IL_0240:
																	if (8 > b)
																	{
																		goto IL_02b3;
																	}
																	goto IL_037a;
																	IL_037a:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_02fb;
																	IL_0250:
																	if (4 > b)
																	{
																		goto IL_025e;
																	}
																	goto IL_0396;
																	IL_025e:
																	if (2 >= b)
																	{
																		goto IL_0269;
																	}
																	goto IL_029a;
																	IL_0269:
																	if (2 > b)
																	{
																		goto IL_0277;
																	}
																	goto IL_03e0;
																	IL_0277:
																	if (1 >= b)
																	{
																		goto IL_0282;
																	}
																	num = 17;
																	goto IL_02b3;
																	IL_0282:
																	if (1 <= b)
																	{
																	}
																	goto IL_02b3;
																	IL_03cd:
																	num5--;
																	goto end_IL_02fb;
																	IL_03e0:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_044e;
																	IL_044e:
																	num5 -= 2;
																	goto end_IL_02fb;
																	IL_029a:
																	if (3 >= b)
																	{
																		goto IL_02a5;
																	}
																	goto IL_02b3;
																	IL_02a5:
																	if (3 > b)
																	{
																		goto IL_02b3;
																	}
																	goto IL_0461;
																	IL_0461:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04a1;
																	IL_04a1:
																	array[num5 - 2] = 0;
																	goto IL_04b5;
																	IL_04b5:
																	num5--;
																	goto end_IL_02fb;
																	IL_0396:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_03bf;
																	continue;
																	end_IL_02db:
																	break;
																}
																continue;
																end_IL_02eb:
																break;
															}
															continue;
															end_IL_02fb:
															break;
														}
														continue;
													}
													goto IL_05a9;
													IL_05a9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04e1:
													break;
												}
												continue;
												end_IL_04f4:
												break;
											}
											continue;
											end_IL_0507:
											break;
										}
										continue;
										end_IL_0512:
										break;
									}
									continue;
									end_IL_0527:
									break;
								}
								continue;
								end_IL_053c:
								break;
							}
							continue;
							end_IL_054c:
							break;
						}
						continue;
						end_IL_0565:
						break;
					}
					continue;
					end_IL_057e:
					break;
				}
				continue;
				end_IL_058e:
				break;
			}
		}
	}

	private static int DirectoryNameGetDynamicModule(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static void ResetConnectAccessInvokeTypeInfo(string string_0)
	{
		BundleManager.smethod_58(string_0);
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 49;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 45;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTransparentProxyGetInvocationList.setAppDomainInitializerArgumentsCMSENTRYPOINTFLAGCUSTOMHOSTSPECIFIED);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 22;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_023c:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_021c:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_020c:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_01ff:
																								if (8 >= b)
																								{
																									while (8 <= b)
																									{
																										num = 111;
																										while (true)
																										{
																											if (num != 111)
																											{
																												if (num != 1092)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 79:
																													goto IL_01ec;
																												case 47:
																													goto IL_01ff;
																												case 41:
																													goto IL_020c;
																												case 37:
																													goto IL_021c;
																												case 69:
																													goto end_IL_01d9;
																												case 86:
																													goto IL_023c;
																												case 24:
																													goto end_IL_023c;
																												case 20:
																												case 30:
																													goto end_IL_024c;
																												case 38:
																												case 70:
																													goto IL_0267;
																												case 34:
																													goto IL_0275;
																												case 53:
																												case 68:
																													goto IL_0283;
																												case 25:
																													goto IL_029f;
																												case 40:
																													goto IL_02df;
																												case 26:
																													goto IL_02f3;
																												case 82:
																													goto IL_030f;
																												case 64:
																												case 78:
																													goto IL_031a;
																												case 9:
																													goto IL_0333;
																												case 10:
																													goto IL_0341;
																												case 23:
																													goto IL_034f;
																												case 85:
																													goto IL_0362;
																												case 55:
																													goto IL_0370;
																												case 89:
																												case 101:
																													goto IL_037e;
																												case 1:
																													goto IL_03be;
																												case 8:
																													goto IL_03d2;
																												case 87:
																													goto IL_03ee;
																												case 6:
																												case 54:
																													goto IL_03fc;
																												case 32:
																													goto IL_040a;
																												case 56:
																												case 71:
																													goto IL_0418;
																												case 104:
																													goto IL_0431;
																												case 27:
																												case 83:
																													goto IL_043f;
																												case 29:
																													goto IL_047f;
																												case 57:
																													goto IL_0493;
																												case 28:
																													goto IL_04a6;
																												case 60:
																												case 62:
																													goto IL_04b4;
																												case 66:
																													goto IL_04dd;
																												case 31:
																													goto IL_04eb;
																												case 92:
																													goto IL_0507;
																												case 51:
																												case 77:
																													goto IL_0512;
																												case 100:
																													goto IL_0552;
																												case 42:
																													goto IL_0566;
																												case 98:
																													goto IL_0579;
																												case 91:
																													goto IL_0584;
																												case 43:
																												case 58:
																													goto IL_059c;
																												case 95:
																													goto IL_05aa;
																												case 103:
																													goto IL_05d6;
																												case 2:
																													goto IL_05e0;
																												case 52:
																													goto IL_05ee;
																												case 0:
																												case 11:
																												case 12:
																												case 13:
																												case 15:
																												case 17:
																												case 21:
																												case 33:
																												case 35:
																												case 36:
																												case 44:
																												case 46:
																												case 63:
																												case 76:
																												case 80:
																												case 88:
																												case 90:
																												case 96:
																												case 102:
																													goto end_IL_01ec;
																												case 14:
																													goto IL_0621;
																												case 19:
																													goto IL_062f;
																												case 72:
																													goto IL_063d;
																												case 3:
																												case 4:
																												case 7:
																												case 18:
																												case 22:
																												case 39:
																												case 50:
																												case 59:
																												case 74:
																												case 94:
																												case 99:
																													goto end_IL_025c;
																												case 5:
																													goto end_IL_064b;
																												case 65:
																													goto end_IL_065e;
																												case 75:
																													goto end_IL_0671;
																												case 84:
																													goto end_IL_067c;
																												case 97:
																													goto end_IL_0691;
																												case 81:
																												case 93:
																													goto end_IL_06a6;
																												case 73:
																													goto end_IL_06b6;
																												case 16:
																												case 45:
																													goto end_IL_06c6;
																												case 48:
																													goto end_IL_06d6;
																												case 49:
																													goto end_IL_06e6;
																												case 61:
																												case 67:
																													goto IL_070a;
																												}
																												continue;
																											}
																											goto IL_029f;
																											IL_02df:
																											array[num5 - 2] = 0;
																											goto IL_02f3;
																											IL_02f3:
																											num5--;
																											goto end_IL_025c;
																											IL_029f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_02df;
																											continue;
																											end_IL_01d9:
																											break;
																										}
																										goto IL_022c;
																										continue;
																										end_IL_01ec:
																										break;
																										IL_01ec:;
																									}
																									break;
																								}
																								goto IL_0267;
																								IL_0283:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_025c;
																								IL_0267:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0275;
																								IL_0275:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0283;
																							}
																							break;
																						}
																						num = 82;
																						goto IL_030f;
																						IL_03be:
																						array[num5 - 2] = 0;
																						goto IL_03d2;
																						IL_03d2:
																						num5--;
																						goto end_IL_025c;
																						IL_030f:
																						if (7 <= b)
																						{
																							goto IL_031a;
																						}
																						goto IL_0362;
																						IL_031a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0333;
																						IL_0333:
																						array[num5] = 0;
																						goto IL_0341;
																						IL_0341:
																						num5++;
																						goto IL_034f;
																						IL_034f:
																						ptr2 += 8;
																						goto end_IL_025c;
																						IL_0362:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_0370;
																						IL_0370:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_037e;
																						IL_037e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03be;
																					}
																					break;
																				}
																				num = 87;
																				goto IL_03ee;
																				IL_05aa:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 103;
																				goto IL_05d6;
																				IL_05d6:
																				array2[num5] = null;
																				goto IL_05e0;
																				IL_03ee:
																				if (5 > b)
																				{
																					goto IL_03fc;
																				}
																				goto IL_059c;
																				IL_03fc:
																				if (2 < b)
																				{
																					goto IL_040a;
																				}
																				goto IL_0507;
																				IL_040a:
																				if (3 < b)
																				{
																					goto IL_0418;
																				}
																				goto IL_04a6;
																				IL_0418:
																				if (4 < b)
																				{
																					num = 15;
																					break;
																				}
																				goto IL_0431;
																				IL_05e0:
																				num5++;
																				goto IL_05ee;
																				IL_0431:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_043f;
																				IL_043f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_047f;
																				IL_047f:
																				array[num5 - 2] = 0;
																				goto IL_0493;
																				IL_0493:
																				num5--;
																				goto end_IL_025c;
																				IL_04a6:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_04b4;
																				IL_04b4:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04dd;
																				IL_04dd:
																				ptr2 += 8;
																				goto IL_04eb;
																				IL_04eb:
																				num5--;
																				num = 4;
																				goto end_IL_025c;
																				IL_0507:
																				if (2 <= b)
																				{
																					goto IL_0512;
																				}
																				goto IL_0579;
																				IL_0512:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0552;
																				IL_0552:
																				array[num5 - 2] = 0;
																				goto IL_0566;
																				IL_0566:
																				num5--;
																				goto end_IL_025c;
																				IL_0579:
																				if (1 < b)
																				{
																					num = 88;
																					break;
																				}
																				goto IL_0584;
																				IL_0584:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_05ee:
																				ptr2 += 8;
																				goto end_IL_025c;
																				IL_059c:
																				array[num5] = 0;
																				goto IL_05aa;
																			}
																			break;
																			IL_022c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0621;
																	IL_063d:
																	ptr2 += 8;
																	goto end_IL_025c;
																	IL_062f:
																	num5++;
																	goto IL_063d;
																	IL_0621:
																	array[num5] = 0;
																	goto IL_062f;
																	continue;
																	end_IL_023c:
																	break;
																}
																continue;
																end_IL_024c:
																break;
															}
															continue;
															end_IL_025c:
															break;
														}
														continue;
													}
													goto IL_070a;
													IL_070a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064b:
													break;
												}
												continue;
												end_IL_065e:
												break;
											}
											continue;
											end_IL_0671:
											break;
										}
										continue;
										end_IL_067c:
										break;
									}
									continue;
									end_IL_0691:
									break;
								}
								continue;
								end_IL_06a6:
								break;
							}
							continue;
							end_IL_06b6:
							break;
						}
						continue;
						end_IL_06c6:
						break;
					}
					continue;
					end_IL_06d6:
					break;
				}
				continue;
				end_IL_06e6:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0409, IL_041c, IL_042f, IL_043f, IL_044f, IL_045c, IL_046c, IL_047c, IL_048c, IL_049c, IL_04ac, IL_04c5, IL_04d0, IL_04d9, IL_0519, IL_0532, IL_054f, IL_059e, IL_05a8, IL_05d5, IL_05e9, IL_05f9, IL_0607, IL_062a, IL_0634, IL_0642, IL_0655, IL_0668, IL_067b, IL_0686, IL_0694, IL_06d4, IL_06e8, IL_06fb, IL_0709, IL_0717, IL_0722, IL_0735, IL_0743, IL_0751, IL_0791, IL_07a5, IL_07b8, IL_07e1, IL_07ef, IL_0802, IL_0810, IL_081e, IL_0829, IL_0837, IL_0877, IL_088b, IL_089e, IL_08ac, IL_08ba, IL_08cd, IL_090d, IL_0921, IL_0934, IL_093f, IL_094d, IL_0960, IL_096e, IL_097c, IL_098a, IL_09ec, IL_09ff, IL_0a13, IL_0a52, IL_0a65, IL_0a73, IL_0a81, IL_0a8c, IL_0aa0, IL_0ae7, IL_0af5, IL_0b08, IL_0b13, IL_0b21, IL_0b4e, IL_0b5c, IL_0b6a, IL_0b7d, IL_0b8b, IL_0b99, IL_0bc2, IL_0bdb, IL_0be6, IL_0bf4, IL_0c02, IL_0c27, IL_0c32, IL_0c47, IL_0c5a, IL_0c68, IL_0c76, IL_0c9f, IL_0cb6, IL_0cc9, IL_0cd7, IL_0ce5, IL_0cf0, IL_0cfe, IL_0d0c, IL_0d24, IL_0d32, IL_0d45, IL_0d4e, IL_0d5c, IL_0d6a, IL_0da8, IL_0dbb, IL_0dc9, IL_0dd4, IL_0de2, IL_0e09, IL_0e17, IL_0e2a, IL_0e35, IL_0e3e, IL_0e49, IL_0e72, IL_0e8b, IL_0ea4, IL_0eb2, IL_0ec0, IL_0ed3, IL_0eeb, IL_0f09, IL_0f2d, IL_0f45, IL_0f55, IL_0f69, IL_0fa1, IL_0faf, IL_0fc2, IL_0fcc, IL_0fd7, IL_0fe7, IL_1000, IL_1010, IL_1020, IL_1030, IL_1049, IL_1059, IL_1074 are reachable both inside and outside the pinned region starting at IL_106e. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 134;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef46 = default(int);
			ref int reference = ref __rxRef46;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1059:
					num2 = 1;
					while (true)
					{
						IL_1049:
						num3 = num2 * 4;
						while (true)
						{
							IL_1030:
							array2 = new byte[4];
							num = 88;
							while (true)
							{
								IL_1020:
								array3 = new object[4];
								while (true)
								{
									IL_1010:
									array4 = new int[4];
									while (true)
									{
										IL_1000:
										array5 = new int[6];
										while (true)
										{
											IL_0fe7:
											array6 = new long[4];
											num = 30;
											while (true)
											{
												IL_0fd7:
												array7 = new object[14];
												while (true)
												{
													IL_0fcc:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BootstrapConextShiftPressed.AttachedToParentgetIsMetric);
													while (true)
													{
														IL_0fc2:
														ptr2 = ptr;
														while (true)
														{
															IL_0faf:
															if (num4 != 1)
															{
																while (true)
																{
																	IL_04c5:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_04ac:
																		ptr2++;
																		num = 122;
																		while (true)
																		{
																			IL_049c:
																			if (b >= 1)
																			{
																				while (b <= 25)
																				{
																					while (true)
																					{
																						IL_047c:
																						if (13 >= b)
																						{
																							while (true)
																							{
																								IL_046c:
																								if (13 > b)
																								{
																									while (true)
																									{
																										IL_045c:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_044f:
																												if (6 > b)
																												{
																													while (true)
																													{
																														IL_043f:
																														if (3 < b)
																														{
																															while (true)
																															{
																																IL_042f:
																																if (4 >= b)
																																{
																																	while (true)
																																	{
																																		IL_041c:
																																		if (4 > b)
																																		{
																																			num = 251;
																																			while (num != 251)
																																			{
																																				if (num != 1232)
																																				{
																																					goto IL_0a13;
																																				}
																																				switch (num)
																																				{
																																				case 134:
																																					break;
																																				default:
																																					continue;
																																				case 123:
																																					goto IL_041c;
																																				case 38:
																																				case 89:
																																					goto IL_042f;
																																				case 198:
																																					goto IL_043f;
																																				case 73:
																																					goto IL_044f;
																																				case 33:
																																					goto IL_045c;
																																				case 5:
																																					goto IL_046c;
																																				case 170:
																																					goto IL_047c;
																																				case 126:
																																					goto IL_048c;
																																				case 122:
																																					goto IL_049c;
																																				case 159:
																																					goto IL_04ac;
																																				case 92:
																																				case 149:
																																					goto IL_04c5;
																																				case 66:
																																				case 83:
																																					goto IL_04d9;
																																				case 12:
																																					goto IL_0519;
																																				case 61:
																																				case 91:
																																					goto IL_0532;
																																				case 114:
																																					goto IL_05e9;
																																				case 81:
																																				case 172:
																																					goto IL_05f9;
																																				case 165:
																																					goto IL_0607;
																																				case 20:
																																					goto IL_062a;
																																				case 138:
																																					goto IL_0634;
																																				case 0:
																																					goto IL_0642;
																																				case 173:
																																					goto IL_0655;
																																				case 187:
																																					goto IL_0668;
																																				case 104:
																																					goto IL_067b;
																																				case 143:
																																					goto IL_0686;
																																				case 17:
																																				case 108:
																																					goto IL_0694;
																																				case 119:
																																					goto IL_06d4;
																																				case 86:
																																					goto IL_06e8;
																																				case 69:
																																					goto IL_0709;
																																				case 102:
																																					goto IL_0717;
																																				case 183:
																																					goto IL_0722;
																																				case 15:
																																				case 207:
																																					goto IL_0735;
																																				case 204:
																																					goto IL_0743;
																																				case 93:
																																				case 158:
																																					goto IL_0751;
																																				case 141:
																																					goto IL_0791;
																																				case 181:
																																					goto IL_07a5;
																																				case 168:
																																				case 188:
																																					goto IL_07b8;
																																				case 117:
																																					goto IL_07e1;
																																				case 144:
																																					goto IL_07ef;
																																				case 193:
																																					goto IL_0802;
																																				case 146:
																																					goto IL_0810;
																																				case 196:
																																				case 225:
																																					goto IL_081e;
																																				case 8:
																																					goto IL_0829;
																																				case 128:
																																				case 206:
																																					goto IL_0837;
																																				case 84:
																																					goto IL_0877;
																																				case 233:
																																					goto IL_088b;
																																				case 202:
																																					goto IL_089e;
																																				case 166:
																																					goto IL_08ac;
																																				case 21:
																																				case 75:
																																					goto IL_08ba;
																																				case 174:
																																				case 221:
																																					goto IL_08cd;
																																				case 97:
																																					goto IL_090d;
																																				case 41:
																																					goto IL_0921;
																																				case 4:
																																					goto IL_0934;
																																				case 3:
																																				case 7:
																																					goto IL_093f;
																																				case 148:
																																					goto IL_094d;
																																				case 28:
																																					goto IL_0960;
																																				case 2:
																																				case 192:
																																					goto IL_096e;
																																				case 107:
																																					goto IL_097c;
																																				case 112:
																																				case 132:
																																					goto IL_098a;
																																				case 241:
																																					goto IL_09ec;
																																				case 54:
																																				case 213:
																																					goto IL_09ff;
																																				case 118:
																																					goto IL_0a13;
																																				case 142:
																																					goto IL_0a52;
																																				case 115:
																																				case 182:
																																					goto IL_0a65;
																																				case 157:
																																					goto IL_0a73;
																																				case 35:
																																					goto IL_0a81;
																																				case 39:
																																				case 121:
																																					goto IL_0a8c;
																																				case 244:
																																					goto IL_0aa0;
																																				case 44:
																																					goto IL_0ae7;
																																				case 130:
																																					goto IL_0af5;
																																				case 63:
																																					goto IL_0b08;
																																				case 140:
																																					goto IL_0b13;
																																				case 40:
																																				case 240:
																																					goto IL_0b21;
																																				case 120:
																																					goto IL_0b4e;
																																				case 239:
																																					goto IL_0b5c;
																																				case 230:
																																					goto IL_0b6a;
																																				case 135:
																																					goto IL_0b7d;
																																				case 58:
																																					goto IL_0b8b;
																																				case 116:
																																				case 129:
																																					goto IL_0b99;
																																				case 13:
																																					goto IL_0bc2;
																																				case 237:
																																					goto IL_0bdb;
																																				case 199:
																																				case 234:
																																					goto IL_0be6;
																																				case 47:
																																					goto IL_0bf4;
																																				case 34:
																																				case 136:
																																					goto IL_0c02;
																																				case 194:
																																					goto IL_0c27;
																																				case 9:
																																				case 64:
																																					goto IL_0c32;
																																				case 175:
																																					goto IL_0c47;
																																				case 65:
																																					goto IL_0c5a;
																																				case 50:
																																					goto IL_0c68;
																																				case 48:
																																				case 67:
																																					goto IL_0c76;
																																				case 98:
																																					goto IL_0c9f;
																																				case 90:
																																					goto IL_0cb6;
																																				case 223:
																																					goto IL_0cc9;
																																				case 10:
																																				case 70:
																																					goto IL_0cd7;
																																				case 11:
																																				case 52:
																																					goto IL_0ce5;
																																				case 110:
																																					goto IL_0cf0;
																																				case 85:
																																				case 238:
																																					goto IL_0cfe;
																																				case 77:
																																					goto IL_0d0c;
																																				case 46:
																																					goto IL_0d24;
																																				case 99:
																																					goto IL_0d32;
																																				case 57:
																																				case 160:
																																					goto IL_0d4e;
																																				case 197:
																																					goto IL_0d5c;
																																				case 53:
																																				case 62:
																																					goto IL_0d6a;
																																				case 164:
																																					goto IL_0da8;
																																				case 60:
																																					goto IL_0dbb;
																																				case 80:
																																					goto IL_0dc9;
																																				case 195:
																																					goto IL_0dd4;
																																				case 1:
																																				case 87:
																																					goto IL_0de2;
																																				case 171:
																																					goto IL_0e09;
																																				case 82:
																																					goto IL_0e17;
																																				case 68:
																																				case 152:
																																					goto IL_0e2a;
																																				case 36:
																																					goto IL_0e3e;
																																				case 161:
																																				case 218:
																																					goto IL_0e49;
																																				case 18:
																																					goto IL_0e72;
																																				case 6:
																																				case 22:
																																				case 26:
																																				case 29:
																																				case 31:
																																				case 32:
																																				case 43:
																																				case 59:
																																				case 72:
																																				case 76:
																																				case 94:
																																				case 95:
																																				case 96:
																																				case 100:
																																				case 101:
																																				case 105:
																																				case 106:
																																				case 124:
																																				case 127:
																																				case 145:
																																				case 147:
																																				case 154:
																																				case 155:
																																				case 156:
																																				case 162:
																																				case 163:
																																				case 177:
																																				case 178:
																																				case 185:
																																				case 186:
																																				case 191:
																																				case 201:
																																				case 205:
																																				case 210:
																																				case 212:
																																				case 217:
																																				case 219:
																																				case 222:
																																				case 227:
																																				case 228:
																																				case 229:
																																				case 232:
																																				case 235:
																																				case 236:
																																					goto end_IL_0409;
																																				case 203:
																																					goto IL_0ea4;
																																				case 25:
																																					goto IL_0eb2;
																																				case 16:
																																					goto IL_0ec0;
																																				case 151:
																																				case 215:
																																					goto IL_0ed3;
																																				case 137:
																																					goto IL_0eeb;
																																				case 49:
																																					goto IL_0f09;
																																				case 71:
																																					goto IL_0f2d;
																																				case 180:
																																					goto IL_0f45;
																																				case 179:
																																				case 224:
																																					goto IL_0f55;
																																				case 27:
																																					goto IL_0f69;
																																				case 169:
																																					goto IL_0fa1;
																																				case 23:
																																				case 24:
																																				case 37:
																																				case 42:
																																				case 51:
																																				case 56:
																																				case 78:
																																				case 79:
																																				case 103:
																																				case 111:
																																				case 113:
																																				case 125:
																																				case 131:
																																				case 139:
																																				case 150:
																																				case 167:
																																				case 176:
																																				case 184:
																																				case 189:
																																				case 190:
																																				case 208:
																																				case 211:
																																				case 214:
																																				case 216:
																																				case 220:
																																				case 226:
																																				case 242:
																																				case 243:
																																					goto IL_0faf;
																																				case 153:
																																					goto IL_0fc2;
																																				case 45:
																																					goto IL_0fcc;
																																				case 30:
																																					goto IL_0fd7;
																																				case 109:
																																					goto IL_0fe7;
																																				case 55:
																																					goto IL_1000;
																																				case 74:
																																					goto IL_1010;
																																				case 88:
																																					goto IL_1020;
																																				case 14:
																																				case 200:
																																					goto IL_1030;
																																				case 209:
																																					goto IL_1049;
																																				case 133:
																																					goto IL_1059;
																																				case 19:
																																				case 231:
																																					return;
																																				}
																																				goto end_IL_049c;
																																				continue;
																																				end_IL_0409:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_05f9;
																																		IL_0634:
																																		num5++;
																																		goto IL_0642;
																																		IL_0642:
																																		ptr2 += 8;
																																		goto IL_0faf;
																																		IL_05f9:
																																		array2[num5] = 0;
																																		goto IL_0607;
																																		IL_0607:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																																		goto IL_062a;
																																		IL_062a:
																																		array3[num5] = null;
																																		goto IL_0634;
																																	}
																																	break;
																																}
																																goto IL_067b;
																																IL_06e8:
																																num5--;
																																goto IL_0faf;
																																IL_067b:
																																if (5 < b)
																																{
																																	num = 22;
																																	break;
																																}
																																goto IL_0686;
																																IL_0686:
																																if (5 > b)
																																{
																																	break;
																																}
																																goto IL_0694;
																																IL_0694:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																goto IL_06d4;
																																IL_06d4:
																																array2[num5 - 2] = 0;
																																goto IL_06e8;
																															}
																															break;
																														}
																														goto IL_0709;
																														IL_07ef:
																														num5--;
																														goto IL_0faf;
																														IL_0709:
																														if (3 > b)
																														{
																															goto IL_0717;
																														}
																														goto IL_07b8;
																														IL_0717:
																														if (1 >= b)
																														{
																															goto IL_0722;
																														}
																														goto IL_0735;
																														IL_0722:
																														if (1 <= b)
																														{
																														}
																														break;
																														IL_0735:
																														if (2 < b)
																														{
																															break;
																														}
																														goto IL_0743;
																														IL_0743:
																														if (2 > b)
																														{
																															break;
																														}
																														goto IL_0751;
																														IL_0751:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_0791;
																														IL_0791:
																														array2[num5 - 2] = 0;
																														goto IL_07a5;
																														IL_07a5:
																														num5--;
																														goto IL_0faf;
																														IL_07b8:
																														reference = ref array5[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														goto IL_07e1;
																														IL_07e1:
																														ptr2 += 8;
																														goto IL_07ef;
																													}
																													break;
																												}
																												num = 83;
																												goto IL_04d9;
																												IL_0519:
																												array2[num5 - 2] = 0;
																												goto IL_0655;
																												IL_0655:
																												num5--;
																												goto IL_0faf;
																												IL_04d9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																												goto IL_0519;
																											}
																											break;
																										}
																										goto IL_0802;
																										IL_0a52:
																										ptr2 += 8;
																										goto IL_0faf;
																										IL_0802:
																										if (9 >= b)
																										{
																											goto IL_0810;
																										}
																										goto IL_0934;
																										IL_0810:
																										if (9 > b)
																										{
																											goto IL_081e;
																										}
																										goto IL_08cd;
																										IL_081e:
																										if (7 >= b)
																										{
																											goto IL_0829;
																										}
																										goto IL_089e;
																										IL_0829:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0837;
																										IL_0837:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0877;
																										IL_0877:
																										array2[num5 - 2] = 0;
																										goto IL_088b;
																										IL_088b:
																										num5--;
																										goto IL_0faf;
																										IL_089e:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_08ac;
																										IL_08ac:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_08ba;
																										IL_08ba:
																										num5--;
																										goto IL_0faf;
																										IL_08cd:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_090d;
																										IL_090d:
																										array2[num5 - 2] = 0;
																										goto IL_0921;
																										IL_0921:
																										num5--;
																										goto IL_0faf;
																										IL_0934:
																										if (11 < b)
																										{
																											goto IL_093f;
																										}
																										goto IL_0960;
																										IL_093f:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_094d;
																										IL_094d:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0faf;
																										IL_0960:
																										if (11 > b)
																										{
																											goto IL_096e;
																										}
																										goto IL_09ff;
																										IL_096e:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_097c;
																										IL_097c:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_098a;
																										IL_098a:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_09ec;
																										IL_09ec:
																										num5 -= 2;
																										goto IL_0faf;
																										IL_09ff:
																										array2[num5 - 1] = 0;
																										goto IL_0a13;
																										IL_0a13:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																										goto IL_0a52;
																									}
																									break;
																								}
																								goto IL_0532;
																								IL_05e9:
																								array2[num5] = 5;
																								goto IL_0668;
																								IL_0532:
																								array8 = array3;
																								num6 = num5;
																								if (array == null)
																								{
																									goto IL_0541;
																								}
																								num7 = ptr2;
																								byte b2 = *num7;
																								ptr2 = num7 + 4;
																								int num8 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num8;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_05e9;
																								IL_0668:
																								num5++;
																								goto IL_0faf;
																							}
																							break;
																						}
																						goto IL_0a65;
																						IL_0f55:
																						array2[num5 - 1] = 5;
																						goto IL_0f69;
																						IL_0a65:
																						if (19 < b)
																						{
																							goto IL_0a73;
																						}
																						goto IL_0cc9;
																						IL_0a73:
																						if (22 >= b)
																						{
																							goto IL_0a81;
																						}
																						goto IL_0bdb;
																						IL_0a81:
																						if (22 <= b)
																						{
																							goto IL_0a8c;
																						}
																						goto IL_0b08;
																						IL_0a8c:
																						array2[num5 - 2] = 5;
																						goto IL_0aa0;
																						IL_0aa0:
																						array3[num5 - 2] = ((delegate*<string, object, string>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
																						goto IL_0ae7;
																						IL_0ae7:
																						num5--;
																						goto IL_0af5;
																						IL_0af5:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0b08:
																						if (20 >= b)
																						{
																							goto IL_0b13;
																						}
																						goto IL_0b7d;
																						IL_0b13:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0b21;
																						IL_0b21:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])();
																						num = 120;
																						goto IL_0b4e;
																						IL_0b4e:
																						array2[num5] = 0;
																						goto IL_0b5c;
																						IL_0b5c:
																						num5++;
																						goto IL_0b6a;
																						IL_0b6a:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0b7d:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0b8b;
																						IL_0b8b:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0b99;
																						IL_0b99:
																						array3[num5 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0bc2;
																						IL_0bc2:
																						array2[num5 - 1] = 5;
																						goto IL_0faf;
																						IL_0bdb:
																						if (24 < b)
																						{
																							goto IL_0be6;
																						}
																						goto IL_0c27;
																						IL_0be6:
																						if (25 < b)
																						{
																							break;
																						}
																						goto IL_0bf4;
																						IL_0bf4:
																						if (25 > b)
																						{
																							break;
																						}
																						goto IL_0c02;
																						IL_0c02:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						num = 189;
																						goto IL_0faf;
																						IL_0c27:
																						if (24 <= b)
																						{
																							goto IL_0c32;
																						}
																						goto IL_0c5a;
																						IL_0c32:
																						((delegate*<void>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])();
																						goto IL_0c47;
																						IL_0c47:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0c5a:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_0c68;
																						IL_0c68:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0c76;
																						IL_0c76:
																						((delegate*<string, void>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_0c9f;
																						IL_0c9f:
																						num5--;
																						num = 90;
																						goto IL_0cb6;
																						IL_0cb6:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0cc9:
																						if (19 > b)
																						{
																							goto IL_0cd7;
																						}
																						goto IL_0f55;
																						IL_0cd7:
																						if (16 < b)
																						{
																							goto IL_0ce5;
																						}
																						goto IL_0dbb;
																						IL_0ce5:
																						if (17 >= b)
																						{
																							goto IL_0cf0;
																						}
																						num = 57;
																						goto IL_0d4e;
																						IL_0cf0:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0cfe;
																						IL_0cfe:
																						array2[num5] = 5;
																						goto IL_0d0c;
																						IL_0d0c:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0d24;
																						IL_0d24:
																						num5++;
																						goto IL_0d32;
																						IL_0d32:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0f69:
																						array3[num5 - 1] = ((delegate*<string[], string>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0fa1;
																						IL_0d4e:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_0d5c;
																						IL_0d5c:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0d6a;
																						IL_0d6a:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_0da8;
																						IL_0da8:
																						num5 -= 3;
																						goto IL_0faf;
																						IL_0dbb:
																						if (16 > b)
																						{
																							goto IL_0dc9;
																						}
																						goto IL_0ed3;
																						IL_0dc9:
																						if (14 >= b)
																						{
																							goto IL_0dd4;
																						}
																						goto IL_0e2a;
																						IL_0dd4:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0de2;
																						IL_0de2:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						num = 171;
																						goto IL_0e09;
																						IL_0e09:
																						ptr2 += 8;
																						goto IL_0e17;
																						IL_0e17:
																						num5--;
																						goto IL_0faf;
																						IL_0e2a:
																						if (15 < b)
																						{
																							break;
																						}
																						num = 36;
																						goto IL_0e3e;
																						IL_0fa1:
																						ptr2 += 8;
																						goto IL_0faf;
																						IL_0e3e:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_0e49;
																						IL_0e49:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0e72;
																						IL_0e72:
																						array2[num5 - 1] = 5;
																						goto IL_0faf;
																						IL_0ed3:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0eeb;
																						IL_0eeb:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_0f09;
																						IL_0f09:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0f2d;
																						IL_0f2d:
																						array3[num5] = array3[num5 - 1];
																						goto IL_0f45;
																						IL_0f45:
																						num5++;
																						goto IL_0faf;
																					}
																					break;
																					IL_048c:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0ea4;
																			IL_0ec0:
																			ptr2 += 8;
																			goto IL_0faf;
																			IL_0eb2:
																			num5++;
																			goto IL_0ec0;
																			IL_0ea4:
																			array2[num5] = 0;
																			goto IL_0eb2;
																			continue;
																			end_IL_049c:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															num = 231;
															return;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0541:
			while (true)
			{
				IL_0541_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_05e9_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0668_2:
							num5++;
							while (true)
							{
								IL_0faf_2:
								if (num4 != 1)
								{
									while (true)
									{
										IL_04c5_2:
										byte b = *ptr2;
										while (true)
										{
											IL_04ac_2:
											ptr2++;
											num = 122;
											while (true)
											{
												IL_049c_2:
												if (b >= 1)
												{
													while (b <= 25)
													{
														while (true)
														{
															IL_047c_2:
															if (13 >= b)
															{
																while (13 > b)
																{
																	while (true)
																	{
																		IL_045c_2:
																		if (6 >= b)
																		{
																			while (true)
																			{
																				IL_044f_2:
																				if (6 > b)
																				{
																					while (true)
																					{
																						IL_043f_2:
																						if (3 < b)
																						{
																							while (true)
																							{
																								IL_042f_2:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_041c_2:
																										if (4 > b)
																										{
																											num = 251;
																											while (num != 251)
																											{
																												if (num != 1232)
																												{
																													goto IL_0a13_2;
																												}
																												switch (num)
																												{
																												case 123:
																													goto IL_041c_2;
																												case 38:
																												case 89:
																													goto IL_042f_2;
																												case 198:
																													goto IL_043f_2;
																												case 73:
																													goto IL_044f_2;
																												case 33:
																													goto IL_045c_2;
																												case 5:
																													goto IL_046c_2;
																												case 170:
																													goto IL_047c_2;
																												case 126:
																													goto IL_048c_2;
																												case 122:
																													goto IL_049c_2;
																												case 159:
																													goto IL_04ac_2;
																												case 92:
																												case 149:
																													goto IL_04c5_2;
																												case 66:
																												case 83:
																													goto IL_04d9_2;
																												case 12:
																													goto IL_0519_2;
																												case 61:
																												case 91:
																													goto end_IL_046c;
																												case 114:
																													goto IL_05e9_2;
																												case 81:
																												case 172:
																													goto IL_05f9_2;
																												case 165:
																													goto IL_0607_2;
																												case 20:
																													goto IL_062a_2;
																												case 138:
																													goto IL_0634_2;
																												case 0:
																													goto IL_0642_2;
																												case 173:
																													goto IL_0655_2;
																												case 187:
																													goto IL_0668_2;
																												case 104:
																													goto IL_067b_2;
																												case 143:
																													goto IL_0686_2;
																												case 17:
																												case 108:
																													goto IL_0694_2;
																												case 119:
																													goto IL_06d4_2;
																												case 86:
																													goto IL_06e8_2;
																												case 69:
																													goto IL_0709_2;
																												case 102:
																													goto IL_0717_2;
																												case 183:
																													goto IL_0722_2;
																												case 15:
																												case 207:
																													goto IL_0735_2;
																												case 204:
																													goto IL_0743_2;
																												case 93:
																												case 158:
																													goto IL_0751_2;
																												case 141:
																													goto IL_0791_2;
																												case 181:
																													goto IL_07a5_2;
																												case 168:
																												case 188:
																													goto IL_07b8_2;
																												case 117:
																													goto IL_07e1_2;
																												case 144:
																													goto IL_07ef_2;
																												case 193:
																													goto IL_0802_2;
																												case 146:
																													goto IL_0810_2;
																												case 196:
																												case 225:
																													goto IL_081e_2;
																												case 8:
																													goto IL_0829_2;
																												case 128:
																												case 206:
																													goto IL_0837_2;
																												case 84:
																													goto IL_0877_2;
																												case 233:
																													goto IL_088b_2;
																												case 202:
																													goto IL_089e_2;
																												case 166:
																													goto IL_08ac_2;
																												case 21:
																												case 75:
																													goto IL_08ba_2;
																												case 174:
																												case 221:
																													goto IL_08cd_2;
																												case 97:
																													goto IL_090d_2;
																												case 41:
																													goto IL_0921_2;
																												case 4:
																													goto IL_0934_2;
																												case 3:
																												case 7:
																													goto IL_093f_2;
																												case 148:
																													goto IL_094d_2;
																												case 28:
																													goto IL_0960_2;
																												case 2:
																												case 192:
																													goto IL_096e_2;
																												case 107:
																													goto IL_097c_2;
																												case 112:
																												case 132:
																													goto IL_098a_2;
																												case 241:
																													goto IL_09ec_2;
																												case 54:
																												case 213:
																													goto IL_09ff_2;
																												case 118:
																													goto IL_0a13_2;
																												case 142:
																													goto IL_0a52_2;
																												case 115:
																												case 182:
																													goto IL_0a65_2;
																												case 157:
																													goto IL_0a73_2;
																												case 35:
																													goto IL_0a81_2;
																												case 39:
																												case 121:
																													goto IL_0a8c_2;
																												case 244:
																													goto IL_0aa0_2;
																												case 44:
																													goto IL_0ae7_2;
																												case 130:
																													goto IL_0af5_2;
																												case 63:
																													goto IL_0b08_2;
																												case 140:
																													goto IL_0b13_2;
																												case 40:
																												case 240:
																													goto IL_0b21_2;
																												case 120:
																													goto IL_0b4e_2;
																												case 239:
																													goto IL_0b5c_2;
																												case 230:
																													goto IL_0b6a_2;
																												case 135:
																													goto IL_0b7d_2;
																												case 58:
																													goto IL_0b8b_2;
																												case 116:
																												case 129:
																													goto IL_0b99_2;
																												case 13:
																													goto IL_0bc2_2;
																												case 237:
																													goto IL_0bdb_2;
																												case 199:
																												case 234:
																													goto IL_0be6_2;
																												case 47:
																													goto IL_0bf4_2;
																												case 34:
																												case 136:
																													goto IL_0c02_2;
																												case 194:
																													goto IL_0c27_2;
																												case 9:
																												case 64:
																													goto IL_0c32_2;
																												case 175:
																													goto IL_0c47_2;
																												case 65:
																													goto IL_0c5a_2;
																												case 50:
																													goto IL_0c68_2;
																												case 48:
																												case 67:
																													goto IL_0c76_2;
																												case 98:
																													goto IL_0c9f_2;
																												case 90:
																													goto IL_0cb6_2;
																												case 223:
																													goto IL_0cc9_2;
																												case 10:
																												case 70:
																													goto IL_0cd7_2;
																												case 11:
																												case 52:
																													goto IL_0ce5_2;
																												case 110:
																													goto IL_0cf0_2;
																												case 85:
																												case 238:
																													goto IL_0cfe_2;
																												case 77:
																													goto IL_0d0c_2;
																												case 46:
																													goto IL_0d24_2;
																												case 99:
																													goto IL_0d32_2;
																												case 57:
																												case 160:
																													goto IL_0d4e_2;
																												case 197:
																													goto IL_0d5c_2;
																												case 53:
																												case 62:
																													goto IL_0d6a_2;
																												case 164:
																													goto IL_0da8_2;
																												case 60:
																													goto IL_0dbb_2;
																												case 80:
																													goto IL_0dc9_2;
																												case 195:
																													goto IL_0dd4_2;
																												case 1:
																												case 87:
																													goto IL_0de2_2;
																												case 171:
																													goto IL_0e09_2;
																												case 82:
																													goto IL_0e17_2;
																												case 68:
																												case 152:
																													goto IL_0e2a_2;
																												case 36:
																													goto IL_0e3e_2;
																												case 161:
																												case 218:
																													goto IL_0e49_2;
																												case 18:
																													goto IL_0e72_2;
																												case 6:
																												case 22:
																												case 26:
																												case 29:
																												case 31:
																												case 32:
																												case 43:
																												case 59:
																												case 72:
																												case 76:
																												case 94:
																												case 95:
																												case 96:
																												case 100:
																												case 101:
																												case 105:
																												case 106:
																												case 124:
																												case 127:
																												case 145:
																												case 147:
																												case 154:
																												case 155:
																												case 156:
																												case 162:
																												case 163:
																												case 177:
																												case 178:
																												case 185:
																												case 186:
																												case 191:
																												case 201:
																												case 205:
																												case 210:
																												case 212:
																												case 217:
																												case 219:
																												case 222:
																												case 227:
																												case 228:
																												case 229:
																												case 232:
																												case 235:
																												case 236:
																													goto end_IL_0409_2;
																												case 203:
																													goto IL_0ea4_2;
																												case 25:
																													goto IL_0eb2_2;
																												case 16:
																													goto IL_0ec0_2;
																												case 151:
																												case 215:
																													goto IL_0ed3_2;
																												case 137:
																													goto IL_0eeb_2;
																												case 49:
																													goto IL_0f09_2;
																												case 71:
																													goto IL_0f2d_2;
																												case 180:
																													goto IL_0f45_2;
																												case 179:
																												case 224:
																													goto IL_0f55_2;
																												case 27:
																													goto IL_0f69_2;
																												case 169:
																													goto IL_0fa1_2;
																												case 23:
																												case 24:
																												case 37:
																												case 42:
																												case 51:
																												case 56:
																												case 78:
																												case 79:
																												case 103:
																												case 111:
																												case 113:
																												case 125:
																												case 131:
																												case 139:
																												case 150:
																												case 167:
																												case 176:
																												case 184:
																												case 189:
																												case 190:
																												case 208:
																												case 211:
																												case 214:
																												case 216:
																												case 220:
																												case 226:
																												case 242:
																												case 243:
																													goto IL_0faf_2;
																												case 153:
																													ptr2 = ptr;
																													goto IL_0faf_2;
																												case 45:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BootstrapConextShiftPressed.AttachedToParentgetIsMetric);
																													goto case 153;
																												case 30:
																													array7 = new object[14];
																													goto case 45;
																												case 109:
																													array6 = new long[4];
																													num = 30;
																													goto case 30;
																												case 55:
																													array5 = new int[6];
																													goto case 109;
																												case 74:
																													array4 = new int[4];
																													goto case 55;
																												case 88:
																													array3 = new object[4];
																													goto case 74;
																												case 14:
																												case 200:
																													array2 = new byte[4];
																													num = 88;
																													goto case 88;
																												case 209:
																													num3 = num2 * 4;
																													goto case 14;
																												case 133:
																													num2 = 1;
																													goto case 209;
																												case 134:
																													goto end_IL_054f;
																												case 19:
																												case 231:
																													return;
																												}
																												continue;
																												end_IL_0409_2:
																												break;
																											}
																											break;
																										}
																										goto IL_05f9_2;
																										IL_0634_2:
																										num5++;
																										goto IL_0642_2;
																										IL_0642_2:
																										ptr2 += 8;
																										goto IL_0faf_2;
																										IL_05f9_2:
																										array2[num5] = 0;
																										goto IL_0607_2;
																										IL_0607_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_062a_2;
																										IL_062a_2:
																										array3[num5] = null;
																										goto IL_0634_2;
																									}
																									break;
																								}
																								goto IL_067b_2;
																								IL_06e8_2:
																								num5--;
																								goto IL_0faf_2;
																								IL_067b_2:
																								if (5 < b)
																								{
																									num = 22;
																									break;
																								}
																								goto IL_0686_2;
																								IL_0686_2:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0694_2;
																								IL_0694_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_06d4_2;
																								IL_06d4_2:
																								array2[num5 - 2] = 0;
																								goto IL_06e8_2;
																							}
																							break;
																						}
																						goto IL_0709_2;
																						IL_07ef_2:
																						num5--;
																						goto IL_0faf_2;
																						IL_0709_2:
																						if (3 > b)
																						{
																							goto IL_0717_2;
																						}
																						goto IL_07b8_2;
																						IL_0717_2:
																						if (1 >= b)
																						{
																							goto IL_0722_2;
																						}
																						goto IL_0735_2;
																						IL_0722_2:
																						if (1 <= b)
																						{
																						}
																						break;
																						IL_0735_2:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_0743_2;
																						IL_0743_2:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_0751_2;
																						IL_0751_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0791_2;
																						IL_0791_2:
																						array2[num5 - 2] = 0;
																						goto IL_07a5_2;
																						IL_07a5_2:
																						num5--;
																						goto IL_0faf_2;
																						IL_07b8_2:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_07e1_2;
																						IL_07e1_2:
																						ptr2 += 8;
																						goto IL_07ef_2;
																					}
																					break;
																				}
																				num = 83;
																				goto IL_04d9_2;
																				IL_0519_2:
																				array2[num5 - 2] = 0;
																				goto IL_0655_2;
																				IL_0655_2:
																				num5--;
																				goto IL_0faf_2;
																				IL_04d9_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																				goto IL_0519_2;
																			}
																			break;
																		}
																		goto IL_0802_2;
																		IL_0a52_2:
																		ptr2 += 8;
																		goto IL_0faf_2;
																		IL_0802_2:
																		if (9 >= b)
																		{
																			goto IL_0810_2;
																		}
																		goto IL_0934_2;
																		IL_0810_2:
																		if (9 > b)
																		{
																			goto IL_081e_2;
																		}
																		goto IL_08cd_2;
																		IL_081e_2:
																		if (7 >= b)
																		{
																			goto IL_0829_2;
																		}
																		goto IL_089e_2;
																		IL_0829_2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0837_2;
																		IL_0837_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0877_2;
																		IL_0877_2:
																		array2[num5 - 2] = 0;
																		goto IL_088b_2;
																		IL_088b_2:
																		num5--;
																		goto IL_0faf_2;
																		IL_089e_2:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_08ac_2;
																		IL_08ac_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_08ba_2;
																		IL_08ba_2:
																		num5--;
																		goto IL_0faf_2;
																		IL_08cd_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_090d_2;
																		IL_090d_2:
																		array2[num5 - 2] = 0;
																		goto IL_0921_2;
																		IL_0921_2:
																		num5--;
																		goto IL_0faf_2;
																		IL_0934_2:
																		if (11 < b)
																		{
																			goto IL_093f_2;
																		}
																		goto IL_0960_2;
																		IL_093f_2:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_094d_2;
																		IL_094d_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0faf_2;
																		IL_0960_2:
																		if (11 > b)
																		{
																			goto IL_096e_2;
																		}
																		goto IL_09ff_2;
																		IL_096e_2:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_097c_2;
																		IL_097c_2:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_098a_2;
																		IL_098a_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_09ec_2;
																		IL_09ec_2:
																		num5 -= 2;
																		goto IL_0faf_2;
																		IL_09ff_2:
																		array2[num5 - 1] = 0;
																		goto IL_0a13_2;
																		IL_0a13_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																		goto IL_0a52_2;
																	}
																	goto end_IL_048c;
																	continue;
																	end_IL_046c:
																	break;
																	IL_046c_2:;
																}
																break;
															}
															goto IL_0a65_2;
															IL_0f55_2:
															array2[num5 - 1] = 5;
															goto IL_0f69_2;
															IL_0a65_2:
															if (19 < b)
															{
																goto IL_0a73_2;
															}
															goto IL_0cc9_2;
															IL_0a73_2:
															if (22 >= b)
															{
																goto IL_0a81_2;
															}
															goto IL_0bdb_2;
															IL_0a81_2:
															if (22 <= b)
															{
																goto IL_0a8c_2;
															}
															goto IL_0b08_2;
															IL_0a8c_2:
															array2[num5 - 2] = 5;
															goto IL_0aa0_2;
															IL_0aa0_2:
															array3[num5 - 2] = ((delegate*<string, object, string>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
															goto IL_0ae7_2;
															IL_0ae7_2:
															num5--;
															goto IL_0af5_2;
															IL_0af5_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0b08_2:
															if (20 >= b)
															{
																goto IL_0b13_2;
															}
															goto IL_0b7d_2;
															IL_0b13_2:
															if (20 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0b21_2;
															IL_0b21_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])();
															num = 120;
															goto IL_0b4e_2;
															IL_0b4e_2:
															array2[num5] = 0;
															goto IL_0b5c_2;
															IL_0b5c_2:
															num5++;
															goto IL_0b6a_2;
															IL_0b6a_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0b7d_2:
															if (21 < b)
															{
																goto end_IL_048c;
															}
															goto IL_0b8b_2;
															IL_0b8b_2:
															if (21 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0b99_2;
															IL_0b99_2:
															array3[num5 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0bc2_2;
															IL_0bc2_2:
															array2[num5 - 1] = 5;
															goto IL_0faf_2;
															IL_0bdb_2:
															if (24 < b)
															{
																goto IL_0be6_2;
															}
															goto IL_0c27_2;
															IL_0be6_2:
															if (25 < b)
															{
																goto end_IL_048c;
															}
															goto IL_0bf4_2;
															IL_0bf4_2:
															if (25 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0c02_2;
															IL_0c02_2:
															num9 = ptr2;
															num10 = -200;
															num4 = 1;
															ptr2 = num9 + num10;
															num = 189;
															goto IL_0faf_2;
															IL_0c27_2:
															if (24 <= b)
															{
																goto IL_0c32_2;
															}
															goto IL_0c5a_2;
															IL_0c32_2:
															((delegate*<void>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])();
															goto IL_0c47_2;
															IL_0c47_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0c5a_2:
															if (23 < b)
															{
																goto end_IL_048c;
															}
															goto IL_0c68_2;
															IL_0c68_2:
															if (23 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0c76_2;
															IL_0c76_2:
															((delegate*<string, void>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
															goto IL_0c9f_2;
															IL_0c9f_2:
															num5--;
															num = 90;
															goto IL_0cb6_2;
															IL_0cb6_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0cc9_2:
															if (19 > b)
															{
																goto IL_0cd7_2;
															}
															goto IL_0f55_2;
															IL_0cd7_2:
															if (16 < b)
															{
																goto IL_0ce5_2;
															}
															goto IL_0dbb_2;
															IL_0ce5_2:
															if (17 >= b)
															{
																goto IL_0cf0_2;
															}
															num = 57;
															goto IL_0d4e_2;
															IL_0cf0_2:
															if (17 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0cfe_2;
															IL_0cfe_2:
															array2[num5] = 5;
															goto IL_0d0c_2;
															IL_0d0c_2:
															array3[num5] = array7[*(int*)(ptr2 + num3)];
															goto IL_0d24_2;
															IL_0d24_2:
															num5++;
															goto IL_0d32_2;
															IL_0d32_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0f69_2:
															array3[num5 - 1] = ((delegate*<string[], string>)ExportgetRuntimeVersion[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															goto IL_0fa1_2;
															IL_0d4e_2:
															if (18 < b)
															{
																goto end_IL_048c;
															}
															goto IL_0d5c_2;
															IL_0d5c_2:
															if (18 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0d6a_2;
															IL_0d6a_2:
															((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
															goto IL_0da8_2;
															IL_0da8_2:
															num5 -= 3;
															goto IL_0faf_2;
															IL_0dbb_2:
															if (16 > b)
															{
																goto IL_0dc9_2;
															}
															goto IL_0ed3_2;
															IL_0dc9_2:
															if (14 >= b)
															{
																goto IL_0dd4_2;
															}
															goto IL_0e2a_2;
															IL_0dd4_2:
															if (14 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0de2_2;
															IL_0de2_2:
															array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
															num = 171;
															goto IL_0e09_2;
															IL_0e09_2:
															ptr2 += 8;
															goto IL_0e17_2;
															IL_0e17_2:
															num5--;
															goto IL_0faf_2;
															IL_0e2a_2:
															if (15 < b)
															{
																goto end_IL_048c;
															}
															num = 36;
															goto IL_0e3e_2;
															IL_0fa1_2:
															ptr2 += 8;
															goto IL_0faf_2;
															IL_0e3e_2:
															if (15 > b)
															{
																goto end_IL_048c;
															}
															goto IL_0e49_2;
															IL_0e49_2:
															array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
															goto IL_0e72_2;
															IL_0e72_2:
															array2[num5 - 1] = 5;
															goto IL_0faf_2;
															IL_0ed3_2:
															array2[num5] = array2[num5 - 1];
															goto IL_0eeb_2;
															IL_0eeb_2:
															array4[num5 - 0] = array4[num5 - 1];
															goto IL_0f09_2;
															IL_0f09_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0f2d_2;
															IL_0f2d_2:
															array3[num5] = array3[num5 - 1];
															goto IL_0f45_2;
															IL_0f45_2:
															num5++;
															goto IL_0faf_2;
														}
														goto end_IL_049c_2;
														continue;
														end_IL_048c:
														break;
														IL_048c_2:;
													}
												}
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
												goto IL_0ea4_2;
												IL_0ec0_2:
												ptr2 += 8;
												goto IL_0faf_2;
												IL_0eb2_2:
												num5++;
												goto IL_0ec0_2;
												IL_0ea4_2:
												array2[num5] = 0;
												goto IL_0eb2_2;
												continue;
												end_IL_049c_2:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								num = 231;
								return;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0541_2;
					}
					continue;
					end_IL_054f:
					break;
				}
				break;
			}
		}
	}

	private static string CheckedOneWaygetTargetScheduler(string string_0, object object_0)
	{
		return string.Format(string_0, object_0);
	}

	private static double setIsConsoleEnabledCleanupCode(double double_1)
	{
		return Math.Log(double_1);
	}

	private static float VARFLAGSIsLeapDay()
	{
		return Time.time;
	}

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0519, IL_052c, IL_053f, IL_054f, IL_055f, IL_056f, IL_057f, IL_058c, IL_059c, IL_05ac, IL_05bc, IL_05c7, IL_05d2, IL_05e0, IL_05ee, IL_05fc, IL_060a, IL_0618, IL_0632, IL_063d, IL_064b, IL_065e, IL_0671, IL_067f, IL_0692, IL_06a0, IL_06c4, IL_06d2, IL_06e5, IL_06f8, IL_070b, IL_0719, IL_0727, IL_0735, IL_0743, IL_074e, IL_075c, IL_076f, IL_077d, IL_078b, IL_0799, IL_07a2, IL_07c0, IL_07ce, IL_07dc, IL_07ea, IL_07f8, IL_0838, IL_084c, IL_085f, IL_089f, IL_08b3, IL_08c6, IL_08cf, IL_08dd, IL_08eb, IL_0930, IL_0943, IL_0951, IL_095f, IL_096a, IL_0988, IL_0996, IL_09b2, IL_09c0, IL_09ce, IL_09eb, IL_0a3a, IL_0a44, IL_0a71, IL_0a85, IL_0a9c, IL_0aaf, IL_0aef, IL_0b08, IL_0b1c, IL_0b2f, IL_0b42, IL_0b4d, IL_0b58, IL_0b66, IL_0b74, IL_0b89, IL_0b9c, IL_0baa, IL_0bb8, IL_0bcb, IL_0be3, IL_0bf1, IL_0bff, IL_0c12, IL_0c20, IL_0c2e, IL_0c3c, IL_0c54, IL_0c72, IL_0c96, IL_0cae, IL_0cc1, IL_0ccc, IL_0cd7, IL_0ce5, IL_0cf8, IL_0d06, IL_0d34, IL_0d47, IL_0d52, IL_0d60, IL_0d6e, IL_0d97, IL_0da5, IL_0db8, IL_0dd4, IL_0de2, IL_0e0f, IL_0e1d, IL_0e2b, IL_0e3e, IL_0eb5, IL_0ec8, IL_0ed6, IL_0ef9, IL_0f03, IL_0f11, IL_0f24, IL_0f32, IL_0f5b, IL_0f7d, IL_0f8b, IL_0f99, IL_0fac, IL_0fc0, IL_1007, IL_1015, IL_1028, IL_1036, IL_1044, IL_10a6, IL_10b9, IL_10c7, IL_10d5, IL_10e9, IL_113d, IL_114b, IL_115e, IL_1171, IL_119c, IL_11b6, IL_11c9, IL_11d7, IL_11ea, IL_1213, IL_1221, IL_1234, IL_1242, IL_1250, IL_1299, IL_12ad, IL_12c0, IL_12cb, IL_12df, IL_1317, IL_132a, IL_1338, IL_1343, IL_1381, IL_1394, IL_13a2, IL_1400, IL_1410, IL_1439, IL_144f, IL_1462, IL_1475, IL_1488, IL_1493, IL_14ac, IL_14bc, IL_14cc, IL_14e5, IL_14f5, IL_1505, IL_1515, IL_1525 are reachable both inside and outside the pinned region starting at IL_153a. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 198;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			int __rxRef47 = default(int);
			ref int reference = ref __rxRef47;
			object[] array8;
			int num8;
			byte* num9;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1525:
					num2 = 1;
					while (true)
					{
						IL_1515:
						num3 = num2 * 4;
						while (true)
						{
							IL_1505:
							array2 = new byte[4];
							while (true)
							{
								IL_14f5:
								array3 = new object[4];
								while (true)
								{
									IL_14e5:
									array4 = new int[4];
									while (true)
									{
										IL_14cc:
										array5 = new int[6];
										num = 99;
										while (true)
										{
											IL_14bc:
											array6 = new long[4];
											while (true)
											{
												IL_14ac:
												array7 = new object[15];
												while (true)
												{
													IL_1493:
													array7[0] = this;
													num = 294;
													while (true)
													{
														IL_1488:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StartMenuStageComponent.getLicenseFilePort);
														while (true)
														{
															IL_1475:
															ptr2 = ptr;
															num = 86;
															while (true)
															{
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_05bc:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_05ac:
																		ptr2++;
																		while (true)
																		{
																			IL_059c:
																			if (b >= 1)
																			{
																				while (b <= 33)
																				{
																					while (true)
																					{
																						IL_057f:
																						if (17 < b)
																						{
																							while (true)
																							{
																								IL_056f:
																								if (25 >= b)
																								{
																									while (true)
																									{
																										IL_055f:
																										if (25 > b)
																										{
																											while (true)
																											{
																												IL_054f:
																												if (21 >= b)
																												{
																													while (true)
																													{
																														IL_053f:
																														if (21 > b)
																														{
																															while (true)
																															{
																																IL_052c:
																																if (19 >= b)
																																{
																																	num = 319;
																																	while (true)
																																	{
																																		if (num != 319)
																																		{
																																			if (num != 1300)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 198:
																																				break;
																																			default:
																																				continue;
																																			case 159:
																																				goto IL_052c;
																																			case 133:
																																				goto IL_053f;
																																			case 135:
																																			case 188:
																																				goto IL_054f;
																																			case 144:
																																				goto IL_055f;
																																			case 243:
																																				goto IL_056f;
																																			case 184:
																																				goto IL_057f;
																																			case 137:
																																				goto IL_058c;
																																			case 48:
																																				goto IL_059c;
																																			case 289:
																																				goto IL_05ac;
																																			case 67:
																																			case 303:
																																				goto IL_05bc;
																																			case 44:
																																				goto IL_05d2;
																																			case 28:
																																				goto IL_05e0;
																																			case 74:
																																				goto IL_05fc;
																																			case 17:
																																			case 114:
																																				goto IL_060a;
																																			case 127:
																																				goto IL_0618;
																																			case 78:
																																			case 141:
																																				goto IL_0632;
																																			case 162:
																																				goto IL_063d;
																																			case 8:
																																				goto IL_064b;
																																			case 183:
																																				goto IL_065e;
																																			case 214:
																																				goto IL_0671;
																																			case 187:
																																				goto IL_067f;
																																			case 68:
																																			case 232:
																																				goto IL_0692;
																																			case 208:
																																				goto IL_06a0;
																																			case 148:
																																				goto IL_06c4;
																																			case 89:
																																				goto IL_06d2;
																																			case 39:
																																			case 235:
																																				goto IL_06e5;
																																			case 247:
																																				goto IL_06f8;
																																			case 264:
																																				goto IL_070b;
																																			case 180:
																																				goto IL_0719;
																																			case 50:
																																			case 171:
																																				goto IL_0727;
																																			case 212:
																																				goto IL_0735;
																																			case 27:
																																				goto IL_0743;
																																			case 23:
																																			case 92:
																																				goto IL_074e;
																																			case 49:
																																				goto IL_075c;
																																			case 245:
																																				goto IL_076f;
																																			case 108:
																																				goto IL_077d;
																																			case 63:
																																				goto IL_078b;
																																			case 192:
																																			case 210:
																																				goto IL_07a2;
																																			case 18:
																																				goto IL_07c0;
																																			case 106:
																																				goto IL_07ce;
																																			case 164:
																																			case 252:
																																				goto IL_07dc;
																																			case 253:
																																				goto IL_07ea;
																																			case 177:
																																			case 199:
																																				goto IL_07f8;
																																			case 91:
																																				goto IL_0838;
																																			case 248:
																																				goto IL_084c;
																																			case 201:
																																			case 257:
																																				goto IL_085f;
																																			case 225:
																																				goto IL_089f;
																																			case 190:
																																				goto IL_08b3;
																																			case 216:
																																			case 240:
																																				goto IL_08cf;
																																			case 136:
																																				goto IL_08dd;
																																			case 35:
																																			case 66:
																																				goto IL_08eb;
																																			case 117:
																																			case 175:
																																				goto IL_0930;
																																			case 79:
																																				goto IL_0943;
																																			case 112:
																																			case 211:
																																				goto IL_0951;
																																			case 43:
																																				goto IL_095f;
																																			case 60:
																																			case 98:
																																				goto IL_096a;
																																			case 207:
																																				goto IL_0988;
																																			case 82:
																																				goto IL_0996;
																																			case 1:
																																				goto IL_09b2;
																																			case 146:
																																				goto IL_09c0;
																																			case 249:
																																			case 250:
																																				goto IL_09ce;
																																			case 166:
																																				goto IL_0a85;
																																			case 87:
																																				goto IL_0a9c;
																																			case 83:
																																			case 267:
																																				goto IL_0aaf;
																																			case 215:
																																				goto IL_0aef;
																																			case 271:
																																				goto IL_0b08;
																																			case 40:
																																				goto IL_0b1c;
																																			case 272:
																																				goto IL_0b2f;
																																			case 275:
																																				goto IL_0b42;
																																			case 65:
																																			case 219:
																																				goto IL_0b4d;
																																			case 69:
																																			case 113:
																																				goto IL_0b58;
																																			case 224:
																																				goto IL_0b66;
																																			case 12:
																																			case 140:
																																				goto IL_0b74;
																																			case 173:
																																				goto IL_0b89;
																																			case 170:
																																				goto IL_0b9c;
																																			case 255:
																																				goto IL_0baa;
																																			case 47:
																																				goto IL_0bb8;
																																			case 109:
																																			case 236:
																																				goto IL_0bcb;
																																			case 57:
																																				goto IL_0be3;
																																			case 269:
																																				goto IL_0bf1;
																																			case 239:
																																				goto IL_0bff;
																																			case 278:
																																				goto IL_0c12;
																																			case 22:
																																			case 149:
																																				goto IL_0c20;
																																			case 242:
																																				goto IL_0c2e;
																																			case 234:
																																			case 260:
																																				goto IL_0c3c;
																																			case 0:
																																				goto IL_0c54;
																																			case 45:
																																				goto IL_0c72;
																																			case 37:
																																				goto IL_0c96;
																																			case 64:
																																				goto IL_0cae;
																																			case 194:
																																			case 279:
																																				goto IL_0cc1;
																																			case 72:
																																			case 97:
																																				goto IL_0ccc;
																																			case 128:
																																			case 169:
																																				goto IL_0cd7;
																																			case 262:
																																				goto IL_0ce5;
																																			case 116:
																																				goto IL_0cf8;
																																			case 34:
																																			case 122:
																																				goto IL_0d06;
																																			case 85:
																																				goto IL_0d34;
																																			case 261:
																																				goto IL_0d47;
																																			case 46:
																																			case 200:
																																				goto IL_0d52;
																																			case 209:
																																				goto IL_0d60;
																																			case 142:
																																			case 176:
																																				goto IL_0d6e;
																																			case 13:
																																				goto IL_0d97;
																																			case 185:
																																				goto IL_0da5;
																																			case 120:
																																			case 237:
																																				goto IL_0db8;
																																			case 282:
																																				goto IL_0dd4;
																																			case 196:
																																			case 204:
																																				goto IL_0de2;
																																			case 259:
																																				goto IL_0e0f;
																																			case 93:
																																				goto IL_0e1d;
																																			case 147:
																																				goto IL_0e2b;
																																			case 121:
																																			case 284:
																																				goto IL_0e3e;
																																			case 161:
																																				goto IL_0eb5;
																																			case 150:
																																			case 288:
																																				goto IL_0ec8;
																																			case 70:
																																				goto IL_0ed6;
																																			case 218:
																																				goto IL_0ef9;
																																			case 14:
																																				goto IL_0f03;
																																			case 223:
																																				goto IL_0f11;
																																			case 290:
																																				goto IL_0f24;
																																			case 51:
																																			case 104:
																																				goto IL_0f32;
																																			case 25:
																																				goto IL_0f5b;
																																			case 292:
																																				goto IL_0f7d;
																																			case 124:
																																				goto IL_0f8b;
																																			case 246:
																																				goto IL_0f99;
																																			case 32:
																																			case 295:
																																				goto IL_0fac;
																																			case 195:
																																				goto IL_0fc0;
																																			case 231:
																																				goto IL_1007;
																																			case 58:
																																				goto IL_1015;
																																			case 296:
																																				goto IL_1028;
																																			case 222:
																																				goto IL_1036;
																																			case 256:
																																			case 270:
																																				goto IL_1044;
																																			case 179:
																																				goto IL_10a6;
																																			case 100:
																																				goto IL_10b9;
																																			case 36:
																																				goto IL_10c7;
																																			case 129:
																																			case 244:
																																				goto IL_10d5;
																																			case 115:
																																				goto IL_10e9;
																																			case 20:
																																				goto IL_113d;
																																			case 230:
																																				goto IL_114b;
																																			case 297:
																																				goto IL_115e;
																																			case 154:
																																			case 299:
																																				goto IL_1171;
																																			case 178:
																																			case 300:
																																				goto IL_119c;
																																			case 119:
																																				goto IL_11b6;
																																			case 305:
																																				goto IL_11c9;
																																			case 287:
																																				goto IL_11d7;
																																			case 130:
																																			case 308:
																																				goto IL_11ea;
																																			case 132:
																																				goto IL_1213;
																																			case 152:
																																				goto IL_1221;
																																			case 312:
																																				goto IL_1234;
																																			case 96:
																																				goto IL_1242;
																																			case 165:
																																			case 301:
																																				goto IL_1250;
																																			case 143:
																																				goto IL_1299;
																																			case 268:
																																				goto IL_12ad;
																																			case 31:
																																			case 155:
																																				goto IL_12cb;
																																			case 56:
																																				goto IL_12df;
																																			case 266:
																																				goto IL_1317;
																																			case 182:
																																				goto IL_132a;
																																			case 26:
																																				goto IL_1338;
																																			case 29:
																																			case 42:
																																				goto IL_1343;
																																			case 309:
																																				goto IL_1381;
																																			case 131:
																																			case 228:
																																				goto IL_13a2;
																																			case 111:
																																				goto IL_1400;
																																			case 167:
																																			case 205:
																																				goto IL_1410;
																																			case 274:
																																				goto IL_1439;
																																			case 5:
																																			case 6:
																																			case 7:
																																			case 10:
																																			case 16:
																																			case 19:
																																			case 21:
																																			case 24:
																																			case 33:
																																			case 54:
																																			case 55:
																																			case 59:
																																			case 71:
																																			case 73:
																																			case 75:
																																			case 77:
																																			case 90:
																																			case 94:
																																			case 101:
																																			case 103:
																																			case 105:
																																			case 107:
																																			case 126:
																																			case 138:
																																			case 145:
																																			case 151:
																																			case 153:
																																			case 158:
																																			case 160:
																																			case 163:
																																			case 168:
																																			case 172:
																																			case 181:
																																			case 189:
																																			case 191:
																																			case 202:
																																			case 203:
																																			case 220:
																																			case 226:
																																			case 233:
																																			case 238:
																																			case 251:
																																			case 254:
																																			case 258:
																																			case 263:
																																			case 273:
																																			case 276:
																																			case 277:
																																			case 280:
																																			case 281:
																																			case 285:
																																			case 286:
																																			case 293:
																																			case 298:
																																			case 302:
																																				goto end_IL_058c;
																																			case 2:
																																			case 3:
																																			case 4:
																																			case 9:
																																			case 15:
																																			case 30:
																																			case 41:
																																			case 53:
																																			case 61:
																																			case 62:
																																			case 76:
																																			case 80:
																																			case 84:
																																			case 86:
																																			case 88:
																																			case 102:
																																			case 110:
																																			case 118:
																																			case 123:
																																			case 125:
																																			case 134:
																																			case 139:
																																			case 156:
																																			case 157:
																																			case 174:
																																			case 186:
																																			case 193:
																																			case 206:
																																			case 213:
																																			case 217:
																																			case 229:
																																			case 241:
																																			case 291:
																																			case 304:
																																			case 307:
																																			case 311:
																																				goto end_IL_0519;
																																			case 265:
																																				goto IL_1475;
																																			case 294:
																																				goto IL_1488;
																																			case 52:
																																				goto IL_1493;
																																			case 81:
																																				goto IL_14ac;
																																			case 99:
																																				goto IL_14bc;
																																			case 227:
																																				goto IL_14cc;
																																			case 306:
																																				goto IL_14e5;
																																			case 11:
																																				goto IL_14f5;
																																			case 38:
																																			case 95:
																																				goto IL_1505;
																																			case 310:
																																				goto IL_1515;
																																			case 197:
																																				goto IL_1525;
																																			case 221:
																																			case 283:
																																				return;
																																			}
																																			goto end_IL_1462;
																																		}
																																		if (19 <= b)
																																		{
																																			goto IL_12cb;
																																		}
																																		goto IL_132a;
																																		IL_1338:
																																		if (18 > b)
																																		{
																																			num = 7;
																																			goto end_IL_058c;
																																		}
																																		goto IL_1343;
																																		IL_1381:
																																		num5 -= 3;
																																		break;
																																		IL_1343:
																																		((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																																		goto IL_1381;
																																		IL_12cb:
																																		array2[num5 - 1] = 5;
																																		goto IL_12df;
																																		IL_12df:
																																		array3[num5 - 1] = ((delegate*<string[], string>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																																		goto IL_1317;
																																		IL_1317:
																																		ptr2 += 8;
																																		break;
																																		IL_132a:
																																		if (18 < b)
																																		{
																																			goto end_IL_058c;
																																		}
																																		goto IL_1338;
																																		continue;
																																		end_IL_0519:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_05d2;
																																IL_06a0:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																goto IL_06c4;
																																IL_06c4:
																																num5++;
																																goto IL_06d2;
																																IL_05d2:
																																if (20 < b)
																																{
																																	goto end_IL_058c;
																																}
																																goto IL_05e0;
																																IL_05e0:
																																if (20 > b)
																																{
																																	goto end_IL_058c;
																																}
																																num = 68;
																																goto IL_0692;
																																IL_06d2:
																																ptr2 += 8;
																																break;
																																IL_0692:
																																array2[num5] = 0;
																																goto IL_06a0;
																															}
																															break;
																														}
																														goto IL_13a2;
																														IL_1400:
																														num5--;
																														break;
																														IL_13a2:
																														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_1400;
																													}
																													break;
																												}
																												goto IL_0632;
																												IL_0eb5:
																												num5 -= 2;
																												break;
																												IL_0632:
																												if (23 >= b)
																												{
																													goto IL_063d;
																												}
																												goto IL_0671;
																												IL_063d:
																												if (23 > b)
																												{
																													goto IL_064b;
																												}
																												goto IL_119c;
																												IL_064b:
																												if (22 < b)
																												{
																													goto end_IL_058c;
																												}
																												goto IL_0dd4;
																												IL_0dd4:
																												if (22 > b)
																												{
																													goto end_IL_058c;
																												}
																												goto IL_0de2;
																												IL_0de2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])();
																												num = 259;
																												goto IL_0e0f;
																												IL_0e0f:
																												array2[num5] = 0;
																												goto IL_0e1d;
																												IL_0e1d:
																												num5++;
																												goto IL_0e2b;
																												IL_0e2b:
																												ptr2 += 8;
																												break;
																												IL_119c:
																												int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																												goto IL_11b6;
																												IL_11b6:
																												num5--;
																												break;
																												IL_0671:
																												if (24 < b)
																												{
																													goto end_IL_058c;
																												}
																												goto IL_067f;
																												IL_067f:
																												if (24 > b)
																												{
																													goto end_IL_058c;
																												}
																												goto IL_0e3e;
																												IL_0e3e:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												num = 161;
																												goto IL_0eb5;
																											}
																											break;
																										}
																										goto IL_1410;
																										IL_1439:
																										array2[num5 - 1] = 5;
																										break;
																										IL_1410:
																										array3[num5 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_1439;
																									}
																									break;
																								}
																								goto IL_06e5;
																								IL_0bff:
																								ptr2 += 8;
																								break;
																								IL_06e5:
																								if (29 >= b)
																								{
																									goto IL_0b42;
																								}
																								goto IL_0cc1;
																								IL_0cc1:
																								if (31 < b)
																								{
																									goto IL_0ccc;
																								}
																								goto IL_0d47;
																								IL_0ccc:
																								if (32 < b)
																								{
																									goto IL_0cd7;
																								}
																								goto IL_0cf8;
																								IL_0cd7:
																								if (33 < b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0ce5;
																								IL_0ce5:
																								if (33 <= b)
																								{
																								}
																								goto end_IL_058c;
																								IL_0cf8:
																								if (32 > b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0d06;
																								IL_0d06:
																								((Class132)array3[num5 - 2]).int_1 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_0d34;
																								IL_0d34:
																								num5 -= 2;
																								break;
																								IL_0d47:
																								if (31 > b)
																								{
																									goto IL_0d52;
																								}
																								goto IL_0db8;
																								IL_0d52:
																								if (30 < b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0d60;
																								IL_0d60:
																								if (30 > b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0d6e;
																								IL_0d6e:
																								((delegate*<UnityEngine.Object, void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((Class132)array3[num5 - 1]);
																								goto IL_0d97;
																								IL_0d97:
																								num5--;
																								goto IL_0da5;
																								IL_0da5:
																								ptr2 += 8;
																								break;
																								IL_0db8:
																								num6 = ptr2;
																								num7 = -200;
																								num4 = 1;
																								ptr2 = num6 + num7;
																								break;
																								IL_0b42:
																								if (29 > b)
																								{
																									goto IL_0b4d;
																								}
																								goto IL_0bcb;
																								IL_0b4d:
																								if (27 < b)
																								{
																									goto IL_0b58;
																								}
																								goto IL_0b9c;
																								IL_0b58:
																								if (28 < b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0b66;
																								IL_0b66:
																								if (28 > b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0b74;
																								IL_0b74:
																								((delegate*<void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])();
																								goto IL_0b89;
																								IL_0b89:
																								ptr2 += 8;
																								break;
																								IL_0b9c:
																								if (27 > b)
																								{
																									goto IL_0baa;
																								}
																								goto IL_1171;
																								IL_0baa:
																								if (26 < b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0bb8;
																								IL_0bb8:
																								if (26 > b)
																								{
																									goto end_IL_058c;
																								}
																								goto IL_0fac;
																								IL_0fac:
																								array2[num5 - 2] = 5;
																								goto IL_0fc0;
																								IL_0fc0:
																								array3[num5 - 2] = ((delegate*<string, object, string>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
																								goto IL_1007;
																								IL_1007:
																								num5--;
																								goto IL_1015;
																								IL_1015:
																								ptr2 += 8;
																								break;
																								IL_1171:
																								((delegate*<string, void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																								goto IL_11c9;
																								IL_11c9:
																								num5--;
																								goto IL_11d7;
																								IL_11d7:
																								ptr2 += 8;
																								break;
																								IL_0bcb:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0be3;
																								IL_0be3:
																								array2[num5] = 5;
																								goto IL_0bf1;
																								IL_0bf1:
																								num5++;
																								goto IL_0bff;
																							}
																							break;
																						}
																						num = 74;
																						goto IL_05fc;
																						IL_12ad:
																						num5--;
																						break;
																						IL_10b9:
																						if (11 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_10c7;
																						IL_05fc:
																						if (17 <= b)
																						{
																							goto IL_060a;
																						}
																						goto IL_070b;
																						IL_060a:
																						array2[num5] = 5;
																						goto IL_0618;
																						IL_0618:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_065e;
																						IL_065e:
																						num5++;
																						goto IL_06f8;
																						IL_06f8:
																						ptr2 += 8;
																						break;
																						IL_070b:
																						if (8 >= b)
																						{
																							goto IL_0719;
																						}
																						goto IL_0943;
																						IL_0719:
																						if (8 > b)
																						{
																							goto IL_0727;
																						}
																						goto IL_0930;
																						IL_0727:
																						if (4 >= b)
																						{
																							goto IL_0735;
																						}
																						goto IL_07c0;
																						IL_0735:
																						if (4 > b)
																						{
																							goto IL_0743;
																						}
																						goto IL_0ec8;
																						IL_0743:
																						if (2 < b)
																						{
																							goto IL_074e;
																						}
																						goto IL_076f;
																						IL_074e:
																						if (3 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_075c;
																						IL_075c:
																						if (3 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_11ea;
																						IL_11ea:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_1213;
																						IL_1213:
																						ptr2 += 8;
																						goto IL_1221;
																						IL_1221:
																						num5--;
																						break;
																						IL_076f:
																						if (2 > b)
																						{
																							goto IL_077d;
																						}
																						goto IL_0aaf;
																						IL_077d:
																						if (1 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_078b;
																						IL_078b:
																						if (1 > b)
																						{
																							goto end_IL_058c;
																						}
																						num = 210;
																						goto IL_07a2;
																						IL_10c7:
																						if (11 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_10d5;
																						IL_07a2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0f7d;
																						IL_0f7d:
																						array2[num5] = 0;
																						goto IL_0f8b;
																						IL_0f8b:
																						num5++;
																						goto IL_0f99;
																						IL_0f99:
																						ptr2 += 8;
																						break;
																						IL_0aaf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0aef;
																						IL_0aef:
																						array2[num5 - 2] = 0;
																						goto IL_115e;
																						IL_115e:
																						num5--;
																						break;
																						IL_0ec8:
																						array2[num5] = 0;
																						goto IL_0ed6;
																						IL_0ed6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0ef9;
																						IL_0ef9:
																						array3[num5] = null;
																						goto IL_0f03;
																						IL_0f03:
																						num5++;
																						goto IL_0f11;
																						IL_0f11:
																						ptr2 += 8;
																						break;
																						IL_07c0:
																						if (6 >= b)
																						{
																							goto IL_07ce;
																						}
																						num = 216;
																						goto IL_08cf;
																						IL_07ce:
																						if (6 > b)
																						{
																							goto IL_07dc;
																						}
																						goto IL_085f;
																						IL_07dc:
																						if (5 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_07ea;
																						IL_07ea:
																						if (5 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_07f8;
																						IL_07f8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0838;
																						IL_0838:
																						array2[num5 - 2] = 0;
																						goto IL_084c;
																						IL_084c:
																						num5--;
																						break;
																						IL_085f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_089f;
																						IL_089f:
																						array2[num5 - 2] = 0;
																						goto IL_08b3;
																						IL_08b3:
																						num5--;
																						break;
																						IL_10d5:
																						array2[num5 - 2] = 0;
																						goto IL_10e9;
																						IL_08cf:
																						if (7 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_08dd;
																						IL_08dd:
																						if (7 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_08eb;
																						IL_08eb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0b08;
																						IL_0b08:
																						array2[num5 - 2] = 0;
																						goto IL_0b1c;
																						IL_0b1c:
																						num5--;
																						break;
																						IL_0930:
																						num5--;
																						break;
																						IL_0943:
																						if (12 < b)
																						{
																							goto IL_0951;
																						}
																						goto IL_0b2f;
																						IL_0951:
																						if (14 >= b)
																						{
																							goto IL_095f;
																						}
																						goto IL_0c12;
																						IL_095f:
																						if (14 <= b)
																						{
																							goto IL_096a;
																						}
																						goto IL_09b2;
																						IL_096a:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0988;
																						IL_0988:
																						ptr2 += 8;
																						goto IL_0996;
																						IL_0996:
																						num5--;
																						num = 156;
																						break;
																						IL_09b2:
																						if (13 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_09c0;
																						IL_09c0:
																						if (13 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_09ce;
																						IL_09ce:
																						array8 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_09dd;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0a85;
																						IL_10e9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_113d;
																						IL_113d:
																						num5--;
																						goto IL_114b;
																						IL_114b:
																						ptr2 += 8;
																						break;
																						IL_0a85:
																						array2[num5] = 5;
																						num = 87;
																						goto IL_0a9c;
																						IL_0a9c:
																						num5++;
																						break;
																						IL_0c12:
																						if (15 < b)
																						{
																							goto IL_0c20;
																						}
																						goto IL_0f24;
																						IL_0c20:
																						if (16 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_0c2e;
																						IL_0c2e:
																						if (16 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_0c3c;
																						IL_0c3c:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0c54;
																						IL_0c54:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_0c72;
																						IL_0c72:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0c96;
																						IL_0c96:
																						array3[num5] = array3[num5 - 1];
																						goto IL_0cae;
																						IL_0cae:
																						num5++;
																						break;
																						IL_0f24:
																						if (15 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_0f32;
																						IL_0f32:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0f5b;
																						IL_0f5b:
																						array2[num5 - 1] = 5;
																						num = 206;
																						break;
																						IL_0b2f:
																						if (12 <= b)
																						{
																							break;
																						}
																						goto IL_1028;
																						IL_1028:
																						if (10 >= b)
																						{
																							goto IL_1036;
																						}
																						goto IL_10b9;
																						IL_1036:
																						if (10 <= b)
																						{
																							goto IL_1044;
																						}
																						goto IL_1234;
																						IL_1044:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_10a6;
																						IL_10a6:
																						num5 -= 2;
																						break;
																						IL_1234:
																						if (9 < b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_1242;
																						IL_1242:
																						if (9 > b)
																						{
																							goto end_IL_058c;
																						}
																						goto IL_1250;
																						IL_1250:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 143;
																						goto IL_1299;
																						IL_1299:
																						array2[num5 - 2] = 0;
																						goto IL_12ad;
																					}
																					goto end_IL_059c;
																					continue;
																					end_IL_058c:
																					break;
																					IL_058c:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_059c:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_1462:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_09dd:
			while (true)
			{
				IL_09dd_2:
				array = new byte[4];
				while (true)
				{
					IL_09eb:
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						num = 87;
						while (true)
						{
							IL_0a9c_2:
							num5++;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_05bc_2:
									byte b = *ptr2;
									while (true)
									{
										IL_05ac_2:
										ptr2++;
										while (true)
										{
											IL_059c_2:
											if (b >= 1)
											{
												while (b <= 33)
												{
													while (true)
													{
														IL_057f_2:
														if (17 < b)
														{
															while (true)
															{
																IL_056f_2:
																if (25 >= b)
																{
																	while (true)
																	{
																		IL_055f_2:
																		if (25 > b)
																		{
																			while (true)
																			{
																				IL_054f_2:
																				if (21 >= b)
																				{
																					while (true)
																					{
																						IL_053f_2:
																						if (21 > b)
																						{
																							while (true)
																							{
																								IL_052c_2:
																								if (19 >= b)
																								{
																									num = 319;
																									while (true)
																									{
																										if (num != 319)
																										{
																											if (num != 1300)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 159:
																												goto IL_052c_2;
																											case 133:
																												goto IL_053f_2;
																											case 135:
																											case 188:
																												goto IL_054f_2;
																											case 144:
																												goto IL_055f_2;
																											case 243:
																												goto IL_056f_2;
																											case 184:
																												goto IL_057f_2;
																											case 137:
																												goto IL_058c_2;
																											case 48:
																												goto IL_059c_2;
																											case 289:
																												goto IL_05ac_2;
																											case 67:
																											case 303:
																												goto IL_05bc_2;
																											case 44:
																												goto IL_05d2_2;
																											case 28:
																												goto IL_05e0_2;
																											case 74:
																												goto IL_05fc_2;
																											case 17:
																											case 114:
																												goto IL_060a_2;
																											case 127:
																												goto IL_0618_2;
																											case 78:
																											case 141:
																												goto IL_0632_2;
																											case 162:
																												goto IL_063d_2;
																											case 8:
																												goto IL_064b_2;
																											case 183:
																												goto IL_065e_2;
																											case 214:
																												goto IL_0671_2;
																											case 187:
																												goto IL_067f_2;
																											case 68:
																											case 232:
																												goto IL_0692_2;
																											case 208:
																												goto IL_06a0_2;
																											case 148:
																												goto IL_06c4_2;
																											case 89:
																												goto IL_06d2_2;
																											case 39:
																											case 235:
																												goto IL_06e5_2;
																											case 247:
																												goto IL_06f8_2;
																											case 264:
																												goto IL_070b_2;
																											case 180:
																												goto IL_0719_2;
																											case 50:
																											case 171:
																												goto IL_0727_2;
																											case 212:
																												goto IL_0735_2;
																											case 27:
																												goto IL_0743_2;
																											case 23:
																											case 92:
																												goto IL_074e_2;
																											case 49:
																												goto IL_075c_2;
																											case 245:
																												goto IL_076f_2;
																											case 108:
																												goto IL_077d_2;
																											case 63:
																												goto IL_078b_2;
																											case 192:
																											case 210:
																												goto IL_07a2_2;
																											case 18:
																												goto IL_07c0_2;
																											case 106:
																												goto IL_07ce_2;
																											case 164:
																											case 252:
																												goto IL_07dc_2;
																											case 253:
																												goto IL_07ea_2;
																											case 177:
																											case 199:
																												goto IL_07f8_2;
																											case 91:
																												goto IL_0838_2;
																											case 248:
																												goto IL_084c_2;
																											case 201:
																											case 257:
																												goto IL_085f_2;
																											case 225:
																												goto IL_089f_2;
																											case 190:
																												goto IL_08b3_2;
																											case 216:
																											case 240:
																												goto IL_08cf_2;
																											case 136:
																												goto IL_08dd_2;
																											case 35:
																											case 66:
																												goto IL_08eb_2;
																											case 117:
																											case 175:
																												goto IL_0930_2;
																											case 79:
																												goto IL_0943_2;
																											case 112:
																											case 211:
																												goto IL_0951_2;
																											case 43:
																												goto IL_095f_2;
																											case 60:
																											case 98:
																												goto IL_096a_2;
																											case 207:
																												goto IL_0988_2;
																											case 82:
																												goto IL_0996_2;
																											case 1:
																												goto IL_09b2_2;
																											case 146:
																												goto IL_09c0_2;
																											case 249:
																											case 250:
																												goto IL_09ce_2;
																											case 166:
																												goto end_IL_1462_2;
																											case 87:
																												goto IL_0a9c_2;
																											case 83:
																											case 267:
																												goto IL_0aaf_2;
																											case 215:
																												goto IL_0aef_2;
																											case 271:
																												goto IL_0b08_2;
																											case 40:
																												goto IL_0b1c_2;
																											case 272:
																												goto IL_0b2f_2;
																											case 275:
																												goto IL_0b42_2;
																											case 65:
																											case 219:
																												goto IL_0b4d_2;
																											case 69:
																											case 113:
																												goto IL_0b58_2;
																											case 224:
																												goto IL_0b66_2;
																											case 12:
																											case 140:
																												goto IL_0b74_2;
																											case 173:
																												goto IL_0b89_2;
																											case 170:
																												goto IL_0b9c_2;
																											case 255:
																												goto IL_0baa_2;
																											case 47:
																												goto IL_0bb8_2;
																											case 109:
																											case 236:
																												goto IL_0bcb_2;
																											case 57:
																												goto IL_0be3_2;
																											case 269:
																												goto IL_0bf1_2;
																											case 239:
																												goto IL_0bff_2;
																											case 278:
																												goto IL_0c12_2;
																											case 22:
																											case 149:
																												goto IL_0c20_2;
																											case 242:
																												goto IL_0c2e_2;
																											case 234:
																											case 260:
																												goto IL_0c3c_2;
																											case 0:
																												goto IL_0c54_2;
																											case 45:
																												goto IL_0c72_2;
																											case 37:
																												goto IL_0c96_2;
																											case 64:
																												goto IL_0cae_2;
																											case 194:
																											case 279:
																												goto IL_0cc1_2;
																											case 72:
																											case 97:
																												goto IL_0ccc_2;
																											case 128:
																											case 169:
																												goto IL_0cd7_2;
																											case 262:
																												goto IL_0ce5_2;
																											case 116:
																												goto IL_0cf8_2;
																											case 34:
																											case 122:
																												goto IL_0d06_2;
																											case 85:
																												goto IL_0d34_2;
																											case 261:
																												goto IL_0d47_2;
																											case 46:
																											case 200:
																												goto IL_0d52_2;
																											case 209:
																												goto IL_0d60_2;
																											case 142:
																											case 176:
																												goto IL_0d6e_2;
																											case 13:
																												goto IL_0d97_2;
																											case 185:
																												goto IL_0da5_2;
																											case 120:
																											case 237:
																												goto IL_0db8_2;
																											case 282:
																												goto IL_0dd4_2;
																											case 196:
																											case 204:
																												goto IL_0de2_2;
																											case 259:
																												goto IL_0e0f_2;
																											case 93:
																												goto IL_0e1d_2;
																											case 147:
																												goto IL_0e2b_2;
																											case 121:
																											case 284:
																												goto IL_0e3e_2;
																											case 161:
																												goto IL_0eb5_2;
																											case 150:
																											case 288:
																												goto IL_0ec8_2;
																											case 70:
																												goto IL_0ed6_2;
																											case 218:
																												goto IL_0ef9_2;
																											case 14:
																												goto IL_0f03_2;
																											case 223:
																												goto IL_0f11_2;
																											case 290:
																												goto IL_0f24_2;
																											case 51:
																											case 104:
																												goto IL_0f32_2;
																											case 25:
																												goto IL_0f5b_2;
																											case 292:
																												goto IL_0f7d_2;
																											case 124:
																												goto IL_0f8b_2;
																											case 246:
																												goto IL_0f99_2;
																											case 32:
																											case 295:
																												goto IL_0fac_2;
																											case 195:
																												goto IL_0fc0_2;
																											case 231:
																												goto IL_1007_2;
																											case 58:
																												goto IL_1015_2;
																											case 296:
																												goto IL_1028_2;
																											case 222:
																												goto IL_1036_2;
																											case 256:
																											case 270:
																												goto IL_1044_2;
																											case 179:
																												goto IL_10a6_2;
																											case 100:
																												goto IL_10b9_2;
																											case 36:
																												goto IL_10c7_2;
																											case 129:
																											case 244:
																												goto IL_10d5_2;
																											case 115:
																												goto IL_10e9_2;
																											case 20:
																												goto IL_113d_2;
																											case 230:
																												goto IL_114b_2;
																											case 297:
																												goto IL_115e_2;
																											case 154:
																											case 299:
																												goto IL_1171_2;
																											case 178:
																											case 300:
																												goto IL_119c_2;
																											case 119:
																												goto IL_11b6_2;
																											case 305:
																												goto IL_11c9_2;
																											case 287:
																												goto IL_11d7_2;
																											case 130:
																											case 308:
																												goto IL_11ea_2;
																											case 132:
																												goto IL_1213_2;
																											case 152:
																												goto IL_1221_2;
																											case 312:
																												goto IL_1234_2;
																											case 96:
																												goto IL_1242_2;
																											case 165:
																											case 301:
																												goto IL_1250_2;
																											case 143:
																												goto IL_1299_2;
																											case 268:
																												goto IL_12ad_2;
																											case 31:
																											case 155:
																												goto IL_12cb_2;
																											case 56:
																												goto IL_12df_2;
																											case 266:
																												goto IL_1317_2;
																											case 182:
																												goto IL_132a_2;
																											case 26:
																												goto IL_1338_2;
																											case 29:
																											case 42:
																												goto IL_1343_2;
																											case 309:
																												goto IL_1381_2;
																											case 131:
																											case 228:
																												goto IL_13a2_2;
																											case 111:
																												goto IL_1400_2;
																											case 167:
																											case 205:
																												goto IL_1410_2;
																											case 274:
																												goto IL_1439_2;
																											case 5:
																											case 6:
																											case 7:
																											case 10:
																											case 16:
																											case 19:
																											case 21:
																											case 24:
																											case 33:
																											case 54:
																											case 55:
																											case 59:
																											case 71:
																											case 73:
																											case 75:
																											case 77:
																											case 90:
																											case 94:
																											case 101:
																											case 103:
																											case 105:
																											case 107:
																											case 126:
																											case 138:
																											case 145:
																											case 151:
																											case 153:
																											case 158:
																											case 160:
																											case 163:
																											case 168:
																											case 172:
																											case 181:
																											case 189:
																											case 191:
																											case 202:
																											case 203:
																											case 220:
																											case 226:
																											case 233:
																											case 238:
																											case 251:
																											case 254:
																											case 258:
																											case 263:
																											case 273:
																											case 276:
																											case 277:
																											case 280:
																											case 281:
																											case 285:
																											case 286:
																											case 293:
																											case 298:
																											case 302:
																												goto end_IL_058c_2;
																											case 2:
																											case 3:
																											case 4:
																											case 9:
																											case 15:
																											case 30:
																											case 41:
																											case 53:
																											case 61:
																											case 62:
																											case 76:
																											case 80:
																											case 84:
																											case 86:
																											case 88:
																											case 102:
																											case 110:
																											case 118:
																											case 123:
																											case 125:
																											case 134:
																											case 139:
																											case 156:
																											case 157:
																											case 174:
																											case 186:
																											case 193:
																											case 206:
																											case 213:
																											case 217:
																											case 229:
																											case 241:
																											case 291:
																											case 304:
																											case 307:
																											case 311:
																												goto end_IL_0519_2;
																											case 265:
																												ptr2 = ptr;
																												num = 86;
																												goto end_IL_0519_2;
																											case 294:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StartMenuStageComponent.getLicenseFilePort);
																												goto case 265;
																											case 52:
																												array7[0] = this;
																												num = 294;
																												goto case 294;
																											case 81:
																												array7 = new object[15];
																												goto case 52;
																											case 99:
																												array6 = new long[4];
																												goto case 81;
																											case 227:
																												array5 = new int[6];
																												num = 99;
																												goto case 99;
																											case 306:
																												array4 = new int[4];
																												goto case 227;
																											case 11:
																												array3 = new object[4];
																												goto case 306;
																											case 38:
																											case 95:
																												array2 = new byte[4];
																												goto case 11;
																											case 310:
																												num3 = num2 * 4;
																												goto case 38;
																											case 197:
																												num2 = 1;
																												goto case 310;
																											case 198:
																												goto end_IL_0a85;
																											case 221:
																											case 283:
																												return;
																											}
																											continue;
																										}
																										if (19 <= b)
																										{
																											goto IL_12cb_2;
																										}
																										goto IL_132a_2;
																										IL_1338_2:
																										if (18 > b)
																										{
																											num = 7;
																											goto end_IL_058c_2;
																										}
																										goto IL_1343_2;
																										IL_1381_2:
																										num5 -= 3;
																										break;
																										IL_1343_2:
																										((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																										goto IL_1381_2;
																										IL_12cb_2:
																										array2[num5 - 1] = 5;
																										goto IL_12df_2;
																										IL_12df_2:
																										array3[num5 - 1] = ((delegate*<string[], string>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																										goto IL_1317_2;
																										IL_1317_2:
																										ptr2 += 8;
																										break;
																										IL_132a_2:
																										if (18 < b)
																										{
																											goto end_IL_058c_2;
																										}
																										goto IL_1338_2;
																										continue;
																										end_IL_0519_2:
																										break;
																									}
																									break;
																								}
																								goto IL_05d2_2;
																								IL_06a0_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_06c4_2;
																								IL_06c4_2:
																								num5++;
																								goto IL_06d2_2;
																								IL_05d2_2:
																								if (20 < b)
																								{
																									goto end_IL_058c_2;
																								}
																								goto IL_05e0_2;
																								IL_05e0_2:
																								if (20 > b)
																								{
																									goto end_IL_058c_2;
																								}
																								num = 68;
																								goto IL_0692_2;
																								IL_06d2_2:
																								ptr2 += 8;
																								break;
																								IL_0692_2:
																								array2[num5] = 0;
																								goto IL_06a0_2;
																							}
																							break;
																						}
																						goto IL_13a2_2;
																						IL_1400_2:
																						num5--;
																						break;
																						IL_13a2_2:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1400_2;
																					}
																					break;
																				}
																				goto IL_0632_2;
																				IL_0eb5_2:
																				num5 -= 2;
																				break;
																				IL_0632_2:
																				if (23 >= b)
																				{
																					goto IL_063d_2;
																				}
																				goto IL_0671_2;
																				IL_063d_2:
																				if (23 > b)
																				{
																					goto IL_064b_2;
																				}
																				goto IL_119c_2;
																				IL_064b_2:
																				if (22 < b)
																				{
																					goto end_IL_058c_2;
																				}
																				goto IL_0dd4_2;
																				IL_0dd4_2:
																				if (22 > b)
																				{
																					goto end_IL_058c_2;
																				}
																				goto IL_0de2_2;
																				IL_0de2_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])();
																				num = 259;
																				goto IL_0e0f_2;
																				IL_0e0f_2:
																				array2[num5] = 0;
																				goto IL_0e1d_2;
																				IL_0e1d_2:
																				num5++;
																				goto IL_0e2b_2;
																				IL_0e2b_2:
																				ptr2 += 8;
																				break;
																				IL_119c_2:
																				int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																				goto IL_11b6_2;
																				IL_11b6_2:
																				num5--;
																				break;
																				IL_0671_2:
																				if (24 < b)
																				{
																					goto end_IL_058c_2;
																				}
																				goto IL_067f_2;
																				IL_067f_2:
																				if (24 > b)
																				{
																					goto end_IL_058c_2;
																				}
																				goto IL_0e3e_2;
																				IL_0e3e_2:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 161;
																				goto IL_0eb5_2;
																			}
																			break;
																		}
																		goto IL_1410_2;
																		IL_1439_2:
																		array2[num5 - 1] = 5;
																		break;
																		IL_1410_2:
																		array3[num5 - 1] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_1439_2;
																	}
																	break;
																}
																goto IL_06e5_2;
																IL_0bff_2:
																ptr2 += 8;
																break;
																IL_06e5_2:
																if (29 >= b)
																{
																	goto IL_0b42_2;
																}
																goto IL_0cc1_2;
																IL_0cc1_2:
																if (31 < b)
																{
																	goto IL_0ccc_2;
																}
																goto IL_0d47_2;
																IL_0ccc_2:
																if (32 < b)
																{
																	goto IL_0cd7_2;
																}
																goto IL_0cf8_2;
																IL_0cd7_2:
																if (33 < b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0ce5_2;
																IL_0ce5_2:
																if (33 <= b)
																{
																}
																goto end_IL_058c_2;
																IL_0cf8_2:
																if (32 > b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0d06_2;
																IL_0d06_2:
																((Class132)array3[num5 - 2]).int_1 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_0d34_2;
																IL_0d34_2:
																num5 -= 2;
																break;
																IL_0d47_2:
																if (31 > b)
																{
																	goto IL_0d52_2;
																}
																goto IL_0db8_2;
																IL_0d52_2:
																if (30 < b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0d60_2;
																IL_0d60_2:
																if (30 > b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0d6e_2;
																IL_0d6e_2:
																((delegate*<UnityEngine.Object, void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((Class132)array3[num5 - 1]);
																goto IL_0d97_2;
																IL_0d97_2:
																num5--;
																goto IL_0da5_2;
																IL_0da5_2:
																ptr2 += 8;
																break;
																IL_0db8_2:
																num6 = ptr2;
																num7 = -200;
																num4 = 1;
																ptr2 = num6 + num7;
																break;
																IL_0b42_2:
																if (29 > b)
																{
																	goto IL_0b4d_2;
																}
																goto IL_0bcb_2;
																IL_0b4d_2:
																if (27 < b)
																{
																	goto IL_0b58_2;
																}
																goto IL_0b9c_2;
																IL_0b58_2:
																if (28 < b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0b66_2;
																IL_0b66_2:
																if (28 > b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0b74_2;
																IL_0b74_2:
																((delegate*<void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])();
																goto IL_0b89_2;
																IL_0b89_2:
																ptr2 += 8;
																break;
																IL_0b9c_2:
																if (27 > b)
																{
																	goto IL_0baa_2;
																}
																goto IL_1171_2;
																IL_0baa_2:
																if (26 < b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0bb8_2;
																IL_0bb8_2:
																if (26 > b)
																{
																	goto end_IL_058c_2;
																}
																goto IL_0fac_2;
																IL_0fac_2:
																array2[num5 - 2] = 5;
																goto IL_0fc0_2;
																IL_0fc0_2:
																array3[num5 - 2] = ((delegate*<string, object, string>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], array3[num5 - 1]);
																goto IL_1007_2;
																IL_1007_2:
																num5--;
																goto IL_1015_2;
																IL_1015_2:
																ptr2 += 8;
																break;
																IL_1171_2:
																((delegate*<string, void>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																goto IL_11c9_2;
																IL_11c9_2:
																num5--;
																goto IL_11d7_2;
																IL_11d7_2:
																ptr2 += 8;
																break;
																IL_0bcb_2:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_0be3_2;
																IL_0be3_2:
																array2[num5] = 5;
																goto IL_0bf1_2;
																IL_0bf1_2:
																num5++;
																goto IL_0bff_2;
															}
															break;
														}
														num = 74;
														goto IL_05fc_2;
														IL_10d5_2:
														array2[num5 - 2] = 0;
														goto IL_10e9_2;
														IL_10e9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)GetFaultDemandedResources[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_113d_2;
														IL_05fc_2:
														if (17 <= b)
														{
															goto IL_060a_2;
														}
														goto IL_070b_2;
														IL_060a_2:
														array2[num5] = 5;
														goto IL_0618_2;
														IL_0618_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_065e_2;
														IL_065e_2:
														num5++;
														goto IL_06f8_2;
														IL_06f8_2:
														ptr2 += 8;
														break;
														IL_070b_2:
														if (8 >= b)
														{
															goto IL_0719_2;
														}
														goto IL_0943_2;
														IL_0719_2:
														if (8 > b)
														{
															goto IL_0727_2;
														}
														goto IL_0930_2;
														IL_0727_2:
														if (4 >= b)
														{
															goto IL_0735_2;
														}
														goto IL_07c0_2;
														IL_0735_2:
														if (4 > b)
														{
															goto IL_0743_2;
														}
														goto IL_0ec8_2;
														IL_0743_2:
														if (2 < b)
														{
															goto IL_074e_2;
														}
														goto IL_076f_2;
														IL_074e_2:
														if (3 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_075c_2;
														IL_075c_2:
														if (3 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_11ea_2;
														IL_11ea_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_1213_2;
														IL_1213_2:
														ptr2 += 8;
														goto IL_1221_2;
														IL_1221_2:
														num5--;
														break;
														IL_076f_2:
														if (2 > b)
														{
															goto IL_077d_2;
														}
														goto IL_0aaf_2;
														IL_077d_2:
														if (1 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_078b_2;
														IL_078b_2:
														if (1 > b)
														{
															goto end_IL_058c_2;
														}
														num = 210;
														goto IL_07a2_2;
														IL_113d_2:
														num5--;
														goto IL_114b_2;
														IL_07a2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
														goto IL_0f7d_2;
														IL_0f7d_2:
														array2[num5] = 0;
														goto IL_0f8b_2;
														IL_0f8b_2:
														num5++;
														goto IL_0f99_2;
														IL_0f99_2:
														ptr2 += 8;
														break;
														IL_0aaf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0aef_2;
														IL_0aef_2:
														array2[num5 - 2] = 0;
														goto IL_115e_2;
														IL_115e_2:
														num5--;
														break;
														IL_0ec8_2:
														array2[num5] = 0;
														goto IL_0ed6_2;
														IL_0ed6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0ef9_2;
														IL_0ef9_2:
														array3[num5] = null;
														goto IL_0f03_2;
														IL_0f03_2:
														num5++;
														goto IL_0f11_2;
														IL_0f11_2:
														ptr2 += 8;
														break;
														IL_07c0_2:
														if (6 >= b)
														{
															goto IL_07ce_2;
														}
														num = 216;
														goto IL_08cf_2;
														IL_07ce_2:
														if (6 > b)
														{
															goto IL_07dc_2;
														}
														goto IL_085f_2;
														IL_07dc_2:
														if (5 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_07ea_2;
														IL_07ea_2:
														if (5 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_07f8_2;
														IL_07f8_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0838_2;
														IL_0838_2:
														array2[num5 - 2] = 0;
														goto IL_084c_2;
														IL_084c_2:
														num5--;
														break;
														IL_085f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_089f_2;
														IL_089f_2:
														array2[num5 - 2] = 0;
														goto IL_08b3_2;
														IL_08b3_2:
														num5--;
														break;
														IL_114b_2:
														ptr2 += 8;
														break;
														IL_08cf_2:
														if (7 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_08dd_2;
														IL_08dd_2:
														if (7 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_08eb_2;
														IL_08eb_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0b08_2;
														IL_0b08_2:
														array2[num5 - 2] = 0;
														goto IL_0b1c_2;
														IL_0b1c_2:
														num5--;
														break;
														IL_0930_2:
														num5--;
														break;
														IL_0943_2:
														if (12 < b)
														{
															goto IL_0951_2;
														}
														goto IL_0b2f_2;
														IL_0951_2:
														if (14 >= b)
														{
															goto IL_095f_2;
														}
														goto IL_0c12_2;
														IL_095f_2:
														if (14 <= b)
														{
															goto IL_096a_2;
														}
														goto IL_09b2_2;
														IL_096a_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_0988_2;
														IL_0988_2:
														ptr2 += 8;
														goto IL_0996_2;
														IL_0996_2:
														num5--;
														num = 156;
														break;
														IL_09b2_2:
														if (13 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_09c0_2;
														IL_09c0_2:
														if (13 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_09ce_2;
														IL_09ce_2:
														array8 = array3;
														num8 = num5;
														if (array == null)
														{
															goto IL_09dd_2;
														}
														goto IL_09eb;
														IL_0c12_2:
														if (15 < b)
														{
															goto IL_0c20_2;
														}
														goto IL_0f24_2;
														IL_0c20_2:
														if (16 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_0c2e_2;
														IL_0c2e_2:
														if (16 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_0c3c_2;
														IL_0c3c_2:
														array2[num5] = array2[num5 - 1];
														goto IL_0c54_2;
														IL_0c54_2:
														array4[num5 - 0] = array4[num5 - 1];
														goto IL_0c72_2;
														IL_0c72_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0c96_2;
														IL_0c96_2:
														array3[num5] = array3[num5 - 1];
														goto IL_0cae_2;
														IL_0cae_2:
														num5++;
														break;
														IL_0f24_2:
														if (15 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_0f32_2;
														IL_0f32_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0f5b_2;
														IL_0f5b_2:
														array2[num5 - 1] = 5;
														num = 206;
														break;
														IL_0b2f_2:
														if (12 <= b)
														{
															break;
														}
														goto IL_1028_2;
														IL_1028_2:
														if (10 >= b)
														{
															goto IL_1036_2;
														}
														goto IL_10b9_2;
														IL_1036_2:
														if (10 <= b)
														{
															goto IL_1044_2;
														}
														goto IL_1234_2;
														IL_1044_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_10a6_2;
														IL_10a6_2:
														num5 -= 2;
														break;
														IL_1234_2:
														if (9 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_1242_2;
														IL_1242_2:
														if (9 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_1250_2;
														IL_1250_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 143;
														goto IL_1299_2;
														IL_1299_2:
														array2[num5 - 2] = 0;
														goto IL_12ad_2;
														IL_12ad_2:
														num5--;
														break;
														IL_10b9_2:
														if (11 < b)
														{
															goto end_IL_058c_2;
														}
														goto IL_10c7_2;
														IL_10c7_2:
														if (11 > b)
														{
															goto end_IL_058c_2;
														}
														goto IL_10d5_2;
													}
													goto end_IL_059c_2;
													continue;
													end_IL_058c_2:
													break;
													IL_058c_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											break;
											continue;
											end_IL_059c_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_1462_2:
								break;
							}
							break;
						}
						continue;
						end_IL_0a85:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private static int getIsEnabledTryRemoveClaim(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static double MethodAttributesSid(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static int smethod_4(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 35;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 106;
				while (true)
				{
					num = 78;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsGuestObjectEqualityComparer.NotEscapedIsHomogenous);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0356:
															byte b = *ptr2;
															while (true)
															{
																IL_0346:
																ptr2++;
																while (true)
																{
																	IL_0336:
																	if (b >= 1)
																	{
																		goto IL_01e6;
																	}
																	goto IL_0315;
																	IL_0315:
																	while (true)
																	{
																		IL_0315_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 113;
																		while (num != 113)
																		{
																			if (num != 1094)
																			{
																				goto IL_0202;
																			}
																			switch (num)
																			{
																			case 85:
																				goto IL_01e6;
																			case 5:
																				goto IL_01f4;
																			case 17:
																			case 59:
																				goto IL_0202;
																			case 25:
																				goto IL_020d;
																			case 3:
																				goto IL_021b;
																			case 12:
																				goto IL_0226;
																			case 53:
																			case 76:
																				goto IL_0239;
																			case 66:
																				goto IL_0247;
																			case 29:
																				goto IL_025a;
																			case 62:
																				goto IL_0265;
																			case 60:
																				goto IL_0278;
																			case 33:
																				goto IL_0286;
																			case 9:
																				goto IL_0296;
																			case 40:
																			case 102:
																				goto IL_02ad;
																			case 2:
																			case 79:
																				goto IL_02b8;
																			case 36:
																				goto IL_02c3;
																			case 6:
																				goto IL_02d3;
																			case 77:
																				goto IL_02de;
																			case 104:
																				goto IL_02ee;
																			case 7:
																			case 84:
																				goto IL_02fc;
																			case 28:
																				goto IL_0307;
																			case 8:
																			case 11:
																			case 13:
																			case 20:
																			case 22:
																			case 26:
																			case 32:
																			case 37:
																			case 51:
																			case 64:
																			case 67:
																			case 69:
																			case 70:
																			case 72:
																			case 87:
																			case 91:
																			case 94:
																			case 98:
																			case 100:
																			case 103:
																			case 105:
																				goto IL_0315_2;
																			case 21:
																				goto IL_0336;
																			case 75:
																				goto IL_0346;
																			case 0:
																			case 89:
																				goto IL_0356;
																			case 31:
																			case 61:
																				goto IL_0361;
																			case 55:
																				goto IL_03c3;
																			case 73:
																			case 80:
																				goto IL_03d6;
																			case 45:
																				goto IL_03f9;
																			case 52:
																				goto IL_0407;
																			case 15:
																				goto IL_0415;
																			case 39:
																			case 43:
																				goto IL_0431;
																			case 68:
																			case 90:
																				goto IL_044d;
																			case 95:
																				goto IL_048d;
																			case 83:
																				goto IL_04a1;
																			case 58:
																			case 101:
																				goto IL_04b4;
																			case 42:
																				goto IL_04c2;
																			case 81:
																				goto IL_04e5;
																			case 18:
																				goto IL_04f8;
																			case 14:
																				goto IL_0506;
																			case 71:
																			case 82:
																				goto IL_0519;
																			case 1:
																			case 44:
																				goto IL_0548;
																			case 10:
																				goto IL_0561;
																			case 38:
																				goto IL_056f;
																			case 46:
																				goto IL_057d;
																			case 19:
																			case 97:
																				goto IL_058d;
																			case 47:
																				goto IL_05b6;
																			case 23:
																				goto IL_05c4;
																			case 16:
																			case 30:
																			case 48:
																			case 49:
																			case 56:
																			case 57:
																			case 65:
																			case 74:
																			case 86:
																			case 88:
																			case 93:
																			case 96:
																				goto end_IL_01d3;
																			case 99:
																				goto end_IL_05d2;
																			case 50:
																				goto end_IL_05e5;
																			case 27:
																				goto end_IL_05ef;
																			case 4:
																				goto end_IL_05fa;
																			case 54:
																			case 63:
																				goto end_IL_060f;
																			case 24:
																				goto end_IL_061f;
																			case 78:
																				goto end_IL_062f;
																			case 106:
																				goto end_IL_063f;
																			case 34:
																				goto end_IL_064f;
																			case 35:
																				goto end_IL_065a;
																			case 41:
																			case 92:
																				goto IL_067e;
																			}
																			continue;
																			end_IL_01d3:
																			break;
																		}
																		break;
																	}
																	break;
																	IL_01e6:
																	if (b <= 10)
																	{
																		goto IL_01f4;
																	}
																	goto IL_0315;
																	IL_01f4:
																	if (5 < b)
																	{
																		goto IL_0202;
																	}
																	goto IL_0296;
																	IL_0202:
																	if (8 >= b)
																	{
																		goto IL_020d;
																	}
																	goto IL_025a;
																	IL_020d:
																	if (8 > b)
																	{
																		goto IL_021b;
																	}
																	goto IL_0361;
																	IL_021b:
																	if (6 >= b)
																	{
																		goto IL_0226;
																	}
																	goto IL_0239;
																	IL_0226:
																	if (6 > b)
																	{
																		goto IL_0315;
																	}
																	goto IL_044d;
																	IL_044d:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_048d;
																	IL_048d:
																	array[num5 - 2] = 0;
																	goto IL_04a1;
																	IL_04a1:
																	num5--;
																	break;
																	IL_0239:
																	if (7 >= b)
																	{
																		goto IL_0247;
																	}
																	goto IL_0315;
																	IL_0247:
																	if (7 > b)
																	{
																		goto IL_0315;
																	}
																	goto IL_03d6;
																	IL_03d6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_03f9;
																	IL_03f9:
																	array[num5] = 0;
																	goto IL_0407;
																	IL_0407:
																	num5++;
																	goto IL_0415;
																	IL_0415:
																	ptr2 += 8;
																	break;
																	IL_0361:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_03c3;
																	IL_03c3:
																	num5 -= 2;
																	break;
																	IL_025a:
																	if (9 >= b)
																	{
																		goto IL_0265;
																	}
																	goto IL_0278;
																	IL_0265:
																	if (9 > b)
																	{
																		goto IL_0315;
																	}
																	num = 39;
																	goto IL_0431;
																	IL_04e5:
																	array2[num5] = null;
																	num = 18;
																	goto IL_04f8;
																	IL_0431:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_0278:
																	if (10 >= b)
																	{
																		goto IL_0286;
																	}
																	goto IL_0315;
																	IL_0286:
																	if (10 > b)
																	{
																	}
																	goto IL_0315;
																	IL_0296:
																	if (5 > b)
																	{
																		num = 102;
																		goto IL_02ad;
																	}
																	goto IL_04b4;
																	IL_04f8:
																	num5++;
																	goto IL_0506;
																	IL_02ad:
																	if (2 < b)
																	{
																		goto IL_02b8;
																	}
																	goto IL_02ee;
																	IL_02b8:
																	if (3 >= b)
																	{
																		goto IL_02c3;
																	}
																	goto IL_02d3;
																	IL_02c3:
																	if (3 > b)
																	{
																		goto IL_0315;
																	}
																	goto IL_0519;
																	IL_0519:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 93;
																	break;
																	IL_02d3:
																	if (4 >= b)
																	{
																		goto IL_02de;
																	}
																	goto IL_0315;
																	IL_02de:
																	if (4 <= b)
																	{
																		num = 16;
																		break;
																	}
																	goto IL_0315;
																	IL_0506:
																	ptr2 += 8;
																	break;
																	IL_02ee:
																	if (2 > b)
																	{
																		goto IL_02fc;
																	}
																	goto IL_058d;
																	IL_02fc:
																	if (1 >= b)
																	{
																		goto IL_0307;
																	}
																	goto IL_0315;
																	IL_0307:
																	if (1 > b)
																	{
																		goto IL_0315;
																	}
																	goto IL_0548;
																	IL_0548:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0561;
																	IL_0561:
																	array[num5] = 0;
																	goto IL_056f;
																	IL_056f:
																	num5++;
																	goto IL_057d;
																	IL_057d:
																	ptr2 += 8;
																	break;
																	IL_058d:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05b6;
																	IL_05b6:
																	ptr2 += 8;
																	goto IL_05c4;
																	IL_05c4:
																	num5--;
																	break;
																	IL_04b4:
																	array[num5] = 0;
																	goto IL_04c2;
																	IL_04c2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04e5;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_067e;
													IL_067e:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05d2:
													break;
												}
												continue;
												end_IL_05e5:
												break;
											}
											continue;
											end_IL_05ef:
											break;
										}
										continue;
										end_IL_05fa:
										break;
									}
									continue;
									end_IL_060f:
									break;
								}
								continue;
								end_IL_061f:
								break;
							}
							continue;
							end_IL_062f:
							break;
						}
						continue;
						end_IL_063f:
						break;
					}
					continue;
					end_IL_064f:
					break;
				}
				continue;
				end_IL_065a:
				break;
			}
		}
	}

	private static float UserApplicationTrustsHashElementEntry()
	{
		return global::_003CModule_003E.float_96;
	}

	private static double ClipboardHijriCalendar(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static string CMSSECTIONIDCacheType(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static double IsExplicitLayoutTransliteratedEnglish(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static float CMSASSEMBLYREFERENCEFLAGFOLLOWIEnvoyInfo()
	{
		return global::_003CModule_003E.float_97;
	}

	private static int ZeroFreeGlobalAllocAnsiParallelOptions(Class132 class132_1)
	{
		return class132_1.int_1;
	}

	private static double PermitOnlySetInstanceGrovelForResourceSet(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static ControllerInputPoller ERRORREFTOINVALIDASSEMBLYgetDefaultInterface()
	{
		return ControllerInputPoller.instance;
	}

	private static int SecurityBindingRedirectsConvertTypeLibToAssembly(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private unsafe void Update()
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			num = 5;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					while (true)
					{
						if (num3 == 45)
						{
							while (true)
							{
								IL_0093:
								num3 = 0;
								num = 14;
								while (true)
								{
									if (num != 14)
									{
										if (num != 995)
										{
											break;
										}
										switch (num)
										{
										case 7:
											break;
										default:
											continue;
										case 4:
											goto IL_0093;
										case 1:
										case 2:
											goto end_IL_0086;
										case 3:
											goto end_IL_00a1;
										case 5:
											goto end_IL_00ac;
										case 6:
											goto end_IL_00b1;
										case 0:
											return;
										}
										goto IL_000e;
									}
									return;
									continue;
									end_IL_0086:
									break;
								}
								break;
							}
							continue;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, Class132, void>)ICLRSurrogateEntryITokenReader[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref num11, this);
						continue;
						end_IL_00a1:
						break;
					}
					continue;
					end_IL_00ac:
					break;
				}
				continue;
				end_IL_00b1:
				break;
			}
		}
	}

	private static float SubscribeMCMWrapperDictionary(Class132 class132_1)
	{
		return class132_1.float_0;
	}

	private static int smethod_6(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private static double CompleteOnCountdownPromiseIndexOfAny(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static float CryptoKeyAccessRulegetClaimsd(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerIndexFloat;
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 78;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 58;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									num = 34;
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getEnvoySinksSTORECATEGORYSUBCATEGORY.CodeGroupPositionMarkersetPosition);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 55;
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_01d4:
																			if (b >= 1)
																			{
																				while (b <= 8)
																				{
																					while (true)
																					{
																						if (4 >= b)
																						{
																							while (true)
																							{
																								if (4 <= b)
																								{
																									num = 93;
																									while (true)
																									{
																										if (num == 93)
																										{
																											goto IL_020a;
																										}
																										if (num != 1074)
																										{
																											goto IL_0241;
																										}
																										switch (num)
																										{
																										case 25:
																											goto end_IL_0191;
																										case 21:
																											goto end_IL_01a1;
																										case 10:
																											goto end_IL_01b4;
																										case 7:
																											goto IL_01d4;
																										case 6:
																											goto end_IL_01d4;
																										case 55:
																											goto end_IL_01e4;
																										case 76:
																											goto end_IL_01f4;
																										case 15:
																											goto IL_020a;
																										case 81:
																											goto IL_0233;
																										case 67:
																											goto IL_0241;
																										case 79:
																											goto IL_0254;
																										case 45:
																											goto IL_0262;
																										case 1:
																										case 18:
																											goto IL_0270;
																										case 37:
																											goto IL_02de;
																										case 47:
																											goto IL_02f1;
																										case 59:
																											goto IL_02ff;
																										case 38:
																											goto IL_0312;
																										case 50:
																											goto IL_0320;
																										case 12:
																										case 74:
																											goto IL_032e;
																										case 68:
																											goto IL_036e;
																										case 41:
																											goto IL_038b;
																										case 80:
																											goto IL_03a7;
																										case 5:
																										case 13:
																											goto IL_03b5;
																										case 51:
																										case 73:
																											goto IL_03c0;
																										case 57:
																											goto IL_03ce;
																										case 8:
																										case 29:
																											goto IL_03d9;
																										case 0:
																											goto IL_0403;
																										case 60:
																										case 82:
																											goto IL_0411;
																										case 65:
																											goto IL_041f;
																										case 11:
																											goto IL_0442;
																										case 48:
																											goto IL_044c;
																										case 20:
																											goto IL_045a;
																										case 71:
																											goto IL_046d;
																										case 42:
																											goto IL_047b;
																										case 27:
																											goto IL_0486;
																										case 24:
																										case 52:
																											goto IL_0491;
																										case 2:
																										case 3:
																										case 9:
																										case 14:
																										case 22:
																										case 23:
																										case 26:
																										case 28:
																										case 46:
																										case 53:
																										case 56:
																										case 66:
																										case 70:
																										case 72:
																										case 75:
																										case 83:
																											goto end_IL_01c4;
																										case 36:
																											goto IL_04d2;
																										case 85:
																											goto IL_04e0;
																										case 62:
																											goto IL_04ee;
																										case 16:
																										case 17:
																										case 19:
																										case 30:
																										case 32:
																										case 39:
																										case 40:
																										case 49:
																										case 61:
																										case 63:
																										case 84:
																											goto end_IL_01ff;
																										case 43:
																											goto end_IL_04fc;
																										case 69:
																											goto end_IL_050f;
																										case 35:
																											goto end_IL_0519;
																										case 34:
																											goto end_IL_0524;
																										case 31:
																											goto end_IL_0539;
																										case 58:
																											goto end_IL_054e;
																										case 33:
																											goto end_IL_0567;
																										case 86:
																											goto end_IL_0577;
																										case 54:
																										case 64:
																											goto end_IL_0582;
																										case 77:
																											goto end_IL_0592;
																										case 78:
																											goto end_IL_05a2;
																										case 4:
																										case 44:
																											goto IL_05bd;
																										}
																										continue;
																										IL_0233:
																										ptr2 += 8;
																										goto IL_0241;
																										IL_0241:
																										num5--;
																										goto end_IL_01ff;
																										IL_020a:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0233;
																										continue;
																										end_IL_0191:
																										break;
																									}
																									continue;
																								}
																								goto IL_0254;
																								IL_036e:
																								array[num5 - 2] = 0;
																								num = 41;
																								goto IL_038b;
																								IL_038b:
																								num5--;
																								num = 17;
																								goto end_IL_01ff;
																								IL_0254:
																								if (2 >= b)
																								{
																									goto IL_0262;
																								}
																								goto IL_0312;
																								IL_0262:
																								if (2 <= b)
																								{
																									goto IL_0270;
																								}
																								goto IL_02f1;
																								IL_0270:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_02de;
																								IL_02de:
																								num5 -= 2;
																								goto end_IL_01ff;
																								IL_02f1:
																								if (1 < b)
																								{
																									goto end_IL_01c4;
																								}
																								goto IL_02ff;
																								IL_02ff:
																								if (1 > b)
																								{
																								}
																								goto end_IL_01c4;
																								IL_0312:
																								if (3 < b)
																								{
																									goto end_IL_01c4;
																								}
																								goto IL_0320;
																								IL_0320:
																								if (3 > b)
																								{
																									goto end_IL_01c4;
																								}
																								goto IL_032e;
																								IL_032e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_036e;
																								continue;
																								end_IL_01a1:
																								break;
																							}
																							continue;
																						}
																						goto IL_03a7;
																						IL_0486:
																						if (5 > b)
																						{
																							num = 53;
																							goto end_IL_01c4;
																						}
																						goto IL_0491;
																						IL_03a7:
																						if (6 < b)
																						{
																							goto IL_03b5;
																						}
																						goto IL_046d;
																						IL_03b5:
																						if (7 < b)
																						{
																							goto IL_03c0;
																						}
																						goto IL_0403;
																						IL_03c0:
																						if (8 < b)
																						{
																							goto end_IL_01c4;
																						}
																						goto IL_03ce;
																						IL_03ce:
																						if (8 > b)
																						{
																							num = 83;
																							goto end_IL_01c4;
																						}
																						goto IL_03d9;
																						IL_03d9:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_01ff;
																						IL_0491:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_01ff;
																						IL_0403:
																						if (7 > b)
																						{
																							goto end_IL_01c4;
																						}
																						goto IL_0411;
																						IL_0411:
																						array[num5] = 0;
																						goto IL_041f;
																						IL_041f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0442;
																						IL_0442:
																						array2[num5] = null;
																						goto IL_044c;
																						IL_044c:
																						num5++;
																						goto IL_045a;
																						IL_045a:
																						ptr2 += 8;
																						goto end_IL_01ff;
																						IL_046d:
																						if (6 <= b)
																						{
																							goto end_IL_01ff;
																						}
																						goto IL_047b;
																						IL_047b:
																						if (5 < b)
																						{
																							goto end_IL_01c4;
																						}
																						goto IL_0486;
																						continue;
																						end_IL_01b4:
																						break;
																					}
																					continue;
																					end_IL_01c4:
																					break;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04d2;
																			IL_04ee:
																			ptr2 += 8;
																			goto end_IL_01ff;
																			IL_04e0:
																			num5++;
																			goto IL_04ee;
																			IL_04d2:
																			array[num5] = 0;
																			goto IL_04e0;
																			continue;
																			end_IL_01d4:
																			break;
																		}
																		continue;
																		end_IL_01e4:
																		break;
																	}
																	continue;
																	end_IL_01f4:
																	break;
																}
																continue;
																end_IL_01ff:
																break;
															}
															continue;
														}
														goto IL_05bd;
														IL_05bd:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04fc:
														break;
													}
													continue;
													end_IL_050f:
													break;
												}
												continue;
												end_IL_0519:
												break;
											}
											continue;
											end_IL_0524:
											break;
										}
										continue;
										end_IL_0539:
										break;
									}
									continue;
									end_IL_054e:
									break;
								}
								continue;
								end_IL_0567:
								break;
							}
							continue;
							end_IL_0577:
							break;
						}
						continue;
						end_IL_0582:
						break;
					}
					continue;
					end_IL_0592:
					break;
				}
				continue;
				end_IL_05a2:
				break;
			}
		}
	}

	private static double PinnableBufferCacheExclusiveScheduler(double double_1)
	{
		return Math.Log(double_1);
	}

	private static int OpenPunctuationgetPrincipal(int int_3, int int_4, int int_5)
	{
		return Mathf.Clamp(int_3, int_4, int_5);
	}

	private static int TrueLinux()
	{
		return int_0;
	}

	private static float LoadFileContinuationResultTaskFromResultTask(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerIndexFloat;
	}

	private static float ReduceNotImpersonated()
	{
		return Time.time;
	}

	private unsafe static int smethod_8()
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 123;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								IL_08e5:
								long[] array4 = new long[4];
								while (true)
								{
									IL_08d5:
									object[] array5 = new object[1];
									while (true)
									{
										IL_08ca:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAsyncStatesetUsageAllowed.RemotingXmlConfigFileDataSEPMinuteSuff);
										while (true)
										{
											IL_08c0:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_08ad:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0342:
														byte b = *ptr2;
														while (true)
														{
															IL_0329:
															ptr2++;
															num = 2;
															while (true)
															{
																IL_0319:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02fc:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02ec:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02dc:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02c9:
																									if (6 < b)
																									{
																										num = 133;
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												num = 154;
																												while (true)
																												{
																													if (num != 154)
																													{
																														if (num != 1135)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 28:
																															goto IL_02a6;
																														case 20:
																														case 133:
																															goto IL_02b9;
																														case 39:
																														case 71:
																															goto IL_02c9;
																														case 62:
																														case 87:
																															goto IL_02dc;
																														case 136:
																															goto IL_02ec;
																														case 122:
																															goto IL_02fc;
																														case 50:
																															goto IL_0309;
																														case 2:
																															goto IL_0319;
																														case 80:
																															goto IL_0329;
																														case 57:
																														case 119:
																															goto IL_0342;
																														case 11:
																														case 83:
																															goto IL_034d;
																														case 63:
																															goto IL_0358;
																														case 35:
																														case 77:
																															goto IL_0363;
																														case 68:
																															goto IL_03a3;
																														case 93:
																															goto IL_03c7;
																														case 9:
																															goto IL_03d5;
																														case 79:
																															goto IL_03e3;
																														case 4:
																															goto IL_03f1;
																														case 105:
																															goto IL_0404;
																														case 109:
																															goto IL_0417;
																														case 97:
																														case 99:
																															goto IL_0425;
																														case 94:
																														case 112:
																															goto IL_0469;
																														case 110:
																															goto IL_0477;
																														case 49:
																														case 114:
																															goto IL_0485;
																														case 7:
																															goto IL_04c9;
																														case 3:
																															goto IL_04dd;
																														case 135:
																															goto IL_04f0;
																														case 31:
																															goto IL_04fe;
																														case 53:
																														case 76:
																															goto IL_050c;
																														case 108:
																															goto IL_051a;
																														case 116:
																															goto IL_0532;
																														case 26:
																															goto IL_0540;
																														case 134:
																														case 140:
																															goto IL_0553;
																														case 1:
																															goto IL_0561;
																														case 25:
																															goto IL_0584;
																														case 14:
																															goto IL_058e;
																														case 54:
																															goto IL_059c;
																														case 144:
																															goto IL_05af;
																														case 86:
																														case 145:
																															goto IL_05c2;
																														case 45:
																															goto IL_05d0;
																														case 33:
																														case 38:
																															goto IL_05db;
																														case 102:
																														case 121:
																															goto IL_0600;
																														case 78:
																															goto IL_060e;
																														case 19:
																														case 36:
																															goto IL_061c;
																														case 52:
																															goto IL_067e;
																														case 146:
																															goto IL_0691;
																														case 81:
																															goto IL_069f;
																														case 46:
																															goto IL_06b2;
																														case 17:
																															goto IL_06db;
																														case 95:
																															goto IL_06e9;
																														case 129:
																															goto IL_06fc;
																														case 130:
																														case 142:
																															goto IL_0707;
																														case 92:
																															goto IL_0725;
																														case 84:
																															goto IL_0733;
																														case 42:
																															goto IL_0746;
																														case 125:
																															goto IL_0754;
																														case 34:
																														case 66:
																															goto IL_075f;
																														case 91:
																															goto IL_076d;
																														case 6:
																														case 73:
																															goto IL_077b;
																														case 98:
																															goto IL_0794;
																														case 64:
																															goto IL_07a2;
																														case 43:
																															goto IL_07b0;
																														case 37:
																														case 104:
																															goto IL_07c3;
																														case 69:
																															goto IL_080c;
																														case 30:
																															goto IL_0820;
																														case 139:
																															goto IL_0830;
																														case 124:
																															goto IL_083b;
																														case 131:
																														case 143:
																															goto IL_0846;
																														case 101:
																															goto IL_086f;
																														case 8:
																														case 75:
																															goto IL_0885;
																														case 0:
																														case 10:
																														case 15:
																														case 18:
																														case 21:
																														case 23:
																														case 27:
																														case 29:
																														case 47:
																														case 51:
																														case 55:
																														case 58:
																														case 59:
																														case 60:
																														case 65:
																														case 70:
																														case 72:
																														case 74:
																														case 82:
																														case 88:
																														case 89:
																														case 106:
																														case 117:
																														case 118:
																														case 126:
																														case 138:
																															goto end_IL_02a6;
																														case 12:
																														case 13:
																														case 16:
																														case 22:
																														case 44:
																														case 48:
																														case 56:
																														case 61:
																														case 67:
																														case 85:
																														case 96:
																														case 103:
																														case 107:
																														case 127:
																														case 128:
																														case 137:
																														case 141:
																														case 147:
																															goto IL_08ad;
																														case 120:
																															goto IL_08c0;
																														case 132:
																															goto IL_08ca;
																														case 90:
																															goto IL_08d5;
																														case 113:
																															goto IL_08e5;
																														case 5:
																														case 24:
																															goto end_IL_0293;
																														case 111:
																															goto end_IL_08f5;
																														case 115:
																														case 123:
																															goto end_IL_0905;
																														case 40:
																															goto end_IL_0915;
																														case 41:
																															goto end_IL_0925;
																														case 32:
																														case 100:
																															goto IL_0949;
																														}
																														continue;
																													}
																													goto IL_06b2;
																													IL_06db:
																													ptr2 += 8;
																													goto IL_06e9;
																													IL_06e9:
																													num5--;
																													goto IL_08ad;
																													IL_06b2:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_06db;
																													continue;
																													end_IL_0293:
																													break;
																												}
																												goto end_IL_0319;
																												continue;
																												end_IL_02a6:
																												break;
																												IL_02a6:;
																											}
																											break;
																											IL_02b9:;
																										}
																										break;
																									}
																									goto IL_0417;
																									IL_0532:
																									num5++;
																									goto IL_0540;
																									IL_0540:
																									ptr2 += 8;
																									goto IL_08ad;
																									IL_0417:
																									if (6 <= b)
																									{
																										goto IL_0425;
																									}
																									goto IL_04f0;
																									IL_0425:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05af;
																									IL_05af:
																									num5 -= 3;
																									goto IL_08ad;
																									IL_04f0:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_04fe;
																									IL_04fe:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_050c;
																									IL_050c:
																									array[num5] = 5;
																									goto IL_051a;
																									IL_051a:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0532;
																								}
																								break;
																							}
																							goto IL_06fc;
																							IL_086f:
																							array[num5 - 1] = 5;
																							goto IL_08ad;
																							IL_06fc:
																							if (4 <= b)
																							{
																								goto IL_0707;
																							}
																							goto IL_0746;
																							IL_0707:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0725;
																							IL_0725:
																							ptr2 += 8;
																							goto IL_0733;
																							IL_0733:
																							num5--;
																							goto IL_08ad;
																							IL_0746:
																							if (2 >= b)
																							{
																								goto IL_0754;
																							}
																							goto IL_0830;
																							IL_0754:
																							if (2 > b)
																							{
																								goto IL_075f;
																							}
																							goto IL_07c3;
																							IL_075f:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_076d;
																							IL_076d:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_077b;
																							IL_077b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0794;
																							IL_0794:
																							array[num5] = 0;
																							goto IL_07a2;
																							IL_07a2:
																							num5++;
																							goto IL_07b0;
																							IL_07b0:
																							ptr2 += 8;
																							goto IL_08ad;
																							IL_07c3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 69;
																							goto IL_080c;
																							IL_080c:
																							array[num5 - 2] = 0;
																							goto IL_0820;
																							IL_0820:
																							num5--;
																							goto IL_08ad;
																							IL_0830:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_083b;
																							IL_083b:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0846;
																							IL_0846:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_086f;
																						}
																						break;
																					}
																					goto IL_0885;
																					IL_0885:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_08ad;
																				}
																				break;
																			}
																			goto IL_034d;
																			IL_067e:
																			num5 -= 2;
																			goto IL_08ad;
																			IL_034d:
																			if (12 >= b)
																			{
																				goto IL_0358;
																			}
																			num = 145;
																			goto IL_05c2;
																			IL_0358:
																			if (12 <= b)
																			{
																				goto IL_0363;
																			}
																			goto IL_03c7;
																			IL_0363:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03a3;
																			IL_03a3:
																			array[num5 - 2] = 0;
																			goto IL_0404;
																			IL_0404:
																			num5--;
																			goto IL_08ad;
																			IL_03c7:
																			if (10 >= b)
																			{
																				goto IL_03d5;
																			}
																			goto IL_0469;
																			IL_03d5:
																			if (10 > b)
																			{
																				goto IL_03e3;
																			}
																			goto IL_0553;
																			IL_03e3:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_03f1;
																			IL_03f1:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_08ad;
																			IL_0553:
																			array[num5] = 0;
																			goto IL_0561;
																			IL_0561:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0584;
																			IL_0584:
																			array2[num5] = null;
																			goto IL_058e;
																			IL_058e:
																			num5++;
																			goto IL_059c;
																			IL_059c:
																			ptr2 += 8;
																			goto IL_08ad;
																			IL_0469:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0477;
																			IL_0477:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0485;
																			IL_0485:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04c9;
																			IL_04c9:
																			array[num5 - 2] = 0;
																			goto IL_04dd;
																			IL_04dd:
																			num5--;
																			goto IL_08ad;
																			IL_0691:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_069f;
																			IL_05c2:
																			if (14 >= b)
																			{
																				goto IL_05d0;
																			}
																			goto IL_0691;
																			IL_05d0:
																			if (14 <= b)
																			{
																				goto IL_05db;
																			}
																			num = 121;
																			goto IL_0600;
																			IL_05db:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_08ad;
																			IL_069f:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_0600:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_060e;
																			IL_060e:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_061c;
																			IL_061c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_067e;
																		}
																		break;
																		IL_0309:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_08ad;
																continue;
																end_IL_0319:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0949;
												IL_0949:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_08f5:
							break;
						}
						continue;
						end_IL_0905:
						break;
					}
					continue;
					end_IL_0915:
					break;
				}
				continue;
				end_IL_0925:
				break;
			}
		}
	}
}
