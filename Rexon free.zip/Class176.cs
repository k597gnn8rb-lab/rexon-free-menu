using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Disable Others Rig Lerping", "Rig", "Remove rig interpolation on others.", false, 50, ModType.const_0, false)]
internal class Class176 : MonoBehaviour
{
	private static double double_0;

	private static int int_0;

	private static double double_1;

	private static float float_0;

	private static double double_2;

	private static int int_1;

	private static bool bool_0;

	private static IntPtr[] FreeHStringFieldAccessMask;

	private static IntPtr[] intptr_0;

	private static IntPtr[] getCharCapacityGetCelestialStem;

	private static IntPtr[] StartNoGCRegionStatusDESCKINDIMPLICITAPPOBJ;

	private static bool SizeParamIndexEmptyReadOnlyDictionaryInternal(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static bool getTypeNameConverterSurrogateSelector(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetTypeFindMethod.TgetIsValueCreated);
											while (true)
											{
												IL_0757:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_0744:
													if (num4 != 1)
													{
														while (true)
														{
															IL_02c5:
															byte b = *ptr2;
															while (true)
															{
																IL_02b5:
																ptr2++;
																while (true)
																{
																	IL_02a5:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0285:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0275:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0262:
																								if (9 > b)
																								{
																									num = 19;
																									while (true)
																									{
																										IL_0252:
																										if (7 < b)
																										{
																											num = 133;
																											while (true)
																											{
																												if (num != 133)
																												{
																													if (num != 1114)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 19:
																													case 54:
																														goto IL_0252;
																													case 115:
																														goto IL_0262;
																													case 33:
																													case 35:
																														goto IL_0275;
																													case 111:
																														goto IL_0285;
																													case 17:
																														goto IL_0295;
																													case 72:
																														goto IL_02a5;
																													case 31:
																														goto IL_02b5;
																													case 9:
																													case 101:
																														goto IL_02c5;
																													case 15:
																														goto IL_02d0;
																													case 48:
																													case 69:
																														goto IL_02de;
																													case 56:
																														goto IL_02ec;
																													case 88:
																														goto IL_030f;
																													case 38:
																														goto IL_0319;
																													case 91:
																														goto IL_0327;
																													case 60:
																													case 122:
																														goto IL_033a;
																													case 65:
																														goto IL_037a;
																													case 124:
																														goto IL_038e;
																													case 90:
																														goto IL_03a1;
																													case 110:
																														goto IL_03af;
																													case 51:
																													case 108:
																														goto IL_03bd;
																													case 92:
																														goto IL_03d6;
																													case 100:
																														goto IL_03e4;
																													case 23:
																														goto IL_03f2;
																													case 102:
																														goto IL_040e;
																													case 11:
																													case 125:
																														goto IL_0419;
																													case 109:
																														goto IL_0427;
																													case 18:
																													case 99:
																														goto IL_0435;
																													case 7:
																														goto IL_0451;
																													case 3:
																													case 47:
																														goto IL_045c;
																													case 70:
																														goto IL_046f;
																													case 103:
																														goto IL_047d;
																													case 52:
																													case 64:
																														goto IL_048b;
																													case 95:
																														goto IL_049f;
																													case 62:
																														goto IL_04f3;
																													case 43:
																														goto IL_050a;
																													case 97:
																														goto IL_051d;
																													case 118:
																														goto IL_052b;
																													case 42:
																														goto IL_0539;
																													case 75:
																													case 112:
																														goto IL_0547;
																													case 30:
																													case 87:
																														goto IL_0555;
																													case 107:
																														goto IL_0563;
																													case 29:
																													case 45:
																														goto IL_0571;
																													case 49:
																														goto IL_05df;
																													case 82:
																														goto IL_05f2;
																													case 22:
																													case 24:
																														goto IL_0605;
																													case 57:
																														goto IL_0645;
																													case 27:
																														goto IL_0659;
																													case 46:
																														goto IL_066c;
																													case 106:
																													case 123:
																														goto IL_0677;
																													case 59:
																														goto IL_0682;
																													case 68:
																													case 126:
																														goto IL_068d;
																													case 74:
																														goto IL_06a5;
																													case 80:
																													case 104:
																														goto IL_06b0;
																													case 93:
																														goto IL_06d9;
																													case 81:
																														goto IL_06e7;
																													case 1:
																													case 2:
																													case 8:
																													case 10:
																													case 13:
																													case 20:
																													case 21:
																													case 26:
																													case 28:
																													case 34:
																													case 41:
																													case 44:
																													case 58:
																													case 61:
																													case 67:
																													case 76:
																													case 77:
																													case 78:
																													case 96:
																													case 98:
																													case 105:
																													case 113:
																													case 119:
																														goto end_IL_0295;
																													case 114:
																														goto IL_071a;
																													case 63:
																														goto IL_0728;
																													case 16:
																														goto IL_0736;
																													case 0:
																													case 5:
																													case 12:
																													case 14:
																													case 25:
																													case 32:
																													case 36:
																													case 50:
																													case 55:
																													case 71:
																													case 73:
																													case 79:
																													case 86:
																													case 89:
																													case 117:
																														goto IL_0744;
																													case 53:
																														goto IL_0757;
																													case 39:
																														goto end_IL_023f;
																													case 85:
																														goto end_IL_0761;
																													case 120:
																														goto end_IL_076c;
																													case 40:
																														goto end_IL_0781;
																													case 37:
																													case 116:
																														goto end_IL_0796;
																													case 6:
																														goto end_IL_07a6;
																													case 4:
																													case 121:
																														goto end_IL_07b6;
																													case 83:
																														goto end_IL_07c6;
																													case 84:
																														goto end_IL_07d6;
																													case 66:
																													case 94:
																														goto IL_07f1;
																													}
																													continue;
																												}
																												goto IL_03a1;
																												IL_03e4:
																												num5++;
																												goto IL_03f2;
																												IL_03f2:
																												ptr2 += 8;
																												num = 32;
																												goto IL_0744;
																												IL_03a1:
																												if (8 < b)
																												{
																													goto end_IL_0295;
																												}
																												goto IL_03af;
																												IL_03af:
																												if (8 > b)
																												{
																													goto end_IL_0295;
																												}
																												goto IL_03bd;
																												IL_03bd:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_03d6;
																												IL_03d6:
																												array[num5] = 0;
																												goto IL_03e4;
																												continue;
																												end_IL_023f:
																												break;
																											}
																											break;
																										}
																										goto IL_02d0;
																										IL_0319:
																										num5++;
																										goto IL_0327;
																										IL_0327:
																										ptr2 += 8;
																										goto IL_0744;
																										IL_02d0:
																										if (7 > b)
																										{
																											goto end_IL_0295;
																										}
																										goto IL_02de;
																										IL_02de:
																										array[num5] = 0;
																										goto IL_02ec;
																										IL_02ec:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_030f;
																										IL_030f:
																										array2[num5] = null;
																										goto IL_0319;
																									}
																									break;
																								}
																								goto IL_033a;
																								IL_037a:
																								array[num5 - 2] = 0;
																								goto IL_038e;
																								IL_038e:
																								num5--;
																								goto IL_0744;
																								IL_033a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_037a;
																							}
																							break;
																						}
																						goto IL_040e;
																						IL_050a:
																						ptr2 += 8;
																						goto IL_0744;
																						IL_040e:
																						if (11 < b)
																						{
																							goto IL_0419;
																						}
																						goto IL_0451;
																						IL_0419:
																						if (12 < b)
																						{
																							goto end_IL_0295;
																						}
																						goto IL_0427;
																						IL_0427:
																						if (12 > b)
																						{
																							goto end_IL_0295;
																						}
																						goto IL_0435;
																						IL_0435:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto IL_0744;
																						IL_0451:
																						if (11 <= b)
																						{
																							goto IL_045c;
																						}
																						goto IL_046f;
																						IL_045c:
																						num5--;
																						goto IL_0744;
																						IL_046f:
																						if (10 < b)
																						{
																							goto end_IL_0295;
																						}
																						goto IL_047d;
																						IL_047d:
																						if (10 > b)
																						{
																							goto end_IL_0295;
																						}
																						goto IL_048b;
																						IL_048b:
																						array[num5 - 2] = 0;
																						goto IL_049f;
																						IL_049f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getCharCapacityGetCelestialStem[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_04f3;
																						IL_04f3:
																						num5--;
																						num = 43;
																						goto IL_050a;
																					}
																					break;
																				}
																				goto IL_051d;
																				IL_06e7:
																				num5--;
																				goto IL_0744;
																				IL_051d:
																				if (6 <= b)
																				{
																					goto IL_0744;
																				}
																				goto IL_052b;
																				IL_052b:
																				if (3 >= b)
																				{
																					goto IL_0539;
																				}
																				goto IL_066c;
																				IL_0539:
																				if (3 > b)
																				{
																					goto IL_0547;
																				}
																				goto IL_0605;
																				IL_0547:
																				if (1 < b)
																				{
																					goto IL_0555;
																				}
																				goto IL_05f2;
																				IL_0555:
																				if (2 < b)
																				{
																					goto end_IL_0295;
																				}
																				goto IL_0563;
																				IL_0563:
																				if (2 > b)
																				{
																					goto end_IL_0295;
																				}
																				goto IL_0571;
																				IL_0571:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05df;
																				IL_05df:
																				num5 -= 2;
																				goto IL_0744;
																				IL_05f2:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0295;
																				IL_0605:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0645;
																				IL_0645:
																				array[num5 - 2] = 0;
																				goto IL_0659;
																				IL_0659:
																				num5--;
																				goto IL_0744;
																				IL_066c:
																				if (4 < b)
																				{
																					goto IL_0677;
																				}
																				goto IL_06a5;
																				IL_0677:
																				if (5 < b)
																				{
																					goto end_IL_0295;
																				}
																				goto IL_0682;
																				IL_0682:
																				if (5 > b)
																				{
																					goto end_IL_0295;
																				}
																				goto IL_068d;
																				IL_068d:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0744;
																				IL_06a5:
																				if (4 > b)
																				{
																					goto end_IL_0295;
																				}
																				goto IL_06b0;
																				IL_06b0:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06d9;
																				IL_06d9:
																				ptr2 += 8;
																				goto IL_06e7;
																			}
																			goto end_IL_02a5;
																			continue;
																			end_IL_0295:
																			break;
																			IL_0295:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_071a;
																	IL_0736:
																	ptr2 += 8;
																	goto IL_0744;
																	IL_0728:
																	num5++;
																	goto IL_0736;
																	IL_071a:
																	array[num5] = 0;
																	goto IL_0728;
																	continue;
																	end_IL_02a5:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_07f1;
													IL_07f1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											continue;
											end_IL_0761:
											break;
										}
										continue;
										end_IL_076c:
										break;
									}
									continue;
									end_IL_0781:
									break;
								}
								continue;
								end_IL_0796:
								break;
							}
							continue;
							end_IL_07a6:
							break;
						}
						continue;
						end_IL_07b6:
						break;
					}
					continue;
					end_IL_07c6:
					break;
				}
				continue;
				end_IL_07d6:
				break;
			}
		}
	}

	private static IEnumerator<VRRig> ResolveMethodHandleOpcodes(IEnumerable<VRRig> ienumerable_0)
	{
		return ienumerable_0.GetEnumerator();
	}

	private unsafe void method_0()
	{
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DangerousGetHandlesetDenySetInstance.CgtTraceLoggingTypeInfo);
		int num = 4;
		int num2 = 17;
		int num3 = 17;
		num3 = 17;
		int try0016_dispatch = -1;
		object[] array = default(object[]);
		Type[] array2 = default(Type[]);
		RuntimeTypeHandle[] array3 = default(RuntimeTypeHandle[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		int num31 = default(int);
		VRRig vRRig = default(VRRig);
		IEnumerator<VRRig> enumerator = default(IEnumerator<VRRig>);
		VRRig vRRig2 = default(VRRig);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0016_dispatch)
				{
				case 2323:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 160 + num8 * 56 + 48 + num);
							num10 = *(int*)(ptr + 160 + num8 * 56 + 8 + num);
							if (num5 < num9 + num10)
							{
								if (num9 <= num5)
								{
									break;
								}
								num7 = num8 - 1;
							}
							else
							{
								num6 = num8 + 1;
							}
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 160 + num11 * 56 + 24 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array != null)
							{
								if ((int)array[7] == 1)
								{
									int num15 = (int)array[3];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 56 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 328 + num8 * 72 + 64 + num);
											num6 = *(int*)(ptr + 328 + num8 * 72 + 16 + num);
											if (num17 < num7 + num6)
											{
												if (num7 <= num17)
												{
													break;
												}
												num9 = num8 - 1;
											}
											else
											{
												num10 = num8 + 1;
											}
										}
										num12 = num8;
										num11 = *(int*)(ptr + 328 + num12 * 72 + 32 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array = (object[])array[1];
										continue;
									}
								}
								else
								{
									int num18 = (int)array[5];
									if (num18 != 1 && num18 != 2 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array[3];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 56 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 328 + num8 * 72 + 64 + num);
											num10 = *(int*)(ptr + 328 + num8 * 72 + 16 + num);
											if (num5 < num9 + num10)
											{
												if (num9 <= num5)
												{
													break;
												}
												num7 = num8 - 1;
											}
											else
											{
												num6 = num8 + 1;
											}
										}
										num11 = num8;
										num12 = *(int*)(ptr + 328 + num11 * 72 + 32 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array = (object[])array[1];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_0926;
							}
							num21 = *(int*)(ptr + num13 + 16 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 16 + num);
								if (4 != num7)
								{
									goto IL_086e;
								}
								num6 = *(int*)(ptr + num5 + 32 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array3[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 8 + num);
										continue;
									}
								}
								goto IL_09b3;
							}
							num13 = *(int*)(ptr + num13 + 80 + num);
							continue;
							IL_086e:
							if (1 != num7)
							{
								num13 = *(int*)(ptr + num13 + 80 + num);
								continue;
							}
							goto IL_095d;
						}
						object[] array4 = array;
						num4 = *(int*)(ptr + (int)array4[3] + 8 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 16 + num);
							if (4 != num21)
							{
								goto IL_05af;
							}
							num13 = *(int*)(ptr + num4 + 32 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array3[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[0]))
								{
									num4 = *(int*)(ptr + num4 + 8 + num);
									continue;
								}
							}
							goto IL_0b3a;
						}
						goto IL_05b7;
						IL_05b7:
						array = (object[])array[1];
						ex = (Exception)array4[0];
						num22 = (int)array4[2];
						continue;
						IL_09b3:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 64 + num) + 80 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 40 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 80 + num);
									continue;
								}
								array4 = new object[8];
								array4[7] = 0;
								array4[1] = array;
								array4[0] = ex;
								array4[2] = num14;
								array4[3] = num8;
								array4[4] = num17;
								array4[5] = 2;
								array = array4;
								num2 = *(int*)(ptr + num8 + 48 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[7] = 0;
							array4[1] = array;
							array4[0] = ex;
							array4[2] = num14;
							array4[3] = num17;
							array4[5] = 1;
							array = array4;
							num2 = *(int*)(ptr + num17 + 48 + num);
							break;
						}
						break;
						IL_0b3a:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 64 + num) + 80 + num);
						num14 = (int)array4[2];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 40 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 80 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 48 + num);
								array = (object[])array[1];
								array5 = new object[8];
								array5[7] = 0;
								array5[1] = array;
								array5[0] = array4[0];
								array5[2] = (int)array4[2];
								array5[3] = num18;
								array5[4] = num12;
								array5[5] = 2;
								array = array5;
								num2 = *(int*)(ptr + num18 + 48 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 48 + num);
							ex2 = (Exception)array4[0];
							array = (object[])array[1];
							array5 = new object[8];
							array5[7] = 0;
							array5[1] = array;
							array5[0] = array4[0];
							array5[2] = (int)array4[2];
							array5[3] = num12;
							array5[5] = 1;
							array = array5;
							num2 = *(int*)(ptr + num12 + 48 + num);
							break;
						}
						break;
						IL_095d:
						ex2 = ex;
						array4 = new object[8];
						array4[7] = 0;
						array4[1] = array;
						array4[0] = ex;
						array4[2] = num14;
						array4[3] = num5;
						array4[5] = 0;
						array = array4;
						num2 = *(int*)(ptr + num5 + num);
						break;
						IL_0926:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 40 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 80 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 48 + num);
						array4 = new object[8];
						array4[7] = 0;
						array4[1] = array;
						array4[0] = ex;
						array4[2] = num14;
						array4[3] = -1;
						array4[4] = -1;
						array4[5] = 1;
						array = array4;
						num2 = *(int*)(ptr + num11 + 48 + num);
						break;
						IL_05af:
						if (1 == num21)
						{
							num5 = *(int*)(ptr + num4 + num);
							ex2 = (Exception)array4[0];
							array = (object[])array[1];
							object[] array5 = new object[8];
							array5[7] = 0;
							array5[1] = array;
							array5[0] = array4[0];
							array5[2] = (int)array4[2];
							array5[3] = num4;
							array5[5] = 0;
							array = array5;
							num2 = *(int*)(ptr + num4 + num);
							break;
						}
						goto IL_05b7;
					}
					break;
				}
				while (num3 != 0)
				{
					int num24;
					int num18;
					int num8;
					int num14;
					int num9;
					int num21;
					int num13;
					if (num3 == 1)
					{
						num3 = 17;
						if ((int)array[7] != 1)
						{
							num9 = (int)array[4];
							if (num9 == -1)
							{
								num21 = -1;
								num14 = -1;
							}
							else
							{
								num21 = *(int*)(ptr + num9 + 64 + num);
								num14 = *(int*)(ptr + *(int*)(ptr + (int)array[3] + 64 + num) + 80 + num);
							}
							while (true)
							{
								if (num14 != num21)
								{
									num8 = *(int*)(ptr + num14 + 40 + num);
									if (num8 == -1)
									{
										num14 = *(int*)(ptr + num14 + 80 + num);
										continue;
									}
									num18 = *(int*)(ptr + num8 + 48 + num);
									array[3] = num8;
									array[5] = 2;
									num2 = *(int*)(ptr + num8 + 48 + num);
									break;
								}
								if (num9 != -1)
								{
									Exception ex3 = (Exception)array[0];
									num18 = *(int*)(ptr + num9 + 48 + num);
									ex2 = ex3;
									array = (object[])array[1];
									object[] array4 = new object[8];
									array4[7] = 0;
									array4[1] = array;
									array4[0] = ex3;
									array4[3] = num9;
									array4[5] = 1;
									array = array4;
									num2 = *(int*)(ptr + num9 + 48 + num);
									break;
								}
								num23 = 1;
								throw ex;
							}
							continue;
						}
						num13 = (int)array[6];
						array = (object[])array[1];
						num24 = num13;
					}
					else
					{
						if (num3 != 4)
						{
							((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref VRRig, ref IEnumerator<VRRig>, ref VRRig, void>)FreeHStringFieldAccessMask[num2])(ref num2, ref num3, ref num25, ex2, ref num26, ref num27, ref num28, ref num29, ref num30, ref num31, ref vRRig, ref enumerator, ref vRRig2);
							continue;
						}
						num3 = 17;
						num8 = num25;
						num24 = num8;
					}
					int num11 = num2;
					num21 = num11;
					num13 = 0;
					int num4 = 2;
					int num7;
					int num6;
					int num5;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 160 + num5 * 56 + 48 + num);
						num7 = *(int*)(ptr + 160 + num5 * 56 + 8 + num);
						if (num21 < num6 + num7)
						{
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						else
						{
							num13 = num5 + 1;
						}
					}
					num14 = num5;
					num18 = *(int*)(ptr + 160 + num14 * 56 + 24 + num);
					int num12 = num18;
					num7 = num24;
					num6 = 0;
					num5 = 2;
					while (true)
					{
						num4 = (num6 + num5) / 2;
						num13 = *(int*)(ptr + 160 + num4 * 56 + 48 + num);
						num21 = *(int*)(ptr + 160 + num4 * 56 + 8 + num);
						if (num7 >= num13 + num21)
						{
							num6 = num4 + 1;
							continue;
						}
						if (num13 <= num7)
						{
							break;
						}
						num5 = num4 - 1;
					}
					num14 = num4;
					num8 = *(int*)(ptr + 160 + num14 * 56 + 24 + num);
					num18 = num8;
					num21 = num24;
					num13 = 0;
					num4 = 2;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 328 + num5 * 72 + 64 + num);
						num7 = *(int*)(ptr + 328 + num5 * 72 + 16 + num);
						if (num21 >= num6 + num7)
						{
							num13 = num5 + 1;
							continue;
						}
						if (num6 <= num21)
						{
							break;
						}
						num4 = num5 - 1;
					}
					num14 = num5;
					num9 = *(int*)(ptr + 328 + num14 * 72 + 32 + num);
					num8 = num9;
					while (true)
					{
						if (array == null || (int)array[7] == 1)
						{
							num21 = num18;
							while (num21 != num12)
							{
								if (num21 != -1)
								{
									num21 = *(int*)(ptr + num21 + 80 + num);
									continue;
								}
								goto IL_033e;
							}
							num2 = num24;
							break;
						}
						int num32 = (int)array[3];
						int num33;
						if (num12 == -1)
						{
							num33 = -1;
						}
						else
						{
							int num10 = *(int*)(ptr + num12 + 56 + num);
							num7 = 0;
							num6 = 2;
							while (true)
							{
								num5 = (num7 + num6) / 2;
								num4 = *(int*)(ptr + 328 + num5 * 72 + 64 + num);
								num13 = *(int*)(ptr + 328 + num5 * 72 + 16 + num);
								if (num10 < num4 + num13)
								{
									if (num4 <= num10)
									{
										break;
									}
									num6 = num5 - 1;
								}
								else
								{
									num7 = num5 + 1;
								}
							}
							num9 = num5;
							num14 = *(int*)(ptr + 328 + num9 * 72 + 32 + num);
							num33 = num14;
						}
						if (num32 == num33)
						{
							num14 = num18;
							while (num14 != num12)
							{
								if (num14 != -1)
								{
									num14 = *(int*)(ptr + num14 + 80 + num);
									continue;
								}
								goto IL_0436;
							}
							num2 = num24;
							break;
						}
						if ((int)array[3] != num8)
						{
							array = (object[])array[1];
							continue;
						}
						num2 = num24;
						break;
						IL_0436:
						num9 = *(int*)(ptr + num12 + 40 + num);
						if (num9 == -1)
						{
							num12 = *(int*)(ptr + num12 + 80 + num);
							continue;
						}
						num21 = *(int*)(ptr + num9 + 48 + num);
						object[] array4 = new object[8];
						array4[7] = 1;
						array4[1] = array;
						array4[6] = num24;
						array4[3] = num9;
						array4[5] = 2;
						array = array4;
						num2 = *(int*)(ptr + num9 + 48 + num);
						break;
						IL_033e:
						num13 = *(int*)(ptr + num12 + 40 + num);
						if (num13 == -1)
						{
							num12 = *(int*)(ptr + num12 + 80 + num);
							continue;
						}
						num4 = *(int*)(ptr + num13 + 48 + num);
						array4 = new object[8];
						array4[7] = 1;
						array4[1] = array;
						array4[6] = num24;
						array4[3] = num13;
						array4[5] = 2;
						array = array4;
						num2 = *(int*)(ptr + num13 + 48 + num);
						break;
					}
				}
				num3 = 17;
				break;
			}
			catch (Exception ex4)
			{
				if (num23 == 1)
				{
					throw ex4;
				}
				ex = ex4;
				num22 = -1;
				try0016_dispatch = 2323;
			}
		}
	}

	public Class176()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static GorillaTagger EncodergetSource()
	{
		return GorillaTagger.Instance;
	}

	private unsafe static int smethod_1()
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 95;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ArgumentOutOfRangeCountDispatchChannelSinkProvider.getOrdinalGetHashFromFileW);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 177;
															while (true)
															{
																if (num != 177)
																{
																	if (num != 1158)
																	{
																		goto IL_0914;
																	}
																	switch (num)
																	{
																	case 77:
																		goto end_IL_02d3;
																	case 68:
																	case 109:
																		goto end_IL_02e3;
																	case 17:
																		goto IL_0315;
																	case 16:
																		goto IL_0323;
																	case 163:
																	case 165:
																		goto IL_0331;
																	case 51:
																	case 66:
																		goto IL_033f;
																	case 12:
																	case 107:
																		goto IL_034a;
																	case 92:
																	case 118:
																		goto IL_035e;
																	case 48:
																		goto IL_036c;
																	case 129:
																		goto IL_037f;
																	case 23:
																	case 155:
																		goto IL_038d;
																	case 161:
																		goto IL_03a9;
																	case 39:
																	case 56:
																		goto IL_03b7;
																	case 67:
																		goto IL_03c5;
																	case 25:
																	case 82:
																		goto IL_03d3;
																	case 131:
																		goto IL_03e7;
																	case 22:
																		goto IL_0426;
																	case 5:
																	case 125:
																		goto IL_0442;
																	case 72:
																		goto IL_0455;
																	case 87:
																		goto IL_0463;
																	case 13:
																	case 170:
																		goto IL_0471;
																	case 26:
																		goto IL_047f;
																	case 60:
																	case 136:
																		goto IL_048d;
																	case 35:
																		goto IL_04cd;
																	case 28:
																		goto IL_04ea;
																	case 42:
																		goto IL_0506;
																	case 30:
																	case 127:
																		goto IL_0511;
																	case 49:
																		goto IL_0555;
																	case 8:
																		goto IL_0569;
																	case 113:
																		goto IL_057c;
																	case 7:
																		goto IL_058a;
																	case 76:
																	case 94:
																		goto IL_0598;
																	case 149:
																		goto IL_05a6;
																	case 53:
																		goto IL_05d2;
																	case 80:
																		goto IL_05dc;
																	case 81:
																		goto IL_05ea;
																	case 36:
																	case 128:
																		goto IL_05fd;
																	case 111:
																		goto IL_065f;
																	case 154:
																		goto IL_067b;
																	case 146:
																		goto IL_0689;
																	case 156:
																		goto IL_0697;
																	case 4:
																	case 52:
																		goto IL_06a5;
																	case 31:
																	case 73:
																		goto IL_06b0;
																	case 137:
																		goto IL_06be;
																	case 32:
																	case 145:
																		goto IL_06cc;
																	case 158:
																		goto IL_06f5;
																	case 114:
																		goto IL_070e;
																	case 115:
																	case 144:
																		goto IL_0719;
																	case 1:
																		goto IL_0724;
																	case 84:
																	case 148:
																		goto IL_0732;
																	case 130:
																		goto IL_074b;
																	case 166:
																		goto IL_0759;
																	case 142:
																		goto IL_0767;
																	case 59:
																	case 167:
																		goto IL_0788;
																	case 20:
																		goto IL_07c8;
																	case 102:
																		goto IL_07dc;
																	case 71:
																	case 119:
																		goto IL_07ef;
																	case 0:
																		goto IL_080d;
																	case 120:
																		goto IL_081b;
																	case 99:
																		goto IL_0837;
																	case 44:
																	case 110:
																		goto IL_0845;
																	case 40:
																	case 43:
																		goto IL_0850;
																	case 69:
																		goto IL_085e;
																	case 138:
																	case 157:
																		goto IL_086c;
																	case 58:
																		goto IL_0884;
																	case 27:
																	case 98:
																		goto IL_0892;
																	case 75:
																		goto IL_08bb;
																	case 152:
																		goto IL_08c9;
																	case 37:
																		goto IL_08dc;
																	case 34:
																	case 159:
																		goto IL_08e7;
																	case 135:
																		goto IL_08f2;
																	case 65:
																	case 169:
																		goto IL_08fd;
																	case 105:
																		goto IL_0914;
																	case 151:
																		goto IL_092c;
																	case 46:
																		goto IL_093a;
																	case 2:
																	case 6:
																	case 10:
																	case 14:
																	case 21:
																	case 41:
																	case 45:
																	case 47:
																	case 54:
																	case 55:
																	case 63:
																	case 64:
																	case 79:
																	case 83:
																	case 85:
																	case 86:
																	case 93:
																	case 97:
																	case 106:
																	case 112:
																	case 116:
																	case 117:
																	case 123:
																	case 133:
																	case 134:
																	case 139:
																	case 140:
																	case 141:
																	case 143:
																	case 147:
																	case 150:
																	case 153:
																	case 164:
																		goto IL_094a;
																	case 91:
																	case 108:
																		goto IL_095f;
																	case 62:
																		goto IL_099e;
																	case 3:
																	case 9:
																	case 11:
																	case 18:
																	case 19:
																	case 24:
																	case 29:
																	case 38:
																	case 70:
																	case 74:
																	case 78:
																	case 88:
																	case 89:
																	case 100:
																	case 101:
																	case 103:
																	case 104:
																	case 122:
																	case 124:
																	case 126:
																		goto end_IL_02fc;
																	case 61:
																		goto end_IL_09ac;
																	case 33:
																		goto end_IL_09bf;
																	case 50:
																		goto end_IL_09c9;
																	case 162:
																		goto end_IL_09d4;
																	case 15:
																	case 168:
																		goto end_IL_09e4;
																	case 57:
																		goto end_IL_09f4;
																	case 90:
																	case 160:
																		goto end_IL_0a04;
																	case 95:
																		goto end_IL_0a14;
																	case 96:
																		goto end_IL_0a24;
																	case 121:
																	case 132:
																		goto IL_0a48;
																	}
																	continue;
																}
																if (b >= 1)
																{
																	goto IL_0315;
																}
																goto IL_094a;
																IL_092c:
																num5++;
																goto IL_093a;
																IL_095f:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_099e;
																IL_093a:
																ptr2 += 8;
																goto end_IL_02fc;
																IL_0315:
																if (b <= 17)
																{
																	goto IL_0323;
																}
																goto IL_094a;
																IL_0323:
																if (9 < b)
																{
																	goto IL_0331;
																}
																goto IL_067b;
																IL_0331:
																if (13 < b)
																{
																	goto IL_033f;
																}
																goto IL_0455;
																IL_033f:
																if (15 < b)
																{
																	goto IL_034a;
																}
																goto IL_03a9;
																IL_034a:
																if (16 < b)
																{
																	num = 118;
																	goto IL_035e;
																}
																goto IL_037f;
																IL_099e:
																num5 -= 3;
																goto end_IL_02fc;
																IL_035e:
																if (17 >= b)
																{
																	goto IL_036c;
																}
																goto IL_094a;
																IL_036c:
																if (17 > b)
																{
																}
																goto IL_094a;
																IL_037f:
																if (16 <= b)
																{
																	goto IL_038d;
																}
																goto IL_094a;
																IL_038d:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_02fc;
																IL_03a9:
																if (15 > b)
																{
																	goto IL_03b7;
																}
																goto IL_0442;
																IL_03b7:
																if (14 >= b)
																{
																	goto IL_03c5;
																}
																goto IL_094a;
																IL_03c5:
																if (14 <= b)
																{
																	goto IL_03d3;
																}
																goto IL_094a;
																IL_03d3:
																array[num5 - 1] = 0;
																goto IL_03e7;
																IL_03e7:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)StartNoGCRegionStatusDESCKINDIMPLICITAPPOBJ[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_0426;
																IL_0426:
																ptr2 += 8;
																num = 101;
																goto end_IL_02fc;
																IL_0442:
																num5--;
																goto end_IL_02fc;
																IL_0455:
																if (13 > b)
																{
																	goto IL_0463;
																}
																goto IL_05fd;
																IL_0463:
																if (11 < b)
																{
																	goto IL_0471;
																}
																goto IL_0506;
																IL_0471:
																if (12 >= b)
																{
																	goto IL_047f;
																}
																goto IL_094a;
																IL_047f:
																if (12 <= b)
																{
																	goto IL_048d;
																}
																goto IL_094a;
																IL_048d:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04cd;
																IL_04cd:
																array[num5 - 2] = 0;
																num = 28;
																goto IL_04ea;
																IL_04ea:
																num5--;
																num = 122;
																goto end_IL_02fc;
																IL_0506:
																if (11 <= b)
																{
																	goto IL_0511;
																}
																goto IL_057c;
																IL_0511:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_0555;
																IL_0555:
																array[num5 - 2] = 0;
																goto IL_0569;
																IL_0569:
																num5--;
																goto end_IL_02fc;
																IL_057c:
																if (10 >= b)
																{
																	goto IL_058a;
																}
																goto IL_094a;
																IL_058a:
																if (10 <= b)
																{
																	goto IL_0598;
																}
																goto IL_094a;
																IL_0598:
																array[num5] = 0;
																goto IL_05a6;
																IL_05a6:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																num = 53;
																goto IL_05d2;
																IL_05d2:
																array2[num5] = null;
																goto IL_05dc;
																IL_05dc:
																num5++;
																goto IL_05ea;
																IL_05ea:
																ptr2 += 8;
																goto end_IL_02fc;
																IL_05fd:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_065f;
																IL_065f:
																num5 -= 2;
																num = 88;
																goto end_IL_02fc;
																IL_067b:
																if (9 <= b)
																{
																	goto end_IL_02fc;
																}
																goto IL_0689;
																IL_0689:
																if (4 >= b)
																{
																	goto IL_0697;
																}
																goto IL_0837;
																IL_0697:
																if (4 > b)
																{
																	goto IL_06a5;
																}
																goto IL_07ef;
																IL_06a5:
																if (2 < b)
																{
																	goto IL_06b0;
																}
																goto IL_070e;
																IL_06b0:
																if (3 >= b)
																{
																	goto IL_06be;
																}
																goto IL_094a;
																IL_06be:
																if (3 <= b)
																{
																	goto IL_06cc;
																}
																goto IL_094a;
																IL_06cc:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_06f5;
																IL_06f5:
																array[num5 - 1] = 5;
																goto end_IL_02fc;
																IL_070e:
																if (2 > b)
																{
																	goto IL_0719;
																}
																goto IL_0788;
																IL_0719:
																if (1 >= b)
																{
																	goto IL_0724;
																}
																num = 85;
																goto IL_094a;
																IL_0724:
																if (1 <= b)
																{
																	goto IL_0732;
																}
																goto IL_094a;
																IL_0732:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_074b;
																IL_074b:
																array[num5] = 0;
																goto IL_0759;
																IL_0759:
																num5++;
																goto IL_0767;
																IL_0767:
																ptr2 += 8;
																goto end_IL_02fc;
																IL_094a:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02fc;
																IL_0788:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_07c8;
																IL_07c8:
																array[num5 - 2] = 0;
																goto IL_07dc;
																IL_07dc:
																num5--;
																goto end_IL_02fc;
																IL_07ef:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_080d;
																IL_080d:
																ptr2 += 8;
																goto IL_081b;
																IL_081b:
																num5--;
																num = 124;
																goto end_IL_02fc;
																IL_0837:
																if (6 < b)
																{
																	goto IL_0845;
																}
																goto IL_08dc;
																IL_0845:
																if (7 < b)
																{
																	goto IL_0850;
																}
																goto IL_0884;
																IL_0850:
																if (8 >= b)
																{
																	goto IL_085e;
																}
																goto IL_094a;
																IL_085e:
																if (8 <= b)
																{
																	goto IL_086c;
																}
																goto IL_094a;
																IL_086c:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02fc;
																IL_0884:
																if (7 <= b)
																{
																	goto IL_0892;
																}
																goto IL_094a;
																IL_0892:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_08bb;
																IL_08bb:
																ptr2 += 8;
																goto IL_08c9;
																IL_08c9:
																num5--;
																goto end_IL_02fc;
																IL_08dc:
																if (6 > b)
																{
																	goto IL_08e7;
																}
																goto IL_095f;
																IL_08e7:
																if (5 >= b)
																{
																	goto IL_08f2;
																}
																goto IL_094a;
																IL_08f2:
																if (5 <= b)
																{
																	goto IL_08fd;
																}
																goto IL_094a;
																IL_08fd:
																array[num5] = 5;
																num = 105;
																goto IL_0914;
																IL_0914:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_092c;
																continue;
																end_IL_02d3:
																break;
															}
															continue;
															end_IL_02e3:
															break;
														}
														continue;
														end_IL_02fc:
														break;
													}
													continue;
												}
												goto IL_0a48;
												IL_0a48:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ac:
												break;
											}
											continue;
											end_IL_09bf:
											break;
										}
										continue;
										end_IL_09c9:
										break;
									}
									continue;
									end_IL_09d4:
									break;
								}
								continue;
								end_IL_09e4:
								break;
							}
							continue;
							end_IL_09f4:
							break;
						}
						continue;
						end_IL_0a04:
						break;
					}
					continue;
					end_IL_0a14:
					break;
				}
				continue;
				end_IL_0a24:
				break;
			}
		}
	}

	private static bool FromOADateSoapNmtoken(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static IReadOnlyList<VRRig> AppDomainManagergetHardwareDevice()
	{
		return VRRigCache.ActiveRigs;
	}

	private static IReadOnlyList<VRRig> AuthenticatedPushi()
	{
		return VRRigCache.ActiveRigs;
	}

	private static IEnumerator<VRRig> ReadStringAuditFlags(IEnumerable<VRRig> ienumerable_0)
	{
		return ienumerable_0.GetEnumerator();
	}

	private static GorillaTagger ParallelLoopEndLastWriteTimeUtc()
	{
		return GorillaTagger.Instance;
	}

	private static VRRig AutoDispatchValueClassMarshaler(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	private static bool DaylightNameArchitecture(IEnumerator ienumerator_0)
	{
		return ienumerator_0.MoveNext();
	}

	private static bool KeyInfoToday(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static VRRig FUNCFLAGFSOURCEgetIsOut(IEnumerator<VRRig> ienumerator_0)
	{
		return ienumerator_0.Current;
	}

	private static GorillaParent KerbTicketUnlockLogonVoid()
	{
		return GorillaParent.instance;
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 94;
		long[] array3 = default(long[]);
		int num4 = default(int);
		int[] array4 = default(int[]);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 111;
						while (true)
						{
							if (num == 111)
							{
								goto IL_021f;
							}
							if (num != 1092)
							{
								goto IL_0464;
							}
							switch (num)
							{
							case 74:
								goto end_IL_01cb;
							case 17:
							case 65:
								goto end_IL_01db;
							case 93:
								goto end_IL_01f4;
							case 94:
								goto end_IL_0204;
							case 44:
								goto IL_021f;
							case 95:
								goto IL_022d;
							case 71:
								goto IL_023b;
							case 100:
								goto IL_024e;
							case 77:
								goto IL_0261;
							case 30:
								goto IL_026a;
							case 0:
							case 6:
							case 27:
							case 37:
							case 43:
							case 45:
							case 52:
							case 69:
							case 89:
							case 99:
							case 102:
								goto IL_0272;
							case 87:
								goto IL_0282;
							case 101:
								goto IL_028b;
							case 97:
								goto IL_0294;
							case 7:
								goto IL_02a2;
							case 3:
								goto IL_02b0;
							case 19:
								goto IL_02be;
							case 18:
								goto IL_02cc;
							case 62:
							case 96:
								goto IL_02d7;
							case 10:
								goto IL_02e5;
							case 59:
								goto IL_0308;
							case 73:
								goto IL_0312;
							case 16:
								goto IL_0320;
							case 53:
								goto IL_033c;
							case 58:
								goto IL_034a;
							case 33:
							case 88:
								goto IL_035e;
							case 21:
								goto IL_036c;
							case 29:
							case 86:
								goto IL_037f;
							case 24:
								goto IL_03bf;
							case 66:
								goto IL_03d3;
							case 84:
								goto IL_03e6;
							case 40:
							case 78:
								goto IL_03f4;
							case 61:
								goto IL_0402;
							case 98:
							case 104:
								goto IL_0410;
							case 12:
								goto IL_0450;
							case 103:
								goto IL_0464;
							case 15:
								goto IL_0477;
							case 50:
							case 72:
								goto IL_0482;
							case 56:
								goto IL_04ab;
							case 13:
								goto IL_04b9;
							case 70:
								goto IL_04da;
							case 92:
								goto IL_04e8;
							case 20:
							case 41:
								goto IL_04f3;
							case 26:
								goto IL_050c;
							case 38:
								goto IL_051a;
							case 57:
								goto IL_0528;
							case 22:
								goto IL_053b;
							case 8:
								goto IL_0549;
							case 39:
							case 79:
								goto IL_0557;
							case 64:
								goto IL_0597;
							case 48:
								goto IL_05ab;
							case 55:
								goto IL_05be;
							case 34:
							case 81:
								goto IL_05c9;
							case 54:
								goto IL_05d7;
							case 35:
							case 46:
								goto IL_05e5;
							case 82:
								goto IL_0601;
							case 14:
							case 75:
								goto IL_060f;
							case 1:
								goto IL_064f;
							case 42:
								goto IL_0663;
							case 9:
								goto IL_067f;
							case 63:
								goto IL_068d;
							case 2:
								goto IL_069b;
							case 4:
							case 5:
							case 11:
							case 25:
							case 28:
							case 31:
							case 32:
							case 36:
							case 47:
							case 49:
							case 51:
							case 60:
							case 67:
							case 76:
							case 80:
							case 83:
							case 85:
							case 90:
							case 91:
								goto IL_06b7;
							case 23:
							case 68:
								goto IL_06dc;
							}
							continue;
							IL_06b7:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
							goto IL_067f;
							IL_067f:
							array[num4] = 0;
							goto IL_068d;
							IL_021f:
							array4 = new int[5];
							goto IL_022d;
							IL_022d:
							array3 = new long[3];
							goto IL_023b;
							IL_023b:
							array4[0] = int_2;
							goto IL_024e;
							IL_024e:
							array4[1] = int_3;
							goto IL_0261;
							IL_0261:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ViewAccessControlDictionaryEnumeratorByKeys.NativeRegisterStackgetTask);
							goto IL_026a;
							IL_026a:
							ptr = ptr2;
							goto IL_0272;
							IL_0272:
							if (num5 != 1)
							{
								goto IL_0282;
							}
							goto IL_06dc;
							IL_06dc:
							return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							IL_0282:
							num = 101;
							goto IL_028b;
							IL_028b:
							b = *ptr;
							goto IL_0294;
							IL_0294:
							ptr++;
							goto IL_02a2;
							IL_02a2:
							if (b >= 1)
							{
								goto IL_02b0;
							}
							goto IL_06b7;
							IL_02b0:
							if (b <= 9)
							{
								goto IL_02be;
							}
							goto IL_06b7;
							IL_02be:
							if (5 >= b)
							{
								goto IL_02cc;
							}
							goto IL_04da;
							IL_02cc:
							if (5 <= b)
							{
								goto IL_02d7;
							}
							goto IL_033c;
							IL_02d7:
							array[num4] = 0;
							goto IL_02e5;
							IL_02e5:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = array4[*(int*)(ptr + num3)];
							goto IL_0308;
							IL_0308:
							array2[num4] = null;
							goto IL_0312;
							IL_0312:
							num4++;
							goto IL_0320;
							IL_0320:
							ptr += 8;
							num = 27;
							goto IL_0272;
							IL_033c:
							if (2 >= b)
							{
								goto IL_034a;
							}
							goto IL_03e6;
							IL_034a:
							if (2 > b)
							{
								num = 33;
								goto IL_035e;
							}
							goto IL_037f;
							IL_068d:
							num4++;
							goto IL_069b;
							IL_035e:
							if (1 >= b)
							{
								goto IL_036c;
							}
							goto IL_06b7;
							IL_036c:
							if (1 <= b)
							{
							}
							goto IL_06b7;
							IL_037f:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_03bf;
							IL_03bf:
							array[num4 - 2] = 0;
							goto IL_03d3;
							IL_03d3:
							num4--;
							goto IL_0272;
							IL_03e6:
							if (3 < b)
							{
								goto IL_03f4;
							}
							goto IL_0477;
							IL_03f4:
							if (4 >= b)
							{
								goto IL_0402;
							}
							goto IL_06b7;
							IL_0402:
							if (4 <= b)
							{
								goto IL_0410;
							}
							goto IL_06b7;
							IL_0410:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_0450;
							IL_0450:
							array[num4 - 2] = 0;
							goto IL_0464;
							IL_0464:
							num4--;
							goto IL_0272;
							IL_0477:
							if (3 <= b)
							{
								goto IL_0482;
							}
							num = 4;
							goto IL_06b7;
							IL_0482:
							ref int reference = ref array4[*(int*)(ptr + num3)];
							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_04ab;
							IL_04ab:
							ptr += 8;
							goto IL_04b9;
							IL_04b9:
							num4--;
							goto IL_0272;
							IL_069b:
							ptr += 8;
							num = 69;
							goto IL_0272;
							IL_04da:
							if (7 >= b)
							{
								goto IL_04e8;
							}
							goto IL_05be;
							IL_04e8:
							if (7 <= b)
							{
								goto IL_04f3;
							}
							goto IL_053b;
							IL_04f3:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4]) = *(int*)(ptr + num3);
							goto IL_050c;
							IL_050c:
							array[num4] = 0;
							goto IL_051a;
							IL_051a:
							num4++;
							goto IL_0528;
							IL_0528:
							ptr += 8;
							goto IL_0272;
							IL_053b:
							if (6 >= b)
							{
								goto IL_0549;
							}
							goto IL_06b7;
							IL_0549:
							if (6 <= b)
							{
								goto IL_0557;
							}
							goto IL_06b7;
							IL_0557:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_0597;
							IL_0597:
							array[num4 - 2] = 0;
							goto IL_05ab;
							IL_05ab:
							num4--;
							goto IL_0272;
							IL_05be:
							if (8 < b)
							{
								goto IL_05c9;
							}
							goto IL_0601;
							IL_05c9:
							if (9 >= b)
							{
								goto IL_05d7;
							}
							goto IL_06b7;
							IL_05d7:
							if (9 <= b)
							{
								goto IL_05e5;
							}
							goto IL_06b7;
							IL_05e5:
							byte* num6 = ptr;
							num5 = 1;
							ptr = num6 + -200;
							goto IL_0272;
							IL_0601:
							if (8 <= b)
							{
								goto IL_060f;
							}
							goto IL_06b7;
							IL_060f:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num4 - 1]);
							goto IL_064f;
							IL_064f:
							array[num4 - 2] = 0;
							goto IL_0663;
							IL_0663:
							num4--;
							num = 45;
							goto IL_0272;
							continue;
							end_IL_01cb:
							break;
						}
						continue;
						end_IL_01db:
						break;
					}
					continue;
					end_IL_01f4:
					break;
				}
				continue;
				end_IL_0204:
				break;
			}
		}
	}

	private static float DarkCyanGetRequestStream(VRRig vrrig_0)
	{
		return vrrig_0.lerpValueFingers;
	}

	private static void GreaterThansetCurrentUICulture(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	private static bool UNKNOWNsetFlags(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 39;
							while (true)
							{
								long[] array4 = new long[3];
								num = 69;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CopyFromDouble.WriteArrayNoPrompt);
										while (true)
										{
											IL_0694:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0681:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0270:
														byte b = *ptr2;
														while (true)
														{
															IL_0260:
															ptr2++;
															while (true)
															{
																IL_0250:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0230:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0223:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0210:
																							if (9 > b)
																							{
																								num = 120;
																								while (true)
																								{
																									if (num != 120)
																									{
																										if (num != 1101)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 61:
																											goto IL_0210;
																										case 108:
																											goto IL_0223;
																										case 1:
																											goto IL_0230;
																										case 2:
																											goto IL_0240;
																										case 0:
																											goto IL_0250;
																										case 12:
																											goto IL_0260;
																										case 15:
																										case 41:
																											goto IL_0270;
																										case 25:
																										case 60:
																											goto IL_027b;
																										case 8:
																											goto IL_0286;
																										case 21:
																										case 62:
																											goto IL_0294;
																										case 89:
																											goto IL_02b0;
																										case 82:
																											goto IL_02be;
																										case 110:
																											goto IL_02d1;
																										case 72:
																										case 79:
																											goto IL_02df;
																										case 101:
																											goto IL_02ed;
																										case 19:
																											goto IL_02fb;
																										case 29:
																										case 58:
																											goto IL_0306;
																										case 92:
																											goto IL_0314;
																										case 42:
																										case 54:
																											goto IL_0322;
																										case 56:
																											goto IL_034b;
																										case 64:
																											goto IL_0359;
																										case 84:
																											goto IL_036c;
																										case 5:
																										case 102:
																											goto IL_0388;
																										case 34:
																											goto IL_03a0;
																										case 14:
																										case 33:
																											goto IL_03ab;
																										case 45:
																											goto IL_03b9;
																										case 20:
																											goto IL_03cc;
																										case 7:
																										case 98:
																											goto IL_03df;
																										case 99:
																											goto IL_041f;
																										case 24:
																											goto IL_0433;
																										case 26:
																										case 111:
																											goto IL_0446;
																										case 55:
																											goto IL_045f;
																										case 43:
																											goto IL_0476;
																										case 93:
																											goto IL_0484;
																										case 75:
																										case 113:
																											goto IL_0497;
																										case 83:
																											goto IL_04a5;
																										case 23:
																											goto IL_04c8;
																										case 27:
																											goto IL_04d2;
																										case 78:
																											goto IL_04e0;
																										case 109:
																											goto IL_04f3;
																										case 105:
																											goto IL_04fe;
																										case 44:
																										case 112:
																											goto IL_0515;
																										case 63:
																											goto IL_0555;
																										case 100:
																											goto IL_0569;
																										case 52:
																											goto IL_057c;
																										case 76:
																											goto IL_058a;
																										case 68:
																										case 85:
																											goto IL_0598;
																										case 106:
																											goto IL_05bb;
																										case 74:
																											goto IL_05c9;
																										case 97:
																											goto IL_05d7;
																										case 59:
																										case 67:
																											goto IL_05ea;
																										case 37:
																											goto IL_064c;
																										case 4:
																										case 6:
																										case 13:
																										case 28:
																										case 32:
																										case 35:
																										case 38:
																										case 40:
																										case 47:
																										case 49:
																										case 50:
																										case 53:
																										case 65:
																										case 66:
																										case 70:
																										case 77:
																										case 81:
																										case 87:
																										case 95:
																										case 104:
																										case 107:
																											goto end_IL_0240;
																										case 3:
																										case 9:
																										case 16:
																										case 31:
																										case 36:
																										case 48:
																										case 51:
																										case 57:
																										case 71:
																										case 80:
																										case 86:
																										case 94:
																										case 96:
																										case 103:
																											goto IL_0681;
																										case 73:
																											goto IL_0694;
																										case 90:
																											goto end_IL_01fd;
																										case 69:
																											goto end_IL_069e;
																										case 39:
																											goto end_IL_06a9;
																										case 46:
																										case 88:
																											goto end_IL_06be;
																										case 91:
																											goto end_IL_06d7;
																										case 22:
																										case 30:
																											goto end_IL_06f0;
																										case 17:
																											goto end_IL_0700;
																										case 18:
																											goto end_IL_0710;
																										case 10:
																										case 11:
																											goto IL_072b;
																										}
																										continue;
																									}
																									goto IL_04f3;
																									IL_05bb:
																									array[num5] = 0;
																									goto IL_05c9;
																									IL_05c9:
																									num5++;
																									goto IL_05d7;
																									IL_04f3:
																									if (7 >= b)
																									{
																										goto IL_04fe;
																									}
																									goto IL_057c;
																									IL_04fe:
																									if (7 > b)
																									{
																										goto end_IL_0240;
																									}
																									num = 112;
																									goto IL_0515;
																									IL_05d7:
																									ptr2 += 8;
																									goto IL_0681;
																									IL_0515:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0555;
																									IL_0555:
																									array[num5 - 2] = 0;
																									goto IL_0569;
																									IL_0569:
																									num5--;
																									goto IL_0681;
																									IL_057c:
																									if (8 < b)
																									{
																										goto end_IL_0240;
																									}
																									goto IL_058a;
																									IL_058a:
																									if (8 > b)
																									{
																										goto end_IL_0240;
																									}
																									goto IL_0598;
																									IL_0598:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_05bb;
																									continue;
																									end_IL_01fd:
																									break;
																								}
																								break;
																							}
																							goto IL_05ea;
																							IL_05ea:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_064c;
																							IL_064c:
																							num5 -= 2;
																							num = 3;
																							goto IL_0681;
																						}
																						break;
																					}
																					goto IL_027b;
																					IL_02be:
																					if (11 <= b)
																					{
																					}
																					goto end_IL_0240;
																					IL_027b:
																					if (10 >= b)
																					{
																						goto IL_0286;
																					}
																					goto IL_02b0;
																					IL_0286:
																					if (10 > b)
																					{
																						goto end_IL_0240;
																					}
																					goto IL_0294;
																					IL_0294:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0681;
																					IL_02b0:
																					if (11 < b)
																					{
																						goto end_IL_0240;
																					}
																					goto IL_02be;
																				}
																				break;
																			}
																			goto IL_02d1;
																			IL_041f:
																			array[num5 - 2] = 0;
																			goto IL_0433;
																			IL_02d1:
																			if (6 > b)
																			{
																				goto IL_02df;
																			}
																			goto IL_03df;
																			IL_02df:
																			if (3 >= b)
																			{
																				goto IL_02ed;
																			}
																			goto IL_03a0;
																			IL_02ed:
																			if (3 > b)
																			{
																				goto IL_02fb;
																			}
																			num = 5;
																			goto IL_0388;
																			IL_02fb:
																			if (1 < b)
																			{
																				goto IL_0306;
																			}
																			goto IL_036c;
																			IL_0306:
																			if (2 < b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_0314;
																			IL_0314:
																			if (2 > b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_0322;
																			IL_0322:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_034b;
																			IL_034b:
																			ptr2 += 8;
																			goto IL_0359;
																			IL_0359:
																			num5--;
																			goto IL_0681;
																			IL_036c:
																			if (1 > b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_0446;
																			IL_0446:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_045f;
																			IL_045f:
																			array[num5] = 0;
																			num = 43;
																			goto IL_0476;
																			IL_0476:
																			num5++;
																			goto IL_0484;
																			IL_0484:
																			ptr2 += 8;
																			goto IL_0681;
																			IL_0433:
																			num5--;
																			goto IL_0681;
																			IL_0388:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_0681;
																			IL_03a0:
																			if (4 < b)
																			{
																				goto IL_03ab;
																			}
																			goto IL_03cc;
																			IL_03ab:
																			if (5 < b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_03b9;
																			IL_03b9:
																			if (5 > b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_0497;
																			IL_0497:
																			array[num5] = 0;
																			goto IL_04a5;
																			IL_04a5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04c8;
																			IL_04c8:
																			array2[num5] = null;
																			goto IL_04d2;
																			IL_04d2:
																			num5++;
																			goto IL_04e0;
																			IL_04e0:
																			ptr2 += 8;
																			goto IL_0681;
																			IL_03cc:
																			if (4 > b)
																			{
																				goto end_IL_0240;
																			}
																			goto IL_0681;
																			IL_03df:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_041f;
																		}
																		goto end_IL_0250;
																		continue;
																		end_IL_0240:
																		break;
																		IL_0240:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 80;
																goto IL_0681;
																continue;
																end_IL_0250:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_072b;
												IL_072b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										continue;
										end_IL_069e:
										break;
									}
									continue;
									end_IL_06a9:
									break;
								}
								continue;
								end_IL_06be:
								break;
							}
							continue;
							end_IL_06d7:
							break;
						}
						continue;
						end_IL_06f0:
						break;
					}
					continue;
					end_IL_0700:
					break;
				}
				continue;
				end_IL_0710:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 73;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 27;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getNameClaimTypesetControlThread.DiscretionaryAclPresentYieldAwaiter);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f9:
														byte b = *ptr2;
														while (true)
														{
															IL_02e9:
															ptr2++;
															while (true)
															{
																IL_02d9:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		num = 109;
																		while (true)
																		{
																			IL_02b6:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02a3:
																					if (12 < b)
																					{
																						num = 154;
																						while (true)
																						{
																							if (num != 154)
																							{
																								if (num != 1135)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 26:
																								case 92:
																									goto IL_02a3;
																								case 109:
																									goto IL_02b6;
																								case 12:
																									goto IL_02c6;
																								case 39:
																									goto IL_02d9;
																								case 3:
																									goto IL_02e9;
																								case 45:
																								case 136:
																									goto IL_02f9;
																								case 128:
																									goto IL_0304;
																								case 13:
																								case 31:
																									goto IL_030f;
																								case 102:
																									goto IL_0326;
																								case 110:
																									goto IL_0339;
																								case 19:
																								case 118:
																									goto IL_0344;
																								case 139:
																									goto IL_0360;
																								case 4:
																									goto IL_036e;
																								case 30:
																								case 70:
																									goto IL_037c;
																								case 64:
																									goto IL_03de;
																								case 105:
																									goto IL_03ff;
																								case 55:
																								case 71:
																									goto IL_040a;
																								case 115:
																									goto IL_0453;
																								case 22:
																									goto IL_0467;
																								case 113:
																									goto IL_047a;
																								case 15:
																								case 35:
																									goto IL_0488;
																								case 11:
																									goto IL_0496;
																								case 49:
																								case 61:
																									goto IL_04a4;
																								case 38:
																									goto IL_04e8;
																								case 114:
																									goto IL_04fc;
																								case 42:
																									goto IL_050f;
																								case 106:
																									goto IL_051a;
																								case 37:
																									goto IL_0528;
																								case 54:
																								case 132:
																									goto IL_053b;
																								case 5:
																									goto IL_0549;
																								case 117:
																									goto IL_0575;
																								case 134:
																									goto IL_057f;
																								case 72:
																									goto IL_058d;
																								case 123:
																									goto IL_05a0;
																								case 90:
																								case 93:
																									goto IL_05ab;
																								case 99:
																									goto IL_05c3;
																								case 144:
																									goto IL_05d1;
																								case 21:
																								case 41:
																									goto IL_05dc;
																								case 33:
																									goto IL_05fa;
																								case 40:
																									goto IL_0608;
																								case 24:
																									goto IL_061b;
																								case 141:
																									goto IL_0629;
																								case 119:
																								case 121:
																									goto IL_0634;
																								case 126:
																									goto IL_0674;
																								case 62:
																									goto IL_0688;
																								case 36:
																								case 135:
																									goto IL_06a4;
																								case 111:
																									goto IL_06b2;
																								case 0:
																								case 82:
																									goto IL_06c0;
																								case 116:
																									goto IL_06d9;
																								case 17:
																									goto IL_06e7;
																								case 16:
																									goto IL_06f5;
																								case 101:
																									goto IL_0708;
																								case 142:
																									goto IL_0716;
																								case 29:
																								case 43:
																									goto IL_0724;
																								case 18:
																									goto IL_074d;
																								case 63:
																									goto IL_0766;
																								case 66:
																								case 112:
																									goto IL_077a;
																								case 84:
																									goto IL_0788;
																								case 1:
																								case 127:
																									goto IL_0796;
																								case 57:
																									goto IL_07bf;
																								case 52:
																									goto IL_07cd;
																								case 138:
																									goto IL_07e0;
																								case 85:
																								case 120:
																									goto IL_07eb;
																								case 125:
																									goto IL_082a;
																								case 56:
																									goto IL_083a;
																								case 81:
																									goto IL_0845;
																								case 25:
																								case 100:
																									goto IL_0850;
																								case 129:
																									goto IL_085e;
																								case 131:
																									goto IL_0876;
																								case 9:
																									goto IL_088d;
																								case 6:
																								case 7:
																								case 8:
																								case 10:
																								case 14:
																								case 20:
																								case 34:
																								case 46:
																								case 48:
																								case 50:
																								case 51:
																								case 68:
																								case 75:
																								case 76:
																								case 83:
																								case 86:
																								case 89:
																								case 95:
																								case 97:
																								case 98:
																								case 107:
																								case 130:
																								case 133:
																								case 137:
																								case 143:
																								case 145:
																								case 146:
																								case 147:
																									goto end_IL_02c6;
																								case 2:
																								case 23:
																								case 44:
																								case 53:
																								case 59:
																								case 60:
																								case 77:
																								case 78:
																								case 79:
																								case 80:
																								case 87:
																								case 88:
																								case 91:
																								case 94:
																								case 96:
																								case 103:
																								case 104:
																								case 140:
																									goto end_IL_0293;
																								case 124:
																									goto end_IL_08b0;
																								case 27:
																									goto end_IL_08c3;
																								case 58:
																									goto end_IL_08cd;
																								case 69:
																									goto end_IL_08d8;
																								case 32:
																								case 67:
																									goto end_IL_08f1;
																								case 28:
																									goto end_IL_0901;
																								case 47:
																								case 108:
																									goto end_IL_0911;
																								case 73:
																									goto end_IL_0921;
																								case 74:
																									goto end_IL_0931;
																								case 65:
																								case 122:
																									goto IL_0955;
																								}
																								continue;
																							}
																							goto IL_0304;
																							IL_036e:
																							if (13 > b)
																							{
																								goto end_IL_02c6;
																							}
																							goto IL_037c;
																							IL_037c:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03de;
																							IL_0304:
																							if (14 < b)
																							{
																								goto IL_030f;
																							}
																							goto IL_0339;
																							IL_030f:
																							if (15 < b)
																							{
																								goto end_IL_02c6;
																							}
																							num = 102;
																							goto IL_0326;
																							IL_03de:
																							num5 -= 2;
																							break;
																							IL_0326:
																							if (15 <= b)
																							{
																							}
																							goto end_IL_02c6;
																							IL_0339:
																							if (14 <= b)
																							{
																								goto IL_0344;
																							}
																							goto IL_0360;
																							IL_0344:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_0360:
																							if (13 < b)
																							{
																								num = 89;
																								goto end_IL_02c6;
																							}
																							goto IL_036e;
																							continue;
																							end_IL_0293:
																							break;
																						}
																						break;
																					}
																					goto IL_03ff;
																					IL_057f:
																					num5++;
																					goto IL_058d;
																					IL_058d:
																					ptr2 += 8;
																					break;
																					IL_03ff:
																					if (12 <= b)
																					{
																						goto IL_040a;
																					}
																					goto IL_047a;
																					IL_040a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 115;
																					goto IL_0453;
																					IL_0453:
																					array[num5 - 2] = 0;
																					goto IL_0467;
																					IL_0467:
																					num5--;
																					break;
																					IL_047a:
																					if (10 < b)
																					{
																						goto IL_0488;
																					}
																					goto IL_050f;
																					IL_0488:
																					if (11 < b)
																					{
																						goto end_IL_02c6;
																					}
																					goto IL_0496;
																					IL_0496:
																					if (11 > b)
																					{
																						goto end_IL_02c6;
																					}
																					goto IL_04a4;
																					IL_04a4:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_04e8;
																					IL_04e8:
																					array[num5 - 2] = 0;
																					goto IL_04fc;
																					IL_04fc:
																					num5--;
																					break;
																					IL_050f:
																					if (10 > b)
																					{
																						goto IL_051a;
																					}
																					goto IL_053b;
																					IL_051a:
																					if (9 < b)
																					{
																						goto end_IL_02c6;
																					}
																					goto IL_0528;
																					IL_0528:
																					if (9 > b)
																					{
																						goto end_IL_02c6;
																					}
																					break;
																					IL_053b:
																					array[num5] = 0;
																					goto IL_0549;
																					IL_0549:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 117;
																					goto IL_0575;
																					IL_0575:
																					array2[num5] = null;
																					goto IL_057f;
																				}
																				break;
																			}
																			goto IL_05a0;
																			IL_085e:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0876;
																			IL_05a0:
																			if (8 <= b)
																			{
																				goto IL_05ab;
																			}
																			goto IL_05c3;
																			IL_05ab:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_05c3:
																			if (4 >= b)
																			{
																				goto IL_05d1;
																			}
																			goto IL_0766;
																			IL_05d1:
																			if (4 <= b)
																			{
																				goto IL_05dc;
																			}
																			goto IL_061b;
																			IL_05dc:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_05fa;
																			IL_05fa:
																			ptr2 += 8;
																			goto IL_0608;
																			IL_0608:
																			num5--;
																			break;
																			IL_061b:
																			if (2 >= b)
																			{
																				goto IL_0629;
																			}
																			goto IL_0708;
																			IL_0629:
																			if (2 <= b)
																			{
																				goto IL_0634;
																			}
																			num = 36;
																			goto IL_06a4;
																			IL_0634:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0674;
																			IL_0674:
																			array[num5 - 2] = 0;
																			goto IL_0688;
																			IL_0688:
																			num5--;
																			break;
																			IL_0876:
																			num5++;
																			num = 9;
																			goto IL_088d;
																			IL_06a4:
																			if (1 < b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_06b2;
																			IL_06b2:
																			if (1 > b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_06c0;
																			IL_06c0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06d9;
																			IL_06d9:
																			array[num5] = 0;
																			goto IL_06e7;
																			IL_06e7:
																			num5++;
																			goto IL_06f5;
																			IL_06f5:
																			ptr2 += 8;
																			break;
																			IL_0708:
																			if (3 < b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0716;
																			IL_0716:
																			if (3 > b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0724;
																			IL_0724:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_074d;
																			IL_074d:
																			array[num5 - 1] = 5;
																			break;
																			IL_0766:
																			if (6 < b)
																			{
																				num = 112;
																				goto IL_077a;
																			}
																			goto IL_07e0;
																			IL_088d:
																			ptr2 += 8;
																			break;
																			IL_077a:
																			if (7 < b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0788;
																			IL_0788:
																			if (7 > b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0796;
																			IL_0796:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07bf;
																			IL_07bf:
																			ptr2 += 8;
																			goto IL_07cd;
																			IL_07cd:
																			num5--;
																			break;
																			IL_07e0:
																			if (6 <= b)
																			{
																				goto IL_07eb;
																			}
																			goto IL_083a;
																			IL_07eb:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_082a;
																			IL_082a:
																			num5 -= 3;
																			break;
																			IL_083a:
																			if (5 < b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0845;
																			IL_0845:
																			if (5 > b)
																			{
																				goto end_IL_02c6;
																			}
																			goto IL_0850;
																			IL_0850:
																			array[num5] = 5;
																			goto IL_085e;
																		}
																		goto end_IL_02d9;
																		continue;
																		end_IL_02c6:
																		break;
																		IL_02c6:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d9:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0955;
												IL_0955:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b0:
												break;
											}
											continue;
											end_IL_08c3:
											break;
										}
										continue;
										end_IL_08cd:
										break;
									}
									continue;
									end_IL_08d8:
									break;
								}
								continue;
								end_IL_08f1:
								break;
							}
							continue;
							end_IL_0901:
							break;
						}
						continue;
						end_IL_0911:
						break;
					}
					continue;
					end_IL_0921:
					break;
				}
				continue;
				end_IL_0931:
				break;
			}
		}
	}

	private static bool CharArrayTypeInfoUserKeySet(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe void Update()
	{
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getConstructorRSAParameters.getProcessorArchitectureUnstarted);
		int num = 4;
		int num2 = 0;
		int num3 = 0;
		num3 = 0;
		int try0013_dispatch = -1;
		object[] array = default(object[]);
		Type[] array2 = default(Type[]);
		RuntimeTypeHandle[] array3 = default(RuntimeTypeHandle[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		int num31 = default(int);
		IEnumerator<VRRig> enumerator = default(IEnumerator<VRRig>);
		VRRig vRRig = default(VRRig);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0013_dispatch)
				{
				case 2315:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 144 + num8 * 64 + 16 + num);
							num10 = *(int*)(ptr + 144 + num8 * 64 + 32 + num);
							if (num5 >= num9 + num10)
							{
								num6 = num8 + 1;
								continue;
							}
							if (num9 <= num5)
							{
								break;
							}
							num7 = num8 - 1;
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 144 + num11 * 64 + 40 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array != null)
							{
								if ((int)array[2] == 0)
								{
									int num15 = (int)array[5];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 48 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 336 + num8 * 72 + 24 + num);
											num6 = *(int*)(ptr + 336 + num8 * 72 + 32 + num);
											if (num17 >= num7 + num6)
											{
												num10 = num8 + 1;
												continue;
											}
											if (num7 <= num17)
											{
												break;
											}
											num9 = num8 - 1;
										}
										num12 = num8;
										num11 = *(int*)(ptr + 336 + num12 * 72 + 48 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array = (object[])array[4];
										continue;
									}
								}
								else
								{
									int num18 = (int)array[6];
									if (num18 != 2 && num18 != 1 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array[5];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 48 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 336 + num8 * 72 + 24 + num);
											num10 = *(int*)(ptr + 336 + num8 * 72 + 32 + num);
											if (num5 < num9 + num10)
											{
												if (num9 <= num5)
												{
													break;
												}
												num7 = num8 - 1;
											}
											else
											{
												num6 = num8 + 1;
											}
										}
										num11 = num8;
										num12 = *(int*)(ptr + 336 + num11 * 72 + 48 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array = (object[])array[4];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_091e;
							}
							num21 = *(int*)(ptr + num13 + 32 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 40 + num);
								if (1 != num7)
								{
									goto IL_086a;
								}
								num6 = *(int*)(ptr + num5 + 56 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array3[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + num);
										continue;
									}
								}
								goto IL_09ae;
							}
							num13 = *(int*)(ptr + num13 + 16 + num);
							continue;
							IL_086a:
							if (2 != num7)
							{
								num13 = *(int*)(ptr + num13 + 16 + num);
								continue;
							}
							goto IL_0955;
						}
						object[] array4 = array;
						num4 = *(int*)(ptr + (int)array4[5] + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 40 + num);
							if (1 != num21)
							{
								goto IL_05ac;
							}
							num13 = *(int*)(ptr + num4 + 56 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array3[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[7]))
								{
									num4 = *(int*)(ptr + num4 + num);
									continue;
								}
							}
							goto IL_0b3b;
						}
						goto IL_05b4;
						IL_05b4:
						array = (object[])array[4];
						ex = (Exception)array4[7];
						num22 = (int)array4[0];
						continue;
						IL_09ae:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 24 + num) + 16 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 40 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 16 + num);
									continue;
								}
								array4 = new object[8];
								array4[2] = 1;
								array4[4] = array;
								array4[7] = ex;
								array4[0] = num14;
								array4[5] = num8;
								array4[1] = num17;
								array4[6] = 1;
								array = array4;
								num2 = *(int*)(ptr + num8 + 48 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[2] = 1;
							array4[4] = array;
							array4[7] = ex;
							array4[0] = num14;
							array4[5] = num17;
							array4[6] = 2;
							array = array4;
							num2 = *(int*)(ptr + num17 + 48 + num);
							break;
						}
						break;
						IL_0b3b:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 24 + num) + 16 + num);
						num14 = (int)array4[0];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 40 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 16 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 48 + num);
								array = (object[])array[4];
								array5 = new object[8];
								array5[2] = 1;
								array5[4] = array;
								array5[7] = array4[7];
								array5[0] = (int)array4[0];
								array5[5] = num18;
								array5[1] = num12;
								array5[6] = 1;
								array = array5;
								num2 = *(int*)(ptr + num18 + 48 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 48 + num);
							ex2 = (Exception)array4[7];
							array = (object[])array[4];
							array5 = new object[8];
							array5[2] = 1;
							array5[4] = array;
							array5[7] = array4[7];
							array5[0] = (int)array4[0];
							array5[5] = num12;
							array5[6] = 2;
							array = array5;
							num2 = *(int*)(ptr + num12 + 48 + num);
							break;
						}
						break;
						IL_0955:
						ex2 = ex;
						array4 = new object[8];
						array4[2] = 1;
						array4[4] = array;
						array4[7] = ex;
						array4[0] = num14;
						array4[5] = num5;
						array4[6] = 0;
						array = array4;
						num2 = *(int*)(ptr + num5 + 72 + num);
						break;
						IL_091e:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 40 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 16 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 48 + num);
						array4 = new object[8];
						array4[2] = 1;
						array4[4] = array;
						array4[7] = ex;
						array4[0] = num14;
						array4[5] = -1;
						array4[1] = -1;
						array4[6] = 2;
						array = array4;
						num2 = *(int*)(ptr + num11 + 48 + num);
						break;
						IL_05ac:
						if (2 == num21)
						{
							num5 = *(int*)(ptr + num4 + 72 + num);
							ex2 = (Exception)array4[7];
							array = (object[])array[4];
							object[] array5 = new object[8];
							array5[2] = 1;
							array5[4] = array;
							array5[7] = array4[7];
							array5[0] = (int)array4[0];
							array5[5] = num4;
							array5[6] = 0;
							array = array5;
							num2 = *(int*)(ptr + num4 + 72 + num);
							break;
						}
						goto IL_05b4;
					}
					break;
				}
				while (num3 != 17)
				{
					int num24;
					int num18;
					int num8;
					int num14;
					int num9;
					int num21;
					int num13;
					if (num3 == 21)
					{
						num3 = 0;
						if ((int)array[2] != 0)
						{
							num9 = (int)array[1];
							if (num9 == -1)
							{
								num21 = -1;
								num14 = -1;
							}
							else
							{
								num21 = *(int*)(ptr + num9 + 24 + num);
								num14 = *(int*)(ptr + *(int*)(ptr + (int)array[5] + 24 + num) + 16 + num);
							}
							while (true)
							{
								if (num14 != num21)
								{
									num8 = *(int*)(ptr + num14 + 40 + num);
									if (num8 == -1)
									{
										num14 = *(int*)(ptr + num14 + 16 + num);
										continue;
									}
									num18 = *(int*)(ptr + num8 + 48 + num);
									array[5] = num8;
									array[6] = 1;
									num2 = *(int*)(ptr + num8 + 48 + num);
									break;
								}
								if (num9 != -1)
								{
									Exception ex3 = (Exception)array[7];
									num18 = *(int*)(ptr + num9 + 48 + num);
									ex2 = ex3;
									array = (object[])array[4];
									object[] array4 = new object[8];
									array4[2] = 1;
									array4[4] = array;
									array4[7] = ex3;
									array4[5] = num9;
									array4[6] = 2;
									array = array4;
									num2 = *(int*)(ptr + num9 + 48 + num);
									break;
								}
								num23 = 1;
								throw ex;
							}
							continue;
						}
						num13 = (int)array[3];
						array = (object[])array[4];
						num24 = num13;
					}
					else
					{
						if (num3 != 22)
						{
							((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref IEnumerator<VRRig>, ref VRRig, void>)FreeHStringFieldAccessMask[num2])(ref num2, ref num3, ref num25, ex2, ref num26, ref num27, ref num28, ref num29, ref num30, ref num31, ref enumerator, ref vRRig);
							continue;
						}
						num3 = 0;
						num8 = num25;
						num24 = num8;
					}
					int num11 = num2;
					num21 = num11;
					num13 = 0;
					int num4 = 2;
					int num7;
					int num6;
					int num5;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 144 + num5 * 64 + 16 + num);
						num7 = *(int*)(ptr + 144 + num5 * 64 + 32 + num);
						if (num21 < num6 + num7)
						{
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						else
						{
							num13 = num5 + 1;
						}
					}
					num14 = num5;
					num18 = *(int*)(ptr + 144 + num14 * 64 + 40 + num);
					int num12 = num18;
					num7 = num24;
					num6 = 0;
					num5 = 2;
					while (true)
					{
						num4 = (num6 + num5) / 2;
						num13 = *(int*)(ptr + 144 + num4 * 64 + 16 + num);
						num21 = *(int*)(ptr + 144 + num4 * 64 + 32 + num);
						if (num7 < num13 + num21)
						{
							if (num13 <= num7)
							{
								break;
							}
							num5 = num4 - 1;
						}
						else
						{
							num6 = num4 + 1;
						}
					}
					num14 = num4;
					num8 = *(int*)(ptr + 144 + num14 * 64 + 40 + num);
					num18 = num8;
					num21 = num24;
					num13 = 0;
					num4 = 2;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 336 + num5 * 72 + 24 + num);
						num7 = *(int*)(ptr + 336 + num5 * 72 + 32 + num);
						if (num21 >= num6 + num7)
						{
							num13 = num5 + 1;
							continue;
						}
						if (num6 <= num21)
						{
							break;
						}
						num4 = num5 - 1;
					}
					num14 = num5;
					num9 = *(int*)(ptr + 336 + num14 * 72 + 48 + num);
					num8 = num9;
					while (true)
					{
						if (array == null || (int)array[2] == 0)
						{
							num21 = num18;
							while (num21 != num12)
							{
								if (num21 != -1)
								{
									num21 = *(int*)(ptr + num21 + 16 + num);
									continue;
								}
								goto IL_033e;
							}
							num2 = num24;
							break;
						}
						int num32 = (int)array[5];
						int num33;
						if (num12 == -1)
						{
							num33 = -1;
						}
						else
						{
							int num10 = *(int*)(ptr + num12 + 48 + num);
							num7 = 0;
							num6 = 2;
							while (true)
							{
								num5 = (num7 + num6) / 2;
								num4 = *(int*)(ptr + 336 + num5 * 72 + 24 + num);
								num13 = *(int*)(ptr + 336 + num5 * 72 + 32 + num);
								if (num10 >= num4 + num13)
								{
									num7 = num5 + 1;
									continue;
								}
								if (num4 <= num10)
								{
									break;
								}
								num6 = num5 - 1;
							}
							num9 = num5;
							num14 = *(int*)(ptr + 336 + num9 * 72 + 48 + num);
							num33 = num14;
						}
						if (num32 == num33)
						{
							num14 = num18;
							while (num14 != num12)
							{
								if (num14 != -1)
								{
									num14 = *(int*)(ptr + num14 + 16 + num);
									continue;
								}
								goto IL_0436;
							}
							num2 = num24;
							break;
						}
						if ((int)array[5] != num8)
						{
							array = (object[])array[4];
							continue;
						}
						num2 = num24;
						break;
						IL_0436:
						num9 = *(int*)(ptr + num12 + 40 + num);
						if (num9 == -1)
						{
							num12 = *(int*)(ptr + num12 + 16 + num);
							continue;
						}
						num21 = *(int*)(ptr + num9 + 48 + num);
						object[] array4 = new object[8];
						array4[2] = 0;
						array4[4] = array;
						array4[3] = num24;
						array4[5] = num9;
						array4[6] = 1;
						array = array4;
						num2 = *(int*)(ptr + num9 + 48 + num);
						break;
						IL_033e:
						num13 = *(int*)(ptr + num12 + 40 + num);
						if (num13 == -1)
						{
							num12 = *(int*)(ptr + num12 + 16 + num);
							continue;
						}
						num4 = *(int*)(ptr + num13 + 48 + num);
						array4 = new object[8];
						array4[2] = 0;
						array4[4] = array;
						array4[3] = num24;
						array4[5] = num13;
						array4[6] = 1;
						array = array4;
						num2 = *(int*)(ptr + num13 + 48 + num);
						break;
					}
				}
				num3 = 0;
				break;
			}
			catch (Exception ex4)
			{
				if (num23 == 1)
				{
					throw ex4;
				}
				ex = ex4;
				num22 = -1;
				try0013_dispatch = 2315;
			}
		}
	}

	private static bool DYMdGenerateDefinitionKey(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static int smethod_5(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_6()
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 88;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTypeInfoCountHexadecimal.ModuleResolveEventHandlerLastCalledMethodClass);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0358:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0338:
																			if (9 >= b)
																			{
																				while (true)
																				{
																					IL_0328:
																					if (9 > b)
																					{
																						while (true)
																						{
																							IL_0318:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_030b:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_02e2:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											num = 176;
																											while (true)
																											{
																												if (num != 176)
																												{
																													if (num != 1157)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 15:
																													case 62:
																														goto IL_02e2;
																													case 101:
																														goto IL_030b;
																													case 10:
																														goto IL_0318;
																													case 169:
																														goto IL_0328;
																													case 119:
																														goto IL_0338;
																													case 90:
																														goto IL_0348;
																													case 140:
																														goto IL_0358;
																													case 8:
																														goto end_IL_0358;
																													case 48:
																													case 118:
																														goto end_IL_0368;
																													case 23:
																													case 27:
																														goto IL_0383;
																													case 18:
																														goto IL_0391;
																													case 12:
																													case 43:
																														goto IL_039f;
																													case 55:
																														goto IL_03e4;
																													case 7:
																														goto IL_03ef;
																													case 5:
																														goto IL_03fc;
																													case 46:
																													case 63:
																														goto IL_040f;
																													case 11:
																														goto IL_041d;
																													case 40:
																													case 83:
																														goto IL_042b;
																													case 53:
																													case 85:
																														goto IL_043e;
																													case 97:
																														goto IL_04a5;
																													case 49:
																													case 74:
																														goto IL_04b0;
																													case 92:
																														goto IL_04c3;
																													case 54:
																													case 107:
																														goto IL_04d3;
																													case 41:
																														goto IL_04de;
																													case 117:
																														goto IL_0508;
																													case 124:
																														goto IL_0521;
																													case 127:
																														goto IL_0534;
																													case 3:
																													case 35:
																														goto IL_0542;
																													case 122:
																														goto IL_0550;
																													case 128:
																														goto IL_0573;
																													case 98:
																														goto IL_057d;
																													case 19:
																														goto IL_0594;
																													case 121:
																													case 130:
																														goto IL_05a7;
																													case 93:
																														goto IL_05b5;
																													case 86:
																													case 108:
																														goto IL_05c3;
																													case 132:
																														goto IL_05e1;
																													case 76:
																													case 136:
																														goto IL_05f4;
																													case 36:
																														goto IL_0638;
																													case 69:
																														goto IL_064c;
																													case 134:
																													case 137:
																														goto IL_065f;
																													case 138:
																														goto IL_06a4;
																													case 70:
																														goto IL_06b2;
																													case 142:
																														goto IL_06c0;
																													case 146:
																														goto IL_06d3;
																													case 72:
																													case 147:
																														goto IL_06e6;
																													case 104:
																														goto IL_06f1;
																													case 47:
																													case 144:
																														goto IL_06ff;
																													case 78:
																														goto IL_071b;
																													case 145:
																														goto IL_0729;
																													case 154:
																														goto IL_073c;
																													case 9:
																														goto IL_0750;
																													case 30:
																													case 156:
																														goto IL_0763;
																													case 28:
																														goto IL_0777;
																													case 24:
																														goto IL_07d4;
																													case 129:
																														goto IL_07e2;
																													case 161:
																													case 166:
																														goto IL_07f5;
																													case 66:
																														goto IL_0803;
																													case 82:
																													case 116:
																														goto IL_0811;
																													case 67:
																														goto IL_083a;
																													case 100:
																														goto IL_0861;
																													case 148:
																														goto IL_0874;
																													case 0:
																													case 38:
																														goto IL_0882;
																													case 13:
																													case 68:
																														goto IL_088d;
																													case 165:
																														goto IL_089b;
																													case 4:
																													case 77:
																														goto IL_08a9;
																													case 133:
																														goto IL_08c1;
																													case 16:
																													case 95:
																														goto IL_08d8;
																													case 157:
																														goto IL_0901;
																													case 162:
																														goto IL_090f;
																													case 45:
																														goto IL_0922;
																													case 123:
																													case 139:
																														goto IL_092d;
																													case 110:
																														goto IL_093b;
																													case 150:
																													case 160:
																														goto IL_0949;
																													case 42:
																														goto IL_0957;
																													case 106:
																														goto IL_096f;
																													case 17:
																														goto IL_097d;
																													case 20:
																													case 34:
																														goto IL_098d;
																													case 143:
																														goto IL_09cc;
																													case 2:
																													case 6:
																													case 22:
																													case 26:
																													case 29:
																													case 31:
																													case 32:
																													case 44:
																													case 50:
																													case 51:
																													case 56:
																													case 58:
																													case 60:
																													case 64:
																													case 79:
																													case 91:
																													case 94:
																													case 99:
																													case 109:
																													case 111:
																													case 113:
																													case 114:
																													case 115:
																													case 126:
																													case 141:
																													case 149:
																													case 151:
																													case 152:
																													case 153:
																													case 155:
																													case 163:
																													case 164:
																													case 168:
																														goto end_IL_02cf;
																													case 14:
																													case 21:
																													case 25:
																													case 33:
																													case 37:
																													case 57:
																													case 59:
																													case 65:
																													case 73:
																													case 75:
																													case 80:
																													case 81:
																													case 87:
																													case 96:
																													case 102:
																													case 103:
																													case 112:
																													case 125:
																													case 131:
																													case 135:
																														goto end_IL_0378;
																													case 84:
																														goto end_IL_09fa;
																													case 167:
																														goto end_IL_0a0d;
																													case 120:
																														goto end_IL_0a17;
																													case 1:
																														goto end_IL_0a22;
																													case 61:
																													case 105:
																														goto end_IL_0a32;
																													case 71:
																														goto end_IL_0a42;
																													case 52:
																													case 158:
																														goto end_IL_0a52;
																													case 88:
																														goto end_IL_0a62;
																													case 89:
																														goto end_IL_0a72;
																													case 39:
																													case 159:
																														goto IL_0a9f;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto IL_0861;
																												IL_0861:
																												num5--;
																												goto end_IL_0378;
																												continue;
																												end_IL_02cf:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0383;
																									IL_083a:
																									array[num5 - 1] = 5;
																									goto end_IL_0378;
																									IL_0383:
																									if (2 >= b)
																									{
																										goto IL_0391;
																									}
																									goto IL_07f5;
																									IL_0391:
																									if (2 <= b)
																									{
																										goto IL_039f;
																									}
																									goto IL_05a7;
																									IL_039f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0508;
																									IL_0508:
																									array[num5 - 2] = 0;
																									goto IL_06d3;
																									IL_06d3:
																									num5--;
																									goto end_IL_0378;
																									IL_05a7:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_05b5;
																									IL_05b5:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_05c3;
																									IL_05c3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_06a4;
																									IL_06a4:
																									array[num5] = 0;
																									goto IL_06b2;
																									IL_06b2:
																									num5++;
																									goto IL_06c0;
																									IL_06c0:
																									ptr2 += 8;
																									goto end_IL_0378;
																									IL_07f5:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_0803;
																									IL_0803:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0811;
																									IL_0811:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_083a;
																								}
																								break;
																							}
																							goto IL_0874;
																							IL_098d:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_09cc;
																							IL_0874:
																							if (6 < b)
																							{
																								goto IL_0882;
																							}
																							goto IL_0922;
																							IL_0882:
																							if (7 < b)
																							{
																								goto IL_088d;
																							}
																							goto IL_08c1;
																							IL_088d:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_089b;
																							IL_089b:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_08a9;
																							IL_08a9:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0378;
																							IL_08c1:
																							if (7 > b)
																							{
																								break;
																							}
																							num = 16;
																							goto IL_08d8;
																							IL_09cc:
																							num5 -= 3;
																							goto end_IL_0378;
																							IL_08d8:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0901;
																							IL_0901:
																							ptr2 += 8;
																							goto IL_090f;
																							IL_090f:
																							num5--;
																							goto end_IL_0378;
																							IL_0922:
																							if (6 > b)
																							{
																								goto IL_092d;
																							}
																							goto IL_098d;
																							IL_092d:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_093b;
																							IL_093b:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0949;
																							IL_0949:
																							array[num5] = 5;
																							goto IL_0957;
																							IL_0957:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_096f;
																							IL_096f:
																							num5++;
																							goto IL_097d;
																							IL_097d:
																							ptr2 += 8;
																							goto end_IL_0378;
																						}
																						break;
																					}
																					num = 65;
																					goto end_IL_0378;
																				}
																				break;
																			}
																			goto IL_03e4;
																			IL_0777:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			num = 24;
																			goto IL_07d4;
																			IL_03e4:
																			if (13 >= b)
																			{
																				goto IL_03ef;
																			}
																			goto IL_03fc;
																			IL_03ef:
																			if (13 > b)
																			{
																				goto IL_040f;
																			}
																			goto IL_043e;
																			IL_040f:
																			if (11 >= b)
																			{
																				goto IL_041d;
																			}
																			goto IL_04d3;
																			IL_041d:
																			if (11 > b)
																			{
																				goto IL_042b;
																			}
																			goto IL_05f4;
																			IL_042b:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0534;
																			IL_0534:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0542;
																			IL_0542:
																			array[num5] = 0;
																			goto IL_0550;
																			IL_0550:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0573;
																			IL_0573:
																			array2[num5] = null;
																			goto IL_057d;
																			IL_057d:
																			num5++;
																			num = 19;
																			goto IL_0594;
																			IL_0594:
																			ptr2 += 8;
																			goto end_IL_0378;
																			IL_05f4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0638;
																			IL_0638:
																			array[num5 - 2] = 0;
																			goto IL_064c;
																			IL_064c:
																			num5--;
																			goto end_IL_0378;
																			IL_04d3:
																			if (12 < b)
																			{
																				num = 29;
																				break;
																			}
																			goto IL_04de;
																			IL_04de:
																			if (12 > b)
																			{
																				break;
																			}
																			num = 134;
																			goto IL_065f;
																			IL_07e2:
																			ptr2 += 8;
																			goto end_IL_0378;
																			IL_065f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_073c;
																			IL_073c:
																			array[num5 - 2] = 0;
																			goto IL_0750;
																			IL_0750:
																			num5--;
																			goto end_IL_0378;
																			IL_07d4:
																			num5--;
																			goto IL_07e2;
																			IL_043e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05e1;
																			IL_05e1:
																			num5 -= 2;
																			goto end_IL_0378;
																			IL_03fc:
																			if (15 >= b)
																			{
																				goto IL_04a5;
																			}
																			goto IL_06e6;
																			IL_06e6:
																			if (16 >= b)
																			{
																				goto IL_06f1;
																			}
																			goto IL_071b;
																			IL_06f1:
																			if (16 > b)
																			{
																				break;
																			}
																			goto IL_06ff;
																			IL_06ff:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0378;
																			IL_071b:
																			if (17 < b)
																			{
																				break;
																			}
																			goto IL_0729;
																			IL_0729:
																			if (17 > b)
																			{
																			}
																			break;
																			IL_04a5:
																			if (15 <= b)
																			{
																				goto IL_04b0;
																			}
																			goto IL_04c3;
																			IL_04b0:
																			num5--;
																			goto end_IL_0378;
																			IL_04c3:
																			if (14 < b)
																			{
																				break;
																			}
																			goto IL_0521;
																			IL_0521:
																			if (14 > b)
																			{
																				break;
																			}
																			goto IL_0763;
																			IL_0763:
																			array[num5 - 2] = 0;
																			goto IL_0777;
																		}
																		break;
																		IL_0348:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0378;
																continue;
																end_IL_0358:
																break;
															}
															continue;
															end_IL_0368:
															break;
														}
														continue;
														end_IL_0378:
														break;
													}
													continue;
												}
												num = 39;
												goto IL_0a9f;
												IL_0a9f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09fa:
												break;
											}
											continue;
											end_IL_0a0d:
											break;
										}
										continue;
										end_IL_0a17:
										break;
									}
									continue;
									end_IL_0a22:
									break;
								}
								continue;
								end_IL_0a32:
								break;
							}
							continue;
							end_IL_0a42:
							break;
						}
						continue;
						end_IL_0a52:
						break;
					}
					continue;
					end_IL_0a62:
					break;
				}
				continue;
				end_IL_0a72:
				break;
			}
		}
	}

	private static bool TryGetSwitchFromXml(IEnumerator ienumerator_0)
	{
		return ienumerator_0.MoveNext();
	}

	private static GorillaTagger getdefaultPermissionSetIDGetArray()
	{
		return GorillaTagger.Instance;
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 44;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getHostCanGenerateSafeArrayAsSystemArray.CustomAttributeFormatExceptionTokenMandatoryPolicy);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_020a:
																		if (b >= 1)
																		{
																			num = 68;
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01ed:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01dd:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01cd:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01ba:
																											if (2 <= b)
																											{
																												num = 95;
																												while (true)
																												{
																													if (num != 95)
																													{
																														if (num != 1076)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 7:
																															goto IL_01ba;
																														case 21:
																															goto IL_01cd;
																														case 38:
																															goto IL_01dd;
																														case 54:
																															goto IL_01ed;
																														case 68:
																															goto end_IL_01ed;
																														case 49:
																															goto IL_020a;
																														case 70:
																															goto end_IL_020a;
																														case 24:
																														case 72:
																															goto end_IL_021d;
																														case 28:
																														case 45:
																															goto IL_0238;
																														case 39:
																															goto IL_0243;
																														case 22:
																														case 34:
																															goto end_IL_01a7;
																														case 0:
																															goto IL_025f;
																														case 14:
																														case 17:
																															goto IL_026d;
																														case 37:
																														case 67:
																															goto IL_0285;
																														case 64:
																															goto IL_02ae;
																														case 53:
																														case 78:
																															goto IL_02c1;
																														case 51:
																															goto IL_02cc;
																														case 9:
																														case 63:
																															goto IL_02da;
																														case 10:
																															goto IL_02e8;
																														case 58:
																															goto IL_030b;
																														case 79:
																															goto IL_0317;
																														case 50:
																															goto IL_0325;
																														case 3:
																														case 32:
																															goto IL_0333;
																														case 83:
																															goto IL_034f;
																														case 85:
																															goto IL_035f;
																														case 87:
																															goto IL_0372;
																														case 84:
																															goto IL_0385;
																														case 65:
																															goto IL_03f3;
																														case 73:
																															goto IL_0406;
																														case 36:
																															goto IL_0411;
																														case 60:
																															goto IL_042f;
																														case 2:
																															goto IL_043a;
																														case 42:
																														case 88:
																															goto IL_0445;
																														case 57:
																															goto IL_0485;
																														case 56:
																															goto IL_0499;
																														case 1:
																														case 8:
																														case 18:
																														case 25:
																														case 27:
																														case 29:
																														case 31:
																														case 41:
																														case 43:
																														case 46:
																														case 48:
																														case 55:
																														case 59:
																														case 66:
																														case 74:
																														case 81:
																														case 86:
																															goto end_IL_01fa;
																														case 5:
																															goto IL_04cc;
																														case 13:
																															goto IL_04e3;
																														case 4:
																															goto IL_04fa;
																														case 11:
																														case 12:
																														case 15:
																														case 16:
																														case 19:
																														case 47:
																														case 69:
																														case 75:
																														case 77:
																														case 80:
																														case 82:
																															goto end_IL_022d;
																														case 26:
																															goto end_IL_0508;
																														case 71:
																															goto end_IL_051b;
																														case 40:
																															goto end_IL_0525;
																														case 23:
																															goto end_IL_0530;
																														case 52:
																															goto end_IL_0545;
																														case 44:
																															goto end_IL_055a;
																														case 35:
																															goto end_IL_056a;
																														case 20:
																															goto end_IL_057a;
																														case 30:
																														case 33:
																															goto end_IL_0585;
																														case 61:
																															goto end_IL_0595;
																														case 62:
																															goto end_IL_05a5;
																														case 6:
																														case 76:
																															goto IL_05c0;
																														}
																														continue;
																													}
																													goto IL_0385;
																													IL_0385:
																													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_03f3;
																													IL_03f3:
																													num5 -= 2;
																													goto end_IL_022d;
																													continue;
																													end_IL_01a7:
																													break;
																												}
																												break;
																											}
																											goto IL_0406;
																											IL_0406:
																											if (1 < b)
																											{
																												num = 48;
																												goto end_IL_01fa;
																											}
																											goto IL_0411;
																											IL_0411:
																											if (1 > b)
																											{
																											}
																											goto end_IL_01fa;
																										}
																										break;
																									}
																									goto IL_042f;
																									IL_0499:
																									num5--;
																									goto end_IL_022d;
																									IL_042f:
																									if (3 < b)
																									{
																										goto end_IL_01fa;
																									}
																									goto IL_043a;
																									IL_043a:
																									if (3 > b)
																									{
																										goto end_IL_01fa;
																									}
																									goto IL_0445;
																									IL_0445:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0485;
																									IL_0485:
																									array[num5 - 2] = 0;
																									goto IL_0499;
																								}
																								break;
																							}
																							goto IL_0285;
																							IL_035f:
																							num5--;
																							goto end_IL_022d;
																							IL_0285:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02ae;
																							IL_02ae:
																							ptr2 += 8;
																							goto IL_035f;
																						}
																						goto IL_0251;
																					}
																					goto IL_0238;
																					IL_0333:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_022d;
																					IL_0238:
																					if (6 >= b)
																					{
																						goto IL_0243;
																					}
																					goto IL_02c1;
																					IL_0243:
																					if (6 <= b)
																					{
																						goto end_IL_022d;
																					}
																					goto IL_0251;
																					IL_0251:
																					if (5 < b)
																					{
																						goto end_IL_01fa;
																					}
																					goto IL_025f;
																					IL_025f:
																					if (5 > b)
																					{
																						goto end_IL_01fa;
																					}
																					goto IL_026d;
																					IL_026d:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_022d;
																					IL_02c1:
																					if (7 >= b)
																					{
																						goto IL_02cc;
																					}
																					goto IL_0317;
																					IL_02cc:
																					if (7 > b)
																					{
																						goto end_IL_01fa;
																					}
																					goto IL_02da;
																					IL_02da:
																					array[num5] = 0;
																					goto IL_02e8;
																					IL_02e8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_030b;
																					IL_030b:
																					array2[num5] = null;
																					goto IL_034f;
																					IL_034f:
																					num5++;
																					goto IL_0372;
																					IL_0372:
																					ptr2 += 8;
																					goto end_IL_022d;
																					IL_0317:
																					if (8 < b)
																					{
																						goto end_IL_01fa;
																					}
																					goto IL_0325;
																					IL_0325:
																					if (8 > b)
																					{
																						goto end_IL_01fa;
																					}
																					goto IL_0333;
																					continue;
																					end_IL_01ed:
																					break;
																				}
																				continue;
																				end_IL_01fa:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04cc;
																		IL_04e3:
																		num5++;
																		num = 4;
																		goto IL_04fa;
																		IL_04fa:
																		ptr2 += 8;
																		goto end_IL_022d;
																		IL_04cc:
																		array[num5] = 0;
																		num = 13;
																		goto IL_04e3;
																		continue;
																		end_IL_020a:
																		break;
																	}
																	continue;
																	end_IL_021d:
																	break;
																}
																continue;
																end_IL_022d:
																break;
															}
															continue;
														}
														goto IL_05c0;
														IL_05c0:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0508:
														break;
													}
													continue;
													end_IL_051b:
													break;
												}
												continue;
												end_IL_0525:
												break;
											}
											continue;
											end_IL_0530:
											break;
										}
										continue;
										end_IL_0545:
										break;
									}
									continue;
									end_IL_055a:
									break;
								}
								continue;
								end_IL_056a:
								break;
							}
							continue;
							end_IL_057a:
							break;
						}
						continue;
						end_IL_0585:
						break;
					}
					continue;
					end_IL_0595:
					break;
				}
				continue;
				end_IL_05a5:
				break;
			}
		}
	}

	private void method_1()
	{
		int num = 308;
		num = 28;
		num = 63;
		num = 21;
		num = 28;
		num = 9;
		num = 29;
		num = 29;
		num = 212;
		num = 53;
		num = 377;
		num = 29;
		num = 53;
		num = 82;
		num = 1619;
		num = 1619;
		num = 1648;
		num = 540;
		num = 135;
		num = 0;
		int num2 = 0;
		do
		{
			num = num2;
			if (num == 1)
			{
				method_0();
				double num3 = 2.0;
				num3 = 2.0;
				int num4 = Convert.ToInt32(num3);
				num = num4;
				num2 = num;
			}
			if (num2 == 0)
			{
				num = 1;
				num2 = 1;
			}
			num = num2;
		}
		while (num != 2);
	}

	private static float BinaryCompatibilityMapTracingStatusChangedEventArgs(VRRig vrrig_0)
	{
		return vrrig_0.lerpValueBody;
	}

	static Class176()
	{
		int num = 5;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 15;
			while (true)
			{
				if (num != 15)
				{
					if (num == 996)
					{
						switch (num)
						{
						case 5:
							goto end_IL_0045;
						case 3:
						case 6:
						case 7:
						case 8:
							goto IL_006a;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 4:
							return;
						}
						continue;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				goto IL_006a;
				IL_006a:
				num = 2;
				return;
				continue;
				end_IL_0045:
				break;
			}
		}
	}

	private static void DBCSDecoderOriginalIssuer(IDisposable idisposable_0)
	{
		idisposable_0.Dispose();
	}

	private static void DependentOSMetadataMinorVersiongetDemandedResources(Class176 class176_1)
	{
		class176_1.method_0();
	}

	private static bool getInvalidHandleDateStart(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static bool smethod_8(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 == object_1;
	}

	private static VRRig MarshalTypeRefgetSandboxInterop(IEnumerator<VRRig> ienumerator_0)
	{
		return ienumerator_0.Current;
	}

	private static VRRig InvariantCultureIgnoreCasegetNumberLock(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	private void OnDisable()
	{
		DependentOSMetadataMinorVersiongetDemandedResources(this);
	}

	private static GorillaParent BeqAddArguments()
	{
		return GorillaParent.instance;
	}
}
