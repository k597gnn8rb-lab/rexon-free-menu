using System.Runtime.CompilerServices;
using Photon.Pun;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Reduce Ping", "Settings", "Increases network send rate.", false, 17, ModType.const_0, false)]
internal class Class138 : MonoBehaviour
{
	private int int_0 = -1;

	private int int_1 = -1;

	private static float float_0;

	private static int int_2;

	private static bool bool_0;

	private static int int_3;

	private static double double_0;

	private static bool bool_1;

	private static int int_4;

	private void OnEnable()
	{
		try
		{
			int num = 13;
			num = 45;
			num = 25;
			num = 9;
			num = 11;
			num = 3;
			num = 27;
			num = 79;
			num = 2133;
			num = 61;
			num = 3;
			num = 1232;
			num = 308;
			object obj = this;
			int sendRate = PhotonNetwork.SendRate;
			num = sendRate;
			((Class138)obj).int_0 = num;
			obj = this;
			int serializationRate = PhotonNetwork.SerializationRate;
			num = serializationRate;
			((Class138)obj).int_1 = num;
			num = 4;
			PhotonNetwork.SendRate = 1000;
			num = 2;
			PhotonNetwork.SerializationRate = 1000;
		}
		catch
		{
		}
	}

	private void Update()
	{
		try
		{
			PhotonNetwork.SendAllOutgoingCommands();
		}
		catch
		{
		}
	}

	private void OnDisable()
	{
		try
		{
			int num = 51;
			num = 315;
			num = 45;
			num = 51;
			num = 30;
			num = 63;
			num = 63;
			num = 155;
			num = 31;
			num = 390;
			num = 78;
			num = 31;
			num = 109;
			num = 2335;
			num = 2335;
			num = 2398;
			num = 327;
			num = 109;
			object obj = this;
			num = ((Class138)obj).int_0;
			if (num != -1)
			{
				obj = this;
				num = ((Class138)obj).int_0;
				PhotonNetwork.SendRate = num;
			}
			obj = this;
			num = ((Class138)obj).int_1;
			if (num != -1)
			{
				obj = this;
				num = ((Class138)obj).int_1;
				PhotonNetwork.SerializationRate = num;
			}
		}
		catch
		{
		}
	}

	private unsafe static int smethod_0(int int_5)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref QuestionmarkIsMethodDef.FallbackBuffergetSecurityRuleSet);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_028e:
														byte b = *ptr2;
														while (true)
														{
															IL_027e:
															ptr2++;
															while (true)
															{
																IL_026e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024b:
																			if (5 >= b)
																			{
																				num = 92;
																				while (true)
																				{
																					IL_023e:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_022e:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_0209:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_01f4:
																									array2[num5] = null;
																									num = 113;
																									while (true)
																									{
																										if (num != 113)
																										{
																											if (num != 1094)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 91:
																												goto IL_01f4;
																											case 97:
																												goto IL_0209;
																											case 67:
																											case 88:
																												goto IL_022e;
																											case 92:
																												goto IL_023e;
																											case 9:
																												goto IL_024b;
																											case 44:
																												goto IL_025e;
																											case 34:
																												goto IL_026e;
																											case 37:
																												goto IL_027e;
																											case 20:
																											case 78:
																												goto IL_028e;
																											case 59:
																											case 77:
																												goto IL_0299;
																											case 28:
																											case 90:
																												goto IL_02a4;
																											case 51:
																												goto IL_02b2;
																											case 82:
																												goto IL_02c0;
																											case 98:
																												goto IL_02d3;
																											case 52:
																											case 81:
																												goto IL_02de;
																											case 33:
																												goto IL_0307;
																											case 58:
																												goto IL_0315;
																											case 31:
																											case 62:
																												goto IL_033a;
																											case 6:
																												goto IL_0348;
																											case 27:
																											case 47:
																												goto IL_0356;
																											case 54:
																												goto IL_0378;
																											case 2:
																												goto IL_0386;
																											case 29:
																												goto IL_0394;
																											case 105:
																												goto IL_03a7;
																											case 93:
																											case 101:
																												goto IL_03c0;
																											case 102:
																												goto IL_03ef;
																											case 55:
																												goto IL_0402;
																											case 30:
																												goto IL_0410;
																											case 15:
																											case 57:
																												goto IL_041e;
																											case 25:
																											case 70:
																												goto IL_0429;
																											case 4:
																												goto IL_0437;
																											case 18:
																											case 40:
																												goto IL_0445;
																											case 89:
																												goto IL_0468;
																											case 21:
																												goto IL_0476;
																											case 63:
																												goto IL_0484;
																											case 79:
																												goto IL_0497;
																											case 23:
																											case 83:
																												goto IL_04a5;
																											case 7:
																												goto IL_04e5;
																											case 45:
																												goto IL_04f9;
																											case 64:
																											case 99:
																												goto IL_050c;
																											case 17:
																												goto IL_056e;
																											case 38:
																												goto IL_057e;
																											case 10:
																												goto IL_0589;
																											case 41:
																											case 68:
																												goto IL_0594;
																											case 74:
																											case 103:
																												goto IL_05ad;
																											case 39:
																												goto IL_05b8;
																											case 3:
																											case 5:
																											case 19:
																											case 24:
																											case 32:
																											case 35:
																											case 43:
																											case 46:
																											case 49:
																											case 53:
																											case 60:
																											case 61:
																											case 66:
																											case 69:
																											case 80:
																											case 84:
																											case 85:
																											case 96:
																											case 104:
																											case 106:
																												goto end_IL_025e;
																											case 1:
																											case 13:
																											case 16:
																											case 22:
																											case 26:
																											case 42:
																											case 48:
																											case 72:
																											case 73:
																											case 86:
																											case 94:
																											case 95:
																											case 100:
																												goto end_IL_01e1;
																											case 11:
																												goto end_IL_05d6;
																											case 50:
																												goto end_IL_05e9;
																											case 14:
																												goto end_IL_05f3;
																											case 36:
																												goto end_IL_05fe;
																											case 8:
																											case 56:
																												goto end_IL_0613;
																											case 71:
																												goto end_IL_0623;
																											case 65:
																											case 87:
																												goto end_IL_0633;
																											case 75:
																												goto end_IL_0643;
																											case 76:
																												goto end_IL_0653;
																											case 0:
																											case 12:
																												goto IL_0677;
																											}
																											continue;
																										}
																										num5++;
																										goto IL_03ef;
																										IL_03ef:
																										ptr2 += 8;
																										break;
																										continue;
																										end_IL_01e1:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_0299;
																					IL_0378:
																					array[num5] = 0;
																					goto IL_0386;
																					IL_0299:
																					if (2 < b)
																					{
																						goto IL_02a4;
																					}
																					goto IL_02d3;
																					IL_02a4:
																					if (3 < b)
																					{
																						goto IL_02b2;
																					}
																					goto IL_03a7;
																					IL_02b2:
																					if (4 < b)
																					{
																						goto end_IL_025e;
																					}
																					goto IL_02c0;
																					IL_02c0:
																					if (4 <= b)
																					{
																						break;
																					}
																					goto end_IL_025e;
																					IL_03a7:
																					if (3 > b)
																					{
																						num = 66;
																						goto end_IL_025e;
																					}
																					goto IL_03c0;
																					IL_0386:
																					num5++;
																					goto IL_0394;
																					IL_03c0:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					num = 95;
																					break;
																					IL_02d3:
																					if (2 <= b)
																					{
																						goto IL_02de;
																					}
																					num = 31;
																					goto IL_033a;
																					IL_02de:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0307;
																					IL_0307:
																					ptr2 += 8;
																					goto IL_0315;
																					IL_0315:
																					num5--;
																					num = 16;
																					break;
																					IL_0394:
																					ptr2 += 8;
																					break;
																					IL_033a:
																					if (1 < b)
																					{
																						goto end_IL_025e;
																					}
																					goto IL_0348;
																					IL_0348:
																					if (1 > b)
																					{
																						goto end_IL_025e;
																					}
																					goto IL_0356;
																					IL_0356:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 54;
																					goto IL_0378;
																				}
																				break;
																			}
																			goto IL_0402;
																			IL_05ad:
																			if (10 < b)
																			{
																				goto end_IL_025e;
																			}
																			goto IL_05b8;
																			IL_05b8:
																			if (10 > b)
																			{
																			}
																			goto end_IL_025e;
																			IL_0402:
																			if (8 >= b)
																			{
																				goto IL_0410;
																			}
																			goto IL_057e;
																			IL_0410:
																			if (8 > b)
																			{
																				goto IL_041e;
																			}
																			goto IL_050c;
																			IL_041e:
																			if (6 < b)
																			{
																				goto IL_0429;
																			}
																			goto IL_0497;
																			IL_0429:
																			if (7 < b)
																			{
																				goto end_IL_025e;
																			}
																			goto IL_0437;
																			IL_0437:
																			if (7 > b)
																			{
																				goto end_IL_025e;
																			}
																			goto IL_0445;
																			IL_0445:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0468;
																			IL_0468:
																			array[num5] = 0;
																			goto IL_0476;
																			IL_0476:
																			num5++;
																			goto IL_0484;
																			IL_0484:
																			ptr2 += 8;
																			break;
																			IL_0497:
																			if (6 > b)
																			{
																				goto end_IL_025e;
																			}
																			goto IL_04a5;
																			IL_04a5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e5;
																			IL_04e5:
																			array[num5 - 2] = 0;
																			goto IL_04f9;
																			IL_04f9:
																			num5--;
																			break;
																			IL_050c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_056e;
																			IL_056e:
																			num5 -= 2;
																			break;
																			IL_057e:
																			if (9 >= b)
																			{
																				goto IL_0589;
																			}
																			goto IL_05ad;
																			IL_0589:
																			if (9 > b)
																			{
																				goto end_IL_025e;
																			}
																			goto IL_0594;
																			IL_0594:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																		}
																		goto end_IL_026e;
																		continue;
																		end_IL_025e:
																		break;
																		IL_025e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_026e:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 12;
												goto IL_0677;
												IL_0677:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d6:
												break;
											}
											continue;
											end_IL_05e9:
											break;
										}
										continue;
										end_IL_05f3:
										break;
									}
									continue;
									end_IL_05fe:
									break;
								}
								continue;
								end_IL_0613:
								break;
							}
							continue;
							end_IL_0623:
							break;
						}
						continue;
						end_IL_0633:
						break;
					}
					continue;
					end_IL_0643:
					break;
				}
				continue;
				end_IL_0653:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FoundMonthPatternFlagSoapYear.setResponseXmlElementNameOn);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_038f:
														byte b = *ptr2;
														while (true)
														{
															IL_037f:
															ptr2++;
															while (true)
															{
																IL_036f:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_034f:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_033f:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_032f:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_0322:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_0315:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_0305:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_02d7:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 13;
																														while (true)
																														{
																															IL_02cb:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_02bb:
																																num5++;
																																while (true)
																																{
																																	IL_02a2:
																																	ptr2 += 8;
																																	num = 160;
																																	while (num != 160 && num == 1141)
																																	{
																																		switch (num)
																																		{
																																		case 69:
																																			goto IL_02a2;
																																		case 139:
																																			goto IL_02bb;
																																		case 13:
																																			goto IL_02cb;
																																		case 135:
																																			goto IL_02d7;
																																		case 55:
																																		case 97:
																																			goto IL_0305;
																																		case 80:
																																			goto IL_0315;
																																		case 42:
																																			goto IL_0322;
																																		case 98:
																																			goto IL_032f;
																																		case 121:
																																		case 123:
																																			goto IL_033f;
																																		case 51:
																																			goto IL_034f;
																																		case 22:
																																			goto IL_035f;
																																		case 120:
																																			goto IL_036f;
																																		case 114:
																																			goto IL_037f;
																																		case 10:
																																		case 70:
																																			goto IL_038f;
																																		case 101:
																																		case 118:
																																			goto IL_039a;
																																		case 68:
																																		case 127:
																																			goto IL_03aa;
																																		case 50:
																																			goto IL_03b8;
																																		case 142:
																																			goto IL_03c8;
																																		case 94:
																																		case 149:
																																			goto IL_03db;
																																		case 153:
																																			goto IL_0428;
																																		case 41:
																																			goto IL_043c;
																																		case 74:
																																		case 141:
																																			goto IL_044f;
																																		case 130:
																																			goto IL_048f;
																																		case 104:
																																			goto IL_04a3;
																																		case 3:
																																		case 140:
																																			goto IL_04bf;
																																		case 45:
																																		case 116:
																																			goto IL_04ca;
																																		case 53:
																																			goto IL_04d5;
																																		case 93:
																																			goto IL_04f6;
																																		case 40:
																																		case 54:
																																			goto IL_0504;
																																		case 62:
																																			goto IL_0512;
																																		case 47:
																																		case 84:
																																			goto IL_051d;
																																		case 66:
																																			goto IL_057f;
																																		case 77:
																																		case 107:
																																			goto IL_05a0;
																																		case 129:
																																			goto IL_05bc;
																																		case 79:
																																		case 144:
																																			goto IL_05c7;
																																		case 20:
																																			goto IL_05df;
																																		case 31:
																																		case 72:
																																			goto IL_05ed;
																																		case 56:
																																			goto IL_05f8;
																																		case 35:
																																			goto IL_0606;
																																		case 26:
																																		case 109:
																																			goto IL_0614;
																																		case 122:
																																			goto IL_063d;
																																		case 113:
																																			goto IL_064b;
																																		case 25:
																																			goto IL_0667;
																																		case 103:
																																		case 145:
																																			goto IL_0672;
																																		case 38:
																																			goto IL_0680;
																																		case 61:
																																		case 87:
																																			goto IL_068e;
																																		case 102:
																																			goto IL_069c;
																																		case 6:
																																			goto IL_06bd;
																																		case 119:
																																			goto IL_06cb;
																																		case 12:
																																		case 28:
																																			goto IL_06de;
																																		case 91:
																																			goto IL_071d;
																																		case 27:
																																			goto IL_0730;
																																		case 17:
																																		case 115:
																																			goto IL_073e;
																																		case 37:
																																		case 125:
																																			goto IL_0749;
																																		case 2:
																																			goto IL_0757;
																																		case 5:
																																		case 133:
																																			goto IL_0765;
																																		case 63:
																																			goto IL_078e;
																																		case 14:
																																			goto IL_07a7;
																																		case 85:
																																		case 124:
																																			goto IL_07b2;
																																		case 81:
																																			goto IL_07c0;
																																		case 58:
																																		case 95:
																																			goto IL_07ce;
																																		case 138:
																																			goto IL_07f0;
																																		case 8:
																																			goto IL_07fe;
																																		case 36:
																																			goto IL_080c;
																																		case 67:
																																		case 137:
																																			goto IL_081f;
																																		case 100:
																																			goto IL_085f;
																																		case 64:
																																			goto IL_0873;
																																		case 52:
																																		case 111:
																																			goto IL_0883;
																																		case 99:
																																			goto IL_08a1;
																																		case 65:
																																			goto IL_08b8;
																																		case 0:
																																		case 11:
																																		case 18:
																																		case 19:
																																		case 21:
																																		case 23:
																																		case 24:
																																		case 29:
																																		case 30:
																																		case 34:
																																		case 39:
																																		case 48:
																																		case 59:
																																		case 60:
																																		case 75:
																																		case 76:
																																		case 88:
																																		case 90:
																																		case 108:
																																		case 110:
																																		case 112:
																																		case 117:
																																		case 126:
																																		case 131:
																																		case 132:
																																		case 147:
																																		case 148:
																																		case 151:
																																		case 152:
																																			goto end_IL_035f;
																																		case 4:
																																		case 7:
																																		case 9:
																																		case 32:
																																		case 33:
																																		case 44:
																																		case 46:
																																		case 49:
																																		case 71:
																																		case 86:
																																		case 89:
																																		case 92:
																																		case 106:
																																		case 134:
																																		case 136:
																																		case 143:
																																		case 146:
																																			goto end_IL_028f;
																																		case 57:
																																			goto end_IL_08db;
																																		case 16:
																																			goto end_IL_08ee;
																																		case 128:
																																			goto end_IL_08f8;
																																		case 1:
																																			goto end_IL_0903;
																																		case 15:
																																		case 150:
																																			goto end_IL_0913;
																																		case 105:
																																			goto end_IL_0923;
																																		case 43:
																																		case 78:
																																			goto end_IL_0933;
																																		case 82:
																																			goto end_IL_0943;
																																		case 83:
																																			goto end_IL_0953;
																																		case 73:
																																		case 96:
																																			goto IL_096e;
																																		}
																																		continue;
																																		end_IL_028f:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_039a;
																											IL_03c8:
																											if (9 <= b)
																											{
																												break;
																											}
																											goto end_IL_035f;
																											IL_039a:
																											if (9 < b)
																											{
																												goto end_IL_035f;
																											}
																											goto IL_03c8;
																										}
																										break;
																									}
																									goto IL_03aa;
																									IL_043c:
																									num5--;
																									break;
																									IL_03aa:
																									if (11 < b)
																									{
																										goto end_IL_035f;
																									}
																									goto IL_03b8;
																									IL_03b8:
																									if (11 > b)
																									{
																										goto end_IL_035f;
																									}
																									goto IL_03db;
																									IL_03db:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									num = 153;
																									goto IL_0428;
																									IL_0428:
																									array[num5 - 2] = 0;
																									goto IL_043c;
																								}
																								break;
																							}
																							goto IL_044f;
																							IL_04a3:
																							num5--;
																							num = 32;
																							break;
																							IL_044f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_048f;
																							IL_048f:
																							array[num5 - 2] = 0;
																							goto IL_04a3;
																						}
																						break;
																					}
																					goto IL_04bf;
																					IL_057f:
																					num5 -= 2;
																					break;
																					IL_04bf:
																					if (14 < b)
																					{
																						goto IL_04ca;
																					}
																					goto IL_04f6;
																					IL_04ca:
																					if (15 < b)
																					{
																						num = 152;
																						goto end_IL_035f;
																					}
																					goto IL_04d5;
																					IL_04d5:
																					if (15 > b)
																					{
																					}
																					goto end_IL_035f;
																					IL_05a0:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_04f6:
																					if (14 > b)
																					{
																						goto IL_0504;
																					}
																					goto IL_05a0;
																					IL_0504:
																					if (13 < b)
																					{
																						goto end_IL_035f;
																					}
																					goto IL_0512;
																					IL_0512:
																					if (13 > b)
																					{
																						num = 147;
																						goto end_IL_035f;
																					}
																					goto IL_051d;
																					IL_051d:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_057f;
																				}
																				break;
																			}
																			goto IL_05bc;
																			IL_08a1:
																			ptr2 += 8;
																			num = 65;
																			goto IL_08b8;
																			IL_05bc:
																			if (8 <= b)
																			{
																				goto IL_05c7;
																			}
																			goto IL_05df;
																			IL_05c7:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_05df:
																			if (4 < b)
																			{
																				goto IL_05ed;
																			}
																			goto IL_0730;
																			IL_05ed:
																			if (6 < b)
																			{
																				goto IL_05f8;
																			}
																			num = 25;
																			goto IL_0667;
																			IL_05f8:
																			if (7 < b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_0606;
																			IL_0606:
																			if (7 > b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_0614;
																			IL_0614:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_063d;
																			IL_063d:
																			ptr2 += 8;
																			goto IL_064b;
																			IL_064b:
																			num5--;
																			break;
																			IL_08b8:
																			num5--;
																			break;
																			IL_0667:
																			if (6 > b)
																			{
																				goto IL_0672;
																			}
																			goto IL_06de;
																			IL_0672:
																			if (5 < b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_0680;
																			IL_0680:
																			if (5 > b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_068e;
																			IL_068e:
																			array[num5] = 5;
																			goto IL_069c;
																			IL_069c:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 6;
																			goto IL_06bd;
																			IL_06bd:
																			num5++;
																			goto IL_06cb;
																			IL_06cb:
																			ptr2 += 8;
																			break;
																			IL_06de:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_071d;
																			IL_071d:
																			num5 -= 3;
																			break;
																			IL_0730:
																			if (4 > b)
																			{
																				goto IL_073e;
																			}
																			goto IL_0883;
																			IL_073e:
																			if (2 < b)
																			{
																				goto IL_0749;
																			}
																			goto IL_07a7;
																			IL_0749:
																			if (3 < b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_0757;
																			IL_0757:
																			if (3 > b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_0765;
																			IL_0765:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_078e;
																			IL_078e:
																			array[num5 - 1] = 5;
																			break;
																			IL_07a7:
																			if (2 > b)
																			{
																				goto IL_07b2;
																			}
																			goto IL_081f;
																			IL_07b2:
																			if (1 < b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_07c0;
																			IL_07c0:
																			if (1 > b)
																			{
																				goto end_IL_035f;
																			}
																			goto IL_07ce;
																			IL_07ce:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 138;
																			goto IL_07f0;
																			IL_07f0:
																			array[num5] = 0;
																			goto IL_07fe;
																			IL_07fe:
																			num5++;
																			goto IL_080c;
																			IL_080c:
																			ptr2 += 8;
																			break;
																			IL_081f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_085f;
																			IL_085f:
																			array[num5 - 2] = 0;
																			goto IL_0873;
																			IL_0873:
																			num5--;
																			break;
																			IL_0883:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_08a1;
																		}
																		goto end_IL_036f;
																		continue;
																		end_IL_035f:
																		break;
																		IL_035f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_036f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_096e;
												IL_096e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08db:
												break;
											}
											continue;
											end_IL_08ee:
											break;
										}
										continue;
										end_IL_08f8:
										break;
									}
									continue;
									end_IL_0903:
									break;
								}
								continue;
								end_IL_0913:
								break;
							}
							continue;
							end_IL_0923:
							break;
						}
						continue;
						end_IL_0933:
						break;
					}
					continue;
					end_IL_0943:
					break;
				}
				continue;
				end_IL_0953:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_5, int int_6)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HandlerOffsetImportCspBlob.UnderlyingSystemTypeISponsor);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 34;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01c4:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_01b4:
																				if (b > 8)
																				{
																					num = 97;
																					while (num != 97 && num == 1078)
																					{
																						switch (num)
																						{
																						case 41:
																							goto IL_01b4;
																						case 47:
																							goto IL_01c4;
																						case 84:
																							goto end_IL_01c4;
																						case 34:
																							goto end_IL_01d4;
																						case 42:
																							goto end_IL_01e4;
																						case 32:
																							goto IL_01fa;
																						case 16:
																						case 23:
																							goto IL_0205;
																						case 7:
																							goto IL_0215;
																						case 36:
																							goto IL_0225;
																						case 18:
																							goto IL_0233;
																						case 28:
																						case 57:
																							goto IL_0241;
																						case 37:
																							goto IL_024f;
																						case 45:
																						case 58:
																							goto IL_0274;
																						case 56:
																							goto IL_0282;
																						case 62:
																							goto IL_0292;
																						case 53:
																							goto IL_029c;
																						case 44:
																							goto IL_02aa;
																						case 65:
																							goto IL_02bd;
																						case 46:
																							goto IL_02cb;
																						case 4:
																							goto IL_02d9;
																						case 66:
																							goto IL_02ec;
																						case 51:
																						case 73:
																							goto IL_02fc;
																						case 72:
																							goto IL_0325;
																						case 22:
																							goto IL_0333;
																						case 75:
																						case 77:
																							goto IL_0346;
																						case 55:
																						case 81:
																							goto IL_0359;
																						case 14:
																							goto IL_0399;
																						case 10:
																							goto IL_03ad;
																						case 52:
																						case 85:
																							goto IL_03c0;
																						case 88:
																							goto IL_03d8;
																						case 68:
																							goto IL_03e3;
																						case 74:
																							goto IL_03f1;
																						case 43:
																						case 89:
																							goto IL_0404;
																						case 87:
																							goto IL_0472;
																						case 90:
																							goto IL_0485;
																						case 2:
																						case 31:
																							goto IL_049b;
																						case 0:
																						case 11:
																						case 12:
																						case 17:
																						case 19:
																						case 21:
																						case 26:
																						case 30:
																						case 39:
																						case 40:
																						case 50:
																						case 54:
																						case 61:
																						case 63:
																						case 64:
																						case 71:
																						case 79:
																						case 82:
																							goto end_IL_01a1;
																						case 76:
																							goto IL_04d7;
																						case 13:
																							goto IL_04ee;
																						case 9:
																							goto IL_04fc;
																						case 15:
																						case 20:
																						case 25:
																						case 29:
																						case 35:
																						case 38:
																						case 49:
																						case 59:
																						case 67:
																						case 70:
																						case 86:
																							goto end_IL_01ef;
																						case 69:
																							goto end_IL_050a;
																						case 80:
																							goto end_IL_051d;
																						case 33:
																							goto end_IL_0527;
																						case 48:
																							goto end_IL_0532;
																						case 60:
																							goto end_IL_0547;
																						case 3:
																						case 8:
																							goto end_IL_055c;
																						case 83:
																							goto end_IL_056c;
																						case 1:
																						case 78:
																							goto end_IL_057c;
																						case 5:
																							goto end_IL_058c;
																						case 6:
																							goto end_IL_059c;
																						case 24:
																						case 27:
																							goto IL_05b7;
																						}
																						continue;
																						end_IL_01a1:
																						break;
																					}
																					break;
																				}
																				goto IL_01fa;
																				IL_02fc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0325;
																				IL_0325:
																				ptr2 += 8;
																				goto IL_0333;
																				IL_01fa:
																				if (4 < b)
																				{
																					goto IL_0205;
																				}
																				goto IL_0215;
																				IL_0205:
																				if (6 < b)
																				{
																					goto IL_0225;
																				}
																				goto IL_02bd;
																				IL_02bd:
																				if (6 <= b)
																				{
																					goto end_IL_01ef;
																				}
																				goto IL_02cb;
																				IL_02cb:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_02d9;
																				IL_02d9:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03c0;
																				IL_03c0:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_01ef;
																				IL_0225:
																				if (7 >= b)
																				{
																					goto IL_0233;
																				}
																				goto IL_0346;
																				IL_0233:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0241;
																				IL_0241:
																				array[num5] = 0;
																				goto IL_024f;
																				IL_024f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0292;
																				IL_0292:
																				array2[num5] = null;
																				goto IL_029c;
																				IL_029c:
																				num5++;
																				goto IL_02aa;
																				IL_02aa:
																				ptr2 += 8;
																				goto end_IL_01ef;
																				IL_0346:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0485;
																				IL_0485:
																				if (8 > b)
																				{
																					num = 17;
																					break;
																				}
																				goto IL_049b;
																				IL_0333:
																				num5--;
																				goto end_IL_01ef;
																				IL_049b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_01ef;
																				IL_0215:
																				if (4 > b)
																				{
																					goto IL_0274;
																				}
																				goto IL_02fc;
																				IL_0274:
																				if (2 < b)
																				{
																					goto IL_0282;
																				}
																				goto IL_03d8;
																				IL_0282:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_02ec;
																				IL_02ec:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0359;
																				IL_0359:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0399;
																				IL_0399:
																				array[num5 - 2] = 0;
																				goto IL_03ad;
																				IL_03ad:
																				num5--;
																				goto end_IL_01ef;
																				IL_03d8:
																				if (2 > b)
																				{
																					goto IL_03e3;
																				}
																				goto IL_0404;
																				IL_03e3:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03f1;
																				IL_03f1:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0404:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0472;
																				IL_0472:
																				num5 -= 2;
																				goto end_IL_01ef;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04d7;
																		IL_04fc:
																		ptr2 += 8;
																		goto end_IL_01ef;
																		IL_04ee:
																		num5++;
																		goto IL_04fc;
																		IL_04d7:
																		array[num5] = 0;
																		num = 13;
																		goto IL_04ee;
																		continue;
																		end_IL_01c4:
																		break;
																	}
																	continue;
																	end_IL_01d4:
																	break;
																}
																continue;
																end_IL_01e4:
																break;
															}
															continue;
															end_IL_01ef:
															break;
														}
														continue;
													}
													goto IL_05b7;
													IL_05b7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_050a:
													break;
												}
												continue;
												end_IL_051d:
												break;
											}
											continue;
											end_IL_0527:
											break;
										}
										continue;
										end_IL_0532:
										break;
									}
									continue;
									end_IL_0547:
									break;
								}
								continue;
								end_IL_055c:
								break;
							}
							continue;
							end_IL_056c:
							break;
						}
						continue;
						end_IL_057c:
						break;
					}
					continue;
					end_IL_058c:
					break;
				}
				continue;
				end_IL_059c:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_5)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 65;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 34;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenSourceModulus.EnumCustomAttributesUCOMIEnumConnections);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 25;
																while (true)
																{
																	IL_02b2:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0295:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0288:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0278:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0268:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												num = 12;
																												while (true)
																												{
																													IL_0245:
																													if (1 <= b)
																													{
																														while (true)
																														{
																															IL_022a:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_0211:
																																array[num5] = 0;
																																num = 80;
																																while (true)
																																{
																																	IL_01f8:
																																	num5++;
																																	num = 114;
																																	while (true)
																																	{
																																		if (num != 114)
																																		{
																																			if (num != 1095)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 80:
																																				goto IL_01f8;
																																			case 20:
																																				goto IL_0211;
																																			case 73:
																																			case 86:
																																				goto IL_022a;
																																			case 12:
																																				goto IL_0245;
																																			case 84:
																																			case 89:
																																				goto IL_0255;
																																			case 46:
																																				goto IL_0268;
																																			case 38:
																																				goto IL_0278;
																																			case 70:
																																				goto IL_0288;
																																			case 67:
																																				goto IL_0295;
																																			case 104:
																																				goto IL_02a2;
																																			case 25:
																																				goto IL_02b2;
																																			case 81:
																																				goto end_IL_02b2;
																																			case 32:
																																			case 97:
																																				goto end_IL_02c2;
																																			case 1:
																																			case 14:
																																				goto IL_02ff;
																																			case 17:
																																			case 24:
																																				goto IL_0312;
																																			case 2:
																																				goto IL_0320;
																																			case 55:
																																			case 62:
																																				goto IL_0345;
																																			case 8:
																																				goto IL_0350;
																																			case 69:
																																			case 78:
																																				goto IL_035e;
																																			case 59:
																																			case 83:
																																				goto IL_0376;
																																			case 88:
																																				goto IL_0389;
																																			case 82:
																																				goto IL_0393;
																																			case 7:
																																				goto end_IL_01e5;
																																			case 30:
																																			case 96:
																																				goto IL_03b4;
																																			case 94:
																																				goto IL_03dd;
																																			case 3:
																																				goto IL_03eb;
																																			case 23:
																																			case 98:
																																				goto IL_03fe;
																																			case 45:
																																			case 68:
																																				goto IL_0409;
																																			case 95:
																																				goto IL_0417;
																																			case 100:
																																				goto IL_042a;
																																			case 101:
																																				goto IL_043d;
																																			case 37:
																																			case 58:
																																				goto IL_044b;
																																			case 106:
																																				goto IL_0467;
																																			case 21:
																																			case 35:
																																				goto IL_0475;
																																			case 44:
																																			case 77:
																																				goto IL_0480;
																																			case 33:
																																				goto IL_048e;
																																			case 56:
																																			case 72:
																																				goto IL_049c;
																																			case 31:
																																				goto IL_04bf;
																																			case 71:
																																				goto IL_04cd;
																																			case 52:
																																				goto IL_04db;
																																			case 42:
																																				goto IL_04ee;
																																			case 48:
																																			case 63:
																																				goto IL_04fc;
																																			case 18:
																																				goto IL_053c;
																																			case 13:
																																				goto IL_0550;
																																			case 36:
																																			case 87:
																																				goto IL_0563;
																																			case 92:
																																				goto IL_05c5;
																																			case 0:
																																			case 4:
																																			case 5:
																																			case 10:
																																			case 15:
																																			case 19:
																																			case 22:
																																			case 26:
																																			case 39:
																																			case 41:
																																			case 43:
																																			case 47:
																																			case 50:
																																			case 53:
																																			case 54:
																																			case 57:
																																			case 61:
																																			case 74:
																																			case 75:
																																				goto end_IL_0245;
																																			case 9:
																																			case 27:
																																			case 28:
																																			case 29:
																																			case 40:
																																			case 51:
																																			case 79:
																																			case 90:
																																			case 91:
																																			case 93:
																																			case 99:
																																			case 102:
																																			case 103:
																																				goto end_IL_02db;
																																			case 60:
																																				goto end_IL_0601;
																																			case 6:
																																				goto end_IL_0614;
																																			case 85:
																																				goto end_IL_061e;
																																			case 16:
																																				goto end_IL_0629;
																																			case 34:
																																				goto end_IL_063e;
																																			case 64:
																																				goto end_IL_064e;
																																			case 11:
																																				goto end_IL_065e;
																																			case 76:
																																			case 107:
																																				goto end_IL_0669;
																																			case 65:
																																				goto end_IL_0679;
																																			case 66:
																																				goto end_IL_0689;
																																			case 49:
																																			case 105:
																																				goto IL_06ad;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_02db;
																																		continue;
																																		end_IL_01e5:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_03a1;
																													}
																													num = 4;
																													break;
																													continue;
																													end_IL_0245:
																													break;
																												}
																												break;
																												IL_0255:;
																											}
																											break;
																										}
																										goto IL_03b4;
																										IL_03eb:
																										num5--;
																										goto end_IL_02db;
																										IL_03b4:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03dd;
																										IL_03dd:
																										ptr2 += 8;
																										goto IL_03eb;
																									}
																									break;
																								}
																								goto IL_0345;
																								IL_042a:
																								if (4 <= b)
																								{
																									goto end_IL_02db;
																								}
																								break;
																								IL_0345:
																								if (3 >= b)
																								{
																									goto IL_0350;
																								}
																								goto IL_0376;
																								IL_0350:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_035e;
																								IL_035e:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02db;
																								IL_0376:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_042a;
																							}
																							break;
																						}
																						num = 17;
																						goto IL_0312;
																						IL_0393:
																						num5++;
																						goto IL_03a1;
																						IL_03a1:
																						ptr2 += 8;
																						goto end_IL_02db;
																						IL_0312:
																						array[num5] = 0;
																						goto IL_0320;
																						IL_0320:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0389;
																						IL_0389:
																						array2[num5] = null;
																						goto IL_0393;
																					}
																					break;
																				}
																				goto IL_02ff;
																				IL_05c5:
																				num5 -= 2;
																				goto end_IL_02db;
																				IL_02ff:
																				if (8 < b)
																				{
																					goto IL_03fe;
																				}
																				goto IL_0467;
																				IL_03fe:
																				if (9 < b)
																				{
																					goto IL_0409;
																				}
																				goto IL_043d;
																				IL_0409:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0417;
																				IL_0417:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_043d:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_044b;
																				IL_044b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02db;
																				IL_0467:
																				if (8 > b)
																				{
																					goto IL_0475;
																				}
																				goto IL_0563;
																				IL_0475:
																				if (6 < b)
																				{
																					goto IL_0480;
																				}
																				goto IL_04ee;
																				IL_0480:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_048e;
																				IL_048e:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_049c;
																				IL_049c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04bf;
																				IL_04bf:
																				array[num5] = 0;
																				goto IL_04cd;
																				IL_04cd:
																				num5++;
																				goto IL_04db;
																				IL_04db:
																				ptr2 += 8;
																				goto end_IL_02db;
																				IL_04ee:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_04fc;
																				IL_04fc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_053c;
																				IL_053c:
																				array[num5 - 2] = 0;
																				goto IL_0550;
																				IL_0550:
																				num5--;
																				goto end_IL_02db;
																				IL_0563:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05c5;
																			}
																			break;
																			IL_02a2:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 102;
																	goto end_IL_02db;
																	continue;
																	end_IL_02b2:
																	break;
																}
																continue;
																end_IL_02c2:
																break;
															}
															continue;
															end_IL_02db:
															break;
														}
														continue;
													}
													goto IL_06ad;
													IL_06ad:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0601:
													break;
												}
												continue;
												end_IL_0614:
												break;
											}
											continue;
											end_IL_061e:
											break;
										}
										continue;
										end_IL_0629:
										break;
									}
									continue;
									end_IL_063e:
									break;
								}
								continue;
								end_IL_064e:
								break;
							}
							continue;
							end_IL_065e:
							break;
						}
						continue;
						end_IL_0669:
						break;
					}
					continue;
					end_IL_0679:
					break;
				}
				continue;
				end_IL_0689:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_5)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_06d7:
						object[] array2 = new object[3];
						while (true)
						{
							IL_06c7:
							int[] array3 = new int[4];
							while (true)
							{
								IL_06b7:
								long[] array4 = new long[3];
								while (true)
								{
									IL_06a2:
									array3[0] = int_5;
									while (true)
									{
										IL_0697:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndOffsetStoreTransactionOperationType.flushEncoderPMDesignator);
										while (true)
										{
											IL_0684:
											byte* ptr2 = ptr;
											num = 59;
											while (true)
											{
												IL_0671:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d0:
														byte b = *ptr2;
														while (true)
														{
															IL_02c0:
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0290:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0283:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0273:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0263:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0256:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0202:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															num = 120;
																															while (true)
																															{
																																if (num != 120)
																																{
																																	if (num != 1101)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 1:
																																	case 58:
																																		goto IL_0202;
																																	case 54:
																																		goto IL_0236;
																																	case 6:
																																		goto IL_0246;
																																	case 47:
																																		goto IL_0256;
																																	case 55:
																																		goto IL_0263;
																																	case 84:
																																		goto IL_0273;
																																	case 107:
																																		goto IL_0283;
																																	case 53:
																																		goto IL_0290;
																																	case 33:
																																		goto IL_02a0;
																																	case 67:
																																		goto IL_02b0;
																																	case 32:
																																		goto IL_02c0;
																																	case 51:
																																	case 94:
																																		goto IL_02d0;
																																	case 44:
																																	case 103:
																																		goto IL_02e9;
																																	case 52:
																																		goto IL_0329;
																																	case 102:
																																		goto IL_033d;
																																	case 42:
																																	case 104:
																																		goto IL_0350;
																																	case 91:
																																	case 106:
																																		goto IL_0368;
																																	case 60:
																																		goto IL_0376;
																																	case 29:
																																	case 39:
																																		goto IL_0381;
																																	case 10:
																																		goto IL_03e3;
																																	case 40:
																																		goto IL_03f6;
																																	case 4:
																																		goto IL_0401;
																																	case 13:
																																		goto IL_040f;
																																	case 5:
																																	case 23:
																																		goto IL_041d;
																																	case 76:
																																		goto IL_0445;
																																	case 71:
																																	case 82:
																																		goto IL_0453;
																																	case 88:
																																		goto IL_0493;
																																	case 93:
																																		goto IL_04a7;
																																	case 50:
																																		goto IL_04ba;
																																	case 78:
																																		goto IL_04c5;
																																	case 2:
																																	case 49:
																																		goto IL_04d3;
																																	case 72:
																																		goto IL_04ef;
																																	case 64:
																																		goto IL_04fa;
																																	case 111:
																																		goto IL_051b;
																																	case 65:
																																		goto IL_0529;
																																	case 37:
																																		goto IL_0537;
																																	case 113:
																																		goto IL_054a;
																																	case 73:
																																	case 81:
																																		goto IL_0558;
																																	case 46:
																																		goto IL_0571;
																																	case 24:
																																		goto IL_057f;
																																	case 21:
																																		goto IL_058d;
																																	case 101:
																																		goto IL_05ae;
																																	case 56:
																																		goto IL_05c1;
																																	case 9:
																																	case 95:
																																		goto IL_05cf;
																																	case 38:
																																		goto IL_05dd;
																																	case 22:
																																	case 70:
																																		goto IL_05e8;
																																	case 57:
																																		goto IL_05ff;
																																	case 36:
																																		goto IL_0622;
																																	case 35:
																																		goto IL_0635;
																																	case 85:
																																		goto IL_0643;
																																	case 110:
																																		goto IL_0653;
																																	case 7:
																																	case 8:
																																	case 14:
																																	case 15:
																																	case 16:
																																	case 25:
																																	case 27:
																																	case 31:
																																	case 45:
																																	case 48:
																																	case 63:
																																	case 66:
																																	case 75:
																																	case 77:
																																	case 79:
																																	case 83:
																																	case 86:
																																	case 90:
																																	case 96:
																																	case 97:
																																	case 98:
																																	case 108:
																																	case 109:
																																	case 112:
																																		goto end_IL_0236;
																																	case 11:
																																	case 12:
																																	case 19:
																																	case 26:
																																	case 30:
																																	case 41:
																																	case 43:
																																	case 59:
																																	case 68:
																																	case 69:
																																	case 74:
																																	case 89:
																																	case 99:
																																	case 100:
																																		goto IL_0671;
																																	case 3:
																																		goto IL_0684;
																																	case 0:
																																		goto IL_0697;
																																	case 20:
																																		goto IL_06a2;
																																	case 34:
																																		goto IL_06b7;
																																	case 62:
																																	case 105:
																																		goto IL_06c7;
																																	case 87:
																																		goto IL_06d7;
																																	case 61:
																																	case 80:
																																		goto end_IL_01ef;
																																	case 17:
																																		goto end_IL_06e7;
																																	case 18:
																																		goto end_IL_06f7;
																																	case 28:
																																	case 92:
																																		goto IL_0712;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto IL_05ae;
																																IL_05ae:
																																num5--;
																																goto IL_0671;
																																continue;
																																end_IL_01ef:
																																break;
																															}
																															break;
																														}
																														goto end_IL_02b0;
																														continue;
																														end_IL_0236:
																														break;
																														IL_0236:;
																													}
																													break;
																													IL_0246:;
																												}
																												break;
																											}
																											num = 113;
																											goto IL_054a;
																											IL_057f:
																											num5++;
																											goto IL_058d;
																											IL_058d:
																											ptr2 += 8;
																											goto IL_0671;
																											IL_054a:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0558;
																											IL_0558:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0571;
																											IL_0571:
																											array[num5] = 0;
																											goto IL_057f;
																										}
																										break;
																									}
																									goto IL_0350;
																									IL_0350:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0671;
																								}
																								break;
																							}
																							goto IL_05c1;
																							IL_0653:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0671;
																							IL_05c1:
																							if (4 < b)
																							{
																								goto IL_05cf;
																							}
																							goto IL_0653;
																							IL_05cf:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_05dd;
																							IL_05dd:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_05e8;
																							IL_05e8:
																							array[num5] = 0;
																							num = 57;
																							goto IL_05ff;
																							IL_05ff:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0622;
																							IL_0622:
																							array2[num5] = null;
																							num = 35;
																							goto IL_0635;
																							IL_0635:
																							num5++;
																							goto IL_0643;
																							IL_0643:
																							ptr2 += 8;
																							goto IL_0671;
																						}
																						break;
																					}
																					goto IL_02e9;
																					IL_033d:
																					num5--;
																					goto IL_0671;
																					IL_02e9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0329;
																					IL_0329:
																					array[num5 - 2] = 0;
																					goto IL_033d;
																				}
																				break;
																			}
																			goto IL_0368;
																			IL_04fa:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0368:
																			if (9 >= b)
																			{
																				goto IL_0376;
																			}
																			goto IL_04ba;
																			IL_0376:
																			if (9 <= b)
																			{
																				goto IL_0381;
																			}
																			goto IL_03f6;
																			IL_0381:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03e3;
																			IL_03e3:
																			num5 -= 2;
																			goto IL_0671;
																			IL_03f6:
																			if (7 < b)
																			{
																				goto IL_0401;
																			}
																			goto IL_0445;
																			IL_0401:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_040f;
																			IL_040f:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_041d;
																			IL_041d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_051b;
																			IL_051b:
																			array[num5] = 0;
																			goto IL_0529;
																			IL_0529:
																			num5++;
																			goto IL_0537;
																			IL_0537:
																			ptr2 += 8;
																			goto IL_0671;
																			IL_0445:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0453;
																			IL_0453:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0493;
																			IL_0493:
																			array[num5 - 2] = 0;
																			goto IL_04a7;
																			IL_04a7:
																			num5--;
																			goto IL_0671;
																			IL_04ba:
																			if (10 >= b)
																			{
																				goto IL_04c5;
																			}
																			goto IL_04ef;
																			IL_04c5:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04d3;
																			IL_04d3:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0671;
																			IL_04ef:
																			if (11 < b)
																			{
																				num = 75;
																				break;
																			}
																			goto IL_04fa;
																		}
																		break;
																		IL_02a0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0671;
																continue;
																end_IL_02b0:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0712;
												IL_0712:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_06e7:
					break;
				}
				continue;
				end_IL_06f7:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_5)
	{
		int num = 115;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExplicitDeploymentMetadataEntryFieldId.IsSecuritySafeCriticalgetDeniedPermissions);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f4:
														byte b = *ptr2;
														while (true)
														{
															IL_02e4:
															ptr2++;
															while (true)
															{
																IL_02d4:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02b4:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02a4:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0297:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_028a:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_027a:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_022f:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_0216:
																																ptr2 += 8;
																																num = 125;
																																while (true)
																																{
																																	if (num != 125)
																																	{
																																		if (num != 1106)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 78:
																																			goto IL_0216;
																																		case 50:
																																		case 73:
																																			goto IL_022f;
																																		case 74:
																																			goto IL_025a;
																																		case 22:
																																		case 23:
																																			goto IL_026a;
																																		case 104:
																																			goto IL_027a;
																																		case 100:
																																			goto IL_028a;
																																		case 14:
																																		case 34:
																																			goto IL_0297;
																																		case 86:
																																			goto IL_02a4;
																																		case 40:
																																			goto IL_02b4;
																																		case 13:
																																			goto IL_02c4;
																																		case 62:
																																			goto IL_02d4;
																																		case 18:
																																			goto IL_02e4;
																																		case 30:
																																		case 52:
																																			goto IL_02f4;
																																		case 17:
																																		case 96:
																																			goto IL_02ff;
																																		case 28:
																																		case 106:
																																			goto IL_0317;
																																		case 38:
																																		case 103:
																																			goto IL_0322;
																																		case 32:
																																			goto IL_0330;
																																		case 21:
																																		case 53:
																																			goto IL_033e;
																																		case 31:
																																			goto IL_034e;
																																		case 110:
																																			goto IL_0361;
																																		case 57:
																																			goto IL_0384;
																																		case 71:
																																			goto IL_038e;
																																		case 80:
																																			goto IL_039c;
																																		case 105:
																																		case 117:
																																			goto IL_03af;
																																		case 46:
																																		case 81:
																																			goto IL_03ba;
																																		case 36:
																																		case 90:
																																			goto IL_03c5;
																																		case 98:
																																			goto IL_03dc;
																																		case 69:
																																			goto IL_03f8;
																																		case 75:
																																		case 77:
																																			goto IL_0406;
																																		case 54:
																																			goto IL_0422;
																																		case 5:
																																		case 87:
																																			goto IL_0430;
																																		case 49:
																																		case 108:
																																			goto IL_043b;
																																		case 25:
																																			goto IL_0449;
																																		case 1:
																																		case 72:
																																			goto IL_0457;
																																		case 8:
																																			goto IL_047a;
																																		case 48:
																																			goto IL_0488;
																																		case 33:
																																			goto IL_0496;
																																		case 83:
																																			goto IL_04a9;
																																		case 65:
																																		case 102:
																																			goto IL_04b7;
																																		case 26:
																																			goto IL_04f7;
																																		case 94:
																																			goto IL_050b;
																																		case 42:
																																		case 97:
																																			goto IL_051e;
																																		case 6:
																																			goto IL_0580;
																																		case 15:
																																			goto IL_05a6;
																																		case 63:
																																		case 118:
																																			goto IL_05b4;
																																		case 10:
																																			goto IL_05cd;
																																		case 29:
																																			goto IL_05db;
																																		case 7:
																																			goto IL_05e9;
																																		case 20:
																																		case 60:
																																			goto IL_05fc;
																																		case 92:
																																			goto IL_063c;
																																		case 93:
																																			goto IL_0650;
																																		case 0:
																																		case 3:
																																		case 4:
																																		case 9:
																																		case 12:
																																		case 27:
																																		case 37:
																																		case 39:
																																		case 43:
																																		case 44:
																																		case 45:
																																		case 47:
																																		case 64:
																																		case 66:
																																		case 68:
																																		case 76:
																																		case 82:
																																		case 85:
																																		case 95:
																																		case 107:
																																		case 112:
																																		case 116:
																																			goto end_IL_025a;
																																		case 11:
																																		case 35:
																																		case 51:
																																		case 55:
																																		case 56:
																																		case 61:
																																		case 70:
																																		case 79:
																																		case 88:
																																		case 89:
																																		case 99:
																																		case 101:
																																		case 109:
																																		case 113:
																																			goto end_IL_0203;
																																		case 41:
																																			goto end_IL_067c;
																																		case 67:
																																			goto end_IL_068f;
																																		case 58:
																																			goto end_IL_0699;
																																		case 16:
																																			goto end_IL_06a4;
																																		case 2:
																																		case 19:
																																			goto end_IL_06b9;
																																		case 59:
																																			goto end_IL_06c9;
																																		case 84:
																																		case 111:
																																			goto end_IL_06d9;
																																		case 114:
																																			goto end_IL_06e9;
																																		case 115:
																																			goto end_IL_06f9;
																																		case 24:
																																		case 91:
																																			goto IL_0714;
																																		}
																																		continue;
																																	}
																																	num5--;
																																	break;
																																	continue;
																																	end_IL_0203:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02d4;
																														continue;
																														end_IL_025a:
																														break;
																														IL_025a:;
																													}
																													break;
																													IL_026a:;
																												}
																												break;
																											}
																											goto IL_05a6;
																											IL_05e9:
																											ptr2 += 8;
																											goto end_IL_02d4;
																											IL_05a6:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_05b4;
																											IL_05b4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_05cd;
																											IL_05cd:
																											array[num5] = 0;
																											goto IL_05db;
																											IL_05db:
																											num5++;
																											goto IL_05e9;
																										}
																										break;
																									}
																									goto IL_02ff;
																									IL_02ff:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02d4;
																								}
																								break;
																							}
																							goto IL_0317;
																							IL_034e:
																							if (4 <= b)
																							{
																								goto end_IL_02d4;
																							}
																							break;
																							IL_0317:
																							if (4 < b)
																							{
																								goto IL_0322;
																							}
																							goto IL_034e;
																							IL_0322:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0330;
																							IL_0330:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_033e;
																							IL_033e:
																							array[num5] = 0;
																							goto IL_0361;
																							IL_0361:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0384;
																							IL_0384:
																							array2[num5] = null;
																							goto IL_038e;
																							IL_038e:
																							num5++;
																							goto IL_039c;
																							IL_039c:
																							ptr2 += 8;
																							goto end_IL_02d4;
																						}
																						break;
																					}
																					goto IL_05fc;
																					IL_0650:
																					num5--;
																					goto end_IL_02d4;
																					IL_05fc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_063c;
																					IL_063c:
																					array[num5 - 2] = 0;
																					goto IL_0650;
																				}
																				break;
																			}
																			goto IL_03af;
																			IL_050b:
																			num5--;
																			goto end_IL_02d4;
																			IL_03af:
																			if (9 < b)
																			{
																				goto IL_03ba;
																			}
																			goto IL_0422;
																			IL_03ba:
																			if (10 < b)
																			{
																				goto IL_03c5;
																			}
																			goto IL_03f8;
																			IL_03c5:
																			if (11 < b)
																			{
																				break;
																			}
																			num = 98;
																			goto IL_03dc;
																			IL_051e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0580;
																			IL_03dc:
																			if (11 > b)
																			{
																				num = 68;
																			}
																			break;
																			IL_0580:
																			num5 -= 2;
																			goto end_IL_02d4;
																			IL_03f8:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0406;
																			IL_0406:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02d4;
																			IL_0422:
																			if (9 > b)
																			{
																				goto IL_0430;
																			}
																			goto IL_051e;
																			IL_0430:
																			if (7 < b)
																			{
																				goto IL_043b;
																			}
																			goto IL_04a9;
																			IL_043b:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0449;
																			IL_0449:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0457;
																			IL_0457:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_047a;
																			IL_047a:
																			array[num5] = 0;
																			goto IL_0488;
																			IL_0488:
																			num5++;
																			goto IL_0496;
																			IL_0496:
																			ptr2 += 8;
																			goto end_IL_02d4;
																			IL_04a9:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04b7;
																			IL_04b7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04f7;
																			IL_04f7:
																			array[num5 - 2] = 0;
																			goto IL_050b;
																		}
																		break;
																		IL_02c4:;
																	}
																}
																else
																{
																	num = 45;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d4:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0714;
												IL_0714:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067c:
												break;
											}
											continue;
											end_IL_068f:
											break;
										}
										continue;
										end_IL_0699:
										break;
									}
									continue;
									end_IL_06a4:
									break;
								}
								continue;
								end_IL_06b9:
								break;
							}
							continue;
							end_IL_06c9:
							break;
						}
						continue;
						end_IL_06d9:
						break;
					}
					continue;
					end_IL_06e9:
					break;
				}
				continue;
				end_IL_06f9:
				break;
			}
		}
	}

	private static int smethod_6(int int_5)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_5;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_7()
	{
		int num = 116;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 30;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AsCyLdelemU.RegistryPermissionAccessAccessAllowedCallback);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 59;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0314:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02f4:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02e4:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02d7:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02c7:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_02b7:
																												if (6 > b)
																												{
																													while (5 >= b)
																													{
																														while (5 <= b)
																														{
																															num = 153;
																															while (true)
																															{
																																if (num != 153)
																																{
																																	if (num != 1134)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 48:
																																		goto IL_0294;
																																	case 125:
																																		goto IL_02a7;
																																	case 22:
																																		goto IL_02b7;
																																	case 98:
																																		goto IL_02c7;
																																	case 58:
																																	case 109:
																																		goto IL_02d7;
																																	case 1:
																																		goto IL_02e4;
																																	case 68:
																																		goto IL_02f4;
																																	case 93:
																																		goto IL_0304;
																																	case 71:
																																		goto IL_0314;
																																	case 51:
																																		goto end_IL_0314;
																																	case 19:
																																	case 92:
																																		goto end_IL_0324;
																																	case 52:
																																		goto IL_033f;
																																	case 43:
																																	case 78:
																																		goto IL_034f;
																																	case 49:
																																		goto IL_038e;
																																	case 81:
																																	case 99:
																																		goto IL_03a1;
																																	case 63:
																																		goto IL_03ac;
																																	case 101:
																																		goto IL_03bf;
																																	case 57:
																																		goto IL_03ca;
																																	case 76:
																																		goto IL_03da;
																																	case 84:
																																		goto IL_03f1;
																																	case 27:
																																	case 110:
																																		goto IL_0404;
																																	case 111:
																																		goto IL_0417;
																																	case 97:
																																		goto IL_0425;
																																	case 50:
																																	case 89:
																																		goto IL_0433;
																																	case 20:
																																		goto IL_0441;
																																	case 2:
																																	case 107:
																																		goto IL_044f;
																																	case 8:
																																		goto IL_04ba;
																																	case 26:
																																		goto IL_04cd;
																																	case 65:
																																		goto IL_04db;
																																	case 95:
																																	case 114:
																																		goto IL_04ee;
																																	case 118:
																																		goto IL_050a;
																																	case 4:
																																	case 12:
																																		goto IL_0518;
																																	case 0:
																																	case 132:
																																		goto IL_0536;
																																	case 82:
																																		goto IL_055f;
																																	case 100:
																																	case 137:
																																		goto IL_0578;
																																	case 73:
																																		goto IL_05b8;
																																	case 3:
																																		goto IL_05cc;
																																	case 141:
																																		goto IL_05e8;
																																	case 123:
																																	case 142:
																																		goto IL_05f8;
																																	case 14:
																																		goto IL_0638;
																																	case 6:
																																		goto IL_064c;
																																	case 143:
																																		goto IL_065f;
																																	case 54:
																																		goto IL_066d;
																																	case 105:
																																	case 144:
																																		goto IL_0689;
																																	case 29:
																																	case 90:
																																		goto IL_0697;
																																	case 33:
																																		goto IL_06a5;
																																	case 13:
																																	case 122:
																																		goto IL_06b3;
																																	case 42:
																																		goto IL_06f7;
																																	case 117:
																																		goto IL_070b;
																																	case 69:
																																		goto end_IL_0281;
																																	case 62:
																																	case 74:
																																		goto IL_0729;
																																	case 31:
																																		goto IL_0737;
																																	case 40:
																																	case 127:
																																		goto IL_074a;
																																	case 38:
																																		goto IL_0758;
																																	case 5:
																																		goto IL_077b;
																																	case 16:
																																		goto IL_0785;
																																	case 133:
																																		goto IL_079c;
																																	case 61:
																																	case 146:
																																		goto IL_07af;
																																	case 77:
																																		goto IL_07cd;
																																	case 10:
																																		goto IL_07db;
																																	case 91:
																																		goto IL_07ee;
																																	case 60:
																																		goto IL_07fc;
																																	case 36:
																																		goto IL_0814;
																																	case 85:
																																		goto IL_0822;
																																	case 55:
																																		goto IL_083e;
																																	case 139:
																																		goto IL_0849;
																																	case 32:
																																	case 104:
																																		goto IL_0854;
																																	case 45:
																																		goto IL_087d;
																																	case 119:
																																		goto IL_088b;
																																	case 23:
																																	case 79:
																																		goto IL_089b;
																																	case 7:
																																	case 9:
																																	case 17:
																																	case 21:
																																	case 25:
																																	case 28:
																																	case 39:
																																	case 44:
																																	case 56:
																																	case 83:
																																	case 86:
																																	case 87:
																																	case 88:
																																	case 94:
																																	case 96:
																																	case 103:
																																	case 108:
																																	case 113:
																																	case 120:
																																	case 124:
																																	case 126:
																																	case 129:
																																	case 131:
																																	case 135:
																																	case 140:
																																	case 145:
																																		goto end_IL_0294;
																																	case 11:
																																	case 15:
																																	case 24:
																																	case 34:
																																	case 35:
																																	case 37:
																																	case 41:
																																	case 46:
																																	case 47:
																																	case 59:
																																	case 67:
																																	case 70:
																																	case 72:
																																	case 80:
																																	case 130:
																																	case 134:
																																	case 136:
																																	case 138:
																																		goto end_IL_0334;
																																	case 75:
																																		goto end_IL_08c3;
																																	case 112:
																																		goto end_IL_08d6;
																																	case 53:
																																		goto end_IL_08e9;
																																	case 128:
																																		goto end_IL_08f4;
																																	case 18:
																																	case 106:
																																		goto end_IL_0904;
																																	case 64:
																																		goto end_IL_0914;
																																	case 30:
																																		goto end_IL_0924;
																																	case 121:
																																		goto end_IL_0934;
																																	case 115:
																																		goto end_IL_0944;
																																	case 116:
																																		goto end_IL_094f;
																																	case 66:
																																	case 102:
																																		goto IL_096a;
																																	}
																																	continue;
																																}
																																goto IL_07ee;
																																IL_0814:
																																num5++;
																																goto IL_0822;
																																IL_0822:
																																ptr2 += 8;
																																num = 47;
																																goto end_IL_0334;
																																IL_07ee:
																																array[num5] = 5;
																																goto IL_07fc;
																																IL_07fc:
																																array2[num5] = array5[*(int*)(ptr2 + num3)];
																																goto IL_0814;
																																continue;
																																end_IL_0281:
																																break;
																															}
																															goto IL_071e;
																															continue;
																															end_IL_0294:
																															break;
																															IL_0294:;
																														}
																														break;
																														IL_02a7:;
																													}
																													break;
																												}
																												goto IL_034f;
																												IL_038e:
																												num5 -= 3;
																												goto end_IL_0334;
																												IL_034f:
																												((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_038e;
																											}
																											break;
																										}
																										goto IL_083e;
																										IL_088b:
																										num5--;
																										goto end_IL_0334;
																										IL_083e:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0849;
																										IL_0849:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0854;
																										IL_0854:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_087d;
																										IL_087d:
																										ptr2 += 8;
																										goto IL_088b;
																									}
																									break;
																								}
																								goto IL_033f;
																								IL_07cd:
																								ptr2 += 8;
																								goto IL_07db;
																								IL_033f:
																								if (4 > b)
																								{
																									goto IL_03bf;
																								}
																								goto IL_07af;
																								IL_03bf:
																								if (2 >= b)
																								{
																									goto IL_03ca;
																								}
																								goto IL_03da;
																								IL_03ca:
																								if (2 > b)
																								{
																									goto IL_0404;
																								}
																								goto IL_05f8;
																								IL_0404:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_050a;
																								IL_050a:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0518;
																								IL_0518:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_05e8;
																								IL_05e8:
																								array[num5] = 0;
																								goto IL_065f;
																								IL_065f:
																								num5++;
																								goto IL_066d;
																								IL_066d:
																								ptr2 += 8;
																								num = 24;
																								goto end_IL_0334;
																								IL_05f8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0638;
																								IL_0638:
																								array[num5 - 2] = 0;
																								goto IL_064c;
																								IL_064c:
																								num5--;
																								goto end_IL_0334;
																								IL_03da:
																								if (3 < b)
																								{
																									break;
																								}
																								num = 84;
																								goto IL_03f1;
																								IL_07db:
																								num5--;
																								goto end_IL_0334;
																								IL_03f1:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0536;
																								IL_0536:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_055f;
																								IL_055f:
																								array[num5 - 1] = 5;
																								goto end_IL_0334;
																								IL_07af:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_07cd;
																							}
																							break;
																						}
																						goto IL_089b;
																						IL_089b:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0334;
																					}
																					break;
																				}
																				goto IL_03a1;
																				IL_04db:
																				if (15 <= b)
																				{
																				}
																				break;
																				IL_03a1:
																				if (12 >= b)
																				{
																					goto IL_03ac;
																				}
																				goto IL_0417;
																				IL_03ac:
																				if (12 <= b)
																				{
																					goto IL_0578;
																				}
																				goto IL_0689;
																				IL_0689:
																				if (10 < b)
																				{
																					goto IL_0697;
																				}
																				goto IL_071e;
																				IL_0697:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_06a5;
																				IL_06a5:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_06b3;
																				IL_06b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_06f7;
																				IL_06f7:
																				array[num5 - 2] = 0;
																				goto IL_070b;
																				IL_070b:
																				num5--;
																				goto end_IL_0334;
																				IL_071e:
																				if (10 > b)
																				{
																					goto IL_0729;
																				}
																				goto IL_074a;
																				IL_0729:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0737;
																				IL_0737:
																				if (9 <= b)
																				{
																					goto end_IL_0334;
																				}
																				break;
																				IL_074a:
																				array[num5] = 0;
																				goto IL_0758;
																				IL_0758:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_077b;
																				IL_077b:
																				array2[num5] = null;
																				goto IL_0785;
																				IL_0785:
																				num5++;
																				num = 133;
																				goto IL_079c;
																				IL_079c:
																				ptr2 += 8;
																				goto end_IL_0334;
																				IL_0578:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05b8;
																				IL_05b8:
																				array[num5 - 2] = 0;
																				goto IL_05cc;
																				IL_05cc:
																				num5--;
																				num = 35;
																				goto end_IL_0334;
																				IL_0417:
																				if (14 >= b)
																				{
																					goto IL_0425;
																				}
																				goto IL_04cd;
																				IL_0425:
																				if (14 > b)
																				{
																					goto IL_0433;
																				}
																				goto IL_04ee;
																				IL_0433:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0441;
																				IL_0441:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_044f;
																				IL_044f:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 8;
																				goto IL_04ba;
																				IL_04ba:
																				num5 -= 2;
																				goto end_IL_0334;
																				IL_04ee:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0334;
																				IL_04cd:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_04db;
																			}
																			break;
																			IL_0304:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0334;
																	continue;
																	end_IL_0314:
																	break;
																}
																continue;
																end_IL_0324:
																break;
															}
															continue;
															end_IL_0334:
															break;
														}
														continue;
													}
													goto IL_096a;
													IL_096a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08c3:
													break;
												}
												continue;
												end_IL_08d6:
												break;
											}
											continue;
											end_IL_08e9:
											break;
										}
										continue;
										end_IL_08f4:
										break;
									}
									continue;
									end_IL_0904:
									break;
								}
								continue;
								end_IL_0914:
								break;
							}
							continue;
							end_IL_0924:
							break;
						}
						continue;
						end_IL_0934:
						break;
					}
					continue;
					end_IL_0944:
					break;
				}
				continue;
				end_IL_094f:
				break;
			}
		}
	}

	static Class138()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 2;
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 2:
							case 5:
								goto end_IL_0039;
							case 3:
								goto end_IL_0046;
							case 4:
								goto end_IL_005b;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_005b:
				break;
			}
		}
	}
}
