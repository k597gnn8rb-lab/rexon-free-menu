using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Mega Charge Blaster Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns mega charge blasters.", false, 18, ModType.const_0, false)]
internal class Class100 : Class93
{
	private static float float_0;

	private static float float_1;

	private static double double_1;

	private static int int_3;

	private static float float_2;

	private static int int_4;

	private static IntPtr[] setFilterLevelObjectManager;

	private static IntPtr[] PrelinkAllStop;

	private static IntPtr[] RightToLeftArabicIsolatedStorageScope;

	private static IntPtr[] AssemblyFlagsIPrincipal;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002a, IL_0038, IL_0048, IL_03c5, IL_03d8, IL_03eb, IL_03fb, IL_040b, IL_0418, IL_042b, IL_043b, IL_044b, IL_045b, IL_046b, IL_047b, IL_048b, IL_0496, IL_04a4, IL_04b4, IL_04f6, IL_0509, IL_054e, IL_0561, IL_057a, IL_0588, IL_0593, IL_05a3, IL_05ac, IL_05ba, IL_05c8, IL_05e4, IL_05f8, IL_060b, IL_0623, IL_0631, IL_063c, IL_065a, IL_0668, IL_067b, IL_0686, IL_0699, IL_06a7, IL_06b5, IL_06d2, IL_0721, IL_072b, IL_0758, IL_076c, IL_077a, IL_078d, IL_0798, IL_07a6, IL_07b4, IL_07d1, IL_07df, IL_07e8, IL_081a, IL_0833, IL_0846, IL_0854, IL_086c, IL_087a, IL_088d, IL_089b, IL_08a6, IL_08b4, IL_08f2, IL_0905, IL_0913, IL_0923, IL_093c, IL_094a, IL_0958, IL_096b, IL_097f, IL_09bc, IL_09ca, IL_09f3, IL_0a01, IL_0a14, IL_0a32, IL_0a56, IL_0a6e, IL_0a81, IL_0a94, IL_0aa2, IL_0ab0, IL_0abe, IL_0ae1, IL_0aeb, IL_0b02, IL_0b1e, IL_0b2c, IL_0b37, IL_0b45, IL_0b85, IL_0b99, IL_0bb5, IL_0bc3, IL_0bd1, IL_0c33, IL_0c46, IL_0c54, IL_0c5f, IL_0c6d, IL_0cad, IL_0cc1, IL_0cd4, IL_0ce2, IL_0cf0, IL_0d39, IL_0d4d, IL_0d60, IL_0d7c, IL_0d90, IL_0dcf, IL_0de8, IL_0e0a, IL_0e18, IL_0e26, IL_0e34, IL_0e47, IL_0e51, IL_0e65, IL_0e7e, IL_0e97, IL_0ea7, IL_0eb7, IL_0ed0, IL_0ee0, IL_0ef0, IL_0f00, IL_0f1b are reachable both inside and outside the pinned region starting at IL_0f15. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 154;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef3 = default(int);
				ref int reference = ref __rxRef3;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0f00:
						num2 = 1;
						while (true)
						{
							IL_0ef0:
							num3 = num2 * 4;
							while (true)
							{
								IL_0ee0:
								num4 = num2 * 8;
								while (true)
								{
									IL_0ed0:
									array2 = new byte[4];
									while (true)
									{
										IL_0eb7:
										array3 = new object[4];
										num = 152;
										while (true)
										{
											IL_0ea7:
											array4 = new int[4];
											while (true)
											{
												IL_0e97:
												array5 = new int[6];
												while (true)
												{
													IL_0e7e:
													array6 = new long[4];
													num = 94;
													while (true)
													{
														IL_0e65:
														array7 = new object[15];
														num = 182;
														while (true)
														{
															IL_0e51:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ShaEncodeOID.permissionSetIDSafeProcessHandle);
															num = 185;
															while (true)
															{
																IL_0e47:
																ptr2 = ptr;
																while (true)
																{
																	IL_0e34:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_048b:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_047b:
																				ptr2++;
																				while (true)
																				{
																					IL_046b:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_044b:
																								if (11 >= b)
																								{
																									num = 194;
																									while (true)
																									{
																										IL_043b:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_042b:
																												if (5 >= b)
																												{
																													while (true)
																													{
																														IL_0418:
																														if (5 > b)
																														{
																															num = 137;
																															while (true)
																															{
																																IL_040b:
																																if (2 >= b)
																																{
																																	while (true)
																																	{
																																		IL_03fb:
																																		if (2 > b)
																																		{
																																			while (1 >= b)
																																			{
																																				while (1 > b)
																																				{
																																					num = 227;
																																					while (num != 227)
																																					{
																																						if (num != 1208)
																																						{
																																							goto IL_0d7c;
																																						}
																																						switch (num)
																																						{
																																						case 154:
																																							break;
																																						default:
																																							continue;
																																						case 197:
																																							goto IL_03d8;
																																						case 106:
																																						case 125:
																																							goto IL_03eb;
																																						case 177:
																																							goto IL_03fb;
																																						case 36:
																																						case 137:
																																							goto IL_040b;
																																						case 198:
																																							goto IL_0418;
																																						case 131:
																																							goto IL_042b;
																																						case 194:
																																							goto IL_043b;
																																						case 65:
																																							goto IL_044b;
																																						case 112:
																																							goto IL_045b;
																																						case 135:
																																							goto IL_046b;
																																						case 82:
																																							goto IL_047b;
																																						case 113:
																																						case 146:
																																							goto IL_048b;
																																						case 0:
																																							goto IL_04a4;
																																						case 14:
																																						case 76:
																																							goto IL_04b4;
																																						case 84:
																																							goto IL_04f6;
																																						case 24:
																																						case 108:
																																							goto IL_0509;
																																						case 31:
																																						case 111:
																																							goto IL_054e;
																																						case 140:
																																							goto IL_0561;
																																						case 147:
																																							goto IL_057a;
																																						case 23:
																																						case 48:
																																							goto IL_0588;
																																						case 132:
																																							goto IL_0593;
																																						case 118:
																																						case 164:
																																							goto IL_05ac;
																																						case 72:
																																							goto IL_05ba;
																																						case 1:
																																						case 102:
																																							goto IL_05c8;
																																						case 174:
																																							goto IL_05e4;
																																						case 81:
																																							goto IL_05f8;
																																						case 130:
																																						case 178:
																																							goto IL_060b;
																																						case 107:
																																						case 180:
																																							goto IL_0623;
																																						case 13:
																																							goto IL_0631;
																																						case 18:
																																						case 68:
																																							goto IL_063c;
																																						case 92:
																																							goto IL_065a;
																																						case 104:
																																							goto IL_0668;
																																						case 158:
																																							goto IL_067b;
																																						case 3:
																																							goto IL_0686;
																																						case 126:
																																							goto IL_0699;
																																						case 39:
																																							goto IL_06a7;
																																						case 121:
																																						case 144:
																																							goto IL_06b5;
																																						case 100:
																																							goto IL_076c;
																																						case 138:
																																							goto IL_077a;
																																						case 28:
																																							goto IL_078d;
																																						case 66:
																																						case 136:
																																							goto IL_0798;
																																						case 124:
																																							goto IL_07a6;
																																						case 45:
																																						case 155:
																																							goto IL_07b4;
																																						case 34:
																																							goto IL_07d1;
																																						case 73:
																																						case 162:
																																							goto IL_07e8;
																																						case 139:
																																							goto IL_081a;
																																						case 191:
																																							goto IL_0833;
																																						case 55:
																																						case 195:
																																							goto IL_0846;
																																						case 5:
																																							goto IL_0854;
																																						case 32:
																																							goto IL_086c;
																																						case 42:
																																							goto IL_087a;
																																						case 199:
																																							goto IL_088d;
																																						case 15:
																																						case 80:
																																							goto IL_089b;
																																						case 187:
																																							goto IL_08a6;
																																						case 21:
																																						case 119:
																																							goto IL_08b4;
																																						case 51:
																																							goto IL_08f2;
																																						case 7:
																																						case 79:
																																							goto IL_0905;
																																						case 56:
																																							goto IL_0913;
																																						case 33:
																																						case 99:
																																							goto IL_0923;
																																						case 129:
																																							goto IL_093c;
																																						case 134:
																																							goto IL_094a;
																																						case 103:
																																							goto IL_0958;
																																						case 157:
																																						case 201:
																																							goto IL_096b;
																																						case 120:
																																							goto IL_097f;
																																						case 204:
																																							goto IL_09bc;
																																						case 63:
																																						case 186:
																																							goto IL_09ca;
																																						case 175:
																																							goto IL_09f3;
																																						case 149:
																																							goto IL_0a01;
																																						case 206:
																																							goto IL_0a14;
																																						case 43:
																																							goto IL_0a32;
																																						case 127:
																																							goto IL_0a56;
																																						case 193:
																																							goto IL_0a6e;
																																						case 210:
																																							goto IL_0a81;
																																						case 115:
																																						case 215:
																																							goto IL_0a94;
																																						case 192:
																																							goto IL_0aa2;
																																						case 25:
																																						case 196:
																																							goto IL_0ab0;
																																						case 209:
																																							goto IL_0abe;
																																						case 75:
																																							goto IL_0ae1;
																																						case 60:
																																							goto IL_0aeb;
																																						case 70:
																																							goto IL_0b02;
																																						case 172:
																																							goto IL_0b1e;
																																						case 184:
																																						case 202:
																																							goto IL_0b2c;
																																						case 46:
																																							goto IL_0b37;
																																						case 10:
																																						case 90:
																																							goto IL_0b45;
																																						case 205:
																																							goto IL_0b85;
																																						case 165:
																																							goto IL_0b99;
																																						case 161:
																																						case 216:
																																							goto IL_0bb5;
																																						case 61:
																																							goto IL_0bc3;
																																						case 4:
																																						case 69:
																																							goto IL_0bd1;
																																						case 167:
																																							goto IL_0c33;
																																						case 220:
																																							goto IL_0c46;
																																						case 8:
																																							goto IL_0c54;
																																						case 35:
																																							goto IL_0c5f;
																																						case 97:
																																						case 168:
																																							goto IL_0c6d;
																																						case 148:
																																							goto IL_0cad;
																																						case 116:
																																							goto IL_0cc1;
																																						case 173:
																																							goto IL_0cd4;
																																						case 44:
																																							goto IL_0ce2;
																																						case 20:
																																						case 41:
																																							goto IL_0cf0;
																																						case 95:
																																							goto IL_0d39;
																																						case 64:
																																							goto IL_0d4d;
																																						case 86:
																																						case 88:
																																							goto IL_0d60;
																																						case 54:
																																						case 117:
																																							goto IL_0d7c;
																																						case 57:
																																							goto IL_0d90;
																																						case 169:
																																							goto IL_0dcf;
																																						case 2:
																																						case 9:
																																						case 12:
																																						case 16:
																																						case 17:
																																						case 19:
																																						case 22:
																																						case 27:
																																						case 29:
																																						case 37:
																																						case 38:
																																						case 47:
																																						case 49:
																																						case 50:
																																						case 53:
																																						case 59:
																																						case 62:
																																						case 71:
																																						case 74:
																																						case 87:
																																						case 89:
																																						case 93:
																																						case 96:
																																						case 98:
																																						case 105:
																																						case 109:
																																						case 122:
																																						case 123:
																																						case 141:
																																						case 143:
																																						case 150:
																																						case 151:
																																						case 160:
																																						case 163:
																																						case 166:
																																						case 171:
																																						case 176:
																																						case 189:
																																						case 200:
																																						case 207:
																																						case 218:
																																							goto end_IL_03c5;
																																						case 159:
																																							goto IL_0e0a;
																																						case 30:
																																							goto IL_0e18;
																																						case 58:
																																							goto IL_0e26;
																																						case 6:
																																						case 11:
																																						case 40:
																																						case 52:
																																						case 77:
																																						case 83:
																																						case 85:
																																						case 101:
																																						case 114:
																																						case 128:
																																						case 142:
																																						case 156:
																																						case 170:
																																						case 179:
																																						case 181:
																																						case 183:
																																						case 188:
																																						case 190:
																																						case 203:
																																						case 208:
																																						case 211:
																																						case 212:
																																						case 213:
																																						case 217:
																																						case 219:
																																							goto IL_0e34;
																																						case 185:
																																							goto IL_0e47;
																																						case 182:
																																							goto IL_0e51;
																																						case 94:
																																							goto IL_0e65;
																																						case 145:
																																							goto IL_0e7e;
																																						case 26:
																																							goto IL_0e97;
																																						case 152:
																																							goto IL_0ea7;
																																						case 67:
																																							goto IL_0eb7;
																																						case 214:
																																							goto IL_0ed0;
																																						case 110:
																																							goto IL_0ee0;
																																						case 78:
																																							goto IL_0ef0;
																																						case 153:
																																							goto IL_0f00;
																																						case 91:
																																						case 133:
																																							goto IL_0f1b;
																																						}
																																						goto end_IL_046b;
																																						continue;
																																						end_IL_03c5:
																																						break;
																																					}
																																					break;
																																					IL_03d8:;
																																				}
																																				break;
																																				IL_03eb:;
																																			}
																																			break;
																																		}
																																		goto IL_04b4;
																																		IL_0833:
																																		num6--;
																																		goto IL_0e34;
																																		IL_04b4:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_0561;
																																		IL_0561:
																																		array2[num6 - 2] = 0;
																																		goto IL_0833;
																																	}
																																	break;
																																}
																																num = 31;
																																goto IL_054e;
																																IL_09f3:
																																ptr2 += 8;
																																goto IL_0a01;
																																IL_0a01:
																																num6--;
																																goto IL_0e34;
																																IL_054e:
																																if (3 >= b)
																																{
																																	goto IL_09bc;
																																}
																																goto IL_0a94;
																																IL_0a94:
																																if (4 < b)
																																{
																																	break;
																																}
																																goto IL_0aa2;
																																IL_0aa2:
																																if (4 > b)
																																{
																																	break;
																																}
																																goto IL_0ab0;
																																IL_0ab0:
																																array2[num6] = 0;
																																goto IL_0abe;
																																IL_0abe:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																goto IL_0ae1;
																																IL_0ae1:
																																array3[num6] = null;
																																goto IL_0aeb;
																																IL_0aeb:
																																num6++;
																																num = 70;
																																goto IL_0b02;
																																IL_0b02:
																																ptr2 += 8;
																																num = 52;
																																goto IL_0e34;
																																IL_09bc:
																																if (3 > b)
																																{
																																	break;
																																}
																																goto IL_09ca;
																																IL_09ca:
																																reference = ref array5[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_09f3;
																															}
																															break;
																														}
																														goto IL_0509;
																														IL_05e4:
																														array2[num6 - 2] = 0;
																														goto IL_05f8;
																														IL_05f8:
																														num6--;
																														goto IL_0e34;
																														IL_0509:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_05e4;
																													}
																													break;
																												}
																												goto IL_0b1e;
																												IL_0d60:
																												num6--;
																												num = 83;
																												goto IL_0e34;
																												IL_0b1e:
																												if (8 < b)
																												{
																													goto IL_0b2c;
																												}
																												goto IL_0c46;
																												IL_0b2c:
																												if (9 >= b)
																												{
																													goto IL_0b37;
																												}
																												goto IL_0bb5;
																												IL_0b37:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_0b45;
																												IL_0b45:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0b85;
																												IL_0b85:
																												array2[num6 - 2] = 0;
																												goto IL_0b99;
																												IL_0b99:
																												num6--;
																												num = 183;
																												goto IL_0e34;
																												IL_0bb5:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_0bc3;
																												IL_0bc3:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_0bd1;
																												IL_0bd1:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0c33;
																												IL_0c33:
																												num6 -= 2;
																												goto IL_0e34;
																												IL_0c46:
																												if (8 > b)
																												{
																													goto IL_0c54;
																												}
																												goto IL_0d60;
																												IL_0c54:
																												if (6 >= b)
																												{
																													goto IL_0c5f;
																												}
																												goto IL_0cd4;
																												IL_0c5f:
																												if (6 > b)
																												{
																													break;
																												}
																												goto IL_0c6d;
																												IL_0c6d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0cad;
																												IL_0cad:
																												array2[num6 - 2] = 0;
																												goto IL_0cc1;
																												IL_0cc1:
																												num6--;
																												goto IL_0e34;
																												IL_0cd4:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_0ce2;
																												IL_0ce2:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_0cf0;
																												IL_0cf0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 95;
																												goto IL_0d39;
																												IL_0d39:
																												array2[num6 - 2] = 0;
																												goto IL_0d4d;
																												IL_0d4d:
																												num6--;
																												goto IL_0e34;
																											}
																											break;
																										}
																										goto IL_0d7c;
																										IL_0dcf:
																										ptr2 += 8;
																										num = 219;
																										goto IL_0e34;
																										IL_0d7c:
																										array2[num6 - 1] = 0;
																										goto IL_0d90;
																										IL_0d90:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)setFilterLevelObjectManager[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0dcf;
																									}
																									break;
																								}
																								goto IL_04a4;
																								IL_087a:
																								ptr2 += 8;
																								goto IL_0e34;
																								IL_07e8:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								num = 139;
																								goto IL_081a;
																								IL_04a4:
																								if (17 >= b)
																								{
																									goto IL_04f6;
																								}
																								goto IL_057a;
																								IL_057a:
																								if (20 < b)
																								{
																									goto IL_0588;
																								}
																								goto IL_088d;
																								IL_0588:
																								if (21 >= b)
																								{
																									goto IL_0593;
																								}
																								num = 164;
																								goto IL_05ac;
																								IL_0593:
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_060b;
																								IL_060b:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_0e34;
																								IL_081a:
																								array2[num6 - 1] = 5;
																								goto IL_0e34;
																								IL_05ac:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_05ba;
																								IL_05ba:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_05c8;
																								IL_05c8:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								goto IL_0e34;
																								IL_088d:
																								if (20 > b)
																								{
																									goto IL_089b;
																								}
																								goto IL_0923;
																								IL_089b:
																								if (18 >= b)
																								{
																									goto IL_08a6;
																								}
																								goto IL_0905;
																								IL_08a6:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_08b4;
																								IL_08b4:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_08f2;
																								IL_08f2:
																								num6 -= 3;
																								goto IL_0e34;
																								IL_0905:
																								if (19 < b)
																								{
																									break;
																								}
																								goto IL_0913;
																								IL_0913:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_096b;
																								IL_096b:
																								array2[num6 - 1] = 5;
																								goto IL_097f;
																								IL_097f:
																								array3[num6 - 1] = ((delegate*<string[], string>)setFilterLevelObjectManager[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0a81;
																								IL_0a81:
																								ptr2 += 8;
																								goto IL_0e34;
																								IL_0923:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_093c;
																								IL_093c:
																								array2[num6] = 1;
																								goto IL_094a;
																								IL_094a:
																								num6++;
																								goto IL_0958;
																								IL_0958:
																								ptr2 += 16;
																								goto IL_0e34;
																								IL_04f6:
																								if (17 > b)
																								{
																									goto IL_0623;
																								}
																								goto IL_0846;
																								IL_0623:
																								if (14 >= b)
																								{
																									goto IL_0631;
																								}
																								goto IL_078d;
																								IL_0631:
																								if (14 <= b)
																								{
																									goto IL_063c;
																								}
																								goto IL_067b;
																								IL_063c:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_065a;
																								IL_065a:
																								ptr2 += 8;
																								goto IL_0668;
																								IL_0668:
																								num6--;
																								goto IL_0e34;
																								IL_067b:
																								if (12 >= b)
																								{
																									goto IL_0686;
																								}
																								goto IL_0699;
																								IL_0686:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_0e34;
																								IL_0699:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_06a7;
																								IL_06a7:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_06b5;
																								IL_06b5:
																								array8 = array3;
																								num9 = num6;
																								if (array == null)
																								{
																									goto IL_06c4;
																								}
																								num10 = ptr2;
																								byte b2 = *num10;
																								ptr2 = num10 + 4;
																								int num11 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num11;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_076c;
																								IL_0846:
																								array2[num6] = 5;
																								goto IL_0854;
																								IL_0854:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_086c;
																								IL_086c:
																								num6++;
																								goto IL_087a;
																								IL_076c:
																								array2[num6] = 5;
																								goto IL_077a;
																								IL_077a:
																								num6++;
																								goto IL_0e34;
																								IL_078d:
																								if (15 < b)
																								{
																									goto IL_0798;
																								}
																								goto IL_07d1;
																								IL_0798:
																								if (16 < b)
																								{
																									break;
																								}
																								goto IL_07a6;
																								IL_07a6:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_07b4;
																								IL_07b4:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0a14;
																								IL_0a14:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_0a32;
																								IL_0a32:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a56;
																								IL_0a56:
																								array3[num6] = array3[num6 - 1];
																								goto IL_0a6e;
																								IL_0a6e:
																								num6++;
																								goto IL_0e34;
																								IL_07d1:
																								if (15 > b)
																								{
																									break;
																								}
																								num = 73;
																								goto IL_07e8;
																							}
																							break;
																							IL_045b:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					num = 159;
																					goto IL_0e0a;
																					IL_0e26:
																					ptr2 += 8;
																					goto IL_0e34;
																					IL_0e18:
																					num6++;
																					goto IL_0e26;
																					IL_0e0a:
																					array2[num6] = 0;
																					goto IL_0e18;
																					continue;
																					end_IL_046b:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0f1b;
																	IL_0f1b:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_06c4:
				while (true)
				{
					IL_06c4_2:
					array = new byte[4];
					while (true)
					{
						IL_06d2:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_077a_2:
								num6++;
								while (true)
								{
									IL_0e34_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_046b_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_044b_2:
																if (11 >= b)
																{
																	num = 194;
																	while (true)
																	{
																		IL_043b_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_042b_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0418_2:
																						if (5 > b)
																						{
																							num = 137;
																							while (true)
																							{
																								IL_040b_2:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_03fb_2:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 > b)
																												{
																													num = 227;
																													while (num != 227)
																													{
																														if (num != 1208)
																														{
																															goto IL_0d7c_2;
																														}
																														switch (num)
																														{
																														case 197:
																															goto IL_03d8_2;
																														case 106:
																														case 125:
																															goto IL_03eb_2;
																														case 177:
																															goto IL_03fb_2;
																														case 36:
																														case 137:
																															goto IL_040b_2;
																														case 198:
																															goto IL_0418_2;
																														case 131:
																															goto IL_042b_2;
																														case 194:
																															goto IL_043b_2;
																														case 65:
																															goto IL_044b_2;
																														case 112:
																															goto IL_045b_2;
																														case 135:
																															goto IL_046b_2;
																														case 82:
																															goto end_IL_046b_2;
																														case 113:
																														case 146:
																															goto end_IL_047b;
																														case 0:
																															goto IL_04a4_2;
																														case 14:
																														case 76:
																															goto IL_04b4_2;
																														case 84:
																															goto IL_04f6_2;
																														case 24:
																														case 108:
																															goto IL_0509_2;
																														case 31:
																														case 111:
																															goto IL_054e_2;
																														case 140:
																															goto IL_0561_2;
																														case 147:
																															goto IL_057a_2;
																														case 23:
																														case 48:
																															goto IL_0588_2;
																														case 132:
																															goto IL_0593_2;
																														case 118:
																														case 164:
																															goto IL_05ac_2;
																														case 72:
																															goto IL_05ba_2;
																														case 1:
																														case 102:
																															goto IL_05c8_2;
																														case 174:
																															goto IL_05e4_2;
																														case 81:
																															goto IL_05f8_2;
																														case 130:
																														case 178:
																															goto IL_060b_2;
																														case 107:
																														case 180:
																															goto IL_0623_2;
																														case 13:
																															goto IL_0631_2;
																														case 18:
																														case 68:
																															goto IL_063c_2;
																														case 92:
																															goto IL_065a_2;
																														case 104:
																															goto IL_0668_2;
																														case 158:
																															goto IL_067b_2;
																														case 3:
																															goto IL_0686_2;
																														case 126:
																															goto IL_0699_2;
																														case 39:
																															goto IL_06a7_2;
																														case 121:
																														case 144:
																															goto IL_06b5_2;
																														case 100:
																															goto end_IL_048b;
																														case 138:
																															goto IL_077a_2;
																														case 28:
																															goto IL_078d_2;
																														case 66:
																														case 136:
																															goto IL_0798_2;
																														case 124:
																															goto IL_07a6_2;
																														case 45:
																														case 155:
																															goto IL_07b4_2;
																														case 34:
																															goto IL_07d1_2;
																														case 73:
																														case 162:
																															goto IL_07e8_2;
																														case 139:
																															goto IL_081a_2;
																														case 191:
																															goto IL_0833_2;
																														case 55:
																														case 195:
																															goto IL_0846_2;
																														case 5:
																															goto IL_0854_2;
																														case 32:
																															goto IL_086c_2;
																														case 42:
																															goto IL_087a_2;
																														case 199:
																															goto IL_088d_2;
																														case 15:
																														case 80:
																															goto IL_089b_2;
																														case 187:
																															goto IL_08a6_2;
																														case 21:
																														case 119:
																															goto IL_08b4_2;
																														case 51:
																															goto IL_08f2_2;
																														case 7:
																														case 79:
																															goto IL_0905_2;
																														case 56:
																															goto IL_0913_2;
																														case 33:
																														case 99:
																															goto IL_0923_2;
																														case 129:
																															goto IL_093c_2;
																														case 134:
																															goto IL_094a_2;
																														case 103:
																															goto IL_0958_2;
																														case 157:
																														case 201:
																															goto IL_096b_2;
																														case 120:
																															goto IL_097f_2;
																														case 204:
																															goto IL_09bc_2;
																														case 63:
																														case 186:
																															goto IL_09ca_2;
																														case 175:
																															goto IL_09f3_2;
																														case 149:
																															goto IL_0a01_2;
																														case 206:
																															goto IL_0a14_2;
																														case 43:
																															goto IL_0a32_2;
																														case 127:
																															goto IL_0a56_2;
																														case 193:
																															goto IL_0a6e_2;
																														case 210:
																															goto IL_0a81_2;
																														case 115:
																														case 215:
																															goto IL_0a94_2;
																														case 192:
																															goto IL_0aa2_2;
																														case 25:
																														case 196:
																															goto IL_0ab0_2;
																														case 209:
																															goto IL_0abe_2;
																														case 75:
																															goto IL_0ae1_2;
																														case 60:
																															goto IL_0aeb_2;
																														case 70:
																															goto IL_0b02_2;
																														case 172:
																															goto IL_0b1e_2;
																														case 184:
																														case 202:
																															goto IL_0b2c_2;
																														case 46:
																															goto IL_0b37_2;
																														case 10:
																														case 90:
																															goto IL_0b45_2;
																														case 205:
																															goto IL_0b85_2;
																														case 165:
																															goto IL_0b99_2;
																														case 161:
																														case 216:
																															goto IL_0bb5_2;
																														case 61:
																															goto IL_0bc3_2;
																														case 4:
																														case 69:
																															goto IL_0bd1_2;
																														case 167:
																															goto IL_0c33_2;
																														case 220:
																															goto IL_0c46_2;
																														case 8:
																															goto IL_0c54_2;
																														case 35:
																															goto IL_0c5f_2;
																														case 97:
																														case 168:
																															goto IL_0c6d_2;
																														case 148:
																															goto IL_0cad_2;
																														case 116:
																															goto IL_0cc1_2;
																														case 173:
																															goto IL_0cd4_2;
																														case 44:
																															goto IL_0ce2_2;
																														case 20:
																														case 41:
																															goto IL_0cf0_2;
																														case 95:
																															goto IL_0d39_2;
																														case 64:
																															goto IL_0d4d_2;
																														case 86:
																														case 88:
																															goto IL_0d60_2;
																														case 54:
																														case 117:
																															goto IL_0d7c_2;
																														case 57:
																															goto IL_0d90_2;
																														case 169:
																															goto IL_0dcf_2;
																														case 2:
																														case 9:
																														case 12:
																														case 16:
																														case 17:
																														case 19:
																														case 22:
																														case 27:
																														case 29:
																														case 37:
																														case 38:
																														case 47:
																														case 49:
																														case 50:
																														case 53:
																														case 59:
																														case 62:
																														case 71:
																														case 74:
																														case 87:
																														case 89:
																														case 93:
																														case 96:
																														case 98:
																														case 105:
																														case 109:
																														case 122:
																														case 123:
																														case 141:
																														case 143:
																														case 150:
																														case 151:
																														case 160:
																														case 163:
																														case 166:
																														case 171:
																														case 176:
																														case 189:
																														case 200:
																														case 207:
																														case 218:
																															goto end_IL_03c5_2;
																														case 159:
																															goto IL_0e0a_2;
																														case 30:
																															goto IL_0e18_2;
																														case 58:
																															goto IL_0e26_2;
																														case 6:
																														case 11:
																														case 40:
																														case 52:
																														case 77:
																														case 83:
																														case 85:
																														case 101:
																														case 114:
																														case 128:
																														case 142:
																														case 156:
																														case 170:
																														case 179:
																														case 181:
																														case 183:
																														case 188:
																														case 190:
																														case 203:
																														case 208:
																														case 211:
																														case 212:
																														case 213:
																														case 217:
																														case 219:
																															goto IL_0e34_2;
																														case 185:
																															ptr2 = ptr;
																															goto IL_0e34_2;
																														case 182:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ShaEncodeOID.permissionSetIDSafeProcessHandle);
																															num = 185;
																															goto case 185;
																														case 94:
																															array7 = new object[15];
																															num = 182;
																															goto case 182;
																														case 145:
																															array6 = new long[4];
																															num = 94;
																															goto case 94;
																														case 26:
																															array5 = new int[6];
																															goto case 145;
																														case 152:
																															array4 = new int[4];
																															goto case 26;
																														case 67:
																															array3 = new object[4];
																															num = 152;
																															goto case 152;
																														case 214:
																															array2 = new byte[4];
																															goto case 67;
																														case 110:
																															num4 = num2 * 8;
																															goto case 214;
																														case 78:
																															num3 = num2 * 4;
																															goto case 110;
																														case 153:
																															num2 = 1;
																															goto case 78;
																														case 154:
																															goto end_IL_076c;
																														case 91:
																														case 133:
																															goto IL_0f1b_2;
																														}
																														continue;
																														end_IL_03c5_2:
																														break;
																													}
																													break;
																													IL_03d8_2:;
																												}
																												break;
																												IL_03eb_2:;
																											}
																											break;
																										}
																										goto IL_04b4_2;
																										IL_0833_2:
																										num6--;
																										goto IL_0e34_2;
																										IL_04b4_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0561_2;
																										IL_0561_2:
																										array2[num6 - 2] = 0;
																										goto IL_0833_2;
																									}
																									break;
																								}
																								num = 31;
																								goto IL_054e_2;
																								IL_09f3_2:
																								ptr2 += 8;
																								goto IL_0a01_2;
																								IL_0a01_2:
																								num6--;
																								goto IL_0e34_2;
																								IL_054e_2:
																								if (3 >= b)
																								{
																									goto IL_09bc_2;
																								}
																								goto IL_0a94_2;
																								IL_0a94_2:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0aa2_2;
																								IL_0aa2_2:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0ab0_2;
																								IL_0ab0_2:
																								array2[num6] = 0;
																								goto IL_0abe_2;
																								IL_0abe_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0ae1_2;
																								IL_0ae1_2:
																								array3[num6] = null;
																								goto IL_0aeb_2;
																								IL_0aeb_2:
																								num6++;
																								num = 70;
																								goto IL_0b02_2;
																								IL_0b02_2:
																								ptr2 += 8;
																								num = 52;
																								goto IL_0e34_2;
																								IL_09bc_2:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_09ca_2;
																								IL_09ca_2:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09f3_2;
																							}
																							break;
																						}
																						goto IL_0509_2;
																						IL_05e4_2:
																						array2[num6 - 2] = 0;
																						goto IL_05f8_2;
																						IL_05f8_2:
																						num6--;
																						goto IL_0e34_2;
																						IL_0509_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_05e4_2;
																					}
																					break;
																				}
																				goto IL_0b1e_2;
																				IL_0d60_2:
																				num6--;
																				num = 83;
																				goto IL_0e34_2;
																				IL_0b1e_2:
																				if (8 < b)
																				{
																					goto IL_0b2c_2;
																				}
																				goto IL_0c46_2;
																				IL_0b2c_2:
																				if (9 >= b)
																				{
																					goto IL_0b37_2;
																				}
																				goto IL_0bb5_2;
																				IL_0b37_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0b45_2;
																				IL_0b45_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0b85_2;
																				IL_0b85_2:
																				array2[num6 - 2] = 0;
																				goto IL_0b99_2;
																				IL_0b99_2:
																				num6--;
																				num = 183;
																				goto IL_0e34_2;
																				IL_0bb5_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0bc3_2;
																				IL_0bc3_2:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0bd1_2;
																				IL_0bd1_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0c33_2;
																				IL_0c33_2:
																				num6 -= 2;
																				goto IL_0e34_2;
																				IL_0c46_2:
																				if (8 > b)
																				{
																					goto IL_0c54_2;
																				}
																				goto IL_0d60_2;
																				IL_0c54_2:
																				if (6 >= b)
																				{
																					goto IL_0c5f_2;
																				}
																				goto IL_0cd4_2;
																				IL_0c5f_2:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0c6d_2;
																				IL_0c6d_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0cad_2;
																				IL_0cad_2:
																				array2[num6 - 2] = 0;
																				goto IL_0cc1_2;
																				IL_0cc1_2:
																				num6--;
																				goto IL_0e34_2;
																				IL_0cd4_2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0ce2_2;
																				IL_0ce2_2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0cf0_2;
																				IL_0cf0_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				num = 95;
																				goto IL_0d39_2;
																				IL_0d39_2:
																				array2[num6 - 2] = 0;
																				goto IL_0d4d_2;
																				IL_0d4d_2:
																				num6--;
																				goto IL_0e34_2;
																			}
																			break;
																		}
																		goto IL_0d7c_2;
																		IL_0dcf_2:
																		ptr2 += 8;
																		num = 219;
																		goto IL_0e34_2;
																		IL_0d7c_2:
																		array2[num6 - 1] = 0;
																		goto IL_0d90_2;
																		IL_0d90_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)setFilterLevelObjectManager[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0dcf_2;
																	}
																	break;
																}
																goto IL_04a4_2;
																IL_0846_2:
																array2[num6] = 5;
																goto IL_0854_2;
																IL_0854_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_086c_2;
																IL_04a4_2:
																if (17 >= b)
																{
																	goto IL_04f6_2;
																}
																goto IL_057a_2;
																IL_057a_2:
																if (20 < b)
																{
																	goto IL_0588_2;
																}
																goto IL_088d_2;
																IL_0588_2:
																if (21 >= b)
																{
																	goto IL_0593_2;
																}
																num = 164;
																goto IL_05ac_2;
																IL_0593_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_060b_2;
																IL_060b_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0e34_2;
																IL_086c_2:
																num6++;
																goto IL_087a_2;
																IL_05ac_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_05ba_2;
																IL_05ba_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_05c8_2;
																IL_05c8_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																goto IL_0e34_2;
																IL_088d_2:
																if (20 > b)
																{
																	goto IL_089b_2;
																}
																goto IL_0923_2;
																IL_089b_2:
																if (18 >= b)
																{
																	goto IL_08a6_2;
																}
																goto IL_0905_2;
																IL_08a6_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_08b4_2;
																IL_08b4_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_08f2_2;
																IL_08f2_2:
																num6 -= 3;
																goto IL_0e34_2;
																IL_0905_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0913_2;
																IL_0913_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_096b_2;
																IL_096b_2:
																array2[num6 - 1] = 5;
																goto IL_097f_2;
																IL_097f_2:
																array3[num6 - 1] = ((delegate*<string[], string>)setFilterLevelObjectManager[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0a81_2;
																IL_0a81_2:
																ptr2 += 8;
																goto IL_0e34_2;
																IL_0923_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_093c_2;
																IL_093c_2:
																array2[num6] = 1;
																goto IL_094a_2;
																IL_094a_2:
																num6++;
																goto IL_0958_2;
																IL_0958_2:
																ptr2 += 16;
																goto IL_0e34_2;
																IL_04f6_2:
																if (17 > b)
																{
																	goto IL_0623_2;
																}
																goto IL_0846_2;
																IL_0623_2:
																if (14 >= b)
																{
																	goto IL_0631_2;
																}
																goto IL_078d_2;
																IL_0631_2:
																if (14 <= b)
																{
																	goto IL_063c_2;
																}
																goto IL_067b_2;
																IL_063c_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_065a_2;
																IL_065a_2:
																ptr2 += 8;
																goto IL_0668_2;
																IL_0668_2:
																num6--;
																goto IL_0e34_2;
																IL_067b_2:
																if (12 >= b)
																{
																	goto IL_0686_2;
																}
																goto IL_0699_2;
																IL_0686_2:
																if (12 > b)
																{
																	break;
																}
																goto IL_0e34_2;
																IL_0699_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_06a7_2;
																IL_06a7_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_06b5_2;
																IL_06b5_2:
																array8 = array3;
																num9 = num6;
																if (array == null)
																{
																	goto IL_06c4_2;
																}
																goto IL_06d2;
																IL_078d_2:
																if (15 < b)
																{
																	goto IL_0798_2;
																}
																goto IL_07d1_2;
																IL_0798_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_07a6_2;
																IL_07a6_2:
																if (16 > b)
																{
																	break;
																}
																goto IL_07b4_2;
																IL_07b4_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0a14_2;
																IL_0a14_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0a32_2;
																IL_0a32_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a56_2;
																IL_0a56_2:
																array3[num6] = array3[num6 - 1];
																goto IL_0a6e_2;
																IL_0a6e_2:
																num6++;
																goto IL_0e34_2;
																IL_07d1_2:
																if (15 > b)
																{
																	break;
																}
																num = 73;
																goto IL_07e8_2;
																IL_087a_2:
																ptr2 += 8;
																goto IL_0e34_2;
																IL_07e8_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																num = 139;
																goto IL_081a_2;
																IL_081a_2:
																array2[num6 - 1] = 5;
																goto IL_0e34_2;
															}
															break;
															IL_045b_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													num = 159;
													goto IL_0e0a_2;
													IL_0e26_2:
													ptr2 += 8;
													goto IL_0e34_2;
													IL_0e18_2:
													num6++;
													goto IL_0e26_2;
													IL_0e0a_2:
													array2[num6] = 0;
													goto IL_0e18_2;
													continue;
													end_IL_046b_2:
													break;
												}
												continue;
												end_IL_047b:
												break;
											}
											continue;
											end_IL_048b:
											break;
										}
										break;
									}
									goto IL_0f1b_2;
									IL_0f1b_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_076c:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_03ad, IL_03c0, IL_0403, IL_0419, IL_0429, IL_0439, IL_0446, IL_0456, IL_0466, IL_0476, IL_0486, IL_0496, IL_04a9, IL_04b9, IL_04c4, IL_04d2, IL_0519, IL_052c, IL_0537, IL_0547, IL_055a, IL_0565, IL_0573, IL_0581, IL_0599, IL_05b7, IL_05e0, IL_05f0, IL_05fb, IL_061b, IL_0644, IL_065d, IL_0668, IL_067b, IL_0689, IL_069c, IL_06ac, IL_06c6, IL_06de, IL_06ec, IL_06ff, IL_0712, IL_0720, IL_073d, IL_078c, IL_0796, IL_07c3, IL_07d7, IL_07e5, IL_07f8, IL_080b, IL_0814, IL_082d, IL_083b, IL_0849, IL_085c, IL_0867, IL_0872, IL_0880, IL_0898, IL_08a6, IL_08b4, IL_08d0, IL_08d9, IL_08e7, IL_08f5, IL_0903, IL_0911, IL_091f, IL_092d, IL_098f, IL_09a2, IL_09b0, IL_09f9, IL_0a0d, IL_0a20, IL_0a2e, IL_0a39, IL_0a47, IL_0a87, IL_0a9b, IL_0aae, IL_0abc, IL_0aca, IL_0b0a, IL_0b1e, IL_0b31, IL_0b4d, IL_0b5b, IL_0b69, IL_0b74, IL_0b82, IL_0bab, IL_0bb9, IL_0bcc, IL_0bda, IL_0be8, IL_0bf6, IL_0c19, IL_0c23, IL_0c31, IL_0c44, IL_0c4f, IL_0c5d, IL_0c70, IL_0cb0, IL_0cc4, IL_0cd7, IL_0d17, IL_0d2b, IL_0d3e, IL_0d52, IL_0d91, IL_0da1, IL_0dba, IL_0dc8, IL_0dd6, IL_0de4, IL_0df7, IL_0e01, IL_0e0c, IL_0e1c, IL_0e2c, IL_0e3c, IL_0e4c, IL_0e5c, IL_0e6c, IL_0e7c, IL_0e8c, IL_0eb0, IL_0eb9 are reachable both inside and outside the pinned region starting at IL_0eaa. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 36;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef4 = default(int);
				ref int reference = ref __rxRef4;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e8c:
						num2 = 1;
						num = 205;
						while (true)
						{
							IL_0e7c:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e6c:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e5c:
									array2 = new byte[4];
									while (true)
									{
										IL_0e4c:
										array3 = new object[4];
										while (true)
										{
											IL_0e3c:
											array4 = new int[4];
											while (true)
											{
												IL_0e2c:
												array5 = new int[6];
												while (true)
												{
													IL_0e1c:
													array6 = new long[4];
													while (true)
													{
														IL_0e0c:
														array7 = new object[14];
														while (true)
														{
															IL_0e01:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentStateRemotingMethodCachedData.CultureListValidRestrictedCodeSid);
															while (true)
															{
																IL_0df7:
																ptr2 = ptr;
																while (true)
																{
																	IL_0de4:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_04b9:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_04a9:
																				ptr2++;
																				while (true)
																				{
																					IL_0496:
																					if (b >= 1)
																					{
																						num = 162;
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0476:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_0466:
																										if (17 < b)
																										{
																											while (true)
																											{
																												IL_0456:
																												if (20 >= b)
																												{
																													while (true)
																													{
																														IL_0446:
																														if (20 > b)
																														{
																															while (true)
																															{
																																IL_0439:
																																if (18 < b)
																																{
																																	while (19 >= b)
																																	{
																																		while (19 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_0403:
																																				array2[num6 - 1] = 5;
																																				while (true)
																																				{
																																					IL_03c0:
																																					array3[num6 - 1] = ((delegate*<string[], string>)PrelinkAllStop[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																					num = 228;
																																					while (true)
																																					{
																																						if (num != 228)
																																						{
																																							if (num != 1209)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 36:
																																								break;
																																							default:
																																								continue;
																																							case 8:
																																								goto IL_03c0;
																																							case 155:
																																							case 201:
																																								goto IL_0403;
																																							case 12:
																																								goto IL_0419;
																																							case 23:
																																								goto IL_0429;
																																							case 63:
																																								goto IL_0439;
																																							case 125:
																																								goto IL_0446;
																																							case 75:
																																								goto IL_0456;
																																							case 121:
																																								goto IL_0466;
																																							case 114:
																																								goto IL_0476;
																																							case 162:
																																								goto IL_0486;
																																							case 132:
																																								goto IL_0496;
																																							case 25:
																																								goto IL_04a9;
																																							case 147:
																																							case 182:
																																								goto IL_04b9;
																																							case 98:
																																								goto IL_04c4;
																																							case 51:
																																							case 131:
																																								goto IL_04d2;
																																							case 71:
																																								goto IL_0519;
																																							case 145:
																																								goto IL_052c;
																																							case 15:
																																							case 108:
																																								goto IL_0537;
																																							case 6:
																																							case 115:
																																								goto IL_0547;
																																							case 43:
																																							case 159:
																																								goto IL_055a;
																																							case 53:
																																								goto IL_0565;
																																							case 32:
																																								goto IL_0573;
																																							case 4:
																																							case 135:
																																								goto IL_0581;
																																							case 69:
																																								goto IL_0599;
																																							case 134:
																																								goto IL_05b7;
																																							case 160:
																																								goto IL_05e0;
																																							case 161:
																																								goto IL_05f0;
																																							case 124:
																																							case 129:
																																								goto IL_05fb;
																																							case 9:
																																							case 175:
																																								goto IL_061b;
																																							case 83:
																																								goto IL_0644;
																																							case 90:
																																							case 178:
																																								goto IL_065d;
																																							case 16:
																																								goto IL_0668;
																																							case 183:
																																								goto IL_067b;
																																							case 80:
																																								goto IL_0689;
																																							case 74:
																																							case 199:
																																								goto IL_069c;
																																							case 207:
																																								goto IL_06ac;
																																							case 211:
																																								goto IL_06c6;
																																							case 38:
																																								goto IL_06de;
																																							case 143:
																																								goto IL_06ec;
																																							case 213:
																																								goto IL_06ff;
																																							case 215:
																																								goto IL_0712;
																																							case 122:
																																							case 180:
																																								goto IL_0720;
																																							case 78:
																																								goto IL_07d7;
																																							case 45:
																																								goto IL_07e5;
																																							case 7:
																																							case 209:
																																								goto IL_0814;
																																							case 77:
																																								goto IL_082d;
																																							case 92:
																																								goto IL_083b;
																																							case 150:
																																								goto IL_0849;
																																							case 152:
																																							case 219:
																																								goto IL_085c;
																																							case 101:
																																								goto IL_0867;
																																							case 88:
																																							case 217:
																																								goto IL_0880;
																																							case 119:
																																								goto IL_0898;
																																							case 103:
																																								goto IL_08a6;
																																							case 84:
																																							case 104:
																																								goto IL_08b4;
																																							case 123:
																																								goto IL_08d9;
																																							case 127:
																																							case 198:
																																								goto IL_08e7;
																																							case 87:
																																							case 97:
																																								goto IL_08f5;
																																							case 110:
																																							case 221:
																																								goto IL_0903;
																																							case 46:
																																							case 186:
																																								goto IL_0911;
																																							case 52:
																																								goto IL_091f;
																																							case 59:
																																							case 105:
																																								goto IL_092d;
																																							case 28:
																																								goto IL_098f;
																																							case 195:
																																								goto IL_09a2;
																																							case 193:
																																							case 210:
																																								goto IL_09b0;
																																							case 172:
																																								goto IL_09f9;
																																							case 76:
																																								goto IL_0a0d;
																																							case 151:
																																								goto IL_0a20;
																																							case 81:
																																							case 138:
																																								goto IL_0a2e;
																																							case 18:
																																								goto IL_0a39;
																																							case 67:
																																							case 187:
																																								goto IL_0a47;
																																							case 192:
																																								goto IL_0a87;
																																							case 66:
																																								goto IL_0a9b;
																																							case 106:
																																								goto IL_0aae;
																																							case 189:
																																								goto IL_0abc;
																																							case 19:
																																							case 40:
																																								goto IL_0aca;
																																							case 153:
																																								goto IL_0b0a;
																																							case 1:
																																								goto IL_0b1e;
																																							case 169:
																																							case 208:
																																								goto IL_0b31;
																																							case 99:
																																								goto IL_0b4d;
																																							case 56:
																																							case 68:
																																								goto IL_0b5b;
																																							case 3:
																																							case 48:
																																								goto IL_0b69;
																																							case 157:
																																								goto IL_0b74;
																																							case 140:
																																							case 176:
																																								goto IL_0b82;
																																							case 44:
																																								goto IL_0bab;
																																							case 34:
																																								goto IL_0bb9;
																																							case 188:
																																								goto IL_0bcc;
																																							case 70:
																																								goto IL_0bda;
																																							case 27:
																																							case 154:
																																								goto IL_0be8;
																																							case 94:
																																								goto IL_0bf6;
																																							case 73:
																																								goto IL_0c19;
																																							case 218:
																																								goto IL_0c23;
																																							case 37:
																																								goto IL_0c31;
																																							case 72:
																																								goto IL_0c44;
																																							case 128:
																																							case 148:
																																								goto IL_0c4f;
																																							case 181:
																																								goto IL_0c5d;
																																							case 142:
																																							case 158:
																																								goto IL_0c70;
																																							case 57:
																																								goto IL_0cb0;
																																							case 139:
																																								goto IL_0cc4;
																																							case 29:
																																							case 60:
																																								goto IL_0cd7;
																																							case 116:
																																								goto IL_0d17;
																																							case 204:
																																								goto IL_0d2b;
																																							case 126:
																																							case 168:
																																								goto IL_0d3e;
																																							case 61:
																																								goto IL_0d52;
																																							case 196:
																																								goto IL_0d91;
																																							case 0:
																																							case 11:
																																							case 14:
																																							case 17:
																																							case 21:
																																							case 22:
																																							case 24:
																																							case 26:
																																							case 30:
																																							case 31:
																																							case 39:
																																							case 41:
																																							case 49:
																																							case 50:
																																							case 54:
																																							case 58:
																																							case 64:
																																							case 79:
																																							case 82:
																																							case 85:
																																							case 89:
																																							case 95:
																																							case 96:
																																							case 107:
																																							case 111:
																																							case 112:
																																							case 120:
																																							case 136:
																																							case 146:
																																							case 156:
																																							case 163:
																																							case 166:
																																							case 167:
																																							case 170:
																																							case 173:
																																							case 174:
																																							case 179:
																																							case 191:
																																							case 194:
																																							case 200:
																																							case 212:
																																							case 220:
																																								goto end_IL_03ad;
																																							case 47:
																																								goto IL_0dba;
																																							case 5:
																																								goto IL_0dc8;
																																							case 177:
																																								goto IL_0dd6;
																																							case 2:
																																							case 10:
																																							case 13:
																																							case 20:
																																							case 42:
																																							case 55:
																																							case 91:
																																							case 93:
																																							case 100:
																																							case 102:
																																							case 109:
																																							case 113:
																																							case 118:
																																							case 130:
																																							case 141:
																																							case 144:
																																							case 149:
																																							case 165:
																																							case 184:
																																							case 197:
																																							case 202:
																																							case 203:
																																							case 206:
																																							case 214:
																																							case 216:
																																								goto IL_0de4;
																																							case 33:
																																								goto IL_0df7;
																																							case 185:
																																								goto IL_0e01;
																																							case 137:
																																								goto IL_0e0c;
																																							case 190:
																																								goto IL_0e1c;
																																							case 65:
																																								goto IL_0e2c;
																																							case 62:
																																								goto IL_0e3c;
																																							case 171:
																																								goto IL_0e4c;
																																							case 86:
																																								goto IL_0e5c;
																																							case 164:
																																								goto IL_0e6c;
																																							case 205:
																																								goto IL_0e7c;
																																							case 35:
																																								goto IL_0e8c;
																																							case 117:
																																							case 133:
																																								goto IL_0eb9;
																																							}
																																							goto end_IL_0496;
																																						}
																																						ptr2 += 8;
																																						goto IL_0de4;
																																						continue;
																																						end_IL_03ad:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																			IL_0419:;
																																		}
																																		break;
																																		IL_0429:;
																																	}
																																	break;
																																}
																																goto IL_04c4;
																																IL_0519:
																																num6 -= 3;
																																goto IL_0de4;
																																IL_04c4:
																																if (18 > b)
																																{
																																	break;
																																}
																																goto IL_04d2;
																																IL_04d2:
																																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																																num = 71;
																																goto IL_0519;
																															}
																															break;
																														}
																														num = 209;
																														goto IL_0814;
																														IL_083b:
																														num6++;
																														goto IL_0849;
																														IL_0849:
																														ptr2 += 16;
																														goto IL_0de4;
																														IL_0814:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																														goto IL_082d;
																														IL_082d:
																														array2[num6] = 1;
																														goto IL_083b;
																													}
																													break;
																												}
																												goto IL_085c;
																												IL_08a6:
																												if (22 > b)
																												{
																													break;
																												}
																												goto IL_08b4;
																												IL_085c:
																												if (21 >= b)
																												{
																													goto IL_0867;
																												}
																												goto IL_0898;
																												IL_0867:
																												if (21 > b)
																												{
																													num = 89;
																													break;
																												}
																												goto IL_0880;
																												IL_08b4:
																												num7 = ptr2;
																												num8 = -200;
																												num5 = 1;
																												ptr2 = num7 + num8;
																												goto IL_0de4;
																												IL_0880:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_0de4;
																												IL_0898:
																												if (22 < b)
																												{
																													break;
																												}
																												goto IL_08a6;
																											}
																											break;
																										}
																										goto IL_052c;
																										IL_0547:
																										array2[num6] = 5;
																										goto IL_06c6;
																										IL_052c:
																										if (17 > b)
																										{
																											goto IL_0537;
																										}
																										goto IL_0547;
																										IL_0537:
																										if (14 < b)
																										{
																											goto IL_055a;
																										}
																										goto IL_05f0;
																										IL_05f0:
																										if (14 <= b)
																										{
																											goto IL_05fb;
																										}
																										goto IL_065d;
																										IL_05fb:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_067b;
																										IL_067b:
																										ptr2 += 8;
																										goto IL_0689;
																										IL_0689:
																										num6--;
																										goto IL_0de4;
																										IL_065d:
																										if (12 >= b)
																										{
																											goto IL_0668;
																										}
																										goto IL_069c;
																										IL_0668:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0de4;
																										IL_069c:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_0712;
																										IL_0712:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_0720;
																										IL_0720:
																										array8 = array3;
																										num9 = num6;
																										if (array == null)
																										{
																											goto IL_072f;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_07d7;
																										IL_06c6:
																										array3[num6] = array7[*(int*)(ptr2 + num3)];
																										goto IL_06de;
																										IL_06de:
																										num6++;
																										goto IL_06ec;
																										IL_06ec:
																										ptr2 += 8;
																										goto IL_0de4;
																										IL_07d7:
																										array2[num6] = 5;
																										goto IL_07e5;
																										IL_07e5:
																										num6++;
																										goto IL_0de4;
																										IL_055a:
																										if (15 < b)
																										{
																											goto IL_0565;
																										}
																										goto IL_05e0;
																										IL_0565:
																										if (16 < b)
																										{
																											break;
																										}
																										goto IL_0573;
																										IL_0573:
																										if (16 > b)
																										{
																											break;
																										}
																										goto IL_0581;
																										IL_0581:
																										array2[num6] = array2[num6 - 1];
																										goto IL_0599;
																										IL_0599:
																										array4[num6 - 0] = array4[num6 - 1];
																										goto IL_05b7;
																										IL_05b7:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_06ac;
																										IL_06ac:
																										array3[num6] = array3[num6 - 1];
																										goto IL_06ff;
																										IL_06ff:
																										num6++;
																										goto IL_0de4;
																										IL_05e0:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_061b;
																										IL_061b:
																										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																										goto IL_0644;
																										IL_0644:
																										array2[num6 - 1] = 5;
																										goto IL_0de4;
																									}
																									break;
																								}
																								num = 123;
																								goto IL_08d9;
																								IL_0d52:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)PrelinkAllStop[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0d91;
																								IL_0d91:
																								ptr2 += 8;
																								goto IL_0de4;
																								IL_08d9:
																								if (11 > b)
																								{
																									goto IL_08e7;
																								}
																								goto IL_0d3e;
																								IL_08e7:
																								if (5 < b)
																								{
																									goto IL_08f5;
																								}
																								goto IL_0b4d;
																								IL_08f5:
																								if (8 < b)
																								{
																									goto IL_0903;
																								}
																								goto IL_0a20;
																								IL_0903:
																								if (9 < b)
																								{
																									goto IL_0911;
																								}
																								goto IL_09a2;
																								IL_0911:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_091f;
																								IL_091f:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_092d;
																								IL_092d:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_098f;
																								IL_098f:
																								num6 -= 2;
																								goto IL_0de4;
																								IL_09a2:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_09b0;
																								IL_09b0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								num = 172;
																								goto IL_09f9;
																								IL_09f9:
																								array2[num6 - 2] = 0;
																								goto IL_0a0d;
																								IL_0a0d:
																								num6--;
																								goto IL_0de4;
																								IL_0a20:
																								if (8 > b)
																								{
																									goto IL_0a2e;
																								}
																								goto IL_0b31;
																								IL_0a2e:
																								if (6 >= b)
																								{
																									goto IL_0a39;
																								}
																								goto IL_0aae;
																								IL_0a39:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0a47;
																								IL_0a47:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a87;
																								IL_0a87:
																								array2[num6 - 2] = 0;
																								goto IL_0a9b;
																								IL_0a9b:
																								num6--;
																								goto IL_0de4;
																								IL_0aae:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0abc;
																								IL_0abc:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0aca;
																								IL_0aca:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0b0a;
																								IL_0b0a:
																								array2[num6 - 2] = 0;
																								goto IL_0b1e;
																								IL_0b1e:
																								num6--;
																								goto IL_0de4;
																								IL_0b31:
																								num6--;
																								num = 184;
																								goto IL_0de4;
																								IL_0b4d:
																								if (5 > b)
																								{
																									goto IL_0b5b;
																								}
																								goto IL_0cd7;
																								IL_0b5b:
																								if (2 < b)
																								{
																									goto IL_0b69;
																								}
																								goto IL_0c44;
																								IL_0b69:
																								if (3 >= b)
																								{
																									goto IL_0b74;
																								}
																								goto IL_0bcc;
																								IL_0b74:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0b82;
																								IL_0b82:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0bab;
																								IL_0bab:
																								ptr2 += 8;
																								goto IL_0bb9;
																								IL_0bb9:
																								num6--;
																								goto IL_0de4;
																								IL_0bcc:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0bda;
																								IL_0bda:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0be8;
																								IL_0be8:
																								array2[num6] = 0;
																								goto IL_0bf6;
																								IL_0bf6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0c19;
																								IL_0c19:
																								array3[num6] = null;
																								goto IL_0c23;
																								IL_0c23:
																								num6++;
																								goto IL_0c31;
																								IL_0c31:
																								ptr2 += 8;
																								goto IL_0de4;
																								IL_0c44:
																								if (2 > b)
																								{
																									goto IL_0c4f;
																								}
																								goto IL_0c70;
																								IL_0c4f:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0c5d;
																								IL_0c5d:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0c70:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0cb0;
																								IL_0cb0:
																								array2[num6 - 2] = 0;
																								goto IL_0cc4;
																								IL_0cc4:
																								num6--;
																								goto IL_0de4;
																								IL_0cd7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0d17;
																								IL_0d17:
																								array2[num6 - 2] = 0;
																								goto IL_0d2b;
																								IL_0d2b:
																								num6--;
																								goto IL_0de4;
																								IL_0d3e:
																								array2[num6 - 1] = 0;
																								goto IL_0d52;
																							}
																							break;
																							IL_0486:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0dba;
																					IL_0dc8:
																					num6++;
																					goto IL_0dd6;
																					IL_0dd6:
																					ptr2 += 8;
																					goto IL_0de4;
																					IL_0dba:
																					array2[num6] = 0;
																					goto IL_0dc8;
																					continue;
																					end_IL_0496:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	num = 133;
																	goto IL_0eb9;
																	IL_0eb9:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_072f:
				while (true)
				{
					IL_072f_2:
					array = new byte[4];
					while (true)
					{
						IL_073d:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_07e5_2:
								num6++;
								while (true)
								{
									IL_0de4_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0496_2:
													if (b >= 1)
													{
														num = 162;
														while (b <= 22)
														{
															while (true)
															{
																IL_0476_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_0466_2:
																		if (17 < b)
																		{
																			while (true)
																			{
																				IL_0456_2:
																				if (20 >= b)
																				{
																					while (true)
																					{
																						IL_0446_2:
																						if (20 > b)
																						{
																							while (true)
																							{
																								IL_0439_2:
																								if (18 < b)
																								{
																									while (19 >= b)
																									{
																										while (19 <= b)
																										{
																											while (true)
																											{
																												IL_0403_2:
																												array2[num6 - 1] = 5;
																												while (true)
																												{
																													IL_03c0_2:
																													array3[num6 - 1] = ((delegate*<string[], string>)PrelinkAllStop[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																													num = 228;
																													while (true)
																													{
																														if (num != 228)
																														{
																															if (num != 1209)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 8:
																																goto IL_03c0_2;
																															case 155:
																															case 201:
																																goto IL_0403_2;
																															case 12:
																																goto IL_0419_2;
																															case 23:
																																goto IL_0429_2;
																															case 63:
																																goto IL_0439_2;
																															case 125:
																																goto IL_0446_2;
																															case 75:
																																goto IL_0456_2;
																															case 121:
																																goto IL_0466_2;
																															case 114:
																																goto IL_0476_2;
																															case 162:
																																goto IL_0486_2;
																															case 132:
																																goto IL_0496_2;
																															case 25:
																																goto end_IL_0496_2;
																															case 147:
																															case 182:
																																goto end_IL_04a9;
																															case 98:
																																goto IL_04c4_2;
																															case 51:
																															case 131:
																																goto IL_04d2_2;
																															case 71:
																																goto IL_0519_2;
																															case 145:
																																goto IL_052c_2;
																															case 15:
																															case 108:
																																goto IL_0537_2;
																															case 6:
																															case 115:
																																goto IL_0547_2;
																															case 43:
																															case 159:
																																goto IL_055a_2;
																															case 53:
																																goto IL_0565_2;
																															case 32:
																																goto IL_0573_2;
																															case 4:
																															case 135:
																																goto IL_0581_2;
																															case 69:
																																goto IL_0599_2;
																															case 134:
																																goto IL_05b7_2;
																															case 160:
																																goto IL_05e0_2;
																															case 161:
																																goto IL_05f0_2;
																															case 124:
																															case 129:
																																goto IL_05fb_2;
																															case 9:
																															case 175:
																																goto IL_061b_2;
																															case 83:
																																goto IL_0644_2;
																															case 90:
																															case 178:
																																goto IL_065d_2;
																															case 16:
																																goto IL_0668_2;
																															case 183:
																																goto IL_067b_2;
																															case 80:
																																goto IL_0689_2;
																															case 74:
																															case 199:
																																goto IL_069c_2;
																															case 207:
																																goto IL_06ac_2;
																															case 211:
																																goto IL_06c6_2;
																															case 38:
																																goto IL_06de_2;
																															case 143:
																																goto IL_06ec_2;
																															case 213:
																																goto IL_06ff_2;
																															case 215:
																																goto IL_0712_2;
																															case 122:
																															case 180:
																																goto IL_0720_2;
																															case 78:
																																goto end_IL_04b9;
																															case 45:
																																goto IL_07e5_2;
																															case 7:
																															case 209:
																																goto IL_0814_2;
																															case 77:
																																goto IL_082d_2;
																															case 92:
																																goto IL_083b_2;
																															case 150:
																																goto IL_0849_2;
																															case 152:
																															case 219:
																																goto IL_085c_2;
																															case 101:
																																goto IL_0867_2;
																															case 88:
																															case 217:
																																goto IL_0880_2;
																															case 119:
																																goto IL_0898_2;
																															case 103:
																																goto IL_08a6_2;
																															case 84:
																															case 104:
																																goto IL_08b4_2;
																															case 123:
																																goto IL_08d9_2;
																															case 127:
																															case 198:
																																goto IL_08e7_2;
																															case 87:
																															case 97:
																																goto IL_08f5_2;
																															case 110:
																															case 221:
																																goto IL_0903_2;
																															case 46:
																															case 186:
																																goto IL_0911_2;
																															case 52:
																																goto IL_091f_2;
																															case 59:
																															case 105:
																																goto IL_092d_2;
																															case 28:
																																goto IL_098f_2;
																															case 195:
																																goto IL_09a2_2;
																															case 193:
																															case 210:
																																goto IL_09b0_2;
																															case 172:
																																goto IL_09f9_2;
																															case 76:
																																goto IL_0a0d_2;
																															case 151:
																																goto IL_0a20_2;
																															case 81:
																															case 138:
																																goto IL_0a2e_2;
																															case 18:
																																goto IL_0a39_2;
																															case 67:
																															case 187:
																																goto IL_0a47_2;
																															case 192:
																																goto IL_0a87_2;
																															case 66:
																																goto IL_0a9b_2;
																															case 106:
																																goto IL_0aae_2;
																															case 189:
																																goto IL_0abc_2;
																															case 19:
																															case 40:
																																goto IL_0aca_2;
																															case 153:
																																goto IL_0b0a_2;
																															case 1:
																																goto IL_0b1e_2;
																															case 169:
																															case 208:
																																goto IL_0b31_2;
																															case 99:
																																goto IL_0b4d_2;
																															case 56:
																															case 68:
																																goto IL_0b5b_2;
																															case 3:
																															case 48:
																																goto IL_0b69_2;
																															case 157:
																																goto IL_0b74_2;
																															case 140:
																															case 176:
																																goto IL_0b82_2;
																															case 44:
																																goto IL_0bab_2;
																															case 34:
																																goto IL_0bb9_2;
																															case 188:
																																goto IL_0bcc_2;
																															case 70:
																																goto IL_0bda_2;
																															case 27:
																															case 154:
																																goto IL_0be8_2;
																															case 94:
																																goto IL_0bf6_2;
																															case 73:
																																goto IL_0c19_2;
																															case 218:
																																goto IL_0c23_2;
																															case 37:
																																goto IL_0c31_2;
																															case 72:
																																goto IL_0c44_2;
																															case 128:
																															case 148:
																																goto IL_0c4f_2;
																															case 181:
																																goto IL_0c5d_2;
																															case 142:
																															case 158:
																																goto IL_0c70_2;
																															case 57:
																																goto IL_0cb0_2;
																															case 139:
																																goto IL_0cc4_2;
																															case 29:
																															case 60:
																																goto IL_0cd7_2;
																															case 116:
																																goto IL_0d17_2;
																															case 204:
																																goto IL_0d2b_2;
																															case 126:
																															case 168:
																																goto IL_0d3e_2;
																															case 61:
																																goto IL_0d52_2;
																															case 196:
																																goto IL_0d91_2;
																															case 0:
																															case 11:
																															case 14:
																															case 17:
																															case 21:
																															case 22:
																															case 24:
																															case 26:
																															case 30:
																															case 31:
																															case 39:
																															case 41:
																															case 49:
																															case 50:
																															case 54:
																															case 58:
																															case 64:
																															case 79:
																															case 82:
																															case 85:
																															case 89:
																															case 95:
																															case 96:
																															case 107:
																															case 111:
																															case 112:
																															case 120:
																															case 136:
																															case 146:
																															case 156:
																															case 163:
																															case 166:
																															case 167:
																															case 170:
																															case 173:
																															case 174:
																															case 179:
																															case 191:
																															case 194:
																															case 200:
																															case 212:
																															case 220:
																																goto end_IL_03ad_2;
																															case 47:
																																goto IL_0dba_2;
																															case 5:
																																goto IL_0dc8_2;
																															case 177:
																																goto IL_0dd6_2;
																															case 2:
																															case 10:
																															case 13:
																															case 20:
																															case 42:
																															case 55:
																															case 91:
																															case 93:
																															case 100:
																															case 102:
																															case 109:
																															case 113:
																															case 118:
																															case 130:
																															case 141:
																															case 144:
																															case 149:
																															case 165:
																															case 184:
																															case 197:
																															case 202:
																															case 203:
																															case 206:
																															case 214:
																															case 216:
																																goto IL_0de4_2;
																															case 33:
																																ptr2 = ptr;
																																goto IL_0de4_2;
																															case 185:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentStateRemotingMethodCachedData.CultureListValidRestrictedCodeSid);
																																goto case 33;
																															case 137:
																																array7 = new object[14];
																																goto case 185;
																															case 190:
																																array6 = new long[4];
																																goto case 137;
																															case 65:
																																array5 = new int[6];
																																goto case 190;
																															case 62:
																																array4 = new int[4];
																																goto case 65;
																															case 171:
																																array3 = new object[4];
																																goto case 62;
																															case 86:
																																array2 = new byte[4];
																																goto case 171;
																															case 164:
																																num4 = num2 * 8;
																																goto case 86;
																															case 205:
																																num3 = num2 * 4;
																																goto case 164;
																															case 35:
																																num2 = 1;
																																num = 205;
																																goto case 205;
																															case 36:
																																goto end_IL_07d7;
																															case 117:
																															case 133:
																																goto IL_0eb9_2;
																															}
																															continue;
																														}
																														ptr2 += 8;
																														goto IL_0de4_2;
																														continue;
																														end_IL_03ad_2:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_0419_2:;
																										}
																										break;
																										IL_0429_2:;
																									}
																									break;
																								}
																								goto IL_04c4_2;
																								IL_0519_2:
																								num6 -= 3;
																								goto IL_0de4_2;
																								IL_04c4_2:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_04d2_2;
																								IL_04d2_2:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								num = 71;
																								goto IL_0519_2;
																							}
																							break;
																						}
																						num = 209;
																						goto IL_0814_2;
																						IL_083b_2:
																						num6++;
																						goto IL_0849_2;
																						IL_0849_2:
																						ptr2 += 16;
																						goto IL_0de4_2;
																						IL_0814_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_082d_2;
																						IL_082d_2:
																						array2[num6] = 1;
																						goto IL_083b_2;
																					}
																					break;
																				}
																				goto IL_085c_2;
																				IL_08a6_2:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_08b4_2;
																				IL_085c_2:
																				if (21 >= b)
																				{
																					goto IL_0867_2;
																				}
																				goto IL_0898_2;
																				IL_0867_2:
																				if (21 > b)
																				{
																					num = 89;
																					break;
																				}
																				goto IL_0880_2;
																				IL_08b4_2:
																				num7 = ptr2;
																				num8 = -200;
																				num5 = 1;
																				ptr2 = num7 + num8;
																				goto IL_0de4_2;
																				IL_0880_2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_0de4_2;
																				IL_0898_2:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_08a6_2;
																			}
																			break;
																		}
																		goto IL_052c_2;
																		IL_06ec_2:
																		ptr2 += 8;
																		goto IL_0de4_2;
																		IL_052c_2:
																		if (17 > b)
																		{
																			goto IL_0537_2;
																		}
																		goto IL_0547_2;
																		IL_0537_2:
																		if (14 < b)
																		{
																			goto IL_055a_2;
																		}
																		goto IL_05f0_2;
																		IL_05f0_2:
																		if (14 <= b)
																		{
																			goto IL_05fb_2;
																		}
																		goto IL_065d_2;
																		IL_05fb_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																		goto IL_067b_2;
																		IL_067b_2:
																		ptr2 += 8;
																		goto IL_0689_2;
																		IL_0689_2:
																		num6--;
																		goto IL_0de4_2;
																		IL_065d_2:
																		if (12 >= b)
																		{
																			goto IL_0668_2;
																		}
																		goto IL_069c_2;
																		IL_0668_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0de4_2;
																		IL_069c_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_0712_2;
																		IL_0712_2:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_0720_2;
																		IL_0720_2:
																		array8 = array3;
																		num9 = num6;
																		if (array == null)
																		{
																			goto IL_072f_2;
																		}
																		goto IL_073d;
																		IL_055a_2:
																		if (15 < b)
																		{
																			goto IL_0565_2;
																		}
																		goto IL_05e0_2;
																		IL_0565_2:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_0573_2;
																		IL_0573_2:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_0581_2;
																		IL_0581_2:
																		array2[num6] = array2[num6 - 1];
																		goto IL_0599_2;
																		IL_0599_2:
																		array4[num6 - 0] = array4[num6 - 1];
																		goto IL_05b7_2;
																		IL_05b7_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_06ac_2;
																		IL_06ac_2:
																		array3[num6] = array3[num6 - 1];
																		goto IL_06ff_2;
																		IL_06ff_2:
																		num6++;
																		goto IL_0de4_2;
																		IL_05e0_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_061b_2;
																		IL_061b_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																		goto IL_0644_2;
																		IL_0644_2:
																		array2[num6 - 1] = 5;
																		goto IL_0de4_2;
																		IL_0547_2:
																		array2[num6] = 5;
																		goto IL_06c6_2;
																		IL_06c6_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_06de_2;
																		IL_06de_2:
																		num6++;
																		goto IL_06ec_2;
																	}
																	break;
																}
																num = 123;
																goto IL_08d9_2;
																IL_0d52_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)PrelinkAllStop[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_0d91_2;
																IL_0d91_2:
																ptr2 += 8;
																goto IL_0de4_2;
																IL_08d9_2:
																if (11 > b)
																{
																	goto IL_08e7_2;
																}
																goto IL_0d3e_2;
																IL_08e7_2:
																if (5 < b)
																{
																	goto IL_08f5_2;
																}
																goto IL_0b4d_2;
																IL_08f5_2:
																if (8 < b)
																{
																	goto IL_0903_2;
																}
																goto IL_0a20_2;
																IL_0903_2:
																if (9 < b)
																{
																	goto IL_0911_2;
																}
																goto IL_09a2_2;
																IL_0911_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_091f_2;
																IL_091f_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_092d_2;
																IL_092d_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_098f_2;
																IL_098f_2:
																num6 -= 2;
																goto IL_0de4_2;
																IL_09a2_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_09b0_2;
																IL_09b0_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 172;
																goto IL_09f9_2;
																IL_09f9_2:
																array2[num6 - 2] = 0;
																goto IL_0a0d_2;
																IL_0a0d_2:
																num6--;
																goto IL_0de4_2;
																IL_0a20_2:
																if (8 > b)
																{
																	goto IL_0a2e_2;
																}
																goto IL_0b31_2;
																IL_0a2e_2:
																if (6 >= b)
																{
																	goto IL_0a39_2;
																}
																goto IL_0aae_2;
																IL_0a39_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0a47_2;
																IL_0a47_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a87_2;
																IL_0a87_2:
																array2[num6 - 2] = 0;
																goto IL_0a9b_2;
																IL_0a9b_2:
																num6--;
																goto IL_0de4_2;
																IL_0aae_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0abc_2;
																IL_0abc_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0aca_2;
																IL_0aca_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0b0a_2;
																IL_0b0a_2:
																array2[num6 - 2] = 0;
																goto IL_0b1e_2;
																IL_0b1e_2:
																num6--;
																goto IL_0de4_2;
																IL_0b31_2:
																num6--;
																num = 184;
																goto IL_0de4_2;
																IL_0b4d_2:
																if (5 > b)
																{
																	goto IL_0b5b_2;
																}
																goto IL_0cd7_2;
																IL_0b5b_2:
																if (2 < b)
																{
																	goto IL_0b69_2;
																}
																goto IL_0c44_2;
																IL_0b69_2:
																if (3 >= b)
																{
																	goto IL_0b74_2;
																}
																goto IL_0bcc_2;
																IL_0b74_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_0b82_2;
																IL_0b82_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0bab_2;
																IL_0bab_2:
																ptr2 += 8;
																goto IL_0bb9_2;
																IL_0bb9_2:
																num6--;
																goto IL_0de4_2;
																IL_0bcc_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_0bda_2;
																IL_0bda_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0be8_2;
																IL_0be8_2:
																array2[num6] = 0;
																goto IL_0bf6_2;
																IL_0bf6_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0c19_2;
																IL_0c19_2:
																array3[num6] = null;
																goto IL_0c23_2;
																IL_0c23_2:
																num6++;
																goto IL_0c31_2;
																IL_0c31_2:
																ptr2 += 8;
																goto IL_0de4_2;
																IL_0c44_2:
																if (2 > b)
																{
																	goto IL_0c4f_2;
																}
																goto IL_0c70_2;
																IL_0c4f_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_0c5d_2;
																IL_0c5d_2:
																if (1 <= b)
																{
																}
																break;
																IL_0c70_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0cb0_2;
																IL_0cb0_2:
																array2[num6 - 2] = 0;
																goto IL_0cc4_2;
																IL_0cc4_2:
																num6--;
																goto IL_0de4_2;
																IL_0cd7_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0d17_2;
																IL_0d17_2:
																array2[num6 - 2] = 0;
																goto IL_0d2b_2;
																IL_0d2b_2:
																num6--;
																goto IL_0de4_2;
																IL_0d3e_2:
																array2[num6 - 1] = 0;
																goto IL_0d52_2;
															}
															break;
															IL_0486_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0dba_2;
													IL_0dc8_2:
													num6++;
													goto IL_0dd6_2;
													IL_0dd6_2:
													ptr2 += 8;
													goto IL_0de4_2;
													IL_0dba_2:
													array2[num6] = 0;
													goto IL_0dc8_2;
													continue;
													end_IL_0496_2:
													break;
												}
												continue;
												end_IL_04a9:
												break;
											}
											continue;
											end_IL_04b9:
											break;
										}
										break;
									}
									num = 133;
									goto IL_0eb9_2;
									IL_0eb9_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_07d7:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class100()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13()
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 55;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllButOverflowUpdateTimeOut.GetHashFromAssemblyFilegetScheduledTasks);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0370:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0353:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_0343:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_0333:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_0323:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (13 <= b)
																											{
																												while (true)
																												{
																													IL_0296:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													num = 157;
																													while (true)
																													{
																														if (num != 157)
																														{
																															if (num != 1138)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 61:
																															case 123:
																																goto IL_0296;
																															case 8:
																																goto IL_0303;
																															case 46:
																															case 114:
																																goto IL_0313;
																															case 24:
																																goto IL_0323;
																															case 31:
																																goto IL_0333;
																															case 37:
																																goto IL_0343;
																															case 98:
																																goto IL_0353;
																															case 38:
																																goto IL_0360;
																															case 143:
																																goto IL_0370;
																															case 144:
																																goto end_IL_0370;
																															case 2:
																															case 94:
																																goto end_IL_0380;
																															case 89:
																																goto IL_039b;
																															case 73:
																															case 79:
																																goto end_IL_0283;
																															case 7:
																															case 22:
																																goto IL_03b6;
																															case 101:
																																goto IL_03ce;
																															case 14:
																															case 92:
																																goto IL_03dc;
																															case 36:
																																goto IL_03e7;
																															case 103:
																																goto IL_03f5;
																															case 108:
																																goto IL_0403;
																															case 58:
																															case 60:
																																goto IL_0411;
																															case 23:
																																goto IL_0433;
																															case 115:
																																goto IL_0441;
																															case 104:
																																goto IL_044f;
																															case 51:
																															case 117:
																																goto IL_0462;
																															case 126:
																																goto IL_0472;
																															case 86:
																															case 90:
																																goto IL_0480;
																															case 127:
																																goto IL_04c5;
																															case 39:
																															case 44:
																																goto IL_04d3;
																															case 119:
																																goto IL_04fc;
																															case 77:
																															case 132:
																																goto IL_0515;
																															case 83:
																																goto IL_0555;
																															case 16:
																																goto IL_0569;
																															case 29:
																															case 136:
																																goto IL_057c;
																															case 100:
																																goto IL_058a;
																															case 41:
																															case 113:
																																goto IL_0595;
																															case 10:
																																goto IL_05a3;
																															case 62:
																															case 75:
																																goto IL_05b1;
																															case 120:
																																goto IL_05bf;
																															case 97:
																																goto IL_05d7;
																															case 80:
																																goto IL_05e5;
																															case 52:
																															case 125:
																																goto IL_05f8;
																															case 63:
																																goto IL_0637;
																															case 99:
																																goto IL_064a;
																															case 3:
																																goto IL_0663;
																															case 6:
																															case 28:
																																goto IL_067c;
																															case 116:
																																goto IL_06ae;
																															case 59:
																																goto IL_06bc;
																															case 140:
																															case 141:
																																goto IL_06d8;
																															case 47:
																																goto IL_06e6;
																															case 49:
																															case 139:
																																goto IL_06f1;
																															case 30:
																																goto IL_06ff;
																															case 69:
																																goto IL_0722;
																															case 82:
																																goto IL_072c;
																															case 45:
																																goto IL_073a;
																															case 118:
																																goto IL_074d;
																															case 93:
																																goto IL_075b;
																															case 57:
																															case 76:
																																goto IL_0777;
																															case 4:
																																goto IL_0785;
																															case 72:
																															case 74:
																																goto IL_0793;
																															case 9:
																																goto IL_07d7;
																															case 26:
																																goto IL_07f4;
																															case 19:
																															case 147:
																																goto IL_0807;
																															case 96:
																																goto IL_0825;
																															case 11:
																																goto IL_0833;
																															case 148:
																																goto IL_0843;
																															case 70:
																																goto IL_0857;
																															case 42:
																															case 67:
																																goto IL_0877;
																															case 20:
																															case 146:
																																goto IL_0890;
																															case 109:
																																goto IL_089b;
																															case 5:
																															case 12:
																															case 25:
																															case 33:
																															case 34:
																															case 43:
																															case 64:
																															case 65:
																															case 66:
																															case 68:
																															case 78:
																															case 84:
																															case 85:
																															case 88:
																															case 91:
																															case 95:
																															case 102:
																															case 106:
																															case 107:
																															case 122:
																															case 129:
																															case 130:
																															case 131:
																															case 133:
																															case 137:
																															case 138:
																															case 149:
																															case 150:
																																goto end_IL_0303;
																															case 13:
																															case 15:
																															case 17:
																															case 27:
																															case 32:
																															case 35:
																															case 40:
																															case 48:
																															case 50:
																															case 54:
																															case 71:
																															case 105:
																															case 111:
																															case 112:
																															case 121:
																															case 128:
																															case 135:
																															case 142:
																																goto end_IL_0390;
																															case 134:
																																goto end_IL_08b9;
																															case 145:
																																goto end_IL_08cc;
																															case 81:
																																goto end_IL_08d6;
																															case 1:
																																goto end_IL_08e1;
																															case 18:
																															case 53:
																																goto end_IL_08f1;
																															case 87:
																																goto end_IL_0901;
																															case 21:
																															case 110:
																																goto end_IL_0911;
																															case 55:
																																goto end_IL_0921;
																															case 56:
																																goto end_IL_0931;
																															case 0:
																															case 124:
																																goto IL_0955;
																															}
																															continue;
																														}
																														num5 -= 2;
																														goto end_IL_0390;
																														continue;
																														end_IL_0283:
																														break;
																													}
																													break;
																												}
																												goto IL_03a6;
																												continue;
																												end_IL_0303:
																												break;
																												IL_0303:;
																											}
																											break;
																											IL_0313:;
																										}
																										break;
																									}
																									goto IL_0877;
																									IL_0877:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0390;
																								}
																								break;
																							}
																							goto IL_0890;
																							IL_089b:
																							if (15 > b)
																							{
																							}
																							break;
																							IL_0890:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_089b;
																						}
																						break;
																					}
																					goto IL_0472;
																					IL_07d7:
																					array[num5 - 2] = 0;
																					num = 26;
																					goto IL_07f4;
																					IL_0472:
																					if (12 <= b)
																					{
																						goto IL_0480;
																					}
																					goto IL_06d8;
																					IL_0480:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0843;
																					IL_0843:
																					array[num5 - 2] = 0;
																					goto IL_0857;
																					IL_0857:
																					num5--;
																					goto end_IL_0390;
																					IL_06d8:
																					if (10 >= b)
																					{
																						goto IL_06e6;
																					}
																					num = 57;
																					goto IL_0777;
																					IL_06e6:
																					if (10 <= b)
																					{
																						goto IL_06f1;
																					}
																					goto IL_074d;
																					IL_06f1:
																					array[num5] = 0;
																					goto IL_06ff;
																					IL_06ff:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0722;
																					IL_0722:
																					array2[num5] = null;
																					goto IL_072c;
																					IL_072c:
																					num5++;
																					goto IL_073a;
																					IL_073a:
																					ptr2 += 8;
																					goto end_IL_0390;
																					IL_074d:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_075b;
																					IL_075b:
																					if (9 > b)
																					{
																						break;
																					}
																					goto end_IL_0390;
																					IL_07f4:
																					num5--;
																					goto end_IL_0390;
																					IL_0777:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0785;
																					IL_0785:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0793;
																					IL_0793:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_07d7;
																				}
																				break;
																			}
																			goto IL_039b;
																			IL_0825:
																			ptr2 += 8;
																			goto IL_0833;
																			IL_039b:
																			if (8 > b)
																			{
																				goto IL_03a6;
																			}
																			goto IL_03b6;
																			IL_03a6:
																			if (4 >= b)
																			{
																				goto IL_03ce;
																			}
																			goto IL_057c;
																			IL_057c:
																			if (6 >= b)
																			{
																				goto IL_058a;
																			}
																			goto IL_064a;
																			IL_058a:
																			if (6 > b)
																			{
																				goto IL_0595;
																			}
																			goto IL_05f8;
																			IL_0595:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_05a3;
																			IL_05a3:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_05b1;
																			IL_05b1:
																			array[num5] = 5;
																			goto IL_05bf;
																			IL_05bf:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_05d7;
																			IL_05d7:
																			num5++;
																			goto IL_05e5;
																			IL_05e5:
																			ptr2 += 8;
																			goto end_IL_0390;
																			IL_05f8:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0637;
																			IL_0637:
																			num5 -= 3;
																			goto end_IL_0390;
																			IL_064a:
																			if (7 < b)
																			{
																				num = 78;
																				break;
																			}
																			goto IL_0663;
																			IL_0833:
																			num5--;
																			goto end_IL_0390;
																			IL_0663:
																			if (7 > b)
																			{
																				num = 129;
																				break;
																			}
																			goto IL_067c;
																			IL_03b6:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0390;
																			IL_067c:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 116;
																			goto IL_06ae;
																			IL_06ae:
																			ptr2 += 8;
																			goto IL_06bc;
																			IL_06bc:
																			num5--;
																			num = 50;
																			goto end_IL_0390;
																			IL_03ce:
																			if (4 > b)
																			{
																				goto IL_03dc;
																			}
																			goto IL_0807;
																			IL_03dc:
																			if (2 >= b)
																			{
																				goto IL_03e7;
																			}
																			goto IL_0462;
																			IL_03e7:
																			if (2 > b)
																			{
																				goto IL_03f5;
																			}
																			goto IL_0515;
																			IL_03f5:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0403;
																			IL_0403:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0411;
																			IL_0411:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 23;
																			goto IL_0433;
																			IL_0433:
																			array[num5] = 0;
																			goto IL_0441;
																			IL_0441:
																			num5++;
																			goto IL_044f;
																			IL_044f:
																			ptr2 += 8;
																			goto end_IL_0390;
																			IL_0515:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0555;
																			IL_0555:
																			array[num5 - 2] = 0;
																			goto IL_0569;
																			IL_0569:
																			num5--;
																			goto end_IL_0390;
																			IL_0462:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_04c5;
																			IL_04c5:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_04d3;
																			IL_04d3:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04fc;
																			IL_04fc:
																			array[num5 - 1] = 5;
																			goto end_IL_0390;
																			IL_0807:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0825;
																		}
																		break;
																		IL_0360:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0390;
																continue;
																end_IL_0370:
																break;
															}
															continue;
															end_IL_0380:
															break;
														}
														continue;
														end_IL_0390:
														break;
													}
													continue;
												}
												goto IL_0955;
												IL_0955:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b9:
												break;
											}
											continue;
											end_IL_08cc:
											break;
										}
										continue;
										end_IL_08d6:
										break;
									}
									continue;
									end_IL_08e1:
									break;
								}
								continue;
								end_IL_08f1:
								break;
							}
							continue;
							end_IL_0901:
							break;
						}
						continue;
						end_IL_0911:
						break;
					}
					continue;
					end_IL_0921:
					break;
				}
				continue;
				end_IL_0931:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_5)
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 31;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								IL_0645:
								long[] array4 = new long[2];
								while (true)
								{
									IL_0630:
									array3[0] = int_5;
									while (true)
									{
										IL_0625:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NullStreamBaseDirectory.getDateTimeITuple);
										while (true)
										{
											IL_0612:
											byte* ptr2 = ptr;
											num = 85;
											while (true)
											{
												IL_0607:
												num = 77;
												while (true)
												{
													IL_05f4:
													if (num4 != 1)
													{
														while (true)
														{
															IL_02ab:
															byte b = *ptr2;
															while (true)
															{
																IL_029b:
																ptr2++;
																while (true)
																{
																	IL_028b:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_026b:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0258:
																						if (8 >= b)
																						{
																							num = 71;
																							while (true)
																							{
																								IL_024b:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_023b:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_01ed:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 38;
																														while (true)
																														{
																															IL_01d4:
																															array[num5] = 0;
																															num = 105;
																															while (true)
																															{
																																if (num != 105)
																																{
																																	if (num != 1086)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 38:
																																		goto IL_01d4;
																																	case 5:
																																	case 42:
																																		goto IL_01ed;
																																	case 55:
																																		goto IL_021b;
																																	case 12:
																																		goto IL_022b;
																																	case 93:
																																		goto IL_023b;
																																	case 71:
																																		goto IL_024b;
																																	case 96:
																																		goto IL_0258;
																																	case 8:
																																		goto IL_026b;
																																	case 87:
																																		goto IL_027b;
																																	case 33:
																																		goto IL_028b;
																																	case 49:
																																		goto IL_029b;
																																	case 26:
																																	case 64:
																																		goto IL_02ab;
																																	case 21:
																																	case 27:
																																		goto IL_02b6;
																																	case 16:
																																		goto IL_0318;
																																	case 45:
																																		goto IL_032b;
																																	case 11:
																																		goto IL_0336;
																																	case 18:
																																		goto IL_0344;
																																	case 50:
																																		goto IL_0360;
																																	case 62:
																																		goto IL_0370;
																																	case 13:
																																	case 58:
																																		goto IL_037e;
																																	case 15:
																																		goto IL_03be;
																																	case 4:
																																		goto IL_03d2;
																																	case 34:
																																	case 68:
																																		goto IL_03e5;
																																	case 80:
																																		goto IL_040a;
																																	case 3:
																																	case 79:
																																		goto IL_0415;
																																	case 47:
																																		goto IL_0423;
																																	case 44:
																																		goto IL_044b;
																																	case 52:
																																	case 56:
																																		goto IL_0456;
																																	case 23:
																																		goto IL_0461;
																																	case 74:
																																		goto IL_047d;
																																	case 37:
																																	case 54:
																																		goto IL_048b;
																																	case 78:
																																		goto IL_04a3;
																																	case 29:
																																		goto IL_04ae;
																																	case 14:
																																		goto IL_04bc;
																																	case 41:
																																	case 65:
																																		goto IL_04cc;
																																	case 39:
																																		goto IL_04f5;
																																	case 81:
																																		goto IL_050c;
																																	case 84:
																																		goto IL_0528;
																																	case 67:
																																	case 86:
																																		goto IL_053b;
																																	case 59:
																																		goto IL_0554;
																																	case 57:
																																		goto IL_0562;
																																	case 76:
																																		goto IL_0579;
																																	case 90:
																																		goto IL_0589;
																																	case 24:
																																		goto IL_059c;
																																	case 6:
																																		goto IL_05aa;
																																	case 82:
																																		goto IL_05d1;
																																	case 0:
																																	case 1:
																																	case 19:
																																	case 30:
																																	case 35:
																																	case 40:
																																	case 46:
																																	case 51:
																																	case 60:
																																	case 61:
																																	case 70:
																																	case 72:
																																	case 73:
																																	case 83:
																																	case 88:
																																	case 91:
																																	case 98:
																																		goto end_IL_021b;
																																	case 9:
																																	case 17:
																																	case 36:
																																	case 43:
																																	case 63:
																																	case 66:
																																	case 69:
																																	case 75:
																																	case 77:
																																	case 94:
																																	case 95:
																																	case 97:
																																		goto IL_05f4;
																																	case 85:
																																		goto IL_0607;
																																	case 25:
																																		goto IL_0612;
																																	case 53:
																																		goto IL_0625;
																																	case 22:
																																		goto IL_0630;
																																	case 10:
																																		goto IL_0645;
																																	case 48:
																																	case 89:
																																		goto end_IL_01c1;
																																	case 2:
																																		goto end_IL_0655;
																																	case 28:
																																	case 92:
																																		goto end_IL_0665;
																																	case 31:
																																		goto end_IL_0675;
																																	case 32:
																																		goto end_IL_0685;
																																	case 7:
																																	case 20:
																																		goto IL_06a9;
																																	}
																																	continue;
																																}
																																num5++;
																																num = 82;
																																goto IL_05d1;
																																IL_05d1:
																																ptr2 += 8;
																																goto IL_05f4;
																																continue;
																																end_IL_01c1:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_028b;
																													continue;
																													end_IL_021b:
																													break;
																													IL_021b:;
																												}
																												break;
																												IL_022b:;
																											}
																											break;
																										}
																										goto IL_0370;
																										IL_03d2:
																										num5--;
																										goto IL_05f4;
																										IL_0370:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_037e;
																										IL_037e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03be;
																										IL_03be:
																										array[num5 - 2] = 0;
																										goto IL_03d2;
																									}
																									break;
																								}
																								goto IL_02b6;
																								IL_0318:
																								num5 -= 2;
																								goto IL_05f4;
																								IL_02b6:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0318;
																							}
																							break;
																						}
																						goto IL_032b;
																						IL_03e5:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						num = 9;
																						goto IL_05f4;
																						IL_0360:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_03e5;
																						IL_032b:
																						if (9 < b)
																						{
																							goto IL_0336;
																						}
																						goto IL_0360;
																						IL_0336:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0344;
																						IL_0344:
																						if (10 <= b)
																						{
																							num = 91;
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_040a;
																				IL_04f5:
																				ptr2 += 8;
																				num = 81;
																				goto IL_050c;
																				IL_040a:
																				if (5 <= b)
																				{
																					goto IL_0415;
																				}
																				goto IL_044b;
																				IL_0415:
																				array[num5] = 0;
																				goto IL_0423;
																				IL_0423:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0589;
																				IL_0589:
																				array2[num5] = null;
																				num = 24;
																				goto IL_059c;
																				IL_059c:
																				num5++;
																				goto IL_05aa;
																				IL_05aa:
																				ptr2 += 8;
																				goto IL_05f4;
																				IL_044b:
																				if (2 < b)
																				{
																					goto IL_0456;
																				}
																				goto IL_04a3;
																				IL_0456:
																				if (3 < b)
																				{
																					goto IL_0461;
																				}
																				num = 74;
																				goto IL_047d;
																				IL_0461:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0528;
																				IL_0528:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05f4;
																				IL_050c:
																				num5--;
																				num = 17;
																				goto IL_05f4;
																				IL_047d:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_048b;
																				IL_048b:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05f4;
																				IL_04a3:
																				if (2 > b)
																				{
																					goto IL_04ae;
																				}
																				goto IL_04cc;
																				IL_04ae:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04bc;
																				IL_04bc:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_053b;
																				IL_053b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0554;
																				IL_0554:
																				array[num5] = 0;
																				goto IL_0562;
																				IL_0562:
																				num5++;
																				num = 76;
																				goto IL_0579;
																				IL_0579:
																				ptr2 += 8;
																				goto IL_05f4;
																				IL_04cc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f5;
																			}
																			break;
																			IL_027b:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05f4;
																	continue;
																	end_IL_028b:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_06a9;
													IL_06a9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							continue;
							end_IL_0655:
							break;
						}
						continue;
						end_IL_0665:
						break;
					}
					continue;
					end_IL_0675:
					break;
				}
				continue;
				end_IL_0685:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_5)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 76;
					while (true)
					{
						byte[] array = new byte[3];
						num = 73;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									num = 75;
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DebuggerBrowsableAttributeDenyOnlyPrimaryGroupSid.IntPtrForwardRef);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 30;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0278:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_0258:
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_0248:
																							if (6 > b)
																							{
																								while (true)
																								{
																									IL_0238:
																									if (3 >= b)
																									{
																										while (true)
																										{
																											IL_022b:
																											if (3 > b)
																											{
																												while (true)
																												{
																													IL_021b:
																													if (1 >= b)
																													{
																														while (true)
																														{
																															IL_0208:
																															if (1 > b)
																															{
																																num = 118;
																																while (num != 118)
																																{
																																	if (num != 1099)
																																	{
																																		goto IL_0594;
																																	}
																																	switch (num)
																																	{
																																	case 90:
																																		goto IL_0208;
																																	case 17:
																																		goto IL_021b;
																																	case 60:
																																		goto IL_022b;
																																	case 55:
																																		goto IL_0238;
																																	case 109:
																																		goto IL_0248;
																																	case 92:
																																		goto IL_0258;
																																	case 79:
																																		goto IL_0268;
																																	case 21:
																																		goto IL_0278;
																																	case 54:
																																		goto end_IL_0278;
																																	case 30:
																																		goto end_IL_0288;
																																	case 88:
																																		goto end_IL_0298;
																																	case 44:
																																	case 67:
																																		goto IL_02ae;
																																	case 14:
																																	case 71:
																																		goto IL_02c6;
																																	case 104:
																																		goto IL_02df;
																																	case 96:
																																		goto IL_02ed;
																																	case 50:
																																		goto IL_02fb;
																																	case 40:
																																		goto IL_030e;
																																	case 108:
																																		goto IL_031c;
																																	case 84:
																																	case 95:
																																		goto IL_032a;
																																	case 58:
																																		goto IL_0353;
																																	case 56:
																																		goto IL_0361;
																																	case 105:
																																		goto IL_037d;
																																	case 26:
																																		goto IL_0388;
																																	case 13:
																																		goto IL_0396;
																																	case 36:
																																	case 64:
																																		goto IL_03a4;
																																	case 87:
																																		goto IL_03b2;
																																	case 81:
																																		goto IL_03d5;
																																	case 11:
																																		goto IL_03df;
																																	case 97:
																																		goto IL_03ed;
																																	case 94:
																																		goto IL_0409;
																																	case 69:
																																	case 89:
																																		goto IL_041c;
																																	case 31:
																																		goto IL_045c;
																																	case 6:
																																		goto IL_0470;
																																	case 18:
																																		goto IL_048c;
																																	case 5:
																																	case 52:
																																		goto IL_0497;
																																	case 32:
																																		goto IL_04a2;
																																	case 63:
																																	case 68:
																																		goto IL_04b0;
																																	case 70:
																																		goto IL_04cc;
																																	case 47:
																																		goto IL_04da;
																																	case 61:
																																		goto IL_04ed;
																																	case 66:
																																	case 85:
																																		goto IL_04f8;
																																	case 77:
																																		goto IL_055a;
																																	case 23:
																																		goto IL_056d;
																																	case 53:
																																	case 65:
																																		goto IL_0578;
																																	case 3:
																																		goto IL_0586;
																																	case 12:
																																	case 15:
																																		goto IL_0594;
																																	case 27:
																																		goto IL_05b7;
																																	case 38:
																																		goto IL_05ce;
																																	case 74:
																																		goto IL_05dc;
																																	case 72:
																																		goto IL_05ef;
																																	case 4:
																																	case 91:
																																		goto IL_05fa;
																																	case 110:
																																		goto IL_063a;
																																	case 37:
																																		goto IL_064e;
																																	case 20:
																																	case 22:
																																	case 29:
																																	case 41:
																																	case 43:
																																	case 46:
																																	case 49:
																																	case 51:
																																	case 57:
																																	case 59:
																																	case 62:
																																	case 78:
																																	case 80:
																																	case 86:
																																	case 98:
																																	case 99:
																																	case 101:
																																	case 103:
																																	case 106:
																																	case 107:
																																	case 111:
																																		goto end_IL_01f5;
																																	case 2:
																																	case 8:
																																	case 9:
																																	case 25:
																																	case 33:
																																	case 34:
																																	case 35:
																																	case 42:
																																	case 45:
																																	case 48:
																																	case 82:
																																	case 83:
																																	case 100:
																																	case 102:
																																		goto end_IL_02a3;
																																	case 10:
																																		goto end_IL_0671;
																																	case 19:
																																		goto end_IL_0684;
																																	case 75:
																																		goto end_IL_068e;
																																	case 7:
																																		goto end_IL_0699;
																																	case 28:
																																	case 93:
																																		goto end_IL_06ae;
																																	case 73:
																																		goto end_IL_06c7;
																																	case 76:
																																		goto end_IL_06d7;
																																	case 24:
																																		goto end_IL_06e7;
																																	case 0:
																																		goto end_IL_0700;
																																	case 1:
																																		goto end_IL_070b;
																																	case 16:
																																	case 39:
																																		goto IL_0726;
																																	}
																																	continue;
																																	end_IL_01f5:
																																	break;
																																}
																																break;
																															}
																															goto IL_02c6;
																															IL_02ed:
																															num5++;
																															goto IL_02fb;
																															IL_02fb:
																															ptr2 += 8;
																															goto end_IL_02a3;
																															IL_02c6:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															goto IL_02df;
																															IL_02df:
																															array[num5] = 0;
																															goto IL_02ed;
																														}
																														break;
																													}
																													goto IL_030e;
																													IL_0361:
																													num5--;
																													num = 83;
																													goto end_IL_02a3;
																													IL_030e:
																													if (2 < b)
																													{
																														break;
																													}
																													goto IL_031c;
																													IL_031c:
																													if (2 > b)
																													{
																														break;
																													}
																													goto IL_032a;
																													IL_032a:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0353;
																													IL_0353:
																													ptr2 += 8;
																													goto IL_0361;
																												}
																												break;
																											}
																											goto IL_02ae;
																											IL_02ae:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_02a3;
																										}
																										break;
																									}
																									goto IL_037d;
																									IL_0409:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02a3;
																									IL_037d:
																									if (4 < b)
																									{
																										goto IL_0388;
																									}
																									num = 94;
																									goto IL_0409;
																									IL_0388:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0396;
																									IL_0396:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_03a4;
																									IL_03a4:
																									array[num5] = 0;
																									goto IL_03b2;
																									IL_03b2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03d5;
																									IL_03d5:
																									array2[num5] = null;
																									goto IL_03df;
																									IL_03df:
																									num5++;
																									goto IL_03ed;
																									IL_03ed:
																									ptr2 += 8;
																									goto end_IL_02a3;
																								}
																								break;
																							}
																							goto IL_041c;
																							IL_0470:
																							num5--;
																							num = 100;
																							goto end_IL_02a3;
																							IL_041c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_045c;
																							IL_045c:
																							array[num5 - 2] = 0;
																							goto IL_0470;
																						}
																						break;
																					}
																					goto IL_048c;
																					IL_064e:
																					num5--;
																					goto end_IL_02a3;
																					IL_048c:
																					if (9 < b)
																					{
																						goto IL_0497;
																					}
																					goto IL_04ed;
																					IL_0497:
																					if (10 >= b)
																					{
																						goto IL_04a2;
																					}
																					goto IL_04cc;
																					IL_04a2:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_04b0;
																					IL_04b0:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a3;
																					IL_04cc:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_04da;
																					IL_04da:
																					if (11 > b)
																					{
																					}
																					break;
																					IL_04ed:
																					if (9 <= b)
																					{
																						goto IL_04f8;
																					}
																					goto IL_056d;
																					IL_04f8:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_055a;
																					IL_055a:
																					num5 -= 2;
																					goto end_IL_02a3;
																					IL_056d:
																					if (7 < b)
																					{
																						goto IL_0578;
																					}
																					goto IL_05ef;
																					IL_0578:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0586;
																					IL_0586:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0594;
																					IL_0594:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05b7;
																					IL_05b7:
																					array[num5] = 0;
																					num = 38;
																					goto IL_05ce;
																					IL_05ce:
																					num5++;
																					goto IL_05dc;
																					IL_05dc:
																					ptr2 += 8;
																					goto end_IL_02a3;
																					IL_05ef:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_05fa;
																					IL_05fa:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_063a;
																					IL_063a:
																					array[num5 - 2] = 0;
																					goto IL_064e;
																				}
																				break;
																				IL_0268:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_02a3;
																		continue;
																		end_IL_0278:
																		break;
																	}
																	continue;
																	end_IL_0288:
																	break;
																}
																continue;
																end_IL_0298:
																break;
															}
															continue;
															end_IL_02a3:
															break;
														}
														continue;
													}
													goto IL_0726;
													IL_0726:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0671:
													break;
												}
												continue;
												end_IL_0684:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_0699:
										break;
									}
									continue;
									end_IL_06ae:
									break;
								}
								continue;
								end_IL_06c7:
								break;
							}
							continue;
							end_IL_06d7:
							break;
						}
						continue;
						end_IL_06e7:
						break;
					}
					continue;
					end_IL_0700:
					break;
				}
				continue;
				end_IL_070b:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_5)
	{
		int num = 37;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 101;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CaseInsensitiveComparerIsClosed.KerbTicketLogonsetAbbreviatedMonthNames);
											num = 50;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0334:
															byte b = *ptr2;
															while (true)
															{
																IL_0324:
																ptr2++;
																while (true)
																{
																	IL_0314:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02f4:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02e7:
																						if (7 <= b)
																						{
																							while (true)
																							{
																								IL_02a5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								while (true)
																								{
																									IL_028f:
																									array[num5 - 2] = 0;
																									while (true)
																									{
																										IL_0276:
																										num5--;
																										num = 149;
																										while (num != 149 && num == 1130)
																										{
																											switch (num)
																											{
																											case 94:
																												goto IL_0276;
																											case 39:
																												goto IL_028f;
																											case 6:
																											case 124:
																												goto IL_02a5;
																											case 95:
																												goto IL_02e7;
																											case 85:
																												goto IL_02f4;
																											case 110:
																												goto IL_0304;
																											case 24:
																												goto IL_0314;
																											case 98:
																												goto IL_0324;
																											case 23:
																											case 66:
																												goto IL_0334;
																											case 30:
																											case 99:
																												goto IL_033f;
																											case 29:
																											case 43:
																												goto IL_034a;
																											case 4:
																												goto IL_0358;
																											case 9:
																											case 69:
																												goto IL_0366;
																											case 68:
																												goto IL_0374;
																											case 19:
																												goto IL_0399;
																											case 62:
																												goto IL_03a7;
																											case 52:
																											case 79:
																												goto IL_03b2;
																											case 46:
																												goto IL_03c0;
																											case 103:
																												goto IL_03d0;
																											case 55:
																												goto IL_03da;
																											case 119:
																												goto IL_03ea;
																											case 75:
																											case 120:
																												goto IL_03fa;
																											case 87:
																												goto IL_0423;
																											case 60:
																												goto IL_0431;
																											case 41:
																											case 122:
																												goto IL_0444;
																											case 88:
																												goto IL_0452;
																											case 132:
																												goto IL_0465;
																											case 89:
																											case 134:
																												goto IL_0478;
																											case 40:
																												goto IL_0491;
																											case 125:
																												goto IL_049f;
																											case 58:
																												goto IL_04ad;
																											case 26:
																											case 140:
																												goto IL_04c0;
																											case 113:
																											case 141:
																												goto IL_04d8;
																											case 107:
																												goto IL_04e6;
																											case 93:
																											case 128:
																												goto IL_04f4;
																											case 17:
																												goto IL_0534;
																											case 20:
																												goto IL_0548;
																											case 31:
																											case 115:
																												goto IL_055b;
																											case 57:
																											case 108:
																												goto IL_0569;
																											case 111:
																												goto IL_0574;
																											case 32:
																											case 80:
																												goto IL_057f;
																											case 49:
																												goto IL_059b;
																											case 28:
																												goto IL_05a9;
																											case 64:
																											case 114:
																												goto IL_05c2;
																											case 106:
																												goto IL_05d5;
																											case 137:
																												goto IL_05e3;
																											case 139:
																												goto IL_05f6;
																											case 56:
																											case 129:
																												goto IL_0604;
																											case 0:
																												goto IL_0612;
																											case 34:
																												goto IL_061d;
																											case 102:
																												goto IL_062b;
																											case 12:
																											case 67:
																												goto IL_0639;
																											case 126:
																												goto IL_065c;
																											case 47:
																												goto IL_066a;
																											case 22:
																												goto IL_0678;
																											case 27:
																											case 54:
																												goto IL_068b;
																											case 142:
																												goto IL_06ed;
																											case 135:
																												goto IL_0700;
																											case 117:
																												goto IL_070e;
																											case 25:
																											case 45:
																												goto IL_0725;
																											case 84:
																												goto IL_0765;
																											case 97:
																												goto IL_0779;
																											case 2:
																											case 61:
																												goto IL_078c;
																											case 33:
																												goto IL_07a0;
																											case 105:
																												goto IL_07f4;
																											case 14:
																												goto IL_080b;
																											case 1:
																											case 3:
																											case 5:
																											case 8:
																											case 10:
																											case 13:
																											case 38:
																											case 44:
																											case 59:
																											case 63:
																											case 65:
																											case 73:
																											case 74:
																											case 76:
																											case 77:
																											case 81:
																											case 83:
																											case 90:
																											case 91:
																											case 96:
																											case 112:
																											case 118:
																											case 127:
																											case 130:
																											case 131:
																											case 133:
																											case 138:
																												goto end_IL_0304;
																											case 7:
																											case 18:
																											case 21:
																											case 42:
																											case 53:
																											case 71:
																											case 78:
																											case 82:
																											case 92:
																											case 100:
																											case 104:
																											case 109:
																											case 116:
																											case 121:
																											case 123:
																											case 136:
																												goto end_IL_0263;
																											case 50:
																												goto end_IL_082e;
																											case 51:
																												goto end_IL_0841;
																											case 48:
																												goto end_IL_084b;
																											case 72:
																												goto end_IL_085f;
																											case 11:
																											case 16:
																												goto end_IL_0874;
																											case 86:
																												goto end_IL_0884;
																											case 101:
																												goto end_IL_0894;
																											case 15:
																												goto end_IL_08a4;
																											case 36:
																												goto end_IL_08b4;
																											case 37:
																												goto end_IL_08bf;
																											case 35:
																											case 70:
																												goto IL_08e3;
																											}
																											continue;
																											end_IL_0263:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_033f;
																						IL_04c0:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_033f:
																						if (3 < b)
																						{
																							goto IL_034a;
																						}
																						goto IL_0399;
																						IL_034a:
																						if (5 >= b)
																						{
																							goto IL_0358;
																						}
																						goto IL_04d8;
																						IL_0358:
																						if (5 <= b)
																						{
																							goto IL_0366;
																						}
																						goto IL_0444;
																						IL_0366:
																						array[num5] = 0;
																						goto IL_0374;
																						IL_0374:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03d0;
																						IL_03d0:
																						array2[num5] = null;
																						goto IL_03da;
																						IL_03da:
																						num5++;
																						goto IL_0465;
																						IL_0465:
																						ptr2 += 8;
																						break;
																						IL_0444:
																						if (4 < b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_0452;
																						IL_0452:
																						if (4 <= b)
																						{
																							break;
																						}
																						goto end_IL_0304;
																						IL_04d8:
																						if (6 < b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_04e6;
																						IL_04e6:
																						if (6 > b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_04f4;
																						IL_04f4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0534;
																						IL_0534:
																						array[num5 - 2] = 0;
																						goto IL_0548;
																						IL_0548:
																						num5--;
																						break;
																						IL_0399:
																						if (3 > b)
																						{
																							goto IL_03a7;
																						}
																						goto IL_04c0;
																						IL_03a7:
																						if (1 < b)
																						{
																							goto IL_03b2;
																						}
																						goto IL_03ea;
																						IL_03b2:
																						if (2 < b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_03c0;
																						IL_03c0:
																						if (2 > b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_03fa;
																						IL_03fa:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0423;
																						IL_0423:
																						ptr2 += 8;
																						goto IL_0431;
																						IL_0431:
																						num5--;
																						break;
																						IL_03ea:
																						if (1 > b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_0478;
																						IL_0478:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0491;
																						IL_0491:
																						array[num5] = 0;
																						goto IL_049f;
																						IL_049f:
																						num5++;
																						goto IL_04ad;
																						IL_04ad:
																						ptr2 += 8;
																						break;
																					}
																					break;
																				}
																				goto IL_055b;
																				IL_07a0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)RightToLeftArabicIsolatedStorageScope[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_07f4;
																				IL_055b:
																				if (11 < b)
																				{
																					goto IL_0569;
																				}
																				goto IL_05f6;
																				IL_0569:
																				if (13 >= b)
																				{
																					goto IL_0574;
																				}
																				goto IL_05d5;
																				IL_0574:
																				if (13 <= b)
																				{
																					goto IL_057f;
																				}
																				goto IL_059b;
																				IL_057f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_059b:
																				if (12 < b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_05a9;
																				IL_05a9:
																				if (12 > b)
																				{
																					num = 96;
																					goto end_IL_0304;
																				}
																				goto IL_05c2;
																				IL_07f4:
																				num5--;
																				num = 14;
																				goto IL_080b;
																				IL_05c2:
																				num5--;
																				break;
																				IL_05d5:
																				if (14 < b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_05e3;
																				IL_05e3:
																				if (14 <= b)
																				{
																				}
																				goto end_IL_0304;
																				IL_05f6:
																				if (11 > b)
																				{
																					goto IL_0604;
																				}
																				goto IL_078c;
																				IL_0604:
																				if (9 >= b)
																				{
																					goto IL_0612;
																				}
																				goto IL_0700;
																				IL_0612:
																				if (9 > b)
																				{
																					goto IL_061d;
																				}
																				goto IL_068b;
																				IL_061d:
																				if (8 < b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_062b;
																				IL_062b:
																				if (8 > b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_0639;
																				IL_0639:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_065c;
																				IL_065c:
																				array[num5] = 0;
																				goto IL_066a;
																				IL_066a:
																				num5++;
																				goto IL_0678;
																				IL_0678:
																				ptr2 += 8;
																				break;
																				IL_068b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06ed;
																				IL_06ed:
																				num5 -= 2;
																				break;
																				IL_0700:
																				if (10 < b)
																				{
																					goto end_IL_0304;
																				}
																				goto IL_070e;
																				IL_070e:
																				if (10 > b)
																				{
																					goto end_IL_0304;
																				}
																				num = 45;
																				goto IL_0725;
																				IL_080b:
																				ptr2 += 8;
																				break;
																				IL_0725:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0765;
																				IL_0765:
																				array[num5 - 2] = 0;
																				goto IL_0779;
																				IL_0779:
																				num5--;
																				break;
																				IL_078c:
																				array[num5 - 2] = 0;
																				goto IL_07a0;
																			}
																			goto end_IL_0314;
																			continue;
																			end_IL_0304:
																			break;
																			IL_0304:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0314:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 70;
													goto IL_08e3;
													IL_08e3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_082e:
													break;
												}
												continue;
												end_IL_0841:
												break;
											}
											continue;
											end_IL_084b:
											break;
										}
										continue;
										end_IL_085f:
										break;
									}
									continue;
									end_IL_0874:
									break;
								}
								continue;
								end_IL_0884:
								break;
							}
							continue;
							end_IL_0894:
							break;
						}
						continue;
						end_IL_08a4:
						break;
					}
					continue;
					end_IL_08b4:
					break;
				}
				continue;
				end_IL_08bf:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_5, int int_6)
	{
		int num = 102;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 2;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											array3[1] = int_6;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DeltaEntryPointFlags.NoDefineVersionResourceUnspecifiedTypeSize);
												num = 42;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_02de:
																byte b = *ptr2;
																while (true)
																{
																	IL_02ce:
																	ptr2++;
																	while (true)
																	{
																		IL_02be:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_029e:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_028e:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0281:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_026e:
																											if (2 <= b)
																											{
																												while (true)
																												{
																													IL_01fb:
																													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													while (true)
																													{
																														IL_01e2:
																														num5 -= 2;
																														num = 112;
																														while (num != 112)
																														{
																															if (num != 1093)
																															{
																																goto IL_02ce;
																															}
																															switch (num)
																															{
																															case 88:
																																goto IL_01e2;
																															case 36:
																															case 78:
																																goto IL_01fb;
																															case 25:
																																goto IL_026e;
																															case 84:
																																goto IL_0281;
																															case 74:
																																goto IL_028e;
																															case 15:
																																goto IL_029e;
																															case 6:
																																goto IL_02ae;
																															case 3:
																																goto IL_02be;
																															case 22:
																																goto IL_02ce;
																															case 38:
																															case 56:
																																goto IL_02de;
																															case 35:
																															case 70:
																																goto IL_02e9;
																															case 61:
																																goto IL_02f7;
																															case 41:
																															case 45:
																																goto IL_0302;
																															case 24:
																																goto IL_0342;
																															case 0:
																																goto IL_0356;
																															case 30:
																																goto IL_0377;
																															case 60:
																																goto IL_0385;
																															case 40:
																															case 81:
																																goto IL_0393;
																															case 48:
																																goto IL_03bc;
																															case 52:
																																goto IL_03ca;
																															case 62:
																															case 92:
																																goto IL_03dd;
																															case 73:
																																goto IL_03e8;
																															case 4:
																															case 87:
																																goto IL_03f3;
																															case 46:
																																goto IL_0406;
																															case 1:
																															case 65:
																																goto IL_0414;
																															case 66:
																																goto IL_0427;
																															case 28:
																															case 69:
																																goto IL_0432;
																															case 37:
																																goto IL_0440;
																															case 13:
																																goto IL_046d;
																															case 27:
																																goto IL_047b;
																															case 31:
																																goto IL_048e;
																															case 18:
																																goto IL_0499;
																															case 5:
																															case 83:
																																goto IL_04b5;
																															case 94:
																																goto IL_04ce;
																															case 63:
																															case 97:
																																goto IL_04dc;
																															case 33:
																															case 99:
																																goto IL_04f8;
																															case 104:
																																goto IL_0510;
																															case 8:
																															case 103:
																																goto IL_051b;
																															case 17:
																																goto IL_0529;
																															case 68:
																																goto IL_054c;
																															case 49:
																																goto IL_055f;
																															case 29:
																																goto IL_056d;
																															case 98:
																																goto IL_057d;
																															case 64:
																																goto IL_0588;
																															case 9:
																															case 16:
																															case 19:
																															case 20:
																															case 21:
																															case 26:
																															case 32:
																															case 44:
																															case 50:
																															case 55:
																															case 58:
																															case 59:
																															case 75:
																															case 80:
																															case 85:
																															case 89:
																															case 91:
																															case 95:
																															case 96:
																															case 100:
																																goto end_IL_02ae;
																															case 51:
																																goto IL_05b6;
																															case 76:
																																goto IL_05c4;
																															case 86:
																																goto IL_05d2;
																															case 7:
																															case 10:
																															case 11:
																															case 14:
																															case 39:
																															case 43:
																															case 53:
																															case 71:
																															case 72:
																															case 79:
																															case 82:
																															case 105:
																																goto end_IL_01cf;
																															case 42:
																																goto end_IL_05e0;
																															case 23:
																																goto end_IL_05f3;
																															case 93:
																																goto end_IL_05fd;
																															case 34:
																																goto end_IL_0611;
																															case 90:
																																goto end_IL_0626;
																															case 54:
																															case 77:
																																goto end_IL_063b;
																															case 57:
																																goto end_IL_064b;
																															case 2:
																																goto end_IL_065b;
																															case 47:
																																goto end_IL_066b;
																															case 101:
																																goto end_IL_067b;
																															case 102:
																																goto end_IL_0686;
																															case 12:
																															case 67:
																																goto IL_06a1;
																															}
																															continue;
																															end_IL_01cf:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_057d;
																											IL_0588:
																											if (1 <= b)
																											{
																											}
																											goto end_IL_02ae;
																											IL_057d:
																											if (1 < b)
																											{
																												goto end_IL_02ae;
																											}
																											goto IL_0588;
																										}
																										break;
																									}
																									goto IL_02e9;
																									IL_03bc:
																									ptr2 += 8;
																									goto IL_03ca;
																									IL_02e9:
																									if (3 >= b)
																									{
																										goto IL_02f7;
																									}
																									goto IL_0377;
																									IL_02f7:
																									if (3 > b)
																									{
																										num = 19;
																										goto end_IL_02ae;
																									}
																									goto IL_0302;
																									IL_0302:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0342;
																									IL_0342:
																									array[num5 - 2] = 0;
																									goto IL_0356;
																									IL_0356:
																									num5--;
																									break;
																									IL_03ca:
																									num5--;
																									break;
																									IL_0377:
																									if (4 < b)
																									{
																										goto end_IL_02ae;
																									}
																									goto IL_0385;
																									IL_0385:
																									if (4 > b)
																									{
																										goto end_IL_02ae;
																									}
																									goto IL_0393;
																									IL_0393:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03bc;
																								}
																								break;
																							}
																							goto IL_04f8;
																							IL_04f8:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																						}
																						break;
																					}
																					goto IL_03dd;
																					IL_054c:
																					array2[num5] = null;
																					num = 49;
																					goto IL_055f;
																					IL_03dd:
																					if (8 < b)
																					{
																						goto IL_03e8;
																					}
																					goto IL_0427;
																					IL_03e8:
																					if (9 < b)
																					{
																						goto IL_03f3;
																					}
																					goto IL_0406;
																					IL_03f3:
																					if (10 < b)
																					{
																						goto end_IL_02ae;
																					}
																					goto IL_04ce;
																					IL_04ce:
																					if (10 > b)
																					{
																						goto end_IL_02ae;
																					}
																					goto IL_04dc;
																					IL_04dc:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0406:
																					if (9 > b)
																					{
																						goto end_IL_02ae;
																					}
																					goto IL_0414;
																					IL_0414:
																					num5--;
																					break;
																					IL_0427:
																					if (8 <= b)
																					{
																						goto IL_0432;
																					}
																					goto IL_048e;
																					IL_0432:
																					array[num5] = 0;
																					goto IL_0440;
																					IL_0440:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)AssemblyFlagsIPrincipal[*(int*)(ptr2 + num3)])();
																					num = 13;
																					goto IL_046d;
																					IL_046d:
																					num5++;
																					goto IL_047b;
																					IL_047b:
																					ptr2 += 8;
																					break;
																					IL_048e:
																					if (6 >= b)
																					{
																						goto IL_0499;
																					}
																					goto IL_04b5;
																					IL_0499:
																					if (6 <= b)
																					{
																						break;
																					}
																					num = 44;
																					goto end_IL_02ae;
																					IL_055f:
																					num5++;
																					goto IL_056d;
																					IL_04b5:
																					if (7 < b)
																					{
																						goto end_IL_02ae;
																					}
																					num = 104;
																					goto IL_0510;
																					IL_056d:
																					ptr2 += 8;
																					break;
																					IL_0510:
																					if (7 > b)
																					{
																						goto end_IL_02ae;
																					}
																					goto IL_051b;
																					IL_051b:
																					array[num5] = 0;
																					goto IL_0529;
																					IL_0529:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_054c;
																				}
																				goto end_IL_02be;
																				continue;
																				end_IL_02ae:
																				break;
																				IL_02ae:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05b6;
																		IL_05d2:
																		ptr2 += 8;
																		break;
																		IL_05c4:
																		num5++;
																		goto IL_05d2;
																		IL_05b6:
																		array[num5] = 0;
																		goto IL_05c4;
																		continue;
																		end_IL_02be:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_06a1;
														IL_06a1:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_05e0:
														break;
													}
													continue;
													end_IL_05f3:
													break;
												}
												continue;
												end_IL_05fd:
												break;
											}
											continue;
											end_IL_0611:
											break;
										}
										continue;
										end_IL_0626:
										break;
									}
									continue;
									end_IL_063b:
									break;
								}
								continue;
								end_IL_064b:
								break;
							}
							continue;
							end_IL_065b:
							break;
						}
						continue;
						end_IL_066b:
						break;
					}
					continue;
					end_IL_067b:
					break;
				}
				continue;
				end_IL_0686:
				break;
			}
		}
	}

	private unsafe static int smethod_18()
	{
		int num = 121;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 20;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									num = 81;
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TryPopSave.GetConstructorTokenDXNNDS);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 21;
																while (true)
																{
																	IL_0302:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02e5:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02d5:
																						if (12 < b)
																						{
																							while (true)
																							{
																								IL_02c8:
																								if (14 < b)
																								{
																									while (15 >= b)
																									{
																										num = 65;
																										while (15 > b)
																										{
																											num = 153;
																											while (num != 153)
																											{
																												if (num != 1134)
																												{
																													goto IL_03dc;
																												}
																												switch (num)
																												{
																												case 65:
																													goto IL_02a2;
																												case 145:
																													goto IL_02b5;
																												case 135:
																													goto IL_02c8;
																												case 41:
																													goto IL_02d5;
																												case 110:
																													goto IL_02e5;
																												case 89:
																													goto IL_02f2;
																												case 21:
																													goto IL_0302;
																												case 108:
																													goto end_IL_0302;
																												case 22:
																												case 140:
																													goto end_IL_0312;
																												case 42:
																													goto IL_0336;
																												case 4:
																												case 13:
																													goto IL_0341;
																												case 58:
																													goto IL_035d;
																												case 69:
																													goto IL_036d;
																												case 61:
																												case 78:
																													goto IL_037b;
																												case 11:
																												case 101:
																													goto IL_03c0;
																												case 114:
																													goto IL_03dc;
																												case 7:
																													goto IL_03ea;
																												case 118:
																													goto IL_03f5;
																												case 63:
																												case 92:
																													goto IL_0400;
																												case 17:
																													goto IL_043f;
																												case 48:
																													goto IL_0452;
																												case 107:
																													goto IL_0460;
																												case 122:
																													goto IL_0473;
																												case 123:
																													goto IL_0486;
																												case 66:
																												case 113:
																													goto IL_0494;
																												case 127:
																													goto IL_04f6;
																												case 72:
																												case 130:
																													goto IL_0509;
																												case 16:
																												case 82:
																													goto IL_0517;
																												case 25:
																													goto IL_0525;
																												case 86:
																												case 125:
																													goto IL_0533;
																												case 71:
																													goto IL_0577;
																												case 112:
																													goto IL_0594;
																												case 1:
																													goto IL_05a7;
																												case 77:
																												case 88:
																													goto IL_05b5;
																												case 55:
																													goto IL_05c3;
																												case 14:
																													goto IL_05e6;
																												case 28:
																													goto IL_05f0;
																												case 57:
																													goto IL_05fe;
																												case 90:
																												case 132:
																													goto IL_061a;
																												case 134:
																													goto IL_0632;
																												case 26:
																												case 75:
																													goto IL_063d;
																												case 44:
																													goto IL_065b;
																												case 93:
																													goto IL_0669;
																												case 38:
																												case 109:
																													goto IL_0685;
																												case 85:
																													goto IL_0690;
																												case 131:
																													goto IL_06a9;
																												case 74:
																												case 83:
																													goto IL_06b7;
																												case 128:
																													goto IL_06e0;
																												case 115:
																													goto IL_06f9;
																												case 12:
																												case 97:
																													goto IL_0704;
																												case 29:
																													goto IL_0712;
																												case 49:
																												case 73:
																													goto IL_0720;
																												case 94:
																													goto IL_0739;
																												case 62:
																													goto IL_0747;
																												case 24:
																												case 37:
																													goto IL_075a;
																												case 54:
																													goto IL_079a;
																												case 126:
																													goto IL_07ae;
																												case 39:
																												case 136:
																													goto IL_07c1;
																												case 35:
																													goto IL_07cf;
																												case 142:
																													goto IL_07e2;
																												case 32:
																												case 64:
																													goto IL_07f0;
																												case 80:
																													goto IL_0819;
																												case 116:
																													goto IL_0827;
																												case 139:
																												case 143:
																													goto IL_083a;
																												case 104:
																													goto IL_0848;
																												case 5:
																													goto IL_0860;
																												case 2:
																													goto IL_086e;
																												case 144:
																													goto IL_087e;
																												case 31:
																													goto IL_0892;
																												case 146:
																													goto IL_08a2;
																												case 0:
																												case 3:
																												case 18:
																												case 27:
																												case 30:
																												case 33:
																												case 36:
																												case 43:
																												case 52:
																												case 56:
																												case 59:
																												case 76:
																												case 87:
																												case 91:
																												case 95:
																												case 96:
																												case 99:
																												case 100:
																												case 102:
																												case 106:
																												case 111:
																												case 117:
																												case 129:
																												case 133:
																												case 137:
																												case 138:
																													goto end_IL_028f;
																												case 6:
																												case 8:
																												case 10:
																												case 19:
																												case 23:
																												case 40:
																												case 45:
																												case 46:
																												case 50:
																												case 51:
																												case 53:
																												case 68:
																												case 70:
																												case 79:
																												case 98:
																												case 103:
																												case 105:
																												case 119:
																													goto end_IL_032b;
																												case 15:
																													goto end_IL_08c5;
																												case 67:
																													goto end_IL_08d8;
																												case 81:
																													goto end_IL_08e2;
																												case 60:
																													goto end_IL_08ed;
																												case 20:
																													goto end_IL_08fd;
																												case 141:
																													goto end_IL_0916;
																												case 34:
																													goto end_IL_0926;
																												case 47:
																												case 84:
																													goto end_IL_0931;
																												case 120:
																													goto end_IL_0941;
																												case 121:
																													goto end_IL_0951;
																												case 9:
																												case 124:
																													goto IL_0975;
																												}
																												continue;
																												end_IL_028f:
																												break;
																											}
																											break;
																											IL_02a2:;
																										}
																										break;
																										IL_02b5:;
																									}
																									break;
																								}
																								goto IL_0336;
																								IL_0494:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_04f6;
																								IL_0336:
																								if (14 <= b)
																								{
																									goto IL_0341;
																								}
																								goto IL_03c0;
																								IL_0341:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_032b;
																								IL_03c0:
																								if (13 < b)
																								{
																									break;
																								}
																								num = 123;
																								goto IL_0486;
																								IL_04f6:
																								num5 -= 2;
																								goto end_IL_032b;
																								IL_0486:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_0494;
																							}
																							break;
																						}
																						goto IL_036d;
																						IL_07cf:
																						if (9 <= b)
																						{
																							goto end_IL_032b;
																						}
																						break;
																						IL_036d:
																						if (12 <= b)
																						{
																							goto IL_037b;
																						}
																						goto IL_0509;
																						IL_037b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_087e;
																						IL_087e:
																						array[num5 - 2] = 0;
																						goto IL_0892;
																						IL_0892:
																						num5--;
																						goto end_IL_032b;
																						IL_0509:
																						if (10 < b)
																						{
																							goto IL_0517;
																						}
																						goto IL_05a7;
																						IL_0517:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_0525;
																						IL_0525:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_0533;
																						IL_0533:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0577;
																						IL_0577:
																						array[num5 - 2] = 0;
																						num = 112;
																						goto IL_0594;
																						IL_0594:
																						num5--;
																						goto end_IL_032b;
																						IL_05a7:
																						if (10 <= b)
																						{
																							goto IL_05b5;
																						}
																						goto IL_07c1;
																						IL_05b5:
																						array[num5] = 0;
																						goto IL_05c3;
																						IL_05c3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05e6;
																						IL_05e6:
																						array2[num5] = null;
																						goto IL_05f0;
																						IL_05f0:
																						num5++;
																						goto IL_05fe;
																						IL_05fe:
																						ptr2 += 8;
																						num = 98;
																						goto end_IL_032b;
																						IL_07c1:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_07cf;
																					}
																					break;
																				}
																				goto IL_035d;
																				IL_075a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_079a;
																				IL_035d:
																				if (8 > b)
																				{
																					goto IL_03dc;
																				}
																				goto IL_061a;
																				IL_061a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_032b;
																				IL_03dc:
																				if (4 < b)
																				{
																					goto IL_03ea;
																				}
																				goto IL_0632;
																				IL_03ea:
																				if (6 >= b)
																				{
																					goto IL_03f5;
																				}
																				goto IL_0473;
																				IL_03f5:
																				if (6 <= b)
																				{
																					goto IL_0400;
																				}
																				goto IL_0452;
																				IL_0400:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_043f;
																				IL_043f:
																				num5 -= 3;
																				goto end_IL_032b;
																				IL_0452:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0460;
																				IL_0460:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_083a;
																				IL_083a:
																				array[num5] = 5;
																				goto IL_0848;
																				IL_0848:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0860;
																				IL_0860:
																				num5++;
																				goto IL_086e;
																				IL_086e:
																				ptr2 += 8;
																				goto end_IL_032b;
																				IL_0473:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_07e2;
																				IL_07e2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_07f0;
																				IL_07f0:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0819;
																				IL_0819:
																				ptr2 += 8;
																				goto IL_0827;
																				IL_0827:
																				num5--;
																				goto end_IL_032b;
																				IL_0632:
																				if (4 <= b)
																				{
																					goto IL_063d;
																				}
																				num = 109;
																				goto IL_0685;
																				IL_063d:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_065b;
																				IL_065b:
																				ptr2 += 8;
																				goto IL_0669;
																				IL_0669:
																				num5--;
																				goto end_IL_032b;
																				IL_079a:
																				array[num5 - 2] = 0;
																				goto IL_07ae;
																				IL_0685:
																				if (2 < b)
																				{
																					goto IL_0690;
																				}
																				goto IL_06f9;
																				IL_0690:
																				if (3 < b)
																				{
																					num = 33;
																					break;
																				}
																				goto IL_06a9;
																				IL_07ae:
																				num5--;
																				goto end_IL_032b;
																				IL_06a9:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_06b7;
																				IL_06b7:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_06e0;
																				IL_06e0:
																				array[num5 - 1] = 5;
																				goto end_IL_032b;
																				IL_06f9:
																				if (2 > b)
																				{
																					goto IL_0704;
																				}
																				goto IL_075a;
																				IL_0704:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0712;
																				IL_0712:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0720;
																				IL_0720:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0739;
																				IL_0739:
																				array[num5] = 0;
																				goto IL_0747;
																				IL_0747:
																				num5++;
																				goto IL_08a2;
																				IL_08a2:
																				ptr2 += 8;
																				goto end_IL_032b;
																			}
																			break;
																			IL_02f2:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_032b;
																	continue;
																	end_IL_0302:
																	break;
																}
																continue;
																end_IL_0312:
																break;
															}
															continue;
															end_IL_032b:
															break;
														}
														continue;
													}
													num = 124;
													goto IL_0975;
													IL_0975:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08c5:
													break;
												}
												continue;
												end_IL_08d8:
												break;
											}
											continue;
											end_IL_08e2:
											break;
										}
										continue;
										end_IL_08ed:
										break;
									}
									continue;
									end_IL_08fd:
									break;
								}
								continue;
								end_IL_0916:
								break;
							}
							continue;
							end_IL_0926:
							break;
						}
						continue;
						end_IL_0931:
						break;
					}
					continue;
					end_IL_0941:
					break;
				}
				continue;
				end_IL_0951:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_5)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 20;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InitializedTYPEFLAGFAPPOBJECT.ContinuationTaskActivatedClientTypeEntry);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02c0:
														byte b = *ptr2;
														while (true)
														{
															IL_02a7:
															ptr2++;
															num = 73;
															while (true)
															{
																IL_0297:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0277:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0267:
																					if (6 <= b)
																					{
																						num = 75;
																						while (true)
																						{
																							IL_021c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 123;
																							while (true)
																							{
																								if (num != 123)
																								{
																									if (num != 1104)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 35:
																									case 75:
																										goto IL_021c;
																									case 21:
																										goto IL_0267;
																									case 37:
																										goto IL_0277;
																									case 41:
																										goto IL_0287;
																									case 73:
																										goto IL_0297;
																									case 46:
																										goto IL_02a7;
																									case 24:
																									case 71:
																										goto IL_02c0;
																									case 3:
																										goto IL_02cb;
																									case 47:
																										goto IL_02e1;
																									case 14:
																									case 67:
																										goto IL_02f1;
																									case 2:
																										goto IL_02ff;
																									case 9:
																									case 81:
																										goto IL_031b;
																									case 25:
																										goto IL_0326;
																									case 22:
																									case 61:
																										goto IL_0334;
																									case 57:
																										goto IL_034d;
																									case 53:
																										goto IL_035b;
																									case 77:
																									case 79:
																										goto IL_0377;
																									case 65:
																										goto IL_0385;
																									case 1:
																									case 15:
																										goto IL_0390;
																									case 31:
																										goto IL_03b9;
																									case 87:
																										goto IL_03da;
																									case 52:
																										goto IL_03e8;
																									case 13:
																									case 50:
																										goto IL_03f6;
																									case 58:
																										goto IL_0404;
																									case 56:
																										goto IL_0427;
																									case 62:
																										goto IL_0431;
																									case 78:
																										goto IL_043f;
																									case 94:
																										goto IL_0452;
																									case 45:
																									case 96:
																										goto IL_0465;
																									case 97:
																										goto IL_047d;
																									case 51:
																										goto IL_04a4;
																									case 66:
																										goto IL_04b7;
																									case 30:
																									case 59:
																										goto IL_04c2;
																									case 10:
																									case 43:
																										goto IL_04cd;
																									case 42:
																										goto IL_04db;
																									case 26:
																										goto IL_04ee;
																									case 98:
																									case 104:
																										goto IL_04fc;
																									case 82:
																										goto IL_0518;
																									case 48:
																									case 100:
																										goto IL_0526;
																									case 92:
																									case 103:
																										goto IL_0531;
																									case 101:
																										goto IL_053f;
																									case 18:
																									case 44:
																										goto IL_054d;
																									case 80:
																										goto IL_0579;
																									case 86:
																										goto IL_0587;
																									case 64:
																										goto IL_0595;
																									case 90:
																										goto IL_05a8;
																									case 29:
																									case 107:
																										goto IL_05b6;
																									case 74:
																										goto IL_05f6;
																									case 40:
																										goto IL_060a;
																									case 34:
																									case 115:
																										goto IL_061d;
																									case 70:
																										goto IL_067f;
																									case 0:
																									case 7:
																									case 8:
																									case 16:
																									case 17:
																									case 19:
																									case 23:
																									case 36:
																									case 38:
																									case 54:
																									case 55:
																									case 60:
																									case 83:
																									case 85:
																									case 88:
																									case 89:
																									case 91:
																									case 102:
																									case 109:
																									case 112:
																									case 113:
																									case 116:
																										goto end_IL_0287;
																									case 4:
																									case 5:
																									case 6:
																									case 11:
																									case 12:
																									case 27:
																									case 28:
																									case 49:
																									case 63:
																									case 99:
																									case 105:
																									case 106:
																									case 110:
																									case 114:
																										goto end_IL_0209;
																									case 68:
																										goto end_IL_06a2;
																									case 84:
																										goto end_IL_06b5;
																									case 93:
																										goto end_IL_06bf;
																									case 20:
																										goto end_IL_06ca;
																									case 95:
																									case 111:
																										goto end_IL_06df;
																									case 72:
																										goto end_IL_06ef;
																									case 69:
																									case 108:
																										goto end_IL_0708;
																									case 32:
																										goto end_IL_0718;
																									case 33:
																										goto end_IL_0728;
																									case 39:
																									case 76:
																										goto IL_074c;
																									}
																									continue;
																								}
																								array[num5 - 2] = 0;
																								goto IL_04a4;
																								IL_04a4:
																								num5--;
																								break;
																								continue;
																								end_IL_0209:
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_02cb;
																					IL_0385:
																					if (2 > b)
																					{
																						num = 85;
																						goto end_IL_0287;
																					}
																					goto IL_0390;
																					IL_0390:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03b9;
																					IL_02cb:
																					if (3 >= b)
																					{
																						goto IL_02e1;
																					}
																					num = 14;
																					goto IL_02f1;
																					IL_03b9:
																					ptr2 += 8;
																					goto IL_047d;
																					IL_02f1:
																					if (4 >= b)
																					{
																						goto IL_02ff;
																					}
																					goto IL_03da;
																					IL_02ff:
																					if (4 <= b)
																					{
																						break;
																					}
																					num = 91;
																					goto end_IL_0287;
																					IL_047d:
																					num5--;
																					break;
																					IL_03da:
																					if (5 < b)
																					{
																						goto end_IL_0287;
																					}
																					goto IL_03e8;
																					IL_03e8:
																					if (5 > b)
																					{
																						goto end_IL_0287;
																					}
																					goto IL_03f6;
																					IL_03f6:
																					array[num5] = 0;
																					goto IL_0404;
																					IL_0404:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0427;
																					IL_0427:
																					array2[num5] = null;
																					goto IL_0431;
																					IL_0431:
																					num5++;
																					goto IL_043f;
																					IL_043f:
																					ptr2 += 8;
																					break;
																					IL_02e1:
																					if (3 > b)
																					{
																						goto IL_031b;
																					}
																					goto IL_0465;
																					IL_031b:
																					if (1 >= b)
																					{
																						goto IL_0326;
																					}
																					num = 79;
																					goto IL_0377;
																					IL_0326:
																					if (1 > b)
																					{
																						goto end_IL_0287;
																					}
																					goto IL_0334;
																					IL_0334:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_034d;
																					IL_034d:
																					array[num5] = 0;
																					goto IL_035b;
																					IL_035b:
																					num5++;
																					goto IL_0452;
																					IL_0452:
																					ptr2 += 8;
																					break;
																					IL_0465:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_0377:
																					if (2 < b)
																					{
																						goto end_IL_0287;
																					}
																					goto IL_0385;
																				}
																				break;
																			}
																			goto IL_04b7;
																			IL_067f:
																			num5 -= 2;
																			break;
																			IL_04b7:
																			if (9 < b)
																			{
																				goto IL_04c2;
																			}
																			goto IL_0518;
																			IL_04c2:
																			if (10 < b)
																			{
																				goto IL_04cd;
																			}
																			goto IL_04ee;
																			IL_04cd:
																			if (11 < b)
																			{
																				goto end_IL_0287;
																			}
																			goto IL_04db;
																			IL_04db:
																			if (11 > b)
																			{
																			}
																			goto end_IL_0287;
																			IL_04ee:
																			if (10 > b)
																			{
																				goto end_IL_0287;
																			}
																			goto IL_04fc;
																			IL_04fc:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0518:
																			if (9 > b)
																			{
																				goto IL_0526;
																			}
																			goto IL_061d;
																			IL_0526:
																			if (7 < b)
																			{
																				goto IL_0531;
																			}
																			goto IL_05a8;
																			IL_0531:
																			if (8 < b)
																			{
																				goto end_IL_0287;
																			}
																			goto IL_053f;
																			IL_053f:
																			if (8 > b)
																			{
																				goto end_IL_0287;
																			}
																			goto IL_054d;
																			IL_054d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 80;
																			goto IL_0579;
																			IL_0579:
																			array[num5] = 0;
																			goto IL_0587;
																			IL_0587:
																			num5++;
																			goto IL_0595;
																			IL_0595:
																			ptr2 += 8;
																			break;
																			IL_05a8:
																			if (7 > b)
																			{
																				goto end_IL_0287;
																			}
																			goto IL_05b6;
																			IL_05b6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05f6;
																			IL_05f6:
																			array[num5 - 2] = 0;
																			goto IL_060a;
																			IL_060a:
																			num5--;
																			break;
																			IL_061d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_067f;
																		}
																		goto end_IL_0297;
																		continue;
																		end_IL_0287:
																		break;
																		IL_0287:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0297:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 39;
												goto IL_074c;
												IL_074c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06a2:
												break;
											}
											continue;
											end_IL_06b5:
											break;
										}
										continue;
										end_IL_06bf:
										break;
									}
									continue;
									end_IL_06ca:
									break;
								}
								continue;
								end_IL_06df:
								break;
							}
							continue;
							end_IL_06ef:
							break;
						}
						continue;
						end_IL_0708:
						break;
					}
					continue;
					end_IL_0718:
					break;
				}
				continue;
				end_IL_0728:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_5, int int_6)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectiondefaultPermissionSetIDLock.StoreBoundedStatic);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0269:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_023c:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_022c:
																								array[num5] = 0;
																								while (true)
																								{
																									IL_0207:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									while (true)
																									{
																										IL_01fb:
																										array2[num5] = null;
																										while (true)
																										{
																											IL_01e2:
																											num5++;
																											num = 112;
																											while (true)
																											{
																												if (num != 112)
																												{
																													if (num != 1093)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 0:
																														goto IL_01e2;
																													case 14:
																														goto IL_01fb;
																													case 60:
																														goto IL_0207;
																													case 28:
																													case 73:
																														goto IL_022c;
																													case 99:
																														goto IL_023c;
																													case 69:
																														goto end_IL_023c;
																													case 4:
																														goto end_IL_0249;
																													case 21:
																														goto IL_0269;
																													case 90:
																														goto end_IL_0269;
																													case 16:
																													case 86:
																														goto end_IL_0279;
																													case 20:
																													case 31:
																														goto IL_0294;
																													case 7:
																														goto IL_029f;
																													case 10:
																													case 33:
																														goto IL_02ad;
																													case 22:
																														goto end_IL_01cf;
																													case 39:
																														goto IL_0301;
																													case 48:
																														goto IL_0314;
																													case 62:
																														goto IL_0322;
																													case 52:
																													case 70:
																														goto IL_0335;
																													case 30:
																														goto IL_0340;
																													case 36:
																													case 51:
																														goto IL_034e;
																													case 58:
																														goto IL_0367;
																													case 67:
																														goto IL_037a;
																													case 38:
																													case 43:
																														goto IL_0385;
																													case 13:
																														goto IL_0398;
																													case 6:
																													case 27:
																														goto IL_03af;
																													case 72:
																														goto IL_03f4;
																													case 37:
																														goto IL_0402;
																													case 44:
																													case 76:
																														goto IL_0415;
																													case 54:
																														goto IL_043e;
																													case 49:
																														goto IL_044c;
																													case 83:
																														goto IL_045f;
																													case 85:
																														goto IL_046d;
																													case 42:
																													case 88:
																														goto IL_0489;
																													case 50:
																													case 89:
																														goto IL_049c;
																													case 94:
																														goto IL_04aa;
																													case 45:
																													case 65:
																														goto IL_04c1;
																													case 61:
																														goto IL_050a;
																													case 59:
																														goto IL_051e;
																													case 98:
																														goto IL_0531;
																													case 29:
																													case 32:
																														goto IL_0548;
																													case 103:
																														goto IL_0564;
																													case 3:
																													case 35:
																														goto IL_0572;
																													case 81:
																														goto IL_05b2;
																													case 57:
																														goto IL_05c6;
																													case 104:
																														goto IL_05d9;
																													case 80:
																														goto IL_05ed;
																													case 2:
																													case 5:
																													case 11:
																													case 12:
																													case 24:
																													case 26:
																													case 34:
																													case 40:
																													case 47:
																													case 53:
																													case 55:
																													case 63:
																													case 68:
																													case 78:
																													case 84:
																													case 87:
																													case 97:
																													case 101:
																														goto end_IL_0259;
																													case 102:
																														goto IL_0630;
																													case 64:
																														goto IL_063e;
																													case 74:
																														goto IL_064c;
																													case 1:
																													case 15:
																													case 17:
																													case 18:
																													case 25:
																													case 41:
																													case 46:
																													case 75:
																													case 77:
																													case 82:
																													case 105:
																														goto end_IL_0289;
																													case 23:
																														goto end_IL_065a;
																													case 93:
																														goto end_IL_066d;
																													case 9:
																														goto end_IL_0677;
																													case 71:
																														goto end_IL_0682;
																													case 100:
																														goto end_IL_0697;
																													case 8:
																													case 56:
																														goto end_IL_06ac;
																													case 19:
																														goto end_IL_06bc;
																													case 79:
																													case 92:
																														goto end_IL_06cc;
																													case 95:
																														goto end_IL_06dc;
																													case 96:
																														goto end_IL_06ec;
																													case 66:
																													case 91:
																														goto IL_0707;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto end_IL_0289;
																												continue;
																												end_IL_01cf:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02ed;
																						}
																						goto IL_0294;
																						IL_05c6:
																						num5--;
																						goto end_IL_0289;
																						IL_0294:
																						if (2 >= b)
																						{
																							goto IL_029f;
																						}
																						goto IL_0314;
																						IL_029f:
																						if (2 <= b)
																						{
																							goto IL_02ad;
																						}
																						goto IL_03f4;
																						IL_02ad:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02ed;
																						IL_02ed:
																						array[num5 - 2] = 0;
																						goto IL_0301;
																						IL_0301:
																						num5--;
																						goto end_IL_0289;
																						IL_03f4:
																						if (1 < b)
																						{
																							goto end_IL_0259;
																						}
																						goto IL_0402;
																						IL_0402:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0259;
																						IL_0314:
																						if (3 >= b)
																						{
																							goto IL_0322;
																						}
																						goto IL_0489;
																						IL_0322:
																						if (3 > b)
																						{
																							goto end_IL_0259;
																						}
																						goto IL_0415;
																						IL_0415:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_043e;
																						IL_043e:
																						ptr2 += 8;
																						goto IL_044c;
																						IL_044c:
																						num5--;
																						goto end_IL_0289;
																						IL_0489:
																						if (4 < b)
																						{
																							goto end_IL_0259;
																						}
																						goto IL_0564;
																						IL_0564:
																						if (4 > b)
																						{
																							goto end_IL_0259;
																						}
																						goto IL_0572;
																						IL_0572:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05b2;
																						IL_05b2:
																						array[num5 - 2] = 0;
																						goto IL_05c6;
																						continue;
																						end_IL_023c:
																						break;
																					}
																					continue;
																				}
																				goto IL_0335;
																				IL_05ed:
																				num5--;
																				goto end_IL_0289;
																				IL_0335:
																				if (7 >= b)
																				{
																					goto IL_0340;
																				}
																				goto IL_037a;
																				IL_0340:
																				if (7 <= b)
																				{
																					goto IL_034e;
																				}
																				goto IL_049c;
																				IL_034e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0367;
																				IL_0367:
																				array[num5] = 0;
																				goto IL_045f;
																				IL_045f:
																				num5++;
																				goto IL_046d;
																				IL_046d:
																				ptr2 += 8;
																				num = 77;
																				goto end_IL_0289;
																				IL_049c:
																				if (6 < b)
																				{
																					goto end_IL_0259;
																				}
																				goto IL_04aa;
																				IL_04aa:
																				if (6 > b)
																				{
																					goto end_IL_0259;
																				}
																				num = 45;
																				goto IL_04c1;
																				IL_03af:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d9;
																				IL_04c1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 61;
																				goto IL_050a;
																				IL_050a:
																				array[num5 - 2] = 0;
																				goto IL_051e;
																				IL_051e:
																				num5--;
																				goto end_IL_0289;
																				IL_037a:
																				if (8 < b)
																				{
																					goto IL_0385;
																				}
																				goto IL_0398;
																				IL_0385:
																				if (9 < b)
																				{
																					goto end_IL_0259;
																				}
																				goto IL_0531;
																				IL_0531:
																				if (9 > b)
																				{
																					goto end_IL_0259;
																				}
																				num = 32;
																				goto IL_0548;
																				IL_05d9:
																				array[num5 - 2] = 0;
																				goto IL_05ed;
																				IL_0548:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0289;
																				IL_0398:
																				if (8 > b)
																				{
																					goto end_IL_0259;
																				}
																				num = 6;
																				goto IL_03af;
																				continue;
																				end_IL_0249:
																				break;
																			}
																			continue;
																			end_IL_0259:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0630;
																	IL_064c:
																	ptr2 += 8;
																	goto end_IL_0289;
																	IL_063e:
																	num5++;
																	goto IL_064c;
																	IL_0630:
																	array[num5] = 0;
																	goto IL_063e;
																	continue;
																	end_IL_0269:
																	break;
																}
																continue;
																end_IL_0279:
																break;
															}
															continue;
															end_IL_0289:
															break;
														}
														continue;
													}
													goto IL_0707;
													IL_0707:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065a:
													break;
												}
												continue;
												end_IL_066d:
												break;
											}
											continue;
											end_IL_0677:
											break;
										}
										continue;
										end_IL_0682:
										break;
									}
									continue;
									end_IL_0697:
									break;
								}
								continue;
								end_IL_06ac:
								break;
							}
							continue;
							end_IL_06bc:
							break;
						}
						continue;
						end_IL_06cc:
						break;
					}
					continue;
					end_IL_06dc:
					break;
				}
				continue;
				end_IL_06ec:
				break;
			}
		}
	}

	static Class100()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num == 13 || num != 994)
						{
							return;
						}
						switch (num)
						{
						case 3:
						case 4:
						case 6:
							goto end_IL_003d;
						case 1:
							goto end_IL_004a;
						case 2:
							goto end_IL_005c;
						case 0:
							return;
						case 5:
							return;
						}
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_005c:
				break;
			}
		}
	}
}
