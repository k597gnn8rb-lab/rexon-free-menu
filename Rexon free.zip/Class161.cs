using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Connect EU", "Room", "Connect to EU servers.", true, 4, ModType.const_1, false)]
internal class Class161 : MonoBehaviour
{
	private static int int_0;

	private static double double_0;

	private static float float_0;

	private static int int_1;

	private static bool bool_0;

	private static float float_1;

	private static IntPtr[] AceTypeResourceManagerMediator;

	private static IntPtr[] GenericParEntryAssembly;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001e, IL_03ef, IL_0402, IL_044c, IL_0462, IL_0472, IL_0482, IL_0492, IL_04a2, IL_04af, IL_04bf, IL_04cf, IL_04df, IL_04ef, IL_04ff, IL_050a, IL_0518, IL_0566, IL_0571, IL_057c, IL_058f, IL_05d8, IL_05ee, IL_05fc, IL_060c, IL_0629, IL_063c, IL_064f, IL_066b, IL_06ab, IL_06bf, IL_06d2, IL_06e0, IL_06ee, IL_06fc, IL_070a, IL_074a, IL_075e, IL_0771, IL_077f, IL_078d, IL_07b0, IL_07ba, IL_07c8, IL_07db, IL_07e9, IL_07f2, IL_07fd, IL_0810, IL_081e, IL_082c, IL_086c, IL_0880, IL_0893, IL_08bc, IL_08ca, IL_08e6, IL_08f9, IL_0904, IL_0966, IL_0979, IL_0987, IL_0995, IL_09a0, IL_09de, IL_09f1, IL_09fa, IL_0a08, IL_0a16, IL_0a1f, IL_0a2d, IL_0a45, IL_0a63, IL_0a87, IL_0a9f, IL_0ab2, IL_0ac0, IL_0ace, IL_0adc, IL_0af4, IL_0b02, IL_0b15, IL_0b20, IL_0b29, IL_0b5b, IL_0b74, IL_0b82, IL_0b90, IL_0bad, IL_0bfc, IL_0c06, IL_0c33, IL_0c47, IL_0c55, IL_0c68, IL_0c76, IL_0c84, IL_0ca2, IL_0cb0, IL_0cc3, IL_0cd1, IL_0cdc, IL_0cea, IL_0cf8, IL_0d14, IL_0d1f, IL_0d2d, IL_0d3b, IL_0d53, IL_0d61, IL_0d6f, IL_0d82, IL_0dab, IL_0db9, IL_0dcc, IL_0dda, IL_0de5, IL_0df3, IL_0e01, IL_0e16, IL_0e29, IL_0e37, IL_0e4b, IL_0e83, IL_0e96, IL_0eaa, IL_0ee8, IL_0ef8, IL_0f11, IL_0f1f, IL_0f2d, IL_0f44, IL_0f57, IL_0f6a, IL_0f75, IL_0f85, IL_0f9e, IL_0fae, IL_0fbe, IL_0fce, IL_0fde, IL_0fee, IL_0ffe are reachable both inside and outside the pinned region starting at IL_1013. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef73 = default(int);
			ref int reference = ref __rxRef73;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0ffe:
					num2 = 1;
					while (true)
					{
						IL_0fee:
						num3 = num2 * 4;
						while (true)
						{
							IL_0fde:
							array2 = new byte[4];
							while (true)
							{
								IL_0fce:
								array3 = new object[4];
								while (true)
								{
									IL_0fbe:
									array4 = new int[4];
									while (true)
									{
										IL_0fae:
										array5 = new int[6];
										while (true)
										{
											IL_0f9e:
											array6 = new long[4];
											while (true)
											{
												IL_0f85:
												array7 = new object[4];
												num = 181;
												while (true)
												{
													IL_0f75:
													array7[0] = this;
													while (true)
													{
														IL_0f6a:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMaximumAgeUnitConcurrentStackFastPushFailed.FromMillisecondsRegisterForFullGCNotification);
														while (true)
														{
															IL_0f57:
															ptr2 = ptr;
															num = 112;
															while (true)
															{
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_04ff:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_04ef:
																		ptr2++;
																		while (true)
																		{
																			IL_04df:
																			if (b >= 1)
																			{
																				while (b <= 24)
																				{
																					while (true)
																					{
																						IL_04bf:
																						if (12 >= b)
																						{
																							while (12 > b)
																							{
																								while (true)
																								{
																									IL_04a2:
																									if (6 < b)
																									{
																										while (true)
																										{
																											IL_0492:
																											if (9 < b)
																											{
																												while (true)
																												{
																													IL_0482:
																													if (10 < b)
																													{
																														while (11 >= b)
																														{
																															while (11 <= b)
																															{
																																while (true)
																																{
																																	IL_044c:
																																	array2[num5 - 1] = 0;
																																	while (true)
																																	{
																																		IL_0402:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																																		num = 248;
																																		while (true)
																																		{
																																			if (num != 248)
																																			{
																																				if (num != 1229)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 8:
																																					break;
																																				default:
																																					continue;
																																				case 78:
																																					goto IL_0402;
																																				case 190:
																																				case 195:
																																					goto IL_044c;
																																				case 131:
																																					goto IL_0462;
																																				case 16:
																																				case 168:
																																					goto IL_0472;
																																				case 36:
																																					goto IL_0482;
																																				case 34:
																																					goto IL_0492;
																																				case 43:
																																				case 169:
																																					goto IL_04a2;
																																				case 63:
																																					goto IL_04af;
																																				case 171:
																																					goto IL_04bf;
																																				case 146:
																																					goto IL_04cf;
																																				case 105:
																																					goto IL_04df;
																																				case 25:
																																					goto IL_04ef;
																																				case 81:
																																				case 133:
																																					goto IL_04ff;
																																				case 44:
																																					goto IL_050a;
																																				case 56:
																																				case 97:
																																					goto IL_0518;
																																				case 179:
																																					goto IL_0566;
																																				case 125:
																																				case 177:
																																					goto IL_0571;
																																				case 64:
																																					goto IL_057c;
																																				case 94:
																																				case 151:
																																					goto IL_058f;
																																				case 21:
																																					goto IL_05d8;
																																				case 69:
																																				case 184:
																																					goto IL_05ee;
																																				case 127:
																																					goto IL_05fc;
																																				case 187:
																																					goto IL_060c;
																																				case 6:
																																					goto IL_0629;
																																				case 59:
																																				case 198:
																																					goto IL_063c;
																																				case 221:
																																					goto IL_064f;
																																				case 66:
																																				case 232:
																																					goto IL_066b;
																																				case 114:
																																					goto IL_06ab;
																																				case 175:
																																					goto IL_06bf;
																																				case 30:
																																				case 233:
																																					goto IL_06d2;
																																				case 9:
																																				case 231:
																																					goto IL_06e0;
																																				case 104:
																																				case 126:
																																					goto IL_06ee;
																																				case 71:
																																					goto IL_06fc;
																																				case 147:
																																				case 229:
																																					goto IL_070a;
																																				case 199:
																																					goto IL_074a;
																																				case 183:
																																					goto IL_075e;
																																				case 109:
																																					goto IL_0771;
																																				case 27:
																																				case 80:
																																					goto IL_077f;
																																				case 4:
																																					goto IL_078d;
																																				case 58:
																																					goto IL_07b0;
																																				case 17:
																																					goto IL_07ba;
																																				case 128:
																																					goto IL_07c8;
																																				case 79:
																																					goto IL_07db;
																																				case 1:
																																				case 216:
																																					goto IL_07f2;
																																				case 75:
																																					goto IL_07fd;
																																				case 156:
																																					goto IL_0810;
																																				case 225:
																																					goto IL_081e;
																																				case 41:
																																				case 165:
																																					goto IL_082c;
																																				case 140:
																																					goto IL_086c;
																																				case 29:
																																					goto IL_0880;
																																				case 51:
																																				case 144:
																																					goto IL_0893;
																																				case 230:
																																					goto IL_08bc;
																																				case 213:
																																					goto IL_08ca;
																																				case 137:
																																					goto IL_08f9;
																																				case 61:
																																				case 93:
																																					goto IL_0904;
																																				case 84:
																																					goto IL_0966;
																																				case 124:
																																				case 193:
																																					goto IL_0987;
																																				case 220:
																																					goto end_IL_03ef;
																																				case 18:
																																				case 98:
																																					goto IL_09a0;
																																				case 196:
																																					goto IL_09de;
																																				case 111:
																																				case 159:
																																					goto IL_09fa;
																																				case 139:
																																				case 157:
																																					goto IL_0a08;
																																				case 136:
																																					goto IL_0a1f;
																																				case 180:
																																				case 217:
																																					goto IL_0a2d;
																																				case 67:
																																					goto IL_0a45;
																																				case 145:
																																					goto IL_0a63;
																																				case 237:
																																					goto IL_0a87;
																																				case 236:
																																					goto IL_0a9f;
																																				case 176:
																																					goto IL_0ab2;
																																				case 206:
																																					goto IL_0ac0;
																																				case 72:
																																				case 219:
																																					goto IL_0ace;
																																				case 0:
																																					goto IL_0adc;
																																				case 135:
																																					goto IL_0af4;
																																				case 222:
																																					goto IL_0b02;
																																				case 107:
																																					goto IL_0b15;
																																				case 3:
																																				case 99:
																																					goto IL_0b29;
																																				case 214:
																																					goto IL_0b5b;
																																				case 15:
																																					goto IL_0b74;
																																				case 26:
																																					goto IL_0b82;
																																				case 160:
																																				case 167:
																																					goto IL_0b90;
																																				case 210:
																																					goto IL_0c47;
																																				case 166:
																																					goto IL_0c55;
																																				case 162:
																																					goto IL_0c68;
																																				case 134:
																																					goto IL_0c76;
																																				case 12:
																																				case 234:
																																					goto IL_0c84;
																																				case 142:
																																					goto IL_0ca2;
																																				case 24:
																																					goto IL_0cb0;
																																				case 224:
																																					goto IL_0cc3;
																																				case 95:
																																				case 121:
																																					goto IL_0cd1;
																																				case 182:
																																				case 235:
																																					goto IL_0cdc;
																																				case 14:
																																					goto IL_0cea;
																																				case 49:
																																				case 174:
																																					goto IL_0cf8;
																																				case 143:
																																					goto IL_0d14;
																																				case 47:
																																				case 60:
																																					goto IL_0d1f;
																																				case 209:
																																					goto IL_0d2d;
																																				case 194:
																																				case 201:
																																					goto IL_0d3b;
																																				case 155:
																																					goto IL_0d53;
																																				case 52:
																																					goto IL_0d61;
																																				case 37:
																																					goto IL_0d6f;
																																				case 48:
																																				case 70:
																																					goto IL_0d82;
																																				case 91:
																																					goto IL_0dab;
																																				case 32:
																																					goto IL_0db9;
																																				case 204:
																																					goto IL_0dcc;
																																				case 53:
																																				case 161:
																																					goto IL_0dda;
																																				case 54:
																																				case 82:
																																					goto IL_0de5;
																																				case 100:
																																					goto IL_0df3;
																																				case 83:
																																				case 163:
																																					goto IL_0e01;
																																				case 68:
																																					goto IL_0e16;
																																				case 186:
																																					goto IL_0e29;
																																				case 158:
																																				case 189:
																																					goto IL_0e37;
																																				case 152:
																																					goto IL_0e4b;
																																				case 218:
																																					goto IL_0e83;
																																				case 90:
																																				case 108:
																																					goto IL_0e96;
																																				case 62:
																																					goto IL_0eaa;
																																				case 76:
																																					goto IL_0ee8;
																																				case 10:
																																				case 11:
																																				case 19:
																																				case 20:
																																				case 22:
																																				case 28:
																																				case 31:
																																				case 33:
																																				case 45:
																																				case 46:
																																				case 50:
																																				case 57:
																																				case 77:
																																				case 85:
																																				case 87:
																																				case 89:
																																				case 92:
																																				case 101:
																																				case 102:
																																				case 115:
																																				case 117:
																																				case 118:
																																				case 119:
																																				case 122:
																																				case 130:
																																				case 138:
																																				case 149:
																																				case 150:
																																				case 154:
																																				case 170:
																																				case 173:
																																				case 185:
																																				case 188:
																																				case 200:
																																				case 205:
																																				case 211:
																																				case 212:
																																				case 215:
																																				case 223:
																																				case 226:
																																				case 228:
																																				case 238:
																																				case 241:
																																					goto end_IL_0462;
																																				case 103:
																																					goto IL_0f11;
																																				case 23:
																																					goto IL_0f1f;
																																				case 2:
																																					goto IL_0f2d;
																																				case 13:
																																				case 39:
																																				case 55:
																																				case 73:
																																				case 74:
																																				case 86:
																																				case 88:
																																				case 96:
																																				case 110:
																																				case 112:
																																				case 113:
																																				case 116:
																																				case 120:
																																				case 123:
																																				case 129:
																																				case 132:
																																				case 148:
																																				case 164:
																																				case 178:
																																				case 191:
																																				case 202:
																																				case 203:
																																				case 207:
																																				case 208:
																																				case 227:
																																				case 239:
																																				case 240:
																																					goto end_IL_04af;
																																				case 65:
																																					goto IL_0f57;
																																				case 38:
																																					goto IL_0f6a;
																																				case 181:
																																					goto IL_0f75;
																																				case 197:
																																					goto IL_0f85;
																																				case 172:
																																					goto IL_0f9e;
																																				case 141:
																																					goto IL_0fae;
																																				case 35:
																																					goto IL_0fbe;
																																				case 42:
																																					goto IL_0fce;
																																				case 5:
																																				case 40:
																																					goto IL_0fde;
																																				case 153:
																																					goto IL_0fee;
																																				case 7:
																																					goto IL_0ffe;
																																				case 106:
																																				case 192:
																																					return;
																																				}
																																				goto end_IL_0f44;
																																			}
																																			ptr2 += 8;
																																			goto end_IL_04af;
																																			continue;
																																			end_IL_03ef:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0995;
																																continue;
																																end_IL_0462:
																																break;
																																IL_0462:;
																															}
																															break;
																															IL_0472:;
																														}
																														break;
																													}
																													goto IL_08f9;
																													IL_0966:
																													num5 -= 2;
																													goto end_IL_04af;
																													IL_08f9:
																													if (10 > b)
																													{
																														num = 45;
																														break;
																													}
																													goto IL_0904;
																													IL_0904:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0966;
																												}
																												break;
																											}
																											goto IL_0566;
																											IL_064f:
																											num5--;
																											num = 132;
																											goto end_IL_04af;
																											IL_0566:
																											if (9 > b)
																											{
																												goto IL_0571;
																											}
																											goto IL_058f;
																											IL_0571:
																											if (7 >= b)
																											{
																												goto IL_057c;
																											}
																											goto IL_05ee;
																											IL_057c:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_066b;
																											IL_066b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_06ab;
																											IL_06ab:
																											array2[num5 - 2] = 0;
																											goto IL_06bf;
																											IL_06bf:
																											num5--;
																											goto end_IL_04af;
																											IL_05ee:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_05fc;
																											IL_05fc:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_063c;
																											IL_063c:
																											num5--;
																											goto end_IL_04af;
																											IL_058f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											num = 21;
																											goto IL_05d8;
																											IL_05d8:
																											array2[num5 - 2] = 0;
																											goto IL_064f;
																										}
																										break;
																									}
																									goto IL_050a;
																									IL_08bc:
																									ptr2 += 8;
																									goto IL_08ca;
																									IL_050a:
																									if (6 <= b)
																									{
																										goto IL_0518;
																									}
																									goto IL_06d2;
																									IL_0518:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									num = 187;
																									goto IL_060c;
																									IL_060c:
																									array2[num5 - 2] = 0;
																									num = 6;
																									goto IL_0629;
																									IL_0629:
																									num5--;
																									goto end_IL_04af;
																									IL_06d2:
																									if (3 < b)
																									{
																										goto IL_06e0;
																									}
																									goto IL_07db;
																									IL_06e0:
																									if (4 < b)
																									{
																										goto IL_06ee;
																									}
																									goto IL_0771;
																									IL_06ee:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_06fc;
																									IL_06fc:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_070a;
																									IL_070a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_074a;
																									IL_074a:
																									array2[num5 - 2] = 0;
																									goto IL_075e;
																									IL_075e:
																									num5--;
																									goto end_IL_04af;
																									IL_0771:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_077f;
																									IL_077f:
																									array2[num5] = 0;
																									goto IL_078d;
																									IL_078d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																									goto IL_07b0;
																									IL_07b0:
																									array3[num5] = null;
																									goto IL_07ba;
																									IL_07ba:
																									num5++;
																									goto IL_07c8;
																									IL_07c8:
																									ptr2 += 8;
																									goto end_IL_04af;
																									IL_07db:
																									if (3 > b)
																									{
																										num = 216;
																										goto IL_07f2;
																									}
																									goto IL_0893;
																									IL_08ca:
																									num5--;
																									num = 13;
																									goto end_IL_04af;
																									IL_07f2:
																									if (1 >= b)
																									{
																										goto IL_07fd;
																									}
																									goto IL_0810;
																									IL_07fd:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_0810:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_081e;
																									IL_081e:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_082c;
																									IL_082c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_086c;
																									IL_086c:
																									array2[num5 - 2] = 0;
																									goto IL_0880;
																									IL_0880:
																									num5--;
																									goto end_IL_04af;
																									IL_0893:
																									reference = ref array5[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_08bc;
																								}
																								goto end_IL_04cf;
																								continue;
																								end_IL_04af:
																								break;
																								IL_04af:;
																							}
																							break;
																						}
																						goto IL_0987;
																						IL_0e29:
																						if (19 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0e37;
																						IL_0987:
																						if (18 >= b)
																						{
																							goto IL_0995;
																						}
																						goto IL_0cc3;
																						IL_0995:
																						if (18 <= b)
																						{
																							goto IL_09a0;
																						}
																						num = 111;
																						goto IL_09fa;
																						IL_09a0:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_09de;
																						IL_09de:
																						num5 -= 3;
																						break;
																						IL_0e37:
																						array2[num5 - 1] = 5;
																						goto IL_0e4b;
																						IL_09fa:
																						if (15 < b)
																						{
																							goto IL_0a08;
																						}
																						goto IL_0b15;
																						IL_0a08:
																						if (16 >= b)
																						{
																							num = 136;
																							goto IL_0a1f;
																						}
																						goto IL_0ab2;
																						IL_0e4b:
																						array3[num5 - 1] = ((delegate*<string[], string>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_0e83;
																						IL_0a1f:
																						if (16 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0a2d;
																						IL_0a2d:
																						array2[num5] = array2[num5 - 1];
																						goto IL_0a45;
																						IL_0a45:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_0a63;
																						IL_0a63:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0a87;
																						IL_0a87:
																						array3[num5] = array3[num5 - 1];
																						goto IL_0a9f;
																						IL_0a9f:
																						num5++;
																						break;
																						IL_0ab2:
																						if (17 < b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0ac0;
																						IL_0ac0:
																						if (17 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0ace;
																						IL_0ace:
																						array2[num5] = 5;
																						goto IL_0adc;
																						IL_0adc:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0af4;
																						IL_0af4:
																						num5++;
																						goto IL_0b02;
																						IL_0b02:
																						ptr2 += 8;
																						break;
																						IL_0b15:
																						if (15 <= b)
																						{
																							num = 99;
																							goto IL_0b29;
																						}
																						goto IL_0b74;
																						IL_0e83:
																						ptr2 += 8;
																						break;
																						IL_0b29:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						num = 214;
																						goto IL_0b5b;
																						IL_0b5b:
																						array2[num5 - 1] = 5;
																						break;
																						IL_0b74:
																						if (13 >= b)
																						{
																							goto IL_0b82;
																						}
																						goto IL_0c68;
																						IL_0b82:
																						if (13 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0b90;
																						IL_0b90:
																						array8 = array3;
																						num6 = num5;
																						if (array == null)
																						{
																							goto IL_0b9f;
																						}
																						num7 = ptr2;
																						byte b2 = *num7;
																						ptr2 = num7 + 4;
																						int num8 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num8;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0c47;
																						IL_0e96:
																						array2[num5 - 1] = 0;
																						goto IL_0eaa;
																						IL_0eaa:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (((delegate*<string, bool>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]) ? 1 : 0);
																						goto IL_0ee8;
																						IL_0ee8:
																						ptr2 += 8;
																						break;
																						IL_0c47:
																						array2[num5] = 5;
																						goto IL_0c55;
																						IL_0c55:
																						num5++;
																						break;
																						IL_0c68:
																						if (14 < b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0c76;
																						IL_0c76:
																						if (14 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0c84;
																						IL_0c84:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0ca2;
																						IL_0ca2:
																						ptr2 += 8;
																						goto IL_0cb0;
																						IL_0cb0:
																						num5--;
																						break;
																						IL_0cc3:
																						if (21 < b)
																						{
																							goto IL_0cd1;
																						}
																						goto IL_0dcc;
																						IL_0cd1:
																						if (23 < b)
																						{
																							goto IL_0cdc;
																						}
																						goto IL_0d14;
																						IL_0cdc:
																						if (24 < b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0cea;
																						IL_0cea:
																						if (24 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0cf8;
																						IL_0cf8:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						break;
																						IL_0d14:
																						if (23 > b)
																						{
																							goto IL_0d1f;
																						}
																						goto IL_0d82;
																						IL_0d1f:
																						if (22 < b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0d2d;
																						IL_0d2d:
																						if (22 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0d3b;
																						IL_0d3b:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0d53;
																						IL_0d53:
																						array2[num5] = 5;
																						goto IL_0d61;
																						IL_0d61:
																						num5++;
																						goto IL_0d6f;
																						IL_0d6f:
																						ptr2 += 8;
																						break;
																						IL_0d82:
																						((delegate*<UnityEngine.Object, void>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((Class161)array3[num5 - 1]);
																						goto IL_0dab;
																						IL_0dab:
																						num5--;
																						goto IL_0db9;
																						IL_0db9:
																						ptr2 += 8;
																						break;
																						IL_0dcc:
																						if (21 > b)
																						{
																							goto IL_0dda;
																						}
																						goto IL_0e96;
																						IL_0dda:
																						if (19 < b)
																						{
																							goto IL_0de5;
																						}
																						goto IL_0e29;
																						IL_0de5:
																						if (20 < b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0df3;
																						IL_0df3:
																						if (20 > b)
																						{
																							goto end_IL_04cf;
																						}
																						goto IL_0e01;
																						IL_0e01:
																						((delegate*<void>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])();
																						goto IL_0e16;
																						IL_0e16:
																						ptr2 += 8;
																						break;
																					}
																					goto end_IL_04df;
																					continue;
																					end_IL_04cf:
																					break;
																					IL_04cf:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0f11;
																			IL_0f2d:
																			ptr2 += 8;
																			num = 202;
																			break;
																			IL_0f1f:
																			num5++;
																			goto IL_0f2d;
																			IL_0f11:
																			array2[num5] = 0;
																			goto IL_0f1f;
																			continue;
																			end_IL_04df:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_0f44:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0b9f:
			while (true)
			{
				IL_0b9f_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0c47_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0c55_2:
							num5++;
							while (true)
							{
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									IL_04ff_2:
									byte b = *ptr2;
									while (true)
									{
										IL_04ef_2:
										ptr2++;
										while (true)
										{
											IL_04df_2:
											if (b >= 1)
											{
												while (b <= 24)
												{
													while (true)
													{
														IL_04bf_2:
														if (12 >= b)
														{
															while (12 > b)
															{
																while (true)
																{
																	IL_04a2_2:
																	if (6 < b)
																	{
																		while (true)
																		{
																			IL_0492_2:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_0482_2:
																					if (10 < b)
																					{
																						while (11 >= b)
																						{
																							while (11 <= b)
																							{
																								while (true)
																								{
																									IL_044c_2:
																									array2[num5 - 1] = 0;
																									while (true)
																									{
																										IL_0402_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																										num = 248;
																										while (true)
																										{
																											if (num != 248)
																											{
																												if (num != 1229)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 78:
																													goto IL_0402_2;
																												case 190:
																												case 195:
																													goto IL_044c_2;
																												case 131:
																													goto IL_0462_2;
																												case 16:
																												case 168:
																													goto IL_0472_2;
																												case 36:
																													goto IL_0482_2;
																												case 34:
																													goto IL_0492_2;
																												case 43:
																												case 169:
																													goto IL_04a2_2;
																												case 63:
																													goto IL_04af_2;
																												case 171:
																													goto IL_04bf_2;
																												case 146:
																													goto IL_04cf_2;
																												case 105:
																													goto IL_04df_2;
																												case 25:
																													goto IL_04ef_2;
																												case 81:
																												case 133:
																													goto IL_04ff_2;
																												case 44:
																													goto IL_050a_2;
																												case 56:
																												case 97:
																													goto IL_0518_2;
																												case 179:
																													goto IL_0566_2;
																												case 125:
																												case 177:
																													goto IL_0571_2;
																												case 64:
																													goto IL_057c_2;
																												case 94:
																												case 151:
																													goto IL_058f_2;
																												case 21:
																													goto IL_05d8_2;
																												case 69:
																												case 184:
																													goto IL_05ee_2;
																												case 127:
																													goto IL_05fc_2;
																												case 187:
																													goto IL_060c_2;
																												case 6:
																													goto IL_0629_2;
																												case 59:
																												case 198:
																													goto IL_063c_2;
																												case 221:
																													goto IL_064f_2;
																												case 66:
																												case 232:
																													goto IL_066b_2;
																												case 114:
																													goto IL_06ab_2;
																												case 175:
																													goto IL_06bf_2;
																												case 30:
																												case 233:
																													goto IL_06d2_2;
																												case 9:
																												case 231:
																													goto IL_06e0_2;
																												case 104:
																												case 126:
																													goto IL_06ee_2;
																												case 71:
																													goto IL_06fc_2;
																												case 147:
																												case 229:
																													goto IL_070a_2;
																												case 199:
																													goto IL_074a_2;
																												case 183:
																													goto IL_075e_2;
																												case 109:
																													goto IL_0771_2;
																												case 27:
																												case 80:
																													goto IL_077f_2;
																												case 4:
																													goto IL_078d_2;
																												case 58:
																													goto IL_07b0_2;
																												case 17:
																													goto IL_07ba_2;
																												case 128:
																													goto IL_07c8_2;
																												case 79:
																													goto IL_07db_2;
																												case 1:
																												case 216:
																													goto IL_07f2_2;
																												case 75:
																													goto IL_07fd_2;
																												case 156:
																													goto IL_0810_2;
																												case 225:
																													goto IL_081e_2;
																												case 41:
																												case 165:
																													goto IL_082c_2;
																												case 140:
																													goto IL_086c_2;
																												case 29:
																													goto IL_0880_2;
																												case 51:
																												case 144:
																													goto IL_0893_2;
																												case 230:
																													goto IL_08bc_2;
																												case 213:
																													goto IL_08ca_2;
																												case 137:
																													goto IL_08f9_2;
																												case 61:
																												case 93:
																													goto IL_0904_2;
																												case 84:
																													goto IL_0966_2;
																												case 124:
																												case 193:
																													goto IL_0987_2;
																												case 220:
																													goto end_IL_03ef_2;
																												case 18:
																												case 98:
																													goto IL_09a0_2;
																												case 196:
																													goto IL_09de_2;
																												case 111:
																												case 159:
																													goto IL_09fa_2;
																												case 139:
																												case 157:
																													goto IL_0a08_2;
																												case 136:
																													goto IL_0a1f_2;
																												case 180:
																												case 217:
																													goto IL_0a2d_2;
																												case 67:
																													goto IL_0a45_2;
																												case 145:
																													goto IL_0a63_2;
																												case 237:
																													goto IL_0a87_2;
																												case 236:
																													goto IL_0a9f_2;
																												case 176:
																													goto IL_0ab2_2;
																												case 206:
																													goto IL_0ac0_2;
																												case 72:
																												case 219:
																													goto IL_0ace_2;
																												case 0:
																													goto IL_0adc_2;
																												case 135:
																													goto IL_0af4_2;
																												case 222:
																													goto IL_0b02_2;
																												case 107:
																													goto IL_0b15_2;
																												case 3:
																												case 99:
																													goto IL_0b29_2;
																												case 214:
																													goto IL_0b5b_2;
																												case 15:
																													goto IL_0b74_2;
																												case 26:
																													goto IL_0b82_2;
																												case 160:
																												case 167:
																													goto end_IL_0f44_2;
																												case 210:
																													goto IL_0c47_2;
																												case 166:
																													goto IL_0c55_2;
																												case 162:
																													goto IL_0c68_2;
																												case 134:
																													goto IL_0c76_2;
																												case 12:
																												case 234:
																													goto IL_0c84_2;
																												case 142:
																													goto IL_0ca2_2;
																												case 24:
																													goto IL_0cb0_2;
																												case 224:
																													goto IL_0cc3_2;
																												case 95:
																												case 121:
																													goto IL_0cd1_2;
																												case 182:
																												case 235:
																													goto IL_0cdc_2;
																												case 14:
																													goto IL_0cea_2;
																												case 49:
																												case 174:
																													goto IL_0cf8_2;
																												case 143:
																													goto IL_0d14_2;
																												case 47:
																												case 60:
																													goto IL_0d1f_2;
																												case 209:
																													goto IL_0d2d_2;
																												case 194:
																												case 201:
																													goto IL_0d3b_2;
																												case 155:
																													goto IL_0d53_2;
																												case 52:
																													goto IL_0d61_2;
																												case 37:
																													goto IL_0d6f_2;
																												case 48:
																												case 70:
																													goto IL_0d82_2;
																												case 91:
																													goto IL_0dab_2;
																												case 32:
																													goto IL_0db9_2;
																												case 204:
																													goto IL_0dcc_2;
																												case 53:
																												case 161:
																													goto IL_0dda_2;
																												case 54:
																												case 82:
																													goto IL_0de5_2;
																												case 100:
																													goto IL_0df3_2;
																												case 83:
																												case 163:
																													goto IL_0e01_2;
																												case 68:
																													goto IL_0e16_2;
																												case 186:
																													goto IL_0e29_2;
																												case 158:
																												case 189:
																													goto IL_0e37_2;
																												case 152:
																													goto IL_0e4b_2;
																												case 218:
																													goto IL_0e83_2;
																												case 90:
																												case 108:
																													goto IL_0e96_2;
																												case 62:
																													goto IL_0eaa_2;
																												case 76:
																													goto IL_0ee8_2;
																												case 10:
																												case 11:
																												case 19:
																												case 20:
																												case 22:
																												case 28:
																												case 31:
																												case 33:
																												case 45:
																												case 46:
																												case 50:
																												case 57:
																												case 77:
																												case 85:
																												case 87:
																												case 89:
																												case 92:
																												case 101:
																												case 102:
																												case 115:
																												case 117:
																												case 118:
																												case 119:
																												case 122:
																												case 130:
																												case 138:
																												case 149:
																												case 150:
																												case 154:
																												case 170:
																												case 173:
																												case 185:
																												case 188:
																												case 200:
																												case 205:
																												case 211:
																												case 212:
																												case 215:
																												case 223:
																												case 226:
																												case 228:
																												case 238:
																												case 241:
																													goto end_IL_0462_2;
																												case 103:
																													goto IL_0f11_2;
																												case 23:
																													goto IL_0f1f_2;
																												case 2:
																													goto IL_0f2d_2;
																												case 13:
																												case 39:
																												case 55:
																												case 73:
																												case 74:
																												case 86:
																												case 88:
																												case 96:
																												case 110:
																												case 112:
																												case 113:
																												case 116:
																												case 120:
																												case 123:
																												case 129:
																												case 132:
																												case 148:
																												case 164:
																												case 178:
																												case 191:
																												case 202:
																												case 203:
																												case 207:
																												case 208:
																												case 227:
																												case 239:
																												case 240:
																													goto end_IL_04af_2;
																												case 65:
																													ptr2 = ptr;
																													num = 112;
																													goto end_IL_04af_2;
																												case 38:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMaximumAgeUnitConcurrentStackFastPushFailed.FromMillisecondsRegisterForFullGCNotification);
																													goto case 65;
																												case 181:
																													array7[0] = this;
																													goto case 38;
																												case 197:
																													array7 = new object[4];
																													num = 181;
																													goto case 181;
																												case 172:
																													array6 = new long[4];
																													goto case 197;
																												case 141:
																													array5 = new int[6];
																													goto case 172;
																												case 35:
																													array4 = new int[4];
																													goto case 141;
																												case 42:
																													array3 = new object[4];
																													goto case 35;
																												case 5:
																												case 40:
																													array2 = new byte[4];
																													goto case 42;
																												case 153:
																													num3 = num2 * 4;
																													goto case 5;
																												case 7:
																													num2 = 1;
																													goto case 153;
																												case 8:
																													goto end_IL_0bad;
																												case 106:
																												case 192:
																													return;
																												}
																												continue;
																											}
																											ptr2 += 8;
																											goto end_IL_04af_2;
																											continue;
																											end_IL_03ef_2:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0995_2;
																								continue;
																								end_IL_0462_2:
																								break;
																								IL_0462_2:;
																							}
																							break;
																							IL_0472_2:;
																						}
																						break;
																					}
																					goto IL_08f9_2;
																					IL_0966_2:
																					num5 -= 2;
																					goto end_IL_04af_2;
																					IL_08f9_2:
																					if (10 > b)
																					{
																						num = 45;
																						break;
																					}
																					goto IL_0904_2;
																					IL_0904_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0966_2;
																				}
																				break;
																			}
																			goto IL_0566_2;
																			IL_064f_2:
																			num5--;
																			num = 132;
																			goto end_IL_04af_2;
																			IL_0566_2:
																			if (9 > b)
																			{
																				goto IL_0571_2;
																			}
																			goto IL_058f_2;
																			IL_0571_2:
																			if (7 >= b)
																			{
																				goto IL_057c_2;
																			}
																			goto IL_05ee_2;
																			IL_057c_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_066b_2;
																			IL_066b_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_06ab_2;
																			IL_06ab_2:
																			array2[num5 - 2] = 0;
																			goto IL_06bf_2;
																			IL_06bf_2:
																			num5--;
																			goto end_IL_04af_2;
																			IL_05ee_2:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_05fc_2;
																			IL_05fc_2:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_063c_2;
																			IL_063c_2:
																			num5--;
																			goto end_IL_04af_2;
																			IL_058f_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			num = 21;
																			goto IL_05d8_2;
																			IL_05d8_2:
																			array2[num5 - 2] = 0;
																			goto IL_064f_2;
																		}
																		break;
																	}
																	goto IL_050a_2;
																	IL_08bc_2:
																	ptr2 += 8;
																	goto IL_08ca_2;
																	IL_050a_2:
																	if (6 <= b)
																	{
																		goto IL_0518_2;
																	}
																	goto IL_06d2_2;
																	IL_0518_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	num = 187;
																	goto IL_060c_2;
																	IL_060c_2:
																	array2[num5 - 2] = 0;
																	num = 6;
																	goto IL_0629_2;
																	IL_0629_2:
																	num5--;
																	goto end_IL_04af_2;
																	IL_06d2_2:
																	if (3 < b)
																	{
																		goto IL_06e0_2;
																	}
																	goto IL_07db_2;
																	IL_06e0_2:
																	if (4 < b)
																	{
																		goto IL_06ee_2;
																	}
																	goto IL_0771_2;
																	IL_06ee_2:
																	if (5 < b)
																	{
																		break;
																	}
																	goto IL_06fc_2;
																	IL_06fc_2:
																	if (5 > b)
																	{
																		break;
																	}
																	goto IL_070a_2;
																	IL_070a_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_074a_2;
																	IL_074a_2:
																	array2[num5 - 2] = 0;
																	goto IL_075e_2;
																	IL_075e_2:
																	num5--;
																	goto end_IL_04af_2;
																	IL_0771_2:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_077f_2;
																	IL_077f_2:
																	array2[num5] = 0;
																	goto IL_078d_2;
																	IL_078d_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																	goto IL_07b0_2;
																	IL_07b0_2:
																	array3[num5] = null;
																	goto IL_07ba_2;
																	IL_07ba_2:
																	num5++;
																	goto IL_07c8_2;
																	IL_07c8_2:
																	ptr2 += 8;
																	goto end_IL_04af_2;
																	IL_07db_2:
																	if (3 > b)
																	{
																		num = 216;
																		goto IL_07f2_2;
																	}
																	goto IL_0893_2;
																	IL_08ca_2:
																	num5--;
																	num = 13;
																	goto end_IL_04af_2;
																	IL_07f2_2:
																	if (1 >= b)
																	{
																		goto IL_07fd_2;
																	}
																	goto IL_0810_2;
																	IL_07fd_2:
																	if (1 > b)
																	{
																	}
																	break;
																	IL_0810_2:
																	if (2 < b)
																	{
																		break;
																	}
																	goto IL_081e_2;
																	IL_081e_2:
																	if (2 > b)
																	{
																		break;
																	}
																	goto IL_082c_2;
																	IL_082c_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_086c_2;
																	IL_086c_2:
																	array2[num5 - 2] = 0;
																	goto IL_0880_2;
																	IL_0880_2:
																	num5--;
																	goto end_IL_04af_2;
																	IL_0893_2:
																	reference = ref array5[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																	goto IL_08bc_2;
																}
																goto end_IL_04cf_2;
																continue;
																end_IL_04af_2:
																break;
																IL_04af_2:;
															}
															break;
														}
														goto IL_0987_2;
														IL_0e83_2:
														ptr2 += 8;
														break;
														IL_0987_2:
														if (18 >= b)
														{
															goto IL_0995_2;
														}
														goto IL_0cc3_2;
														IL_0995_2:
														if (18 <= b)
														{
															goto IL_09a0_2;
														}
														num = 111;
														goto IL_09fa_2;
														IL_09a0_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														goto IL_09de_2;
														IL_09de_2:
														num5 -= 3;
														break;
														IL_0e96_2:
														array2[num5 - 1] = 0;
														goto IL_0eaa_2;
														IL_09fa_2:
														if (15 < b)
														{
															goto IL_0a08_2;
														}
														goto IL_0b15_2;
														IL_0a08_2:
														if (16 >= b)
														{
															num = 136;
															goto IL_0a1f_2;
														}
														goto IL_0ab2_2;
														IL_0eaa_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (((delegate*<string, bool>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]) ? 1 : 0);
														goto IL_0ee8_2;
														IL_0a1f_2:
														if (16 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0a2d_2;
														IL_0a2d_2:
														array2[num5] = array2[num5 - 1];
														goto IL_0a45_2;
														IL_0a45_2:
														array4[num5 - 0] = array4[num5 - 1];
														goto IL_0a63_2;
														IL_0a63_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0a87_2;
														IL_0a87_2:
														array3[num5] = array3[num5 - 1];
														goto IL_0a9f_2;
														IL_0a9f_2:
														num5++;
														break;
														IL_0ab2_2:
														if (17 < b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0ac0_2;
														IL_0ac0_2:
														if (17 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0ace_2;
														IL_0ace_2:
														array2[num5] = 5;
														goto IL_0adc_2;
														IL_0adc_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_0af4_2;
														IL_0af4_2:
														num5++;
														goto IL_0b02_2;
														IL_0b02_2:
														ptr2 += 8;
														break;
														IL_0b15_2:
														if (15 <= b)
														{
															num = 99;
															goto IL_0b29_2;
														}
														goto IL_0b74_2;
														IL_0ee8_2:
														ptr2 += 8;
														break;
														IL_0b29_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														num = 214;
														goto IL_0b5b_2;
														IL_0b5b_2:
														array2[num5 - 1] = 5;
														break;
														IL_0b74_2:
														if (13 >= b)
														{
															goto IL_0b82_2;
														}
														goto IL_0c68_2;
														IL_0b82_2:
														if (13 > b)
														{
															goto end_IL_04cf_2;
														}
														goto end_IL_0f44_2;
														IL_0c68_2:
														if (14 < b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0c76_2;
														IL_0c76_2:
														if (14 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0c84_2;
														IL_0c84_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_0ca2_2;
														IL_0ca2_2:
														ptr2 += 8;
														goto IL_0cb0_2;
														IL_0cb0_2:
														num5--;
														break;
														IL_0cc3_2:
														if (21 < b)
														{
															goto IL_0cd1_2;
														}
														goto IL_0dcc_2;
														IL_0cd1_2:
														if (23 < b)
														{
															goto IL_0cdc_2;
														}
														goto IL_0d14_2;
														IL_0cdc_2:
														if (24 < b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0cea_2;
														IL_0cea_2:
														if (24 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0cf8_2;
														IL_0cf8_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														break;
														IL_0d14_2:
														if (23 > b)
														{
															goto IL_0d1f_2;
														}
														goto IL_0d82_2;
														IL_0d1f_2:
														if (22 < b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0d2d_2;
														IL_0d2d_2:
														if (22 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0d3b_2;
														IL_0d3b_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_0d53_2;
														IL_0d53_2:
														array2[num5] = 5;
														goto IL_0d61_2;
														IL_0d61_2:
														num5++;
														goto IL_0d6f_2;
														IL_0d6f_2:
														ptr2 += 8;
														break;
														IL_0d82_2:
														((delegate*<UnityEngine.Object, void>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((Class161)array3[num5 - 1]);
														goto IL_0dab_2;
														IL_0dab_2:
														num5--;
														goto IL_0db9_2;
														IL_0db9_2:
														ptr2 += 8;
														break;
														IL_0dcc_2:
														if (21 > b)
														{
															goto IL_0dda_2;
														}
														goto IL_0e96_2;
														IL_0dda_2:
														if (19 < b)
														{
															goto IL_0de5_2;
														}
														goto IL_0e29_2;
														IL_0de5_2:
														if (20 < b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0df3_2;
														IL_0df3_2:
														if (20 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0e01_2;
														IL_0e01_2:
														((delegate*<void>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])();
														goto IL_0e16_2;
														IL_0e16_2:
														ptr2 += 8;
														break;
														IL_0e29_2:
														if (19 > b)
														{
															goto end_IL_04cf_2;
														}
														goto IL_0e37_2;
														IL_0e37_2:
														array2[num5 - 1] = 5;
														goto IL_0e4b_2;
														IL_0e4b_2:
														array3[num5 - 1] = ((delegate*<string[], string>)AceTypeResourceManagerMediator[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
														goto IL_0e83_2;
													}
													goto end_IL_04df_2;
													continue;
													end_IL_04cf_2:
													break;
													IL_04cf_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_0f11_2;
											IL_0f2d_2:
											ptr2 += 8;
											num = 202;
											break;
											IL_0f1f_2:
											num5++;
											goto IL_0f2d_2;
											IL_0f11_2:
											array2[num5] = 0;
											goto IL_0f1f_2;
											continue;
											end_IL_04df_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_0f44_2:
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0b9f_2;
					}
					continue;
					end_IL_0bad:
					break;
				}
				break;
			}
		}
	}

	public Class161()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 96;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 30;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PEFileKindsEnableEvents.UNICODEINTPTRSTRINGgetInternalStore);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 59;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 86;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0283:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0263:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0253:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0243:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0233:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_0220:
																												if (1 >= b)
																												{
																													num = 124;
																													while (true)
																													{
																														if (num != 124)
																														{
																															if (num != 1105)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 44:
																															case 56:
																																goto IL_0220;
																															case 0:
																																goto IL_0233;
																															case 34:
																															case 81:
																																goto IL_0243;
																															case 14:
																																goto IL_0253;
																															case 38:
																																goto IL_0263;
																															case 66:
																																goto IL_0273;
																															case 80:
																																goto end_IL_020d;
																															case 86:
																																goto end_IL_0283;
																															case 10:
																															case 76:
																																goto end_IL_0293;
																															case 12:
																															case 89:
																																goto IL_02c5;
																															case 74:
																																goto IL_02de;
																															case 43:
																																goto IL_02ec;
																															case 98:
																																goto IL_02fa;
																															case 58:
																																goto IL_030d;
																															case 77:
																																goto IL_031b;
																															case 25:
																															case 79:
																																goto IL_0329;
																															case 22:
																																goto IL_0352;
																															case 29:
																																goto IL_0360;
																															case 18:
																															case 117:
																																goto IL_0373;
																															case 8:
																																goto IL_038b;
																															case 23:
																															case 47:
																																goto IL_0399;
																															case 20:
																																goto IL_03a7;
																															case 3:
																															case 9:
																																goto IL_03b5;
																															case 94:
																																goto IL_03c3;
																															case 85:
																																goto IL_03e6;
																															case 93:
																																goto IL_03f9;
																															case 60:
																																goto IL_0407;
																															case 33:
																																goto IL_041a;
																															case 90:
																															case 106:
																																goto IL_042d;
																															case 39:
																																goto IL_046d;
																															case 13:
																																goto IL_0481;
																															case 27:
																															case 88:
																																goto IL_049d;
																															case 15:
																															case 19:
																																goto IL_04b1;
																															case 70:
																																goto IL_04bc;
																															case 73:
																															case 92:
																																goto IL_04ca;
																															case 24:
																															case 41:
																																goto IL_04e6;
																															case 57:
																																goto IL_04f4;
																															case 31:
																																goto IL_0507;
																															case 4:
																															case 67:
																																goto IL_0512;
																															case 87:
																																goto IL_0574;
																															case 116:
																																goto IL_0587;
																															case 72:
																															case 101:
																																goto IL_0592;
																															case 107:
																																goto IL_05a0;
																															case 108:
																															case 115:
																																goto IL_05ae;
																															case 21:
																																goto IL_05d1;
																															case 50:
																																goto IL_05df;
																															case 63:
																																goto IL_05f6;
																															case 114:
																																goto IL_0609;
																															case 45:
																															case 49:
																																goto IL_061f;
																															case 68:
																																goto IL_065f;
																															case 113:
																																goto IL_0673;
																															case 16:
																															case 17:
																															case 32:
																															case 36:
																															case 37:
																															case 40:
																															case 46:
																															case 51:
																															case 55:
																															case 61:
																															case 62:
																															case 64:
																															case 69:
																															case 71:
																															case 75:
																															case 82:
																															case 97:
																															case 99:
																															case 103:
																															case 105:
																															case 109:
																															case 111:
																															case 112:
																																goto end_IL_0273;
																															case 6:
																															case 35:
																															case 42:
																															case 48:
																															case 52:
																															case 54:
																															case 59:
																															case 78:
																															case 84:
																															case 100:
																															case 102:
																															case 104:
																															case 110:
																																goto end_IL_02a3;
																															case 11:
																																goto end_IL_0696;
																															case 1:
																																goto end_IL_06a9;
																															case 30:
																																goto end_IL_06b4;
																															case 26:
																																goto end_IL_06be;
																															case 65:
																																goto end_IL_06c9;
																															case 83:
																															case 91:
																																goto end_IL_06e7;
																															case 28:
																																goto end_IL_06f7;
																															case 7:
																															case 53:
																																goto end_IL_0707;
																															case 95:
																																goto end_IL_0717;
																															case 96:
																																goto end_IL_0727;
																															case 2:
																															case 5:
																																goto IL_074b;
																															}
																															continue;
																														}
																														if (1 > b)
																														{
																															goto end_IL_0273;
																														}
																														goto IL_02c5;
																														IL_02de:
																														array[num5] = 0;
																														goto IL_02ec;
																														IL_02fa:
																														ptr2 += 8;
																														goto end_IL_02a3;
																														IL_02ec:
																														num5++;
																														goto IL_02fa;
																														IL_02c5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														goto IL_02de;
																														continue;
																														end_IL_020d:
																														break;
																													}
																													break;
																												}
																												goto IL_030d;
																												IL_0352:
																												ptr2 += 8;
																												goto IL_0360;
																												IL_0360:
																												num5--;
																												goto end_IL_02a3;
																												IL_030d:
																												if (2 < b)
																												{
																													goto end_IL_0273;
																												}
																												goto IL_031b;
																												IL_031b:
																												if (2 > b)
																												{
																													goto end_IL_0273;
																												}
																												goto IL_0329;
																												IL_0329:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0352;
																											}
																											break;
																										}
																										goto IL_0373;
																										IL_0373:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02a3;
																									}
																									break;
																								}
																								goto IL_038b;
																								IL_041a:
																								if (4 > b)
																								{
																									goto end_IL_0273;
																								}
																								goto end_IL_02a3;
																								IL_038b:
																								if (4 < b)
																								{
																									goto IL_0399;
																								}
																								goto IL_041a;
																								IL_0399:
																								if (5 < b)
																								{
																									goto end_IL_0273;
																								}
																								goto IL_03a7;
																								IL_03a7:
																								if (5 > b)
																								{
																									goto end_IL_0273;
																								}
																								goto IL_03b5;
																								IL_03b5:
																								array[num5] = 0;
																								goto IL_03c3;
																								IL_03c3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03e6;
																								IL_03e6:
																								array2[num5] = null;
																								num = 93;
																								goto IL_03f9;
																								IL_03f9:
																								num5++;
																								goto IL_0407;
																								IL_0407:
																								ptr2 += 8;
																								goto end_IL_02a3;
																							}
																							break;
																						}
																						goto IL_042d;
																						IL_0481:
																						num5--;
																						goto end_IL_02a3;
																						IL_042d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_046d;
																						IL_046d:
																						array[num5 - 2] = 0;
																						goto IL_0481;
																					}
																					break;
																				}
																				num = 88;
																				goto IL_049d;
																				IL_0673:
																				num5--;
																				goto end_IL_02a3;
																				IL_061f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_065f;
																				IL_049d:
																				if (9 < b)
																				{
																					num = 15;
																					goto IL_04b1;
																				}
																				goto IL_0507;
																				IL_065f:
																				array[num5 - 2] = 0;
																				goto IL_0673;
																				IL_04b1:
																				if (10 >= b)
																				{
																					goto IL_04bc;
																				}
																				goto IL_04e6;
																				IL_04bc:
																				if (10 > b)
																				{
																					goto end_IL_0273;
																				}
																				goto IL_04ca;
																				IL_04ca:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a3;
																				IL_04e6:
																				if (11 < b)
																				{
																					goto end_IL_0273;
																				}
																				goto IL_04f4;
																				IL_04f4:
																				if (11 <= b)
																				{
																				}
																				goto end_IL_0273;
																				IL_0507:
																				if (9 <= b)
																				{
																					goto IL_0512;
																				}
																				goto IL_0587;
																				IL_0512:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0574;
																				IL_0574:
																				num5 -= 2;
																				goto end_IL_02a3;
																				IL_0587:
																				if (7 < b)
																				{
																					goto IL_0592;
																				}
																				goto IL_0609;
																				IL_0592:
																				if (8 < b)
																				{
																					goto end_IL_0273;
																				}
																				goto IL_05a0;
																				IL_05a0:
																				if (8 > b)
																				{
																					goto end_IL_0273;
																				}
																				goto IL_05ae;
																				IL_05ae:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05d1;
																				IL_05d1:
																				array[num5] = 0;
																				goto IL_05df;
																				IL_05df:
																				num5++;
																				num = 63;
																				goto IL_05f6;
																				IL_05f6:
																				ptr2 += 8;
																				goto end_IL_02a3;
																				IL_0609:
																				if (7 > b)
																				{
																					num = 109;
																					goto end_IL_0273;
																				}
																				goto IL_061f;
																			}
																			goto IL_0283;
																			continue;
																			end_IL_0273:
																			break;
																			IL_0273:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02a3;
																	continue;
																	end_IL_0283:
																	break;
																}
																continue;
																end_IL_0293:
																break;
															}
															continue;
															end_IL_02a3:
															break;
														}
														continue;
													}
													num = 5;
													goto IL_074b;
													IL_074b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0696:
													break;
												}
												continue;
												end_IL_06a9:
												break;
											}
											continue;
											end_IL_06b4:
											break;
										}
										continue;
										end_IL_06be:
										break;
									}
									continue;
									end_IL_06c9:
									break;
								}
								continue;
								end_IL_06e7:
								break;
							}
							continue;
							end_IL_06f7:
							break;
						}
						continue;
						end_IL_0707:
						break;
					}
					continue;
					end_IL_0717:
					break;
				}
				continue;
				end_IL_0727:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 26;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadCachegetDisallowPublisherPolicy.setKeyStoreStringBuffer);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02a0:
																		if (b > 15)
																		{
																			num = 156;
																			while (num != 156)
																			{
																				if (num != 1137)
																				{
																					goto IL_04d0;
																				}
																				switch (num)
																				{
																				case 2:
																					goto IL_02a0;
																				case 103:
																					goto IL_02b0;
																				case 33:
																					goto end_IL_02b0;
																				case 13:
																				case 80:
																					goto end_IL_02c0;
																				case 91:
																					goto IL_02db;
																				case 133:
																					goto IL_02e9;
																				case 72:
																				case 147:
																					goto IL_02f7;
																				case 65:
																					goto IL_0305;
																				case 108:
																				case 113:
																					goto IL_0310;
																				case 105:
																					goto IL_032e;
																				case 66:
																					goto IL_033c;
																				case 99:
																					goto IL_0358;
																				case 1:
																				case 149:
																					goto IL_0363;
																				case 95:
																					goto IL_0371;
																				case 98:
																				case 139:
																					goto IL_037f;
																				case 74:
																					goto IL_03a8;
																				case 141:
																					goto IL_03c1;
																				case 97:
																				case 144:
																					goto IL_03cc;
																				case 4:
																					goto IL_03da;
																				case 44:
																				case 120:
																					goto IL_03e8;
																				case 67:
																					goto IL_040a;
																				case 52:
																					goto IL_0418;
																				case 29:
																					goto IL_0426;
																				case 6:
																				case 131:
																					goto IL_0442;
																				case 3:
																					goto IL_0482;
																				case 112:
																					goto IL_0496;
																				case 55:
																					goto IL_04a9;
																				case 54:
																				case 88:
																					goto IL_04b4;
																				case 43:
																					goto IL_04c2;
																				case 17:
																				case 28:
																					goto IL_04d0;
																				case 12:
																					goto IL_04f9;
																				case 49:
																					goto IL_0510;
																				case 36:
																					goto IL_0523;
																				case 63:
																				case 81:
																					goto IL_052e;
																				case 51:
																					goto IL_056d;
																				case 76:
																					goto IL_0580;
																				case 70:
																					goto IL_058e;
																				case 90:
																				case 134:
																					goto IL_059c;
																				case 138:
																					goto IL_05aa;
																				case 15:
																					goto IL_05c2;
																				case 114:
																					goto IL_05d0;
																				case 40:
																				case 87:
																					goto IL_05e3;
																				case 31:
																					goto IL_0604;
																				case 39:
																				case 118:
																					goto IL_0612;
																				case 34:
																					goto IL_0620;
																				case 48:
																				case 85:
																					goto IL_062b;
																				case 22:
																					goto IL_0647;
																				case 46:
																					goto IL_065e;
																				case 37:
																				case 68:
																					goto IL_066c;
																				case 18:
																					goto IL_06ce;
																				case 93:
																				case 148:
																					goto IL_06e1;
																				case 9:
																					goto IL_06ef;
																				case 142:
																					goto IL_0702;
																				case 0:
																				case 71:
																					goto IL_070d;
																				case 107:
																					goto IL_074d;
																				case 137:
																					goto IL_0761;
																				case 96:
																					goto IL_0774;
																				case 84:
																				case 109:
																					goto IL_0782;
																				case 145:
																					goto IL_0790;
																				case 38:
																				case 57:
																					goto IL_079e;
																				case 14:
																					goto IL_07e2;
																				case 64:
																					goto IL_07f6;
																				case 106:
																					goto IL_0809;
																				case 75:
																				case 129:
																					goto IL_0814;
																				case 92:
																					goto IL_081f;
																				case 102:
																				case 146:
																					goto IL_082c;
																				case 101:
																					goto IL_083a;
																				case 83:
																					goto IL_085d;
																				case 20:
																					goto IL_0867;
																				case 119:
																					goto IL_0875;
																				case 5:
																				case 7:
																				case 8:
																				case 19:
																				case 24:
																				case 30:
																				case 41:
																				case 45:
																				case 56:
																				case 62:
																				case 79:
																				case 82:
																				case 86:
																				case 89:
																				case 104:
																				case 111:
																				case 115:
																				case 117:
																				case 121:
																				case 122:
																				case 126:
																				case 128:
																				case 130:
																				case 135:
																				case 136:
																				case 140:
																				case 143:
																					goto end_IL_028d;
																				case 11:
																				case 16:
																				case 23:
																				case 32:
																				case 35:
																				case 42:
																				case 47:
																				case 53:
																				case 59:
																				case 69:
																				case 78:
																				case 94:
																				case 100:
																				case 116:
																				case 124:
																				case 125:
																				case 127:
																				case 132:
																					goto end_IL_02d0;
																				case 73:
																					goto end_IL_0898;
																				case 58:
																					goto end_IL_08ab;
																				case 10:
																					goto end_IL_08b5;
																				case 110:
																					goto end_IL_08c0;
																				case 21:
																				case 27:
																					goto end_IL_08d0;
																				case 77:
																					goto end_IL_08e0;
																				case 60:
																				case 123:
																					goto end_IL_08f0;
																				case 25:
																					goto end_IL_0900;
																				case 26:
																					goto end_IL_0910;
																				case 50:
																				case 61:
																					goto IL_092b;
																				}
																				continue;
																				end_IL_028d:
																				break;
																			}
																			break;
																		}
																		goto IL_02db;
																		IL_085d:
																		array2[num5] = null;
																		goto IL_0867;
																		IL_0867:
																		num5++;
																		goto IL_0875;
																		IL_02db:
																		if (8 >= b)
																		{
																			goto IL_02e9;
																		}
																		goto IL_0604;
																		IL_02e9:
																		if (8 > b)
																		{
																			goto IL_02f7;
																		}
																		goto IL_05e3;
																		IL_02f7:
																		if (4 >= b)
																		{
																			goto IL_0305;
																		}
																		goto IL_04a9;
																		IL_0305:
																		if (4 <= b)
																		{
																			goto IL_0310;
																		}
																		goto IL_0358;
																		IL_0310:
																		array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																		goto IL_032e;
																		IL_032e:
																		ptr2 += 8;
																		goto IL_033c;
																		IL_033c:
																		num5--;
																		num = 42;
																		goto end_IL_02d0;
																		IL_0358:
																		if (2 < b)
																		{
																			goto IL_0363;
																		}
																		goto IL_03c1;
																		IL_0363:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_0371;
																		IL_0371:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_037f;
																		IL_037f:
																		array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																		goto IL_03a8;
																		IL_03a8:
																		array[num5 - 1] = 5;
																		goto end_IL_02d0;
																		IL_03c1:
																		if (2 > b)
																		{
																			goto IL_03cc;
																		}
																		goto IL_0442;
																		IL_03cc:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_03da;
																		IL_03da:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_03e8;
																		IL_03e8:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		num = 67;
																		goto IL_040a;
																		IL_040a:
																		array[num5] = 0;
																		goto IL_0418;
																		IL_0418:
																		num5++;
																		goto IL_0426;
																		IL_0426:
																		ptr2 += 8;
																		num = 16;
																		goto end_IL_02d0;
																		IL_0442:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0482;
																		IL_0482:
																		array[num5 - 2] = 0;
																		goto IL_0496;
																		IL_0496:
																		num5--;
																		goto end_IL_02d0;
																		IL_04a9:
																		if (6 < b)
																		{
																			goto IL_04b4;
																		}
																		goto IL_0523;
																		IL_04b4:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_04c2;
																		IL_04c2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_04d0;
																		IL_04d0:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04f9;
																		IL_04f9:
																		ptr2 += 8;
																		num = 49;
																		goto IL_0510;
																		IL_0510:
																		num5--;
																		goto end_IL_02d0;
																		IL_0523:
																		if (6 <= b)
																		{
																			goto IL_052e;
																		}
																		goto IL_0580;
																		IL_052e:
																		((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_056d;
																		IL_056d:
																		num5 -= 3;
																		goto end_IL_02d0;
																		IL_0580:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_058e;
																		IL_058e:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_059c;
																		IL_059c:
																		array[num5] = 5;
																		goto IL_05aa;
																		IL_05aa:
																		array2[num5] = array5[*(int*)(ptr2 + num3)];
																		goto IL_05c2;
																		IL_05c2:
																		num5++;
																		goto IL_05d0;
																		IL_05d0:
																		ptr2 += 8;
																		goto end_IL_02d0;
																		IL_05e3:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 132;
																		goto end_IL_02d0;
																		IL_0604:
																		if (12 < b)
																		{
																			goto IL_0612;
																		}
																		goto IL_0702;
																		IL_0612:
																		if (14 >= b)
																		{
																			goto IL_0620;
																		}
																		goto IL_06e1;
																		IL_0620:
																		if (14 <= b)
																		{
																			goto IL_062b;
																		}
																		goto IL_0647;
																		IL_062b:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_02d0;
																		IL_0647:
																		if (13 < b)
																		{
																			break;
																		}
																		num = 46;
																		goto IL_065e;
																		IL_0875:
																		ptr2 += 8;
																		goto end_IL_02d0;
																		IL_065e:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_066c;
																		IL_066c:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_06ce;
																		IL_06ce:
																		num5 -= 2;
																		goto end_IL_02d0;
																		IL_06e1:
																		if (15 < b)
																		{
																			break;
																		}
																		goto IL_06ef;
																		IL_06ef:
																		if (15 <= b)
																		{
																		}
																		break;
																		IL_0702:
																		if (12 <= b)
																		{
																			goto IL_070d;
																		}
																		goto IL_0774;
																		IL_070d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_074d;
																		IL_074d:
																		array[num5 - 2] = 0;
																		goto IL_0761;
																		IL_0761:
																		num5--;
																		goto end_IL_02d0;
																		IL_0774:
																		if (10 < b)
																		{
																			goto IL_0782;
																		}
																		goto IL_0809;
																		IL_0782:
																		if (11 < b)
																		{
																			break;
																		}
																		goto IL_0790;
																		IL_0790:
																		if (11 > b)
																		{
																			break;
																		}
																		goto IL_079e;
																		IL_079e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																		goto IL_07e2;
																		IL_07e2:
																		array[num5 - 2] = 0;
																		goto IL_07f6;
																		IL_07f6:
																		num5--;
																		goto end_IL_02d0;
																		IL_0809:
																		if (10 > b)
																		{
																			goto IL_0814;
																		}
																		goto IL_082c;
																		IL_0814:
																		if (9 < b)
																		{
																			break;
																		}
																		goto IL_081f;
																		IL_081f:
																		if (9 > b)
																		{
																			break;
																		}
																		goto end_IL_02d0;
																		IL_082c:
																		array[num5] = 0;
																		goto IL_083a;
																		IL_083a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_085d;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d0;
																continue;
																end_IL_02b0:
																break;
															}
															continue;
															end_IL_02c0:
															break;
														}
														continue;
														end_IL_02d0:
														break;
													}
													continue;
												}
												goto IL_092b;
												IL_092b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0898:
												break;
											}
											continue;
											end_IL_08ab:
											break;
										}
										continue;
										end_IL_08b5:
										break;
									}
									continue;
									end_IL_08c0:
									break;
								}
								continue;
								end_IL_08d0:
								break;
							}
							continue;
							end_IL_08e0:
							break;
						}
						continue;
						end_IL_08f0:
						break;
					}
					continue;
					end_IL_0900:
					break;
				}
				continue;
				end_IL_0910:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 108;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 117;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 36;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MetadataSectionDependentOSDataConvOvfI.setHostContextMemberTypes);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f3:
														byte b = *ptr2;
														while (true)
														{
															IL_02da:
															ptr2++;
															num = 51;
															while (true)
															{
																IL_02ca:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ad:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02a0:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_0293:
																							if (14 < b)
																							{
																								while (15 >= b)
																								{
																									num = 148;
																									while (true)
																									{
																										if (num != 148)
																										{
																											if (num != 1129)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 122:
																												goto IL_0280;
																											case 45:
																												goto IL_0293;
																											case 16:
																												goto IL_02a0;
																											case 124:
																												goto IL_02ad;
																											case 74:
																												goto IL_02ba;
																											case 51:
																												goto IL_02ca;
																											case 65:
																												goto IL_02da;
																											case 50:
																											case 90:
																												goto IL_02f3;
																											case 30:
																												goto IL_02fe;
																											case 70:
																												goto IL_0311;
																											case 67:
																												goto IL_031f;
																											case 72:
																												goto IL_0332;
																											case 42:
																											case 59:
																												goto IL_033d;
																											case 52:
																											case 64:
																												goto IL_0355;
																											case 56:
																												goto IL_0360;
																											case 53:
																											case 60:
																												goto IL_036b;
																											case 22:
																												goto IL_0379;
																											case 43:
																												goto IL_0387;
																											case 10:
																											case 33:
																												goto IL_039a;
																											case 47:
																												goto IL_03ba;
																											case 77:
																												goto IL_03ca;
																											case 21:
																												goto IL_03d8;
																											case 96:
																											case 110:
																												goto IL_03eb;
																											case 86:
																											case 115:
																												goto IL_0407;
																											case 95:
																												goto IL_0415;
																											case 15:
																											case 116:
																												goto IL_0423;
																											case 5:
																												goto IL_044c;
																											case 119:
																												goto IL_045a;
																											case 7:
																											case 123:
																												goto IL_046d;
																											case 13:
																												goto IL_04ad;
																											case 19:
																												goto IL_04c1;
																											case 12:
																											case 128:
																												goto IL_04d4;
																											case 49:
																												goto IL_04e2;
																											case 71:
																											case 125:
																												goto IL_04ed;
																											case 91:
																												goto IL_04fb;
																											case 76:
																											case 83:
																												goto IL_050e;
																											case 93:
																												goto IL_051c;
																											case 24:
																												goto IL_053f;
																											case 82:
																												goto IL_0549;
																											case 32:
																												goto IL_0557;
																											case 129:
																												goto IL_056a;
																											case 26:
																											case 38:
																												goto IL_0578;
																											case 78:
																												goto IL_05da;
																											case 130:
																												goto IL_05f6;
																											case 35:
																												goto IL_0601;
																											case 121:
																												goto IL_060f;
																											case 61:
																											case 113:
																												goto IL_061d;
																											case 3:
																												goto IL_062b;
																											case 39:
																												goto IL_0643;
																											case 99:
																												goto IL_0651;
																											case 9:
																											case 111:
																												goto IL_066d;
																											case 131:
																												goto IL_06b1;
																											case 126:
																											case 127:
																												goto IL_06bc;
																											case 8:
																												goto IL_06fc;
																											case 63:
																												goto IL_0715;
																											case 20:
																												goto IL_0723;
																											case 0:
																											case 6:
																												goto IL_0731;
																											case 120:
																												goto IL_074a;
																											case 58:
																												goto IL_0758;
																											case 102:
																												goto IL_0766;
																											case 69:
																											case 133:
																												goto IL_0782;
																											case 103:
																												goto IL_07ab;
																											case 137:
																												goto IL_07c4;
																											case 1:
																												goto IL_07d2;
																											case 57:
																											case 98:
																												goto IL_07e0;
																											case 75:
																												goto IL_0824;
																											case 40:
																												goto IL_0838;
																											case 138:
																												goto IL_0848;
																											case 140:
																												goto IL_0858;
																											case 2:
																											case 4:
																											case 17:
																											case 18:
																											case 25:
																											case 44:
																											case 54:
																											case 62:
																											case 66:
																											case 73:
																											case 79:
																											case 80:
																											case 81:
																											case 92:
																											case 94:
																											case 101:
																											case 109:
																											case 112:
																											case 114:
																											case 132:
																											case 135:
																											case 136:
																											case 141:
																												goto end_IL_0280;
																											case 23:
																											case 27:
																											case 28:
																											case 29:
																											case 31:
																											case 37:
																											case 41:
																											case 48:
																											case 55:
																											case 68:
																											case 89:
																											case 100:
																											case 104:
																											case 105:
																											case 106:
																											case 118:
																											case 134:
																											case 139:
																												goto end_IL_026d;
																											case 46:
																												goto end_IL_0886;
																											case 88:
																												goto end_IL_0899;
																											case 36:
																												goto end_IL_08a3;
																											case 97:
																												goto end_IL_08ae;
																											case 34:
																											case 85:
																												goto end_IL_08be;
																											case 117:
																												goto end_IL_08d7;
																											case 11:
																											case 84:
																												goto end_IL_08e7;
																											case 107:
																												goto end_IL_08f7;
																											case 108:
																												goto end_IL_0910;
																											case 14:
																											case 87:
																												goto IL_092b;
																											}
																											continue;
																										}
																										if (15 <= b)
																										{
																										}
																										goto end_IL_0280;
																										continue;
																										end_IL_026d:
																										break;
																									}
																									goto end_IL_02ca;
																									continue;
																									end_IL_0280:
																									break;
																									IL_0280:;
																								}
																								break;
																							}
																							goto IL_0311;
																							IL_03eb:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_02ca;
																							IL_0311:
																							if (14 > b)
																							{
																								goto IL_031f;
																							}
																							goto IL_03eb;
																							IL_031f:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_056a;
																							IL_056a:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0578;
																							IL_0578:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05da;
																							IL_05da:
																							num6 -= 2;
																							num = 27;
																							goto end_IL_02ca;
																						}
																						break;
																					}
																					goto IL_02fe;
																					IL_0838:
																					num6--;
																					goto end_IL_02ca;
																					IL_02fe:
																					if (12 <= b)
																					{
																						goto IL_046d;
																					}
																					goto IL_04d4;
																					IL_046d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_04ad;
																					IL_04ad:
																					array[num6 - 2] = 0;
																					goto IL_04c1;
																					IL_04c1:
																					num6--;
																					goto end_IL_02ca;
																					IL_04d4:
																					if (10 >= b)
																					{
																						goto IL_04e2;
																					}
																					goto IL_07c4;
																					IL_04e2:
																					if (10 > b)
																					{
																						goto IL_04ed;
																					}
																					goto IL_050e;
																					IL_04ed:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_04fb;
																					IL_04fb:
																					if (9 > b)
																					{
																						break;
																					}
																					goto end_IL_02ca;
																					IL_050e:
																					array[num6] = 0;
																					goto IL_051c;
																					IL_051c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_053f;
																					IL_053f:
																					array2[num6] = null;
																					goto IL_0549;
																					IL_0549:
																					num6++;
																					goto IL_0557;
																					IL_0557:
																					ptr2 += 8;
																					goto end_IL_02ca;
																					IL_07c4:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_07d2;
																					IL_07d2:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_07e0;
																					IL_07e0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_0824;
																					IL_0824:
																					array[num6 - 2] = 0;
																					goto IL_0838;
																				}
																				break;
																			}
																			goto IL_0332;
																			IL_066d:
																			((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0848;
																			IL_0332:
																			if (8 <= b)
																			{
																				goto IL_033d;
																			}
																			goto IL_0355;
																			IL_033d:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02ca;
																			IL_0355:
																			if (4 >= b)
																			{
																				goto IL_0360;
																			}
																			goto IL_03ba;
																			IL_0360:
																			if (4 > b)
																			{
																				goto IL_036b;
																			}
																			goto IL_039a;
																			IL_036b:
																			if (2 < b)
																			{
																				goto IL_0379;
																			}
																			goto IL_06b1;
																			IL_0379:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0387;
																			IL_0387:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0782;
																			IL_0782:
																			array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																			goto IL_07ab;
																			IL_07ab:
																			array[num6 - 1] = 5;
																			goto end_IL_02ca;
																			IL_06b1:
																			if (2 <= b)
																			{
																				goto IL_06bc;
																			}
																			goto IL_0715;
																			IL_06bc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_06fc;
																			IL_06fc:
																			array[num6 - 2] = 0;
																			goto IL_0858;
																			IL_0858:
																			num6--;
																			goto end_IL_02ca;
																			IL_0715:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0723;
																			IL_0723:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0731;
																			IL_0731:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_074a;
																			IL_074a:
																			array[num6] = 0;
																			goto IL_0758;
																			IL_0758:
																			num6++;
																			goto IL_0766;
																			IL_0766:
																			ptr2 += 8;
																			num = 89;
																			goto end_IL_02ca;
																			IL_039a:
																			array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																			goto IL_03ca;
																			IL_03ca:
																			ptr2 += 8;
																			goto IL_03d8;
																			IL_03d8:
																			num6--;
																			goto end_IL_02ca;
																			IL_03ba:
																			if (6 < b)
																			{
																				goto IL_0407;
																			}
																			goto IL_05f6;
																			IL_0407:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0415;
																			IL_0415:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0423;
																			IL_0423:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_044c;
																			IL_044c:
																			ptr2 += 8;
																			goto IL_045a;
																			IL_045a:
																			num6--;
																			goto end_IL_02ca;
																			IL_05f6:
																			if (6 > b)
																			{
																				goto IL_0601;
																			}
																			num = 9;
																			goto IL_066d;
																			IL_0601:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_060f;
																			IL_060f:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_061d;
																			IL_061d:
																			array[num6] = 5;
																			goto IL_062b;
																			IL_062b:
																			array2[num6] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0643;
																			IL_0643:
																			num6++;
																			goto IL_0651;
																			IL_0651:
																			ptr2 += 8;
																			goto end_IL_02ca;
																			IL_0848:
																			num6 -= 3;
																			goto end_IL_02ca;
																		}
																		break;
																		IL_02ba:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02ca:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_092b;
												IL_092b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0886:
												break;
											}
											continue;
											end_IL_0899:
											break;
										}
										continue;
										end_IL_08a3:
										break;
									}
									continue;
									end_IL_08ae:
									break;
								}
								continue;
								end_IL_08be:
								break;
							}
							continue;
							end_IL_08d7:
							break;
						}
						continue;
						end_IL_08e7:
						break;
					}
					continue;
					end_IL_08f7:
					break;
				}
				continue;
				end_IL_0910:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2, int int_3)
	{
		int num = 74;
		int num4 = default(int);
		byte* ptr = default(byte*);
		int[] array3 = default(int[]);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 114;
						while (true)
						{
							if (num == 114)
							{
								goto IL_022b;
							}
							if (num != 1095)
							{
								goto IL_06a9;
							}
							switch (num)
							{
							case 48:
								goto end_IL_01d7;
							case 22:
							case 63:
								goto end_IL_01e7;
							case 73:
								goto end_IL_0200;
							case 74:
								goto end_IL_0210;
							case 31:
								goto IL_022b;
							case 69:
								goto IL_0239;
							case 79:
								goto IL_0247;
							case 34:
								goto IL_025a;
							case 53:
								goto IL_026d;
							case 91:
								goto IL_027f;
							case 1:
							case 3:
							case 7:
							case 38:
							case 65:
							case 77:
							case 80:
							case 86:
							case 96:
							case 99:
							case 100:
								goto IL_0287;
							case 71:
							case 83:
								goto IL_0297;
							case 28:
								goto IL_02a0;
							case 0:
								goto IL_02ae;
							case 21:
								goto IL_02bc;
							case 41:
								goto IL_02d5;
							case 107:
								goto IL_02e3;
							case 2:
							case 56:
								goto IL_02ee;
							case 54:
								goto IL_02fc;
							case 102:
								goto IL_031f;
							case 5:
								goto IL_0329;
							case 23:
								goto IL_0337;
							case 94:
								goto IL_034a;
							case 81:
								goto IL_0358;
							case 16:
								goto IL_0366;
							case 90:
								goto IL_0374;
							case 52:
							case 70:
								goto IL_0382;
							case 64:
								goto IL_03c2;
							case 97:
								goto IL_03d6;
							case 39:
								goto IL_03f2;
							case 24:
							case 85:
								goto IL_0400;
							case 20:
								goto IL_0429;
							case 17:
								goto IL_0437;
							case 50:
								goto IL_0453;
							case 27:
							case 78:
								goto IL_045e;
							case 57:
								goto IL_046c;
							case 45:
							case 61:
								goto IL_047f;
							case 14:
								goto IL_04bf;
							case 33:
								goto IL_04d3;
							case 67:
								goto IL_04e6;
							case 36:
							case 42:
								goto IL_04f4;
							case 59:
								goto IL_04ff;
							case 29:
							case 92:
								goto IL_050d;
							case 19:
								goto IL_054d;
							case 13:
								goto IL_0561;
							case 82:
							case 105:
								goto IL_0574;
							case 98:
								goto IL_0582;
							case 30:
							case 47:
								goto IL_0590;
							case 35:
								goto IL_05ac;
							case 66:
								goto IL_05ba;
							case 51:
								goto IL_05c8;
							case 8:
							case 12:
								goto IL_05d3;
							case 104:
								goto IL_0613;
							case 18:
								goto IL_0627;
							case 15:
								goto IL_0645;
							case 89:
								goto IL_0653;
							case 58:
								goto IL_0661;
							case 68:
							case 72:
								goto IL_0674;
							case 60:
								goto IL_068d;
							case 4:
								goto IL_069b;
							case 11:
								goto IL_06a9;
							case 6:
							case 9:
							case 10:
							case 25:
							case 26:
							case 32:
							case 40:
							case 43:
							case 44:
							case 46:
							case 49:
							case 55:
							case 62:
							case 75:
							case 76:
							case 84:
							case 87:
							case 93:
							case 95:
							case 101:
							case 103:
							case 106:
								goto IL_06bc;
							case 37:
							case 88:
								goto IL_06e4;
							}
							continue;
							IL_069b:
							num4++;
							goto IL_06a9;
							IL_06a9:
							ptr += 8;
							goto IL_0287;
							IL_022b:
							array3 = new int[5];
							goto IL_0239;
							IL_0239:
							array4 = new long[3];
							goto IL_0247;
							IL_0247:
							array3[0] = int_2;
							goto IL_025a;
							IL_025a:
							array3[1] = int_3;
							goto IL_026d;
							IL_026d:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCOMRedirectionSectionsetCustomErrorsMode.HashNameCspKeyContainerInfo);
							num = 91;
							goto IL_027f;
							IL_027f:
							ptr = ptr2;
							goto IL_0287;
							IL_0287:
							if (num5 != 1)
							{
								goto IL_0297;
							}
							goto IL_06e4;
							IL_06e4:
							return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							IL_0297:
							b = *ptr;
							goto IL_02a0;
							IL_02a0:
							ptr++;
							goto IL_02ae;
							IL_02ae:
							if (b >= 1)
							{
								goto IL_02bc;
							}
							goto IL_06bc;
							IL_02bc:
							if (b <= 9)
							{
								goto IL_02d5;
							}
							num = 25;
							goto IL_06bc;
							IL_06bc:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
							goto IL_0645;
							IL_02d5:
							if (5 >= b)
							{
								goto IL_02e3;
							}
							goto IL_04e6;
							IL_02e3:
							if (5 <= b)
							{
								goto IL_02ee;
							}
							goto IL_034a;
							IL_02ee:
							array[num4] = 0;
							goto IL_02fc;
							IL_02fc:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
							goto IL_031f;
							IL_031f:
							array2[num4] = null;
							goto IL_0329;
							IL_0329:
							num4++;
							goto IL_0337;
							IL_0337:
							ptr += 8;
							goto IL_0287;
							IL_034a:
							if (2 < b)
							{
								goto IL_0358;
							}
							num = 50;
							goto IL_0453;
							IL_0358:
							if (3 < b)
							{
								goto IL_0366;
							}
							num = 39;
							goto IL_03f2;
							IL_0366:
							if (4 >= b)
							{
								goto IL_0374;
							}
							goto IL_06bc;
							IL_0374:
							if (4 <= b)
							{
								goto IL_0382;
							}
							goto IL_06bc;
							IL_0382:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_03c2;
							IL_03c2:
							array[num4 - 2] = 0;
							goto IL_03d6;
							IL_03d6:
							num4--;
							goto IL_0287;
							IL_0653:
							num4++;
							goto IL_0661;
							IL_03f2:
							if (3 <= b)
							{
								goto IL_0400;
							}
							goto IL_06bc;
							IL_0400:
							ref int reference = ref array3[*(int*)(ptr + num3)];
							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0429;
							IL_0429:
							ptr += 8;
							goto IL_0437;
							IL_0437:
							num4--;
							goto IL_0287;
							IL_0645:
							array[num4] = 0;
							goto IL_0653;
							IL_0453:
							if (2 > b)
							{
								goto IL_045e;
							}
							goto IL_047f;
							IL_045e:
							if (1 >= b)
							{
								goto IL_046c;
							}
							goto IL_06bc;
							IL_046c:
							if (1 <= b)
							{
							}
							goto IL_06bc;
							IL_047f:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_04bf;
							IL_04bf:
							array[num4 - 2] = 0;
							goto IL_04d3;
							IL_04d3:
							num4--;
							goto IL_0287;
							IL_04e6:
							if (7 < b)
							{
								goto IL_04f4;
							}
							goto IL_05ac;
							IL_04f4:
							if (8 >= b)
							{
								goto IL_04ff;
							}
							goto IL_0574;
							IL_04ff:
							if (8 <= b)
							{
								goto IL_050d;
							}
							goto IL_06bc;
							IL_050d:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_054d;
							IL_054d:
							array[num4 - 2] = 0;
							goto IL_0561;
							IL_0561:
							num4--;
							goto IL_0287;
							IL_0574:
							if (9 >= b)
							{
								goto IL_0582;
							}
							goto IL_06bc;
							IL_0582:
							if (9 <= b)
							{
								goto IL_0590;
							}
							goto IL_06bc;
							IL_0590:
							byte* num6 = ptr;
							num5 = 1;
							ptr = num6 + -200;
							goto IL_0287;
							IL_05ac:
							if (7 > b)
							{
								goto IL_05ba;
							}
							goto IL_0674;
							IL_05ba:
							if (6 >= b)
							{
								goto IL_05c8;
							}
							goto IL_06bc;
							IL_05c8:
							if (6 <= b)
							{
								goto IL_05d3;
							}
							num = 6;
							goto IL_06bc;
							IL_05d3:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
							goto IL_0613;
							IL_0613:
							array[num4 - 2] = 0;
							goto IL_0627;
							IL_0627:
							num4--;
							goto IL_0287;
							IL_0661:
							ptr += 8;
							goto IL_0287;
							IL_0674:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
							goto IL_068d;
							IL_068d:
							array[num4] = 0;
							goto IL_069b;
							continue;
							end_IL_01d7:
							break;
						}
						continue;
						end_IL_01e7:
						break;
					}
					continue;
					end_IL_0200:
					break;
				}
				continue;
				end_IL_0210:
				break;
			}
		}
	}

	private static int smethod_4(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadOnlyDictionaryValueCollectionRequires.ExportNullReferenceException);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 76;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02fb:
														byte b = *ptr2;
														while (true)
														{
															IL_02eb:
															ptr2++;
															while (true)
															{
																IL_02db:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02be:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_02ae:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_029e:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_028e:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_027e:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														while (true)
																														{
																															IL_0233:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_0223:
																																ptr2 += 8;
																																while (true)
																																{
																																	IL_020a:
																																	num5--;
																																	num = 122;
																																	while (num != 122)
																																	{
																																		if (num != 1103)
																																		{
																																			goto end_IL_025e;
																																		}
																																		switch (num)
																																		{
																																		case 107:
																																			goto IL_020a;
																																		case 71:
																																			goto IL_0223;
																																		case 65:
																																		case 85:
																																			goto IL_0233;
																																		case 42:
																																			goto IL_025e;
																																		case 53:
																																		case 97:
																																			goto IL_026e;
																																		case 52:
																																		case 64:
																																			goto IL_027e;
																																		case 17:
																																			goto IL_028e;
																																		case 34:
																																		case 102:
																																			goto IL_029e;
																																		case 88:
																																			goto IL_02ae;
																																		case 5:
																																			goto IL_02be;
																																		case 9:
																																			goto IL_02cb;
																																		case 24:
																																			goto IL_02db;
																																		case 83:
																																			goto IL_02eb;
																																		case 37:
																																		case 90:
																																			goto IL_02fb;
																																		case 57:
																																		case 79:
																																			goto IL_030f;
																																		case 59:
																																			goto IL_031a;
																																		case 7:
																																			goto IL_0325;
																																		case 4:
																																		case 81:
																																			goto IL_0338;
																																		case 77:
																																			goto IL_0346;
																																		case 98:
																																			goto IL_0359;
																																		case 14:
																																		case 50:
																																			goto IL_0367;
																																		case 89:
																																			goto IL_03c9;
																																		case 19:
																																		case 109:
																																			goto IL_03dc;
																																		case 54:
																																		case 113:
																																			goto IL_03f8;
																																		case 23:
																																			goto IL_0403;
																																		case 20:
																																		case 66:
																																			goto IL_0411;
																																		case 75:
																																			goto IL_0451;
																																		case 95:
																																			goto IL_0465;
																																		case 100:
																																			goto IL_0478;
																																		case 46:
																																			goto IL_0486;
																																		case 26:
																																		case 114:
																																			goto IL_0494;
																																		case 36:
																																			goto IL_04b7;
																																		case 40:
																																			goto IL_04c5;
																																		case 74:
																																			goto IL_04d3;
																																		case 106:
																																			goto IL_04ef;
																																		case 67:
																																		case 94:
																																			goto IL_04fd;
																																		case 47:
																																			goto IL_0516;
																																		case 2:
																																			goto IL_0524;
																																		case 18:
																																			goto IL_0532;
																																		case 86:
																																		case 111:
																																			goto IL_0545;
																																		case 112:
																																			goto IL_055d;
																																		case 68:
																																			goto IL_0568;
																																		case 21:
																																			goto IL_057b;
																																		case 27:
																																			goto IL_0589;
																																		case 0:
																																		case 45:
																																			goto IL_0597;
																																		case 56:
																																			goto IL_05a5;
																																		case 55:
																																			goto IL_05c8;
																																		case 15:
																																			goto IL_05d2;
																																		case 91:
																																			goto IL_05e0;
																																		case 25:
																																		case 48:
																																			goto IL_05f9;
																																		case 115:
																																			goto IL_0639;
																																		case 41:
																																			goto IL_064d;
																																		case 3:
																																		case 10:
																																		case 12:
																																		case 22:
																																		case 28:
																																		case 30:
																																		case 31:
																																		case 32:
																																		case 33:
																																		case 38:
																																		case 44:
																																		case 49:
																																		case 60:
																																		case 63:
																																		case 70:
																																		case 72:
																																		case 73:
																																		case 93:
																																		case 99:
																																		case 101:
																																		case 104:
																																		case 110:
																																			goto end_IL_025e;
																																		case 6:
																																		case 11:
																																		case 13:
																																		case 16:
																																		case 29:
																																		case 35:
																																		case 39:
																																		case 51:
																																		case 58:
																																		case 69:
																																		case 76:
																																		case 80:
																																		case 103:
																																			goto end_IL_01f7;
																																		case 96:
																																			goto end_IL_0670;
																																		case 82:
																																			goto end_IL_0683;
																																		case 78:
																																			goto end_IL_0696;
																																		case 108:
																																			goto end_IL_06a1;
																																		case 84:
																																		case 87:
																																			goto end_IL_06b6;
																																		case 92:
																																			goto end_IL_06c6;
																																		case 1:
																																		case 105:
																																			goto end_IL_06d6;
																																		case 61:
																																			goto end_IL_06e6;
																																		case 62:
																																			goto end_IL_06f6;
																																		case 8:
																																		case 43:
																																			goto IL_0711;
																																		}
																																		continue;
																																		end_IL_01f7:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02db;
																														continue;
																														end_IL_025e:
																														break;
																														IL_025e:;
																													}
																													break;
																													IL_026e:;
																												}
																												break;
																											}
																											goto IL_04ef;
																											IL_0532:
																											ptr2 += 8;
																											goto end_IL_02db;
																											IL_04ef:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_04fd;
																											IL_04fd:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0516;
																											IL_0516:
																											array[num5] = 0;
																											goto IL_0524;
																											IL_0524:
																											num5++;
																											goto IL_0532;
																										}
																										break;
																									}
																									goto IL_0545;
																									IL_0545:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02db;
																								}
																								break;
																							}
																							goto IL_055d;
																							IL_05e0:
																							ptr2 += 8;
																							num = 51;
																							goto end_IL_02db;
																							IL_055d:
																							if (4 >= b)
																							{
																								goto IL_0568;
																							}
																							goto IL_057b;
																							IL_0568:
																							if (4 <= b)
																							{
																								goto end_IL_02db;
																							}
																							break;
																							IL_057b:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0589;
																							IL_0589:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0597;
																							IL_0597:
																							array[num5] = 0;
																							goto IL_05a5;
																							IL_05a5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05c8;
																							IL_05c8:
																							array2[num5] = null;
																							goto IL_05d2;
																							IL_05d2:
																							num5++;
																							goto IL_05e0;
																						}
																						break;
																					}
																					goto IL_05f9;
																					IL_064d:
																					num5--;
																					goto end_IL_02db;
																					IL_05f9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0639;
																					IL_0639:
																					array[num5 - 2] = 0;
																					goto IL_064d;
																				}
																				break;
																			}
																			num = 79;
																			goto IL_030f;
																			IL_04c5:
																			num5++;
																			goto IL_04d3;
																			IL_04d3:
																			ptr2 += 8;
																			num = 29;
																			goto end_IL_02db;
																			IL_030f:
																			if (9 < b)
																			{
																				goto IL_031a;
																			}
																			goto IL_0359;
																			IL_031a:
																			if (10 >= b)
																			{
																				goto IL_0325;
																			}
																			goto IL_0338;
																			IL_0325:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_03dc;
																			IL_03dc:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02db;
																			IL_0338:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0346;
																			IL_0346:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0359:
																			if (9 <= b)
																			{
																				goto IL_0367;
																			}
																			goto IL_03f8;
																			IL_0367:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03c9;
																			IL_03c9:
																			num5 -= 2;
																			goto end_IL_02db;
																			IL_03f8:
																			if (7 >= b)
																			{
																				goto IL_0403;
																			}
																			goto IL_0478;
																			IL_0403:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0411;
																			IL_0411:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0451;
																			IL_0451:
																			array[num5 - 2] = 0;
																			goto IL_0465;
																			IL_0465:
																			num5--;
																			goto end_IL_02db;
																			IL_0478:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0486;
																			IL_0486:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0494;
																			IL_0494:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04b7;
																			IL_04b7:
																			array[num5] = 0;
																			goto IL_04c5;
																		}
																		break;
																		IL_02cb:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02db:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0711;
												IL_0711:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0670:
												break;
											}
											continue;
											end_IL_0683:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06a1:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06d6:
						break;
					}
					continue;
					end_IL_06e6:
					break;
				}
				continue;
				end_IL_06f6:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 62;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 103;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IReflectHaveMonth.UnicodeClassTokenSource);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_028c:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_026c:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_025f:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_024f:
																								if (10 < b)
																								{
																									while (11 >= b)
																									{
																										num = 131;
																										while (true)
																										{
																											if (num != 131)
																											{
																												if (num != 1112)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 49:
																												case 99:
																													goto IL_023c;
																												case 86:
																												case 98:
																													goto IL_024f;
																												case 39:
																													goto IL_025f;
																												case 50:
																													goto IL_026c;
																												case 70:
																													goto IL_027c;
																												case 71:
																													goto IL_028c;
																												case 88:
																													goto end_IL_0229;
																												case 51:
																												case 90:
																													goto end_IL_029c;
																												case 77:
																													goto IL_02b7;
																												case 59:
																												case 83:
																													goto IL_02c2;
																												case 75:
																													goto IL_02d0;
																												case 17:
																													goto IL_02f4;
																												case 76:
																													goto IL_0302;
																												case 8:
																												case 89:
																													goto IL_0315;
																												case 20:
																												case 82:
																													goto IL_0320;
																												case 9:
																													goto IL_032e;
																												case 38:
																													goto IL_033e;
																												case 12:
																												case 110:
																													goto IL_034e;
																												case 118:
																													goto IL_038e;
																												case 109:
																													goto IL_03a2;
																												case 84:
																												case 120:
																													goto IL_03b5;
																												case 4:
																													goto IL_03ce;
																												case 29:
																													goto IL_03dc;
																												case 123:
																													goto IL_03ea;
																												case 52:
																												case 56:
																													goto IL_040b;
																												case 81:
																													goto IL_0430;
																												case 6:
																												case 69:
																													goto IL_043e;
																												case 13:
																													goto IL_0451;
																												case 11:
																												case 68:
																													goto IL_045c;
																												case 111:
																													goto IL_049c;
																												case 54:
																													goto IL_04b0;
																												case 124:
																													goto IL_04cc;
																												case 41:
																													goto IL_04da;
																												case 55:
																												case 108:
																													goto IL_04e8;
																												case 101:
																													goto IL_04f3;
																												case 113:
																													goto IL_0506;
																												case 30:
																													goto IL_0514;
																												case 46:
																												case 106:
																													goto IL_0522;
																												case 67:
																													goto IL_0562;
																												case 2:
																													goto IL_0576;
																												case 15:
																												case 31:
																													goto IL_0589;
																												case 40:
																													goto IL_05bb;
																												case 5:
																													goto IL_05c9;
																												case 116:
																													goto IL_05dc;
																												case 16:
																													goto IL_05e7;
																												case 7:
																												case 85:
																													goto IL_05f5;
																												case 122:
																													goto IL_0635;
																												case 78:
																													goto IL_0649;
																												case 53:
																													goto IL_065c;
																												case 24:
																													goto IL_0667;
																												case 79:
																												case 80:
																													goto IL_0672;
																												case 48:
																													goto IL_0680;
																												case 23:
																													goto IL_06a3;
																												case 45:
																													goto IL_06ad;
																												case 3:
																													goto IL_06bb;
																												case 0:
																												case 18:
																												case 22:
																												case 26:
																												case 32:
																												case 34:
																												case 42:
																												case 44:
																												case 58:
																												case 60:
																												case 63:
																												case 65:
																												case 72:
																												case 73:
																												case 87:
																												case 91:
																												case 93:
																												case 94:
																												case 97:
																												case 102:
																												case 104:
																												case 112:
																												case 117:
																												case 119:
																													goto end_IL_023c;
																												case 115:
																													goto IL_06ee;
																												case 36:
																													goto IL_06fc;
																												case 35:
																													goto IL_070a;
																												case 19:
																												case 21:
																												case 25:
																												case 28:
																												case 43:
																												case 47:
																												case 57:
																												case 64:
																												case 66:
																												case 95:
																												case 100:
																												case 107:
																												case 121:
																													goto end_IL_02ac;
																												case 10:
																													goto end_IL_0718;
																												case 114:
																													goto end_IL_072b;
																												case 37:
																													goto end_IL_0735;
																												case 103:
																													goto end_IL_0740;
																												case 14:
																													goto end_IL_0755;
																												case 1:
																												case 33:
																													goto end_IL_076a;
																												case 105:
																													goto end_IL_0783;
																												case 74:
																												case 96:
																													goto end_IL_0793;
																												case 61:
																													goto end_IL_07a3;
																												case 62:
																													goto end_IL_07b3;
																												case 27:
																												case 92:
																													goto IL_07ce;
																												}
																												continue;
																											}
																											if (11 > b)
																											{
																												goto end_IL_023c;
																											}
																											goto IL_040b;
																											IL_040b:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											num = 25;
																											goto end_IL_02ac;
																											continue;
																											end_IL_0229:
																											break;
																										}
																										goto end_IL_028c;
																										continue;
																										end_IL_023c:
																										break;
																										IL_023c:;
																									}
																									break;
																								}
																								goto IL_0430;
																								IL_043e:
																								num6--;
																								goto end_IL_02ac;
																								IL_0430:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_043e;
																							}
																							break;
																						}
																						goto IL_02b7;
																						IL_03ea:
																						ptr2 += 8;
																						goto end_IL_02ac;
																						IL_02b7:
																						if (9 <= b)
																						{
																							goto IL_02c2;
																						}
																						goto IL_0315;
																						IL_02c2:
																						array[num6] = 0;
																						goto IL_02d0;
																						IL_02d0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)GenericParEntryAssembly[*(int*)(ptr2 + num3)])();
																						goto IL_02f4;
																						IL_02f4:
																						num6++;
																						goto IL_0302;
																						IL_0302:
																						ptr2 += 8;
																						goto end_IL_02ac;
																						IL_0315:
																						if (7 < b)
																						{
																							goto IL_0320;
																						}
																						goto IL_033e;
																						IL_0320:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_032e;
																						IL_032e:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_034e;
																						IL_034e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_038e;
																						IL_038e:
																						array[num6 - 2] = 0;
																						goto IL_03a2;
																						IL_03a2:
																						num6--;
																						goto end_IL_02ac;
																						IL_033e:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03b5;
																						IL_03b5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_03ce;
																						IL_03ce:
																						array[num6] = 0;
																						goto IL_03dc;
																						IL_03dc:
																						num6++;
																						goto IL_03ea;
																					}
																					break;
																				}
																				goto IL_0451;
																				IL_06bb:
																				ptr2 += 8;
																				goto end_IL_02ac;
																				IL_0451:
																				if (6 <= b)
																				{
																					goto IL_045c;
																				}
																				goto IL_04cc;
																				IL_045c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_049c;
																				IL_049c:
																				array[num6 - 2] = 0;
																				goto IL_04b0;
																				IL_04b0:
																				num6--;
																				num = 66;
																				goto end_IL_02ac;
																				IL_04cc:
																				if (3 >= b)
																				{
																					goto IL_04da;
																				}
																				goto IL_05dc;
																				IL_04da:
																				if (3 > b)
																				{
																					goto IL_04e8;
																				}
																				goto IL_0589;
																				IL_04e8:
																				if (1 >= b)
																				{
																					goto IL_04f3;
																				}
																				goto IL_0506;
																				IL_04f3:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0506:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0514;
																				IL_0514:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0522;
																				IL_0522:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0562;
																				IL_0562:
																				array[num6 - 2] = 0;
																				goto IL_0576;
																				IL_0576:
																				num6--;
																				goto end_IL_02ac;
																				IL_0589:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 40;
																				goto IL_05bb;
																				IL_05bb:
																				ptr2 += 8;
																				goto IL_05c9;
																				IL_05c9:
																				num6--;
																				goto end_IL_02ac;
																				IL_05dc:
																				if (4 >= b)
																				{
																					goto IL_05e7;
																				}
																				goto IL_065c;
																				IL_05e7:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05f5;
																				IL_05f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0635;
																				IL_0635:
																				array[num6 - 2] = 0;
																				goto IL_0649;
																				IL_0649:
																				num6--;
																				goto end_IL_02ac;
																				IL_065c:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0667;
																				IL_0667:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0672;
																				IL_0672:
																				array[num6] = 0;
																				goto IL_0680;
																				IL_0680:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06a3;
																				IL_06a3:
																				array2[num6] = null;
																				goto IL_06ad;
																				IL_06ad:
																				num6++;
																				goto IL_06bb;
																			}
																			break;
																			IL_027c:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06ee;
																	IL_070a:
																	ptr2 += 8;
																	goto end_IL_02ac;
																	IL_06fc:
																	num6++;
																	goto IL_070a;
																	IL_06ee:
																	array[num6] = 0;
																	goto IL_06fc;
																	continue;
																	end_IL_028c:
																	break;
																}
																continue;
																end_IL_029c:
																break;
															}
															continue;
															end_IL_02ac:
															break;
														}
														continue;
													}
													goto IL_07ce;
													IL_07ce:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0718:
													break;
												}
												continue;
												end_IL_072b:
												break;
											}
											continue;
											end_IL_0735:
											break;
										}
										continue;
										end_IL_0740:
										break;
									}
									continue;
									end_IL_0755:
									break;
								}
								continue;
								end_IL_076a:
								break;
							}
							continue;
							end_IL_0783:
							break;
						}
						continue;
						end_IL_0793:
						break;
					}
					continue;
					end_IL_07a3:
					break;
				}
				continue;
				end_IL_07b3:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 45;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KeyCollectionNewPermissionElement.CDatagetReturnParameter);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 53;
														while (true)
														{
															ptr2++;
															num = 112;
															while (true)
															{
																if (num != 112)
																{
																	if (num == 1093)
																	{
																		switch (num)
																		{
																		case 53:
																			goto end_IL_01cf;
																		case 42:
																		case 83:
																			goto end_IL_01df;
																		case 13:
																			goto IL_021a;
																		case 78:
																			goto IL_0228;
																		case 3:
																			goto IL_0236;
																		case 39:
																		case 86:
																			goto IL_0241;
																		case 15:
																			goto IL_024f;
																		case 63:
																			goto IL_0272;
																		case 103:
																			goto IL_027c;
																		case 19:
																			goto IL_028a;
																		case 11:
																			goto IL_029d;
																		case 79:
																			goto IL_02a8;
																		case 31:
																		case 52:
																			goto IL_02b3;
																		case 47:
																			goto IL_02c1;
																		case 68:
																			goto IL_02d4;
																		case 30:
																		case 76:
																			goto IL_02e2;
																		case 10:
																			goto IL_0303;
																		case 58:
																		case 92:
																			goto IL_0317;
																		case 84:
																			goto IL_0340;
																		case 9:
																			goto IL_034e;
																		case 41:
																			goto IL_036a;
																		case 82:
																			goto IL_0378;
																		case 28:
																		case 101:
																			goto IL_0386;
																		case 29:
																			goto IL_039f;
																		case 17:
																			goto IL_03ad;
																		case 0:
																			goto IL_03bb;
																		case 50:
																			goto IL_03ce;
																		case 4:
																			goto IL_03dc;
																		case 5:
																			goto IL_03ea;
																		case 25:
																			goto IL_03f5;
																		case 72:
																		case 102:
																			goto IL_0403;
																		case 1:
																			goto IL_0443;
																		case 51:
																			goto IL_0457;
																		case 16:
																		case 48:
																			goto IL_046a;
																		case 105:
																			goto IL_0478;
																		case 46:
																		case 56:
																			goto IL_048f;
																		case 89:
																			goto IL_04b2;
																		case 99:
																			goto IL_04c0;
																		case 43:
																			goto IL_04ce;
																		case 77:
																		case 81:
																			goto IL_04e1;
																		case 55:
																			goto IL_0543;
																		case 64:
																		case 80:
																			goto IL_0553;
																		case 70:
																			goto IL_055e;
																		case 73:
																		case 94:
																			goto IL_0569;
																		case 34:
																		case 85:
																			goto IL_0582;
																		case 71:
																			goto IL_058d;
																		case 2:
																		case 8:
																		case 14:
																		case 20:
																		case 22:
																		case 26:
																		case 33:
																		case 36:
																		case 38:
																		case 40:
																		case 49:
																		case 61:
																		case 65:
																		case 66:
																		case 74:
																		case 75:
																		case 88:
																		case 90:
																		case 96:
																		case 98:
																		case 104:
																			goto IL_0598;
																		case 6:
																		case 7:
																		case 12:
																		case 18:
																		case 21:
																		case 23:
																		case 27:
																		case 57:
																		case 59:
																		case 62:
																		case 69:
																		case 87:
																		case 97:
																			goto end_IL_01f8;
																		case 100:
																			goto end_IL_05ab;
																		case 24:
																			goto end_IL_05be;
																		case 91:
																			goto end_IL_05c8;
																		case 32:
																			goto end_IL_05d3;
																		case 60:
																		case 95:
																			goto end_IL_05e8;
																		case 93:
																			goto end_IL_05f8;
																		case 35:
																		case 67:
																			goto end_IL_0608;
																		case 44:
																			goto end_IL_0618;
																		case 45:
																			goto end_IL_0628;
																		case 37:
																		case 54:
																			goto IL_0643;
																		}
																		continue;
																	}
																}
																else if (b >= 1)
																{
																	goto IL_021a;
																}
																goto IL_0598;
																IL_0553:
																if (9 >= b)
																{
																	goto IL_055e;
																}
																goto IL_0582;
																IL_0569:
																byte* num5 = ptr2;
																num4 = 1;
																ptr2 = num5 + -200;
																goto end_IL_01f8;
																IL_055e:
																if (9 <= b)
																{
																	goto IL_0569;
																}
																goto IL_0598;
																IL_021a:
																if (b <= 10)
																{
																	goto IL_0228;
																}
																goto IL_0598;
																IL_0228:
																if (5 >= b)
																{
																	goto IL_0236;
																}
																goto IL_03ce;
																IL_0236:
																if (5 <= b)
																{
																	goto IL_0241;
																}
																goto IL_029d;
																IL_0241:
																array[num6] = 0;
																goto IL_024f;
																IL_024f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0272;
																IL_0272:
																array2[num6] = null;
																goto IL_027c;
																IL_027c:
																num6++;
																goto IL_028a;
																IL_028a:
																ptr2 += 8;
																goto end_IL_01f8;
																IL_029d:
																if (2 < b)
																{
																	goto IL_02a8;
																}
																num = 10;
																goto IL_0303;
																IL_02a8:
																if (3 < b)
																{
																	goto IL_02b3;
																}
																goto IL_02d4;
																IL_02b3:
																if (4 >= b)
																{
																	goto IL_02c1;
																}
																goto IL_0598;
																IL_02c1:
																if (4 <= b)
																{
																	goto end_IL_01f8;
																}
																goto IL_0598;
																IL_02d4:
																if (3 <= b)
																{
																	goto IL_02e2;
																}
																goto IL_0598;
																IL_02e2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01f8;
																IL_0582:
																if (10 >= b)
																{
																	goto IL_058d;
																}
																goto IL_0598;
																IL_0303:
																if (2 <= b)
																{
																	num = 92;
																	goto IL_0317;
																}
																goto IL_036a;
																IL_058d:
																if (10 > b)
																{
																}
																goto IL_0598;
																IL_0317:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0340;
																IL_0340:
																ptr2 += 8;
																goto IL_034e;
																IL_034e:
																num6--;
																num = 7;
																goto end_IL_01f8;
																IL_036a:
																if (1 >= b)
																{
																	goto IL_0378;
																}
																goto IL_0598;
																IL_0378:
																if (1 <= b)
																{
																	goto IL_0386;
																}
																goto IL_0598;
																IL_0386:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																goto IL_039f;
																IL_039f:
																array[num6] = 0;
																goto IL_03ad;
																IL_03ad:
																num6++;
																goto IL_03bb;
																IL_03bb:
																ptr2 += 8;
																goto end_IL_01f8;
																IL_03ce:
																if (8 >= b)
																{
																	goto IL_03dc;
																}
																goto IL_0553;
																IL_03dc:
																if (8 > b)
																{
																	goto IL_03ea;
																}
																goto IL_04e1;
																IL_03ea:
																if (6 >= b)
																{
																	goto IL_03f5;
																}
																goto IL_046a;
																IL_03f5:
																if (6 <= b)
																{
																	goto IL_0403;
																}
																goto IL_0598;
																IL_0403:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																goto IL_0443;
																IL_0443:
																array[num6 - 2] = 0;
																goto IL_0457;
																IL_0457:
																num6--;
																goto end_IL_01f8;
																IL_046a:
																if (7 >= b)
																{
																	goto IL_0478;
																}
																goto IL_0598;
																IL_0478:
																if (7 <= b)
																{
																	num = 46;
																	goto IL_048f;
																}
																goto IL_0598;
																IL_0598:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01f8;
																IL_048f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04b2;
																IL_04b2:
																array[num6] = 0;
																goto IL_04c0;
																IL_04c0:
																num6++;
																goto IL_04ce;
																IL_04ce:
																ptr2 += 8;
																goto end_IL_01f8;
																IL_04e1:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0543;
																IL_0543:
																num6 -= 2;
																goto end_IL_01f8;
																continue;
																end_IL_01cf:
																break;
															}
															continue;
															end_IL_01df:
															break;
														}
														continue;
														end_IL_01f8:
														break;
													}
													continue;
												}
												goto IL_0643;
												IL_0643:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05ab:
												break;
											}
											continue;
											end_IL_05be:
											break;
										}
										continue;
										end_IL_05c8:
										break;
									}
									continue;
									end_IL_05d3:
									break;
								}
								continue;
								end_IL_05e8:
								break;
							}
							continue;
							end_IL_05f8:
							break;
						}
						continue;
						end_IL_0608:
						break;
					}
					continue;
					end_IL_0618:
					break;
				}
				continue;
				end_IL_0628:
				break;
			}
		}
	}

	static Class161()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 11;
			while (true)
			{
				if (num != 11)
				{
					if (num == 992)
					{
						switch (num)
						{
						default:
							continue;
						case 2:
							break;
						case 0:
							return;
						case 1:
							return;
						case 3:
							return;
						case 4:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
