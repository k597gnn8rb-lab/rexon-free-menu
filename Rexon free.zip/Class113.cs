using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Yoyo Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns yoyos.", false, 1, ModType.const_0, false)]
internal class Class113 : Class93
{
	private static int int_3;

	private static int int_4;

	private static float float_0;

	private static int int_5;

	private static double double_1;

	private static double double_2;

	private static int int_6;

	private static IntPtr[] ChangePermissionsLoaderInformation;

	private static IntPtr[] SerializationInvalidOnDeserUtcDateTime;

	private static IntPtr[] EnablePropertyLocalFindAndPop;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0391, IL_03a4, IL_03b7, IL_03c7, IL_03d4, IL_03e4, IL_03f4, IL_0404, IL_0414, IL_041f, IL_042d, IL_0436, IL_0441, IL_044c, IL_0475, IL_0483, IL_048c, IL_049c, IL_04af, IL_04c2, IL_04d0, IL_04ed, IL_053c, IL_0546, IL_0573, IL_0587, IL_0595, IL_05a8, IL_05bb, IL_05c9, IL_05d7, IL_05ef, IL_060d, IL_0631, IL_0649, IL_0665, IL_0678, IL_0688, IL_069b, IL_06b3, IL_06c6, IL_06f8, IL_071a, IL_0728, IL_0736, IL_0752, IL_0760, IL_076b, IL_0779, IL_07c0, IL_07d3, IL_07e3, IL_0801, IL_080f, IL_0823, IL_0864, IL_0877, IL_088a, IL_0898, IL_08a6, IL_08b9, IL_08c7, IL_08df, IL_08ed, IL_0901, IL_095e, IL_096c, IL_097f, IL_098d, IL_099b, IL_09a6, IL_09b4, IL_09f4, IL_0a11, IL_0a24, IL_0a32, IL_0a40, IL_0aa2, IL_0abe, IL_0ac9, IL_0adc, IL_0aea, IL_0af8, IL_0b06, IL_0b46, IL_0b5a, IL_0b6d, IL_0b7b, IL_0b84, IL_0bc4, IL_0bd8, IL_0beb, IL_0bf6, IL_0c36, IL_0c53, IL_0c66, IL_0c74, IL_0c7f, IL_0c8d, IL_0cb6, IL_0cc4, IL_0cd7, IL_0ce5, IL_0cf3, IL_0d01, IL_0d24, IL_0d2e, IL_0d3c, IL_0d58, IL_0d63, IL_0d6e, IL_0d7b, IL_0dbb, IL_0dcf, IL_0ddf, IL_0df8, IL_0e06, IL_0e14, IL_0e22, IL_0e35, IL_0e3f, IL_0e4a, IL_0e63, IL_0e73, IL_0e8c, IL_0e9c, IL_0eac, IL_0ebc, IL_0ecc, IL_0edc, IL_0ef7 are reachable both inside and outside the pinned region starting at IL_0ef1. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 112;
			int num5 = default(int);
			int num8 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num6;
				int num7;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef30 = default(int);
				ref int reference = ref __rxRef30;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0edc:
						num2 = 1;
						while (true)
						{
							IL_0ecc:
							num3 = num2 * 4;
							while (true)
							{
								IL_0ebc:
								num4 = num2 * 8;
								while (true)
								{
									IL_0eac:
									array2 = new byte[4];
									while (true)
									{
										IL_0e9c:
										array3 = new object[4];
										while (true)
										{
											IL_0e8c:
											array4 = new int[4];
											while (true)
											{
												IL_0e73:
												array5 = new int[6];
												num = 58;
												while (true)
												{
													IL_0e63:
													array6 = new long[4];
													while (true)
													{
														IL_0e4a:
														array7 = new object[7];
														num = 104;
														while (true)
														{
															IL_0e3f:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsGenericTypeDefinitionDefaultGrantSet.CurrentStateSid);
															while (true)
															{
																IL_0e35:
																ptr2 = ptr;
																while (true)
																{
																	IL_0e22:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0414:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0404:
																				ptr2++;
																				while (true)
																				{
																					IL_03f4:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_03d4:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_03c7:
																										if (17 < b)
																										{
																											while (true)
																											{
																												IL_03b7:
																												if (20 < b)
																												{
																													while (true)
																													{
																														IL_03a4:
																														if (21 >= b)
																														{
																															num = 221;
																															while (true)
																															{
																																if (num != 221)
																																{
																																	if (num != 1202)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 112:
																																		break;
																																	default:
																																		continue;
																																	case 149:
																																		goto IL_03a4;
																																	case 45:
																																	case 206:
																																		goto IL_03b7;
																																	case 106:
																																	case 138:
																																		goto IL_03c7;
																																	case 38:
																																		goto IL_03d4;
																																	case 157:
																																		goto IL_03e4;
																																	case 130:
																																		goto IL_03f4;
																																	case 68:
																																		goto IL_0404;
																																	case 116:
																																	case 133:
																																		goto IL_0414;
																																	case 33:
																																		goto IL_041f;
																																	case 63:
																																	case 139:
																																		goto IL_0436;
																																	case 47:
																																		goto IL_0441;
																																	case 55:
																																	case 60:
																																		goto IL_044c;
																																	case 117:
																																		goto IL_0475;
																																	case 120:
																																	case 132:
																																		goto IL_048c;
																																	case 39:
																																		goto IL_049c;
																																	case 142:
																																		goto IL_04af;
																																	case 150:
																																		goto IL_04c2;
																																	case 2:
																																	case 8:
																																		goto IL_04d0;
																																	case 0:
																																		goto IL_0587;
																																	case 20:
																																		goto IL_0595;
																																	case 72:
																																	case 161:
																																		goto IL_05a8;
																																	case 99:
																																	case 169:
																																		goto IL_05bb;
																																	case 10:
																																		goto IL_05c9;
																																	case 5:
																																	case 28:
																																		goto IL_05d7;
																																	case 86:
																																		goto IL_05ef;
																																	case 37:
																																		goto IL_060d;
																																	case 108:
																																		goto IL_0631;
																																	case 75:
																																		goto IL_0649;
																																	case 172:
																																		goto IL_0665;
																																	case 174:
																																		goto IL_0678;
																																	case 184:
																																		goto IL_0688;
																																	case 186:
																																		goto IL_069b;
																																	case 26:
																																		goto IL_06b3;
																																	case 153:
																																	case 187:
																																		goto IL_06c6;
																																	case 113:
																																		goto IL_06f8;
																																	case 194:
																																		goto IL_071a;
																																	case 141:
																																		goto IL_0728;
																																	case 73:
																																	case 163:
																																		goto IL_0736;
																																	case 196:
																																		goto IL_0752;
																																	case 93:
																																	case 110:
																																		goto IL_0760;
																																	case 126:
																																		goto IL_076b;
																																	case 82:
																																	case 188:
																																		goto IL_0779;
																																	case 78:
																																		goto IL_07c0;
																																	case 13:
																																		goto IL_07d3;
																																	case 175:
																																	case 195:
																																		goto IL_07e3;
																																	case 205:
																																		goto IL_0801;
																																	case 56:
																																	case 57:
																																		goto IL_080f;
																																	case 146:
																																		goto IL_0823;
																																	case 94:
																																		goto IL_0864;
																																	case 208:
																																		goto IL_0877;
																																	case 211:
																																		goto IL_088a;
																																	case 44:
																																		goto IL_0898;
																																	case 59:
																																		goto IL_08a6;
																																	case 22:
																																	case 167:
																																		goto IL_08c7;
																																	case 125:
																																		goto IL_08df;
																																	case 6:
																																	case 209:
																																		goto IL_08ed;
																																	case 48:
																																		goto IL_0901;
																																	case 18:
																																		goto IL_095e;
																																	case 95:
																																		goto IL_096c;
																																	case 210:
																																		goto IL_097f;
																																	case 127:
																																	case 204:
																																		goto IL_098d;
																																	case 137:
																																	case 162:
																																		goto IL_099b;
																																	case 88:
																																		goto IL_09a6;
																																	case 89:
																																	case 123:
																																		goto IL_09b4;
																																	case 83:
																																		goto IL_09f4;
																																	case 35:
																																		goto IL_0a11;
																																	case 14:
																																		goto IL_0a24;
																																	case 199:
																																		goto IL_0a32;
																																	case 156:
																																	case 192:
																																		goto IL_0a40;
																																	case 84:
																																		goto IL_0aa2;
																																	case 30:
																																		goto IL_0abe;
																																	case 168:
																																	case 191:
																																		goto IL_0ac9;
																																	case 102:
																																		goto IL_0adc;
																																	case 3:
																																	case 143:
																																		goto IL_0aea;
																																	case 42:
																																		goto IL_0af8;
																																	case 12:
																																	case 178:
																																		goto IL_0b06;
																																	case 43:
																																		goto IL_0b46;
																																	case 67:
																																		goto IL_0b5a;
																																	case 180:
																																		goto IL_0b6d;
																																	case 50:
																																	case 171:
																																		goto IL_0b84;
																																	case 34:
																																		goto IL_0bc4;
																																	case 190:
																																		goto IL_0bd8;
																																	case 185:
																																		goto IL_0beb;
																																	case 23:
																																	case 201:
																																		goto IL_0bf6;
																																	case 179:
																																		goto IL_0c36;
																																	case 54:
																																		goto IL_0c53;
																																	case 81:
																																		goto IL_0c66;
																																	case 66:
																																	case 124:
																																		goto IL_0c74;
																																	case 41:
																																		goto IL_0c7f;
																																	case 70:
																																	case 144:
																																		goto IL_0c8d;
																																	case 25:
																																		goto IL_0cb6;
																																	case 154:
																																		goto IL_0cc4;
																																	case 182:
																																		goto IL_0cd7;
																																	case 69:
																																		goto IL_0ce5;
																																	case 40:
																																	case 65:
																																		goto IL_0cf3;
																																	case 193:
																																		goto IL_0d01;
																																	case 98:
																																		goto IL_0d24;
																																	case 159:
																																		goto IL_0d2e;
																																	case 49:
																																		goto IL_0d3c;
																																	case 151:
																																		goto IL_0d58;
																																	case 101:
																																	case 115:
																																		goto IL_0d63;
																																	case 1:
																																		goto IL_0d6e;
																																	case 7:
																																	case 158:
																																		goto IL_0d7b;
																																	case 85:
																																		goto IL_0dbb;
																																	case 15:
																																		goto IL_0dcf;
																																	case 4:
																																	case 9:
																																	case 19:
																																	case 21:
																																	case 29:
																																	case 32:
																																	case 36:
																																	case 46:
																																	case 51:
																																	case 61:
																																	case 62:
																																	case 74:
																																	case 77:
																																	case 79:
																																	case 80:
																																	case 87:
																																	case 90:
																																	case 92:
																																	case 97:
																																	case 103:
																																	case 119:
																																	case 121:
																																	case 128:
																																	case 131:
																																	case 135:
																																	case 145:
																																	case 147:
																																	case 148:
																																	case 152:
																																	case 155:
																																	case 170:
																																	case 173:
																																	case 181:
																																	case 189:
																																	case 212:
																																	case 214:
																																		goto end_IL_0391;
																																	case 53:
																																		goto IL_0df8;
																																	case 198:
																																		goto IL_0e06;
																																	case 107:
																																		goto IL_0e14;
																																	case 11:
																																	case 16:
																																	case 17:
																																	case 27:
																																	case 31:
																																	case 64:
																																	case 71:
																																	case 91:
																																	case 114:
																																	case 118:
																																	case 122:
																																	case 129:
																																	case 134:
																																	case 136:
																																	case 140:
																																	case 160:
																																	case 164:
																																	case 165:
																																	case 177:
																																	case 183:
																																	case 197:
																																	case 200:
																																	case 202:
																																	case 203:
																																	case 213:
																																		goto IL_0e22;
																																	case 166:
																																		goto IL_0e35;
																																	case 104:
																																		goto IL_0e3f;
																																	case 207:
																																		goto IL_0e4a;
																																	case 58:
																																		goto IL_0e63;
																																	case 24:
																																		goto IL_0e73;
																																	case 100:
																																		goto IL_0e8c;
																																	case 52:
																																		goto IL_0e9c;
																																	case 96:
																																		goto IL_0eac;
																																	case 105:
																																		goto IL_0ebc;
																																	case 176:
																																		goto IL_0ecc;
																																	case 111:
																																		goto IL_0edc;
																																	case 76:
																																	case 109:
																																		goto IL_0ef7;
																																	}
																																	goto end_IL_03f4;
																																}
																																if (21 > b)
																																{
																																	break;
																																}
																																goto IL_08c7;
																																IL_08c7:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																goto IL_0e22;
																																continue;
																																end_IL_0391:
																																break;
																															}
																															break;
																														}
																														goto IL_071a;
																														IL_0728:
																														if (22 > b)
																														{
																															break;
																														}
																														goto IL_0736;
																														IL_0736:
																														num6 = ptr2;
																														num7 = -200;
																														num5 = 1;
																														ptr2 = num6 + num7;
																														goto IL_0e22;
																														IL_071a:
																														if (22 < b)
																														{
																															break;
																														}
																														goto IL_0728;
																													}
																													break;
																												}
																												goto IL_0752;
																												IL_08a6:
																												ptr2 += 16;
																												goto IL_0e22;
																												IL_0752:
																												if (20 > b)
																												{
																													goto IL_0760;
																												}
																												goto IL_07e3;
																												IL_0760:
																												if (18 >= b)
																												{
																													goto IL_076b;
																												}
																												goto IL_07d3;
																												IL_076b:
																												if (18 > b)
																												{
																													break;
																												}
																												goto IL_0779;
																												IL_0779:
																												((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
																												num = 78;
																												goto IL_07c0;
																												IL_07c0:
																												num8 -= 3;
																												goto IL_0e22;
																												IL_07d3:
																												if (19 < b)
																												{
																													break;
																												}
																												goto IL_0801;
																												IL_0801:
																												if (19 > b)
																												{
																													break;
																												}
																												goto IL_080f;
																												IL_080f:
																												array2[num8 - 1] = 5;
																												goto IL_0823;
																												IL_0823:
																												array3[num8 - 1] = ((delegate*<string[], string>)ChangePermissionsLoaderInformation[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
																												num = 94;
																												goto IL_0864;
																												IL_0864:
																												ptr2 += 8;
																												goto IL_0e22;
																												IL_07e3:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
																												goto IL_088a;
																												IL_088a:
																												array2[num8] = 1;
																												goto IL_0898;
																												IL_0898:
																												num8++;
																												goto IL_08a6;
																											}
																											break;
																										}
																										goto IL_041f;
																										IL_06c6:
																										array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
																										num = 113;
																										goto IL_06f8;
																										IL_041f:
																										if (17 > b)
																										{
																											num = 63;
																											goto IL_0436;
																										}
																										goto IL_05a8;
																										IL_06f8:
																										array2[num8 - 1] = 5;
																										num = 140;
																										goto IL_0e22;
																										IL_0436:
																										if (14 >= b)
																										{
																											goto IL_0441;
																										}
																										goto IL_049c;
																										IL_0441:
																										if (14 <= b)
																										{
																											goto IL_044c;
																										}
																										goto IL_0475;
																										IL_044c:
																										array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
																										num = 142;
																										goto IL_04af;
																										IL_04af:
																										ptr2 += 8;
																										goto IL_0665;
																										IL_0665:
																										num8--;
																										goto IL_0e22;
																										IL_0475:
																										if (12 < b)
																										{
																											num = 132;
																											goto IL_048c;
																										}
																										goto IL_0688;
																										IL_05a8:
																										array2[num8] = 5;
																										goto IL_069b;
																										IL_048c:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_04c2;
																										IL_04c2:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_04d0;
																										IL_04d0:
																										array8 = array3;
																										num9 = num8;
																										if (array == null)
																										{
																											goto IL_04df;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0587;
																										IL_069b:
																										array3[num8] = array7[*(int*)(ptr2 + num3)];
																										goto IL_06b3;
																										IL_06b3:
																										num8++;
																										goto IL_0877;
																										IL_0877:
																										ptr2 += 8;
																										goto IL_0e22;
																										IL_0587:
																										array2[num8] = 5;
																										goto IL_0595;
																										IL_0595:
																										num8++;
																										goto IL_0e22;
																										IL_0688:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0e22;
																										IL_049c:
																										if (15 < b)
																										{
																											goto IL_05bb;
																										}
																										goto IL_0678;
																										IL_05bb:
																										if (16 < b)
																										{
																											break;
																										}
																										goto IL_05c9;
																										IL_05c9:
																										if (16 > b)
																										{
																											break;
																										}
																										goto IL_05d7;
																										IL_05d7:
																										array2[num8] = array2[num8 - 1];
																										goto IL_05ef;
																										IL_05ef:
																										array4[num8 - 0] = array4[num8 - 1];
																										goto IL_060d;
																										IL_060d:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																										goto IL_0631;
																										IL_0631:
																										array3[num8] = array3[num8 - 1];
																										goto IL_0649;
																										IL_0649:
																										num8++;
																										num = 27;
																										goto IL_0e22;
																										IL_0678:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_06c6;
																									}
																									break;
																								}
																								goto IL_08df;
																								IL_0dbb:
																								array2[num8 - 2] = 0;
																								goto IL_0dcf;
																								IL_08df:
																								if (11 <= b)
																								{
																									goto IL_08ed;
																								}
																								goto IL_097f;
																								IL_08ed:
																								array2[num8 - 2] = 0;
																								goto IL_0901;
																								IL_0901:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = ((delegate*<int, int, int>)ChangePermissionsLoaderInformation[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]));
																								num = 18;
																								goto IL_095e;
																								IL_095e:
																								num8--;
																								goto IL_096c;
																								IL_096c:
																								ptr2 += 8;
																								goto IL_0e22;
																								IL_097f:
																								if (5 < b)
																								{
																									goto IL_098d;
																								}
																								goto IL_0beb;
																								IL_098d:
																								if (8 < b)
																								{
																									goto IL_099b;
																								}
																								goto IL_0abe;
																								IL_099b:
																								if (9 >= b)
																								{
																									goto IL_09a6;
																								}
																								goto IL_0a24;
																								IL_09a6:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_09b4;
																								IL_09b4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_09f4;
																								IL_09f4:
																								array2[num8 - 2] = 0;
																								num = 35;
																								goto IL_0a11;
																								IL_0a11:
																								num8--;
																								goto IL_0e22;
																								IL_0a24:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0a32;
																								IL_0a32:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0a40;
																								IL_0a40:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0aa2;
																								IL_0aa2:
																								num8 -= 2;
																								num = 160;
																								goto IL_0e22;
																								IL_0abe:
																								if (8 <= b)
																								{
																									goto IL_0ac9;
																								}
																								goto IL_0adc;
																								IL_0ac9:
																								num8--;
																								goto IL_0e22;
																								IL_0adc:
																								if (6 < b)
																								{
																									goto IL_0aea;
																								}
																								goto IL_0b6d;
																								IL_0aea:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0af8;
																								IL_0af8:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0b06;
																								IL_0b06:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0b46;
																								IL_0b46:
																								array2[num8 - 2] = 0;
																								goto IL_0b5a;
																								IL_0b5a:
																								num8--;
																								goto IL_0e22;
																								IL_0b6d:
																								if (6 > b)
																								{
																									break;
																								}
																								num = 50;
																								goto IL_0b84;
																								IL_0dcf:
																								num8--;
																								goto IL_0e22;
																								IL_0b84:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0bc4;
																								IL_0bc4:
																								array2[num8 - 2] = 0;
																								goto IL_0bd8;
																								IL_0bd8:
																								num8--;
																								goto IL_0e22;
																								IL_0beb:
																								if (5 <= b)
																								{
																									goto IL_0bf6;
																								}
																								goto IL_0c66;
																								IL_0bf6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0c36;
																								IL_0c36:
																								array2[num8 - 2] = 0;
																								num = 54;
																								goto IL_0c53;
																								IL_0c53:
																								num8--;
																								goto IL_0e22;
																								IL_0c66:
																								if (2 < b)
																								{
																									goto IL_0c74;
																								}
																								goto IL_0d58;
																								IL_0c74:
																								if (3 >= b)
																								{
																									goto IL_0c7f;
																								}
																								goto IL_0cd7;
																								IL_0c7f:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0c8d;
																								IL_0c8d:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0cb6;
																								IL_0cb6:
																								ptr2 += 8;
																								goto IL_0cc4;
																								IL_0cc4:
																								num8--;
																								goto IL_0e22;
																								IL_0cd7:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0ce5;
																								IL_0ce5:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0cf3;
																								IL_0cf3:
																								array2[num8] = 0;
																								goto IL_0d01;
																								IL_0d01:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_0d24;
																								IL_0d24:
																								array3[num8] = null;
																								goto IL_0d2e;
																								IL_0d2e:
																								num8++;
																								goto IL_0d3c;
																								IL_0d3c:
																								ptr2 += 8;
																								num = 122;
																								goto IL_0e22;
																								IL_0d58:
																								if (2 > b)
																								{
																									goto IL_0d63;
																								}
																								goto IL_0d7b;
																								IL_0d63:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0d6e;
																								IL_0d6e:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0d7b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0dbb;
																							}
																							break;
																							IL_03e4:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
																					goto IL_0df8;
																					IL_0e14:
																					ptr2 += 8;
																					goto IL_0e22;
																					IL_0e06:
																					num8++;
																					goto IL_0e14;
																					IL_0df8:
																					array2[num8] = 0;
																					goto IL_0e06;
																					continue;
																					end_IL_03f4:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0ef7;
																	IL_0ef7:
																	return (string)array3[num8 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_04df:
				while (true)
				{
					IL_04df_2:
					array = new byte[4];
					while (true)
					{
						IL_04ed:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num8] = 5;
							while (true)
							{
								IL_0595_2:
								num8++;
								while (true)
								{
									IL_0e22_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_03f4_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_03d4_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_03c7_2:
																		if (17 < b)
																		{
																			while (true)
																			{
																				IL_03b7_2:
																				if (20 < b)
																				{
																					while (true)
																					{
																						IL_03a4_2:
																						if (21 >= b)
																						{
																							num = 221;
																							while (true)
																							{
																								if (num != 221)
																								{
																									if (num != 1202)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 149:
																										goto IL_03a4_2;
																									case 45:
																									case 206:
																										goto IL_03b7_2;
																									case 106:
																									case 138:
																										goto IL_03c7_2;
																									case 38:
																										goto IL_03d4_2;
																									case 157:
																										goto IL_03e4_2;
																									case 130:
																										goto IL_03f4_2;
																									case 68:
																										goto end_IL_03f4_2;
																									case 116:
																									case 133:
																										goto end_IL_0404;
																									case 33:
																										goto IL_041f_2;
																									case 63:
																									case 139:
																										goto IL_0436_2;
																									case 47:
																										goto IL_0441_2;
																									case 55:
																									case 60:
																										goto IL_044c_2;
																									case 117:
																										goto IL_0475_2;
																									case 120:
																									case 132:
																										goto IL_048c_2;
																									case 39:
																										goto IL_049c_2;
																									case 142:
																										goto IL_04af_2;
																									case 150:
																										goto IL_04c2_2;
																									case 2:
																									case 8:
																										goto IL_04d0_2;
																									case 0:
																										goto end_IL_0414;
																									case 20:
																										goto IL_0595_2;
																									case 72:
																									case 161:
																										goto IL_05a8_2;
																									case 99:
																									case 169:
																										goto IL_05bb_2;
																									case 10:
																										goto IL_05c9_2;
																									case 5:
																									case 28:
																										goto IL_05d7_2;
																									case 86:
																										goto IL_05ef_2;
																									case 37:
																										goto IL_060d_2;
																									case 108:
																										goto IL_0631_2;
																									case 75:
																										goto IL_0649_2;
																									case 172:
																										goto IL_0665_2;
																									case 174:
																										goto IL_0678_2;
																									case 184:
																										goto IL_0688_2;
																									case 186:
																										goto IL_069b_2;
																									case 26:
																										goto IL_06b3_2;
																									case 153:
																									case 187:
																										goto IL_06c6_2;
																									case 113:
																										goto IL_06f8_2;
																									case 194:
																										goto IL_071a_2;
																									case 141:
																										goto IL_0728_2;
																									case 73:
																									case 163:
																										goto IL_0736_2;
																									case 196:
																										goto IL_0752_2;
																									case 93:
																									case 110:
																										goto IL_0760_2;
																									case 126:
																										goto IL_076b_2;
																									case 82:
																									case 188:
																										goto IL_0779_2;
																									case 78:
																										goto IL_07c0_2;
																									case 13:
																										goto IL_07d3_2;
																									case 175:
																									case 195:
																										goto IL_07e3_2;
																									case 205:
																										goto IL_0801_2;
																									case 56:
																									case 57:
																										goto IL_080f_2;
																									case 146:
																										goto IL_0823_2;
																									case 94:
																										goto IL_0864_2;
																									case 208:
																										goto IL_0877_2;
																									case 211:
																										goto IL_088a_2;
																									case 44:
																										goto IL_0898_2;
																									case 59:
																										goto IL_08a6_2;
																									case 22:
																									case 167:
																										goto IL_08c7_2;
																									case 125:
																										goto IL_08df_2;
																									case 6:
																									case 209:
																										goto IL_08ed_2;
																									case 48:
																										goto IL_0901_2;
																									case 18:
																										goto IL_095e_2;
																									case 95:
																										goto IL_096c_2;
																									case 210:
																										goto IL_097f_2;
																									case 127:
																									case 204:
																										goto IL_098d_2;
																									case 137:
																									case 162:
																										goto IL_099b_2;
																									case 88:
																										goto IL_09a6_2;
																									case 89:
																									case 123:
																										goto IL_09b4_2;
																									case 83:
																										goto IL_09f4_2;
																									case 35:
																										goto IL_0a11_2;
																									case 14:
																										goto IL_0a24_2;
																									case 199:
																										goto IL_0a32_2;
																									case 156:
																									case 192:
																										goto IL_0a40_2;
																									case 84:
																										goto IL_0aa2_2;
																									case 30:
																										goto IL_0abe_2;
																									case 168:
																									case 191:
																										goto IL_0ac9_2;
																									case 102:
																										goto IL_0adc_2;
																									case 3:
																									case 143:
																										goto IL_0aea_2;
																									case 42:
																										goto IL_0af8_2;
																									case 12:
																									case 178:
																										goto IL_0b06_2;
																									case 43:
																										goto IL_0b46_2;
																									case 67:
																										goto IL_0b5a_2;
																									case 180:
																										goto IL_0b6d_2;
																									case 50:
																									case 171:
																										goto IL_0b84_2;
																									case 34:
																										goto IL_0bc4_2;
																									case 190:
																										goto IL_0bd8_2;
																									case 185:
																										goto IL_0beb_2;
																									case 23:
																									case 201:
																										goto IL_0bf6_2;
																									case 179:
																										goto IL_0c36_2;
																									case 54:
																										goto IL_0c53_2;
																									case 81:
																										goto IL_0c66_2;
																									case 66:
																									case 124:
																										goto IL_0c74_2;
																									case 41:
																										goto IL_0c7f_2;
																									case 70:
																									case 144:
																										goto IL_0c8d_2;
																									case 25:
																										goto IL_0cb6_2;
																									case 154:
																										goto IL_0cc4_2;
																									case 182:
																										goto IL_0cd7_2;
																									case 69:
																										goto IL_0ce5_2;
																									case 40:
																									case 65:
																										goto IL_0cf3_2;
																									case 193:
																										goto IL_0d01_2;
																									case 98:
																										goto IL_0d24_2;
																									case 159:
																										goto IL_0d2e_2;
																									case 49:
																										goto IL_0d3c_2;
																									case 151:
																										goto IL_0d58_2;
																									case 101:
																									case 115:
																										goto IL_0d63_2;
																									case 1:
																										goto IL_0d6e_2;
																									case 7:
																									case 158:
																										goto IL_0d7b_2;
																									case 85:
																										goto IL_0dbb_2;
																									case 15:
																										goto IL_0dcf_2;
																									case 4:
																									case 9:
																									case 19:
																									case 21:
																									case 29:
																									case 32:
																									case 36:
																									case 46:
																									case 51:
																									case 61:
																									case 62:
																									case 74:
																									case 77:
																									case 79:
																									case 80:
																									case 87:
																									case 90:
																									case 92:
																									case 97:
																									case 103:
																									case 119:
																									case 121:
																									case 128:
																									case 131:
																									case 135:
																									case 145:
																									case 147:
																									case 148:
																									case 152:
																									case 155:
																									case 170:
																									case 173:
																									case 181:
																									case 189:
																									case 212:
																									case 214:
																										goto end_IL_0391_2;
																									case 53:
																										goto IL_0df8_2;
																									case 198:
																										goto IL_0e06_2;
																									case 107:
																										goto IL_0e14_2;
																									case 11:
																									case 16:
																									case 17:
																									case 27:
																									case 31:
																									case 64:
																									case 71:
																									case 91:
																									case 114:
																									case 118:
																									case 122:
																									case 129:
																									case 134:
																									case 136:
																									case 140:
																									case 160:
																									case 164:
																									case 165:
																									case 177:
																									case 183:
																									case 197:
																									case 200:
																									case 202:
																									case 203:
																									case 213:
																										goto IL_0e22_2;
																									case 166:
																										ptr2 = ptr;
																										goto IL_0e22_2;
																									case 104:
																										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsGenericTypeDefinitionDefaultGrantSet.CurrentStateSid);
																										goto case 166;
																									case 207:
																										array7 = new object[7];
																										num = 104;
																										goto case 104;
																									case 58:
																										array6 = new long[4];
																										goto case 207;
																									case 24:
																										array5 = new int[6];
																										num = 58;
																										goto case 58;
																									case 100:
																										array4 = new int[4];
																										goto case 24;
																									case 52:
																										array3 = new object[4];
																										goto case 100;
																									case 96:
																										array2 = new byte[4];
																										goto case 52;
																									case 105:
																										num4 = num2 * 8;
																										goto case 96;
																									case 176:
																										num3 = num2 * 4;
																										goto case 105;
																									case 111:
																										num2 = 1;
																										goto case 176;
																									case 112:
																										goto end_IL_0587;
																									case 76:
																									case 109:
																										goto IL_0ef7_2;
																									}
																									continue;
																								}
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_08c7_2;
																								IL_08c7_2:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_0e22_2;
																								continue;
																								end_IL_0391_2:
																								break;
																							}
																							break;
																						}
																						goto IL_071a_2;
																						IL_0728_2:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0736_2;
																						IL_0736_2:
																						num6 = ptr2;
																						num7 = -200;
																						num5 = 1;
																						ptr2 = num6 + num7;
																						goto IL_0e22_2;
																						IL_071a_2:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_0728_2;
																					}
																					break;
																				}
																				goto IL_0752_2;
																				IL_08a6_2:
																				ptr2 += 16;
																				goto IL_0e22_2;
																				IL_0752_2:
																				if (20 > b)
																				{
																					goto IL_0760_2;
																				}
																				goto IL_07e3_2;
																				IL_0760_2:
																				if (18 >= b)
																				{
																					goto IL_076b_2;
																				}
																				goto IL_07d3_2;
																				IL_076b_2:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_0779_2;
																				IL_0779_2:
																				((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
																				num = 78;
																				goto IL_07c0_2;
																				IL_07c0_2:
																				num8 -= 3;
																				goto IL_0e22_2;
																				IL_07d3_2:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_0801_2;
																				IL_0801_2:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_080f_2;
																				IL_080f_2:
																				array2[num8 - 1] = 5;
																				goto IL_0823_2;
																				IL_0823_2:
																				array3[num8 - 1] = ((delegate*<string[], string>)ChangePermissionsLoaderInformation[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
																				num = 94;
																				goto IL_0864_2;
																				IL_0864_2:
																				ptr2 += 8;
																				goto IL_0e22_2;
																				IL_07e3_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
																				goto IL_088a_2;
																				IL_088a_2:
																				array2[num8] = 1;
																				goto IL_0898_2;
																				IL_0898_2:
																				num8++;
																				goto IL_08a6_2;
																			}
																			break;
																		}
																		goto IL_041f_2;
																		IL_069b_2:
																		array3[num8] = array7[*(int*)(ptr2 + num3)];
																		goto IL_06b3_2;
																		IL_041f_2:
																		if (17 > b)
																		{
																			num = 63;
																			goto IL_0436_2;
																		}
																		goto IL_05a8_2;
																		IL_06b3_2:
																		num8++;
																		goto IL_0877_2;
																		IL_0436_2:
																		if (14 >= b)
																		{
																			goto IL_0441_2;
																		}
																		goto IL_049c_2;
																		IL_0441_2:
																		if (14 <= b)
																		{
																			goto IL_044c_2;
																		}
																		goto IL_0475_2;
																		IL_044c_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
																		num = 142;
																		goto IL_04af_2;
																		IL_04af_2:
																		ptr2 += 8;
																		goto IL_0665_2;
																		IL_0665_2:
																		num8--;
																		goto IL_0e22_2;
																		IL_0475_2:
																		if (12 < b)
																		{
																			num = 132;
																			goto IL_048c_2;
																		}
																		goto IL_0688_2;
																		IL_0877_2:
																		ptr2 += 8;
																		goto IL_0e22_2;
																		IL_048c_2:
																		if (13 < b)
																		{
																			break;
																		}
																		goto IL_04c2_2;
																		IL_04c2_2:
																		if (13 > b)
																		{
																			break;
																		}
																		goto IL_04d0_2;
																		IL_04d0_2:
																		array8 = array3;
																		num9 = num8;
																		if (array == null)
																		{
																			goto IL_04df_2;
																		}
																		goto IL_04ed;
																		IL_0688_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0e22_2;
																		IL_049c_2:
																		if (15 < b)
																		{
																			goto IL_05bb_2;
																		}
																		goto IL_0678_2;
																		IL_05bb_2:
																		if (16 < b)
																		{
																			break;
																		}
																		goto IL_05c9_2;
																		IL_05c9_2:
																		if (16 > b)
																		{
																			break;
																		}
																		goto IL_05d7_2;
																		IL_05d7_2:
																		array2[num8] = array2[num8 - 1];
																		goto IL_05ef_2;
																		IL_05ef_2:
																		array4[num8 - 0] = array4[num8 - 1];
																		goto IL_060d_2;
																		IL_060d_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																		goto IL_0631_2;
																		IL_0631_2:
																		array3[num8] = array3[num8 - 1];
																		goto IL_0649_2;
																		IL_0649_2:
																		num8++;
																		num = 27;
																		goto IL_0e22_2;
																		IL_0678_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_06c6_2;
																		IL_06c6_2:
																		array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
																		num = 113;
																		goto IL_06f8_2;
																		IL_06f8_2:
																		array2[num8 - 1] = 5;
																		num = 140;
																		goto IL_0e22_2;
																		IL_05a8_2:
																		array2[num8] = 5;
																		goto IL_069b_2;
																	}
																	break;
																}
																goto IL_08df_2;
																IL_0dbb_2:
																array2[num8 - 2] = 0;
																goto IL_0dcf_2;
																IL_08df_2:
																if (11 <= b)
																{
																	goto IL_08ed_2;
																}
																goto IL_097f_2;
																IL_08ed_2:
																array2[num8 - 2] = 0;
																goto IL_0901_2;
																IL_0901_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = ((delegate*<int, int, int>)ChangePermissionsLoaderInformation[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]));
																num = 18;
																goto IL_095e_2;
																IL_095e_2:
																num8--;
																goto IL_096c_2;
																IL_096c_2:
																ptr2 += 8;
																goto IL_0e22_2;
																IL_097f_2:
																if (5 < b)
																{
																	goto IL_098d_2;
																}
																goto IL_0beb_2;
																IL_098d_2:
																if (8 < b)
																{
																	goto IL_099b_2;
																}
																goto IL_0abe_2;
																IL_099b_2:
																if (9 >= b)
																{
																	goto IL_09a6_2;
																}
																goto IL_0a24_2;
																IL_09a6_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_09b4_2;
																IL_09b4_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_09f4_2;
																IL_09f4_2:
																array2[num8 - 2] = 0;
																num = 35;
																goto IL_0a11_2;
																IL_0a11_2:
																num8--;
																goto IL_0e22_2;
																IL_0a24_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_0a32_2;
																IL_0a32_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_0a40_2;
																IL_0a40_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0aa2_2;
																IL_0aa2_2:
																num8 -= 2;
																num = 160;
																goto IL_0e22_2;
																IL_0abe_2:
																if (8 <= b)
																{
																	goto IL_0ac9_2;
																}
																goto IL_0adc_2;
																IL_0ac9_2:
																num8--;
																goto IL_0e22_2;
																IL_0adc_2:
																if (6 < b)
																{
																	goto IL_0aea_2;
																}
																goto IL_0b6d_2;
																IL_0aea_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0af8_2;
																IL_0af8_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0b06_2;
																IL_0b06_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0b46_2;
																IL_0b46_2:
																array2[num8 - 2] = 0;
																goto IL_0b5a_2;
																IL_0b5a_2:
																num8--;
																goto IL_0e22_2;
																IL_0b6d_2:
																if (6 > b)
																{
																	break;
																}
																num = 50;
																goto IL_0b84_2;
																IL_0dcf_2:
																num8--;
																goto IL_0e22_2;
																IL_0b84_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0bc4_2;
																IL_0bc4_2:
																array2[num8 - 2] = 0;
																goto IL_0bd8_2;
																IL_0bd8_2:
																num8--;
																goto IL_0e22_2;
																IL_0beb_2:
																if (5 <= b)
																{
																	goto IL_0bf6_2;
																}
																goto IL_0c66_2;
																IL_0bf6_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0c36_2;
																IL_0c36_2:
																array2[num8 - 2] = 0;
																num = 54;
																goto IL_0c53_2;
																IL_0c53_2:
																num8--;
																goto IL_0e22_2;
																IL_0c66_2:
																if (2 < b)
																{
																	goto IL_0c74_2;
																}
																goto IL_0d58_2;
																IL_0c74_2:
																if (3 >= b)
																{
																	goto IL_0c7f_2;
																}
																goto IL_0cd7_2;
																IL_0c7f_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_0c8d_2;
																IL_0c8d_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0cb6_2;
																IL_0cb6_2:
																ptr2 += 8;
																goto IL_0cc4_2;
																IL_0cc4_2:
																num8--;
																goto IL_0e22_2;
																IL_0cd7_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_0ce5_2;
																IL_0ce5_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0cf3_2;
																IL_0cf3_2:
																array2[num8] = 0;
																goto IL_0d01_2;
																IL_0d01_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
																goto IL_0d24_2;
																IL_0d24_2:
																array3[num8] = null;
																goto IL_0d2e_2;
																IL_0d2e_2:
																num8++;
																goto IL_0d3c_2;
																IL_0d3c_2:
																ptr2 += 8;
																num = 122;
																goto IL_0e22_2;
																IL_0d58_2:
																if (2 > b)
																{
																	goto IL_0d63_2;
																}
																goto IL_0d7b_2;
																IL_0d63_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_0d6e_2;
																IL_0d6e_2:
																if (1 <= b)
																{
																}
																break;
																IL_0d7b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0dbb_2;
															}
															break;
															IL_03e4_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
													goto IL_0df8_2;
													IL_0e14_2:
													ptr2 += 8;
													goto IL_0e22_2;
													IL_0e06_2:
													num8++;
													goto IL_0e14_2;
													IL_0df8_2:
													array2[num8] = 0;
													goto IL_0e06_2;
													continue;
													end_IL_03f4_2:
													break;
												}
												continue;
												end_IL_0404:
												break;
											}
											continue;
											end_IL_0414:
											break;
										}
										break;
									}
									goto IL_0ef7_2;
									IL_0ef7_2:
									return (string)array3[num8 - 1];
								}
								break;
							}
							continue;
							end_IL_0587:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0381, IL_0394, IL_03a4, IL_03b4, IL_03c4, IL_03d4, IL_03ed, IL_03f8, IL_040c, IL_044b, IL_045e, IL_046c, IL_0477, IL_04b7, IL_04cb, IL_04de, IL_04ec, IL_04f7, IL_0537, IL_054b, IL_055e, IL_056c, IL_057f, IL_058a, IL_0598, IL_05c1, IL_05cf, IL_05e2, IL_05f0, IL_05fe, IL_060c, IL_062f, IL_0639, IL_0647, IL_065a, IL_0668, IL_0676, IL_0684, IL_0692, IL_06fd, IL_0710, IL_071e, IL_075e, IL_0772, IL_0785, IL_0793, IL_079e, IL_07ac, IL_07ec, IL_0800, IL_0813, IL_0821, IL_082f, IL_0878, IL_088c, IL_08a8, IL_08bb, IL_08c9, IL_08d7, IL_08e5, IL_08f3, IL_08fe, IL_0911, IL_091f, IL_092d, IL_094a, IL_0999, IL_09a3, IL_09d0, IL_09e4, IL_09f2, IL_0a05, IL_0a23, IL_0a31, IL_0a4d, IL_0a58, IL_0a66, IL_0a8f, IL_0aa8, IL_0ab6, IL_0ac4, IL_0ae5, IL_0b03, IL_0b27, IL_0b3f, IL_0b52, IL_0b60, IL_0b78, IL_0b86, IL_0b99, IL_0ba7, IL_0bb2, IL_0bcb, IL_0be2, IL_0bf0, IL_0c03, IL_0c0e, IL_0c19, IL_0c57, IL_0c6a, IL_0c78, IL_0c86, IL_0c94, IL_0ca8, IL_0ce0, IL_0cf3, IL_0cfe, IL_0d09, IL_0d14, IL_0d2d, IL_0d38, IL_0d4d, IL_0d6f, IL_0d7d, IL_0d8b, IL_0d99, IL_0dac, IL_0db7, IL_0dc1, IL_0dcc, IL_0ddc, IL_0dec, IL_0e05, IL_0e15, IL_0e25, IL_0e35, IL_0e45, IL_0e55, IL_0e70 are reachable both inside and outside the pinned region starting at IL_0e6a. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 157;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef31 = default(int);
				ref int reference = ref __rxRef31;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e55:
						num2 = 1;
						while (true)
						{
							IL_0e45:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e35:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e25:
									array2 = new byte[4];
									while (true)
									{
										IL_0e15:
										array3 = new object[4];
										while (true)
										{
											IL_0e05:
											array4 = new int[4];
											while (true)
											{
												IL_0dec:
												array5 = new int[6];
												num = 139;
												while (true)
												{
													IL_0ddc:
													array6 = new long[4];
													while (true)
													{
														IL_0dcc:
														array7 = new object[15];
														while (true)
														{
															IL_0dc1:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisterTrackingHandlerTotalDays.GetSharedStringMakergetCryptoKeySecurity);
															while (true)
															{
																IL_0db7:
																ptr2 = ptr;
																while (true)
																{
																	IL_0dac:
																	num = 84;
																	while (true)
																	{
																		IL_0d99:
																		if (num5 != 1)
																		{
																			while (true)
																			{
																				IL_03ed:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_03d4:
																					ptr2++;
																					num = 89;
																					while (true)
																					{
																						IL_03c4:
																						if (b >= 1)
																						{
																							while (b <= 22)
																							{
																								while (true)
																								{
																									IL_03a4:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0394:
																											if (11 > b)
																											{
																												num = 217;
																												while (true)
																												{
																													if (num == 217)
																													{
																														goto IL_045e;
																													}
																													if (num != 1198)
																													{
																														goto IL_062f;
																													}
																													switch (num)
																													{
																													case 157:
																														break;
																													default:
																														continue;
																													case 197:
																														goto IL_0394;
																													case 205:
																														goto IL_03a4;
																													case 206:
																														goto IL_03b4;
																													case 89:
																														goto IL_03c4;
																													case 175:
																														goto IL_03d4;
																													case 20:
																													case 94:
																														goto IL_03ed;
																													case 0:
																													case 144:
																														goto IL_03f8;
																													case 150:
																														goto IL_040c;
																													case 100:
																														goto IL_044b;
																													case 101:
																														goto IL_045e;
																													case 127:
																														goto IL_046c;
																													case 33:
																													case 166:
																														goto IL_0477;
																													case 66:
																														goto IL_04b7;
																													case 58:
																														goto IL_04cb;
																													case 189:
																														goto IL_04de;
																													case 50:
																														goto IL_04ec;
																													case 105:
																													case 183:
																														goto IL_04f7;
																													case 178:
																														goto IL_0537;
																													case 198:
																														goto IL_054b;
																													case 141:
																														goto IL_055e;
																													case 172:
																														goto IL_056c;
																													case 71:
																														goto IL_057f;
																													case 115:
																														goto IL_058a;
																													case 26:
																													case 128:
																														goto IL_0598;
																													case 72:
																														goto IL_05c1;
																													case 86:
																														goto IL_05cf;
																													case 25:
																														goto IL_05e2;
																													case 30:
																														goto IL_05f0;
																													case 68:
																													case 104:
																														goto IL_05fe;
																													case 27:
																														goto IL_060c;
																													case 1:
																														goto IL_062f;
																													case 14:
																														goto IL_0639;
																													case 17:
																														goto IL_0647;
																													case 49:
																														goto IL_065a;
																													case 107:
																													case 188:
																														goto IL_0668;
																													case 38:
																													case 109:
																														goto IL_0676;
																													case 43:
																														goto IL_0684;
																													case 78:
																													case 153:
																														goto IL_0692;
																													case 170:
																														goto IL_06fd;
																													case 102:
																														goto IL_0710;
																													case 5:
																													case 67:
																														goto IL_071e;
																													case 119:
																														goto IL_075e;
																													case 116:
																														goto IL_0772;
																													case 36:
																														goto IL_0785;
																													case 135:
																													case 158:
																														goto IL_0793;
																													case 200:
																														goto IL_079e;
																													case 147:
																													case 181:
																														goto IL_07ac;
																													case 193:
																														goto IL_07ec;
																													case 203:
																														goto IL_0800;
																													case 152:
																														goto IL_0813;
																													case 32:
																														goto IL_0821;
																													case 21:
																													case 194:
																														goto IL_082f;
																													case 160:
																														goto IL_0878;
																													case 59:
																														goto IL_088c;
																													case 117:
																													case 149:
																														goto IL_08a8;
																													case 75:
																														goto IL_08bb;
																													case 42:
																														goto IL_08c9;
																													case 40:
																													case 62:
																														goto IL_08d7;
																													case 129:
																														goto IL_08e5;
																													case 125:
																													case 131:
																														goto IL_08f3;
																													case 23:
																														goto IL_08fe;
																													case 164:
																														goto IL_0911;
																													case 18:
																														goto IL_091f;
																													case 106:
																													case 146:
																														goto IL_092d;
																													case 133:
																														goto IL_09e4;
																													case 204:
																														goto IL_09f2;
																													case 9:
																													case 140:
																														goto IL_0a05;
																													case 93:
																														goto IL_0a23;
																													case 199:
																														goto IL_0a31;
																													case 60:
																														goto IL_0a4d;
																													case 56:
																														goto IL_0a58;
																													case 97:
																													case 180:
																														goto IL_0a66;
																													case 55:
																														goto IL_0a8f;
																													case 95:
																														goto IL_0aa8;
																													case 134:
																														goto IL_0ab6;
																													case 35:
																													case 201:
																														goto IL_0ac4;
																													case 85:
																														goto IL_0ae5;
																													case 190:
																														goto IL_0b03;
																													case 191:
																														goto IL_0b27;
																													case 155:
																														goto IL_0b3f;
																													case 53:
																													case 80:
																														goto IL_0b52;
																													case 74:
																														goto IL_0b60;
																													case 179:
																														goto IL_0b78;
																													case 209:
																														goto IL_0b86;
																													case 113:
																														goto IL_0b99;
																													case 114:
																														goto IL_0ba7;
																													case 136:
																													case 186:
																														goto IL_0bb2;
																													case 148:
																														goto IL_0bcb;
																													case 210:
																														goto IL_0be2;
																													case 159:
																														goto IL_0bf0;
																													case 13:
																														goto IL_0c03;
																													case 54:
																														goto IL_0c0e;
																													case 51:
																													case 145:
																														goto IL_0c19;
																													case 120:
																														goto IL_0c57;
																													case 29:
																														goto IL_0c78;
																													case 130:
																														goto IL_0c86;
																													case 167:
																													case 208:
																														goto IL_0c94;
																													case 192:
																														goto IL_0ca8;
																													case 45:
																														goto IL_0ce0;
																													case 103:
																														goto IL_0cf3;
																													case 123:
																													case 126:
																														goto IL_0cfe;
																													case 79:
																														goto IL_0d09;
																													case 87:
																													case 137:
																														goto IL_0d14;
																													case 92:
																														goto IL_0d2d;
																													case 69:
																													case 96:
																														goto IL_0d38;
																													case 3:
																													case 4:
																													case 6:
																													case 8:
																													case 10:
																													case 11:
																													case 12:
																													case 15:
																													case 22:
																													case 28:
																													case 34:
																													case 39:
																													case 41:
																													case 46:
																													case 48:
																													case 52:
																													case 63:
																													case 64:
																													case 65:
																													case 77:
																													case 81:
																													case 90:
																													case 91:
																													case 98:
																													case 110:
																													case 112:
																													case 118:
																													case 121:
																													case 124:
																													case 132:
																													case 138:
																													case 165:
																													case 171:
																													case 173:
																													case 177:
																													case 187:
																													case 207:
																														goto end_IL_03b4;
																													case 88:
																														goto IL_0d6f;
																													case 162:
																														goto IL_0d7d;
																													case 37:
																														goto IL_0d8b;
																													case 2:
																													case 7:
																													case 16:
																													case 19:
																													case 24:
																													case 44:
																													case 61:
																													case 73:
																													case 76:
																													case 82:
																													case 83:
																													case 84:
																													case 99:
																													case 108:
																													case 111:
																													case 122:
																													case 151:
																													case 154:
																													case 168:
																													case 169:
																													case 174:
																													case 182:
																													case 184:
																													case 196:
																														goto IL_0d99;
																													case 57:
																														goto IL_0dac;
																													case 31:
																														goto IL_0db7;
																													case 202:
																														goto IL_0dc1;
																													case 70:
																														goto IL_0dcc;
																													case 139:
																														goto IL_0ddc;
																													case 143:
																														goto IL_0dec;
																													case 195:
																														goto IL_0e05;
																													case 142:
																														goto IL_0e15;
																													case 47:
																														goto IL_0e25;
																													case 185:
																														goto IL_0e35;
																													case 161:
																														goto IL_0e45;
																													case 156:
																														goto IL_0e55;
																													case 163:
																													case 176:
																														goto IL_0e70;
																													}
																													break;
																													IL_088c:
																													num6--;
																													num = 169;
																													goto IL_0d99;
																													IL_08a8:
																													num6--;
																													goto IL_0d99;
																													IL_045e:
																													if (5 >= b)
																													{
																														goto IL_046c;
																													}
																													goto IL_065a;
																													IL_046c:
																													if (5 <= b)
																													{
																														goto IL_0477;
																													}
																													goto IL_04de;
																													IL_0477:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_04b7;
																													IL_04b7:
																													array2[num6 - 2] = 0;
																													goto IL_04cb;
																													IL_04cb:
																													num6--;
																													goto IL_0d99;
																													IL_04de:
																													if (2 >= b)
																													{
																														goto IL_04ec;
																													}
																													goto IL_057f;
																													IL_04ec:
																													if (2 <= b)
																													{
																														goto IL_04f7;
																													}
																													goto IL_055e;
																													IL_04f7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0537;
																													IL_0537:
																													array2[num6 - 2] = 0;
																													goto IL_054b;
																													IL_054b:
																													num6--;
																													goto IL_0d99;
																													IL_055e:
																													if (1 < b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_056c;
																													IL_056c:
																													if (1 <= b)
																													{
																													}
																													goto end_IL_03b4;
																													IL_057f:
																													if (3 >= b)
																													{
																														goto IL_058a;
																													}
																													goto IL_05e2;
																													IL_058a:
																													if (3 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_0598;
																													IL_0598:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_05c1;
																													IL_05c1:
																													ptr2 += 8;
																													goto IL_05cf;
																													IL_05cf:
																													num6--;
																													goto IL_0d99;
																													IL_05e2:
																													if (4 < b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_05f0;
																													IL_05f0:
																													if (4 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_05fe;
																													IL_05fe:
																													array2[num6] = 0;
																													goto IL_060c;
																													IL_060c:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																													goto IL_062f;
																													IL_062f:
																													array3[num6] = null;
																													goto IL_0639;
																													IL_0639:
																													num6++;
																													goto IL_0647;
																													IL_0647:
																													ptr2 += 8;
																													goto IL_0d99;
																													IL_065a:
																													if (8 < b)
																													{
																														goto IL_0668;
																													}
																													goto IL_0785;
																													IL_0668:
																													if (9 < b)
																													{
																														goto IL_0676;
																													}
																													goto IL_0710;
																													IL_0676:
																													if (10 < b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_0684;
																													IL_0684:
																													if (10 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_0692;
																													IL_0692:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													num = 170;
																													goto IL_06fd;
																													IL_06fd:
																													num6 -= 2;
																													goto IL_0d99;
																													IL_0710:
																													if (9 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_071e;
																													IL_071e:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_075e;
																													IL_075e:
																													array2[num6 - 2] = 0;
																													goto IL_0772;
																													IL_0772:
																													num6--;
																													goto IL_0d99;
																													IL_0785:
																													if (8 > b)
																													{
																														goto IL_0793;
																													}
																													goto IL_08a8;
																													IL_0793:
																													if (6 >= b)
																													{
																														goto IL_079e;
																													}
																													goto IL_0813;
																													IL_079e:
																													if (6 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_07ac;
																													IL_07ac:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_07ec;
																													IL_07ec:
																													array2[num6 - 2] = 0;
																													goto IL_0800;
																													IL_0800:
																													num6--;
																													goto IL_0d99;
																													IL_0813:
																													if (7 < b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_0821;
																													IL_0821:
																													if (7 > b)
																													{
																														goto end_IL_03b4;
																													}
																													goto IL_082f;
																													IL_082f:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													num = 160;
																													goto IL_0878;
																													IL_0878:
																													array2[num6 - 2] = 0;
																													goto IL_088c;
																												}
																												break;
																											}
																											goto IL_03f8;
																											IL_040c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)SerializationInvalidOnDeserUtcDateTime[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_044b;
																											IL_044b:
																											ptr2 += 8;
																											goto IL_0d99;
																											IL_03f8:
																											array2[num6 - 1] = 0;
																											goto IL_040c;
																										}
																										break;
																									}
																									goto IL_08bb;
																									IL_0cfe:
																									if (22 < b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0d09;
																									IL_08bb:
																									if (17 >= b)
																									{
																										goto IL_08c9;
																									}
																									goto IL_0b99;
																									IL_08c9:
																									if (17 > b)
																									{
																										goto IL_08d7;
																									}
																									goto IL_0b52;
																									IL_08d7:
																									if (14 >= b)
																									{
																										goto IL_08e5;
																									}
																									goto IL_0a4d;
																									IL_08e5:
																									if (14 > b)
																									{
																										goto IL_08f3;
																									}
																									goto IL_0a05;
																									IL_08f3:
																									if (12 >= b)
																									{
																										goto IL_08fe;
																									}
																									goto IL_0911;
																									IL_08fe:
																									if (12 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0d99;
																									IL_0911:
																									if (13 < b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_091f;
																									IL_091f:
																									if (13 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_092d;
																									IL_092d:
																									array8 = array3;
																									num7 = num6;
																									if (array == null)
																									{
																										goto IL_093c;
																									}
																									num8 = ptr2;
																									byte b2 = *num8;
																									ptr2 = num8 + 4;
																									int num9 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num9;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_09e4;
																									IL_0d09:
																									if (22 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0d14;
																									IL_0d14:
																									num10 = ptr2;
																									num11 = -200;
																									num5 = 1;
																									ptr2 = num10 + num11;
																									goto IL_0d99;
																									IL_0d2d:
																									if (21 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0d38;
																									IL_09e4:
																									array2[num6] = 5;
																									goto IL_09f2;
																									IL_09f2:
																									num6++;
																									goto IL_0d99;
																									IL_0a05:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_0a23;
																									IL_0a23:
																									ptr2 += 8;
																									goto IL_0a31;
																									IL_0a31:
																									num6--;
																									num = 196;
																									goto IL_0d99;
																									IL_0a4d:
																									if (15 >= b)
																									{
																										goto IL_0a58;
																									}
																									goto IL_0aa8;
																									IL_0a58:
																									if (15 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0a66;
																									IL_0a66:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0a8f;
																									IL_0a8f:
																									array2[num6 - 1] = 5;
																									goto IL_0d99;
																									IL_0aa8:
																									if (16 < b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0ab6;
																									IL_0ab6:
																									if (16 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0ac4;
																									IL_0ac4:
																									array2[num6] = array2[num6 - 1];
																									num = 85;
																									goto IL_0ae5;
																									IL_0ae5:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0b03;
																									IL_0b03:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0b27;
																									IL_0b27:
																									array3[num6] = array3[num6 - 1];
																									goto IL_0b3f;
																									IL_0b3f:
																									num6++;
																									goto IL_0d99;
																									IL_0b52:
																									array2[num6] = 5;
																									goto IL_0b60;
																									IL_0b60:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0b78;
																									IL_0b78:
																									num6++;
																									goto IL_0b86;
																									IL_0b86:
																									ptr2 += 8;
																									goto IL_0d99;
																									IL_0b99:
																									if (20 >= b)
																									{
																										goto IL_0ba7;
																									}
																									goto IL_0cf3;
																									IL_0ba7:
																									if (20 <= b)
																									{
																										goto IL_0bb2;
																									}
																									goto IL_0c03;
																									IL_0bb2:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0bcb;
																									IL_0bcb:
																									array2[num6] = 1;
																									num = 210;
																									goto IL_0be2;
																									IL_0be2:
																									num6++;
																									goto IL_0bf0;
																									IL_0bf0:
																									ptr2 += 16;
																									goto IL_0d99;
																									IL_0c03:
																									if (18 >= b)
																									{
																										goto IL_0c0e;
																									}
																									goto IL_0c78;
																									IL_0c0e:
																									if (18 > b)
																									{
																										num = 22;
																										goto end_IL_03b4;
																									}
																									goto IL_0c19;
																									IL_0c19:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0c57;
																									IL_0c57:
																									num6 -= 3;
																									goto IL_0d99;
																									IL_0d38:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0d99;
																									IL_0c78:
																									if (19 < b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0c86;
																									IL_0c86:
																									if (19 > b)
																									{
																										goto end_IL_03b4;
																									}
																									goto IL_0c94;
																									IL_0c94:
																									array2[num6 - 1] = 5;
																									goto IL_0ca8;
																									IL_0ca8:
																									array3[num6 - 1] = ((delegate*<string[], string>)SerializationInvalidOnDeserUtcDateTime[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0ce0;
																									IL_0ce0:
																									ptr2 += 8;
																									goto IL_0d99;
																									IL_0cf3:
																									if (21 < b)
																									{
																										goto IL_0cfe;
																									}
																									goto IL_0d2d;
																								}
																								goto end_IL_03c4;
																								continue;
																								end_IL_03b4:
																								break;
																								IL_03b4:;
																							}
																						}
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						num = 88;
																						goto IL_0d6f;
																						IL_0d8b:
																						ptr2 += 8;
																						goto IL_0d99;
																						IL_0d7d:
																						num6++;
																						goto IL_0d8b;
																						IL_0d6f:
																						array2[num6] = 0;
																						goto IL_0d7d;
																						continue;
																						end_IL_03c4:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		goto IL_0e70;
																		IL_0e70:
																		return (string)array3[num6 - 1];
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_093c:
				while (true)
				{
					IL_093c_2:
					array = new byte[4];
					while (true)
					{
						IL_094a:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_09f2_2:
								num6++;
								while (true)
								{
									IL_0d99_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												num = 89;
												while (true)
												{
													IL_03c4_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																if (11 >= b)
																{
																	while (true)
																	{
																		if (11 > b)
																		{
																			num = 217;
																			while (true)
																			{
																				if (num == 217)
																				{
																					goto IL_045e_2;
																				}
																				if (num != 1198)
																				{
																					goto IL_062f_2;
																				}
																				switch (num)
																				{
																				case 197:
																					goto end_IL_0381;
																				case 205:
																					goto end_IL_0394;
																				case 206:
																					goto end_IL_03a4;
																				case 89:
																					goto IL_03c4_2;
																				case 175:
																					goto end_IL_03c4_2;
																				case 20:
																				case 94:
																					goto end_IL_03d4;
																				case 0:
																				case 144:
																					goto IL_03f8_2;
																				case 150:
																					goto IL_040c_2;
																				case 100:
																					goto IL_044b_2;
																				case 101:
																					goto IL_045e_2;
																				case 127:
																					goto IL_046c_2;
																				case 33:
																				case 166:
																					goto IL_0477_2;
																				case 66:
																					goto IL_04b7_2;
																				case 58:
																					goto IL_04cb_2;
																				case 189:
																					goto IL_04de_2;
																				case 50:
																					goto IL_04ec_2;
																				case 105:
																				case 183:
																					goto IL_04f7_2;
																				case 178:
																					goto IL_0537_2;
																				case 198:
																					goto IL_054b_2;
																				case 141:
																					goto IL_055e_2;
																				case 172:
																					goto IL_056c_2;
																				case 71:
																					goto IL_057f_2;
																				case 115:
																					goto IL_058a_2;
																				case 26:
																				case 128:
																					goto IL_0598_2;
																				case 72:
																					goto IL_05c1_2;
																				case 86:
																					goto IL_05cf_2;
																				case 25:
																					goto IL_05e2_2;
																				case 30:
																					goto IL_05f0_2;
																				case 68:
																				case 104:
																					goto IL_05fe_2;
																				case 27:
																					goto IL_060c_2;
																				case 1:
																					goto IL_062f_2;
																				case 14:
																					goto IL_0639_2;
																				case 17:
																					goto IL_0647_2;
																				case 49:
																					goto IL_065a_2;
																				case 107:
																				case 188:
																					goto IL_0668_2;
																				case 38:
																				case 109:
																					goto IL_0676_2;
																				case 43:
																					goto IL_0684_2;
																				case 78:
																				case 153:
																					goto IL_0692_2;
																				case 170:
																					goto IL_06fd_2;
																				case 102:
																					goto IL_0710_2;
																				case 5:
																				case 67:
																					goto IL_071e_2;
																				case 119:
																					goto IL_075e_2;
																				case 116:
																					goto IL_0772_2;
																				case 36:
																					goto IL_0785_2;
																				case 135:
																				case 158:
																					goto IL_0793_2;
																				case 200:
																					goto IL_079e_2;
																				case 147:
																				case 181:
																					goto IL_07ac_2;
																				case 193:
																					goto IL_07ec_2;
																				case 203:
																					goto IL_0800_2;
																				case 152:
																					goto IL_0813_2;
																				case 32:
																					goto IL_0821_2;
																				case 21:
																				case 194:
																					goto IL_082f_2;
																				case 160:
																					goto IL_0878_2;
																				case 59:
																					goto IL_088c_2;
																				case 117:
																				case 149:
																					goto IL_08a8_2;
																				case 75:
																					goto IL_08bb_2;
																				case 42:
																					goto IL_08c9_2;
																				case 40:
																				case 62:
																					goto IL_08d7_2;
																				case 129:
																					goto IL_08e5_2;
																				case 125:
																				case 131:
																					goto IL_08f3_2;
																				case 23:
																					goto IL_08fe_2;
																				case 164:
																					goto IL_0911_2;
																				case 18:
																					goto IL_091f_2;
																				case 106:
																				case 146:
																					goto IL_092d_2;
																				case 133:
																					goto end_IL_03ed;
																				case 204:
																					goto IL_09f2_2;
																				case 9:
																				case 140:
																					goto IL_0a05_2;
																				case 93:
																					goto IL_0a23_2;
																				case 199:
																					goto IL_0a31_2;
																				case 60:
																					goto IL_0a4d_2;
																				case 56:
																					goto IL_0a58_2;
																				case 97:
																				case 180:
																					goto IL_0a66_2;
																				case 55:
																					goto IL_0a8f_2;
																				case 95:
																					goto IL_0aa8_2;
																				case 134:
																					goto IL_0ab6_2;
																				case 35:
																				case 201:
																					goto IL_0ac4_2;
																				case 85:
																					goto IL_0ae5_2;
																				case 190:
																					goto IL_0b03_2;
																				case 191:
																					goto IL_0b27_2;
																				case 155:
																					goto IL_0b3f_2;
																				case 53:
																				case 80:
																					goto IL_0b52_2;
																				case 74:
																					goto IL_0b60_2;
																				case 179:
																					goto IL_0b78_2;
																				case 209:
																					goto IL_0b86_2;
																				case 113:
																					goto IL_0b99_2;
																				case 114:
																					goto IL_0ba7_2;
																				case 136:
																				case 186:
																					goto IL_0bb2_2;
																				case 148:
																					goto IL_0bcb_2;
																				case 210:
																					goto IL_0be2_2;
																				case 159:
																					goto IL_0bf0_2;
																				case 13:
																					goto IL_0c03_2;
																				case 54:
																					goto IL_0c0e_2;
																				case 51:
																				case 145:
																					goto IL_0c19_2;
																				case 120:
																					goto IL_0c57_2;
																				case 29:
																					goto IL_0c78_2;
																				case 130:
																					goto IL_0c86_2;
																				case 167:
																				case 208:
																					goto IL_0c94_2;
																				case 192:
																					goto IL_0ca8_2;
																				case 45:
																					goto IL_0ce0_2;
																				case 103:
																					goto IL_0cf3_2;
																				case 123:
																				case 126:
																					goto IL_0cfe_2;
																				case 79:
																					goto IL_0d09_2;
																				case 87:
																				case 137:
																					goto IL_0d14_2;
																				case 92:
																					goto IL_0d2d_2;
																				case 69:
																				case 96:
																					goto IL_0d38_2;
																				case 3:
																				case 4:
																				case 6:
																				case 8:
																				case 10:
																				case 11:
																				case 12:
																				case 15:
																				case 22:
																				case 28:
																				case 34:
																				case 39:
																				case 41:
																				case 46:
																				case 48:
																				case 52:
																				case 63:
																				case 64:
																				case 65:
																				case 77:
																				case 81:
																				case 90:
																				case 91:
																				case 98:
																				case 110:
																				case 112:
																				case 118:
																				case 121:
																				case 124:
																				case 132:
																				case 138:
																				case 165:
																				case 171:
																				case 173:
																				case 177:
																				case 187:
																				case 207:
																					goto end_IL_03b4_2;
																				case 88:
																					goto IL_0d6f_2;
																				case 162:
																					goto IL_0d7d_2;
																				case 37:
																					goto IL_0d8b_2;
																				case 2:
																				case 7:
																				case 16:
																				case 19:
																				case 24:
																				case 44:
																				case 61:
																				case 73:
																				case 76:
																				case 82:
																				case 83:
																				case 84:
																				case 99:
																				case 108:
																				case 111:
																				case 122:
																				case 151:
																				case 154:
																				case 168:
																				case 169:
																				case 174:
																				case 182:
																				case 184:
																				case 196:
																					goto IL_0d99_2;
																				case 57:
																					num = 84;
																					goto IL_0d99_2;
																				case 31:
																					ptr2 = ptr;
																					goto case 57;
																				case 202:
																					ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisterTrackingHandlerTotalDays.GetSharedStringMakergetCryptoKeySecurity);
																					goto case 31;
																				case 70:
																					array7 = new object[15];
																					goto case 202;
																				case 139:
																					array6 = new long[4];
																					goto case 70;
																				case 143:
																					array5 = new int[6];
																					num = 139;
																					goto case 139;
																				case 195:
																					array4 = new int[4];
																					goto case 143;
																				case 142:
																					array3 = new object[4];
																					goto case 195;
																				case 47:
																					array2 = new byte[4];
																					goto case 142;
																				case 185:
																					num4 = num2 * 8;
																					goto case 47;
																				case 161:
																					num3 = num2 * 4;
																					goto case 185;
																				case 156:
																					num2 = 1;
																					goto case 161;
																				case 157:
																					goto end_IL_09e4;
																				case 163:
																				case 176:
																					goto IL_0e70_2;
																				}
																				continue;
																				IL_088c_2:
																				num6--;
																				num = 169;
																				goto IL_0d99_2;
																				IL_08a8_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_045e_2:
																				if (5 >= b)
																				{
																					goto IL_046c_2;
																				}
																				goto IL_065a_2;
																				IL_046c_2:
																				if (5 <= b)
																				{
																					goto IL_0477_2;
																				}
																				goto IL_04de_2;
																				IL_0477_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_04b7_2;
																				IL_04b7_2:
																				array2[num6 - 2] = 0;
																				goto IL_04cb_2;
																				IL_04cb_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_04de_2:
																				if (2 >= b)
																				{
																					goto IL_04ec_2;
																				}
																				goto IL_057f_2;
																				IL_04ec_2:
																				if (2 <= b)
																				{
																					goto IL_04f7_2;
																				}
																				goto IL_055e_2;
																				IL_04f7_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0537_2;
																				IL_0537_2:
																				array2[num6 - 2] = 0;
																				goto IL_054b_2;
																				IL_054b_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_055e_2:
																				if (1 < b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_056c_2;
																				IL_056c_2:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_03b4_2;
																				IL_057f_2:
																				if (3 >= b)
																				{
																					goto IL_058a_2;
																				}
																				goto IL_05e2_2;
																				IL_058a_2:
																				if (3 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_0598_2;
																				IL_0598_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_05c1_2;
																				IL_05c1_2:
																				ptr2 += 8;
																				goto IL_05cf_2;
																				IL_05cf_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_05e2_2:
																				if (4 < b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_05f0_2;
																				IL_05f0_2:
																				if (4 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_05fe_2;
																				IL_05fe_2:
																				array2[num6] = 0;
																				goto IL_060c_2;
																				IL_060c_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				goto IL_062f_2;
																				IL_062f_2:
																				array3[num6] = null;
																				goto IL_0639_2;
																				IL_0639_2:
																				num6++;
																				goto IL_0647_2;
																				IL_0647_2:
																				ptr2 += 8;
																				goto IL_0d99_2;
																				IL_065a_2:
																				if (8 < b)
																				{
																					goto IL_0668_2;
																				}
																				goto IL_0785_2;
																				IL_0668_2:
																				if (9 < b)
																				{
																					goto IL_0676_2;
																				}
																				goto IL_0710_2;
																				IL_0676_2:
																				if (10 < b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_0684_2;
																				IL_0684_2:
																				if (10 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_0692_2;
																				IL_0692_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 170;
																				goto IL_06fd_2;
																				IL_06fd_2:
																				num6 -= 2;
																				goto IL_0d99_2;
																				IL_0710_2:
																				if (9 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_071e_2;
																				IL_071e_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_075e_2;
																				IL_075e_2:
																				array2[num6 - 2] = 0;
																				goto IL_0772_2;
																				IL_0772_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_0785_2:
																				if (8 > b)
																				{
																					goto IL_0793_2;
																				}
																				goto IL_08a8_2;
																				IL_0793_2:
																				if (6 >= b)
																				{
																					goto IL_079e_2;
																				}
																				goto IL_0813_2;
																				IL_079e_2:
																				if (6 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_07ac_2;
																				IL_07ac_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_07ec_2;
																				IL_07ec_2:
																				array2[num6 - 2] = 0;
																				goto IL_0800_2;
																				IL_0800_2:
																				num6--;
																				goto IL_0d99_2;
																				IL_0813_2:
																				if (7 < b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_0821_2;
																				IL_0821_2:
																				if (7 > b)
																				{
																					goto end_IL_03b4_2;
																				}
																				goto IL_082f_2;
																				IL_082f_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				num = 160;
																				goto IL_0878_2;
																				IL_0878_2:
																				array2[num6 - 2] = 0;
																				goto IL_088c_2;
																				continue;
																				end_IL_0381:
																				break;
																			}
																			continue;
																		}
																		goto IL_03f8_2;
																		IL_040c_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)SerializationInvalidOnDeserUtcDateTime[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_044b_2;
																		IL_044b_2:
																		ptr2 += 8;
																		goto IL_0d99_2;
																		IL_03f8_2:
																		array2[num6 - 1] = 0;
																		goto IL_040c_2;
																		continue;
																		end_IL_0394:
																		break;
																	}
																	continue;
																}
																goto IL_08bb_2;
																IL_0d2d_2:
																if (21 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0d38_2;
																IL_08bb_2:
																if (17 >= b)
																{
																	goto IL_08c9_2;
																}
																goto IL_0b99_2;
																IL_08c9_2:
																if (17 > b)
																{
																	goto IL_08d7_2;
																}
																goto IL_0b52_2;
																IL_08d7_2:
																if (14 >= b)
																{
																	goto IL_08e5_2;
																}
																goto IL_0a4d_2;
																IL_08e5_2:
																if (14 > b)
																{
																	goto IL_08f3_2;
																}
																goto IL_0a05_2;
																IL_08f3_2:
																if (12 >= b)
																{
																	goto IL_08fe_2;
																}
																goto IL_0911_2;
																IL_08fe_2:
																if (12 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0d99_2;
																IL_0911_2:
																if (13 < b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_091f_2;
																IL_091f_2:
																if (13 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_092d_2;
																IL_092d_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_093c_2;
																}
																goto IL_094a;
																IL_0a05_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0a23_2;
																IL_0a23_2:
																ptr2 += 8;
																goto IL_0a31_2;
																IL_0a31_2:
																num6--;
																num = 196;
																goto IL_0d99_2;
																IL_0a4d_2:
																if (15 >= b)
																{
																	goto IL_0a58_2;
																}
																goto IL_0aa8_2;
																IL_0a58_2:
																if (15 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0a66_2;
																IL_0a66_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_0a8f_2;
																IL_0a8f_2:
																array2[num6 - 1] = 5;
																goto IL_0d99_2;
																IL_0aa8_2:
																if (16 < b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0ab6_2;
																IL_0ab6_2:
																if (16 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0ac4_2;
																IL_0ac4_2:
																array2[num6] = array2[num6 - 1];
																num = 85;
																goto IL_0ae5_2;
																IL_0ae5_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0b03_2;
																IL_0b03_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0b27_2;
																IL_0b27_2:
																array3[num6] = array3[num6 - 1];
																goto IL_0b3f_2;
																IL_0b3f_2:
																num6++;
																goto IL_0d99_2;
																IL_0b52_2:
																array2[num6] = 5;
																goto IL_0b60_2;
																IL_0b60_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0b78_2;
																IL_0b78_2:
																num6++;
																goto IL_0b86_2;
																IL_0b86_2:
																ptr2 += 8;
																goto IL_0d99_2;
																IL_0b99_2:
																if (20 >= b)
																{
																	goto IL_0ba7_2;
																}
																goto IL_0cf3_2;
																IL_0ba7_2:
																if (20 <= b)
																{
																	goto IL_0bb2_2;
																}
																goto IL_0c03_2;
																IL_0bb2_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0bcb_2;
																IL_0bcb_2:
																array2[num6] = 1;
																num = 210;
																goto IL_0be2_2;
																IL_0be2_2:
																num6++;
																goto IL_0bf0_2;
																IL_0bf0_2:
																ptr2 += 16;
																goto IL_0d99_2;
																IL_0c03_2:
																if (18 >= b)
																{
																	goto IL_0c0e_2;
																}
																goto IL_0c78_2;
																IL_0c0e_2:
																if (18 > b)
																{
																	num = 22;
																	goto end_IL_03b4_2;
																}
																goto IL_0c19_2;
																IL_0c19_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0c57_2;
																IL_0c57_2:
																num6 -= 3;
																goto IL_0d99_2;
																IL_0d38_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0d99_2;
																IL_0c78_2:
																if (19 < b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0c86_2;
																IL_0c86_2:
																if (19 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0c94_2;
																IL_0c94_2:
																array2[num6 - 1] = 5;
																goto IL_0ca8_2;
																IL_0ca8_2:
																array3[num6 - 1] = ((delegate*<string[], string>)SerializationInvalidOnDeserUtcDateTime[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0ce0_2;
																IL_0ce0_2:
																ptr2 += 8;
																goto IL_0d99_2;
																IL_0cf3_2:
																if (21 < b)
																{
																	goto IL_0cfe_2;
																}
																goto IL_0d2d_2;
																IL_0cfe_2:
																if (22 < b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0d09_2;
																IL_0d09_2:
																if (22 > b)
																{
																	goto end_IL_03b4_2;
																}
																goto IL_0d14_2;
																IL_0d14_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																goto IL_0d99_2;
																continue;
																end_IL_03a4:
																break;
															}
															continue;
															end_IL_03b4_2:
															break;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													num = 88;
													goto IL_0d6f_2;
													IL_0d8b_2:
													ptr2 += 8;
													goto IL_0d99_2;
													IL_0d7d_2:
													num6++;
													goto IL_0d8b_2;
													IL_0d6f_2:
													array2[num6] = 0;
													goto IL_0d7d_2;
													continue;
													end_IL_03c4_2:
													break;
												}
												continue;
												end_IL_03d4:
												break;
											}
											continue;
											end_IL_03ed:
											break;
										}
										break;
									}
									goto IL_0e70_2;
									IL_0e70_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_09e4:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class113()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_7, int int_8)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_7;
									num = 72;
									while (true)
									{
										array3[1] = int_8;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getInvalidHandleObjectCreationDelegate.FormKDDisallowUnassignedRefusedSet);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02bb:
																	if (b >= 1)
																	{
																		goto IL_019e;
																	}
																	goto IL_028a;
																	IL_028a:
																	while (true)
																	{
																		IL_028a_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 95;
																		while (true)
																		{
																			if (num != 95)
																			{
																				if (num != 1076)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 73:
																					goto IL_019e;
																				case 41:
																					goto IL_01ac;
																				case 11:
																				case 27:
																					goto IL_01b7;
																				case 2:
																					goto IL_01c5;
																				case 46:
																					goto IL_01d0;
																				case 67:
																					goto IL_01ee;
																				case 32:
																					goto IL_01fc;
																				case 13:
																					goto IL_0207;
																				case 30:
																					goto IL_0212;
																				case 33:
																					goto IL_0222;
																				case 75:
																					goto IL_0230;
																				case 36:
																					goto IL_023b;
																				case 66:
																				case 78:
																					goto IL_0248;
																				case 15:
																					goto IL_0253;
																				case 83:
																					goto IL_0263;
																				case 7:
																				case 23:
																					goto IL_0271;
																				case 87:
																					goto IL_027c;
																				case 0:
																				case 1:
																				case 10:
																				case 16:
																				case 18:
																				case 29:
																				case 34:
																				case 45:
																				case 54:
																				case 55:
																				case 58:
																				case 59:
																				case 62:
																				case 70:
																				case 74:
																				case 76:
																				case 79:
																					goto IL_028a_2;
																				case 71:
																					goto IL_02bb;
																				case 63:
																					goto end_IL_02bb;
																				case 12:
																				case 88:
																					goto end_IL_02cb;
																				case 14:
																				case 17:
																					goto IL_02e6;
																				case 39:
																					goto IL_02f4;
																				case 20:
																					goto IL_0317;
																				case 47:
																					goto IL_0321;
																				case 31:
																					goto IL_032f;
																				case 38:
																				case 65:
																					goto end_IL_018b;
																				case 3:
																					goto IL_038b;
																				case 64:
																					goto IL_039f;
																				case 26:
																				case 50:
																					goto IL_03b2;
																				case 52:
																					goto IL_0429;
																				case 35:
																				case 56:
																					goto IL_043c;
																				case 42:
																				case 86:
																					goto IL_0461;
																				case 68:
																					goto IL_0493;
																				case 25:
																					goto IL_04a1;
																				case 19:
																				case 53:
																					goto IL_04b1;
																				case 60:
																					goto IL_04dd;
																				case 22:
																					goto IL_04eb;
																				case 5:
																				case 6:
																				case 21:
																				case 24:
																				case 40:
																				case 48:
																				case 69:
																				case 77:
																				case 80:
																				case 82:
																				case 85:
																					goto end_IL_02db;
																				case 61:
																					goto end_IL_04f9;
																				case 84:
																					goto end_IL_050c;
																				case 72:
																					goto end_IL_0516;
																				case 28:
																					goto end_IL_0521;
																				case 51:
																					goto end_IL_0536;
																				case 43:
																				case 49:
																					goto end_IL_0554;
																				case 57:
																					goto end_IL_0564;
																				case 4:
																				case 81:
																					goto end_IL_0574;
																				case 8:
																					goto end_IL_0584;
																				case 9:
																					goto end_IL_0594;
																				case 37:
																				case 44:
																					goto IL_05af;
																				}
																				continue;
																			}
																			array[num5] = 0;
																			goto IL_04dd;
																			IL_04dd:
																			num5++;
																			goto IL_04eb;
																			IL_04eb:
																			ptr2 += 8;
																			goto end_IL_02db;
																			continue;
																			end_IL_018b:
																			break;
																		}
																		break;
																	}
																	goto IL_034b;
																	IL_019e:
																	if (b <= 8)
																	{
																		goto IL_01ac;
																	}
																	goto IL_028a;
																	IL_01ac:
																	if (4 < b)
																	{
																		goto IL_01b7;
																	}
																	goto IL_01ee;
																	IL_01b7:
																	if (6 < b)
																	{
																		goto IL_01c5;
																	}
																	goto IL_0263;
																	IL_01c5:
																	if (7 >= b)
																	{
																		goto IL_01d0;
																	}
																	num = 78;
																	goto IL_0248;
																	IL_01d0:
																	if (7 > b)
																	{
																		goto IL_028a;
																	}
																	goto IL_02e6;
																	IL_02e6:
																	array[num5] = 0;
																	goto IL_02f4;
																	IL_02f4:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0317;
																	IL_0317:
																	array2[num5] = null;
																	goto IL_0321;
																	IL_0321:
																	num5++;
																	goto IL_032f;
																	IL_032f:
																	ptr2 += 8;
																	num = 69;
																	goto end_IL_02db;
																	IL_04a1:
																	num5--;
																	goto end_IL_02db;
																	IL_0248:
																	if (8 >= b)
																	{
																		goto IL_0253;
																	}
																	goto IL_028a;
																	IL_0253:
																	if (8 > b)
																	{
																		goto IL_028a;
																	}
																	goto IL_043c;
																	IL_043c:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	num = 48;
																	goto end_IL_02db;
																	IL_0263:
																	if (6 <= b)
																	{
																		goto end_IL_02db;
																	}
																	goto IL_0271;
																	IL_0271:
																	if (5 >= b)
																	{
																		goto IL_027c;
																	}
																	goto IL_028a;
																	IL_027c:
																	if (5 > b)
																	{
																		goto IL_028a;
																	}
																	goto IL_04b1;
																	IL_04b1:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 21;
																	goto end_IL_02db;
																	IL_01ee:
																	if (4 > b)
																	{
																		goto IL_01fc;
																	}
																	goto IL_0461;
																	IL_01fc:
																	if (2 < b)
																	{
																		goto IL_0207;
																	}
																	goto IL_0222;
																	IL_0207:
																	if (3 >= b)
																	{
																		goto IL_0212;
																	}
																	goto IL_028a;
																	IL_0212:
																	if (3 > b)
																	{
																		goto IL_028a;
																	}
																	goto IL_034b;
																	IL_034b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_038b;
																	IL_038b:
																	array[num5 - 2] = 0;
																	goto IL_039f;
																	IL_039f:
																	num5--;
																	goto end_IL_02db;
																	IL_0222:
																	if (2 > b)
																	{
																		goto IL_0230;
																	}
																	goto IL_03b2;
																	IL_0230:
																	if (1 >= b)
																	{
																		goto IL_023b;
																	}
																	goto IL_028a;
																	IL_023b:
																	if (1 <= b)
																	{
																	}
																	goto IL_028a;
																	IL_03b2:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	num = 52;
																	goto IL_0429;
																	IL_0429:
																	num5 -= 2;
																	goto end_IL_02db;
																	IL_0461:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 68;
																	goto IL_0493;
																	IL_0493:
																	ptr2 += 8;
																	goto IL_04a1;
																	continue;
																	end_IL_02bb:
																	break;
																}
																continue;
																end_IL_02cb:
																break;
															}
															continue;
															end_IL_02db:
															break;
														}
														continue;
													}
													goto IL_05af;
													IL_05af:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f9:
													break;
												}
												continue;
												end_IL_050c:
												break;
											}
											continue;
											end_IL_0516:
											break;
										}
										continue;
										end_IL_0521:
										break;
									}
									continue;
									end_IL_0536:
									break;
								}
								continue;
								end_IL_0554:
								break;
							}
							continue;
							end_IL_0564:
							break;
						}
						continue;
						end_IL_0574:
						break;
					}
					continue;
					end_IL_0584:
					break;
				}
				continue;
				end_IL_0594:
				break;
			}
		}
	}

	private static int smethod_14(int int_7)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num6;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_7;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_7;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 198;
		num6 = 11;
		num4 = 18;
		num6 = 49;
		num6 = 7;
		int num7 = smethod_15(18, 7);
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_15(int int_7, int int_8)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 24;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_7;
									while (true)
									{
										array3[1] = int_8;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StructuralComparisonsLastSubNodeType.NumberSharedState);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0297:
															num = 15;
															while (true)
															{
																IL_028c:
																byte b = *ptr2;
																while (true)
																{
																	IL_027c:
																	ptr2++;
																	while (true)
																	{
																		IL_026c:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_024c:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_023c:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_022f:
																									if (2 < b)
																									{
																										while (3 >= b)
																										{
																											while (3 <= b)
																											{
																												while (true)
																												{
																													IL_01cd:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_01b7:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_019e:
																															num5--;
																															num = 95;
																															while (num != 95)
																															{
																																if (num != 1076)
																																{
																																	goto IL_040c;
																																}
																																switch (num)
																																{
																																case 10:
																																	goto IL_019e;
																																case 62:
																																	goto IL_01b7;
																																case 29:
																																case 81:
																																	goto IL_01cd;
																																case 59:
																																	goto IL_020f;
																																case 2:
																																case 7:
																																	goto IL_021f;
																																case 80:
																																case 84:
																																	goto IL_022f;
																																case 14:
																																	goto IL_023c;
																																case 73:
																																	goto IL_024c;
																																case 58:
																																	goto IL_025c;
																																case 76:
																																	goto IL_026c;
																																case 71:
																																	goto IL_027c;
																																case 15:
																																	goto IL_028c;
																																case 5:
																																	goto IL_0297;
																																case 17:
																																	goto IL_02a2;
																																case 12:
																																case 16:
																																	goto IL_02ad;
																																case 69:
																																	goto IL_02c4;
																																case 23:
																																case 64:
																																	goto IL_02e0;
																																case 48:
																																	goto IL_034e;
																																case 45:
																																case 85:
																																	goto IL_036a;
																																case 18:
																																	goto IL_0393;
																																case 66:
																																	goto IL_03a1;
																																case 79:
																																	goto IL_03b4;
																																case 46:
																																	goto IL_03bf;
																																case 61:
																																	goto IL_03cd;
																																case 38:
																																	goto IL_03db;
																																case 37:
																																case 41:
																																	goto IL_03e9;
																																case 19:
																																	goto IL_0401;
																																case 11:
																																case 52:
																																	goto IL_040c;
																																case 67:
																																	goto IL_041a;
																																case 31:
																																case 83:
																																	goto IL_0428;
																																case 50:
																																	goto IL_0444;
																																case 39:
																																case 44:
																																	goto IL_044f;
																																case 53:
																																	goto IL_045d;
																																case 63:
																																	goto IL_0480;
																																case 6:
																																	goto IL_048a;
																																case 27:
																																	goto IL_0498;
																																case 0:
																																case 13:
																																case 22:
																																case 26:
																																case 28:
																																case 33:
																																case 34:
																																case 35:
																																case 49:
																																case 54:
																																case 55:
																																case 65:
																																case 70:
																																case 82:
																																case 86:
																																case 88:
																																	goto end_IL_020f;
																																case 20:
																																	goto IL_04cb;
																																case 87:
																																	goto IL_04d9;
																																case 77:
																																	goto IL_04e7;
																																case 1:
																																case 21:
																																case 25:
																																case 30:
																																case 36:
																																case 42:
																																case 43:
																																case 68:
																																case 72:
																																case 78:
																																	goto end_IL_018b;
																																case 57:
																																	goto end_IL_04f5;
																																case 75:
																																	goto end_IL_0508;
																																case 32:
																																	goto end_IL_0512;
																																case 8:
																																	goto end_IL_051d;
																																case 9:
																																	goto end_IL_0532;
																																case 24:
																																case 60:
																																	goto end_IL_0547;
																																case 74:
																																	goto end_IL_0557;
																																case 40:
																																case 51:
																																	goto end_IL_0567;
																																case 3:
																																	goto end_IL_0580;
																																case 4:
																																	goto end_IL_0590;
																																case 47:
																																case 56:
																																	goto IL_05ab;
																																}
																																continue;
																																end_IL_018b:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_026c;
																												continue;
																												end_IL_020f:
																												break;
																												IL_020f:;
																											}
																											break;
																											IL_021f:;
																										}
																										break;
																									}
																									goto IL_02a2;
																									IL_034e:
																									num5 -= 2;
																									num = 68;
																									goto end_IL_026c;
																									IL_02a2:
																									if (2 > b)
																									{
																										goto IL_02ad;
																									}
																									goto IL_02e0;
																									IL_02ad:
																									if (1 < b)
																									{
																										break;
																									}
																									num = 69;
																									goto IL_02c4;
																									IL_02e0:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_034e;
																									IL_02c4:
																									if (1 > b)
																									{
																										num = 28;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_036a;
																							IL_03a1:
																							num5--;
																							goto end_IL_026c;
																							IL_036a:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0393;
																							IL_0393:
																							ptr2 += 8;
																							goto IL_03a1;
																						}
																						break;
																					}
																					goto IL_03b4;
																					IL_0498:
																					ptr2 += 8;
																					goto end_IL_026c;
																					IL_03b4:
																					if (6 >= b)
																					{
																						goto IL_03bf;
																					}
																					goto IL_0401;
																					IL_03bf:
																					if (6 <= b)
																					{
																						goto end_IL_026c;
																					}
																					goto IL_03cd;
																					IL_03cd:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_03db;
																					IL_03db:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_03e9;
																					IL_03e9:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_026c;
																					IL_0401:
																					if (7 < b)
																					{
																						goto IL_040c;
																					}
																					goto IL_0444;
																					IL_040c:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_041a;
																					IL_041a:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0428;
																					IL_0428:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_026c;
																					IL_0444:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_044f;
																					IL_044f:
																					array[num5] = 0;
																					goto IL_045d;
																					IL_045d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0480;
																					IL_0480:
																					array2[num5] = null;
																					goto IL_048a;
																					IL_048a:
																					num5++;
																					goto IL_0498;
																				}
																				break;
																				IL_025c:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04cb;
																		IL_04e7:
																		ptr2 += 8;
																		break;
																		IL_04d9:
																		num5++;
																		goto IL_04e7;
																		IL_04cb:
																		array[num5] = 0;
																		goto IL_04d9;
																		continue;
																		end_IL_026c:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05ab;
													IL_05ab:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f5:
													break;
												}
												continue;
												end_IL_0508:
												break;
											}
											continue;
											end_IL_0512:
											break;
										}
										continue;
										end_IL_051d:
										break;
									}
									continue;
									end_IL_0532:
									break;
								}
								continue;
								end_IL_0547:
								break;
							}
							continue;
							end_IL_0557:
							break;
						}
						continue;
						end_IL_0567:
						break;
					}
					continue;
					end_IL_0580:
					break;
				}
				continue;
				end_IL_0590:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_7, int int_8)
	{
		int num = 2;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_7;
									while (true)
									{
										array3[1] = int_8;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FeedbackSizeAddConnectAccess.removeReflectionOnlyAssemblyResolveRegistryView);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0245:
															byte b = *ptr2;
															while (true)
															{
																IL_0235:
																ptr2++;
																while (true)
																{
																	IL_0225:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0205:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01f8:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (5 <= b)
																									{
																										while (true)
																										{
																											IL_01aa:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 98;
																											while (num != 98 && num == 1079)
																											{
																												switch (num)
																												{
																												case 57:
																												case 60:
																													goto IL_01aa;
																												case 23:
																													goto IL_01c8;
																												case 39:
																												case 64:
																													goto IL_01d8;
																												case 19:
																													goto IL_01e8;
																												case 11:
																												case 63:
																													goto IL_01f8;
																												case 53:
																													goto IL_0205;
																												case 41:
																													goto IL_0215;
																												case 62:
																													goto IL_0225;
																												case 86:
																													goto IL_0235;
																												case 15:
																												case 68:
																													goto IL_0245;
																												case 4:
																												case 9:
																													goto IL_0250;
																												case 59:
																													goto IL_025b;
																												case 7:
																												case 80:
																													goto IL_0269;
																												case 71:
																													goto IL_0277;
																												case 29:
																													goto IL_02a3;
																												case 85:
																													goto IL_02ad;
																												case 74:
																													goto IL_02bb;
																												case 55:
																												case 89:
																													goto IL_02d7;
																												case 25:
																													goto IL_02e5;
																												case 38:
																												case 61:
																													goto IL_02f3;
																												case 40:
																													goto IL_030f;
																												case 67:
																												case 78:
																													goto IL_031d;
																												case 5:
																												case 14:
																													goto IL_032b;
																												case 90:
																													goto IL_0339;
																												case 32:
																												case 50:
																													goto IL_0347;
																												case 36:
																													goto IL_0387;
																												case 54:
																													goto IL_039b;
																												case 84:
																													goto IL_03b7;
																												case 27:
																												case 65:
																													goto IL_03ce;
																												case 48:
																													goto IL_043c;
																												case 16:
																													goto IL_044f;
																												case 79:
																													goto IL_045a;
																												case 17:
																												case 20:
																												case 24:
																												case 26:
																												case 31:
																												case 34:
																												case 35:
																												case 37:
																												case 45:
																												case 51:
																												case 52:
																												case 58:
																												case 66:
																												case 69:
																												case 75:
																												case 87:
																												case 91:
																													goto end_IL_01c8;
																												case 83:
																													goto IL_0488;
																												case 33:
																													goto IL_049f;
																												case 3:
																													goto IL_04ad;
																												case 8:
																												case 12:
																													goto IL_04bd;
																												case 47:
																													goto IL_04e6;
																												case 72:
																													goto IL_04f4;
																												case 0:
																												case 18:
																												case 21:
																												case 42:
																												case 43:
																												case 44:
																												case 56:
																												case 73:
																												case 77:
																												case 82:
																													goto end_IL_0197;
																												case 22:
																													goto end_IL_0502;
																												case 10:
																													goto end_IL_0515;
																												case 13:
																													goto end_IL_051f;
																												case 70:
																													goto end_IL_052a;
																												case 76:
																													goto end_IL_053f;
																												case 28:
																												case 88:
																													goto end_IL_0554;
																												case 6:
																													goto end_IL_0564;
																												case 46:
																												case 49:
																													goto end_IL_0574;
																												case 1:
																													goto end_IL_0584;
																												case 2:
																													goto end_IL_0594;
																												case 30:
																												case 81:
																													goto IL_05af;
																												}
																												continue;
																												end_IL_0197:
																												break;
																											}
																											break;
																										}
																										goto end_IL_01e8;
																										continue;
																										end_IL_01c8:
																										break;
																										IL_01c8:;
																									}
																									break;
																									IL_01d8:;
																								}
																								goto end_IL_0215;
																								continue;
																								end_IL_01e8:
																								break;
																								IL_01e8:;
																							}
																							break;
																						}
																						goto IL_0250;
																						IL_02f3:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_0250:
																						if (7 >= b)
																						{
																							goto IL_025b;
																						}
																						goto IL_02d7;
																						IL_025b:
																						if (7 > b)
																						{
																							goto end_IL_0215;
																						}
																						goto IL_0269;
																						IL_0269:
																						array[num6] = 0;
																						goto IL_0277;
																						IL_0277:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						num = 29;
																						goto IL_02a3;
																						IL_02a3:
																						array2[num6] = null;
																						goto IL_02ad;
																						IL_02ad:
																						num6++;
																						goto IL_02bb;
																						IL_02bb:
																						ptr2 += 8;
																						num = 82;
																						break;
																						IL_02d7:
																						if (8 < b)
																						{
																							goto end_IL_0215;
																						}
																						goto IL_02e5;
																						IL_02e5:
																						if (8 > b)
																						{
																							goto end_IL_0215;
																						}
																						goto IL_02f3;
																					}
																					break;
																				}
																				goto IL_030f;
																				IL_04e6:
																				ptr2 += 8;
																				goto IL_04f4;
																				IL_030f:
																				if (4 > b)
																				{
																					goto IL_031d;
																				}
																				goto IL_04bd;
																				IL_031d:
																				if (2 < b)
																				{
																					goto IL_032b;
																				}
																				goto IL_03b7;
																				IL_032b:
																				if (3 < b)
																				{
																					goto end_IL_0215;
																				}
																				goto IL_0339;
																				IL_0339:
																				if (3 > b)
																				{
																					goto end_IL_0215;
																				}
																				goto IL_0347;
																				IL_0347:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0387;
																				IL_0387:
																				array[num6 - 2] = 0;
																				goto IL_039b;
																				IL_039b:
																				num6--;
																				num = 43;
																				break;
																				IL_03b7:
																				if (2 <= b)
																				{
																					num = 65;
																					goto IL_03ce;
																				}
																				goto IL_044f;
																				IL_04f4:
																				num6--;
																				break;
																				IL_03ce:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_043c;
																				IL_043c:
																				num6 -= 2;
																				break;
																				IL_044f:
																				if (1 < b)
																				{
																					goto end_IL_0215;
																				}
																				goto IL_045a;
																				IL_045a:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0215;
																				IL_04bd:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04e6;
																			}
																			goto end_IL_0225;
																			continue;
																			end_IL_0215:
																			break;
																			IL_0215:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0488;
																	IL_04ad:
																	ptr2 += 8;
																	break;
																	IL_049f:
																	num6++;
																	goto IL_04ad;
																	IL_0488:
																	array[num6] = 0;
																	num = 33;
																	goto IL_049f;
																	continue;
																	end_IL_0225:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05af;
													IL_05af:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0502:
													break;
												}
												continue;
												end_IL_0515:
												break;
											}
											continue;
											end_IL_051f:
											break;
										}
										continue;
										end_IL_052a:
										break;
									}
									continue;
									end_IL_053f:
									break;
								}
								continue;
								end_IL_0554:
								break;
							}
							continue;
							end_IL_0564:
							break;
						}
						continue;
						end_IL_0574:
						break;
					}
					continue;
					end_IL_0584:
					break;
				}
				continue;
				end_IL_0594:
				break;
			}
		}
	}

	private static int smethod_17(int int_7)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_7;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_7;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_18(int int_7, int int_8)
	{
		int num = 23;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_7;
									while (true)
									{
										array3[1] = int_8;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InternalRMExternalThreading.getTotalDaysISymbolScope);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0254:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0234:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0227:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0217:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0207:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 > b)
																												{
																													num = 109;
																													while (num != 109)
																													{
																														if (num != 1090)
																														{
																															goto end_IL_0254;
																														}
																														switch (num)
																														{
																														case 33:
																															goto IL_01e4;
																														case 10:
																														case 40:
																															goto IL_01f7;
																														case 82:
																															goto IL_0207;
																														case 46:
																															goto IL_0217;
																														case 29:
																															goto IL_0227;
																														case 102:
																															goto IL_0234;
																														case 19:
																															goto IL_0244;
																														case 101:
																															goto IL_0254;
																														case 36:
																															goto end_IL_0254;
																														case 48:
																														case 85:
																															goto end_IL_0264;
																														case 53:
																														case 99:
																															goto IL_027f;
																														case 17:
																															goto IL_028d;
																														case 43:
																															goto IL_02b0;
																														case 13:
																															goto IL_02c3;
																														case 54:
																															goto IL_02d1;
																														case 4:
																														case 89:
																															goto IL_02e4;
																														case 50:
																															goto IL_0324;
																														case 76:
																															goto IL_0341;
																														case 5:
																															goto IL_0354;
																														case 83:
																															goto IL_035f;
																														case 73:
																														case 92:
																															goto IL_036d;
																														case 72:
																															goto IL_0396;
																														case 25:
																															goto IL_03a4;
																														case 62:
																															goto IL_03b7;
																														case 90:
																															goto IL_03d0;
																														case 0:
																														case 70:
																															goto IL_03e9;
																														case 42:
																															goto IL_0432;
																														case 64:
																															goto IL_0446;
																														case 41:
																															goto IL_0462;
																														case 98:
																															goto IL_0470;
																														case 7:
																														case 8:
																															goto IL_047b;
																														case 49:
																															goto IL_0494;
																														case 69:
																															goto IL_04a2;
																														case 52:
																															goto IL_04b0;
																														case 21:
																															goto IL_04c3;
																														case 80:
																															goto IL_04d1;
																														case 34:
																														case 35:
																															goto IL_04df;
																														case 86:
																															goto IL_051f;
																														case 65:
																															goto IL_0533;
																														case 39:
																															goto IL_0546;
																														case 20:
																														case 77:
																															goto IL_0551;
																														case 68:
																															goto IL_0568;
																														case 6:
																														case 14:
																															goto IL_0576;
																														case 57:
																															goto IL_0592;
																														case 37:
																														case 38:
																															goto IL_059d;
																														case 60:
																															goto IL_05dd;
																														case 78:
																															goto IL_05f1;
																														case 2:
																														case 9:
																														case 11:
																														case 12:
																														case 27:
																														case 28:
																														case 30:
																														case 55:
																														case 58:
																														case 59:
																														case 66:
																														case 71:
																														case 75:
																														case 91:
																														case 93:
																														case 97:
																														case 100:
																															goto end_IL_01d1;
																														case 74:
																															goto IL_0624;
																														case 26:
																															goto IL_0632;
																														case 15:
																															goto IL_0649;
																														case 1:
																														case 3:
																														case 18:
																														case 32:
																														case 51:
																														case 61:
																														case 63:
																														case 79:
																														case 81:
																														case 87:
																														case 88:
																															goto end_IL_0274;
																														case 44:
																															goto end_IL_0657;
																														case 95:
																															goto end_IL_066a;
																														case 24:
																															goto end_IL_0674;
																														case 96:
																															goto end_IL_067f;
																														case 16:
																															goto end_IL_0694;
																														case 67:
																														case 84:
																															goto end_IL_06a9;
																														case 31:
																															goto end_IL_06b9;
																														case 47:
																														case 94:
																															goto end_IL_06c9;
																														case 22:
																															goto end_IL_06d9;
																														case 23:
																															goto end_IL_06e9;
																														case 45:
																														case 56:
																															goto IL_070d;
																														}
																														continue;
																														end_IL_01d1:
																														break;
																													}
																													break;
																													IL_01e4:;
																												}
																												break;
																												IL_01f7:;
																											}
																											break;
																										}
																										goto IL_02e4;
																										IL_0341:
																										num5--;
																										goto end_IL_0274;
																										IL_02e4:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0324;
																										IL_0324:
																										array[num5 - 2] = 0;
																										num = 76;
																										goto IL_0341;
																									}
																									break;
																								}
																								goto IL_0354;
																								IL_03e9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 42;
																								goto IL_0432;
																								IL_0354:
																								if (3 >= b)
																								{
																									goto IL_035f;
																								}
																								goto IL_03b7;
																								IL_035f:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_036d;
																								IL_036d:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0396;
																								IL_0396:
																								ptr2 += 8;
																								goto IL_03a4;
																								IL_03a4:
																								num5--;
																								goto end_IL_0274;
																								IL_03b7:
																								if (4 < b)
																								{
																									num = 2;
																									break;
																								}
																								goto IL_03d0;
																								IL_0432:
																								array[num5 - 2] = 0;
																								goto IL_0446;
																								IL_03d0:
																								if (4 > b)
																								{
																									num = 30;
																									break;
																								}
																								goto IL_03e9;
																								IL_0446:
																								num5--;
																								num = 32;
																								goto end_IL_0274;
																							}
																							break;
																						}
																						goto IL_027f;
																						IL_02d1:
																						ptr2 += 8;
																						goto end_IL_0274;
																						IL_027f:
																						array[num5] = 0;
																						goto IL_028d;
																						IL_028d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02b0;
																						IL_02b0:
																						array2[num5] = null;
																						num = 13;
																						goto IL_02c3;
																						IL_02c3:
																						num5++;
																						goto IL_02d1;
																					}
																					break;
																				}
																				goto IL_0462;
																				IL_05dd:
																				array[num5 - 2] = 0;
																				goto IL_05f1;
																				IL_0462:
																				if (7 >= b)
																				{
																					goto IL_0470;
																				}
																				goto IL_0546;
																				IL_0470:
																				if (7 <= b)
																				{
																					goto IL_047b;
																				}
																				goto IL_04c3;
																				IL_047b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0494;
																				IL_0494:
																				array[num5] = 0;
																				goto IL_04a2;
																				IL_04a2:
																				num5++;
																				goto IL_04b0;
																				IL_04b0:
																				ptr2 += 8;
																				goto end_IL_0274;
																				IL_04c3:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_04d1;
																				IL_04d1:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_04df;
																				IL_04df:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_051f;
																				IL_051f:
																				array[num5 - 2] = 0;
																				goto IL_0533;
																				IL_0533:
																				num5--;
																				goto end_IL_0274;
																				IL_0546:
																				if (8 < b)
																				{
																					goto IL_0551;
																				}
																				goto IL_0592;
																				IL_0551:
																				if (9 < b)
																				{
																					break;
																				}
																				num = 68;
																				goto IL_0568;
																				IL_05f1:
																				num5--;
																				goto end_IL_0274;
																				IL_0568:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0576;
																				IL_0576:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0274;
																				IL_0592:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_059d;
																				IL_059d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05dd;
																			}
																			break;
																			IL_0244:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0624;
																	IL_0649:
																	ptr2 += 8;
																	goto end_IL_0274;
																	IL_0632:
																	num5++;
																	num = 15;
																	goto IL_0649;
																	IL_0624:
																	array[num5] = 0;
																	goto IL_0632;
																	continue;
																	end_IL_0254:
																	break;
																}
																continue;
																end_IL_0264:
																break;
															}
															continue;
															end_IL_0274:
															break;
														}
														continue;
													}
													num = 56;
													goto IL_070d;
													IL_070d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0657:
													break;
												}
												continue;
												end_IL_066a:
												break;
											}
											continue;
											end_IL_0674:
											break;
										}
										continue;
										end_IL_067f:
										break;
									}
									continue;
									end_IL_0694:
									break;
								}
								continue;
								end_IL_06a9:
								break;
							}
							continue;
							end_IL_06b9:
							break;
						}
						continue;
						end_IL_06c9:
						break;
					}
					continue;
					end_IL_06d9:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_7, int int_8)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 51;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_7;
									while (true)
									{
										array3[1] = int_8;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RuntimeFieldHandleAddEventHandler.NNFAppObject);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02b8:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_029b:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_028b:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_027b:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_026e:
																										if (3 <= b)
																										{
																											while (true)
																											{
																												IL_0243:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_022a:
																													ptr2 += 8;
																													num = 130;
																													while (true)
																													{
																														if (num != 130)
																														{
																															if (num != 1111)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 36:
																																goto IL_022a;
																															case 37:
																															case 43:
																																goto IL_0243;
																															case 69:
																																goto IL_026e;
																															case 90:
																																goto IL_027b;
																															case 24:
																																goto IL_028b;
																															case 21:
																																goto IL_029b;
																															case 84:
																																goto IL_02a8;
																															case 6:
																																goto IL_02b8;
																															case 96:
																																goto end_IL_02b8;
																															case 119:
																															case 120:
																																goto end_IL_02c8;
																															case 40:
																																goto IL_02e3;
																															case 31:
																																goto IL_02ee;
																															case 50:
																																goto IL_0301;
																															case 2:
																															case 98:
																																goto IL_0314;
																															case 58:
																																goto IL_031f;
																															case 44:
																															case 88:
																																goto IL_032a;
																															case 57:
																															case 80:
																																goto IL_034c;
																															case 14:
																															case 66:
																																goto IL_035a;
																															case 30:
																															case 75:
																																goto IL_0373;
																															case 10:
																																goto IL_037e;
																															case 39:
																																goto IL_038c;
																															case 38:
																															case 94:
																																goto IL_039a;
																															case 97:
																																goto IL_03bf;
																															case 99:
																																goto IL_03d2;
																															case 9:
																															case 47:
																																goto IL_03e0;
																															case 56:
																																goto IL_0420;
																															case 79:
																																goto IL_0434;
																															case 107:
																																goto IL_0447;
																															case 46:
																																goto IL_049b;
																															case 41:
																																goto IL_04a9;
																															case 110:
																																goto IL_04bc;
																															case 0:
																															case 82:
																																goto IL_04ca;
																															case 7:
																																goto IL_04e3;
																															case 3:
																																goto IL_04f1;
																															case 70:
																																goto IL_04ff;
																															case 28:
																															case 116:
																																goto IL_0512;
																															case 122:
																																goto IL_0525;
																															case 54:
																															case 60:
																																goto IL_0530;
																															case 5:
																																goto IL_0570;
																															case 86:
																																goto IL_0584;
																															case 35:
																																goto IL_05b8;
																															case 34:
																															case 109:
																																goto IL_05c3;
																															case 55:
																																goto IL_05d1;
																															case 25:
																															case 92:
																																goto IL_05df;
																															case 29:
																																goto IL_05ed;
																															case 17:
																																goto IL_0610;
																															case 111:
																																goto IL_061a;
																															case 59:
																																goto IL_0628;
																															case 67:
																																goto IL_063b;
																															case 42:
																															case 103:
																																goto IL_0654;
																															case 95:
																																goto IL_0694;
																															case 13:
																																goto IL_06b1;
																															case 11:
																															case 112:
																																goto IL_06c4;
																															case 1:
																																goto IL_0704;
																															case 83:
																																goto IL_0718;
																															case 4:
																															case 8:
																															case 12:
																															case 15:
																															case 18:
																															case 20:
																															case 27:
																															case 32:
																															case 45:
																															case 61:
																															case 62:
																															case 64:
																															case 68:
																															case 77:
																															case 85:
																															case 91:
																															case 101:
																															case 106:
																															case 108:
																															case 113:
																															case 114:
																															case 121:
																															case 123:
																																goto end_IL_0217;
																															case 16:
																																goto IL_074b;
																															case 53:
																																goto IL_0762;
																															case 78:
																																goto IL_0770;
																															case 23:
																															case 33:
																															case 48:
																															case 52:
																															case 63:
																															case 73:
																															case 74:
																															case 76:
																															case 81:
																															case 89:
																															case 93:
																															case 100:
																															case 104:
																																goto end_IL_02d8;
																															case 19:
																																goto end_IL_077e;
																															case 102:
																																goto end_IL_0791;
																															case 87:
																																goto end_IL_079b;
																															case 26:
																																goto end_IL_07a6;
																															case 22:
																																goto end_IL_07bb;
																															case 115:
																															case 117:
																																goto end_IL_07d0;
																															case 51:
																																goto end_IL_07e0;
																															case 49:
																															case 65:
																																goto end_IL_07f0;
																															case 71:
																																goto end_IL_0800;
																															case 72:
																																goto end_IL_0819;
																															case 105:
																															case 118:
																																goto IL_0834;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02d8;
																														continue;
																														end_IL_0217:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02e3;
																										IL_0584:
																										num5--;
																										goto end_IL_02d8;
																										IL_02e3:
																										if (1 >= b)
																										{
																											goto IL_02ee;
																										}
																										goto IL_0301;
																										IL_02ee:
																										if (1 > b)
																										{
																										}
																										break;
																										IL_0301:
																										if (2 < b)
																										{
																											break;
																										}
																										goto IL_0525;
																										IL_0525:
																										if (2 > b)
																										{
																											num = 64;
																											break;
																										}
																										goto IL_0530;
																										IL_0530:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0570;
																										IL_0570:
																										array[num5 - 2] = 0;
																										goto IL_0584;
																									}
																									break;
																								}
																								goto IL_05b8;
																								IL_0694:
																								array[num5 - 2] = 0;
																								num = 13;
																								goto IL_06b1;
																								IL_05b8:
																								if (4 < b)
																								{
																									goto IL_05c3;
																								}
																								goto IL_063b;
																								IL_05c3:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_05d1;
																								IL_05d1:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_05df;
																								IL_05df:
																								array[num5] = 0;
																								goto IL_05ed;
																								IL_05ed:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0610;
																								IL_0610:
																								array2[num5] = null;
																								goto IL_061a;
																								IL_061a:
																								num5++;
																								goto IL_0628;
																								IL_0628:
																								ptr2 += 8;
																								goto end_IL_02d8;
																								IL_063b:
																								if (4 > b)
																								{
																									num = 45;
																									break;
																								}
																								goto IL_0654;
																								IL_06b1:
																								num5--;
																								goto end_IL_02d8;
																								IL_0654:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0694;
																							}
																							break;
																						}
																						goto IL_06c4;
																						IL_0718:
																						num5--;
																						goto end_IL_02d8;
																						IL_06c4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0704;
																						IL_0704:
																						array[num5 - 2] = 0;
																						goto IL_0718;
																					}
																					break;
																				}
																				goto IL_0314;
																				IL_039a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02d8;
																				IL_0314:
																				if (9 >= b)
																				{
																					goto IL_031f;
																				}
																				num = 75;
																				goto IL_0373;
																				IL_031f:
																				if (9 <= b)
																				{
																					goto IL_032a;
																				}
																				num = 57;
																				goto IL_034c;
																				IL_032a:
																				array[num5 - 2] = 0;
																				goto IL_0447;
																				IL_0447:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)EnablePropertyLocalFindAndPop[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_049b;
																				IL_049b:
																				num5--;
																				goto IL_04a9;
																				IL_04a9:
																				ptr2 += 8;
																				goto end_IL_02d8;
																				IL_03bf:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0512;
																				IL_034c:
																				if (7 < b)
																				{
																					goto IL_035a;
																				}
																				goto IL_04bc;
																				IL_035a:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03d2;
																				IL_03d2:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03e0;
																				IL_03e0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0420;
																				IL_0420:
																				array[num5 - 2] = 0;
																				goto IL_0434;
																				IL_0434:
																				num5--;
																				goto end_IL_02d8;
																				IL_04bc:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04ca;
																				IL_04ca:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04e3;
																				IL_04e3:
																				array[num5] = 0;
																				goto IL_04f1;
																				IL_04f1:
																				num5++;
																				goto IL_04ff;
																				IL_04ff:
																				ptr2 += 8;
																				goto end_IL_02d8;
																				IL_0512:
																				num5--;
																				goto end_IL_02d8;
																				IL_0373:
																				if (10 < b)
																				{
																					goto IL_037e;
																				}
																				num = 97;
																				goto IL_03bf;
																				IL_037e:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_038c;
																				IL_038c:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_039a;
																			}
																			break;
																			IL_02a8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_074b;
																	IL_0770:
																	ptr2 += 8;
																	goto end_IL_02d8;
																	IL_0762:
																	num5++;
																	goto IL_0770;
																	IL_074b:
																	array[num5] = 0;
																	num = 53;
																	goto IL_0762;
																	continue;
																	end_IL_02b8:
																	break;
																}
																continue;
																end_IL_02c8:
																break;
															}
															continue;
															end_IL_02d8:
															break;
														}
														continue;
													}
													goto IL_0834;
													IL_0834:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_077e:
													break;
												}
												continue;
												end_IL_0791:
												break;
											}
											continue;
											end_IL_079b:
											break;
										}
										continue;
										end_IL_07a6:
										break;
									}
									continue;
									end_IL_07bb:
									break;
								}
								continue;
								end_IL_07d0:
								break;
							}
							continue;
							end_IL_07e0:
							break;
						}
						continue;
						end_IL_07f0:
						break;
					}
					continue;
					end_IL_0800:
					break;
				}
				continue;
				end_IL_0819:
				break;
			}
		}
	}

	private static int smethod_20(int int_7)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_7;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 69;
		num4 = 23;
		int num5 = smethod_16(23, 6);
		num4 = num5;
		return num;
	}

	static Class113()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 14;
				while (true)
				{
					if (num == 14 || num != 995)
					{
						return;
					}
					switch (num)
					{
					case 2:
						goto end_IL_0041;
					case 3:
						goto end_IL_004e;
					case 0:
						return;
					case 1:
						return;
					case 4:
						return;
					case 5:
						return;
					case 6:
						return;
					case 7:
						return;
					}
					continue;
					end_IL_0041:
					break;
				}
				continue;
				end_IL_004e:
				break;
			}
		}
	}
}
