using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Stilt Extendo Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns extendo stilts.", false, 5, ModType.const_0, false)]
internal class Class104 : Class93
{
	private static double double_1;

	private static bool bool_0;

	private static bool bool_1;

	private static double double_2;

	private static int int_3;

	private static IntPtr[] IsTransientgetBufferWidth;

	private static IntPtr[] ControlPrincipalLoadedAssembly;

	private static IntPtr[] FUNCFLAGFUIDEFAULTText;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0369, IL_037c, IL_038f, IL_039f, IL_03af, IL_03bf, IL_03cf, IL_03dc, IL_03ec, IL_03fc, IL_040c, IL_0417, IL_0420, IL_042e, IL_043c, IL_044a, IL_0458, IL_0463, IL_0471, IL_0484, IL_0492, IL_04ac, IL_04f1, IL_0508, IL_051b, IL_0526, IL_0531, IL_0544, IL_054f, IL_0562, IL_0570, IL_0583, IL_058e, IL_059c, IL_05dc, IL_05f5, IL_0603, IL_0611, IL_0678, IL_06b8, IL_06cc, IL_06df, IL_071f, IL_0733, IL_0746, IL_078f, IL_07a3, IL_07b6, IL_07c9, IL_07dc, IL_07ea, IL_07f8, IL_0806, IL_0814, IL_0840, IL_084a, IL_0858, IL_086b, IL_0879, IL_08a2, IL_08b0, IL_08c3, IL_08d7, IL_08ea, IL_08f8, IL_0919, IL_0940, IL_0964, IL_097c, IL_0998, IL_09a6, IL_09cf, IL_09e8, IL_09f1, IL_09ff, IL_0a0d, IL_0a1b, IL_0a38, IL_0a87, IL_0a91, IL_0abe, IL_0adb, IL_0ae9, IL_0afc, IL_0b1a, IL_0b28, IL_0b3b, IL_0b46, IL_0b51, IL_0b5f, IL_0b6d, IL_0b89, IL_0b97, IL_0baf, IL_0bba, IL_0bd3, IL_0bea, IL_0bf8, IL_0c0b, IL_0c16, IL_0c24, IL_0c62, IL_0c75, IL_0c80, IL_0c8b, IL_0c9f, IL_0cd7, IL_0ce7, IL_0d00, IL_0d0e, IL_0d1c, IL_0d33, IL_0d46, IL_0d51, IL_0d5b, IL_0d66, IL_0d76, IL_0d86, IL_0d96, IL_0da6, IL_0db6, IL_0dc6, IL_0dd6, IL_0de6, IL_0e01 are reachable both inside and outside the pinned region starting at IL_0dfb. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 32;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				int __rxRef10 = default(int);
				ref int reference = ref __rxRef10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0de6:
						num2 = 1;
						while (true)
						{
							IL_0dd6:
							num3 = num2 * 4;
							while (true)
							{
								IL_0dc6:
								num4 = num2 * 8;
								while (true)
								{
									IL_0db6:
									array2 = new byte[4];
									while (true)
									{
										IL_0da6:
										array3 = new object[4];
										while (true)
										{
											IL_0d96:
											array4 = new int[4];
											while (true)
											{
												IL_0d86:
												array5 = new int[6];
												while (true)
												{
													IL_0d76:
													array6 = new long[4];
													while (true)
													{
														IL_0d66:
														array7 = new object[13];
														while (true)
														{
															IL_0d5b:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllCulturesUntrusted.SetIterationContextPEFileKinds);
															while (true)
															{
																IL_0d51:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d46:
																	num = 95;
																	while (true)
																	{
																		IL_0d33:
																		if (num5 != 1)
																		{
																			while (true)
																			{
																				IL_040c:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_03fc:
																					ptr2++;
																					while (true)
																					{
																						IL_03ec:
																						if (b >= 1)
																						{
																							while (b <= 21)
																							{
																								while (true)
																								{
																									IL_03cf:
																									if (11 < b)
																									{
																										while (true)
																										{
																											IL_03bf:
																											if (16 >= b)
																											{
																												while (true)
																												{
																													IL_03af:
																													if (16 > b)
																													{
																														while (true)
																														{
																															IL_039f:
																															if (13 < b)
																															{
																																while (true)
																																{
																																	IL_038f:
																																	if (14 < b)
																																	{
																																		while (15 >= b)
																																		{
																																			num = 211;
																																			while (true)
																																			{
																																				if (num != 211)
																																				{
																																					if (num != 1192)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 32:
																																						break;
																																					default:
																																						continue;
																																					case 7:
																																					case 41:
																																						goto IL_037c;
																																					case 112:
																																						goto IL_038f;
																																					case 190:
																																						goto IL_039f;
																																					case 123:
																																						goto IL_03af;
																																					case 173:
																																						goto IL_03bf;
																																					case 65:
																																						goto IL_03cf;
																																					case 111:
																																						goto IL_03dc;
																																					case 54:
																																						goto IL_03ec;
																																					case 177:
																																						goto IL_03fc;
																																					case 39:
																																					case 145:
																																						goto IL_040c;
																																					case 126:
																																						goto IL_0420;
																																					case 68:
																																					case 91:
																																						goto IL_042e;
																																					case 97:
																																						goto IL_043c;
																																					case 110:
																																					case 117:
																																						goto IL_044a;
																																					case 51:
																																						goto IL_0458;
																																					case 93:
																																						goto IL_0463;
																																					case 52:
																																						goto IL_0471;
																																					case 89:
																																					case 132:
																																						goto IL_0484;
																																					case 120:
																																						goto IL_0492;
																																					case 21:
																																					case 137:
																																						goto IL_04ac;
																																					case 149:
																																						goto IL_04f1;
																																					case 15:
																																						goto IL_0508;
																																					case 170:
																																						goto IL_051b;
																																					case 18:
																																						goto IL_0526;
																																					case 82:
																																					case 139:
																																						goto IL_0531;
																																					case 3:
																																						goto IL_0544;
																																					case 6:
																																						goto IL_054f;
																																					case 87:
																																						goto IL_0562;
																																					case 38:
																																						goto IL_0570;
																																					case 131:
																																					case 180:
																																						goto IL_0583;
																																					case 158:
																																						goto IL_058e;
																																					case 67:
																																					case 162:
																																						goto IL_059c;
																																					case 101:
																																						goto IL_05dc;
																																					case 176:
																																						goto IL_05f5;
																																					case 71:
																																						goto IL_0603;
																																					case 20:
																																					case 40:
																																						goto IL_0611;
																																					case 156:
																																					case 181:
																																						goto IL_0678;
																																					case 160:
																																						goto IL_06b8;
																																					case 94:
																																						goto IL_06cc;
																																					case 49:
																																					case 188:
																																						goto IL_06df;
																																					case 0:
																																						goto IL_071f;
																																					case 9:
																																						goto IL_0733;
																																					case 178:
																																					case 191:
																																						goto IL_0746;
																																					case 96:
																																						goto IL_078f;
																																					case 186:
																																						goto IL_07a3;
																																					case 195:
																																						goto IL_07b6;
																																					case 198:
																																						goto IL_07c9;
																																					case 104:
																																					case 199:
																																						goto IL_07dc;
																																					case 163:
																																					case 187:
																																						goto IL_07ea;
																																					case 125:
																																						goto IL_07f8;
																																					case 2:
																																					case 116:
																																						goto IL_0806;
																																					case 53:
																																						goto IL_0814;
																																					case 69:
																																						goto end_IL_0369;
																																					case 83:
																																						goto IL_084a;
																																					case 148:
																																						goto IL_0858;
																																					case 36:
																																						goto IL_086b;
																																					case 133:
																																					case 169:
																																						goto IL_0879;
																																					case 140:
																																						goto IL_08a2;
																																					case 10:
																																						goto IL_08b0;
																																					case 201:
																																						goto IL_08c3;
																																					case 60:
																																						goto IL_08d7;
																																					case 8:
																																					case 161:
																																						goto IL_08f8;
																																					case 146:
																																						goto IL_0919;
																																					case 143:
																																						goto IL_0940;
																																					case 84:
																																						goto IL_0964;
																																					case 109:
																																						goto IL_097c;
																																					case 25:
																																						goto IL_0998;
																																					case 58:
																																					case 184:
																																						goto IL_09a6;
																																					case 24:
																																						goto IL_09cf;
																																					case 141:
																																						goto IL_09f1;
																																					case 105:
																																					case 124:
																																						goto IL_09ff;
																																					case 203:
																																						goto IL_0a0d;
																																					case 37:
																																					case 79:
																																						goto IL_0a1b;
																																					case 35:
																																						goto IL_0adb;
																																					case 29:
																																						goto IL_0ae9;
																																					case 63:
																																					case 168:
																																						goto IL_0afc;
																																					case 12:
																																						goto IL_0b1a;
																																					case 147:
																																						goto IL_0b28;
																																					case 77:
																																						goto IL_0b3b;
																																					case 55:
																																					case 62:
																																						goto IL_0b46;
																																					case 106:
																																						goto IL_0b51;
																																					case 138:
																																						goto IL_0b5f;
																																					case 152:
																																					case 185:
																																						goto IL_0b6d;
																																					case 100:
																																						goto IL_0b89;
																																					case 26:
																																					case 114:
																																						goto IL_0b97;
																																					case 134:
																																						goto IL_0baf;
																																					case 108:
																																					case 189:
																																						goto IL_0bba;
																																					case 121:
																																						goto IL_0bd3;
																																					case 153:
																																						goto IL_0bea;
																																					case 92:
																																						goto IL_0bf8;
																																					case 80:
																																						goto IL_0c0b;
																																					case 154:
																																						goto IL_0c16;
																																					case 28:
																																					case 122:
																																						goto IL_0c24;
																																					case 200:
																																						goto IL_0c62;
																																					case 30:
																																						goto IL_0c75;
																																					case 19:
																																						goto IL_0c80;
																																					case 57:
																																					case 204:
																																						goto IL_0c8b;
																																					case 1:
																																						goto IL_0c9f;
																																					case 167:
																																						goto IL_0cd7;
																																					case 4:
																																					case 5:
																																					case 16:
																																					case 22:
																																					case 23:
																																					case 33:
																																					case 43:
																																					case 45:
																																					case 50:
																																					case 56:
																																					case 59:
																																					case 64:
																																					case 66:
																																					case 70:
																																					case 73:
																																					case 74:
																																					case 90:
																																					case 98:
																																					case 102:
																																					case 103:
																																					case 107:
																																					case 113:
																																					case 115:
																																					case 128:
																																					case 129:
																																					case 144:
																																					case 150:
																																					case 155:
																																					case 165:
																																					case 171:
																																					case 174:
																																					case 175:
																																					case 179:
																																					case 182:
																																					case 192:
																																					case 196:
																																					case 197:
																																						goto end_IL_037c;
																																					case 99:
																																						goto IL_0d00;
																																					case 164:
																																						goto IL_0d0e;
																																					case 14:
																																						goto IL_0d1c;
																																					case 11:
																																					case 13:
																																					case 42:
																																					case 48:
																																					case 61:
																																					case 72:
																																					case 75:
																																					case 81:
																																					case 85:
																																					case 86:
																																					case 95:
																																					case 118:
																																					case 127:
																																					case 130:
																																					case 135:
																																					case 136:
																																					case 142:
																																					case 151:
																																					case 157:
																																					case 166:
																																					case 172:
																																					case 183:
																																					case 193:
																																						goto IL_0d33;
																																					case 88:
																																						goto IL_0d46;
																																					case 202:
																																						goto IL_0d51;
																																					case 46:
																																						goto IL_0d5b;
																																					case 78:
																																						goto IL_0d66;
																																					case 27:
																																						goto IL_0d76;
																																					case 194:
																																						goto IL_0d86;
																																					case 47:
																																						goto IL_0d96;
																																					case 34:
																																						goto IL_0da6;
																																					case 76:
																																						goto IL_0db6;
																																					case 44:
																																						goto IL_0dc6;
																																					case 119:
																																						goto IL_0dd6;
																																					case 31:
																																						goto IL_0de6;
																																					case 17:
																																					case 159:
																																						goto IL_0e01;
																																					}
																																					goto end_IL_03ec;
																																				}
																																				if (15 > b)
																																				{
																																					goto end_IL_037c;
																																				}
																																				goto IL_08f8;
																																				IL_0940:
																																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																				goto IL_0964;
																																				IL_097c:
																																				num6++;
																																				num = 157;
																																				goto IL_0d33;
																																				IL_0964:
																																				array3[num6] = array3[num6 - 1];
																																				goto IL_097c;
																																				IL_08f8:
																																				array2[num6] = array2[num6 - 1];
																																				num = 146;
																																				goto IL_0919;
																																				IL_0919:
																																				array4[num6 - 0] = array4[num6 - 1];
																																				num = 143;
																																				goto IL_0940;
																																				continue;
																																				end_IL_0369:
																																				break;
																																			}
																																			goto IL_0840;
																																			continue;
																																			end_IL_037c:
																																			break;
																																			IL_037c:;
																																		}
																																		break;
																																	}
																																	goto IL_0998;
																																	IL_09cf:
																																	array2[num6 - 1] = 5;
																																	goto IL_0d33;
																																	IL_0998:
																																	if (14 > b)
																																	{
																																		break;
																																	}
																																	goto IL_09a6;
																																	IL_09a6:
																																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																	goto IL_09cf;
																																}
																																break;
																															}
																															num = 141;
																															goto IL_09f1;
																															IL_0adb:
																															array2[num6] = 5;
																															goto IL_0ae9;
																															IL_0ae9:
																															num6++;
																															goto IL_0d33;
																															IL_09f1:
																															if (13 > b)
																															{
																																goto IL_09ff;
																															}
																															goto IL_0afc;
																															IL_09ff:
																															if (12 < b)
																															{
																																break;
																															}
																															goto IL_0a0d;
																															IL_0a0d:
																															if (12 > b)
																															{
																																break;
																															}
																															goto IL_0a1b;
																															IL_0a1b:
																															array8 = array3;
																															num7 = num6;
																															if (array == null)
																															{
																																goto IL_0a2a;
																															}
																															num8 = ptr2;
																															byte b2 = *num8;
																															ptr2 = num8 + 4;
																															int num9 = *(int*)(ptr2 + num3);
																															ptr2 += 8;
																															byte* ptr3 = ptr2 + num9;
																															byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																															while (ptr2 != ptr3)
																															{
																																*ptr4 = (byte)(*ptr2 ^ b2);
																																ptr2++;
																																ptr4++;
																															}
																															array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																															num = 35;
																															goto IL_0adb;
																															IL_0afc:
																															array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																															goto IL_0b1a;
																															IL_0b1a:
																															ptr2 += 8;
																															goto IL_0b28;
																															IL_0b28:
																															num6--;
																															goto IL_0d33;
																														}
																														break;
																													}
																													goto IL_0484;
																													IL_0508:
																													ptr2 += 8;
																													goto IL_0d33;
																													IL_0484:
																													array2[num6] = 5;
																													goto IL_0492;
																													IL_0492:
																													array3[num6] = array7[*(int*)(ptr2 + num3)];
																													goto IL_04f1;
																													IL_04f1:
																													num6++;
																													num = 15;
																													goto IL_0508;
																												}
																												break;
																											}
																											goto IL_0b3b;
																											IL_0cd7:
																											ptr2 += 8;
																											goto IL_0d33;
																											IL_0b3b:
																											if (19 < b)
																											{
																												goto IL_0b46;
																											}
																											goto IL_0baf;
																											IL_0b46:
																											if (20 < b)
																											{
																												goto IL_0b51;
																											}
																											goto IL_0b89;
																											IL_0b51:
																											if (21 < b)
																											{
																												break;
																											}
																											goto IL_0b5f;
																											IL_0b5f:
																											if (21 > b)
																											{
																												break;
																											}
																											goto IL_0b6d;
																											IL_0b6d:
																											num10 = ptr2;
																											num11 = -200;
																											num5 = 1;
																											ptr2 = num10 + num11;
																											goto IL_0d33;
																											IL_0b89:
																											if (20 > b)
																											{
																												break;
																											}
																											goto IL_0b97;
																											IL_0b97:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_0d33;
																											IL_0baf:
																											if (19 <= b)
																											{
																												goto IL_0bba;
																											}
																											goto IL_0c0b;
																											IL_0bba:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											goto IL_0bd3;
																											IL_0bd3:
																											array2[num6] = 1;
																											num = 153;
																											goto IL_0bea;
																											IL_0bea:
																											num6++;
																											goto IL_0bf8;
																											IL_0bf8:
																											ptr2 += 16;
																											goto IL_0d33;
																											IL_0c0b:
																											if (17 >= b)
																											{
																												goto IL_0c16;
																											}
																											goto IL_0c75;
																											IL_0c16:
																											if (17 > b)
																											{
																												break;
																											}
																											goto IL_0c24;
																											IL_0c24:
																											((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																											goto IL_0c62;
																											IL_0c62:
																											num6 -= 3;
																											goto IL_0d33;
																											IL_0c75:
																											if (18 < b)
																											{
																												break;
																											}
																											goto IL_0c80;
																											IL_0c80:
																											if (18 > b)
																											{
																												break;
																											}
																											goto IL_0c8b;
																											IL_0c8b:
																											array2[num6 - 1] = 5;
																											goto IL_0c9f;
																											IL_0c9f:
																											array3[num6 - 1] = ((delegate*<string[], string>)IsTransientgetBufferWidth[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																											goto IL_0cd7;
																										}
																										break;
																									}
																									num = 126;
																									goto IL_0420;
																									IL_0611:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_07b6;
																									IL_07b6:
																									num6 -= 2;
																									goto IL_0d33;
																									IL_0420:
																									if (11 <= b)
																									{
																										goto IL_0d33;
																									}
																									goto IL_042e;
																									IL_042e:
																									if (5 >= b)
																									{
																										goto IL_043c;
																									}
																									goto IL_051b;
																									IL_043c:
																									if (5 > b)
																									{
																										goto IL_044a;
																									}
																									goto IL_06df;
																									IL_044a:
																									if (2 >= b)
																									{
																										goto IL_0458;
																									}
																									goto IL_07dc;
																									IL_0458:
																									if (2 > b)
																									{
																										goto IL_0463;
																									}
																									goto IL_04ac;
																									IL_0463:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0471;
																									IL_0471:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_04ac:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_08c3;
																									IL_08c3:
																									array2[num6 - 2] = 0;
																									goto IL_08d7;
																									IL_08d7:
																									num6--;
																									goto IL_0d33;
																									IL_07dc:
																									if (3 < b)
																									{
																										goto IL_07ea;
																									}
																									goto IL_086b;
																									IL_07ea:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_07f8;
																									IL_07f8:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_0806;
																									IL_0806:
																									array2[num6] = 0;
																									goto IL_0814;
																									IL_0814:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																									num = 69;
																									goto IL_0840;
																									IL_0840:
																									array3[num6] = null;
																									goto IL_084a;
																									IL_084a:
																									num6++;
																									goto IL_0858;
																									IL_0858:
																									ptr2 += 8;
																									goto IL_0d33;
																									IL_086b:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0879;
																									IL_0879:
																									reference = ref array5[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_08a2;
																									IL_08a2:
																									ptr2 += 8;
																									goto IL_08b0;
																									IL_08b0:
																									num6--;
																									goto IL_0d33;
																									IL_06df:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_071f;
																									IL_071f:
																									array2[num6 - 2] = 0;
																									goto IL_0733;
																									IL_0733:
																									num6--;
																									goto IL_0d33;
																									IL_051b:
																									if (8 >= b)
																									{
																										goto IL_0526;
																									}
																									goto IL_0583;
																									IL_0526:
																									if (8 <= b)
																									{
																										goto IL_0531;
																									}
																									goto IL_0544;
																									IL_0531:
																									num6--;
																									goto IL_0d33;
																									IL_0544:
																									if (6 >= b)
																									{
																										goto IL_054f;
																									}
																									goto IL_0562;
																									IL_054f:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0678;
																									IL_0678:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_06b8;
																									IL_06b8:
																									array2[num6 - 2] = 0;
																									goto IL_06cc;
																									IL_06cc:
																									num6--;
																									goto IL_0d33;
																									IL_0562:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_0570;
																									IL_0570:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_0746;
																									IL_0746:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									num = 96;
																									goto IL_078f;
																									IL_078f:
																									array2[num6 - 2] = 0;
																									goto IL_07a3;
																									IL_07a3:
																									num6--;
																									goto IL_0d33;
																									IL_0583:
																									if (9 >= b)
																									{
																										goto IL_058e;
																									}
																									goto IL_05f5;
																									IL_058e:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_059c;
																									IL_059c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_05dc;
																									IL_05dc:
																									array2[num6 - 2] = 0;
																									goto IL_07c9;
																									IL_07c9:
																									num6--;
																									goto IL_0d33;
																									IL_05f5:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_0603;
																									IL_0603:
																									if (10 > b)
																									{
																										break;
																									}
																									goto IL_0611;
																								}
																								break;
																								IL_03dc:;
																							}
																						}
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0d00;
																						IL_0d1c:
																						ptr2 += 8;
																						num = 136;
																						goto IL_0d33;
																						IL_0d0e:
																						num6++;
																						goto IL_0d1c;
																						IL_0d00:
																						array2[num6] = 0;
																						goto IL_0d0e;
																						continue;
																						end_IL_03ec:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		goto IL_0e01;
																		IL_0e01:
																		return (string)array3[num6 - 1];
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0a2a:
				while (true)
				{
					IL_0a2a_2:
					array = new byte[4];
					while (true)
					{
						IL_0a38:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						num = 35;
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0ae9_2:
								num6++;
								while (true)
								{
									IL_0d33_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_03ec_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03cf_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_03bf_2:
																		if (16 >= b)
																		{
																			while (true)
																			{
																				IL_03af_2:
																				if (16 > b)
																				{
																					while (true)
																					{
																						IL_039f_2:
																						if (13 < b)
																						{
																							while (true)
																							{
																								IL_038f_2:
																								if (14 < b)
																								{
																									while (15 >= b)
																									{
																										num = 211;
																										while (true)
																										{
																											if (num != 211)
																											{
																												if (num != 1192)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 7:
																												case 41:
																													goto IL_037c_2;
																												case 112:
																													goto IL_038f_2;
																												case 190:
																													goto IL_039f_2;
																												case 123:
																													goto IL_03af_2;
																												case 173:
																													goto IL_03bf_2;
																												case 65:
																													goto IL_03cf_2;
																												case 111:
																													goto IL_03dc_2;
																												case 54:
																													goto IL_03ec_2;
																												case 177:
																													goto end_IL_03ec_2;
																												case 39:
																												case 145:
																													goto end_IL_03fc;
																												case 126:
																													goto IL_0420_2;
																												case 68:
																												case 91:
																													goto IL_042e_2;
																												case 97:
																													goto IL_043c_2;
																												case 110:
																												case 117:
																													goto IL_044a_2;
																												case 51:
																													goto IL_0458_2;
																												case 93:
																													goto IL_0463_2;
																												case 52:
																													goto IL_0471_2;
																												case 89:
																												case 132:
																													goto IL_0484_2;
																												case 120:
																													goto IL_0492_2;
																												case 21:
																												case 137:
																													goto IL_04ac_2;
																												case 149:
																													goto IL_04f1_2;
																												case 15:
																													goto IL_0508_2;
																												case 170:
																													goto IL_051b_2;
																												case 18:
																													goto IL_0526_2;
																												case 82:
																												case 139:
																													goto IL_0531_2;
																												case 3:
																													goto IL_0544_2;
																												case 6:
																													goto IL_054f_2;
																												case 87:
																													goto IL_0562_2;
																												case 38:
																													goto IL_0570_2;
																												case 131:
																												case 180:
																													goto IL_0583_2;
																												case 158:
																													goto IL_058e_2;
																												case 67:
																												case 162:
																													goto IL_059c_2;
																												case 101:
																													goto IL_05dc_2;
																												case 176:
																													goto IL_05f5_2;
																												case 71:
																													goto IL_0603_2;
																												case 20:
																												case 40:
																													goto IL_0611_2;
																												case 156:
																												case 181:
																													goto IL_0678_2;
																												case 160:
																													goto IL_06b8_2;
																												case 94:
																													goto IL_06cc_2;
																												case 49:
																												case 188:
																													goto IL_06df_2;
																												case 0:
																													goto IL_071f_2;
																												case 9:
																													goto IL_0733_2;
																												case 178:
																												case 191:
																													goto IL_0746_2;
																												case 96:
																													goto IL_078f_2;
																												case 186:
																													goto IL_07a3_2;
																												case 195:
																													goto IL_07b6_2;
																												case 198:
																													goto IL_07c9_2;
																												case 104:
																												case 199:
																													goto IL_07dc_2;
																												case 163:
																												case 187:
																													goto IL_07ea_2;
																												case 125:
																													goto IL_07f8_2;
																												case 2:
																												case 116:
																													goto IL_0806_2;
																												case 53:
																													goto IL_0814_2;
																												case 69:
																													goto end_IL_0369_2;
																												case 83:
																													goto IL_084a_2;
																												case 148:
																													goto IL_0858_2;
																												case 36:
																													goto IL_086b_2;
																												case 133:
																												case 169:
																													goto IL_0879_2;
																												case 140:
																													goto IL_08a2_2;
																												case 10:
																													goto IL_08b0_2;
																												case 201:
																													goto IL_08c3_2;
																												case 60:
																													goto IL_08d7_2;
																												case 8:
																												case 161:
																													goto IL_08f8_2;
																												case 146:
																													goto IL_0919_2;
																												case 143:
																													goto IL_0940_2;
																												case 84:
																													goto IL_0964_2;
																												case 109:
																													goto IL_097c_2;
																												case 25:
																													goto IL_0998_2;
																												case 58:
																												case 184:
																													goto IL_09a6_2;
																												case 24:
																													goto IL_09cf_2;
																												case 141:
																													goto IL_09f1_2;
																												case 105:
																												case 124:
																													goto IL_09ff_2;
																												case 203:
																													goto IL_0a0d_2;
																												case 37:
																												case 79:
																													goto IL_0a1b_2;
																												case 35:
																													goto end_IL_040c;
																												case 29:
																													goto IL_0ae9_2;
																												case 63:
																												case 168:
																													goto IL_0afc_2;
																												case 12:
																													goto IL_0b1a_2;
																												case 147:
																													goto IL_0b28_2;
																												case 77:
																													goto IL_0b3b_2;
																												case 55:
																												case 62:
																													goto IL_0b46_2;
																												case 106:
																													goto IL_0b51_2;
																												case 138:
																													goto IL_0b5f_2;
																												case 152:
																												case 185:
																													goto IL_0b6d_2;
																												case 100:
																													goto IL_0b89_2;
																												case 26:
																												case 114:
																													goto IL_0b97_2;
																												case 134:
																													goto IL_0baf_2;
																												case 108:
																												case 189:
																													goto IL_0bba_2;
																												case 121:
																													goto IL_0bd3_2;
																												case 153:
																													goto IL_0bea_2;
																												case 92:
																													goto IL_0bf8_2;
																												case 80:
																													goto IL_0c0b_2;
																												case 154:
																													goto IL_0c16_2;
																												case 28:
																												case 122:
																													goto IL_0c24_2;
																												case 200:
																													goto IL_0c62_2;
																												case 30:
																													goto IL_0c75_2;
																												case 19:
																													goto IL_0c80_2;
																												case 57:
																												case 204:
																													goto IL_0c8b_2;
																												case 1:
																													goto IL_0c9f_2;
																												case 167:
																													goto IL_0cd7_2;
																												case 4:
																												case 5:
																												case 16:
																												case 22:
																												case 23:
																												case 33:
																												case 43:
																												case 45:
																												case 50:
																												case 56:
																												case 59:
																												case 64:
																												case 66:
																												case 70:
																												case 73:
																												case 74:
																												case 90:
																												case 98:
																												case 102:
																												case 103:
																												case 107:
																												case 113:
																												case 115:
																												case 128:
																												case 129:
																												case 144:
																												case 150:
																												case 155:
																												case 165:
																												case 171:
																												case 174:
																												case 175:
																												case 179:
																												case 182:
																												case 192:
																												case 196:
																												case 197:
																													goto end_IL_037c_2;
																												case 99:
																													goto IL_0d00_2;
																												case 164:
																													goto IL_0d0e_2;
																												case 14:
																													goto IL_0d1c_2;
																												case 11:
																												case 13:
																												case 42:
																												case 48:
																												case 61:
																												case 72:
																												case 75:
																												case 81:
																												case 85:
																												case 86:
																												case 95:
																												case 118:
																												case 127:
																												case 130:
																												case 135:
																												case 136:
																												case 142:
																												case 151:
																												case 157:
																												case 166:
																												case 172:
																												case 183:
																												case 193:
																													goto IL_0d33_2;
																												case 88:
																													num = 95;
																													goto IL_0d33_2;
																												case 202:
																													ptr2 = ptr;
																													goto case 88;
																												case 46:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllCulturesUntrusted.SetIterationContextPEFileKinds);
																													goto case 202;
																												case 78:
																													array7 = new object[13];
																													goto case 46;
																												case 27:
																													array6 = new long[4];
																													goto case 78;
																												case 194:
																													array5 = new int[6];
																													goto case 27;
																												case 47:
																													array4 = new int[4];
																													goto case 194;
																												case 34:
																													array3 = new object[4];
																													goto case 47;
																												case 76:
																													array2 = new byte[4];
																													goto case 34;
																												case 44:
																													num4 = num2 * 8;
																													goto case 76;
																												case 119:
																													num3 = num2 * 4;
																													goto case 44;
																												case 31:
																													num2 = 1;
																													goto case 119;
																												case 32:
																													goto end_IL_0adb;
																												case 17:
																												case 159:
																													goto IL_0e01_2;
																												}
																												continue;
																											}
																											if (15 > b)
																											{
																												goto end_IL_037c_2;
																											}
																											goto IL_08f8_2;
																											IL_0940_2:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0964_2;
																											IL_097c_2:
																											num6++;
																											num = 157;
																											goto IL_0d33_2;
																											IL_0964_2:
																											array3[num6] = array3[num6 - 1];
																											goto IL_097c_2;
																											IL_08f8_2:
																											array2[num6] = array2[num6 - 1];
																											num = 146;
																											goto IL_0919_2;
																											IL_0919_2:
																											array4[num6 - 0] = array4[num6 - 1];
																											num = 143;
																											goto IL_0940_2;
																											continue;
																											end_IL_0369_2:
																											break;
																										}
																										goto IL_0840_2;
																										continue;
																										end_IL_037c_2:
																										break;
																										IL_037c_2:;
																									}
																									break;
																								}
																								goto IL_0998_2;
																								IL_09cf_2:
																								array2[num6 - 1] = 5;
																								goto IL_0d33_2;
																								IL_0998_2:
																								if (14 > b)
																								{
																									break;
																								}
																								goto IL_09a6_2;
																								IL_09a6_2:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_09cf_2;
																							}
																							break;
																						}
																						num = 141;
																						goto IL_09f1_2;
																						IL_0b1a_2:
																						ptr2 += 8;
																						goto IL_0b28_2;
																						IL_0b28_2:
																						num6--;
																						goto IL_0d33_2;
																						IL_09f1_2:
																						if (13 > b)
																						{
																							goto IL_09ff_2;
																						}
																						goto IL_0afc_2;
																						IL_09ff_2:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0a0d_2;
																						IL_0a0d_2:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_0a1b_2;
																						IL_0a1b_2:
																						array8 = array3;
																						num7 = num6;
																						if (array == null)
																						{
																							goto IL_0a2a_2;
																						}
																						goto IL_0a38;
																						IL_0afc_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_0b1a_2;
																					}
																					break;
																				}
																				goto IL_0484_2;
																				IL_0508_2:
																				ptr2 += 8;
																				goto IL_0d33_2;
																				IL_0484_2:
																				array2[num6] = 5;
																				goto IL_0492_2;
																				IL_0492_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_04f1_2;
																				IL_04f1_2:
																				num6++;
																				num = 15;
																				goto IL_0508_2;
																			}
																			break;
																		}
																		goto IL_0b3b_2;
																		IL_0cd7_2:
																		ptr2 += 8;
																		goto IL_0d33_2;
																		IL_0b3b_2:
																		if (19 < b)
																		{
																			goto IL_0b46_2;
																		}
																		goto IL_0baf_2;
																		IL_0b46_2:
																		if (20 < b)
																		{
																			goto IL_0b51_2;
																		}
																		goto IL_0b89_2;
																		IL_0b51_2:
																		if (21 < b)
																		{
																			break;
																		}
																		goto IL_0b5f_2;
																		IL_0b5f_2:
																		if (21 > b)
																		{
																			break;
																		}
																		goto IL_0b6d_2;
																		IL_0b6d_2:
																		num10 = ptr2;
																		num11 = -200;
																		num5 = 1;
																		ptr2 = num10 + num11;
																		goto IL_0d33_2;
																		IL_0b89_2:
																		if (20 > b)
																		{
																			break;
																		}
																		goto IL_0b97_2;
																		IL_0b97_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_0d33_2;
																		IL_0baf_2:
																		if (19 <= b)
																		{
																			goto IL_0bba_2;
																		}
																		goto IL_0c0b_2;
																		IL_0bba_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0bd3_2;
																		IL_0bd3_2:
																		array2[num6] = 1;
																		num = 153;
																		goto IL_0bea_2;
																		IL_0bea_2:
																		num6++;
																		goto IL_0bf8_2;
																		IL_0bf8_2:
																		ptr2 += 16;
																		goto IL_0d33_2;
																		IL_0c0b_2:
																		if (17 >= b)
																		{
																			goto IL_0c16_2;
																		}
																		goto IL_0c75_2;
																		IL_0c16_2:
																		if (17 > b)
																		{
																			break;
																		}
																		goto IL_0c24_2;
																		IL_0c24_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0c62_2;
																		IL_0c62_2:
																		num6 -= 3;
																		goto IL_0d33_2;
																		IL_0c75_2:
																		if (18 < b)
																		{
																			break;
																		}
																		goto IL_0c80_2;
																		IL_0c80_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0c8b_2;
																		IL_0c8b_2:
																		array2[num6 - 1] = 5;
																		goto IL_0c9f_2;
																		IL_0c9f_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)IsTransientgetBufferWidth[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_0cd7_2;
																	}
																	break;
																}
																num = 126;
																goto IL_0420_2;
																IL_0611_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_07b6_2;
																IL_07b6_2:
																num6 -= 2;
																goto IL_0d33_2;
																IL_0420_2:
																if (11 <= b)
																{
																	goto IL_0d33_2;
																}
																goto IL_042e_2;
																IL_042e_2:
																if (5 >= b)
																{
																	goto IL_043c_2;
																}
																goto IL_051b_2;
																IL_043c_2:
																if (5 > b)
																{
																	goto IL_044a_2;
																}
																goto IL_06df_2;
																IL_044a_2:
																if (2 >= b)
																{
																	goto IL_0458_2;
																}
																goto IL_07dc_2;
																IL_0458_2:
																if (2 > b)
																{
																	goto IL_0463_2;
																}
																goto IL_04ac_2;
																IL_0463_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_0471_2;
																IL_0471_2:
																if (1 > b)
																{
																}
																break;
																IL_04ac_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_08c3_2;
																IL_08c3_2:
																array2[num6 - 2] = 0;
																goto IL_08d7_2;
																IL_08d7_2:
																num6--;
																goto IL_0d33_2;
																IL_07dc_2:
																if (3 < b)
																{
																	goto IL_07ea_2;
																}
																goto IL_086b_2;
																IL_07ea_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_07f8_2;
																IL_07f8_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_0806_2;
																IL_0806_2:
																array2[num6] = 0;
																goto IL_0814_2;
																IL_0814_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																num = 69;
																goto IL_0840_2;
																IL_0840_2:
																array3[num6] = null;
																goto IL_084a_2;
																IL_084a_2:
																num6++;
																goto IL_0858_2;
																IL_0858_2:
																ptr2 += 8;
																goto IL_0d33_2;
																IL_086b_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_0879_2;
																IL_0879_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_08a2_2;
																IL_08a2_2:
																ptr2 += 8;
																goto IL_08b0_2;
																IL_08b0_2:
																num6--;
																goto IL_0d33_2;
																IL_06df_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_071f_2;
																IL_071f_2:
																array2[num6 - 2] = 0;
																goto IL_0733_2;
																IL_0733_2:
																num6--;
																goto IL_0d33_2;
																IL_051b_2:
																if (8 >= b)
																{
																	goto IL_0526_2;
																}
																goto IL_0583_2;
																IL_0526_2:
																if (8 <= b)
																{
																	goto IL_0531_2;
																}
																goto IL_0544_2;
																IL_0531_2:
																num6--;
																goto IL_0d33_2;
																IL_0544_2:
																if (6 >= b)
																{
																	goto IL_054f_2;
																}
																goto IL_0562_2;
																IL_054f_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0678_2;
																IL_0678_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_06b8_2;
																IL_06b8_2:
																array2[num6 - 2] = 0;
																goto IL_06cc_2;
																IL_06cc_2:
																num6--;
																goto IL_0d33_2;
																IL_0562_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0570_2;
																IL_0570_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0746_2;
																IL_0746_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																num = 96;
																goto IL_078f_2;
																IL_078f_2:
																array2[num6 - 2] = 0;
																goto IL_07a3_2;
																IL_07a3_2:
																num6--;
																goto IL_0d33_2;
																IL_0583_2:
																if (9 >= b)
																{
																	goto IL_058e_2;
																}
																goto IL_05f5_2;
																IL_058e_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_059c_2;
																IL_059c_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_05dc_2;
																IL_05dc_2:
																array2[num6 - 2] = 0;
																goto IL_07c9_2;
																IL_07c9_2:
																num6--;
																goto IL_0d33_2;
																IL_05f5_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_0603_2;
																IL_0603_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_0611_2;
															}
															break;
															IL_03dc_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d00_2;
													IL_0d1c_2:
													ptr2 += 8;
													num = 136;
													goto IL_0d33_2;
													IL_0d0e_2:
													num6++;
													goto IL_0d1c_2;
													IL_0d00_2:
													array2[num6] = 0;
													goto IL_0d0e_2;
													continue;
													end_IL_03ec_2:
													break;
												}
												continue;
												end_IL_03fc:
												break;
											}
											continue;
											end_IL_040c:
											break;
										}
										break;
									}
									goto IL_0e01_2;
									IL_0e01_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0adb:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_0383, IL_0396, IL_03a9, IL_03b9, IL_03c9, IL_03dc, IL_03e9, IL_03f9, IL_0409, IL_0419, IL_0429, IL_0439, IL_0452, IL_045d, IL_049f, IL_04aa, IL_04b8, IL_04c6, IL_04d4, IL_04e7, IL_04fd, IL_050b, IL_0519, IL_052c, IL_053f, IL_054a, IL_0555, IL_0568, IL_0576, IL_057f, IL_0592, IL_059d, IL_05b0, IL_05be, IL_05cc, IL_05da, IL_05e8, IL_0600, IL_061e, IL_0642, IL_065a, IL_066d, IL_06d4, IL_06df, IL_06ed, IL_071b, IL_0726, IL_0734, IL_0742, IL_0765, IL_076f, IL_077d, IL_0790, IL_079e, IL_07e7, IL_07fb, IL_080e, IL_0821, IL_0861, IL_087e, IL_0891, IL_08ba, IL_08d3, IL_08e1, IL_08f9, IL_0907, IL_0915, IL_0923, IL_0940, IL_098f, IL_0999, IL_09c6, IL_09da, IL_09e8, IL_09fb, IL_0a19, IL_0a27, IL_0a3a, IL_0a48, IL_0a60, IL_0a77, IL_0a8a, IL_0a98, IL_0ab1, IL_0abf, IL_0acd, IL_0ae0, IL_0aee, IL_0b01, IL_0b14, IL_0b22, IL_0b3e, IL_0b49, IL_0b89, IL_0b9d, IL_0bb0, IL_0bbe, IL_0bcc, IL_0bda, IL_0be3, IL_0bf1, IL_0c05, IL_0c3d, IL_0c59, IL_0c69, IL_0c77, IL_0cb7, IL_0ccb, IL_0cde, IL_0d25, IL_0d35, IL_0d4e, IL_0d5c, IL_0d6a, IL_0d78, IL_0d8b, IL_0d95, IL_0da0, IL_0db0, IL_0dc0, IL_0dd0, IL_0de0, IL_0df0, IL_0e00, IL_0e10, IL_0e20, IL_0e3b are reachable both inside and outside the pinned region starting at IL_0e35. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 66;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef11 = default(int);
				ref int reference = ref __rxRef11;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e20:
						num2 = 1;
						while (true)
						{
							IL_0e10:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e00:
								num4 = num2 * 8;
								while (true)
								{
									IL_0df0:
									array2 = new byte[4];
									while (true)
									{
										IL_0de0:
										array3 = new object[4];
										while (true)
										{
											IL_0dd0:
											array4 = new int[4];
											while (true)
											{
												IL_0dc0:
												array5 = new int[6];
												while (true)
												{
													IL_0db0:
													array6 = new long[4];
													while (true)
													{
														IL_0da0:
														array7 = new object[15];
														while (true)
														{
															IL_0d95:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsNestedAssemblyDay.CallTypeSoapPositiveInteger);
															while (true)
															{
																IL_0d8b:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0452:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0439:
																				ptr2++;
																				num = 15;
																				while (true)
																				{
																					IL_0429:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_0409:
																								if (11 >= b)
																								{
																									while (11 > b)
																									{
																										while (true)
																										{
																											IL_03e9:
																											if (5 >= b)
																											{
																												while (true)
																												{
																													IL_03dc:
																													if (5 > b)
																													{
																														while (true)
																														{
																															IL_03c9:
																															if (2 >= b)
																															{
																																num = 102;
																																while (true)
																																{
																																	IL_03b9:
																																	if (2 > b)
																																	{
																																		while (1 >= b)
																																		{
																																			while (1 <= b)
																																			{
																																				num = 214;
																																				while (num != 214)
																																				{
																																					if (num != 1195)
																																					{
																																						goto IL_09e8;
																																					}
																																					switch (num)
																																					{
																																					case 66:
																																						break;
																																					default:
																																						continue;
																																					case 3:
																																						goto IL_0396;
																																					case 200:
																																						goto IL_03a9;
																																					case 102:
																																						goto IL_03b9;
																																					case 165:
																																						goto IL_03c9;
																																					case 21:
																																						goto IL_03dc;
																																					case 17:
																																					case 138:
																																						goto IL_03e9;
																																					case 207:
																																						goto IL_03f9;
																																					case 28:
																																						goto IL_0409;
																																					case 171:
																																						goto IL_0419;
																																					case 15:
																																						goto IL_0429;
																																					case 145:
																																						goto IL_0439;
																																					case 71:
																																					case 203:
																																						goto IL_0452;
																																					case 32:
																																					case 44:
																																						goto IL_045d;
																																					case 88:
																																					case 105:
																																						goto IL_049f;
																																					case 73:
																																						goto IL_04aa;
																																					case 22:
																																					case 83:
																																						goto IL_04b8;
																																					case 48:
																																						goto IL_04c6;
																																					case 10:
																																						goto IL_04d4;
																																					case 132:
																																						goto IL_04e7;
																																					case 119:
																																					case 137:
																																						goto IL_04fd;
																																					case 75:
																																						goto IL_050b;
																																					case 63:
																																					case 126:
																																						goto IL_0519;
																																					case 139:
																																						goto IL_052c;
																																					case 120:
																																					case 148:
																																						goto IL_053f;
																																					case 45:
																																					case 55:
																																						goto IL_054a;
																																					case 58:
																																						goto IL_0555;
																																					case 89:
																																						goto IL_0568;
																																					case 64:
																																						goto IL_057f;
																																					case 26:
																																						goto IL_0592;
																																					case 61:
																																					case 91:
																																						goto IL_059d;
																																					case 108:
																																						goto IL_05b0;
																																					case 86:
																																					case 156:
																																						goto IL_05cc;
																																					case 53:
																																						goto IL_05da;
																																					case 30:
																																					case 104:
																																						goto IL_05e8;
																																					case 99:
																																						goto IL_0600;
																																					case 35:
																																						goto IL_061e;
																																					case 123:
																																						goto IL_0642;
																																					case 1:
																																						goto IL_065a;
																																					case 67:
																																					case 159:
																																						goto IL_066d;
																																					case 163:
																																						goto IL_06d4;
																																					case 49:
																																						goto IL_06df;
																																					case 41:
																																					case 94:
																																						goto IL_06ed;
																																					case 47:
																																						goto IL_071b;
																																					case 111:
																																						goto IL_0726;
																																					case 12:
																																					case 151:
																																						goto IL_0734;
																																					case 161:
																																						goto IL_0742;
																																					case 154:
																																						goto IL_0765;
																																					case 130:
																																						goto IL_076f;
																																					case 128:
																																						goto IL_077d;
																																					case 25:
																																					case 166:
																																						goto IL_079e;
																																					case 141:
																																						goto IL_07e7;
																																					case 18:
																																						goto IL_07fb;
																																					case 177:
																																						goto IL_080e;
																																					case 79:
																																					case 178:
																																						goto IL_0821;
																																					case 78:
																																						goto IL_0861;
																																					case 85:
																																						goto IL_087e;
																																					case 115:
																																					case 183:
																																						goto IL_0891;
																																					case 113:
																																						goto IL_08ba;
																																					case 184:
																																						goto IL_08d3;
																																					case 153:
																																					case 188:
																																						goto IL_08e1;
																																					case 190:
																																						goto IL_08f9;
																																					case 168:
																																					case 173:
																																						goto IL_0907;
																																					case 4:
																																						goto IL_0915;
																																					case 23:
																																					case 112:
																																						goto IL_0923;
																																					case 13:
																																						goto IL_09da;
																																					case 84:
																																						goto IL_09e8;
																																					case 122:
																																					case 152:
																																						goto IL_09fb;
																																					case 117:
																																						goto IL_0a19;
																																					case 81:
																																						goto IL_0a27;
																																					case 187:
																																					case 193:
																																						goto IL_0a3a;
																																					case 179:
																																						goto IL_0a48;
																																					case 8:
																																						goto IL_0a60;
																																					case 133:
																																						goto IL_0a77;
																																					case 194:
																																						goto IL_0a8a;
																																					case 76:
																																					case 155:
																																						goto IL_0a98;
																																					case 158:
																																						goto IL_0ab1;
																																					case 34:
																																						goto IL_0abf;
																																					case 6:
																																						goto IL_0acd;
																																					case 195:
																																						goto IL_0ae0;
																																					case 82:
																																						goto IL_0aee;
																																					case 196:
																																						goto IL_0b01;
																																					case 197:
																																						goto IL_0b14;
																																					case 43:
																																					case 189:
																																						goto IL_0b22;
																																					case 199:
																																						goto IL_0b3e;
																																					case 96:
																																					case 118:
																																						goto IL_0b49;
																																					case 16:
																																						goto IL_0b89;
																																					case 103:
																																						goto IL_0b9d;
																																					case 175:
																																					case 204:
																																						goto IL_0bbe;
																																					case 24:
																																					case 98:
																																						goto IL_0bcc;
																																					case 160:
																																						goto IL_0be3;
																																					case 106:
																																					case 150:
																																						goto IL_0bf1;
																																					case 135:
																																						goto IL_0c05;
																																					case 51:
																																						goto IL_0c3d;
																																					case 146:
																																						goto IL_0c59;
																																					case 205:
																																						goto IL_0c69;
																																					case 46:
																																					case 62:
																																						goto IL_0c77;
																																					case 116:
																																						goto IL_0cb7;
																																					case 0:
																																						goto IL_0ccb;
																																					case 60:
																																					case 206:
																																						goto IL_0cde;
																																					case 144:
																																						goto IL_0d25;
																																					case 7:
																																					case 9:
																																					case 20:
																																					case 31:
																																					case 33:
																																					case 37:
																																					case 38:
																																					case 40:
																																					case 50:
																																					case 56:
																																					case 59:
																																					case 68:
																																					case 72:
																																					case 74:
																																					case 80:
																																					case 92:
																																					case 93:
																																					case 97:
																																					case 100:
																																					case 107:
																																					case 127:
																																					case 134:
																																					case 142:
																																					case 143:
																																					case 147:
																																					case 149:
																																					case 157:
																																					case 164:
																																					case 169:
																																					case 172:
																																					case 176:
																																					case 180:
																																					case 186:
																																					case 198:
																																					case 201:
																																					case 202:
																																						goto end_IL_0383;
																																					case 181:
																																						goto IL_0d4e;
																																					case 11:
																																						goto IL_0d5c;
																																					case 95:
																																						goto IL_0d6a;
																																					case 2:
																																					case 19:
																																					case 27:
																																					case 29:
																																					case 39:
																																					case 42:
																																					case 52:
																																					case 57:
																																					case 69:
																																					case 87:
																																					case 90:
																																					case 101:
																																					case 109:
																																					case 110:
																																					case 114:
																																					case 121:
																																					case 124:
																																					case 125:
																																					case 129:
																																					case 131:
																																					case 167:
																																					case 174:
																																					case 191:
																																					case 192:
																																						goto end_IL_03f9;
																																					case 140:
																																						goto IL_0d8b;
																																					case 70:
																																						goto IL_0d95;
																																					case 185:
																																						goto IL_0da0;
																																					case 170:
																																						goto IL_0db0;
																																					case 5:
																																						goto IL_0dc0;
																																					case 14:
																																						goto IL_0dd0;
																																					case 54:
																																						goto IL_0de0;
																																					case 162:
																																						goto IL_0df0;
																																					case 136:
																																						goto IL_0e00;
																																					case 77:
																																						goto IL_0e10;
																																					case 65:
																																						goto IL_0e20;
																																					case 36:
																																					case 182:
																																						goto IL_0e3b;
																																					}
																																					goto end_IL_0d78;
																																					continue;
																																					end_IL_0383:
																																					break;
																																				}
																																				break;
																																				IL_0396:;
																																			}
																																			break;
																																			IL_03a9:;
																																		}
																																		break;
																																	}
																																	goto IL_0821;
																																	IL_087e:
																																	num6--;
																																	goto end_IL_03f9;
																																	IL_0821:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_0861;
																																	IL_0861:
																																	array2[num6 - 2] = 0;
																																	num = 85;
																																	goto IL_087e;
																																}
																																break;
																															}
																															goto IL_06d4;
																															IL_076f:
																															num6++;
																															goto IL_077d;
																															IL_077d:
																															ptr2 += 8;
																															goto end_IL_03f9;
																															IL_06d4:
																															if (3 >= b)
																															{
																																goto IL_06df;
																															}
																															goto IL_071b;
																															IL_06df:
																															if (3 > b)
																															{
																																break;
																															}
																															goto IL_06ed;
																															IL_06ed:
																															reference = ref array5[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_0ae0;
																															IL_0ae0:
																															ptr2 += 8;
																															goto IL_0aee;
																															IL_0aee:
																															num6--;
																															goto end_IL_03f9;
																															IL_071b:
																															if (4 < b)
																															{
																																num = 164;
																																break;
																															}
																															goto IL_0726;
																															IL_0726:
																															if (4 > b)
																															{
																																break;
																															}
																															goto IL_0734;
																															IL_0734:
																															array2[num6] = 0;
																															goto IL_0742;
																															IL_0742:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																															goto IL_0765;
																															IL_0765:
																															array3[num6] = null;
																															goto IL_076f;
																														}
																														break;
																													}
																													goto IL_045d;
																													IL_052c:
																													num6--;
																													goto end_IL_03f9;
																													IL_045d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_04e7;
																													IL_04e7:
																													array2[num6 - 2] = 0;
																													goto IL_052c;
																												}
																												break;
																											}
																											goto IL_053f;
																											IL_0c69:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_0c77;
																											IL_053f:
																											if (8 < b)
																											{
																												goto IL_054a;
																											}
																											goto IL_0592;
																											IL_054a:
																											if (9 >= b)
																											{
																												goto IL_0555;
																											}
																											goto IL_0568;
																											IL_0555:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_079e;
																											IL_079e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 141;
																											goto IL_07e7;
																											IL_07e7:
																											array2[num6 - 2] = 0;
																											goto IL_07fb;
																											IL_07fb:
																											num6--;
																											goto end_IL_03f9;
																											IL_0568:
																											if (10 < b)
																											{
																												break;
																											}
																											num = 64;
																											goto IL_057f;
																											IL_0c77:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0cb7;
																											IL_057f:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_066d;
																											IL_066d:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0b01;
																											IL_0b01:
																											num6 -= 2;
																											goto end_IL_03f9;
																											IL_0592:
																											if (8 <= b)
																											{
																												goto IL_059d;
																											}
																											goto IL_05b0;
																											IL_059d:
																											num6--;
																											goto end_IL_03f9;
																											IL_05b0:
																											if (6 < b)
																											{
																												goto IL_080e;
																											}
																											num = 199;
																											goto IL_0b3e;
																											IL_0cb7:
																											array2[num6 - 2] = 0;
																											goto IL_0ccb;
																											IL_0b3e:
																											if (6 > b)
																											{
																												num = 38;
																												break;
																											}
																											goto IL_0b49;
																											IL_0b49:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0b89;
																											IL_0b89:
																											array2[num6 - 2] = 0;
																											goto IL_0b9d;
																											IL_0b9d:
																											num6--;
																											goto end_IL_03f9;
																											IL_0ccb:
																											num6--;
																											goto end_IL_03f9;
																											IL_080e:
																											if (7 < b)
																											{
																												break;
																											}
																											goto IL_0c69;
																										}
																										goto end_IL_0419;
																										continue;
																										end_IL_03f9:
																										break;
																										IL_03f9:;
																									}
																									break;
																								}
																								goto IL_049f;
																								IL_0c05:
																								array3[num6 - 1] = ((delegate*<string[], string>)ControlPrincipalLoadedAssembly[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0c3d;
																								IL_049f:
																								if (16 >= b)
																								{
																									goto IL_04aa;
																								}
																								goto IL_04fd;
																								IL_04aa:
																								if (16 > b)
																								{
																									goto IL_04b8;
																								}
																								goto IL_0a3a;
																								IL_04b8:
																								if (13 < b)
																								{
																									goto IL_04c6;
																								}
																								goto IL_08f9;
																								IL_04c6:
																								if (14 >= b)
																								{
																									goto IL_04d4;
																								}
																								goto IL_05cc;
																								IL_04d4:
																								if (14 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0891;
																								IL_0891:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_08ba;
																								IL_08ba:
																								array2[num6 - 1] = 5;
																								break;
																								IL_05cc:
																								if (15 < b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_05da;
																								IL_05da:
																								if (15 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_05e8;
																								IL_05e8:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0600;
																								IL_0600:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_061e;
																								IL_061e:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0642;
																								IL_0642:
																								array3[num6] = array3[num6 - 1];
																								goto IL_065a;
																								IL_065a:
																								num6++;
																								break;
																								IL_08f9:
																								if (13 > b)
																								{
																									goto IL_0907;
																								}
																								goto IL_09fb;
																								IL_0907:
																								if (12 < b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0915;
																								IL_0915:
																								if (12 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0923;
																								IL_0923:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0932;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_09da;
																								IL_0c3d:
																								ptr2 += 8;
																								num = 114;
																								break;
																								IL_0c59:
																								if (17 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0cde;
																								IL_0cde:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								num = 144;
																								goto IL_0d25;
																								IL_09da:
																								array2[num6] = 5;
																								goto IL_09e8;
																								IL_09e8:
																								num6++;
																								break;
																								IL_09fb:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0a19;
																								IL_0a19:
																								ptr2 += 8;
																								goto IL_0a27;
																								IL_0a27:
																								num6--;
																								break;
																								IL_0a3a:
																								array2[num6] = 5;
																								goto IL_0a48;
																								IL_0a48:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0a60;
																								IL_0a60:
																								num6++;
																								num = 133;
																								goto IL_0a77;
																								IL_0a77:
																								ptr2 += 8;
																								break;
																								IL_04fd:
																								if (19 < b)
																								{
																									goto IL_050b;
																								}
																								goto IL_0a8a;
																								IL_050b:
																								if (20 < b)
																								{
																									goto IL_0519;
																								}
																								goto IL_08d3;
																								IL_0519:
																								if (21 < b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0b14;
																								IL_0b14:
																								if (21 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0b22;
																								IL_0b22:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								break;
																								IL_08d3:
																								if (20 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_08e1;
																								IL_08e1:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0a8a:
																								if (19 <= b)
																								{
																									goto IL_0a98;
																								}
																								goto IL_0bbe;
																								IL_0a98:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0ab1;
																								IL_0ab1:
																								array2[num6] = 1;
																								goto IL_0abf;
																								IL_0abf:
																								num6++;
																								goto IL_0acd;
																								IL_0acd:
																								ptr2 += 16;
																								break;
																								IL_0bbe:
																								if (17 < b)
																								{
																									goto IL_0bcc;
																								}
																								goto IL_0c59;
																								IL_0bcc:
																								if (18 < b)
																								{
																									goto end_IL_0419;
																								}
																								num = 160;
																								goto IL_0be3;
																								IL_0d25:
																								num6 -= 3;
																								break;
																								IL_0be3:
																								if (18 > b)
																								{
																									goto end_IL_0419;
																								}
																								goto IL_0bf1;
																								IL_0bf1:
																								array2[num6 - 1] = 5;
																								goto IL_0c05;
																							}
																							goto end_IL_0429;
																							continue;
																							end_IL_0419:
																							break;
																							IL_0419:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d4e;
																					IL_0d6a:
																					ptr2 += 8;
																					break;
																					IL_0d5c:
																					num6++;
																					goto IL_0d6a;
																					IL_0d4e:
																					array2[num6] = 0;
																					goto IL_0d5c;
																					continue;
																					end_IL_0429:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0e3b;
																	IL_0e3b:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0d78:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0932:
				while (true)
				{
					IL_0932_2:
					array = new byte[4];
					while (true)
					{
						IL_0940:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_0452_2:
											byte b = *ptr2;
											while (true)
											{
												IL_0439_2:
												ptr2++;
												num = 15;
												while (true)
												{
													IL_0429_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_0409_2:
																if (11 >= b)
																{
																	while (11 > b)
																	{
																		while (true)
																		{
																			IL_03e9_2:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_03dc_2:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_03c9_2:
																							if (2 >= b)
																							{
																								num = 102;
																								while (true)
																								{
																									IL_03b9_2:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												num = 214;
																												while (num != 214)
																												{
																													if (num != 1195)
																													{
																														goto end_IL_0d78_2;
																													}
																													switch (num)
																													{
																													case 3:
																														goto IL_0396_2;
																													case 200:
																														goto IL_03a9_2;
																													case 102:
																														goto IL_03b9_2;
																													case 165:
																														goto IL_03c9_2;
																													case 21:
																														goto IL_03dc_2;
																													case 17:
																													case 138:
																														goto IL_03e9_2;
																													case 207:
																														goto IL_03f9_2;
																													case 28:
																														goto IL_0409_2;
																													case 171:
																														goto IL_0419_2;
																													case 15:
																														goto IL_0429_2;
																													case 145:
																														goto IL_0439_2;
																													case 71:
																													case 203:
																														goto IL_0452_2;
																													case 32:
																													case 44:
																														goto IL_045d_2;
																													case 88:
																													case 105:
																														goto IL_049f_2;
																													case 73:
																														goto IL_04aa_2;
																													case 22:
																													case 83:
																														goto IL_04b8_2;
																													case 48:
																														goto IL_04c6_2;
																													case 10:
																														goto IL_04d4_2;
																													case 132:
																														goto IL_04e7_2;
																													case 119:
																													case 137:
																														goto IL_04fd_2;
																													case 75:
																														goto IL_050b_2;
																													case 63:
																													case 126:
																														goto IL_0519_2;
																													case 139:
																														goto IL_052c_2;
																													case 120:
																													case 148:
																														goto IL_053f_2;
																													case 45:
																													case 55:
																														goto IL_054a_2;
																													case 58:
																														goto IL_0555_2;
																													case 89:
																														goto IL_0568_2;
																													case 64:
																														goto IL_057f_2;
																													case 26:
																														goto IL_0592_2;
																													case 61:
																													case 91:
																														goto IL_059d_2;
																													case 108:
																														goto IL_05b0_2;
																													case 86:
																													case 156:
																														goto IL_05cc_2;
																													case 53:
																														goto IL_05da_2;
																													case 30:
																													case 104:
																														goto IL_05e8_2;
																													case 99:
																														goto IL_0600_2;
																													case 35:
																														goto IL_061e_2;
																													case 123:
																														goto IL_0642_2;
																													case 1:
																														goto IL_065a_2;
																													case 67:
																													case 159:
																														goto IL_066d_2;
																													case 163:
																														goto IL_06d4_2;
																													case 49:
																														goto IL_06df_2;
																													case 41:
																													case 94:
																														goto IL_06ed_2;
																													case 47:
																														goto IL_071b_2;
																													case 111:
																														goto IL_0726_2;
																													case 12:
																													case 151:
																														goto IL_0734_2;
																													case 161:
																														goto IL_0742_2;
																													case 154:
																														goto IL_0765_2;
																													case 130:
																														goto IL_076f_2;
																													case 128:
																														goto IL_077d_2;
																													case 25:
																													case 166:
																														goto IL_079e_2;
																													case 141:
																														goto IL_07e7_2;
																													case 18:
																														goto IL_07fb_2;
																													case 177:
																														goto IL_080e_2;
																													case 79:
																													case 178:
																														goto IL_0821_2;
																													case 78:
																														goto IL_0861_2;
																													case 85:
																														goto IL_087e_2;
																													case 115:
																													case 183:
																														goto IL_0891_2;
																													case 113:
																														goto IL_08ba_2;
																													case 184:
																														goto IL_08d3_2;
																													case 153:
																													case 188:
																														goto IL_08e1_2;
																													case 190:
																														goto IL_08f9_2;
																													case 168:
																													case 173:
																														goto IL_0907_2;
																													case 4:
																														goto IL_0915_2;
																													case 23:
																													case 112:
																														goto IL_0923_2;
																													case 13:
																														goto end_IL_09e8;
																													case 84:
																														goto end_IL_0d78_2;
																													case 122:
																													case 152:
																														goto IL_09fb_2;
																													case 117:
																														goto IL_0a19_2;
																													case 81:
																														goto IL_0a27_2;
																													case 187:
																													case 193:
																														goto IL_0a3a_2;
																													case 179:
																														goto IL_0a48_2;
																													case 8:
																														goto IL_0a60_2;
																													case 133:
																														goto IL_0a77_2;
																													case 194:
																														goto IL_0a8a_2;
																													case 76:
																													case 155:
																														goto IL_0a98_2;
																													case 158:
																														goto IL_0ab1_2;
																													case 34:
																														goto IL_0abf_2;
																													case 6:
																														goto IL_0acd_2;
																													case 195:
																														goto IL_0ae0_2;
																													case 82:
																														goto IL_0aee_2;
																													case 196:
																														goto IL_0b01_2;
																													case 197:
																														goto IL_0b14_2;
																													case 43:
																													case 189:
																														goto IL_0b22_2;
																													case 199:
																														goto IL_0b3e_2;
																													case 96:
																													case 118:
																														goto IL_0b49_2;
																													case 16:
																														goto IL_0b89_2;
																													case 103:
																														goto IL_0b9d_2;
																													case 175:
																													case 204:
																														goto IL_0bbe_2;
																													case 24:
																													case 98:
																														goto IL_0bcc_2;
																													case 160:
																														goto IL_0be3_2;
																													case 106:
																													case 150:
																														goto IL_0bf1_2;
																													case 135:
																														goto IL_0c05_2;
																													case 51:
																														goto IL_0c3d_2;
																													case 146:
																														goto IL_0c59_2;
																													case 205:
																														goto IL_0c69_2;
																													case 46:
																													case 62:
																														goto IL_0c77_2;
																													case 116:
																														goto IL_0cb7_2;
																													case 0:
																														goto IL_0ccb_2;
																													case 60:
																													case 206:
																														goto IL_0cde_2;
																													case 144:
																														goto IL_0d25_2;
																													case 7:
																													case 9:
																													case 20:
																													case 31:
																													case 33:
																													case 37:
																													case 38:
																													case 40:
																													case 50:
																													case 56:
																													case 59:
																													case 68:
																													case 72:
																													case 74:
																													case 80:
																													case 92:
																													case 93:
																													case 97:
																													case 100:
																													case 107:
																													case 127:
																													case 134:
																													case 142:
																													case 143:
																													case 147:
																													case 149:
																													case 157:
																													case 164:
																													case 169:
																													case 172:
																													case 176:
																													case 180:
																													case 186:
																													case 198:
																													case 201:
																													case 202:
																														goto end_IL_0383_2;
																													case 181:
																														goto IL_0d4e_2;
																													case 11:
																														goto IL_0d5c_2;
																													case 95:
																														goto IL_0d6a_2;
																													case 2:
																													case 19:
																													case 27:
																													case 29:
																													case 39:
																													case 42:
																													case 52:
																													case 57:
																													case 69:
																													case 87:
																													case 90:
																													case 101:
																													case 109:
																													case 110:
																													case 114:
																													case 121:
																													case 124:
																													case 125:
																													case 129:
																													case 131:
																													case 167:
																													case 174:
																													case 191:
																													case 192:
																														goto end_IL_03f9_2;
																													case 140:
																														ptr2 = ptr;
																														goto end_IL_03f9_2;
																													case 70:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsNestedAssemblyDay.CallTypeSoapPositiveInteger);
																														goto case 140;
																													case 185:
																														array7 = new object[15];
																														goto case 70;
																													case 170:
																														array6 = new long[4];
																														goto case 185;
																													case 5:
																														array5 = new int[6];
																														goto case 170;
																													case 14:
																														array4 = new int[4];
																														goto case 5;
																													case 54:
																														array3 = new object[4];
																														goto case 14;
																													case 162:
																														array2 = new byte[4];
																														goto case 54;
																													case 136:
																														num4 = num2 * 8;
																														goto case 162;
																													case 77:
																														num3 = num2 * 4;
																														goto case 136;
																													case 65:
																														num2 = 1;
																														goto case 77;
																													case 66:
																														goto end_IL_09da;
																													case 36:
																													case 182:
																														goto IL_0e3b_2;
																													}
																													continue;
																													end_IL_0383_2:
																													break;
																												}
																												break;
																												IL_0396_2:;
																											}
																											break;
																											IL_03a9_2:;
																										}
																										break;
																									}
																									goto IL_0821_2;
																									IL_087e_2:
																									num6--;
																									goto end_IL_03f9_2;
																									IL_0821_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0861_2;
																									IL_0861_2:
																									array2[num6 - 2] = 0;
																									num = 85;
																									goto IL_087e_2;
																								}
																								break;
																							}
																							goto IL_06d4_2;
																							IL_076f_2:
																							num6++;
																							goto IL_077d_2;
																							IL_077d_2:
																							ptr2 += 8;
																							goto end_IL_03f9_2;
																							IL_06d4_2:
																							if (3 >= b)
																							{
																								goto IL_06df_2;
																							}
																							goto IL_071b_2;
																							IL_06df_2:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_06ed_2;
																							IL_06ed_2:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0ae0_2;
																							IL_0ae0_2:
																							ptr2 += 8;
																							goto IL_0aee_2;
																							IL_0aee_2:
																							num6--;
																							goto end_IL_03f9_2;
																							IL_071b_2:
																							if (4 < b)
																							{
																								num = 164;
																								break;
																							}
																							goto IL_0726_2;
																							IL_0726_2:
																							if (4 > b)
																							{
																								break;
																							}
																							goto IL_0734_2;
																							IL_0734_2:
																							array2[num6] = 0;
																							goto IL_0742_2;
																							IL_0742_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0765_2;
																							IL_0765_2:
																							array3[num6] = null;
																							goto IL_076f_2;
																						}
																						break;
																					}
																					goto IL_045d_2;
																					IL_052c_2:
																					num6--;
																					goto end_IL_03f9_2;
																					IL_045d_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_04e7_2;
																					IL_04e7_2:
																					array2[num6 - 2] = 0;
																					goto IL_052c_2;
																				}
																				break;
																			}
																			goto IL_053f_2;
																			IL_0c69_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0c77_2;
																			IL_053f_2:
																			if (8 < b)
																			{
																				goto IL_054a_2;
																			}
																			goto IL_0592_2;
																			IL_054a_2:
																			if (9 >= b)
																			{
																				goto IL_0555_2;
																			}
																			goto IL_0568_2;
																			IL_0555_2:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_079e_2;
																			IL_079e_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 141;
																			goto IL_07e7_2;
																			IL_07e7_2:
																			array2[num6 - 2] = 0;
																			goto IL_07fb_2;
																			IL_07fb_2:
																			num6--;
																			goto end_IL_03f9_2;
																			IL_0568_2:
																			if (10 < b)
																			{
																				break;
																			}
																			num = 64;
																			goto IL_057f_2;
																			IL_0c77_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0cb7_2;
																			IL_057f_2:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_066d_2;
																			IL_066d_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0b01_2;
																			IL_0b01_2:
																			num6 -= 2;
																			goto end_IL_03f9_2;
																			IL_0592_2:
																			if (8 <= b)
																			{
																				goto IL_059d_2;
																			}
																			goto IL_05b0_2;
																			IL_059d_2:
																			num6--;
																			goto end_IL_03f9_2;
																			IL_05b0_2:
																			if (6 < b)
																			{
																				goto IL_080e_2;
																			}
																			num = 199;
																			goto IL_0b3e_2;
																			IL_0cb7_2:
																			array2[num6 - 2] = 0;
																			goto IL_0ccb_2;
																			IL_0b3e_2:
																			if (6 > b)
																			{
																				num = 38;
																				break;
																			}
																			goto IL_0b49_2;
																			IL_0b49_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0b89_2;
																			IL_0b89_2:
																			array2[num6 - 2] = 0;
																			goto IL_0b9d_2;
																			IL_0b9d_2:
																			num6--;
																			goto end_IL_03f9_2;
																			IL_0ccb_2:
																			num6--;
																			goto end_IL_03f9_2;
																			IL_080e_2:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0c69_2;
																		}
																		goto end_IL_0419_2;
																		continue;
																		end_IL_03f9_2:
																		break;
																		IL_03f9_2:;
																	}
																	break;
																}
																goto IL_049f_2;
																IL_0cde_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																num = 144;
																goto IL_0d25_2;
																IL_049f_2:
																if (16 >= b)
																{
																	goto IL_04aa_2;
																}
																goto IL_04fd_2;
																IL_04aa_2:
																if (16 > b)
																{
																	goto IL_04b8_2;
																}
																goto IL_0a3a_2;
																IL_04b8_2:
																if (13 < b)
																{
																	goto IL_04c6_2;
																}
																goto IL_08f9_2;
																IL_04c6_2:
																if (14 >= b)
																{
																	goto IL_04d4_2;
																}
																goto IL_05cc_2;
																IL_04d4_2:
																if (14 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0891_2;
																IL_0891_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_08ba_2;
																IL_08ba_2:
																array2[num6 - 1] = 5;
																break;
																IL_05cc_2:
																if (15 < b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_05da_2;
																IL_05da_2:
																if (15 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_05e8_2;
																IL_05e8_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0600_2;
																IL_0600_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_061e_2;
																IL_061e_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0642_2;
																IL_0642_2:
																array3[num6] = array3[num6 - 1];
																goto IL_065a_2;
																IL_065a_2:
																num6++;
																break;
																IL_08f9_2:
																if (13 > b)
																{
																	goto IL_0907_2;
																}
																goto IL_09fb_2;
																IL_0907_2:
																if (12 < b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0915_2;
																IL_0915_2:
																if (12 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0923_2;
																IL_0923_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0932_2;
																}
																goto IL_0940;
																IL_09fb_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0a19_2;
																IL_0a19_2:
																ptr2 += 8;
																goto IL_0a27_2;
																IL_0a27_2:
																num6--;
																break;
																IL_0a3a_2:
																array2[num6] = 5;
																goto IL_0a48_2;
																IL_0a48_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0a60_2;
																IL_0a60_2:
																num6++;
																num = 133;
																goto IL_0a77_2;
																IL_0a77_2:
																ptr2 += 8;
																break;
																IL_04fd_2:
																if (19 < b)
																{
																	goto IL_050b_2;
																}
																goto IL_0a8a_2;
																IL_050b_2:
																if (20 < b)
																{
																	goto IL_0519_2;
																}
																goto IL_08d3_2;
																IL_0519_2:
																if (21 < b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0b14_2;
																IL_0b14_2:
																if (21 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0b22_2;
																IL_0b22_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																break;
																IL_08d3_2:
																if (20 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_08e1_2;
																IL_08e1_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0a8a_2:
																if (19 <= b)
																{
																	goto IL_0a98_2;
																}
																goto IL_0bbe_2;
																IL_0a98_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0ab1_2;
																IL_0ab1_2:
																array2[num6] = 1;
																goto IL_0abf_2;
																IL_0abf_2:
																num6++;
																goto IL_0acd_2;
																IL_0acd_2:
																ptr2 += 16;
																break;
																IL_0bbe_2:
																if (17 < b)
																{
																	goto IL_0bcc_2;
																}
																goto IL_0c59_2;
																IL_0bcc_2:
																if (18 < b)
																{
																	goto end_IL_0419_2;
																}
																num = 160;
																goto IL_0be3_2;
																IL_0d25_2:
																num6 -= 3;
																break;
																IL_0be3_2:
																if (18 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0bf1_2;
																IL_0bf1_2:
																array2[num6 - 1] = 5;
																goto IL_0c05_2;
																IL_0c05_2:
																array3[num6 - 1] = ((delegate*<string[], string>)ControlPrincipalLoadedAssembly[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0c3d_2;
																IL_0c3d_2:
																ptr2 += 8;
																num = 114;
																break;
																IL_0c59_2:
																if (17 > b)
																{
																	goto end_IL_0419_2;
																}
																goto IL_0cde_2;
															}
															goto end_IL_0429_2;
															continue;
															end_IL_0419_2:
															break;
															IL_0419_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d4e_2;
													IL_0d6a_2:
													ptr2 += 8;
													break;
													IL_0d5c_2:
													num6++;
													goto IL_0d6a_2;
													IL_0d4e_2:
													array2[num6] = 0;
													goto IL_0d5c_2;
													continue;
													end_IL_0429_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0e3b_2;
									IL_0e3b_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0d78_2:
									break;
								}
								continue;
								end_IL_09e8:
								break;
							}
							continue;
							end_IL_09da:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class104()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_4, int int_5)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 17;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InstallDeploymentGetValue.SetResultSingleTypeInfo);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_01d4:
															byte b = *ptr2;
															while (true)
															{
																IL_01c4:
																ptr2++;
																while (true)
																{
																	IL_01b4:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_01a4:
																			if (b > 8)
																			{
																				num = 93;
																				while (num != 93)
																				{
																					if (num != 1074)
																					{
																						goto end_IL_01b4;
																					}
																					switch (num)
																					{
																					case 65:
																						goto IL_01a4;
																					case 36:
																						goto IL_01b4;
																					case 14:
																						goto IL_01c4;
																					case 9:
																					case 41:
																						goto IL_01d4;
																					case 25:
																						goto IL_01df;
																					case 21:
																						goto IL_01ea;
																					case 5:
																						goto IL_01f8;
																					case 29:
																						goto IL_0208;
																					case 23:
																					case 48:
																						goto IL_0216;
																					case 22:
																					case 63:
																						goto IL_0224;
																					case 61:
																						goto IL_0232;
																					case 68:
																						goto IL_0242;
																					case 19:
																						goto IL_0250;
																					case 35:
																					case 69:
																						goto IL_0263;
																					case 0:
																						goto IL_02a3;
																					case 59:
																						goto IL_02b7;
																					case 74:
																						goto IL_02ca;
																					case 7:
																					case 64:
																						goto IL_02d8;
																					case 55:
																						goto IL_0346;
																					case 54:
																					case 76:
																						goto IL_0359;
																					case 42:
																						goto IL_0382;
																					case 43:
																						goto IL_0390;
																					case 79:
																						goto IL_03a3;
																					case 2:
																						goto IL_03b1;
																					case 81:
																						goto IL_03c4;
																					case 15:
																						goto IL_03cf;
																					case 56:
																					case 57:
																						goto IL_03dd;
																					case 34:
																						goto IL_03eb;
																					case 45:
																						goto IL_0410;
																					case 33:
																						goto IL_041b;
																					case 58:
																					case 80:
																						goto IL_0426;
																					case 53:
																					case 85:
																						goto IL_0442;
																					case 86:
																						goto IL_0457;
																					case 62:
																						goto IL_0461;
																					case 52:
																						goto IL_046f;
																					case 1:
																					case 4:
																					case 20:
																					case 38:
																					case 40:
																					case 46:
																					case 47:
																					case 50:
																					case 51:
																					case 71:
																					case 72:
																					case 77:
																					case 78:
																					case 82:
																					case 84:
																						goto end_IL_0191;
																					case 3:
																						goto IL_04a2;
																					case 12:
																						goto IL_04b0;
																					case 49:
																						goto IL_04be;
																					case 8:
																					case 11:
																					case 13:
																					case 24:
																					case 28:
																					case 30:
																					case 39:
																					case 44:
																					case 67:
																					case 70:
																					case 83:
																						goto end_IL_01b4;
																					case 10:
																						goto end_IL_04cc;
																					case 75:
																						goto end_IL_04df;
																					case 31:
																						goto end_IL_04e9;
																					case 16:
																						goto end_IL_04f4;
																					case 37:
																						goto end_IL_0509;
																					case 6:
																					case 60:
																						goto end_IL_051e;
																					case 32:
																						goto end_IL_052e;
																					case 27:
																					case 73:
																						goto end_IL_053e;
																					case 17:
																						goto end_IL_054e;
																					case 18:
																						goto end_IL_055e;
																					case 26:
																					case 66:
																						goto IL_0582;
																					}
																					continue;
																					end_IL_0191:
																					break;
																				}
																				break;
																			}
																			goto IL_01df;
																			IL_0382:
																			ptr2 += 8;
																			goto IL_0390;
																			IL_0390:
																			num5--;
																			goto end_IL_01b4;
																			IL_01df:
																			if (4 < b)
																			{
																				goto IL_01ea;
																			}
																			goto IL_0208;
																			IL_01ea:
																			if (6 >= b)
																			{
																				goto IL_01f8;
																			}
																			goto IL_03c4;
																			IL_01f8:
																			if (6 <= b)
																			{
																				goto end_IL_01b4;
																			}
																			goto IL_0242;
																			IL_0242:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0250;
																			IL_0250:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0442;
																			IL_0442:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_01b4;
																			IL_03c4:
																			if (7 >= b)
																			{
																				goto IL_03cf;
																			}
																			goto IL_0410;
																			IL_03cf:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_03dd;
																			IL_03dd:
																			array[num5] = 0;
																			goto IL_03eb;
																			IL_03eb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0457;
																			IL_0457:
																			array2[num5] = null;
																			goto IL_0461;
																			IL_0461:
																			num5++;
																			goto IL_046f;
																			IL_046f:
																			ptr2 += 8;
																			goto end_IL_01b4;
																			IL_0410:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_041b;
																			IL_041b:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_01b4;
																			IL_0208:
																			if (4 > b)
																			{
																				goto IL_0216;
																			}
																			goto IL_0359;
																			IL_0216:
																			if (2 < b)
																			{
																				goto IL_0224;
																			}
																			goto IL_02ca;
																			IL_0224:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0232;
																			IL_0232:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0263;
																			IL_0263:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_02a3;
																			IL_02a3:
																			array[num5 - 2] = 0;
																			goto IL_02b7;
																			IL_02b7:
																			num5--;
																			goto end_IL_01b4;
																			IL_02ca:
																			if (2 <= b)
																			{
																				goto IL_02d8;
																			}
																			goto IL_03a3;
																			IL_02d8:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0346;
																			IL_0346:
																			num5 -= 2;
																			goto end_IL_01b4;
																			IL_03a3:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_03b1;
																			IL_03b1:
																			if (1 > b)
																			{
																			}
																			break;
																			IL_0359:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0382;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a2;
																	IL_04be:
																	ptr2 += 8;
																	break;
																	IL_04b0:
																	num5++;
																	goto IL_04be;
																	IL_04a2:
																	array[num5] = 0;
																	goto IL_04b0;
																	continue;
																	end_IL_01b4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0582;
													IL_0582:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04cc:
													break;
												}
												continue;
												end_IL_04df:
												break;
											}
											continue;
											end_IL_04e9:
											break;
										}
										continue;
										end_IL_04f4:
										break;
									}
									continue;
									end_IL_0509:
									break;
								}
								continue;
								end_IL_051e:
								break;
							}
							continue;
							end_IL_052e:
							break;
						}
						continue;
						end_IL_053e:
						break;
					}
					continue;
					end_IL_054e:
					break;
				}
				continue;
				end_IL_055e:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_4, int int_5)
	{
		int num = 58;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										num = 31;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IntPtrArrayTypeInfoIAsyncCausalityTracerStatics.EventTagsIsLetter);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 114;
															while (true)
															{
																if (num != 114)
																{
																	if (num != 1095)
																	{
																		goto IL_048b;
																	}
																	switch (num)
																	{
																	case 101:
																		goto end_IL_01d7;
																	case 80:
																		goto IL_01fb;
																	case 62:
																		goto IL_0209;
																	case 97:
																		goto IL_0217;
																	case 27:
																		goto IL_0225;
																	case 30:
																	case 55:
																		goto IL_0233;
																	case 1:
																		goto IL_0241;
																	case 14:
																	case 33:
																		goto IL_024c;
																	case 63:
																		goto IL_0265;
																	case 7:
																		goto IL_0273;
																	case 54:
																		goto IL_0281;
																	case 16:
																		goto IL_0294;
																	case 37:
																		goto IL_02a2;
																	case 4:
																	case 6:
																		goto IL_02b0;
																	case 81:
																		goto IL_02f0;
																	case 48:
																		goto IL_0304;
																	case 77:
																	case 105:
																		goto IL_0320;
																	case 34:
																		goto IL_032b;
																	case 40:
																	case 67:
																		goto IL_0339;
																	case 96:
																		goto IL_0379;
																	case 99:
																		goto IL_038d;
																	case 13:
																	case 76:
																		goto IL_03a9;
																	case 17:
																		goto IL_03b7;
																	case 20:
																	case 95:
																		goto IL_03c5;
																	case 11:
																		goto IL_03e1;
																	case 19:
																	case 22:
																		goto IL_03ec;
																	case 91:
																		goto IL_03fa;
																	case 88:
																		goto IL_041d;
																	case 65:
																		goto IL_0427;
																	case 92:
																		goto IL_0435;
																	case 73:
																		goto IL_0451;
																	case 94:
																		goto IL_045f;
																	case 47:
																		goto IL_046a;
																	case 18:
																		goto IL_0478;
																	case 38:
																	case 69:
																		goto IL_048b;
																	case 29:
																		goto IL_04cb;
																	case 49:
																		goto IL_04df;
																	case 59:
																		goto IL_04fb;
																	case 53:
																	case 85:
																		goto IL_0509;
																	case 43:
																		goto IL_0517;
																	case 10:
																	case 106:
																		goto IL_0525;
																	case 42:
																		goto IL_056e;
																	case 83:
																		goto IL_0582;
																	case 71:
																		goto IL_0595;
																	case 0:
																	case 102:
																		goto IL_05a0;
																	case 107:
																		goto IL_05c9;
																	case 68:
																		goto IL_05e0;
																	case 2:
																	case 3:
																	case 5:
																	case 8:
																	case 21:
																	case 23:
																	case 25:
																	case 32:
																	case 36:
																	case 41:
																	case 44:
																	case 60:
																	case 64:
																	case 66:
																	case 70:
																	case 72:
																	case 82:
																	case 89:
																	case 90:
																	case 93:
																	case 104:
																		goto IL_05f0;
																	case 98:
																		goto IL_0613;
																	case 51:
																		goto IL_0621;
																	case 56:
																		goto IL_062f;
																	case 24:
																	case 26:
																	case 35:
																	case 45:
																	case 46:
																	case 75:
																	case 79:
																	case 84:
																	case 86:
																	case 100:
																	case 103:
																		goto end_IL_01e7;
																	case 52:
																		goto end_IL_063d;
																	case 31:
																		goto end_IL_0650;
																	case 28:
																		goto end_IL_065a;
																	case 12:
																		goto end_IL_0665;
																	case 15:
																		goto end_IL_0683;
																	case 50:
																	case 74:
																		goto end_IL_0698;
																	case 61:
																		goto end_IL_06a8;
																	case 39:
																	case 78:
																		goto end_IL_06b8;
																	case 57:
																		goto end_IL_06c8;
																	case 58:
																		goto end_IL_06d8;
																	case 9:
																	case 87:
																		goto IL_06f3;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_01fb;
																IL_05e0:
																num5--;
																goto end_IL_01e7;
																IL_0613:
																array[num5] = 0;
																goto IL_0621;
																IL_05f0:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0613;
																IL_01fb:
																ptr2++;
																goto IL_0209;
																IL_0209:
																if (b >= 1)
																{
																	goto IL_0217;
																}
																goto IL_05f0;
																IL_0217:
																if (b <= 9)
																{
																	goto IL_0225;
																}
																goto IL_05f0;
																IL_0225:
																if (5 < b)
																{
																	goto IL_0233;
																}
																goto IL_03e1;
																IL_0233:
																if (7 >= b)
																{
																	goto IL_0241;
																}
																num = 77;
																goto IL_0320;
																IL_0241:
																if (7 <= b)
																{
																	goto IL_024c;
																}
																goto IL_0294;
																IL_024c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0265;
																IL_0265:
																array[num5] = 0;
																goto IL_0273;
																IL_0273:
																num5++;
																goto IL_0281;
																IL_0281:
																ptr2 += 8;
																goto end_IL_01e7;
																IL_0294:
																if (6 >= b)
																{
																	goto IL_02a2;
																}
																goto IL_05f0;
																IL_02a2:
																if (6 <= b)
																{
																	goto IL_02b0;
																}
																goto IL_05f0;
																IL_02b0:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_02f0;
																IL_02f0:
																array[num5 - 2] = 0;
																goto IL_0304;
																IL_0304:
																num5--;
																goto end_IL_01e7;
																IL_0621:
																num5++;
																goto IL_062f;
																IL_0320:
																if (8 >= b)
																{
																	goto IL_032b;
																}
																num = 76;
																goto IL_03a9;
																IL_032b:
																if (8 <= b)
																{
																	goto IL_0339;
																}
																goto IL_05f0;
																IL_0339:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0379;
																IL_0379:
																array[num5 - 2] = 0;
																goto IL_038d;
																IL_038d:
																num5--;
																goto end_IL_01e7;
																IL_062f:
																ptr2 += 8;
																goto end_IL_01e7;
																IL_03a9:
																if (9 >= b)
																{
																	goto IL_03b7;
																}
																goto IL_05f0;
																IL_03b7:
																if (9 <= b)
																{
																	goto IL_03c5;
																}
																goto IL_05f0;
																IL_03c5:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_01e7;
																IL_03e1:
																if (5 <= b)
																{
																	goto IL_03ec;
																}
																goto IL_0451;
																IL_03ec:
																array[num5] = 0;
																goto IL_03fa;
																IL_03fa:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_041d;
																IL_041d:
																array2[num5] = null;
																goto IL_0427;
																IL_0427:
																num5++;
																goto IL_0435;
																IL_0435:
																ptr2 += 8;
																num = 79;
																goto end_IL_01e7;
																IL_0451:
																if (2 >= b)
																{
																	goto IL_045f;
																}
																goto IL_04fb;
																IL_045f:
																if (2 > b)
																{
																	goto IL_046a;
																}
																goto IL_048b;
																IL_046a:
																if (1 >= b)
																{
																	goto IL_0478;
																}
																goto IL_05f0;
																IL_0478:
																if (1 > b)
																{
																}
																goto IL_05f0;
																IL_048b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_04cb;
																IL_04cb:
																array[num5 - 2] = 0;
																goto IL_04df;
																IL_04df:
																num5--;
																num = 26;
																goto end_IL_01e7;
																IL_04fb:
																if (3 < b)
																{
																	goto IL_0509;
																}
																goto IL_0595;
																IL_0509:
																if (4 >= b)
																{
																	goto IL_0517;
																}
																goto IL_05f0;
																IL_0517:
																if (4 <= b)
																{
																	goto IL_0525;
																}
																goto IL_05f0;
																IL_0525:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 42;
																goto IL_056e;
																IL_056e:
																array[num5 - 2] = 0;
																goto IL_0582;
																IL_0582:
																num5--;
																goto end_IL_01e7;
																IL_0595:
																if (3 <= b)
																{
																	goto IL_05a0;
																}
																goto IL_05f0;
																IL_05a0:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05c9;
																IL_05c9:
																ptr2 += 8;
																num = 68;
																goto IL_05e0;
																continue;
																end_IL_01d7:
																break;
															}
															continue;
															end_IL_01e7:
															break;
														}
														continue;
													}
													goto IL_06f3;
													IL_06f3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_063d:
													break;
												}
												continue;
												end_IL_0650:
												break;
											}
											continue;
											end_IL_065a:
											break;
										}
										continue;
										end_IL_0665:
										break;
									}
									continue;
									end_IL_0683:
									break;
								}
								continue;
								end_IL_0698:
								break;
							}
							continue;
							end_IL_06a8:
							break;
						}
						continue;
						end_IL_06b8:
						break;
					}
					continue;
					end_IL_06c8:
					break;
				}
				continue;
				end_IL_06d8:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_4)
	{
		int num = 69;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 22;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref INVOKEFUNCgetAsyncWaitHandle.TimeoutHelperAllowHexSpecifier);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 66;
																while (true)
																{
																	IL_0240:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0210:
																						if (5 > b)
																						{
																							goto IL_029f;
																						}
																						while (true)
																						{
																							IL_0200:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_01d2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								num = 108;
																								while (true)
																								{
																									if (num != 108)
																									{
																										if (num != 1089)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 52:
																											goto IL_01d2;
																										case 40:
																										case 78:
																											goto IL_0200;
																										case 86:
																											goto IL_0210;
																										case 3:
																											goto end_IL_0210;
																										case 15:
																											goto end_IL_0220;
																										case 66:
																											goto IL_0240;
																										case 14:
																											goto end_IL_0240;
																										case 0:
																										case 9:
																											goto end_IL_0250;
																										case 2:
																											goto IL_027e;
																										case 51:
																											goto IL_028c;
																										case 23:
																											goto IL_029f;
																										case 5:
																											goto IL_02ad;
																										case 74:
																										case 82:
																											goto end_IL_01bf;
																										case 53:
																											goto IL_02c6;
																										case 46:
																										case 79:
																											goto IL_02d4;
																										case 50:
																											goto IL_02ed;
																										case 27:
																											goto IL_02fb;
																										case 39:
																											goto IL_0309;
																										case 6:
																										case 99:
																											goto IL_031c;
																										case 73:
																											goto IL_0345;
																										case 25:
																											goto IL_0353;
																										case 31:
																											goto IL_0366;
																										case 62:
																											goto IL_0371;
																										case 36:
																										case 55:
																											goto IL_037f;
																										case 37:
																											goto IL_0397;
																										case 21:
																											goto IL_03a5;
																										case 60:
																											goto IL_03b8;
																										case 11:
																										case 80:
																											goto IL_03c3;
																										case 7:
																											goto IL_03ce;
																										case 17:
																										case 64:
																											goto IL_03dc;
																										case 20:
																											goto IL_03f8;
																										case 57:
																											goto IL_040f;
																										case 75:
																											goto IL_0422;
																										case 61:
																										case 90:
																											goto IL_042d;
																										case 29:
																											goto IL_048f;
																										case 16:
																											goto IL_04a2;
																										case 47:
																											goto IL_04b6;
																										case 32:
																										case 89:
																											goto IL_04c4;
																										case 13:
																											goto IL_0504;
																										case 97:
																											goto IL_0518;
																										case 95:
																											goto IL_0528;
																										case 100:
																											goto IL_0533;
																										case 26:
																										case 72:
																											goto IL_053e;
																										case 33:
																											goto IL_0561;
																										case 41:
																											goto IL_056f;
																										case 84:
																											goto IL_057d;
																										case 1:
																										case 4:
																										case 24:
																										case 42:
																										case 43:
																										case 44:
																										case 48:
																										case 54:
																										case 59:
																										case 63:
																										case 70:
																										case 77:
																										case 83:
																										case 85:
																										case 88:
																										case 91:
																										case 92:
																										case 94:
																										case 101:
																											goto end_IL_0230;
																										case 10:
																										case 12:
																										case 19:
																										case 38:
																										case 45:
																										case 49:
																										case 56:
																										case 65:
																										case 67:
																										case 71:
																										case 76:
																										case 81:
																										case 87:
																											goto end_IL_0269;
																										case 98:
																											goto end_IL_05a0;
																										case 28:
																											goto end_IL_05b3;
																										case 30:
																											goto end_IL_05bd;
																										case 34:
																											goto end_IL_05c8;
																										case 18:
																										case 96:
																											goto end_IL_05dd;
																										case 35:
																											goto end_IL_05ed;
																										case 22:
																											goto end_IL_05fd;
																										case 93:
																											goto end_IL_060d;
																										case 68:
																											goto end_IL_061d;
																										case 69:
																											goto end_IL_0628;
																										case 8:
																										case 58:
																											goto IL_0643;
																										}
																										continue;
																									}
																									array2[num5] = null;
																									goto IL_027e;
																									IL_027e:
																									num5++;
																									goto IL_028c;
																									IL_028c:
																									ptr2 += 8;
																									goto end_IL_0269;
																									continue;
																									end_IL_01bf:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02b8;
																						IL_03a5:
																						if (4 > b)
																						{
																							goto end_IL_0230;
																						}
																						goto end_IL_0269;
																						IL_029f:
																						if (2 >= b)
																						{
																							goto IL_02ad;
																						}
																						goto IL_0366;
																						IL_02ad:
																						if (2 > b)
																						{
																							goto IL_02b8;
																						}
																						goto IL_031c;
																						IL_02b8:
																						if (1 < b)
																						{
																							goto end_IL_0230;
																						}
																						goto IL_02c6;
																						IL_02c6:
																						if (1 > b)
																						{
																							goto end_IL_0230;
																						}
																						goto IL_02d4;
																						IL_02d4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_02ed;
																						IL_02ed:
																						array[num5] = 0;
																						goto IL_02fb;
																						IL_02fb:
																						num5++;
																						goto IL_0309;
																						IL_0309:
																						ptr2 += 8;
																						goto end_IL_0269;
																						IL_031c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0345;
																						IL_0345:
																						ptr2 += 8;
																						goto IL_0353;
																						IL_0353:
																						num5--;
																						goto end_IL_0269;
																						IL_0366:
																						if (3 >= b)
																						{
																							goto IL_0371;
																						}
																						goto IL_0397;
																						IL_0371:
																						if (3 > b)
																						{
																							goto end_IL_0230;
																						}
																						goto IL_037f;
																						IL_037f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0269;
																						IL_0397:
																						if (4 < b)
																						{
																							goto end_IL_0230;
																						}
																						goto IL_03a5;
																						continue;
																						end_IL_0210:
																						break;
																					}
																					continue;
																				}
																				goto IL_03b8;
																				IL_0561:
																				array[num5] = 0;
																				goto IL_056f;
																				IL_03b8:
																				if (8 < b)
																				{
																					goto IL_03c3;
																				}
																				goto IL_0422;
																				IL_03c3:
																				if (9 >= b)
																				{
																					goto IL_03ce;
																				}
																				goto IL_03f8;
																				IL_03ce:
																				if (9 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_03dc;
																				IL_03dc:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0269;
																				IL_03f8:
																				if (10 < b)
																				{
																					goto end_IL_0230;
																				}
																				num = 57;
																				goto IL_040f;
																				IL_056f:
																				num5++;
																				goto IL_057d;
																				IL_040f:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0230;
																				IL_0422:
																				if (8 <= b)
																				{
																					goto IL_042d;
																				}
																				goto IL_04a2;
																				IL_042d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_048f;
																				IL_048f:
																				num5 -= 2;
																				goto end_IL_0269;
																				IL_04a2:
																				if (6 >= b)
																				{
																					num = 47;
																					goto IL_04b6;
																				}
																				goto IL_0528;
																				IL_057d:
																				ptr2 += 8;
																				goto end_IL_0269;
																				IL_04b6:
																				if (6 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_04c4;
																				IL_04c4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0504;
																				IL_0504:
																				array[num5 - 2] = 0;
																				goto IL_0518;
																				IL_0518:
																				num5--;
																				goto end_IL_0269;
																				IL_0528:
																				if (7 < b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_0533;
																				IL_0533:
																				if (7 > b)
																				{
																					goto end_IL_0230;
																				}
																				goto IL_053e;
																				IL_053e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0561;
																				continue;
																				end_IL_0220:
																				break;
																			}
																			continue;
																			end_IL_0230:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0269;
																	continue;
																	end_IL_0240:
																	break;
																}
																continue;
																end_IL_0250:
																break;
															}
															continue;
															end_IL_0269:
															break;
														}
														continue;
													}
													goto IL_0643;
													IL_0643:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05a0:
													break;
												}
												continue;
												end_IL_05b3:
												break;
											}
											continue;
											end_IL_05bd:
											break;
										}
										continue;
										end_IL_05c8:
										break;
									}
									continue;
									end_IL_05dd:
									break;
								}
								continue;
								end_IL_05ed:
								break;
							}
							continue;
							end_IL_05fd:
							break;
						}
						continue;
						end_IL_060d:
						break;
					}
					continue;
					end_IL_061d:
					break;
				}
				continue;
				end_IL_0628:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_4)
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BinaryConverterUrtUser.CompilationRelaxationsAttributeCreateDelegate);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02a0:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_0280:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_0270:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0260:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0250:
																									if (5 >= b)
																									{
																										num = 136;
																										while (true)
																										{
																											if (num != 136)
																											{
																												if (num != 1117)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 66:
																												case 70:
																													goto IL_0250;
																												case 74:
																													goto IL_0260;
																												case 56:
																													goto IL_0270;
																												case 79:
																													goto IL_0280;
																												case 82:
																													goto end_IL_0280;
																												case 73:
																													goto IL_02a0;
																												case 122:
																													goto end_IL_02a0;
																												case 30:
																												case 116:
																													goto end_IL_02b0;
																												case 81:
																													goto IL_02cb;
																												case 51:
																													goto IL_02d9;
																												case 26:
																												case 40:
																													goto IL_02e4;
																												case 67:
																													goto IL_0324;
																												case 17:
																													goto IL_0338;
																												case 6:
																												case 108:
																													goto IL_0359;
																												case 46:
																													goto IL_037c;
																												case 50:
																													goto IL_038a;
																												case 24:
																													goto IL_0398;
																												case 83:
																												case 123:
																													goto IL_03ab;
																												case 68:
																													goto IL_03b9;
																												case 15:
																												case 112:
																													goto IL_03c7;
																												case 95:
																													goto IL_03db;
																												case 13:
																													goto IL_042f;
																												case 39:
																													goto IL_043d;
																												case 63:
																													goto IL_0450;
																												case 35:
																												case 65:
																													goto IL_045e;
																												case 10:
																													goto IL_046c;
																												case 4:
																												case 32:
																													goto IL_047a;
																												case 18:
																													goto IL_04ba;
																												case 53:
																													goto IL_04ce;
																												case 91:
																													goto end_IL_023d;
																												case 28:
																												case 47:
																													goto IL_04ef;
																												case 103:
																													goto IL_0551;
																												case 78:
																												case 84:
																													goto IL_0564;
																												case 92:
																													goto IL_056f;
																												case 21:
																													goto IL_057a;
																												case 111:
																													goto IL_0588;
																												case 25:
																												case 71:
																													goto IL_0596;
																												case 76:
																													goto IL_05b4;
																												case 36:
																													goto IL_05c2;
																												case 100:
																												case 125:
																													goto IL_05d5;
																												case 59:
																												case 93:
																													goto IL_05fc;
																												case 88:
																													goto IL_060a;
																												case 72:
																												case 126:
																													goto IL_061d;
																												case 115:
																													goto IL_062b;
																												case 101:
																													goto IL_064e;
																												case 62:
																													goto IL_0658;
																												case 29:
																													goto IL_0666;
																												case 27:
																													goto IL_0679;
																												case 0:
																												case 61:
																													goto IL_0687;
																												case 9:
																													goto IL_0692;
																												case 11:
																												case 120:
																													goto IL_06a0;
																												case 5:
																													goto IL_06b9;
																												case 16:
																													goto IL_06c7;
																												case 69:
																													goto IL_06d5;
																												case 109:
																													goto IL_06e8;
																												case 77:
																													goto IL_06f3;
																												case 89:
																												case 94:
																													goto IL_06fe;
																												case 33:
																													goto IL_0727;
																												case 8:
																													goto IL_0735;
																												case 43:
																												case 98:
																													goto IL_0745;
																												case 1:
																												case 3:
																												case 14:
																												case 19:
																												case 37:
																												case 38:
																												case 49:
																												case 52:
																												case 55:
																												case 57:
																												case 58:
																												case 64:
																												case 80:
																												case 85:
																												case 86:
																												case 87:
																												case 97:
																												case 104:
																												case 105:
																												case 110:
																												case 118:
																												case 128:
																												case 129:
																													goto end_IL_0290;
																												case 2:
																												case 12:
																												case 22:
																												case 23:
																												case 31:
																												case 42:
																												case 44:
																												case 45:
																												case 48:
																												case 60:
																												case 75:
																												case 96:
																												case 102:
																												case 106:
																												case 107:
																												case 117:
																													goto end_IL_02c0;
																												case 90:
																													goto end_IL_076d;
																												case 124:
																													goto end_IL_0780;
																												case 20:
																													goto end_IL_078a;
																												case 54:
																													goto end_IL_0795;
																												case 34:
																												case 127:
																													goto end_IL_07aa;
																												case 121:
																													goto end_IL_07ba;
																												case 99:
																												case 119:
																													goto end_IL_07ca;
																												case 113:
																													goto end_IL_07da;
																												case 114:
																													goto end_IL_07ea;
																												case 7:
																												case 41:
																													goto IL_0805;
																												}
																												continue;
																											}
																											if (5 > b)
																											{
																												goto IL_05fc;
																											}
																											goto IL_061d;
																											IL_064e:
																											array2[num5] = null;
																											goto IL_0658;
																											IL_0666:
																											ptr2 += 8;
																											goto end_IL_02c0;
																											IL_0658:
																											num5++;
																											goto IL_0666;
																											IL_05fc:
																											if (4 < b)
																											{
																												goto end_IL_0290;
																											}
																											goto IL_060a;
																											IL_060a:
																											if (4 <= b)
																											{
																												goto end_IL_02c0;
																											}
																											goto end_IL_0290;
																											IL_061d:
																											array[num5] = 0;
																											goto IL_062b;
																											IL_062b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_064e;
																											continue;
																											end_IL_023d:
																											break;
																										}
																										break;
																									}
																									goto IL_02cb;
																									IL_0324:
																									array[num5 - 2] = 0;
																									goto IL_0338;
																									IL_0338:
																									num5--;
																									goto end_IL_02c0;
																									IL_02cb:
																									if (6 < b)
																									{
																										goto end_IL_0290;
																									}
																									goto IL_02d9;
																									IL_02d9:
																									if (6 > b)
																									{
																										num = 38;
																										goto end_IL_0290;
																									}
																									goto IL_02e4;
																									IL_02e4:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0324;
																								}
																								break;
																							}
																							goto IL_0679;
																							IL_0745:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02c0;
																							IL_0679:
																							if (3 > b)
																							{
																								goto IL_0687;
																							}
																							goto IL_0745;
																							IL_0687:
																							if (1 >= b)
																							{
																								goto IL_0692;
																							}
																							goto IL_06e8;
																							IL_0692:
																							if (1 > b)
																							{
																								goto end_IL_0290;
																							}
																							goto IL_06a0;
																							IL_06a0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_06b9;
																							IL_06b9:
																							array[num5] = 0;
																							goto IL_06c7;
																							IL_06c7:
																							num5++;
																							goto IL_06d5;
																							IL_06d5:
																							ptr2 += 8;
																							goto end_IL_02c0;
																							IL_06e8:
																							if (2 < b)
																							{
																								goto end_IL_0290;
																							}
																							goto IL_06f3;
																							IL_06f3:
																							if (2 > b)
																							{
																								goto end_IL_0290;
																							}
																							goto IL_06fe;
																							IL_06fe:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0727;
																							IL_0727:
																							ptr2 += 8;
																							goto IL_0735;
																							IL_0735:
																							num5--;
																							goto end_IL_02c0;
																						}
																						break;
																					}
																					goto IL_0359;
																					IL_0398:
																					ptr2 += 8;
																					goto end_IL_02c0;
																					IL_0359:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_037c;
																					IL_037c:
																					array[num5] = 0;
																					goto IL_038a;
																					IL_038a:
																					num5++;
																					goto IL_0398;
																				}
																				goto IL_04e1;
																			}
																			goto IL_03ab;
																			IL_05b4:
																			if (13 < b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_05c2;
																			IL_03ab:
																			if (10 >= b)
																			{
																				goto IL_03b9;
																			}
																			goto IL_0564;
																			IL_03b9:
																			if (10 <= b)
																			{
																				goto IL_03c7;
																			}
																			goto IL_0450;
																			IL_03c7:
																			array[num5 - 2] = 0;
																			goto IL_03db;
																			IL_03db:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)FUNCFLAGFUIDEFAULTText[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_042f;
																			IL_042f:
																			num5--;
																			goto IL_043d;
																			IL_043d:
																			ptr2 += 8;
																			goto end_IL_02c0;
																			IL_0450:
																			if (8 < b)
																			{
																				goto IL_045e;
																			}
																			goto IL_04e1;
																			IL_045e:
																			if (9 < b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_046c;
																			IL_046c:
																			if (9 > b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_047a;
																			IL_047a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04ba;
																			IL_04ba:
																			array[num5 - 2] = 0;
																			goto IL_04ce;
																			IL_04ce:
																			num5--;
																			goto end_IL_02c0;
																			IL_04e1:
																			if (8 > b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_04ef;
																			IL_04ef:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0551;
																			IL_0551:
																			num5 -= 2;
																			goto end_IL_02c0;
																			IL_0564:
																			if (12 >= b)
																			{
																				goto IL_056f;
																			}
																			goto IL_05b4;
																			IL_056f:
																			if (12 > b)
																			{
																				goto IL_057a;
																			}
																			num = 100;
																			goto IL_05d5;
																			IL_057a:
																			if (11 < b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_0588;
																			IL_0588:
																			if (11 > b)
																			{
																				goto end_IL_0290;
																			}
																			goto IL_0596;
																			IL_0596:
																			num5--;
																			goto end_IL_02c0;
																			IL_05c2:
																			if (13 <= b)
																			{
																			}
																			goto end_IL_0290;
																			IL_05d5:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02c0;
																			continue;
																			end_IL_0280:
																			break;
																		}
																		continue;
																		end_IL_0290:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02c0;
																continue;
																end_IL_02a0:
																break;
															}
															continue;
															end_IL_02b0:
															break;
														}
														continue;
														end_IL_02c0:
														break;
													}
													continue;
												}
												goto IL_0805;
												IL_0805:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_076d:
												break;
											}
											continue;
											end_IL_0780:
											break;
										}
										continue;
										end_IL_078a:
										break;
									}
									continue;
									end_IL_0795:
									break;
								}
								continue;
								end_IL_07aa:
								break;
							}
							continue;
							end_IL_07ba:
							break;
						}
						continue;
						end_IL_07ca:
						break;
					}
					continue;
					end_IL_07da:
					break;
				}
				continue;
				end_IL_07ea:
				break;
			}
		}
	}

	private static int smethod_17(int int_4)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_4;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private static int smethod_18()
	{
		int num = 55;
		int num2 = 11;
		num = 5;
		object obj = new int[5];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 39;
		num3 = 13;
		((int[])obj)[0] = 13;
		obj = obj2;
		num2 = 1;
		num3 = 172;
		num3 = 43;
		((int[])obj)[1] = 43;
		obj = obj2;
		num2 = 10;
		num3 = 5;
		num2 = 2;
		num3 = 8;
		num3 = 4;
		((int[])obj)[2] = 4;
		obj = obj2;
		num2 = 9;
		num3 = 3;
		num2 = 3;
		num3 = 112;
		num3 = 28;
		((int[])obj)[3] = 28;
		obj = obj2;
		num2 = 28;
		num3 = 7;
		num2 = 4;
		num3 = 66;
		num3 = 22;
		((int[])obj)[4] = 22;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 20;
			num3 = 4;
			num2 = 5;
			if (num >= 5)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_19(int int_4, int int_5)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 44;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_4;
									while (true)
									{
										array3[1] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaskSchedulerAwaitTaskContinuationRegisterDynamicProperty.getFiltergetStart);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0211:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01ee:
																				if (4 >= b)
																				{
																					num = 34;
																					while (true)
																					{
																						IL_01e1:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01d1:
																								if (2 < b)
																								{
																									while (3 >= b)
																									{
																										num = 96;
																										while (true)
																										{
																											if (num != 96)
																											{
																												if (num != 1077)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 32:
																													goto IL_01be;
																												case 5:
																													goto IL_01d1;
																												case 34:
																													goto IL_01e1;
																												case 24:
																													goto IL_01ee;
																												case 36:
																													goto IL_0201;
																												case 82:
																													goto IL_0211;
																												case 20:
																													goto end_IL_0211;
																												case 25:
																												case 45:
																													goto end_IL_0221;
																												case 1:
																												case 54:
																													goto IL_023c;
																												case 47:
																													goto IL_0265;
																												case 49:
																													goto IL_0273;
																												case 55:
																													goto IL_028f;
																												case 60:
																													goto IL_02a2;
																												case 31:
																												case 52:
																													goto IL_02ad;
																												case 4:
																													goto IL_02bb;
																												case 14:
																												case 21:
																													goto IL_02ce;
																												case 63:
																													goto IL_033c;
																												case 58:
																												case 69:
																													goto IL_034f;
																												case 40:
																												case 68:
																													goto IL_035a;
																												case 19:
																													goto IL_0368;
																												case 57:
																													goto IL_0378;
																												case 27:
																												case 71:
																													goto IL_0391;
																												case 75:
																												case 79:
																													goto IL_03ad;
																												case 8:
																													goto IL_03bb;
																												case 22:
																													goto IL_03de;
																												case 17:
																													goto IL_03e8;
																												case 37:
																													goto IL_03f6;
																												case 88:
																													goto IL_0409;
																												case 2:
																												case 53:
																													goto IL_0417;
																												case 50:
																													goto IL_0422;
																												case 38:
																												case 43:
																													goto IL_0430;
																												case 18:
																												case 46:
																													goto IL_046c;
																												case 3:
																													goto IL_04ac;
																												case 77:
																													goto IL_04c9;
																												case 0:
																												case 6:
																												case 9:
																												case 10:
																												case 12:
																												case 13:
																												case 15:
																												case 23:
																												case 30:
																												case 33:
																												case 56:
																												case 64:
																												case 67:
																												case 70:
																												case 72:
																												case 83:
																												case 87:
																													goto end_IL_01ab;
																												case 41:
																													goto IL_04fc;
																												case 76:
																													goto IL_050a;
																												case 74:
																													goto IL_0518;
																												case 7:
																												case 11:
																												case 35:
																												case 42:
																												case 61:
																												case 62:
																												case 65:
																												case 73:
																												case 78:
																												case 84:
																												case 89:
																													goto end_IL_0231;
																												case 39:
																													goto end_IL_0526;
																												case 48:
																													goto end_IL_0539;
																												case 28:
																													goto end_IL_0543;
																												case 29:
																													goto end_IL_054e;
																												case 44:
																													goto end_IL_0563;
																												case 59:
																												case 86:
																													goto end_IL_0578;
																												case 85:
																													goto end_IL_0588;
																												case 26:
																												case 66:
																													goto end_IL_05a1;
																												case 80:
																													goto end_IL_05b1;
																												case 81:
																													goto end_IL_05c1;
																												case 16:
																												case 51:
																													goto IL_05dc;
																												}
																												continue;
																											}
																											if (3 > b)
																											{
																												num = 9;
																												break;
																											}
																											goto IL_046c;
																											IL_04c9:
																											num5--;
																											goto end_IL_0231;
																											IL_04ac:
																											array[num5 - 2] = 0;
																											num = 77;
																											goto IL_04c9;
																											IL_046c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_04ac;
																											continue;
																											end_IL_01ab:
																											break;
																										}
																										break;
																										IL_01be:;
																									}
																									break;
																								}
																								goto IL_02a2;
																								IL_033c:
																								num5 -= 2;
																								goto end_IL_0231;
																								IL_02a2:
																								if (2 > b)
																								{
																									goto IL_02ad;
																								}
																								goto IL_02ce;
																								IL_02ad:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_02bb;
																								IL_02bb:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_02ce:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_033c;
																							}
																							break;
																						}
																						goto IL_023c;
																						IL_0273:
																						num5--;
																						num = 42;
																						goto end_IL_0231;
																						IL_023c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0265;
																						IL_0265:
																						ptr2 += 8;
																						goto IL_0273;
																					}
																					break;
																				}
																				goto IL_028f;
																				IL_0417:
																				if (5 < b)
																				{
																					num = 15;
																					break;
																				}
																				goto IL_0422;
																				IL_0422:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0430;
																				IL_028f:
																				if (6 < b)
																				{
																					goto IL_034f;
																				}
																				goto IL_0409;
																				IL_034f:
																				if (7 < b)
																				{
																					goto IL_035a;
																				}
																				goto IL_0378;
																				IL_035a:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0368;
																				IL_0368:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0391;
																				IL_0391:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0231;
																				IL_0378:
																				if (7 > b)
																				{
																					num = 12;
																					break;
																				}
																				goto IL_03ad;
																				IL_0430:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0231;
																				IL_03ad:
																				array[num5] = 0;
																				goto IL_03bb;
																				IL_03bb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03de;
																				IL_03de:
																				array2[num5] = null;
																				goto IL_03e8;
																				IL_03e8:
																				num5++;
																				goto IL_03f6;
																				IL_03f6:
																				ptr2 += 8;
																				goto end_IL_0231;
																				IL_0409:
																				if (6 <= b)
																				{
																					goto end_IL_0231;
																				}
																				goto IL_0417;
																			}
																			break;
																			IL_0201:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04fc;
																	IL_0518:
																	ptr2 += 8;
																	goto end_IL_0231;
																	IL_050a:
																	num5++;
																	goto IL_0518;
																	IL_04fc:
																	array[num5] = 0;
																	goto IL_050a;
																	continue;
																	end_IL_0211:
																	break;
																}
																continue;
																end_IL_0221:
																break;
															}
															continue;
															end_IL_0231:
															break;
														}
														continue;
													}
													goto IL_05dc;
													IL_05dc:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0526:
													break;
												}
												continue;
												end_IL_0539:
												break;
											}
											continue;
											end_IL_0543:
											break;
										}
										continue;
										end_IL_054e:
										break;
									}
									continue;
									end_IL_0563:
									break;
								}
								continue;
								end_IL_0578:
								break;
							}
							continue;
							end_IL_0588:
							break;
						}
						continue;
						end_IL_05a1:
						break;
					}
					continue;
					end_IL_05b1:
					break;
				}
				continue;
				end_IL_05c1:
				break;
			}
		}
	}

	private unsafe static int smethod_20()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref INVOCATIONFLAGSCONTAINSSTACKPOINTERSDateTimeFormatFlags.getNumberLockFindConnectionPoint);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02f4:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02d7:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02c7:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_02b7:
																							if (14 < b)
																							{
																								while (15 >= b)
																								{
																									num = 157;
																									while (true)
																									{
																										if (num != 157)
																										{
																											if (num != 1138)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 83:
																											case 135:
																												goto IL_02a4;
																											case 33:
																											case 52:
																												goto IL_02b7;
																											case 16:
																											case 68:
																												goto IL_02c7;
																											case 111:
																												goto IL_02d7;
																											case 29:
																												goto IL_02e4;
																											case 134:
																												goto IL_02f4;
																											case 30:
																												goto end_IL_02f4;
																											case 77:
																											case 98:
																												goto end_IL_0304;
																											case 104:
																												goto IL_031f;
																											case 11:
																											case 48:
																												goto IL_032a;
																											case 142:
																												goto IL_0342;
																											case 65:
																											case 133:
																												goto IL_0350;
																											case 36:
																												goto IL_035e;
																											case 117:
																												goto IL_0369;
																											case 138:
																												goto IL_0377;
																											case 27:
																											case 118:
																												goto IL_0385;
																											case 4:
																												goto IL_0393;
																											case 13:
																												goto IL_03b4;
																											case 80:
																												goto IL_03cb;
																											case 82:
																											case 113:
																												goto IL_03de;
																											case 99:
																												goto IL_0426;
																											case 6:
																												goto IL_0439;
																											case 8:
																											case 114:
																												goto IL_0444;
																											case 62:
																												goto IL_0462;
																											case 122:
																												goto IL_0470;
																											case 79:
																												goto IL_0483;
																											case 10:
																											case 51:
																												goto IL_048e;
																											case 103:
																												goto IL_049c;
																											case 3:
																											case 132:
																												goto IL_04aa;
																											case 73:
																												goto IL_04d3;
																											case 101:
																												goto IL_04ec;
																											case 22:
																											case 41:
																												goto IL_04f7;
																											case 129:
																												goto IL_0537;
																											case 74:
																												goto IL_054b;
																											case 21:
																												goto IL_055e;
																											case 78:
																												goto IL_056c;
																											case 15:
																											case 63:
																												goto IL_057a;
																											case 75:
																												goto IL_0593;
																											case 54:
																												goto IL_05aa;
																											case 125:
																												goto IL_05b8;
																											case 19:
																											case 145:
																												goto IL_05d4;
																											case 34:
																												goto IL_05e2;
																											case 42:
																											case 97:
																												goto end_IL_0291;
																											case 23:
																												goto IL_0619;
																											case 45:
																												goto IL_0627;
																											case 91:
																												goto IL_064d;
																											case 46:
																											case 94:
																												goto IL_0658;
																											case 136:
																												goto IL_0674;
																											case 44:
																												goto IL_0682;
																											case 20:
																											case 60:
																												goto IL_0690;
																											case 55:
																												goto IL_06f2;
																											case 102:
																												goto IL_0705;
																											case 57:
																											case 88:
																												goto IL_0713;
																											case 108:
																											case 126:
																												goto IL_0721;
																											case 64:
																												goto IL_0738;
																											case 67:
																											case 123:
																												goto IL_0746;
																											case 66:
																												goto IL_078a;
																											case 112:
																												goto IL_079e;
																											case 147:
																												goto IL_07b1;
																											case 127:
																												goto IL_07bc;
																											case 59:
																												goto IL_07d3;
																											case 37:
																											case 146:
																												goto IL_07e6;
																											case 89:
																												goto IL_07fd;
																											case 137:
																												goto IL_0820;
																											case 50:
																												goto IL_082a;
																											case 105:
																												goto IL_0841;
																											case 14:
																											case 38:
																												goto IL_0851;
																											case 115:
																												goto IL_0891;
																											case 24:
																												goto IL_08a5;
																											case 7:
																											case 17:
																											case 18:
																											case 39:
																											case 43:
																											case 49:
																											case 53:
																											case 56:
																											case 58:
																											case 69:
																											case 71:
																											case 76:
																											case 81:
																											case 86:
																											case 87:
																											case 90:
																											case 95:
																											case 96:
																											case 100:
																											case 106:
																											case 107:
																											case 110:
																											case 116:
																											case 119:
																											case 124:
																											case 130:
																											case 144:
																											case 148:
																											case 150:
																												goto end_IL_02a4;
																											case 2:
																											case 5:
																											case 9:
																											case 25:
																											case 31:
																											case 40:
																											case 47:
																											case 61:
																											case 70:
																											case 84:
																											case 85:
																											case 92:
																											case 93:
																											case 109:
																											case 120:
																											case 121:
																											case 128:
																											case 139:
																												goto end_IL_0314;
																											case 149:
																												goto end_IL_08c8;
																											case 140:
																												goto end_IL_08db;
																											case 12:
																												goto end_IL_08e5;
																											case 143:
																												goto end_IL_08f0;
																											case 26:
																											case 141:
																												goto end_IL_0900;
																											case 32:
																												goto end_IL_0910;
																											case 28:
																											case 131:
																												goto end_IL_0920;
																											case 0:
																												goto end_IL_0930;
																											case 1:
																												goto end_IL_0940;
																											case 35:
																											case 72:
																												goto IL_095b;
																											}
																											continue;
																										}
																										if (15 <= b)
																										{
																										}
																										goto end_IL_02a4;
																										continue;
																										end_IL_0291:
																										break;
																									}
																									goto IL_05f0;
																									continue;
																									end_IL_02a4:
																									break;
																									IL_02a4:;
																								}
																								break;
																							}
																							goto IL_064d;
																							IL_06f2:
																							num5 -= 2;
																							goto end_IL_0314;
																							IL_064d:
																							if (14 <= b)
																							{
																								goto IL_0658;
																							}
																							goto IL_0674;
																							IL_0658:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0314;
																							IL_0674:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0682;
																							IL_0682:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0690;
																							IL_0690:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_06f2;
																						}
																						break;
																					}
																					goto IL_0705;
																					IL_0851:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0891;
																					IL_0705:
																					if (12 > b)
																					{
																						goto IL_0713;
																					}
																					goto IL_0851;
																					IL_0713:
																					if (10 < b)
																					{
																						goto IL_0721;
																					}
																					goto IL_07b1;
																					IL_0721:
																					if (11 < b)
																					{
																						break;
																					}
																					num = 64;
																					goto IL_0738;
																					IL_0891:
																					array[num5 - 2] = 0;
																					goto IL_08a5;
																					IL_0738:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0746;
																					IL_0746:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_078a;
																					IL_078a:
																					array[num5 - 2] = 0;
																					goto IL_079e;
																					IL_079e:
																					num5--;
																					goto end_IL_0314;
																					IL_07b1:
																					if (10 > b)
																					{
																						goto IL_07bc;
																					}
																					goto IL_07e6;
																					IL_07bc:
																					if (9 < b)
																					{
																						break;
																					}
																					num = 59;
																					goto IL_07d3;
																					IL_08a5:
																					num5--;
																					goto end_IL_0314;
																					IL_07d3:
																					if (9 > b)
																					{
																						break;
																					}
																					goto end_IL_0314;
																					IL_07e6:
																					array[num5] = 0;
																					num = 89;
																					goto IL_07fd;
																					IL_07fd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0820;
																					IL_0820:
																					array2[num5] = null;
																					goto IL_082a;
																					IL_082a:
																					num5++;
																					num = 105;
																					goto IL_0841;
																					IL_0841:
																					ptr2 += 8;
																					goto end_IL_0314;
																				}
																				break;
																			}
																			goto IL_031f;
																			IL_05b8:
																			ptr2 += 8;
																			num = 31;
																			goto end_IL_0314;
																			IL_031f:
																			if (8 <= b)
																			{
																				goto IL_032a;
																			}
																			goto IL_0342;
																			IL_032a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0314;
																			IL_0342:
																			if (4 < b)
																			{
																				goto IL_0350;
																			}
																			goto IL_0439;
																			IL_0350:
																			if (6 >= b)
																			{
																				goto IL_035e;
																			}
																			goto IL_05d4;
																			IL_035e:
																			if (6 > b)
																			{
																				goto IL_0369;
																			}
																			goto IL_03de;
																			IL_0369:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0377;
																			IL_0377:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0385;
																			IL_0385:
																			array[num5] = 5;
																			goto IL_0393;
																			IL_0393:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 13;
																			goto IL_03b4;
																			IL_03b4:
																			num5++;
																			num = 80;
																			goto IL_03cb;
																			IL_03cb:
																			ptr2 += 8;
																			goto end_IL_0314;
																			IL_03de:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 99;
																			goto IL_0426;
																			IL_0426:
																			num5 -= 3;
																			goto end_IL_0314;
																			IL_05d4:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_05e2;
																			IL_05e2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_05f0;
																			IL_05f0:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0619;
																			IL_0619:
																			ptr2 += 8;
																			goto IL_0627;
																			IL_0627:
																			num5--;
																			goto end_IL_0314;
																			IL_0439:
																			if (4 <= b)
																			{
																				goto IL_0444;
																			}
																			goto IL_0483;
																			IL_0444:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0462;
																			IL_0462:
																			ptr2 += 8;
																			goto IL_0470;
																			IL_0470:
																			num5--;
																			goto end_IL_0314;
																			IL_0483:
																			if (2 < b)
																			{
																				goto IL_048e;
																			}
																			goto IL_04ec;
																			IL_048e:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_049c;
																			IL_049c:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_04aa;
																			IL_04aa:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04d3;
																			IL_04d3:
																			array[num5 - 1] = 5;
																			goto end_IL_0314;
																			IL_04ec:
																			if (2 <= b)
																			{
																				goto IL_04f7;
																			}
																			goto IL_055e;
																			IL_04f7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0537;
																			IL_0537:
																			array[num5 - 2] = 0;
																			goto IL_054b;
																			IL_054b:
																			num5--;
																			goto end_IL_0314;
																			IL_055e:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_056c;
																			IL_056c:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_057a;
																			IL_057a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0593;
																			IL_0593:
																			array[num5] = 0;
																			num = 54;
																			goto IL_05aa;
																			IL_05aa:
																			num5++;
																			goto IL_05b8;
																		}
																		break;
																		IL_02e4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0314;
																continue;
																end_IL_02f4:
																break;
															}
															continue;
															end_IL_0304:
															break;
														}
														continue;
														end_IL_0314:
														break;
													}
													continue;
												}
												goto IL_095b;
												IL_095b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c8:
												break;
											}
											continue;
											end_IL_08db:
											break;
										}
										continue;
										end_IL_08e5:
										break;
									}
									continue;
									end_IL_08f0:
									break;
								}
								continue;
								end_IL_0900:
								break;
							}
							continue;
							end_IL_0910:
							break;
						}
						continue;
						end_IL_0920:
						break;
					}
					continue;
					end_IL_0930:
					break;
				}
				continue;
				end_IL_0940:
				break;
			}
		}
	}

	static Class104()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0052:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 5:
								goto IL_0046;
							case 1:
								goto IL_0052;
							case 2:
								goto end_IL_0039;
							case 0:
								return;
							case 3:
								return;
							case 4:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
