using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Weird Gear Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns weird gears.", false, 8, ModType.const_0, false)]
internal class Class112 : Class93
{
	private static int int_3;

	private static bool bool_0;

	private static int int_4;

	private static float float_0;

	private static IntPtr[] AssignPrimarygetDriveFormat;

	private static IntPtr[] KeyValuePairsAuthenticationType;

	private static IntPtr[] DebugActivityIdInfiniteTimeSpan;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_03a9, IL_03bc, IL_03cf, IL_03df, IL_03ef, IL_03ff, IL_040f, IL_041f, IL_042f, IL_043a, IL_0445, IL_0458, IL_0466, IL_0474, IL_0482, IL_04c2, IL_04d6, IL_04e9, IL_04f7, IL_0537, IL_054b, IL_055e, IL_056c, IL_057a, IL_05c3, IL_05e0, IL_05f3, IL_05fc, IL_060a, IL_0618, IL_0683, IL_0696, IL_06a1, IL_06e1, IL_06f5, IL_0708, IL_0716, IL_0721, IL_072f, IL_0742, IL_078b, IL_079f, IL_07b2, IL_07c0, IL_07ce, IL_07d9, IL_07e7, IL_080a, IL_0814, IL_0822, IL_0835, IL_0843, IL_0851, IL_087a, IL_0888, IL_089b, IL_08b8, IL_090c, IL_091a, IL_092d, IL_093b, IL_0946, IL_0951, IL_095f, IL_096d, IL_0989, IL_0997, IL_09af, IL_09b8, IL_09c3, IL_09e5, IL_09f3, IL_0a01, IL_0a14, IL_0a22, IL_0a30, IL_0a3e, IL_0a5b, IL_0a93, IL_0aa6, IL_0ab4, IL_0af2, IL_0b0e, IL_0b17, IL_0b25, IL_0b33, IL_0b3e, IL_0b5c, IL_0b6a, IL_0b7d, IL_0b8b, IL_0b99, IL_0ba7, IL_0bc4, IL_0c13, IL_0c1d, IL_0c4a, IL_0c5e, IL_0c6c, IL_0c7f, IL_0c92, IL_0ca0, IL_0cae, IL_0cbc, IL_0cd4, IL_0cf2, IL_0d16, IL_0d2e, IL_0d41, IL_0d4f, IL_0d78, IL_0d91, IL_0d9f, IL_0db7, IL_0dce, IL_0dde, IL_0de7, IL_0e00, IL_0e0e, IL_0e1c, IL_0e2a, IL_0e3d, IL_0e47, IL_0e52, IL_0e62, IL_0e72, IL_0e82, IL_0e9b, IL_0eab, IL_0ebb, IL_0ecb, IL_0edb, IL_0eff are reachable both inside and outside the pinned region starting at IL_0ef9. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 183;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef28 = default(int);
				ref int reference = ref __rxRef28;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0edb:
						num2 = 1;
						num = 4;
						while (true)
						{
							IL_0ecb:
							num3 = num2 * 4;
							while (true)
							{
								IL_0ebb:
								num4 = num2 * 8;
								while (true)
								{
									IL_0eab:
									array2 = new byte[4];
									while (true)
									{
										IL_0e9b:
										array3 = new object[4];
										while (true)
										{
											IL_0e82:
											array4 = new int[4];
											num = 66;
											while (true)
											{
												IL_0e72:
												array5 = new int[6];
												while (true)
												{
													IL_0e62:
													array6 = new long[4];
													while (true)
													{
														IL_0e52:
														array7 = new object[10];
														while (true)
														{
															IL_0e47:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref JulianCalendarTrimToSize.NotCurrentlyProcessingVerifyHash);
															while (true)
															{
																IL_0e3d:
																ptr2 = ptr;
																while (true)
																{
																	IL_0e2a:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_042f:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_041f:
																				ptr2++;
																				while (true)
																				{
																					IL_040f:
																					if (b >= 1)
																					{
																						while (true)
																						{
																							IL_03ff:
																							if (b <= 22)
																							{
																								while (true)
																								{
																									IL_03ef:
																									if (11 < b)
																									{
																										goto IL_092d;
																									}
																									while (true)
																									{
																										IL_03df:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_03cf:
																												if (5 < b)
																												{
																													while (true)
																													{
																														IL_03bc:
																														if (8 >= b)
																														{
																															num = 227;
																															while (true)
																															{
																																if (num != 227)
																																{
																																	if (num != 1208)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 183:
																																		break;
																																	default:
																																		continue;
																																	case 149:
																																	case 207:
																																		goto IL_03bc;
																																	case 50:
																																	case 202:
																																		goto IL_03cf;
																																	case 58:
																																		goto IL_03df;
																																	case 108:
																																		goto IL_03ef;
																																	case 76:
																																		goto IL_03ff;
																																	case 198:
																																		goto IL_040f;
																																	case 124:
																																		goto IL_041f;
																																	case 65:
																																	case 125:
																																		goto IL_042f;
																																	case 16:
																																	case 33:
																																		goto IL_0445;
																																	case 189:
																																	case 219:
																																		goto IL_0458;
																																	case 80:
																																	case 181:
																																		goto IL_0466;
																																	case 6:
																																		goto IL_0474;
																																	case 132:
																																	case 210:
																																		goto IL_0482;
																																	case 184:
																																		goto IL_04c2;
																																	case 116:
																																		goto IL_04d6;
																																	case 44:
																																		goto IL_04e9;
																																	case 13:
																																	case 52:
																																		goto IL_04f7;
																																	case 220:
																																		goto IL_0537;
																																	case 69:
																																		goto IL_054b;
																																	case 216:
																																		goto IL_055e;
																																	case 84:
																																		goto IL_056c;
																																	case 152:
																																	case 153:
																																		goto IL_057a;
																																	case 73:
																																		goto IL_05c3;
																																	case 211:
																																		goto IL_05e0;
																																	case 90:
																																	case 205:
																																		goto IL_05fc;
																																	case 1:
																																		goto IL_060a;
																																	case 68:
																																	case 163:
																																		goto IL_0618;
																																	case 11:
																																		goto IL_0683;
																																	case 144:
																																		goto IL_0696;
																																	case 91:
																																	case 155:
																																		goto IL_06a1;
																																	case 173:
																																		goto IL_06e1;
																																	case 78:
																																		goto IL_06f5;
																																	case 141:
																																	case 161:
																																		goto IL_0708;
																																	case 38:
																																		goto IL_0716;
																																	case 199:
																																	case 214:
																																		goto IL_0721;
																																	case 92:
																																		goto IL_072f;
																																	case 81:
																																	case 115:
																																		goto IL_0742;
																																	case 130:
																																		goto IL_078b;
																																	case 123:
																																		goto IL_079f;
																																	case 139:
																																		goto IL_07b2;
																																	case 79:
																																	case 190:
																																		goto IL_07c0;
																																	case 63:
																																		goto IL_07ce;
																																	case 7:
																																	case 42:
																																		goto IL_07d9;
																																	case 77:
																																		goto IL_07e7;
																																	case 168:
																																		goto IL_080a;
																																	case 40:
																																		goto IL_0814;
																																	case 151:
																																		goto IL_0822;
																																	case 192:
																																		goto IL_0843;
																																	case 94:
																																	case 165:
																																		goto IL_0851;
																																	case 172:
																																		goto IL_087a;
																																	case 191:
																																		goto IL_0888;
																																	case 43:
																																	case 109:
																																		goto IL_089b;
																																	case 53:
																																		goto IL_08b8;
																																	case 213:
																																		goto IL_090c;
																																	case 71:
																																		goto IL_091a;
																																	case 122:
																																		goto IL_092d;
																																	case 146:
																																		goto IL_093b;
																																	case 2:
																																		goto IL_0946;
																																	case 93:
																																	case 154:
																																		goto IL_0951;
																																	case 118:
																																		goto IL_095f;
																																	case 111:
																																	case 167:
																																		goto IL_096d;
																																	case 174:
																																		goto IL_0989;
																																	case 27:
																																	case 203:
																																		goto IL_0997;
																																	case 26:
																																		goto IL_09b8;
																																	case 41:
																																	case 99:
																																		goto IL_09c3;
																																	case 45:
																																		goto IL_09e5;
																																	case 104:
																																		goto IL_09f3;
																																	case 195:
																																		goto IL_0a01;
																																	case 171:
																																		goto IL_0a14;
																																	case 74:
																																	case 126:
																																		goto IL_0a22;
																																	case 140:
																																		goto IL_0a30;
																																	case 89:
																																	case 188:
																																		goto IL_0a3e;
																																	case 34:
																																		goto IL_0a5b;
																																	case 160:
																																		goto IL_0a93;
																																	case 215:
																																		goto IL_0aa6;
																																	case 3:
																																	case 12:
																																		goto IL_0ab4;
																																	case 9:
																																		goto IL_0af2;
																																	case 166:
																																		goto IL_0b17;
																																	case 39:
																																	case 208:
																																		goto IL_0b25;
																																	case 36:
																																		goto IL_0b33;
																																	case 49:
																																	case 158:
																																		goto IL_0b3e;
																																	case 0:
																																		goto IL_0b5c;
																																	case 35:
																																		goto IL_0b6a;
																																	case 25:
																																		goto IL_0b7d;
																																	case 131:
																																	case 185:
																																		goto end_IL_03a9;
																																	case 59:
																																		goto IL_0b99;
																																	case 15:
																																	case 133:
																																		goto IL_0ba7;
																																	case 200:
																																		goto IL_0c5e;
																																	case 51:
																																		goto IL_0c6c;
																																	case 178:
																																		goto IL_0c7f;
																																	case 47:
																																		goto IL_0c92;
																																	case 85:
																																	case 107:
																																		goto IL_0ca0;
																																	case 194:
																																		goto IL_0cae;
																																	case 29:
																																	case 103:
																																		goto IL_0cbc;
																																	case 193:
																																		goto IL_0cd4;
																																	case 22:
																																		goto IL_0cf2;
																																	case 62:
																																		goto IL_0d16;
																																	case 60:
																																		goto IL_0d2e;
																																	case 98:
																																		goto IL_0d41;
																																	case 48:
																																	case 147:
																																		goto IL_0d4f;
																																	case 148:
																																		goto IL_0d78;
																																	case 20:
																																	case 186:
																																		goto IL_0d91;
																																	case 96:
																																		goto IL_0d9f;
																																	case 129:
																																		goto IL_0db7;
																																	case 28:
																																		goto IL_0dce;
																																	case 5:
																																	case 8:
																																	case 10:
																																	case 14:
																																	case 19:
																																	case 21:
																																	case 23:
																																	case 24:
																																	case 30:
																																	case 31:
																																	case 32:
																																	case 46:
																																	case 56:
																																	case 61:
																																	case 72:
																																	case 83:
																																	case 86:
																																	case 88:
																																	case 95:
																																	case 100:
																																	case 105:
																																	case 106:
																																	case 110:
																																	case 112:
																																	case 113:
																																	case 114:
																																	case 135:
																																	case 136:
																																	case 142:
																																	case 156:
																																	case 159:
																																	case 162:
																																	case 164:
																																	case 170:
																																	case 180:
																																	case 201:
																																	case 204:
																																	case 212:
																																	case 217:
																																	case 218:
																																		goto IL_0de7;
																																	case 177:
																																		goto IL_0e00;
																																	case 57:
																																		goto IL_0e0e;
																																	case 120:
																																		goto IL_0e1c;
																																	case 17:
																																	case 18:
																																	case 37:
																																	case 54:
																																	case 55:
																																	case 64:
																																	case 67:
																																	case 97:
																																	case 101:
																																	case 102:
																																	case 117:
																																	case 119:
																																	case 128:
																																	case 134:
																																	case 138:
																																	case 143:
																																	case 145:
																																	case 157:
																																	case 169:
																																	case 175:
																																	case 176:
																																	case 187:
																																	case 196:
																																	case 206:
																																	case 209:
																																		goto IL_0e2a;
																																	case 150:
																																		goto IL_0e3d;
																																	case 197:
																																		goto IL_0e47;
																																	case 127:
																																		goto IL_0e52;
																																	case 179:
																																		goto IL_0e62;
																																	case 66:
																																		goto IL_0e72;
																																	case 75:
																																		goto IL_0e82;
																																	case 87:
																																		goto IL_0e9b;
																																	case 82:
																																		goto IL_0eab;
																																	case 70:
																																		goto IL_0ebb;
																																	case 4:
																																		goto IL_0ecb;
																																	case 182:
																																		goto IL_0edb;
																																	case 121:
																																	case 137:
																																		goto IL_0eff;
																																	}
																																	goto end_IL_03ef;
																																}
																																if (8 <= b)
																																{
																																	goto IL_0445;
																																}
																																goto IL_0458;
																																IL_04f7:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0537;
																																IL_054b:
																																num6--;
																																goto IL_0e2a;
																																IL_0537:
																																array2[num6 - 2] = 0;
																																goto IL_054b;
																																IL_0445:
																																num6--;
																																goto IL_0e2a;
																																IL_0458:
																																if (6 < b)
																																{
																																	goto IL_0466;
																																}
																																goto IL_04e9;
																																IL_0466:
																																if (7 >= b)
																																{
																																	goto IL_0474;
																																}
																																goto IL_0de7;
																																IL_0474:
																																if (7 <= b)
																																{
																																	goto IL_0482;
																																}
																																goto IL_0de7;
																																IL_0482:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_04c2;
																																IL_04c2:
																																array2[num6 - 2] = 0;
																																goto IL_04d6;
																																IL_04d6:
																																num6--;
																																goto IL_0e2a;
																																IL_04e9:
																																if (6 <= b)
																																{
																																	goto IL_04f7;
																																}
																																goto IL_0de7;
																																continue;
																																end_IL_03a9:
																																break;
																															}
																															break;
																														}
																														goto IL_055e;
																														IL_060a:
																														if (10 <= b)
																														{
																															goto IL_0618;
																														}
																														goto IL_0de7;
																														IL_0618:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														num = 11;
																														goto IL_0683;
																														IL_055e:
																														if (9 >= b)
																														{
																															goto IL_056c;
																														}
																														num = 90;
																														goto IL_05fc;
																														IL_056c:
																														if (9 <= b)
																														{
																															goto IL_057a;
																														}
																														goto IL_0de7;
																														IL_057a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														num = 73;
																														goto IL_05c3;
																														IL_05c3:
																														array2[num6 - 2] = 0;
																														num = 211;
																														goto IL_05e0;
																														IL_05e0:
																														num6--;
																														goto IL_0e2a;
																														IL_0683:
																														num6 -= 2;
																														goto IL_0e2a;
																														IL_05fc:
																														if (10 >= b)
																														{
																															goto IL_060a;
																														}
																														goto IL_0de7;
																													}
																													break;
																												}
																												goto IL_0696;
																												IL_087a:
																												ptr2 += 8;
																												goto IL_0888;
																												IL_0696:
																												if (5 <= b)
																												{
																													goto IL_06a1;
																												}
																												goto IL_0708;
																												IL_06a1:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_06e1;
																												IL_06e1:
																												array2[num6 - 2] = 0;
																												goto IL_06f5;
																												IL_06f5:
																												num6--;
																												goto IL_0e2a;
																												IL_0708:
																												if (2 >= b)
																												{
																													goto IL_0716;
																												}
																												goto IL_07b2;
																												IL_0716:
																												if (2 > b)
																												{
																													goto IL_0721;
																												}
																												goto IL_0742;
																												IL_0721:
																												if (1 >= b)
																												{
																													goto IL_072f;
																												}
																												goto IL_0de7;
																												IL_072f:
																												if (1 <= b)
																												{
																												}
																												goto IL_0de7;
																												IL_0742:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 130;
																												goto IL_078b;
																												IL_078b:
																												array2[num6 - 2] = 0;
																												goto IL_079f;
																												IL_079f:
																												num6--;
																												goto IL_0e2a;
																												IL_07b2:
																												if (3 < b)
																												{
																													goto IL_07c0;
																												}
																												goto IL_0843;
																												IL_07c0:
																												if (4 >= b)
																												{
																													goto IL_07ce;
																												}
																												goto IL_0de7;
																												IL_07ce:
																												if (4 <= b)
																												{
																													goto IL_07d9;
																												}
																												num = 10;
																												goto IL_0de7;
																												IL_07d9:
																												array2[num6] = 0;
																												goto IL_07e7;
																												IL_07e7:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												goto IL_080a;
																												IL_080a:
																												array3[num6] = null;
																												goto IL_0814;
																												IL_0814:
																												num6++;
																												goto IL_0822;
																												IL_0822:
																												ptr2 += 8;
																												goto IL_0e2a;
																												IL_0888:
																												num6--;
																												goto IL_0e2a;
																												IL_0843:
																												if (3 <= b)
																												{
																													goto IL_0851;
																												}
																												goto IL_0de7;
																												IL_0851:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_087a;
																											}
																											break;
																										}
																										goto IL_089b;
																										IL_091a:
																										ptr2 += 8;
																										goto IL_0e2a;
																										IL_089b:
																										array2[num6 - 2] = 0;
																										num = 53;
																										goto IL_08b8;
																										IL_08b8:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)AssignPrimarygetDriveFormat[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_090c;
																										IL_090c:
																										num6--;
																										goto IL_091a;
																									}
																									goto IL_0b8b;
																									IL_0d4f:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0d78;
																									IL_092d:
																									if (17 < b)
																									{
																										goto IL_093b;
																									}
																									num = 166;
																									goto IL_0b17;
																									IL_093b:
																									if (20 < b)
																									{
																										goto IL_0946;
																									}
																									num = 26;
																									goto IL_09b8;
																									IL_0946:
																									if (21 < b)
																									{
																										goto IL_0951;
																									}
																									goto IL_0989;
																									IL_0951:
																									if (22 >= b)
																									{
																										goto IL_095f;
																									}
																									goto IL_0de7;
																									IL_095f:
																									if (22 <= b)
																									{
																										goto IL_096d;
																									}
																									goto IL_0de7;
																									IL_096d:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto IL_0e2a;
																									IL_0989:
																									if (21 <= b)
																									{
																										goto IL_0997;
																									}
																									goto IL_0de7;
																									IL_0997:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto IL_0e2a;
																									IL_0d91:
																									array2[num6] = 5;
																									goto IL_0d9f;
																									IL_09b8:
																									if (20 <= b)
																									{
																										goto IL_09c3;
																									}
																									goto IL_0a14;
																									IL_09c3:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									num = 45;
																									goto IL_09e5;
																									IL_09e5:
																									array2[num6] = 1;
																									goto IL_09f3;
																									IL_09f3:
																									num6++;
																									goto IL_0a01;
																									IL_0a01:
																									ptr2 += 16;
																									goto IL_0e2a;
																									IL_0a14:
																									if (18 < b)
																									{
																										goto IL_0a22;
																									}
																									goto IL_0aa6;
																									IL_0a22:
																									if (19 >= b)
																									{
																										goto IL_0a30;
																									}
																									goto IL_0de7;
																									IL_0a30:
																									if (19 <= b)
																									{
																										goto IL_0a3e;
																									}
																									goto IL_0de7;
																									IL_0a3e:
																									array2[num6 - 1] = 5;
																									num = 34;
																									goto IL_0a5b;
																									IL_0a5b:
																									array3[num6 - 1] = ((delegate*<string[], string>)AssignPrimarygetDriveFormat[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0a93;
																									IL_0a93:
																									ptr2 += 8;
																									goto IL_0e2a;
																									IL_0aa6:
																									if (18 <= b)
																									{
																										goto IL_0ab4;
																									}
																									goto IL_0de7;
																									IL_0ab4:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0af2;
																									IL_0af2:
																									num6 -= 3;
																									num = 145;
																									goto IL_0e2a;
																									IL_0d78:
																									array2[num6 - 1] = 5;
																									goto IL_0e2a;
																									IL_0b17:
																									if (17 > b)
																									{
																										goto IL_0b25;
																									}
																									goto IL_0d91;
																									IL_0b25:
																									if (14 >= b)
																									{
																										goto IL_0b33;
																									}
																									goto IL_0c92;
																									IL_0b33:
																									if (14 <= b)
																									{
																										goto IL_0b3e;
																									}
																									goto IL_0b7d;
																									IL_0b3e:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_0b5c;
																									IL_0b5c:
																									ptr2 += 8;
																									goto IL_0b6a;
																									IL_0b6a:
																									num6--;
																									goto IL_0e2a;
																									IL_0b7d:
																									if (12 < b)
																									{
																										goto IL_0b8b;
																									}
																									goto IL_0c7f;
																									IL_0b8b:
																									if (13 >= b)
																									{
																										goto IL_0b99;
																									}
																									goto IL_0de7;
																									IL_0b99:
																									if (13 <= b)
																									{
																										goto IL_0ba7;
																									}
																									goto IL_0de7;
																									IL_0ba7:
																									array8 = array3;
																									num9 = num6;
																									if (array == null)
																									{
																										goto IL_0bb6;
																									}
																									num10 = ptr2;
																									byte b2 = *num10;
																									ptr2 = num10 + 4;
																									int num11 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num11;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_0c5e;
																									IL_0d9f:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0db7;
																									IL_0db7:
																									num6++;
																									num = 28;
																									goto IL_0dce;
																									IL_0dce:
																									ptr2 += 8;
																									goto IL_0e2a;
																									IL_0c5e:
																									array2[num6] = 5;
																									goto IL_0c6c;
																									IL_0c6c:
																									num6++;
																									goto IL_0e2a;
																									IL_0c7f:
																									if (12 <= b)
																									{
																										goto IL_0e2a;
																									}
																									goto IL_0de7;
																									IL_0c92:
																									if (15 < b)
																									{
																										goto IL_0ca0;
																									}
																									goto IL_0d41;
																									IL_0ca0:
																									if (16 >= b)
																									{
																										goto IL_0cae;
																									}
																									goto IL_0de7;
																									IL_0cae:
																									if (16 <= b)
																									{
																										goto IL_0cbc;
																									}
																									goto IL_0de7;
																									IL_0cbc:
																									array2[num6] = array2[num6 - 1];
																									goto IL_0cd4;
																									IL_0cd4:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0cf2;
																									IL_0cf2:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0d16;
																									IL_0d16:
																									array3[num6] = array3[num6 - 1];
																									goto IL_0d2e;
																									IL_0d2e:
																									num6++;
																									goto IL_0e2a;
																									IL_0d41:
																									if (15 <= b)
																									{
																										goto IL_0d4f;
																									}
																									goto IL_0de7;
																									continue;
																									end_IL_03ef:
																									break;
																								}
																								break;
																							}
																							num = 5;
																							goto IL_0de7;
																						}
																						break;
																					}
																					goto IL_0de7;
																					IL_0e1c:
																					ptr2 += 8;
																					goto IL_0e2a;
																					IL_0de7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0e00;
																					IL_0e00:
																					array2[num6] = 0;
																					goto IL_0e0e;
																					IL_0e0e:
																					num6++;
																					goto IL_0e1c;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0eff;
																	IL_0eff:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0bb6:
				while (true)
				{
					IL_0bb6_2:
					array = new byte[4];
					while (true)
					{
						IL_0bc4:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0c6c_2:
								num6++;
								while (true)
								{
									IL_0e2a_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													if (b >= 1)
													{
														while (true)
														{
															if (b <= 22)
															{
																while (true)
																{
																	IL_03ef_2:
																	if (11 < b)
																	{
																		goto IL_092d_2;
																	}
																	while (true)
																	{
																		IL_03df_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_03cf_2:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_03bc_2:
																						if (8 >= b)
																						{
																							num = 227;
																							while (true)
																							{
																								if (num != 227)
																								{
																									if (num != 1208)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 149:
																									case 207:
																										goto IL_03bc_2;
																									case 50:
																									case 202:
																										goto IL_03cf_2;
																									case 58:
																										goto IL_03df_2;
																									case 108:
																										goto IL_03ef_2;
																									case 76:
																										goto end_IL_03ef_2;
																									case 198:
																										goto end_IL_03ff;
																									case 124:
																										goto end_IL_040f;
																									case 65:
																									case 125:
																										goto end_IL_041f;
																									case 16:
																									case 33:
																										goto IL_0445_2;
																									case 189:
																									case 219:
																										goto IL_0458_2;
																									case 80:
																									case 181:
																										goto IL_0466_2;
																									case 6:
																										goto IL_0474_2;
																									case 132:
																									case 210:
																										goto IL_0482_2;
																									case 184:
																										goto IL_04c2_2;
																									case 116:
																										goto IL_04d6_2;
																									case 44:
																										goto IL_04e9_2;
																									case 13:
																									case 52:
																										goto IL_04f7_2;
																									case 220:
																										goto IL_0537_2;
																									case 69:
																										goto IL_054b_2;
																									case 216:
																										goto IL_055e_2;
																									case 84:
																										goto IL_056c_2;
																									case 152:
																									case 153:
																										goto IL_057a_2;
																									case 73:
																										goto IL_05c3_2;
																									case 211:
																										goto IL_05e0_2;
																									case 90:
																									case 205:
																										goto IL_05fc_2;
																									case 1:
																										goto IL_060a_2;
																									case 68:
																									case 163:
																										goto IL_0618_2;
																									case 11:
																										goto IL_0683_2;
																									case 144:
																										goto IL_0696_2;
																									case 91:
																									case 155:
																										goto IL_06a1_2;
																									case 173:
																										goto IL_06e1_2;
																									case 78:
																										goto IL_06f5_2;
																									case 141:
																									case 161:
																										goto IL_0708_2;
																									case 38:
																										goto IL_0716_2;
																									case 199:
																									case 214:
																										goto IL_0721_2;
																									case 92:
																										goto IL_072f_2;
																									case 81:
																									case 115:
																										goto IL_0742_2;
																									case 130:
																										goto IL_078b_2;
																									case 123:
																										goto IL_079f_2;
																									case 139:
																										goto IL_07b2_2;
																									case 79:
																									case 190:
																										goto IL_07c0_2;
																									case 63:
																										goto IL_07ce_2;
																									case 7:
																									case 42:
																										goto IL_07d9_2;
																									case 77:
																										goto IL_07e7_2;
																									case 168:
																										goto IL_080a_2;
																									case 40:
																										goto IL_0814_2;
																									case 151:
																										goto IL_0822_2;
																									case 192:
																										goto IL_0843_2;
																									case 94:
																									case 165:
																										goto IL_0851_2;
																									case 172:
																										goto IL_087a_2;
																									case 191:
																										goto IL_0888_2;
																									case 43:
																									case 109:
																										goto IL_089b_2;
																									case 53:
																										goto IL_08b8_2;
																									case 213:
																										goto IL_090c_2;
																									case 71:
																										goto IL_091a_2;
																									case 122:
																										goto IL_092d_2;
																									case 146:
																										goto IL_093b_2;
																									case 2:
																										goto IL_0946_2;
																									case 93:
																									case 154:
																										goto IL_0951_2;
																									case 118:
																										goto IL_095f_2;
																									case 111:
																									case 167:
																										goto IL_096d_2;
																									case 174:
																										goto IL_0989_2;
																									case 27:
																									case 203:
																										goto IL_0997_2;
																									case 26:
																										goto IL_09b8_2;
																									case 41:
																									case 99:
																										goto IL_09c3_2;
																									case 45:
																										goto IL_09e5_2;
																									case 104:
																										goto IL_09f3_2;
																									case 195:
																										goto IL_0a01_2;
																									case 171:
																										goto IL_0a14_2;
																									case 74:
																									case 126:
																										goto IL_0a22_2;
																									case 140:
																										goto IL_0a30_2;
																									case 89:
																									case 188:
																										goto IL_0a3e_2;
																									case 34:
																										goto IL_0a5b_2;
																									case 160:
																										goto IL_0a93_2;
																									case 215:
																										goto IL_0aa6_2;
																									case 3:
																									case 12:
																										goto IL_0ab4_2;
																									case 9:
																										goto IL_0af2_2;
																									case 166:
																										goto IL_0b17_2;
																									case 39:
																									case 208:
																										goto IL_0b25_2;
																									case 36:
																										goto IL_0b33_2;
																									case 49:
																									case 158:
																										goto IL_0b3e_2;
																									case 0:
																										goto IL_0b5c_2;
																									case 35:
																										goto IL_0b6a_2;
																									case 25:
																										goto IL_0b7d_2;
																									case 131:
																									case 185:
																										goto end_IL_03a9_2;
																									case 59:
																										goto IL_0b99_2;
																									case 15:
																									case 133:
																										goto IL_0ba7_2;
																									case 200:
																										goto end_IL_042f;
																									case 51:
																										goto IL_0c6c_2;
																									case 178:
																										goto IL_0c7f_2;
																									case 47:
																										goto IL_0c92_2;
																									case 85:
																									case 107:
																										goto IL_0ca0_2;
																									case 194:
																										goto IL_0cae_2;
																									case 29:
																									case 103:
																										goto IL_0cbc_2;
																									case 193:
																										goto IL_0cd4_2;
																									case 22:
																										goto IL_0cf2_2;
																									case 62:
																										goto IL_0d16_2;
																									case 60:
																										goto IL_0d2e_2;
																									case 98:
																										goto IL_0d41_2;
																									case 48:
																									case 147:
																										goto IL_0d4f_2;
																									case 148:
																										goto IL_0d78_2;
																									case 20:
																									case 186:
																										goto IL_0d91_2;
																									case 96:
																										goto IL_0d9f_2;
																									case 129:
																										goto IL_0db7_2;
																									case 28:
																										goto IL_0dce_2;
																									case 5:
																									case 8:
																									case 10:
																									case 14:
																									case 19:
																									case 21:
																									case 23:
																									case 24:
																									case 30:
																									case 31:
																									case 32:
																									case 46:
																									case 56:
																									case 61:
																									case 72:
																									case 83:
																									case 86:
																									case 88:
																									case 95:
																									case 100:
																									case 105:
																									case 106:
																									case 110:
																									case 112:
																									case 113:
																									case 114:
																									case 135:
																									case 136:
																									case 142:
																									case 156:
																									case 159:
																									case 162:
																									case 164:
																									case 170:
																									case 180:
																									case 201:
																									case 204:
																									case 212:
																									case 217:
																									case 218:
																										goto IL_0de7_2;
																									case 177:
																										goto IL_0e00_2;
																									case 57:
																										goto IL_0e0e_2;
																									case 120:
																										goto IL_0e1c_2;
																									case 17:
																									case 18:
																									case 37:
																									case 54:
																									case 55:
																									case 64:
																									case 67:
																									case 97:
																									case 101:
																									case 102:
																									case 117:
																									case 119:
																									case 128:
																									case 134:
																									case 138:
																									case 143:
																									case 145:
																									case 157:
																									case 169:
																									case 175:
																									case 176:
																									case 187:
																									case 196:
																									case 206:
																									case 209:
																										goto IL_0e2a_2;
																									case 150:
																										ptr2 = ptr;
																										goto IL_0e2a_2;
																									case 197:
																										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref JulianCalendarTrimToSize.NotCurrentlyProcessingVerifyHash);
																										goto case 150;
																									case 127:
																										array7 = new object[10];
																										goto case 197;
																									case 179:
																										array6 = new long[4];
																										goto case 127;
																									case 66:
																										array5 = new int[6];
																										goto case 179;
																									case 75:
																										array4 = new int[4];
																										num = 66;
																										goto case 66;
																									case 87:
																										array3 = new object[4];
																										goto case 75;
																									case 82:
																										array2 = new byte[4];
																										goto case 87;
																									case 70:
																										num4 = num2 * 8;
																										goto case 82;
																									case 4:
																										num3 = num2 * 4;
																										goto case 70;
																									case 182:
																										num2 = 1;
																										num = 4;
																										goto case 4;
																									case 183:
																										goto end_IL_0c5e;
																									case 121:
																									case 137:
																										goto IL_0eff_2;
																									}
																									continue;
																								}
																								if (8 <= b)
																								{
																									goto IL_0445_2;
																								}
																								goto IL_0458_2;
																								IL_04f7_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0537_2;
																								IL_054b_2:
																								num6--;
																								goto IL_0e2a_2;
																								IL_0537_2:
																								array2[num6 - 2] = 0;
																								goto IL_054b_2;
																								IL_0445_2:
																								num6--;
																								goto IL_0e2a_2;
																								IL_0458_2:
																								if (6 < b)
																								{
																									goto IL_0466_2;
																								}
																								goto IL_04e9_2;
																								IL_0466_2:
																								if (7 >= b)
																								{
																									goto IL_0474_2;
																								}
																								goto IL_0de7_2;
																								IL_0474_2:
																								if (7 <= b)
																								{
																									goto IL_0482_2;
																								}
																								goto IL_0de7_2;
																								IL_0482_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_04c2_2;
																								IL_04c2_2:
																								array2[num6 - 2] = 0;
																								goto IL_04d6_2;
																								IL_04d6_2:
																								num6--;
																								goto IL_0e2a_2;
																								IL_04e9_2:
																								if (6 <= b)
																								{
																									goto IL_04f7_2;
																								}
																								goto IL_0de7_2;
																								continue;
																								end_IL_03a9_2:
																								break;
																							}
																							break;
																						}
																						goto IL_055e_2;
																						IL_060a_2:
																						if (10 <= b)
																						{
																							goto IL_0618_2;
																						}
																						goto IL_0de7_2;
																						IL_0618_2:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						num = 11;
																						goto IL_0683_2;
																						IL_055e_2:
																						if (9 >= b)
																						{
																							goto IL_056c_2;
																						}
																						num = 90;
																						goto IL_05fc_2;
																						IL_056c_2:
																						if (9 <= b)
																						{
																							goto IL_057a_2;
																						}
																						goto IL_0de7_2;
																						IL_057a_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 73;
																						goto IL_05c3_2;
																						IL_05c3_2:
																						array2[num6 - 2] = 0;
																						num = 211;
																						goto IL_05e0_2;
																						IL_05e0_2:
																						num6--;
																						goto IL_0e2a_2;
																						IL_0683_2:
																						num6 -= 2;
																						goto IL_0e2a_2;
																						IL_05fc_2:
																						if (10 >= b)
																						{
																							goto IL_060a_2;
																						}
																						goto IL_0de7_2;
																					}
																					break;
																				}
																				goto IL_0696_2;
																				IL_087a_2:
																				ptr2 += 8;
																				goto IL_0888_2;
																				IL_0696_2:
																				if (5 <= b)
																				{
																					goto IL_06a1_2;
																				}
																				goto IL_0708_2;
																				IL_06a1_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_06e1_2;
																				IL_06e1_2:
																				array2[num6 - 2] = 0;
																				goto IL_06f5_2;
																				IL_06f5_2:
																				num6--;
																				goto IL_0e2a_2;
																				IL_0708_2:
																				if (2 >= b)
																				{
																					goto IL_0716_2;
																				}
																				goto IL_07b2_2;
																				IL_0716_2:
																				if (2 > b)
																				{
																					goto IL_0721_2;
																				}
																				goto IL_0742_2;
																				IL_0721_2:
																				if (1 >= b)
																				{
																					goto IL_072f_2;
																				}
																				goto IL_0de7_2;
																				IL_072f_2:
																				if (1 <= b)
																				{
																				}
																				goto IL_0de7_2;
																				IL_0742_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				num = 130;
																				goto IL_078b_2;
																				IL_078b_2:
																				array2[num6 - 2] = 0;
																				goto IL_079f_2;
																				IL_079f_2:
																				num6--;
																				goto IL_0e2a_2;
																				IL_07b2_2:
																				if (3 < b)
																				{
																					goto IL_07c0_2;
																				}
																				goto IL_0843_2;
																				IL_07c0_2:
																				if (4 >= b)
																				{
																					goto IL_07ce_2;
																				}
																				goto IL_0de7_2;
																				IL_07ce_2:
																				if (4 <= b)
																				{
																					goto IL_07d9_2;
																				}
																				num = 10;
																				goto IL_0de7_2;
																				IL_07d9_2:
																				array2[num6] = 0;
																				goto IL_07e7_2;
																				IL_07e7_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				goto IL_080a_2;
																				IL_080a_2:
																				array3[num6] = null;
																				goto IL_0814_2;
																				IL_0814_2:
																				num6++;
																				goto IL_0822_2;
																				IL_0822_2:
																				ptr2 += 8;
																				goto IL_0e2a_2;
																				IL_0888_2:
																				num6--;
																				goto IL_0e2a_2;
																				IL_0843_2:
																				if (3 <= b)
																				{
																					goto IL_0851_2;
																				}
																				goto IL_0de7_2;
																				IL_0851_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_087a_2;
																			}
																			break;
																		}
																		goto IL_089b_2;
																		IL_091a_2:
																		ptr2 += 8;
																		goto IL_0e2a_2;
																		IL_089b_2:
																		array2[num6 - 2] = 0;
																		num = 53;
																		goto IL_08b8_2;
																		IL_08b8_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)AssignPrimarygetDriveFormat[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_090c_2;
																		IL_090c_2:
																		num6--;
																		goto IL_091a_2;
																	}
																	goto IL_0b8b_2;
																	IL_0d9f_2:
																	array3[num6] = array7[*(int*)(ptr2 + num3)];
																	goto IL_0db7_2;
																	IL_092d_2:
																	if (17 < b)
																	{
																		goto IL_093b_2;
																	}
																	num = 166;
																	goto IL_0b17_2;
																	IL_093b_2:
																	if (20 < b)
																	{
																		goto IL_0946_2;
																	}
																	num = 26;
																	goto IL_09b8_2;
																	IL_0946_2:
																	if (21 < b)
																	{
																		goto IL_0951_2;
																	}
																	goto IL_0989_2;
																	IL_0951_2:
																	if (22 >= b)
																	{
																		goto IL_095f_2;
																	}
																	goto IL_0de7_2;
																	IL_095f_2:
																	if (22 <= b)
																	{
																		goto IL_096d_2;
																	}
																	goto IL_0de7_2;
																	IL_096d_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	goto IL_0e2a_2;
																	IL_0989_2:
																	if (21 <= b)
																	{
																		goto IL_0997_2;
																	}
																	goto IL_0de7_2;
																	IL_0997_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_0e2a_2;
																	IL_0dce_2:
																	ptr2 += 8;
																	goto IL_0e2a_2;
																	IL_09b8_2:
																	if (20 <= b)
																	{
																		goto IL_09c3_2;
																	}
																	goto IL_0a14_2;
																	IL_09c3_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																	num = 45;
																	goto IL_09e5_2;
																	IL_09e5_2:
																	array2[num6] = 1;
																	goto IL_09f3_2;
																	IL_09f3_2:
																	num6++;
																	goto IL_0a01_2;
																	IL_0a01_2:
																	ptr2 += 16;
																	goto IL_0e2a_2;
																	IL_0a14_2:
																	if (18 < b)
																	{
																		goto IL_0a22_2;
																	}
																	goto IL_0aa6_2;
																	IL_0a22_2:
																	if (19 >= b)
																	{
																		goto IL_0a30_2;
																	}
																	goto IL_0de7_2;
																	IL_0a30_2:
																	if (19 <= b)
																	{
																		goto IL_0a3e_2;
																	}
																	goto IL_0de7_2;
																	IL_0a3e_2:
																	array2[num6 - 1] = 5;
																	num = 34;
																	goto IL_0a5b_2;
																	IL_0a5b_2:
																	array3[num6 - 1] = ((delegate*<string[], string>)AssignPrimarygetDriveFormat[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																	goto IL_0a93_2;
																	IL_0a93_2:
																	ptr2 += 8;
																	goto IL_0e2a_2;
																	IL_0aa6_2:
																	if (18 <= b)
																	{
																		goto IL_0ab4_2;
																	}
																	goto IL_0de7_2;
																	IL_0ab4_2:
																	((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																	goto IL_0af2_2;
																	IL_0af2_2:
																	num6 -= 3;
																	num = 145;
																	goto IL_0e2a_2;
																	IL_0db7_2:
																	num6++;
																	num = 28;
																	goto IL_0dce_2;
																	IL_0b17_2:
																	if (17 > b)
																	{
																		goto IL_0b25_2;
																	}
																	goto IL_0d91_2;
																	IL_0b25_2:
																	if (14 >= b)
																	{
																		goto IL_0b33_2;
																	}
																	goto IL_0c92_2;
																	IL_0b33_2:
																	if (14 <= b)
																	{
																		goto IL_0b3e_2;
																	}
																	goto IL_0b7d_2;
																	IL_0b3e_2:
																	array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																	goto IL_0b5c_2;
																	IL_0b5c_2:
																	ptr2 += 8;
																	goto IL_0b6a_2;
																	IL_0b6a_2:
																	num6--;
																	goto IL_0e2a_2;
																	IL_0b7d_2:
																	if (12 < b)
																	{
																		goto IL_0b8b_2;
																	}
																	goto IL_0c7f_2;
																	IL_0b8b_2:
																	if (13 >= b)
																	{
																		goto IL_0b99_2;
																	}
																	goto IL_0de7_2;
																	IL_0b99_2:
																	if (13 <= b)
																	{
																		goto IL_0ba7_2;
																	}
																	goto IL_0de7_2;
																	IL_0ba7_2:
																	array8 = array3;
																	num9 = num6;
																	if (array == null)
																	{
																		goto IL_0bb6_2;
																	}
																	goto IL_0bc4;
																	IL_0c7f_2:
																	if (12 <= b)
																	{
																		goto IL_0e2a_2;
																	}
																	goto IL_0de7_2;
																	IL_0c92_2:
																	if (15 < b)
																	{
																		goto IL_0ca0_2;
																	}
																	goto IL_0d41_2;
																	IL_0ca0_2:
																	if (16 >= b)
																	{
																		goto IL_0cae_2;
																	}
																	goto IL_0de7_2;
																	IL_0cae_2:
																	if (16 <= b)
																	{
																		goto IL_0cbc_2;
																	}
																	goto IL_0de7_2;
																	IL_0cbc_2:
																	array2[num6] = array2[num6 - 1];
																	goto IL_0cd4_2;
																	IL_0cd4_2:
																	array4[num6 - 0] = array4[num6 - 1];
																	goto IL_0cf2_2;
																	IL_0cf2_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0d16_2;
																	IL_0d16_2:
																	array3[num6] = array3[num6 - 1];
																	goto IL_0d2e_2;
																	IL_0d2e_2:
																	num6++;
																	goto IL_0e2a_2;
																	IL_0d41_2:
																	if (15 <= b)
																	{
																		goto IL_0d4f_2;
																	}
																	goto IL_0de7_2;
																	IL_0d4f_2:
																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_0d78_2;
																	IL_0d78_2:
																	array2[num6 - 1] = 5;
																	goto IL_0e2a_2;
																	IL_0d91_2:
																	array2[num6] = 5;
																	goto IL_0d9f_2;
																	continue;
																	end_IL_03ef_2:
																	break;
																}
																continue;
															}
															num = 5;
															goto IL_0de7_2;
															continue;
															end_IL_03ff:
															break;
														}
														continue;
													}
													goto IL_0de7_2;
													IL_0e1c_2:
													ptr2 += 8;
													goto IL_0e2a_2;
													IL_0de7_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0e00_2;
													IL_0e00_2:
													array2[num6] = 0;
													goto IL_0e0e_2;
													IL_0e0e_2:
													num6++;
													goto IL_0e1c_2;
													continue;
													end_IL_040f:
													break;
												}
												continue;
												end_IL_041f:
												break;
											}
											continue;
											end_IL_042f:
											break;
										}
										break;
									}
									goto IL_0eff_2;
									IL_0eff_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_0c5e:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_038d, IL_03a0, IL_03b9, IL_041d, IL_042d, IL_043d, IL_044d, IL_045d, IL_0470, IL_047d, IL_048d, IL_049d, IL_04ad, IL_04bd, IL_04c8, IL_04d3, IL_04e1, IL_04ef, IL_0508, IL_0516, IL_0521, IL_0534, IL_0542, IL_0550, IL_0590, IL_05a9, IL_05fd, IL_060b, IL_061e, IL_0629, IL_0669, IL_067d, IL_0690, IL_06a0, IL_06b3, IL_06c6, IL_06d1, IL_06dc, IL_06ef, IL_06fd, IL_073d, IL_0751, IL_0764, IL_07a4, IL_07b8, IL_07cb, IL_07d6, IL_07e4, IL_07f2, IL_0800, IL_0823, IL_082d, IL_083b, IL_084e, IL_085c, IL_0885, IL_0893, IL_08a6, IL_08e6, IL_0903, IL_0916, IL_0924, IL_0932, IL_0940, IL_094b, IL_0969, IL_0977, IL_098a, IL_0995, IL_09a8, IL_09b6, IL_09c4, IL_09e1, IL_0a30, IL_0a3a, IL_0a67, IL_0a7b, IL_0a92, IL_0aa5, IL_0ab3, IL_0ac1, IL_0acf, IL_0ae7, IL_0b05, IL_0b29, IL_0b41, IL_0b54, IL_0b62, IL_0b8b, IL_0ba4, IL_0bb2, IL_0bca, IL_0bd8, IL_0beb, IL_0bf9, IL_0c07, IL_0c12, IL_0c20, IL_0c5e, IL_0c71, IL_0c7f, IL_0c8d, IL_0caa, IL_0ce2, IL_0cf5, IL_0d0e, IL_0d1c, IL_0d2a, IL_0d3d, IL_0d48, IL_0d53, IL_0d6b, IL_0d76, IL_0d81, IL_0d8a, IL_0dac, IL_0dc5, IL_0dd3, IL_0de1, IL_0def, IL_0e02, IL_0e15, IL_0e20, IL_0e30, IL_0e40, IL_0e50, IL_0e69, IL_0e79, IL_0e89, IL_0e99, IL_0ea9, IL_0ec4 are reachable both inside and outside the pinned region starting at IL_0ebe. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 160;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef29 = default(int);
				ref int reference = ref __rxRef29;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0ea9:
						num2 = 1;
						while (true)
						{
							IL_0e99:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e89:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e79:
									array2 = new byte[4];
									while (true)
									{
										IL_0e69:
										array3 = new object[4];
										while (true)
										{
											IL_0e50:
											array4 = new int[4];
											num = 87;
											while (true)
											{
												IL_0e40:
												array5 = new int[6];
												while (true)
												{
													IL_0e30:
													array6 = new long[4];
													while (true)
													{
														IL_0e20:
														array7 = new object[16];
														while (true)
														{
															IL_0e15:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getResourceExposureLevelSecurityInfrastructure.GetDirectoryRootActor);
															while (true)
															{
																IL_0e02:
																ptr2 = ptr;
																num = 130;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_04c8:
																			num = 2;
																			while (true)
																			{
																				IL_04bd:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_04ad:
																					ptr2++;
																					while (true)
																					{
																						IL_049d:
																						if (b >= 1)
																						{
																							while (b <= 22)
																							{
																								while (true)
																								{
																									IL_047d:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_0470:
																											if (11 > b)
																											{
																												while (true)
																												{
																													IL_045d:
																													if (5 < b)
																													{
																														num = 168;
																														while (true)
																														{
																															IL_044d:
																															if (8 < b)
																															{
																																while (true)
																																{
																																	IL_043d:
																																	if (9 < b)
																																	{
																																		while (10 >= b)
																																		{
																																			while (10 <= b)
																																			{
																																				while (true)
																																				{
																																					IL_03b9:
																																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																					while (true)
																																					{
																																						IL_03a0:
																																						num6 -= 2;
																																						num = 220;
																																						while (num != 220)
																																						{
																																							if (num != 1201)
																																							{
																																								goto IL_0d6b;
																																							}
																																							switch (num)
																																							{
																																							case 160:
																																								break;
																																							default:
																																								continue;
																																							case 131:
																																								goto IL_03a0;
																																							case 57:
																																							case 169:
																																								goto IL_03b9;
																																							case 15:
																																								goto IL_041d;
																																							case 45:
																																							case 190:
																																								goto IL_042d;
																																							case 68:
																																								goto IL_043d;
																																							case 113:
																																							case 168:
																																								goto IL_044d;
																																							case 52:
																																								goto IL_045d;
																																							case 76:
																																								goto IL_0470;
																																							case 84:
																																								goto IL_047d;
																																							case 64:
																																								goto IL_048d;
																																							case 75:
																																								goto IL_049d;
																																							case 184:
																																								goto IL_04ad;
																																							case 2:
																																								goto IL_04bd;
																																							case 164:
																																								goto IL_04c8;
																																							case 29:
																																								goto IL_04d3;
																																							case 11:
																																							case 116:
																																								goto IL_04ef;
																																							case 135:
																																								goto IL_0508;
																																							case 51:
																																							case 107:
																																								goto IL_0516;
																																							case 118:
																																								goto IL_0521;
																																							case 120:
																																							case 146:
																																								goto IL_0534;
																																							case 44:
																																								goto IL_0542;
																																							case 46:
																																							case 155:
																																								goto IL_0550;
																																							case 109:
																																								goto IL_0590;
																																							case 174:
																																								goto IL_05a9;
																																							case 4:
																																								goto IL_05fd;
																																							case 69:
																																								goto IL_060b;
																																							case 180:
																																								goto IL_061e;
																																							case 38:
																																							case 124:
																																								goto IL_0629;
																																							case 59:
																																								goto IL_0669;
																																							case 167:
																																								goto IL_067d;
																																							case 148:
																																								goto IL_0690;
																																							case 53:
																																							case 193:
																																								goto IL_06a0;
																																							case 194:
																																								goto IL_06b3;
																																							case 206:
																																								goto IL_06c6;
																																							case 105:
																																							case 147:
																																								goto IL_06d1;
																																							case 91:
																																								goto IL_06dc;
																																							case 66:
																																							case 100:
																																								goto IL_06fd;
																																							case 20:
																																								goto IL_073d;
																																							case 121:
																																								goto IL_0751;
																																							case 102:
																																							case 210:
																																								goto IL_0764;
																																							case 6:
																																								goto IL_07a4;
																																							case 205:
																																								goto IL_07b8;
																																							case 211:
																																								goto IL_07cb;
																																							case 32:
																																							case 80:
																																								goto IL_07d6;
																																							case 19:
																																								goto IL_07e4;
																																							case 16:
																																							case 132:
																																								goto IL_07f2;
																																							case 166:
																																								goto IL_0800;
																																							case 39:
																																								goto IL_0823;
																																							case 37:
																																								goto IL_082d;
																																							case 49:
																																								goto IL_083b;
																																							case 149:
																																								goto IL_084e;
																																							case 10:
																																							case 134:
																																								goto IL_085c;
																																							case 85:
																																								goto IL_0885;
																																							case 35:
																																								goto IL_0893;
																																							case 79:
																																							case 213:
																																								goto IL_08a6;
																																							case 178:
																																								goto IL_08e6;
																																							case 48:
																																								goto IL_0903;
																																							case 199:
																																								goto IL_0916;
																																							case 82:
																																								goto IL_0924;
																																							case 0:
																																							case 187:
																																								goto IL_0932;
																																							case 126:
																																								goto IL_0940;
																																							case 88:
																																							case 203:
																																								goto IL_094b;
																																							case 202:
																																								goto IL_0969;
																																							case 54:
																																								goto IL_0977;
																																							case 207:
																																								goto IL_098a;
																																							case 33:
																																								goto IL_0995;
																																							case 165:
																																								goto IL_09a8;
																																							case 186:
																																								goto IL_09b6;
																																							case 78:
																																							case 112:
																																								goto IL_09c4;
																																							case 141:
																																								goto IL_0a7b;
																																							case 22:
																																								goto IL_0a92;
																																							case 23:
																																								goto IL_0aa5;
																																							case 95:
																																								goto IL_0ab3;
																																							case 43:
																																								goto IL_0ac1;
																																							case 12:
																																							case 181:
																																								goto IL_0acf;
																																							case 189:
																																								goto IL_0ae7;
																																							case 122:
																																								goto IL_0b05;
																																							case 27:
																																								goto IL_0b29;
																																							case 55:
																																								goto IL_0b41;
																																							case 195:
																																								goto IL_0b54;
																																							case 50:
																																							case 197:
																																								goto IL_0b62;
																																							case 191:
																																								goto IL_0b8b;
																																							case 136:
																																							case 185:
																																								goto IL_0ba4;
																																							case 26:
																																								goto IL_0bb2;
																																							case 90:
																																								goto IL_0bca;
																																							case 61:
																																								goto IL_0bd8;
																																							case 94:
																																								goto IL_0beb;
																																							case 142:
																																								goto IL_0bf9;
																																							case 143:
																																							case 208:
																																								goto IL_0c07;
																																							case 104:
																																								goto IL_0c12;
																																							case 8:
																																							case 115:
																																								goto IL_0c20;
																																							case 150:
																																								goto IL_0c5e;
																																							case 74:
																																								goto IL_0c71;
																																							case 137:
																																								goto IL_0c7f;
																																							case 108:
																																							case 123:
																																								goto IL_0c8d;
																																							case 99:
																																								goto IL_0caa;
																																							case 175:
																																								goto IL_0ce2;
																																							case 42:
																																							case 128:
																																								goto IL_0cf5;
																																							case 63:
																																								goto IL_0d0e;
																																							case 133:
																																								goto IL_0d1c;
																																							case 111:
																																								goto IL_0d2a;
																																							case 47:
																																								goto IL_0d3d;
																																							case 31:
																																								goto IL_0d48;
																																							case 25:
																																							case 170:
																																								goto IL_0d53;
																																							case 3:
																																							case 200:
																																								goto IL_0d6b;
																																							case 173:
																																								goto IL_0d76;
																																							case 129:
																																							case 161:
																																								goto IL_0d8a;
																																							case 1:
																																							case 5:
																																							case 14:
																																							case 21:
																																							case 28:
																																							case 41:
																																							case 60:
																																							case 65:
																																							case 70:
																																							case 72:
																																							case 73:
																																							case 81:
																																							case 101:
																																							case 103:
																																							case 110:
																																							case 114:
																																							case 117:
																																							case 119:
																																							case 127:
																																							case 139:
																																							case 144:
																																							case 145:
																																							case 151:
																																							case 153:
																																							case 154:
																																							case 157:
																																							case 158:
																																							case 162:
																																							case 171:
																																							case 172:
																																							case 177:
																																							case 183:
																																							case 188:
																																							case 192:
																																							case 201:
																																							case 204:
																																							case 212:
																																								goto end_IL_041d;
																																							case 71:
																																								goto IL_0dc5;
																																							case 34:
																																								goto IL_0dd3;
																																							case 196:
																																								goto IL_0de1;
																																							case 9:
																																							case 13:
																																							case 17:
																																							case 18:
																																							case 24:
																																							case 40:
																																							case 56:
																																							case 62:
																																							case 77:
																																							case 86:
																																							case 92:
																																							case 96:
																																							case 97:
																																							case 106:
																																							case 130:
																																							case 138:
																																							case 140:
																																							case 156:
																																							case 163:
																																							case 176:
																																							case 179:
																																							case 182:
																																							case 198:
																																							case 209:
																																								goto end_IL_038d;
																																							case 89:
																																								goto IL_0e02;
																																							case 67:
																																								goto IL_0e15;
																																							case 125:
																																								goto IL_0e20;
																																							case 152:
																																								goto IL_0e30;
																																							case 87:
																																								goto IL_0e40;
																																							case 30:
																																								goto IL_0e50;
																																							case 58:
																																								goto IL_0e69;
																																							case 36:
																																								goto IL_0e79;
																																							case 83:
																																								goto IL_0e89;
																																							case 98:
																																								goto IL_0e99;
																																							case 159:
																																								goto IL_0ea9;
																																							case 7:
																																							case 93:
																																								goto IL_0ec4;
																																							}
																																							goto end_IL_0def;
																																							continue;
																																							end_IL_038d:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				goto end_IL_049d;
																																				continue;
																																				end_IL_041d:
																																				break;
																																				IL_041d:;
																																			}
																																			break;
																																			IL_042d:;
																																		}
																																		break;
																																	}
																																	goto IL_04d3;
																																	IL_07a4:
																																	array2[num6 - 2] = 0;
																																	goto IL_07b8;
																																	IL_04d3:
																																	if (9 > b)
																																	{
																																		break;
																																	}
																																	num = 102;
																																	goto IL_0764;
																																	IL_07b8:
																																	num6--;
																																	goto end_IL_049d;
																																	IL_0764:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_07a4;
																																}
																																break;
																															}
																															goto IL_0508;
																															IL_06a0:
																															num6--;
																															goto end_IL_049d;
																															IL_0508:
																															if (8 > b)
																															{
																																goto IL_0516;
																															}
																															goto IL_06a0;
																															IL_0516:
																															if (6 >= b)
																															{
																																goto IL_0521;
																															}
																															goto IL_0534;
																															IL_0521:
																															if (6 > b)
																															{
																																break;
																															}
																															goto IL_08a6;
																															IL_08a6:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_08e6;
																															IL_08e6:
																															array2[num6 - 2] = 0;
																															num = 48;
																															goto IL_0903;
																															IL_0903:
																															num6--;
																															goto end_IL_049d;
																															IL_0534:
																															if (7 < b)
																															{
																																break;
																															}
																															goto IL_0542;
																															IL_0542:
																															if (7 > b)
																															{
																																break;
																															}
																															goto IL_0550;
																															IL_0550:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_0590;
																															IL_0590:
																															array2[num6 - 2] = 0;
																															goto IL_06b3;
																															IL_06b3:
																															num6--;
																															goto end_IL_049d;
																														}
																														break;
																													}
																													goto IL_061e;
																													IL_085c:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0885;
																													IL_0885:
																													ptr2 += 8;
																													goto IL_0893;
																													IL_061e:
																													if (5 <= b)
																													{
																														goto IL_0629;
																													}
																													goto IL_0690;
																													IL_0629:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0669;
																													IL_0669:
																													array2[num6 - 2] = 0;
																													goto IL_067d;
																													IL_067d:
																													num6--;
																													goto end_IL_049d;
																													IL_0690:
																													if (2 >= b)
																													{
																														goto IL_06c6;
																													}
																													goto IL_07cb;
																													IL_06c6:
																													if (2 > b)
																													{
																														goto IL_06d1;
																													}
																													goto IL_06fd;
																													IL_06d1:
																													if (1 < b)
																													{
																														num = 127;
																														break;
																													}
																													goto IL_06dc;
																													IL_06dc:
																													if (1 <= b)
																													{
																													}
																													break;
																													IL_0893:
																													num6--;
																													goto end_IL_049d;
																													IL_06fd:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_073d;
																													IL_073d:
																													array2[num6 - 2] = 0;
																													goto IL_0751;
																													IL_0751:
																													num6--;
																													goto end_IL_049d;
																													IL_07cb:
																													if (3 < b)
																													{
																														goto IL_07d6;
																													}
																													goto IL_084e;
																													IL_07d6:
																													if (4 < b)
																													{
																														break;
																													}
																													goto IL_07e4;
																													IL_07e4:
																													if (4 > b)
																													{
																														break;
																													}
																													goto IL_07f2;
																													IL_07f2:
																													array2[num6] = 0;
																													goto IL_0800;
																													IL_0800:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																													goto IL_0823;
																													IL_0823:
																													array3[num6] = null;
																													goto IL_082d;
																													IL_082d:
																													num6++;
																													goto IL_083b;
																													IL_083b:
																													ptr2 += 8;
																													goto end_IL_049d;
																													IL_084e:
																													if (3 > b)
																													{
																														break;
																													}
																													goto IL_085c;
																												}
																												break;
																											}
																											goto IL_04ef;
																											IL_060b:
																											ptr2 += 8;
																											goto end_IL_049d;
																											IL_04ef:
																											array2[num6 - 2] = 0;
																											goto IL_05a9;
																											IL_05a9:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)KeyValuePairsAuthenticationType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_05fd;
																											IL_05fd:
																											num6--;
																											goto IL_060b;
																										}
																										break;
																									}
																									goto IL_0916;
																									IL_0d53:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_049d;
																									IL_0916:
																									if (17 >= b)
																									{
																										goto IL_0924;
																									}
																									goto IL_0beb;
																									IL_0924:
																									if (17 > b)
																									{
																										goto IL_0932;
																									}
																									goto IL_0ba4;
																									IL_0932:
																									if (14 >= b)
																									{
																										goto IL_0940;
																									}
																									goto IL_0aa5;
																									IL_0940:
																									if (14 <= b)
																									{
																										goto IL_094b;
																									}
																									goto IL_098a;
																									IL_094b:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_0969;
																									IL_0969:
																									ptr2 += 8;
																									goto IL_0977;
																									IL_0977:
																									num6--;
																									goto end_IL_049d;
																									IL_098a:
																									if (12 >= b)
																									{
																										goto IL_0995;
																									}
																									goto IL_09a8;
																									IL_0995:
																									if (12 <= b)
																									{
																										goto end_IL_049d;
																									}
																									break;
																									IL_09a8:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_09b6;
																									IL_09b6:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_09c4;
																									IL_09c4:
																									array8 = array3;
																									num7 = num6;
																									if (array == null)
																									{
																										goto IL_09d3;
																									}
																									num8 = ptr2;
																									byte b2 = *num8;
																									ptr2 = num8 + 4;
																									int num9 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num9;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_0a7b;
																									IL_0d6b:
																									if (22 < b)
																									{
																										break;
																									}
																									goto IL_0d76;
																									IL_0d76:
																									if (22 > b)
																									{
																										break;
																									}
																									num = 129;
																									goto IL_0d8a;
																									IL_0d8a:
																									num10 = ptr2;
																									num11 = -200;
																									num5 = 1;
																									ptr2 = num10 + num11;
																									num = 92;
																									goto end_IL_049d;
																									IL_0a7b:
																									array2[num6] = 5;
																									num = 22;
																									goto IL_0a92;
																									IL_0a92:
																									num6++;
																									goto end_IL_049d;
																									IL_0aa5:
																									if (15 < b)
																									{
																										goto IL_0ab3;
																									}
																									goto IL_0b54;
																									IL_0ab3:
																									if (16 < b)
																									{
																										break;
																									}
																									goto IL_0ac1;
																									IL_0ac1:
																									if (16 > b)
																									{
																										break;
																									}
																									goto IL_0acf;
																									IL_0acf:
																									array2[num6] = array2[num6 - 1];
																									goto IL_0ae7;
																									IL_0ae7:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0b05;
																									IL_0b05:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0b29;
																									IL_0b29:
																									array3[num6] = array3[num6 - 1];
																									goto IL_0b41;
																									IL_0b41:
																									num6++;
																									goto end_IL_049d;
																									IL_0b54:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_0b62;
																									IL_0b62:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0b8b;
																									IL_0b8b:
																									array2[num6 - 1] = 5;
																									goto end_IL_049d;
																									IL_0ba4:
																									array2[num6] = 5;
																									goto IL_0bb2;
																									IL_0bb2:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0bca;
																									IL_0bca:
																									num6++;
																									goto IL_0bd8;
																									IL_0bd8:
																									ptr2 += 8;
																									goto end_IL_049d;
																									IL_0beb:
																									if (20 >= b)
																									{
																										goto IL_0bf9;
																									}
																									goto IL_0d3d;
																									IL_0bf9:
																									if (20 > b)
																									{
																										goto IL_0c07;
																									}
																									goto IL_0cf5;
																									IL_0c07:
																									if (18 >= b)
																									{
																										goto IL_0c12;
																									}
																									goto IL_0c71;
																									IL_0c12:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_0c20;
																									IL_0c20:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0c5e;
																									IL_0c5e:
																									num6 -= 3;
																									goto end_IL_049d;
																									IL_0c71:
																									if (19 < b)
																									{
																										break;
																									}
																									goto IL_0c7f;
																									IL_0c7f:
																									if (19 > b)
																									{
																										break;
																									}
																									goto IL_0c8d;
																									IL_0c8d:
																									array2[num6 - 1] = 5;
																									num = 99;
																									goto IL_0caa;
																									IL_0caa:
																									array3[num6 - 1] = ((delegate*<string[], string>)KeyValuePairsAuthenticationType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0ce2;
																									IL_0ce2:
																									ptr2 += 8;
																									goto end_IL_049d;
																									IL_0cf5:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0d0e;
																									IL_0d0e:
																									array2[num6] = 1;
																									goto IL_0d1c;
																									IL_0d1c:
																									num6++;
																									goto IL_0d2a;
																									IL_0d2a:
																									ptr2 += 16;
																									goto end_IL_049d;
																									IL_0d3d:
																									if (21 >= b)
																									{
																										goto IL_0d48;
																									}
																									goto IL_0d6b;
																									IL_0d48:
																									if (21 > b)
																									{
																										break;
																									}
																									goto IL_0d53;
																								}
																								break;
																								IL_048d:;
																							}
																						}
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0dc5;
																						IL_0de1:
																						ptr2 += 8;
																						break;
																						IL_0dd3:
																						num6++;
																						goto IL_0de1;
																						IL_0dc5:
																						array2[num6] = 0;
																						goto IL_0dd3;
																						continue;
																						end_IL_049d:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0ec4;
																	IL_0ec4:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0def:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_09d3:
				while (true)
				{
					IL_09d3_2:
					array = new byte[4];
					while (true)
					{
						IL_09e1:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							num = 22;
							while (true)
							{
								IL_0a92_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_04c8_2:
											num = 2;
											while (true)
											{
												IL_04bd_2:
												byte b = *ptr2;
												while (true)
												{
													IL_04ad_2:
													ptr2++;
													while (true)
													{
														IL_049d_2:
														if (b >= 1)
														{
															while (b <= 22)
															{
																while (true)
																{
																	IL_047d_2:
																	if (11 >= b)
																	{
																		while (true)
																		{
																			IL_0470_2:
																			if (11 > b)
																			{
																				while (true)
																				{
																					IL_045d_2:
																					if (5 < b)
																					{
																						num = 168;
																						while (true)
																						{
																							IL_044d_2:
																							if (8 < b)
																							{
																								while (true)
																								{
																									IL_043d_2:
																									if (9 < b)
																									{
																										while (10 >= b)
																										{
																											while (10 <= b)
																											{
																												while (true)
																												{
																													IL_03b9_2:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													while (true)
																													{
																														IL_03a0_2:
																														num6 -= 2;
																														num = 220;
																														while (num != 220)
																														{
																															if (num != 1201)
																															{
																																goto IL_0d6b_2;
																															}
																															switch (num)
																															{
																															case 131:
																																goto IL_03a0_2;
																															case 57:
																															case 169:
																																goto IL_03b9_2;
																															case 15:
																																goto IL_041d_2;
																															case 45:
																															case 190:
																																goto IL_042d_2;
																															case 68:
																																goto IL_043d_2;
																															case 113:
																															case 168:
																																goto IL_044d_2;
																															case 52:
																																goto IL_045d_2;
																															case 76:
																																goto IL_0470_2;
																															case 84:
																																goto IL_047d_2;
																															case 64:
																																goto IL_048d_2;
																															case 75:
																																goto IL_049d_2;
																															case 184:
																																goto IL_04ad_2;
																															case 2:
																																goto IL_04bd_2;
																															case 164:
																																goto IL_04c8_2;
																															case 29:
																																goto IL_04d3_2;
																															case 11:
																															case 116:
																																goto IL_04ef_2;
																															case 135:
																																goto IL_0508_2;
																															case 51:
																															case 107:
																																goto IL_0516_2;
																															case 118:
																																goto IL_0521_2;
																															case 120:
																															case 146:
																																goto IL_0534_2;
																															case 44:
																																goto IL_0542_2;
																															case 46:
																															case 155:
																																goto IL_0550_2;
																															case 109:
																																goto IL_0590_2;
																															case 174:
																																goto IL_05a9_2;
																															case 4:
																																goto IL_05fd_2;
																															case 69:
																																goto IL_060b_2;
																															case 180:
																																goto IL_061e_2;
																															case 38:
																															case 124:
																																goto IL_0629_2;
																															case 59:
																																goto IL_0669_2;
																															case 167:
																																goto IL_067d_2;
																															case 148:
																																goto IL_0690_2;
																															case 53:
																															case 193:
																																goto IL_06a0_2;
																															case 194:
																																goto IL_06b3_2;
																															case 206:
																																goto IL_06c6_2;
																															case 105:
																															case 147:
																																goto IL_06d1_2;
																															case 91:
																																goto IL_06dc_2;
																															case 66:
																															case 100:
																																goto IL_06fd_2;
																															case 20:
																																goto IL_073d_2;
																															case 121:
																																goto IL_0751_2;
																															case 102:
																															case 210:
																																goto IL_0764_2;
																															case 6:
																																goto IL_07a4_2;
																															case 205:
																																goto IL_07b8_2;
																															case 211:
																																goto IL_07cb_2;
																															case 32:
																															case 80:
																																goto IL_07d6_2;
																															case 19:
																																goto IL_07e4_2;
																															case 16:
																															case 132:
																																goto IL_07f2_2;
																															case 166:
																																goto IL_0800_2;
																															case 39:
																																goto IL_0823_2;
																															case 37:
																																goto IL_082d_2;
																															case 49:
																																goto IL_083b_2;
																															case 149:
																																goto IL_084e_2;
																															case 10:
																															case 134:
																																goto IL_085c_2;
																															case 85:
																																goto IL_0885_2;
																															case 35:
																																goto IL_0893_2;
																															case 79:
																															case 213:
																																goto IL_08a6_2;
																															case 178:
																																goto IL_08e6_2;
																															case 48:
																																goto IL_0903_2;
																															case 199:
																																goto IL_0916_2;
																															case 82:
																																goto IL_0924_2;
																															case 0:
																															case 187:
																																goto IL_0932_2;
																															case 126:
																																goto IL_0940_2;
																															case 88:
																															case 203:
																																goto IL_094b_2;
																															case 202:
																																goto IL_0969_2;
																															case 54:
																																goto IL_0977_2;
																															case 207:
																																goto IL_098a_2;
																															case 33:
																																goto IL_0995_2;
																															case 165:
																																goto IL_09a8_2;
																															case 186:
																																goto IL_09b6_2;
																															case 78:
																															case 112:
																																goto IL_09c4_2;
																															case 141:
																																goto end_IL_0def_2;
																															case 22:
																																goto IL_0a92_2;
																															case 23:
																																goto IL_0aa5_2;
																															case 95:
																																goto IL_0ab3_2;
																															case 43:
																																goto IL_0ac1_2;
																															case 12:
																															case 181:
																																goto IL_0acf_2;
																															case 189:
																																goto IL_0ae7_2;
																															case 122:
																																goto IL_0b05_2;
																															case 27:
																																goto IL_0b29_2;
																															case 55:
																																goto IL_0b41_2;
																															case 195:
																																goto IL_0b54_2;
																															case 50:
																															case 197:
																																goto IL_0b62_2;
																															case 191:
																																goto IL_0b8b_2;
																															case 136:
																															case 185:
																																goto IL_0ba4_2;
																															case 26:
																																goto IL_0bb2_2;
																															case 90:
																																goto IL_0bca_2;
																															case 61:
																																goto IL_0bd8_2;
																															case 94:
																																goto IL_0beb_2;
																															case 142:
																																goto IL_0bf9_2;
																															case 143:
																															case 208:
																																goto IL_0c07_2;
																															case 104:
																																goto IL_0c12_2;
																															case 8:
																															case 115:
																																goto IL_0c20_2;
																															case 150:
																																goto IL_0c5e_2;
																															case 74:
																																goto IL_0c71_2;
																															case 137:
																																goto IL_0c7f_2;
																															case 108:
																															case 123:
																																goto IL_0c8d_2;
																															case 99:
																																goto IL_0caa_2;
																															case 175:
																																goto IL_0ce2_2;
																															case 42:
																															case 128:
																																goto IL_0cf5_2;
																															case 63:
																																goto IL_0d0e_2;
																															case 133:
																																goto IL_0d1c_2;
																															case 111:
																																goto IL_0d2a_2;
																															case 47:
																																goto IL_0d3d_2;
																															case 31:
																																goto IL_0d48_2;
																															case 25:
																															case 170:
																																goto IL_0d53_2;
																															case 3:
																															case 200:
																																goto IL_0d6b_2;
																															case 173:
																																goto IL_0d76_2;
																															case 129:
																															case 161:
																																goto IL_0d8a_2;
																															case 1:
																															case 5:
																															case 14:
																															case 21:
																															case 28:
																															case 41:
																															case 60:
																															case 65:
																															case 70:
																															case 72:
																															case 73:
																															case 81:
																															case 101:
																															case 103:
																															case 110:
																															case 114:
																															case 117:
																															case 119:
																															case 127:
																															case 139:
																															case 144:
																															case 145:
																															case 151:
																															case 153:
																															case 154:
																															case 157:
																															case 158:
																															case 162:
																															case 171:
																															case 172:
																															case 177:
																															case 183:
																															case 188:
																															case 192:
																															case 201:
																															case 204:
																															case 212:
																																goto end_IL_041d_2;
																															case 71:
																																goto IL_0dc5_2;
																															case 34:
																																goto IL_0dd3_2;
																															case 196:
																																goto IL_0de1_2;
																															case 9:
																															case 13:
																															case 17:
																															case 18:
																															case 24:
																															case 40:
																															case 56:
																															case 62:
																															case 77:
																															case 86:
																															case 92:
																															case 96:
																															case 97:
																															case 106:
																															case 130:
																															case 138:
																															case 140:
																															case 156:
																															case 163:
																															case 176:
																															case 179:
																															case 182:
																															case 198:
																															case 209:
																																goto end_IL_038d_2;
																															case 89:
																																ptr2 = ptr;
																																num = 130;
																																goto end_IL_038d_2;
																															case 67:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getResourceExposureLevelSecurityInfrastructure.GetDirectoryRootActor);
																																goto case 89;
																															case 125:
																																array7 = new object[16];
																																goto case 67;
																															case 152:
																																array6 = new long[4];
																																goto case 125;
																															case 87:
																																array5 = new int[6];
																																goto case 152;
																															case 30:
																																array4 = new int[4];
																																num = 87;
																																goto case 87;
																															case 58:
																																array3 = new object[4];
																																goto case 30;
																															case 36:
																																array2 = new byte[4];
																																goto case 58;
																															case 83:
																																num4 = num2 * 8;
																																goto case 36;
																															case 98:
																																num3 = num2 * 4;
																																goto case 83;
																															case 159:
																																num2 = 1;
																																goto case 98;
																															case 160:
																																goto end_IL_0a7b;
																															case 7:
																															case 93:
																																goto IL_0ec4_2;
																															}
																															continue;
																															end_IL_038d_2:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_049d_2;
																												continue;
																												end_IL_041d_2:
																												break;
																												IL_041d_2:;
																											}
																											break;
																											IL_042d_2:;
																										}
																										break;
																									}
																									goto IL_04d3_2;
																									IL_07a4_2:
																									array2[num6 - 2] = 0;
																									goto IL_07b8_2;
																									IL_04d3_2:
																									if (9 > b)
																									{
																										break;
																									}
																									num = 102;
																									goto IL_0764_2;
																									IL_07b8_2:
																									num6--;
																									goto end_IL_049d_2;
																									IL_0764_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_07a4_2;
																								}
																								break;
																							}
																							goto IL_0508_2;
																							IL_06a0_2:
																							num6--;
																							goto end_IL_049d_2;
																							IL_0508_2:
																							if (8 > b)
																							{
																								goto IL_0516_2;
																							}
																							goto IL_06a0_2;
																							IL_0516_2:
																							if (6 >= b)
																							{
																								goto IL_0521_2;
																							}
																							goto IL_0534_2;
																							IL_0521_2:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_08a6_2;
																							IL_08a6_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_08e6_2;
																							IL_08e6_2:
																							array2[num6 - 2] = 0;
																							num = 48;
																							goto IL_0903_2;
																							IL_0903_2:
																							num6--;
																							goto end_IL_049d_2;
																							IL_0534_2:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0542_2;
																							IL_0542_2:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0550_2;
																							IL_0550_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0590_2;
																							IL_0590_2:
																							array2[num6 - 2] = 0;
																							goto IL_06b3_2;
																							IL_06b3_2:
																							num6--;
																							goto end_IL_049d_2;
																						}
																						break;
																					}
																					goto IL_061e_2;
																					IL_085c_2:
																					reference = ref array5[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0885_2;
																					IL_0885_2:
																					ptr2 += 8;
																					goto IL_0893_2;
																					IL_061e_2:
																					if (5 <= b)
																					{
																						goto IL_0629_2;
																					}
																					goto IL_0690_2;
																					IL_0629_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0669_2;
																					IL_0669_2:
																					array2[num6 - 2] = 0;
																					goto IL_067d_2;
																					IL_067d_2:
																					num6--;
																					goto end_IL_049d_2;
																					IL_0690_2:
																					if (2 >= b)
																					{
																						goto IL_06c6_2;
																					}
																					goto IL_07cb_2;
																					IL_06c6_2:
																					if (2 > b)
																					{
																						goto IL_06d1_2;
																					}
																					goto IL_06fd_2;
																					IL_06d1_2:
																					if (1 < b)
																					{
																						num = 127;
																						break;
																					}
																					goto IL_06dc_2;
																					IL_06dc_2:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_0893_2:
																					num6--;
																					goto end_IL_049d_2;
																					IL_06fd_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_073d_2;
																					IL_073d_2:
																					array2[num6 - 2] = 0;
																					goto IL_0751_2;
																					IL_0751_2:
																					num6--;
																					goto end_IL_049d_2;
																					IL_07cb_2:
																					if (3 < b)
																					{
																						goto IL_07d6_2;
																					}
																					goto IL_084e_2;
																					IL_07d6_2:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_07e4_2;
																					IL_07e4_2:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_07f2_2;
																					IL_07f2_2:
																					array2[num6] = 0;
																					goto IL_0800_2;
																					IL_0800_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																					goto IL_0823_2;
																					IL_0823_2:
																					array3[num6] = null;
																					goto IL_082d_2;
																					IL_082d_2:
																					num6++;
																					goto IL_083b_2;
																					IL_083b_2:
																					ptr2 += 8;
																					goto end_IL_049d_2;
																					IL_084e_2:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_085c_2;
																				}
																				break;
																			}
																			goto IL_04ef_2;
																			IL_060b_2:
																			ptr2 += 8;
																			goto end_IL_049d_2;
																			IL_04ef_2:
																			array2[num6 - 2] = 0;
																			goto IL_05a9_2;
																			IL_05a9_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)KeyValuePairsAuthenticationType[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_05fd_2;
																			IL_05fd_2:
																			num6--;
																			goto IL_060b_2;
																		}
																		break;
																	}
																	goto IL_0916_2;
																	IL_0d8a_2:
																	num10 = ptr2;
																	num11 = -200;
																	num5 = 1;
																	ptr2 = num10 + num11;
																	num = 92;
																	goto end_IL_049d_2;
																	IL_0916_2:
																	if (17 >= b)
																	{
																		goto IL_0924_2;
																	}
																	goto IL_0beb_2;
																	IL_0924_2:
																	if (17 > b)
																	{
																		goto IL_0932_2;
																	}
																	goto IL_0ba4_2;
																	IL_0932_2:
																	if (14 >= b)
																	{
																		goto IL_0940_2;
																	}
																	goto IL_0aa5_2;
																	IL_0940_2:
																	if (14 <= b)
																	{
																		goto IL_094b_2;
																	}
																	goto IL_098a_2;
																	IL_094b_2:
																	array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																	goto IL_0969_2;
																	IL_0969_2:
																	ptr2 += 8;
																	goto IL_0977_2;
																	IL_0977_2:
																	num6--;
																	goto end_IL_049d_2;
																	IL_098a_2:
																	if (12 >= b)
																	{
																		goto IL_0995_2;
																	}
																	goto IL_09a8_2;
																	IL_0995_2:
																	if (12 <= b)
																	{
																		goto end_IL_049d_2;
																	}
																	break;
																	IL_09a8_2:
																	if (13 < b)
																	{
																		break;
																	}
																	goto IL_09b6_2;
																	IL_09b6_2:
																	if (13 > b)
																	{
																		break;
																	}
																	goto IL_09c4_2;
																	IL_09c4_2:
																	array8 = array3;
																	num7 = num6;
																	if (array == null)
																	{
																		goto IL_09d3_2;
																	}
																	goto IL_09e1;
																	IL_0aa5_2:
																	if (15 < b)
																	{
																		goto IL_0ab3_2;
																	}
																	goto IL_0b54_2;
																	IL_0ab3_2:
																	if (16 < b)
																	{
																		break;
																	}
																	goto IL_0ac1_2;
																	IL_0ac1_2:
																	if (16 > b)
																	{
																		break;
																	}
																	goto IL_0acf_2;
																	IL_0acf_2:
																	array2[num6] = array2[num6 - 1];
																	goto IL_0ae7_2;
																	IL_0ae7_2:
																	array4[num6 - 0] = array4[num6 - 1];
																	goto IL_0b05_2;
																	IL_0b05_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0b29_2;
																	IL_0b29_2:
																	array3[num6] = array3[num6 - 1];
																	goto IL_0b41_2;
																	IL_0b41_2:
																	num6++;
																	goto end_IL_049d_2;
																	IL_0b54_2:
																	if (15 > b)
																	{
																		break;
																	}
																	goto IL_0b62_2;
																	IL_0b62_2:
																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_0b8b_2;
																	IL_0b8b_2:
																	array2[num6 - 1] = 5;
																	goto end_IL_049d_2;
																	IL_0ba4_2:
																	array2[num6] = 5;
																	goto IL_0bb2_2;
																	IL_0bb2_2:
																	array3[num6] = array7[*(int*)(ptr2 + num3)];
																	goto IL_0bca_2;
																	IL_0bca_2:
																	num6++;
																	goto IL_0bd8_2;
																	IL_0bd8_2:
																	ptr2 += 8;
																	goto end_IL_049d_2;
																	IL_0beb_2:
																	if (20 >= b)
																	{
																		goto IL_0bf9_2;
																	}
																	goto IL_0d3d_2;
																	IL_0bf9_2:
																	if (20 > b)
																	{
																		goto IL_0c07_2;
																	}
																	goto IL_0cf5_2;
																	IL_0c07_2:
																	if (18 >= b)
																	{
																		goto IL_0c12_2;
																	}
																	goto IL_0c71_2;
																	IL_0c12_2:
																	if (18 > b)
																	{
																		break;
																	}
																	goto IL_0c20_2;
																	IL_0c20_2:
																	((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																	goto IL_0c5e_2;
																	IL_0c5e_2:
																	num6 -= 3;
																	goto end_IL_049d_2;
																	IL_0c71_2:
																	if (19 < b)
																	{
																		break;
																	}
																	goto IL_0c7f_2;
																	IL_0c7f_2:
																	if (19 > b)
																	{
																		break;
																	}
																	goto IL_0c8d_2;
																	IL_0c8d_2:
																	array2[num6 - 1] = 5;
																	num = 99;
																	goto IL_0caa_2;
																	IL_0caa_2:
																	array3[num6 - 1] = ((delegate*<string[], string>)KeyValuePairsAuthenticationType[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																	goto IL_0ce2_2;
																	IL_0ce2_2:
																	ptr2 += 8;
																	goto end_IL_049d_2;
																	IL_0cf5_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0d0e_2;
																	IL_0d0e_2:
																	array2[num6] = 1;
																	goto IL_0d1c_2;
																	IL_0d1c_2:
																	num6++;
																	goto IL_0d2a_2;
																	IL_0d2a_2:
																	ptr2 += 16;
																	goto end_IL_049d_2;
																	IL_0d3d_2:
																	if (21 >= b)
																	{
																		goto IL_0d48_2;
																	}
																	goto IL_0d6b_2;
																	IL_0d48_2:
																	if (21 > b)
																	{
																		break;
																	}
																	goto IL_0d53_2;
																	IL_0d53_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_049d_2;
																	IL_0d6b_2:
																	if (22 < b)
																	{
																		break;
																	}
																	goto IL_0d76_2;
																	IL_0d76_2:
																	if (22 > b)
																	{
																		break;
																	}
																	num = 129;
																	goto IL_0d8a_2;
																}
																break;
																IL_048d_2:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_0dc5_2;
														IL_0de1_2:
														ptr2 += 8;
														break;
														IL_0dd3_2:
														num6++;
														goto IL_0de1_2;
														IL_0dc5_2:
														array2[num6] = 0;
														goto IL_0dd3_2;
														continue;
														end_IL_049d_2:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0ec4_2;
									IL_0ec4_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0def_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0a7b:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class112()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_5)
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 4;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ListToVectorAdaptersetSkipVerificationInFullTrust.GetStandardSandboxEnableProperty);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01f4:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_01e4:
																			if (b > 10)
																			{
																				num = 109;
																				while (num != 109 && num == 1090)
																				{
																					switch (num)
																					{
																					case 34:
																						goto IL_01e4;
																					case 18:
																						goto IL_01f4;
																					case 35:
																						goto end_IL_01f4;
																					case 27:
																					case 38:
																						goto end_IL_0201;
																					case 21:
																						goto IL_022a;
																					case 89:
																						goto IL_0238;
																					case 13:
																					case 60:
																						goto IL_0243;
																					case 58:
																					case 80:
																						goto IL_024e;
																					case 87:
																						goto IL_025c;
																					case 83:
																						goto IL_026f;
																					case 71:
																						goto IL_0282;
																					case 45:
																					case 72:
																						goto IL_028d;
																					case 51:
																						goto IL_02f4;
																					case 3:
																						goto IL_030b;
																					case 43:
																					case 66:
																						goto IL_0319;
																					case 23:
																						goto IL_0359;
																					case 1:
																						goto IL_036d;
																					case 59:
																					case 93:
																						goto IL_0380;
																					case 96:
																						goto IL_039c;
																					case 97:
																						goto IL_03af;
																					case 31:
																					case 85:
																						goto IL_03ba;
																					case 17:
																						goto IL_03c8;
																					case 20:
																						goto IL_03eb;
																					case 76:
																						goto IL_03f5;
																					case 24:
																						goto IL_0403;
																					case 25:
																						goto IL_041f;
																					case 65:
																					case 77:
																						goto IL_042a;
																					case 52:
																						goto IL_0435;
																					case 55:
																						goto IL_0443;
																					case 10:
																						goto IL_045f;
																					case 36:
																					case 49:
																						goto IL_046d;
																					case 74:
																						goto IL_0485;
																					case 48:
																					case 81:
																						goto IL_0490;
																					case 50:
																						goto IL_04b9;
																					case 6:
																						goto IL_04c7;
																					case 84:
																						goto IL_04da;
																					case 75:
																						goto IL_04e8;
																					case 73:
																					case 95:
																						goto IL_04f6;
																					case 79:
																						goto IL_050f;
																					case 11:
																						goto IL_051d;
																					case 28:
																						goto IL_052b;
																					case 101:
																						goto IL_053e;
																					case 16:
																						goto IL_0549;
																					case 44:
																					case 91:
																						goto IL_055d;
																					case 5:
																						goto IL_0580;
																					case 90:
																						goto IL_058e;
																					case 41:
																						goto IL_059c;
																					case 0:
																					case 2:
																					case 12:
																					case 14:
																					case 19:
																					case 22:
																					case 26:
																					case 29:
																					case 30:
																					case 37:
																					case 40:
																					case 46:
																					case 54:
																					case 56:
																					case 57:
																					case 62:
																					case 86:
																					case 98:
																						goto end_IL_01d1;
																					case 7:
																					case 15:
																					case 32:
																					case 33:
																					case 39:
																					case 63:
																					case 68:
																					case 78:
																					case 82:
																					case 92:
																					case 94:
																					case 99:
																					case 100:
																						goto end_IL_0211;
																					case 88:
																						goto end_IL_05c8;
																					case 102:
																						goto end_IL_05db;
																					case 53:
																						goto end_IL_05e5;
																					case 61:
																						goto end_IL_05f0;
																					case 8:
																					case 47:
																						goto end_IL_0605;
																					case 67:
																						goto end_IL_0615;
																					case 4:
																						goto end_IL_0625;
																					case 64:
																						goto end_IL_0635;
																					case 69:
																						goto end_IL_0645;
																					case 70:
																						goto end_IL_0650;
																					case 9:
																					case 42:
																						goto IL_066b;
																					}
																					continue;
																					end_IL_01d1:
																					break;
																				}
																				break;
																			}
																			goto IL_022a;
																			IL_04e8:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04f6;
																			IL_04f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_050f;
																			IL_022a:
																			if (5 < b)
																			{
																				goto IL_0238;
																			}
																			goto IL_03af;
																			IL_0238:
																			if (8 < b)
																			{
																				goto IL_0243;
																			}
																			goto IL_0282;
																			IL_0243:
																			if (9 < b)
																			{
																				goto IL_024e;
																			}
																			goto IL_026f;
																			IL_024e:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_025c;
																			IL_025c:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_026f:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0380;
																			IL_0380:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0211;
																			IL_0282:
																			if (8 <= b)
																			{
																				goto IL_028d;
																			}
																			goto IL_02f4;
																			IL_028d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_039c;
																			IL_039c:
																			num5 -= 2;
																			goto end_IL_0211;
																			IL_02f4:
																			if (6 >= b)
																			{
																				num = 3;
																				goto IL_030b;
																			}
																			goto IL_053e;
																			IL_050f:
																			array[num5] = 0;
																			goto IL_051d;
																			IL_030b:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0319;
																			IL_0319:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0359;
																			IL_0359:
																			array[num5 - 2] = 0;
																			goto IL_036d;
																			IL_036d:
																			num5--;
																			goto end_IL_0211;
																			IL_053e:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0549;
																			IL_0549:
																			if (7 > b)
																			{
																				break;
																			}
																			num = 91;
																			goto IL_055d;
																			IL_051d:
																			num5++;
																			goto IL_052b;
																			IL_055d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0580;
																			IL_0580:
																			array[num5] = 0;
																			goto IL_058e;
																			IL_058e:
																			num5++;
																			goto IL_059c;
																			IL_059c:
																			ptr2 += 8;
																			goto end_IL_0211;
																			IL_03af:
																			if (5 <= b)
																			{
																				goto IL_03ba;
																			}
																			goto IL_041f;
																			IL_03ba:
																			array[num5] = 0;
																			goto IL_03c8;
																			IL_03c8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03eb;
																			IL_03eb:
																			array2[num5] = null;
																			goto IL_03f5;
																			IL_03f5:
																			num5++;
																			goto IL_0403;
																			IL_0403:
																			ptr2 += 8;
																			num = 68;
																			goto end_IL_0211;
																			IL_041f:
																			if (2 < b)
																			{
																				goto IL_042a;
																			}
																			goto IL_0485;
																			IL_042a:
																			if (3 < b)
																			{
																				goto IL_0435;
																			}
																			num = 10;
																			goto IL_045f;
																			IL_0435:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0443;
																			IL_0443:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0211;
																			IL_052b:
																			ptr2 += 8;
																			goto end_IL_0211;
																			IL_045f:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_046d;
																			IL_046d:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0211;
																			IL_0485:
																			if (2 <= b)
																			{
																				goto IL_0490;
																			}
																			goto IL_04da;
																			IL_0490:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b9;
																			IL_04b9:
																			ptr2 += 8;
																			goto IL_04c7;
																			IL_04c7:
																			num5--;
																			goto end_IL_0211;
																			IL_04da:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04e8;
																		}
																	}
																	else
																	{
																		num = 62;
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 99;
																	goto end_IL_0211;
																	continue;
																	end_IL_01f4:
																	break;
																}
																continue;
																end_IL_0201:
																break;
															}
															continue;
															end_IL_0211:
															break;
														}
														continue;
													}
													goto IL_066b;
													IL_066b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05c8:
													break;
												}
												continue;
												end_IL_05db:
												break;
											}
											continue;
											end_IL_05e5:
											break;
										}
										continue;
										end_IL_05f0:
										break;
									}
									continue;
									end_IL_0605:
									break;
								}
								continue;
								end_IL_0615:
								break;
							}
							continue;
							end_IL_0625:
							break;
						}
						continue;
						end_IL_0635:
						break;
					}
					continue;
					end_IL_0645:
					break;
				}
				continue;
				end_IL_0650:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_5, int int_6)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											IL_0239:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IncludeSectDomain.GetObjectParamSafeArrayTypeMismatchException);
											num = 99;
											while (true)
											{
												IL_0226:
												byte* ptr2 = ptr;
												num = 129;
												while (true)
												{
													if (num != 129)
													{
														if (num != 1110)
														{
															break;
														}
														switch (num)
														{
														case 99:
															goto IL_0226;
														case 65:
															goto IL_0239;
														case 105:
															goto end_IL_0213;
														case 74:
															goto end_IL_024d;
														case 3:
															goto end_IL_0262;
														case 59:
														case 108:
															goto end_IL_0277;
														case 48:
															goto end_IL_0287;
														case 68:
														case 82:
															goto end_IL_0297;
														case 32:
															goto end_IL_02a7;
														case 33:
															goto end_IL_02b7;
														case 8:
														case 13:
														case 49:
														case 50:
														case 64:
														case 79:
														case 87:
														case 89:
														case 101:
														case 106:
														case 112:
														case 118:
															goto IL_02d2;
														case 19:
														case 44:
															goto IL_02e2;
														case 10:
															goto IL_02eb;
														case 100:
															goto IL_02f9;
														case 61:
															goto IL_0307;
														case 116:
															goto IL_0315;
														case 4:
															goto IL_0323;
														case 34:
															goto IL_0331;
														case 83:
															goto IL_033f;
														case 58:
														case 80:
															goto IL_034a;
														case 43:
															goto IL_0373;
														case 18:
															goto IL_0381;
														case 45:
														case 122:
															goto IL_0394;
														case 26:
															goto IL_039f;
														case 27:
															goto IL_03b2;
														case 107:
															goto IL_03c0;
														case 15:
														case 115:
															goto IL_03d7;
														case 6:
															goto IL_0417;
														case 41:
															goto IL_042b;
														case 7:
														case 29:
															goto IL_043e;
														case 22:
														case 84:
															goto IL_044c;
														case 55:
															goto IL_045a;
														case 0:
														case 110:
															goto IL_0468;
														case 39:
															goto IL_047f;
														case 9:
															goto IL_04a2;
														case 85:
															goto IL_04ac;
														case 86:
															goto IL_04ba;
														case 113:
															goto IL_04cd;
														case 24:
														case 121:
															goto IL_04db;
														case 109:
															goto IL_051b;
														case 38:
															goto IL_052f;
														case 23:
														case 95:
															goto IL_0542;
														case 62:
															goto IL_0582;
														case 12:
															goto IL_0596;
														case 14:
															goto IL_05b2;
														case 94:
															goto IL_05bd;
														case 117:
															goto IL_05c8;
														case 40:
														case 81:
															goto IL_05d6;
														case 98:
															goto IL_05e9;
														case 69:
															goto IL_05f7;
														case 53:
														case 92:
															goto IL_0605;
														case 97:
															goto IL_0621;
														case 56:
															goto IL_062f;
														case 96:
															goto IL_063a;
														case 2:
														case 67:
															goto IL_0648;
														case 70:
															goto IL_0661;
														case 75:
															goto IL_066f;
														case 76:
															goto IL_067d;
														case 1:
															goto IL_0690;
														case 25:
															goto IL_069e;
														case 46:
														case 91:
															goto IL_06ac;
														case 77:
															goto IL_06ec;
														case 30:
															goto IL_0700;
														case 54:
														case 104:
															goto IL_071c;
														case 28:
															goto IL_0730;
														case 66:
															goto IL_0784;
														case 78:
															goto IL_0792;
														case 119:
															goto IL_07a5;
														case 88:
															goto IL_07b3;
														case 102:
															goto IL_07c1;
														case 5:
														case 11:
														case 16:
														case 17:
														case 20:
														case 21:
														case 31:
														case 35:
														case 36:
														case 37:
														case 42:
														case 47:
														case 52:
														case 57:
														case 60:
														case 63:
														case 72:
														case 73:
														case 90:
														case 93:
														case 103:
														case 111:
														case 114:
														case 120:
															goto IL_07d4;
														case 51:
														case 71:
															goto IL_07f9;
														}
														continue;
													}
													goto IL_02d2;
													IL_07d4:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_07a5;
													IL_07a5:
													array[num4] = 0;
													goto IL_07b3;
													IL_02d2:
													if (num5 != 1)
													{
														goto IL_02e2;
													}
													goto IL_07f9;
													IL_07f9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_02e2:
													b = *ptr2;
													goto IL_02eb;
													IL_02eb:
													ptr2++;
													goto IL_02f9;
													IL_02f9:
													if (b >= 1)
													{
														goto IL_0307;
													}
													goto IL_07d4;
													IL_0307:
													if (b <= 11)
													{
														goto IL_0315;
													}
													goto IL_07d4;
													IL_0315:
													if (6 >= b)
													{
														goto IL_0323;
													}
													goto IL_05b2;
													IL_0323:
													if (6 > b)
													{
														goto IL_0331;
													}
													goto IL_0542;
													IL_0331:
													if (3 >= b)
													{
														goto IL_033f;
													}
													goto IL_043e;
													IL_033f:
													if (3 <= b)
													{
														goto IL_034a;
													}
													goto IL_0394;
													IL_034a:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0373;
													IL_0373:
													ptr2 += 8;
													goto IL_0381;
													IL_0381:
													num4--;
													goto IL_02d2;
													IL_0394:
													if (1 >= b)
													{
														goto IL_039f;
													}
													goto IL_03b2;
													IL_039f:
													if (1 > b)
													{
													}
													goto IL_07d4;
													IL_03b2:
													if (2 >= b)
													{
														goto IL_03c0;
													}
													goto IL_07d4;
													IL_03c0:
													if (2 <= b)
													{
														num = 115;
														goto IL_03d7;
													}
													goto IL_07d4;
													IL_07b3:
													num4++;
													goto IL_07c1;
													IL_03d7:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0417;
													IL_0417:
													array[num4 - 2] = 0;
													goto IL_042b;
													IL_042b:
													num4--;
													goto IL_02d2;
													IL_043e:
													if (4 < b)
													{
														goto IL_044c;
													}
													goto IL_04cd;
													IL_044c:
													if (5 >= b)
													{
														goto IL_045a;
													}
													goto IL_07d4;
													IL_045a:
													if (5 <= b)
													{
														goto IL_0468;
													}
													goto IL_07d4;
													IL_0468:
													array[num4] = 0;
													num = 39;
													goto IL_047f;
													IL_047f:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_04a2;
													IL_04a2:
													array2[num4] = null;
													goto IL_04ac;
													IL_04ac:
													num4++;
													goto IL_04ba;
													IL_04ba:
													ptr2 += 8;
													goto IL_02d2;
													IL_04cd:
													if (4 <= b)
													{
														goto IL_04db;
													}
													goto IL_07d4;
													IL_04db:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_051b;
													IL_051b:
													array[num4 - 2] = 0;
													goto IL_052f;
													IL_052f:
													num4--;
													goto IL_02d2;
													IL_0542:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0582;
													IL_0582:
													array[num4 - 2] = 0;
													goto IL_0596;
													IL_0596:
													num4--;
													num = 118;
													goto IL_02d2;
													IL_05b2:
													if (9 < b)
													{
														goto IL_05bd;
													}
													goto IL_0621;
													IL_05bd:
													if (10 >= b)
													{
														goto IL_05c8;
													}
													goto IL_05e9;
													IL_05c8:
													if (10 <= b)
													{
														goto IL_05d6;
													}
													goto IL_07d4;
													IL_05d6:
													num4--;
													goto IL_02d2;
													IL_05e9:
													if (11 >= b)
													{
														goto IL_05f7;
													}
													goto IL_07d4;
													IL_05f7:
													if (11 <= b)
													{
														goto IL_0605;
													}
													goto IL_07d4;
													IL_0605:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_02d2;
													IL_0621:
													if (9 > b)
													{
														goto IL_062f;
													}
													num = 104;
													goto IL_071c;
													IL_062f:
													if (7 >= b)
													{
														goto IL_063a;
													}
													goto IL_0690;
													IL_063a:
													if (7 <= b)
													{
														goto IL_0648;
													}
													goto IL_07d4;
													IL_0648:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
													goto IL_0661;
													IL_0661:
													array[num4] = 0;
													goto IL_066f;
													IL_066f:
													num4++;
													goto IL_067d;
													IL_067d:
													ptr2 += 8;
													goto IL_02d2;
													IL_0690:
													if (8 >= b)
													{
														goto IL_069e;
													}
													goto IL_07d4;
													IL_069e:
													if (8 <= b)
													{
														goto IL_06ac;
													}
													goto IL_07d4;
													IL_06ac:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_06ec;
													IL_06ec:
													array[num4 - 2] = 0;
													goto IL_0700;
													IL_0700:
													num4--;
													goto IL_02d2;
													IL_07c1:
													ptr2 += 8;
													goto IL_02d2;
													IL_071c:
													array[num4 - 2] = 0;
													goto IL_0730;
													IL_0730:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((delegate*<int, int, int>)DebugActivityIdInfiniteTimeSpan[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]));
													goto IL_0784;
													IL_0784:
													num4--;
													goto IL_0792;
													IL_0792:
													ptr2 += 8;
													goto IL_02d2;
													continue;
													end_IL_0213:
													break;
												}
												break;
											}
											break;
										}
										continue;
										end_IL_024d:
										break;
									}
									continue;
									end_IL_0262:
									break;
								}
								continue;
								end_IL_0277:
								break;
							}
							continue;
							end_IL_0287:
							break;
						}
						continue;
						end_IL_0297:
						break;
					}
					continue;
					end_IL_02a7:
					break;
				}
				continue;
				end_IL_02b7:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_5)
	{
		int num = 82;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 86;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetStubDataReadOnlyDictionaryHelpers.GetXmlTypeForInteropTypeCreateServerChannelSinkChain);
											num = 13;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0255:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0238:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0228:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_0218:
																								if (10 >= b)
																								{
																									while (true)
																									{
																										IL_0208:
																										if (10 > b)
																										{
																											num = 118;
																											while (num != 118)
																											{
																												if (num != 1099)
																												{
																													goto IL_05d3;
																												}
																												switch (num)
																												{
																												case 52:
																													goto IL_0208;
																												case 11:
																												case 75:
																													goto IL_0218;
																												case 70:
																													goto IL_0228;
																												case 32:
																													goto IL_0238;
																												case 66:
																													goto IL_0245;
																												case 26:
																													goto IL_0255;
																												case 8:
																													goto end_IL_0255;
																												case 4:
																												case 53:
																													goto end_IL_0265;
																												case 50:
																												case 101:
																													goto IL_0280;
																												case 103:
																													goto IL_029c;
																												case 5:
																												case 60:
																													goto IL_02aa;
																												case 40:
																												case 71:
																													goto IL_02b8;
																												case 55:
																													goto IL_02c3;
																												case 14:
																													goto IL_02d6;
																												case 28:
																													goto IL_02e4;
																												case 3:
																												case 61:
																													goto IL_02f2;
																												case 44:
																													goto IL_0300;
																												case 56:
																													goto IL_0323;
																												case 64:
																													goto IL_032d;
																												case 87:
																													goto IL_033b;
																												case 88:
																													goto IL_034e;
																												case 17:
																												case 84:
																													goto IL_0359;
																												case 98:
																													goto IL_0371;
																												case 54:
																													goto IL_037c;
																												case 9:
																												case 85:
																													goto IL_038a;
																												case 79:
																													goto IL_03a3;
																												case 31:
																													goto IL_03b1;
																												case 23:
																													goto IL_03bf;
																												case 72:
																													goto IL_03d2;
																												case 19:
																													goto IL_03e0;
																												case 10:
																												case 102:
																													goto IL_03ee;
																												case 25:
																													goto IL_0417;
																												case 58:
																													goto IL_0425;
																												case 97:
																												case 110:
																													goto IL_0438;
																												case 92:
																													goto IL_0478;
																												case 80:
																													goto IL_048c;
																												case 76:
																													goto IL_049f;
																												case 77:
																													goto IL_04ad;
																												case 63:
																													goto IL_04c0;
																												case 35:
																												case 96:
																													goto IL_04cb;
																												case 18:
																													goto IL_052d;
																												case 24:
																												case 62:
																													goto IL_0540;
																												case 59:
																													goto IL_054b;
																												case 91:
																												case 99:
																													goto IL_0559;
																												case 38:
																													goto IL_0599;
																												case 109:
																													goto IL_05ad;
																												case 39:
																													goto IL_05bd;
																												case 45:
																													goto IL_05c8;
																												case 83:
																												case 104:
																													goto IL_05d3;
																												case 33:
																													goto IL_05f6;
																												case 29:
																													goto IL_0604;
																												case 41:
																													goto IL_0612;
																												case 1:
																												case 2:
																												case 6:
																												case 12:
																												case 21:
																												case 22:
																												case 34:
																												case 42:
																												case 46:
																												case 48:
																												case 49:
																												case 51:
																												case 57:
																												case 67:
																												case 73:
																												case 93:
																												case 95:
																												case 100:
																												case 106:
																													goto end_IL_01f5;
																												case 7:
																												case 16:
																												case 27:
																												case 30:
																												case 36:
																												case 37:
																												case 43:
																												case 47:
																												case 78:
																												case 89:
																												case 90:
																												case 94:
																												case 105:
																												case 107:
																													goto end_IL_0275;
																												case 13:
																													goto end_IL_0635;
																												case 68:
																													goto end_IL_0648;
																												case 69:
																													goto end_IL_0652;
																												case 20:
																													goto end_IL_0666;
																												case 108:
																												case 111:
																													goto end_IL_067b;
																												case 74:
																													goto end_IL_068b;
																												case 86:
																													goto end_IL_069b;
																												case 0:
																													goto end_IL_06ab;
																												case 81:
																													goto end_IL_06bb;
																												case 82:
																													goto end_IL_06c6;
																												case 15:
																												case 65:
																													goto IL_06e1;
																												}
																												continue;
																												end_IL_01f5:
																												break;
																											}
																											break;
																										}
																										goto IL_0280;
																										IL_0280:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0275;
																									}
																									break;
																								}
																								goto IL_049f;
																								IL_04ad:
																								if (11 <= b)
																								{
																								}
																								break;
																								IL_049f:
																								if (11 < b)
																								{
																									break;
																								}
																								goto IL_04ad;
																							}
																							break;
																						}
																						goto IL_04c0;
																						IL_0612:
																						ptr2 += 8;
																						goto end_IL_0275;
																						IL_04c0:
																						if (9 <= b)
																						{
																							goto IL_04cb;
																						}
																						goto IL_0540;
																						IL_04cb:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_052d;
																						IL_052d:
																						num6 -= 2;
																						goto end_IL_0275;
																						IL_0540:
																						if (7 >= b)
																						{
																							goto IL_054b;
																						}
																						goto IL_05bd;
																						IL_054b:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0559;
																						IL_0559:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0599;
																						IL_0599:
																						array[num6 - 2] = 0;
																						goto IL_05ad;
																						IL_05ad:
																						num6--;
																						goto end_IL_0275;
																						IL_05bd:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_05c8;
																						IL_05c8:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_05d3;
																						IL_05d3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05f6;
																						IL_05f6:
																						array[num6] = 0;
																						goto IL_0604;
																						IL_0604:
																						num6++;
																						goto IL_0612;
																					}
																					break;
																				}
																				goto IL_029c;
																				IL_048c:
																				num6--;
																				goto end_IL_0275;
																				IL_029c:
																				if (6 > b)
																				{
																					goto IL_02aa;
																				}
																				goto IL_0438;
																				IL_02aa:
																				if (3 < b)
																				{
																					goto IL_02b8;
																				}
																				goto IL_034e;
																				IL_02b8:
																				if (4 >= b)
																				{
																					goto IL_02c3;
																				}
																				goto IL_02d6;
																				IL_02c3:
																				if (4 <= b)
																				{
																					goto end_IL_0275;
																				}
																				break;
																				IL_02d6:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_02e4;
																				IL_02e4:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_02f2;
																				IL_02f2:
																				array[num6] = 0;
																				goto IL_0300;
																				IL_0300:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0323;
																				IL_0323:
																				array2[num6] = null;
																				goto IL_032d;
																				IL_032d:
																				num6++;
																				goto IL_033b;
																				IL_033b:
																				ptr2 += 8;
																				goto end_IL_0275;
																				IL_034e:
																				if (3 <= b)
																				{
																					goto IL_0359;
																				}
																				goto IL_0371;
																				IL_0359:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0275;
																				IL_0371:
																				if (1 >= b)
																				{
																					goto IL_037c;
																				}
																				goto IL_03d2;
																				IL_037c:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_038a;
																				IL_038a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_03a3;
																				IL_03a3:
																				array[num6] = 0;
																				goto IL_03b1;
																				IL_03b1:
																				num6++;
																				goto IL_03bf;
																				IL_03bf:
																				ptr2 += 8;
																				goto end_IL_0275;
																				IL_03d2:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_03e0;
																				IL_03e0:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_03ee;
																				IL_03ee:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0417;
																				IL_0417:
																				ptr2 += 8;
																				goto IL_0425;
																				IL_0425:
																				num6--;
																				goto end_IL_0275;
																				IL_0438:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0478;
																				IL_0478:
																				array[num6 - 2] = 0;
																				goto IL_048c;
																			}
																			break;
																			IL_0245:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0275;
																	continue;
																	end_IL_0255:
																	break;
																}
																continue;
																end_IL_0265:
																break;
															}
															continue;
															end_IL_0275:
															break;
														}
														continue;
													}
													goto IL_06e1;
													IL_06e1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0635:
													break;
												}
												continue;
												end_IL_0648:
												break;
											}
											continue;
											end_IL_0652:
											break;
										}
										continue;
										end_IL_0666:
										break;
									}
									continue;
									end_IL_067b:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_069b:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06c6:
				break;
			}
		}
	}

	private unsafe static int smethod_16()
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnmanagedMemoryStreamgetJustification.setNativeDigitsStringType);
										num = 4;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 108;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02fc:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02dc:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02cc:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02bf:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02af:
																										if (10 < b)
																										{
																											while (true)
																											{
																												IL_029c:
																												if (11 < b)
																												{
																													num = 155;
																													while (num != 155)
																													{
																														if (num != 1136)
																														{
																															goto IL_0675;
																														}
																														switch (num)
																														{
																														case 18:
																														case 111:
																															goto IL_029c;
																														case 109:
																															goto IL_02af;
																														case 77:
																															goto IL_02bf;
																														case 39:
																															goto IL_02cc;
																														case 58:
																															goto IL_02dc;
																														case 134:
																															goto IL_02ec;
																														case 126:
																															goto IL_02fc;
																														case 137:
																															goto end_IL_02fc;
																														case 108:
																															goto end_IL_030c;
																														case 23:
																															goto end_IL_031c;
																														case 9:
																															goto IL_0332;
																														case 38:
																														case 85:
																															goto IL_0342;
																														case 12:
																															goto IL_0382;
																														case 101:
																															goto IL_0396;
																														case 60:
																														case 144:
																															goto IL_03a9;
																														case 41:
																															goto IL_03ed;
																														case 19:
																															goto IL_0401;
																														case 20:
																															goto IL_041d;
																														case 54:
																														case 93:
																															goto IL_0428;
																														case 33:
																															goto IL_0436;
																														case 5:
																															goto IL_0459;
																														case 61:
																															goto IL_0463;
																														case 44:
																															goto IL_0471;
																														case 53:
																														case 136:
																															goto IL_0484;
																														case 13:
																															goto IL_0492;
																														case 113:
																															goto IL_04a5;
																														case 98:
																															goto IL_04bc;
																														case 34:
																														case 42:
																															goto IL_04c7;
																														case 29:
																															goto IL_04e3;
																														case 80:
																															goto IL_04f1;
																														case 40:
																														case 88:
																															goto IL_04ff;
																														case 30:
																															goto IL_0561;
																														case 140:
																															goto IL_0574;
																														case 102:
																															goto IL_0582;
																														case 83:
																															goto IL_0595;
																														case 36:
																														case 125:
																															goto IL_05a0;
																														case 117:
																															goto IL_05b8;
																														case 106:
																															goto IL_05c6;
																														case 14:
																														case 145:
																															goto IL_05d1;
																														case 28:
																															goto IL_05df;
																														case 92:
																														case 95:
																															goto IL_05ed;
																														case 63:
																															goto IL_0616;
																														case 81:
																															goto IL_062d;
																														case 135:
																															goto IL_0640;
																														case 45:
																														case 55:
																															goto IL_064b;
																														case 119:
																															goto IL_0659;
																														case 76:
																														case 100:
																															goto IL_0667;
																														case 86:
																															goto IL_0675;
																														case 35:
																															goto IL_068d;
																														case 62:
																															goto IL_069b;
																														case 32:
																														case 116:
																															goto IL_06ae;
																														case 138:
																															goto IL_06ed;
																														case 46:
																															goto IL_0700;
																														case 67:
																														case 105:
																															goto IL_070e;
																														case 133:
																															goto IL_071c;
																														case 51:
																														case 120:
																															goto IL_0727;
																														case 79:
																															goto IL_0767;
																														case 148:
																															goto IL_077b;
																														case 15:
																															goto IL_078e;
																														case 78:
																															goto IL_07a5;
																														case 0:
																														case 96:
																															goto IL_07b3;
																														case 121:
																															goto IL_07cc;
																														case 16:
																															goto IL_07da;
																														case 66:
																															goto IL_07e8;
																														case 141:
																															goto IL_07fb;
																														case 68:
																															goto IL_0806;
																														case 27:
																														case 122:
																															goto IL_0814;
																														case 10:
																															goto IL_083d;
																														case 52:
																														case 130:
																															goto IL_085e;
																														case 70:
																															goto IL_087c;
																														case 89:
																															goto IL_088a;
																														case 6:
																														case 11:
																														case 25:
																														case 47:
																														case 48:
																														case 50:
																														case 56:
																														case 65:
																														case 72:
																														case 73:
																														case 74:
																														case 75:
																														case 87:
																														case 91:
																														case 94:
																														case 97:
																														case 99:
																														case 103:
																														case 104:
																														case 107:
																														case 112:
																														case 123:
																														case 124:
																														case 127:
																														case 131:
																														case 139:
																														case 142:
																														case 146:
																														case 147:
																															goto end_IL_0289;
																														case 1:
																														case 17:
																														case 22:
																														case 24:
																														case 26:
																														case 31:
																														case 37:
																														case 43:
																														case 57:
																														case 59:
																														case 71:
																														case 110:
																														case 114:
																														case 115:
																														case 118:
																														case 128:
																														case 132:
																														case 143:
																															goto end_IL_0327;
																														case 4:
																															goto end_IL_08b6;
																														case 84:
																															goto end_IL_08c9;
																														case 69:
																															goto end_IL_08d3;
																														case 82:
																															goto end_IL_08e7;
																														case 2:
																														case 64:
																															goto end_IL_08f7;
																														case 49:
																															goto end_IL_0907;
																														case 21:
																														case 129:
																															goto end_IL_0917;
																														case 7:
																															goto end_IL_0927;
																														case 8:
																															goto end_IL_0937;
																														case 3:
																														case 90:
																															goto IL_0952;
																														}
																														continue;
																														end_IL_0289:
																														break;
																													}
																													break;
																												}
																												goto IL_0332;
																												IL_03ed:
																												array[num5 - 2] = 0;
																												goto IL_0401;
																												IL_0401:
																												num5--;
																												num = 37;
																												goto end_IL_0327;
																												IL_0332:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_03a9;
																												IL_03a9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																												goto IL_03ed;
																											}
																											break;
																										}
																										goto IL_041d;
																										IL_0492:
																										if (9 <= b)
																										{
																											goto end_IL_0327;
																										}
																										break;
																										IL_041d:
																										if (10 <= b)
																										{
																											goto IL_0428;
																										}
																										goto IL_0484;
																										IL_0428:
																										array[num5] = 0;
																										goto IL_0436;
																										IL_0436:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_0459;
																										IL_0459:
																										array2[num5] = null;
																										goto IL_0463;
																										IL_0463:
																										num5++;
																										goto IL_0471;
																										IL_0471:
																										ptr2 += 8;
																										goto end_IL_0327;
																										IL_0484:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_0492;
																									}
																									break;
																								}
																								goto IL_0342;
																								IL_0396:
																								num5--;
																								goto end_IL_0327;
																								IL_0342:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0382;
																								IL_0382:
																								array[num5 - 2] = 0;
																								goto IL_0396;
																							}
																							break;
																						}
																						goto IL_04a5;
																						IL_0574:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0582;
																						IL_04a5:
																						if (14 >= b)
																						{
																							num = 98;
																							goto IL_04bc;
																						}
																						goto IL_0574;
																						IL_0582:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_04bc:
																						if (14 <= b)
																						{
																							goto IL_04c7;
																						}
																						goto IL_04e3;
																						IL_04c7:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0327;
																						IL_04e3:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_04f1;
																						IL_04f1:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_04ff;
																						IL_04ff:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0561;
																						IL_0561:
																						num5 -= 2;
																						goto end_IL_0327;
																					}
																					break;
																				}
																				goto IL_0595;
																				IL_085e:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_087c;
																				IL_0595:
																				if (8 <= b)
																				{
																					goto IL_05a0;
																				}
																				goto IL_05b8;
																				IL_05a0:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0327;
																				IL_05b8:
																				if (4 < b)
																				{
																					goto IL_05c6;
																				}
																				goto IL_0700;
																				IL_05c6:
																				if (6 < b)
																				{
																					goto IL_05d1;
																				}
																				goto IL_0640;
																				IL_05d1:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_05df;
																				IL_05df:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05ed;
																				IL_05ed:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0616;
																				IL_0616:
																				ptr2 += 8;
																				num = 81;
																				goto IL_062d;
																				IL_062d:
																				num5--;
																				goto end_IL_0327;
																				IL_0640:
																				if (6 > b)
																				{
																					goto IL_064b;
																				}
																				goto IL_06ae;
																				IL_064b:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0659;
																				IL_0659:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0667;
																				IL_0667:
																				array[num5] = 5;
																				goto IL_0675;
																				IL_0675:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_068d;
																				IL_068d:
																				num5++;
																				goto IL_069b;
																				IL_069b:
																				ptr2 += 8;
																				goto end_IL_0327;
																				IL_06ae:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06ed;
																				IL_06ed:
																				num5 -= 3;
																				goto end_IL_0327;
																				IL_0700:
																				if (4 > b)
																				{
																					goto IL_070e;
																				}
																				goto IL_085e;
																				IL_070e:
																				if (2 >= b)
																				{
																					goto IL_071c;
																				}
																				goto IL_07fb;
																				IL_071c:
																				if (2 <= b)
																				{
																					goto IL_0727;
																				}
																				goto IL_078e;
																				IL_0727:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0767;
																				IL_0767:
																				array[num5 - 2] = 0;
																				goto IL_077b;
																				IL_077b:
																				num5--;
																				goto end_IL_0327;
																				IL_078e:
																				if (1 < b)
																				{
																					break;
																				}
																				num = 78;
																				goto IL_07a5;
																				IL_087c:
																				ptr2 += 8;
																				goto IL_088a;
																				IL_07a5:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_07b3;
																				IL_07b3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_07cc;
																				IL_07cc:
																				array[num5] = 0;
																				goto IL_07da;
																				IL_07da:
																				num5++;
																				goto IL_07e8;
																				IL_07e8:
																				ptr2 += 8;
																				goto end_IL_0327;
																				IL_07fb:
																				if (3 < b)
																				{
																					num = 47;
																					break;
																				}
																				goto IL_0806;
																				IL_0806:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0814;
																				IL_0814:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_083d;
																				IL_083d:
																				array[num5 - 1] = 5;
																				goto end_IL_0327;
																				IL_088a:
																				num5--;
																				num = 71;
																				goto end_IL_0327;
																			}
																			break;
																			IL_02ec:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0327;
																	continue;
																	end_IL_02fc:
																	break;
																}
																continue;
																end_IL_030c:
																break;
															}
															continue;
															end_IL_031c:
															break;
														}
														continue;
														end_IL_0327:
														break;
													}
													continue;
												}
												goto IL_0952;
												IL_0952:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08b6:
												break;
											}
											continue;
											end_IL_08c9:
											break;
										}
										continue;
										end_IL_08d3:
										break;
									}
									continue;
									end_IL_08e7:
									break;
								}
								continue;
								end_IL_08f7:
								break;
							}
							continue;
							end_IL_0907:
							break;
						}
						continue;
						end_IL_0917:
						break;
					}
					continue;
					end_IL_0927:
					break;
				}
				continue;
				end_IL_0937:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_5)
	{
		int num = 65;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 64;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DiscretionaryAclgetCursorTop.ViewAndModifyFullTrustZoneUntrusted);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02b0:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		num = 104;
																		while (true)
																		{
																			IL_028d:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_027d:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0270:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0260:
																									if (2 > b)
																									{
																										while (1 >= b)
																										{
																											while (1 <= b)
																											{
																												while (true)
																												{
																													IL_0225:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													while (true)
																													{
																														IL_0215:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_01fc:
																															num5++;
																															num = 115;
																															while (true)
																															{
																																if (num != 115)
																																{
																																	if (num != 1096)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 20:
																																		goto IL_01fc;
																																	case 12:
																																		goto IL_0215;
																																	case 49:
																																	case 68:
																																		goto IL_0225;
																																	case 43:
																																		goto IL_0240;
																																	case 31:
																																	case 77:
																																		goto IL_0250;
																																	case 74:
																																		goto IL_0260;
																																	case 51:
																																	case 63:
																																		goto IL_0270;
																																	case 52:
																																		goto IL_027d;
																																	case 104:
																																		goto IL_028d;
																																	case 14:
																																		goto IL_029d;
																																	case 60:
																																		goto IL_02b0;
																																	case 105:
																																		goto end_IL_02b0;
																																	case 87:
																																	case 99:
																																		goto end_IL_02bd;
																																	case 25:
																																	case 96:
																																		goto IL_02e6;
																																	case 37:
																																		goto IL_02f1;
																																	case 28:
																																	case 46:
																																		goto IL_030a;
																																	case 92:
																																		goto IL_032b;
																																	case 11:
																																		goto IL_0339;
																																	case 18:
																																	case 54:
																																		goto IL_035f;
																																	case 61:
																																		goto IL_0388;
																																	case 32:
																																		goto IL_0396;
																																	case 85:
																																	case 98:
																																		goto end_IL_01e9;
																																	case 17:
																																		goto IL_03c0;
																																	case 50:
																																		goto IL_03e3;
																																	case 13:
																																		goto IL_03ed;
																																	case 8:
																																		goto IL_03fb;
																																	case 67:
																																		goto IL_040e;
																																	case 66:
																																		goto IL_041c;
																																	case 1:
																																	case 15:
																																		goto IL_042a;
																																	case 41:
																																	case 78:
																																		goto IL_0435;
																																	case 19:
																																		goto IL_0443;
																																	case 16:
																																	case 59:
																																		goto IL_0451;
																																	case 24:
																																		goto IL_0474;
																																	case 53:
																																		goto IL_0482;
																																	case 101:
																																		goto IL_0490;
																																	case 89:
																																		goto IL_04a3;
																																	case 3:
																																	case 73:
																																		goto IL_04b1;
																																	case 79:
																																		goto IL_04f1;
																																	case 58:
																																		goto IL_0505;
																																	case 34:
																																	case 48:
																																		goto IL_0518;
																																	case 86:
																																		goto IL_0583;
																																	case 90:
																																		goto IL_0593;
																																	case 45:
																																	case 100:
																																		goto IL_059e;
																																	case 6:
																																		goto IL_05a9;
																																	case 26:
																																		goto IL_05b6;
																																	case 10:
																																	case 44:
																																		goto IL_05c1;
																																	case 9:
																																	case 27:
																																	case 30:
																																	case 33:
																																	case 36:
																																	case 39:
																																	case 42:
																																	case 55:
																																	case 56:
																																	case 70:
																																	case 71:
																																	case 72:
																																	case 75:
																																	case 76:
																																	case 81:
																																	case 82:
																																	case 91:
																																	case 95:
																																	case 97:
																																	case 102:
																																	case 103:
																																	case 107:
																																		goto end_IL_0240;
																																	case 0:
																																	case 2:
																																	case 4:
																																	case 5:
																																	case 23:
																																	case 35:
																																	case 38:
																																	case 57:
																																	case 62:
																																	case 84:
																																	case 88:
																																	case 94:
																																	case 106:
																																		goto end_IL_02cd;
																																	case 47:
																																		goto end_IL_05f6;
																																	case 80:
																																		goto end_IL_0609;
																																	case 83:
																																		goto end_IL_0613;
																																	case 40:
																																		goto end_IL_061e;
																																	case 22:
																																	case 29:
																																		goto end_IL_0633;
																																	case 69:
																																		goto end_IL_0643;
																																	case 7:
																																	case 93:
																																		goto end_IL_0653;
																																	case 64:
																																		goto end_IL_0663;
																																	case 65:
																																		goto end_IL_0673;
																																	case 21:
																																	case 108:
																																		goto IL_0697;
																																	}
																																	continue;
																																}
																																ptr2 += 8;
																																goto end_IL_02cd;
																																continue;
																																end_IL_01e9:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_03a9;
																												continue;
																												end_IL_0240:
																												break;
																												IL_0240:;
																											}
																											break;
																											IL_0250:;
																										}
																										break;
																									}
																									goto IL_035f;
																									IL_0396:
																									num5--;
																									goto end_IL_02cd;
																									IL_035f:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0388;
																									IL_0388:
																									ptr2 += 8;
																									goto IL_0396;
																								}
																								break;
																							}
																							goto IL_02e6;
																							IL_032b:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_0339;
																							IL_02e6:
																							if (3 >= b)
																							{
																								goto IL_02f1;
																							}
																							goto IL_032b;
																							IL_02f1:
																							if (3 > b)
																							{
																								num = 75;
																								break;
																							}
																							goto IL_030a;
																							IL_0339:
																							if (4 <= b)
																							{
																								goto end_IL_02cd;
																							}
																							break;
																							IL_030a:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 4;
																							goto end_IL_02cd;
																						}
																						break;
																					}
																					goto IL_03a9;
																					IL_03fb:
																					ptr2 += 8;
																					goto end_IL_02cd;
																					IL_03a9:
																					array[num5] = 0;
																					num = 17;
																					goto IL_03c0;
																					IL_03c0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03e3;
																					IL_03e3:
																					array2[num5] = null;
																					goto IL_03ed;
																					IL_03ed:
																					num5++;
																					goto IL_03fb;
																				}
																				break;
																			}
																			goto IL_040e;
																			IL_05c1:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02cd;
																			IL_040e:
																			if (8 >= b)
																			{
																				goto IL_041c;
																			}
																			goto IL_0593;
																			IL_041c:
																			if (8 > b)
																			{
																				goto IL_042a;
																			}
																			goto IL_0518;
																			IL_042a:
																			if (6 < b)
																			{
																				goto IL_0435;
																			}
																			goto IL_04a3;
																			IL_0435:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0443;
																			IL_0443:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0451;
																			IL_0451:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0474;
																			IL_0474:
																			array[num5] = 0;
																			goto IL_0482;
																			IL_0482:
																			num5++;
																			goto IL_0490;
																			IL_0490:
																			ptr2 += 8;
																			goto end_IL_02cd;
																			IL_04a3:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_04b1;
																			IL_04b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04f1;
																			IL_04f1:
																			array[num5 - 2] = 0;
																			goto IL_0505;
																			IL_0505:
																			num5--;
																			goto end_IL_02cd;
																			IL_0518:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 86;
																			goto IL_0583;
																			IL_0583:
																			num5 -= 2;
																			goto end_IL_02cd;
																			IL_0593:
																			if (9 < b)
																			{
																				goto IL_059e;
																			}
																			goto IL_05b6;
																			IL_059e:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_05a9;
																			IL_05a9:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_05b6:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_05c1;
																		}
																		break;
																		IL_029d:;
																	}
																}
																else
																{
																	num = 30;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 94;
																goto end_IL_02cd;
																continue;
																end_IL_02b0:
																break;
															}
															continue;
															end_IL_02bd:
															break;
														}
														continue;
														end_IL_02cd:
														break;
													}
													continue;
												}
												goto IL_0697;
												IL_0697:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f6:
												break;
											}
											continue;
											end_IL_0609:
											break;
										}
										continue;
										end_IL_0613:
										break;
									}
									continue;
									end_IL_061e:
									break;
								}
								continue;
								end_IL_0633:
								break;
							}
							continue;
							end_IL_0643:
							break;
						}
						continue;
						end_IL_0653:
						break;
					}
					continue;
					end_IL_0663:
					break;
				}
				continue;
				end_IL_0673:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_5, int int_6)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 38;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											array3[1] = int_6;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EndReadCachePathValue.TargetFrameworkIdDenySetInstance);
												num = 28;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 93;
																	while (true)
																	{
																		if (num != 93)
																		{
																			if (num != 1074)
																			{
																				goto IL_01fd;
																			}
																			switch (num)
																			{
																			case 72:
																				goto end_IL_0183;
																			case 36:
																			case 71:
																				goto end_IL_0193;
																			case 4:
																				goto IL_01c5;
																			case 81:
																				goto IL_01d3;
																			case 29:
																				goto IL_01e1;
																			case 33:
																			case 59:
																				goto IL_01ef;
																			case 61:
																				goto IL_01fd;
																			case 20:
																				goto IL_0208;
																			case 13:
																				goto IL_0216;
																			case 3:
																			case 7:
																				goto IL_0229;
																			case 84:
																				goto IL_02a0;
																			case 2:
																				goto IL_02b3;
																			case 51:
																				goto IL_02c1;
																			case 40:
																			case 41:
																				goto IL_02cf;
																			case 77:
																				goto IL_030f;
																			case 18:
																				goto IL_0323;
																			case 5:
																			case 69:
																				goto IL_0336;
																			case 53:
																				goto IL_035f;
																			case 31:
																				goto IL_036d;
																			case 35:
																				goto IL_0380;
																			case 30:
																			case 78:
																				goto IL_038e;
																			case 42:
																			case 66:
																				goto IL_0399;
																			case 21:
																				goto IL_03a7;
																			case 17:
																			case 68:
																				goto IL_03b5;
																			case 76:
																				goto IL_03d1;
																			case 27:
																			case 32:
																				goto IL_03e8;
																			case 10:
																				goto IL_03f6;
																			case 46:
																				goto IL_0419;
																			case 19:
																				goto IL_0423;
																			case 15:
																				goto IL_0431;
																			case 67:
																				goto IL_0444;
																			case 12:
																				goto IL_044f;
																			case 86:
																				goto IL_045a;
																			case 44:
																			case 75:
																				goto IL_0465;
																			case 1:
																			case 6:
																			case 9:
																			case 11:
																			case 16:
																			case 22:
																			case 25:
																			case 37:
																			case 39:
																			case 43:
																			case 49:
																			case 56:
																			case 65:
																			case 79:
																			case 85:
																				goto IL_047a;
																			case 34:
																				goto IL_049d;
																			case 50:
																				goto IL_04ab;
																			case 0:
																				goto IL_04b9;
																			case 8:
																			case 14:
																			case 23:
																			case 24:
																			case 55:
																			case 58:
																			case 60:
																			case 70:
																			case 74:
																			case 80:
																			case 83:
																				goto end_IL_01ac;
																			case 28:
																				goto end_IL_04c7;
																			case 52:
																				goto end_IL_04da;
																			case 48:
																				goto end_IL_04e4;
																			case 57:
																				goto end_IL_04f8;
																			case 54:
																				goto end_IL_050d;
																			case 26:
																			case 45:
																				goto end_IL_0522;
																			case 73:
																				goto end_IL_0532;
																			case 38:
																				goto end_IL_0542;
																			case 47:
																				goto end_IL_0552;
																			case 63:
																				goto end_IL_0562;
																			case 64:
																				goto end_IL_056d;
																			case 62:
																			case 82:
																				goto IL_0588;
																			}
																			continue;
																		}
																		if (b >= 1)
																		{
																			goto IL_01c5;
																		}
																		goto IL_047a;
																		IL_047a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_049d;
																		IL_04ab:
																		num5++;
																		goto IL_04b9;
																		IL_049d:
																		array[num5] = 0;
																		goto IL_04ab;
																		IL_01c5:
																		if (b <= 8)
																		{
																			goto IL_01d3;
																		}
																		goto IL_047a;
																		IL_01d3:
																		if (4 >= b)
																		{
																			goto IL_01e1;
																		}
																		goto IL_0380;
																		IL_01e1:
																		if (4 > b)
																		{
																			goto IL_01ef;
																		}
																		goto IL_0336;
																		IL_01ef:
																		if (2 >= b)
																		{
																			goto IL_01fd;
																		}
																		goto IL_02b3;
																		IL_01fd:
																		if (2 > b)
																		{
																			goto IL_0208;
																		}
																		goto IL_0229;
																		IL_0208:
																		if (1 >= b)
																		{
																			goto IL_0216;
																		}
																		goto IL_047a;
																		IL_0216:
																		if (1 > b)
																		{
																		}
																		goto IL_047a;
																		IL_0229:
																		ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		num = 84;
																		goto IL_02a0;
																		IL_02a0:
																		num5 -= 2;
																		goto end_IL_01ac;
																		IL_02b3:
																		if (3 >= b)
																		{
																			goto IL_02c1;
																		}
																		goto IL_047a;
																		IL_02c1:
																		if (3 <= b)
																		{
																			goto IL_02cf;
																		}
																		goto IL_047a;
																		IL_02cf:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_030f;
																		IL_030f:
																		array[num5 - 2] = 0;
																		goto IL_0323;
																		IL_0323:
																		num5--;
																		goto end_IL_01ac;
																		IL_0336:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_035f;
																		IL_035f:
																		ptr2 += 8;
																		goto IL_036d;
																		IL_036d:
																		num5--;
																		goto end_IL_01ac;
																		IL_0380:
																		if (6 < b)
																		{
																			goto IL_038e;
																		}
																		goto IL_0444;
																		IL_038e:
																		if (7 < b)
																		{
																			goto IL_0399;
																		}
																		goto IL_03d1;
																		IL_0399:
																		if (8 >= b)
																		{
																			goto IL_03a7;
																		}
																		goto IL_047a;
																		IL_03a7:
																		if (8 <= b)
																		{
																			goto IL_03b5;
																		}
																		goto IL_047a;
																		IL_03b5:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_01ac;
																		IL_03d1:
																		if (7 <= b)
																		{
																			num = 32;
																			goto IL_03e8;
																		}
																		goto IL_047a;
																		IL_04b9:
																		ptr2 += 8;
																		goto end_IL_01ac;
																		IL_03e8:
																		array[num5] = 0;
																		goto IL_03f6;
																		IL_03f6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0419;
																		IL_0419:
																		array2[num5] = null;
																		goto IL_0423;
																		IL_0423:
																		num5++;
																		goto IL_0431;
																		IL_0431:
																		ptr2 += 8;
																		goto end_IL_01ac;
																		IL_0444:
																		if (6 <= b)
																		{
																			goto end_IL_01ac;
																		}
																		goto IL_044f;
																		IL_044f:
																		if (5 >= b)
																		{
																			goto IL_045a;
																		}
																		goto IL_047a;
																		IL_045a:
																		if (5 <= b)
																		{
																			goto IL_0465;
																		}
																		goto IL_047a;
																		IL_0465:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_01ac;
																		continue;
																		end_IL_0183:
																		break;
																	}
																	continue;
																	end_IL_0193:
																	break;
																}
																continue;
																end_IL_01ac:
																break;
															}
															continue;
														}
														goto IL_0588;
														IL_0588:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04c7:
														break;
													}
													continue;
													end_IL_04da:
													break;
												}
												continue;
												end_IL_04e4:
												break;
											}
											continue;
											end_IL_04f8:
											break;
										}
										continue;
										end_IL_050d:
										break;
									}
									continue;
									end_IL_0522:
									break;
								}
								continue;
								end_IL_0532:
								break;
							}
							continue;
							end_IL_0542:
							break;
						}
						continue;
						end_IL_0552:
						break;
					}
					continue;
					end_IL_0562:
					break;
				}
				continue;
				end_IL_056d:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_5, int int_6)
	{
		int num = 13;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SpinOnceGetTypeFromProgID.AsyncLocalEndThreadAffinity);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0218:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01f8:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01e8:
																						if (4 <= b)
																						{
																							num = 33;
																							while (true)
																							{
																								IL_01bd:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								while (true)
																								{
																									IL_01a4:
																									ptr2 += 8;
																									num = 93;
																									while (true)
																									{
																										if (num != 93)
																										{
																											if (num != 1074)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 44:
																												goto IL_01a4;
																											case 10:
																											case 33:
																												goto IL_01bd;
																											case 43:
																												goto IL_01e8;
																											case 74:
																												goto IL_01f8;
																											case 77:
																												goto IL_0208;
																											case 22:
																												goto IL_0218;
																											case 45:
																												goto end_IL_0218;
																											case 31:
																											case 75:
																												goto end_IL_0228;
																											case 1:
																												goto IL_0243;
																											case 23:
																												goto IL_0251;
																											case 15:
																											case 26:
																												goto IL_025f;
																											case 9:
																											case 27:
																												goto IL_02d2;
																											case 37:
																												goto IL_02e0;
																											case 5:
																											case 65:
																												goto IL_02ee;
																											case 66:
																												goto IL_032e;
																											case 76:
																												goto IL_034d;
																											case 78:
																												goto IL_035b;
																											case 83:
																												goto IL_036e;
																											case 85:
																												goto IL_0381;
																											case 84:
																												goto IL_03a7;
																											case 51:
																											case 72:
																												goto IL_03b5;
																											case 39:
																												goto IL_03c0;
																											case 68:
																												goto IL_03ce;
																											case 53:
																											case 56:
																												goto IL_03dc;
																											case 4:
																												goto IL_03f8;
																											case 35:
																											case 70:
																												goto IL_0406;
																											case 29:
																												goto IL_041d;
																											case 60:
																												goto IL_0440;
																											case 8:
																												goto IL_0453;
																											case 57:
																												goto IL_0461;
																											case 67:
																												goto IL_0474;
																											case 20:
																												goto IL_0482;
																											case 46:
																												goto IL_048d;
																											case 42:
																											case 64:
																												goto IL_0498;
																											case 3:
																											case 11:
																											case 16:
																											case 19:
																											case 28:
																											case 36:
																											case 38:
																											case 40:
																											case 47:
																											case 61:
																											case 62:
																											case 69:
																											case 71:
																											case 73:
																											case 79:
																											case 86:
																												goto end_IL_0191;
																											case 59:
																												goto IL_04ed;
																											case 54:
																												goto IL_04fb;
																											case 24:
																												goto IL_0509;
																											case 14:
																											case 18:
																											case 25:
																											case 34:
																											case 41:
																											case 49:
																											case 50:
																											case 58:
																											case 63:
																											case 80:
																											case 82:
																												goto end_IL_0238;
																											case 7:
																												goto end_IL_0520;
																											case 21:
																												goto end_IL_0533;
																											case 55:
																												goto end_IL_053d;
																											case 2:
																												goto end_IL_0548;
																											case 52:
																												goto end_IL_055d;
																											case 30:
																											case 81:
																												goto end_IL_0572;
																											case 17:
																												goto end_IL_0582;
																											case 32:
																											case 48:
																												goto end_IL_0592;
																											case 12:
																												goto end_IL_05a2;
																											case 13:
																												goto end_IL_05b2;
																											case 0:
																											case 6:
																												goto IL_05cd;
																											}
																											continue;
																										}
																										num5--;
																										goto end_IL_0238;
																										continue;
																										end_IL_0191:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0243;
																						IL_032e:
																						array[num5 - 2] = 0;
																						num = 83;
																						goto IL_036e;
																						IL_036e:
																						num5--;
																						goto end_IL_0238;
																						IL_0243:
																						if (2 >= b)
																						{
																							goto IL_0251;
																						}
																						goto IL_02d2;
																						IL_0251:
																						if (2 <= b)
																						{
																							goto IL_025f;
																						}
																						goto IL_034d;
																						IL_025f:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0381;
																						IL_0381:
																						num5 -= 2;
																						goto end_IL_0238;
																						IL_034d:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_035b;
																						IL_035b:
																						if (1 > b)
																						{
																						}
																						break;
																						IL_02d2:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_02e0;
																						IL_02e0:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_02ee;
																						IL_02ee:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_032e;
																					}
																					break;
																				}
																				goto IL_03a7;
																				IL_0498:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0238;
																				IL_03a7:
																				if (6 < b)
																				{
																					goto IL_03b5;
																				}
																				goto IL_0474;
																				IL_03b5:
																				if (7 < b)
																				{
																					goto IL_03c0;
																				}
																				goto IL_03f8;
																				IL_03c0:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03ce;
																				IL_03ce:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03dc;
																				IL_03dc:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0238;
																				IL_03f8:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0406;
																				IL_0406:
																				array[num5] = 0;
																				num = 29;
																				goto IL_041d;
																				IL_041d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0440;
																				IL_0440:
																				array2[num5] = null;
																				num = 8;
																				goto IL_0453;
																				IL_0453:
																				num5++;
																				goto IL_0461;
																				IL_0461:
																				ptr2 += 8;
																				goto end_IL_0238;
																				IL_0474:
																				if (6 <= b)
																				{
																					goto end_IL_0238;
																				}
																				goto IL_0482;
																				IL_0482:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_048d;
																				IL_048d:
																				if (5 > b)
																				{
																					num = 19;
																					break;
																				}
																				goto IL_0498;
																			}
																			break;
																			IL_0208:;
																		}
																	}
																	else
																	{
																		num = 40;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 59;
																	goto IL_04ed;
																	IL_04fb:
																	num5++;
																	goto IL_0509;
																	IL_0509:
																	ptr2 += 8;
																	num = 82;
																	goto end_IL_0238;
																	IL_04ed:
																	array[num5] = 0;
																	goto IL_04fb;
																	continue;
																	end_IL_0218:
																	break;
																}
																continue;
																end_IL_0228:
																break;
															}
															continue;
															end_IL_0238:
															break;
														}
														continue;
													}
													goto IL_05cd;
													IL_05cd:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0520:
													break;
												}
												continue;
												end_IL_0533:
												break;
											}
											continue;
											end_IL_053d:
											break;
										}
										continue;
										end_IL_0548:
										break;
									}
									continue;
									end_IL_055d:
									break;
								}
								continue;
								end_IL_0572:
								break;
							}
							continue;
							end_IL_0582:
							break;
						}
						continue;
						end_IL_0592:
						break;
					}
					continue;
					end_IL_05a2:
					break;
				}
				continue;
				end_IL_05b2:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_5, int int_6)
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAssemblyQualifiedNameCreatePermissionSet.getRandomlyGeneratedGetOrderablePartitions);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_04e8:
													if (num4 != 1)
													{
														goto IL_000e;
													}
													num = 96;
													while (true)
													{
														if (num != 96)
														{
															if (num != 1077)
															{
																break;
															}
															switch (num)
															{
															case 29:
															case 77:
																break;
															case 52:
																goto end_IL_04d5;
															case 84:
																goto IL_0025;
															case 3:
																goto IL_0033;
															case 48:
																goto IL_0041;
															case 1:
																goto IL_004f;
															case 66:
															case 69:
																goto IL_005a;
															case 6:
																goto IL_0083;
															case 0:
																goto IL_0091;
															case 41:
																goto IL_00a4;
															case 67:
																goto IL_00b2;
															case 43:
																goto IL_00c0;
															case 35:
															case 70:
																goto IL_00ce;
															case 53:
																goto IL_010e;
															case 46:
																goto IL_0122;
															case 26:
																goto IL_013e;
															case 16:
															case 45:
																goto IL_0149;
															case 59:
																goto IL_0157;
															case 8:
															case 54:
																goto IL_016a;
															case 75:
																goto IL_01d8;
															case 17:
															case 74:
																goto IL_01f4;
															case 21:
																goto IL_01ff;
															case 86:
																goto IL_020d;
															case 38:
																goto IL_021b;
															case 20:
															case 55:
																goto IL_0229;
															case 73:
																goto IL_024a;
															case 51:
															case 89:
																goto IL_0255;
															case 28:
																goto IL_0263;
															case 30:
															case 36:
																goto IL_0271;
															case 37:
																goto IL_028d;
															case 44:
															case 88:
																goto IL_0298;
															case 79:
																goto IL_02a6;
															case 85:
																goto IL_02c9;
															case 61:
																goto IL_02d3;
															case 56:
																goto IL_02e1;
															case 2:
															case 5:
															case 9:
															case 13:
															case 19:
															case 22:
															case 23:
															case 32:
															case 50:
															case 60:
															case 62:
															case 63:
															case 64:
															case 65:
															case 68:
															case 72:
															case 81:
															case 82:
																goto IL_02f4;
															case 25:
																goto IL_0317;
															case 24:
																goto IL_0325;
															case 49:
																goto IL_0333;
															default:
																continue;
															case 10:
															case 11:
															case 14:
															case 27:
															case 42:
															case 57:
															case 71:
															case 78:
															case 80:
															case 83:
															case 87:
																goto IL_04e8;
															case 15:
																goto end_IL_04e8;
															case 34:
																goto end_IL_04fb;
															case 58:
																goto end_IL_0505;
															case 31:
																goto end_IL_0510;
															case 18:
																goto end_IL_0525;
															case 4:
															case 47:
																goto end_IL_053a;
															case 76:
																goto end_IL_054a;
															case 12:
															case 33:
																goto end_IL_055a;
															case 39:
																goto end_IL_056a;
															case 40:
																goto end_IL_057a;
															case 7:
																goto IL_0595;
															}
															goto IL_000e;
														}
														goto IL_0595;
														IL_0595:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04d5:
														break;
													}
													goto IL_0017;
													IL_02f4:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0317;
													IL_0317:
													array[num5] = 0;
													goto IL_0325;
													IL_000e:
													b = *ptr2;
													goto IL_0017;
													IL_0017:
													ptr2++;
													goto IL_0025;
													IL_0025:
													if (b >= 1)
													{
														goto IL_0033;
													}
													goto IL_02f4;
													IL_0033:
													if (b <= 8)
													{
														goto IL_0041;
													}
													goto IL_02f4;
													IL_0041:
													if (4 >= b)
													{
														goto IL_004f;
													}
													num = 74;
													goto IL_01f4;
													IL_004f:
													if (4 <= b)
													{
														goto IL_005a;
													}
													goto IL_00a4;
													IL_005a:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_0083;
													IL_0083:
													ptr2 += 8;
													goto IL_0091;
													IL_0091:
													num5--;
													continue;
													IL_00a4:
													if (2 < b)
													{
														goto IL_00b2;
													}
													num = 26;
													goto IL_013e;
													IL_00b2:
													if (3 >= b)
													{
														goto IL_00c0;
													}
													goto IL_02f4;
													IL_00c0:
													if (3 <= b)
													{
														goto IL_00ce;
													}
													goto IL_02f4;
													IL_00ce:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													goto IL_010e;
													IL_010e:
													array[num5 - 2] = 0;
													goto IL_0122;
													IL_0122:
													num5--;
													continue;
													IL_0333:
													ptr2 += 8;
													continue;
													IL_013e:
													if (2 > b)
													{
														goto IL_0149;
													}
													goto IL_016a;
													IL_0149:
													if (1 >= b)
													{
														goto IL_0157;
													}
													goto IL_02f4;
													IL_0157:
													if (1 <= b)
													{
													}
													goto IL_02f4;
													IL_016a:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_01d8;
													IL_01d8:
													num5 -= 2;
													continue;
													IL_0325:
													num5++;
													goto IL_0333;
													IL_01f4:
													if (6 >= b)
													{
														goto IL_01ff;
													}
													goto IL_024a;
													IL_01ff:
													if (6 <= b)
													{
														continue;
													}
													goto IL_020d;
													IL_020d:
													if (5 >= b)
													{
														goto IL_021b;
													}
													goto IL_02f4;
													IL_021b:
													if (5 <= b)
													{
														goto IL_0229;
													}
													goto IL_02f4;
													IL_0229:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													num = 11;
													continue;
													IL_024a:
													if (7 < b)
													{
														goto IL_0255;
													}
													goto IL_028d;
													IL_0255:
													if (8 >= b)
													{
														goto IL_0263;
													}
													goto IL_02f4;
													IL_0263:
													if (8 <= b)
													{
														goto IL_0271;
													}
													goto IL_02f4;
													IL_0271:
													byte* num6 = ptr2;
													num4 = 1;
													ptr2 = num6 + -200;
													continue;
													IL_028d:
													if (7 <= b)
													{
														goto IL_0298;
													}
													goto IL_02f4;
													IL_0298:
													array[num5] = 0;
													goto IL_02a6;
													IL_02a6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
													goto IL_02c9;
													IL_02c9:
													array2[num5] = null;
													goto IL_02d3;
													IL_02d3:
													num5++;
													goto IL_02e1;
													IL_02e1:
													ptr2 += 8;
													continue;
													end_IL_04e8:
													break;
												}
												continue;
												end_IL_04fb:
												break;
											}
											continue;
											end_IL_0505:
											break;
										}
										continue;
										end_IL_0510:
										break;
									}
									continue;
									end_IL_0525:
									break;
								}
								continue;
								end_IL_053a:
								break;
							}
							continue;
							end_IL_054a:
							break;
						}
						continue;
						end_IL_055a:
						break;
					}
					continue;
					end_IL_056a:
					break;
				}
				continue;
				end_IL_057a:
				break;
			}
		}
	}

	static Class112()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 5:
								goto IL_0046;
							case 1:
								goto end_IL_0039;
							case 2:
								goto end_IL_0052;
							case 0:
								return;
							case 3:
								return;
							case 4:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				continue;
				end_IL_0052:
				break;
			}
		}
	}
}
