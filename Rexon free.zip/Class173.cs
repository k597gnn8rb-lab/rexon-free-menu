using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;

[Mod("Back Track Delay: 0.50", "Rig", "Triggers (VR) / Click (PC) to adjust.", false, 31, ModType.const_0, false)]
internal class Class173 : MonoBehaviour
{
	private static float[] float_0;

	private static int int_0;

	private float float_1;

	private float float_2;

	private static int int_1;

	private static int int_2;

	private static double double_0;

	private static double double_1;

	private static IntPtr[] getHasCurrentExport;

	private static IntPtr[] TokenRestrictedDeviceClaimAttributesSpinWait;

	private static IntPtr[] CreateConstructionReturnMessageObjectWithMapTyped;

	private static IntPtr[] SetCreationTimeIsClosed;

	private static IntPtr[] AddChannelEventCacheEntry;

	private static IntPtr[] IsClosedActor;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_055d, IL_0570, IL_059f, IL_05c8, IL_05e2, IL_05f2, IL_0605, IL_0615, IL_0625, IL_0632, IL_0642, IL_0652, IL_0662, IL_0672, IL_0682, IL_0692, IL_069d, IL_06a8, IL_06b6, IL_06c9, IL_06f2, IL_070b, IL_0719, IL_0724, IL_0732, IL_0740, IL_074e, IL_075c, IL_076a, IL_0778, IL_0795, IL_07e4, IL_07ee, IL_081b, IL_082f, IL_0846, IL_0859, IL_0867, IL_0875, IL_087e, IL_089c, IL_08aa, IL_08bd, IL_08c8, IL_08db, IL_08e9, IL_08f7, IL_0937, IL_094b, IL_095e, IL_096c, IL_0989, IL_099c, IL_09aa, IL_09bd, IL_09cb, IL_09d9, IL_09e7, IL_09f5, IL_0a03, IL_0a11, IL_0a55, IL_0a69, IL_0a7c, IL_0a8a, IL_0a98, IL_0aab, IL_0ab9, IL_0ac7, IL_0ad2, IL_0ae0, IL_0afe, IL_0b0c, IL_0b1a, IL_0b2d, IL_0b3b, IL_0b49, IL_0b57, IL_0b65, IL_0b73, IL_0b81, IL_0bdf, IL_0bf2, IL_0c1f, IL_0c2d, IL_0c44, IL_0c57, IL_0c82, IL_0c9b, IL_0ca9, IL_0cc1, IL_0ccf, IL_0cdd, IL_0ce8, IL_0cf6, IL_0d24, IL_0d37, IL_0d4a, IL_0d58, IL_0d66, IL_0d7a, IL_0db9, IL_0dcc, IL_0dda, IL_0de8, IL_0df3, IL_0e01, IL_0e2a, IL_0e38, IL_0e4b, IL_0e59, IL_0e6c, IL_0e7f, IL_0ea9, IL_0ec2, IL_0ed0, IL_0eec, IL_0efa, IL_0f0d, IL_0f52, IL_0f97, IL_0fe0, IL_0ff4, IL_1007, IL_1050, IL_1064, IL_1077, IL_1094, IL_10a7, IL_10b5, IL_10c8, IL_10f0, IL_1104, IL_1117, IL_1179, IL_118c, IL_1197, IL_11c0, IL_11ce, IL_11e1, IL_11ef, IL_11fd, IL_120b, IL_1219, IL_122d, IL_12ab, IL_12b9, IL_12cc, IL_12e9, IL_1335, IL_1343, IL_1356, IL_1361, IL_136f, IL_137d, IL_1395, IL_13a3, IL_13b1, IL_13c4, IL_13d2, IL_13fb, IL_1409, IL_1425, IL_1430, IL_1470, IL_1484, IL_1497, IL_14a5, IL_14b3, IL_14cc, IL_14da, IL_14e8, IL_14fb, IL_1509, IL_152c, IL_153f, IL_154d, IL_1560, IL_156b, IL_158f, IL_159d, IL_15ab, IL_15be, IL_15cc, IL_15da, IL_15f6, IL_1609, IL_1623, IL_1636, IL_164e, IL_1661, IL_166c, IL_167a, IL_16b8, IL_16d4, IL_16e2, IL_16f0, IL_1704, IL_173c, IL_174c, IL_175a, IL_1787, IL_1795, IL_17a5, IL_17b8, IL_17cb, IL_17d5, IL_17e0, IL_17f0, IL_1800, IL_1810, IL_1820, IL_1830, IL_1840, IL_1850, IL_1860 are reachable both inside and outside the pinned region starting at IL_1875. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 139;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num6;
			byte* num7;
			int __rxRef77 = default(int);
			ref int reference = ref __rxRef77;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1860:
					num2 = 1;
					while (true)
					{
						IL_1850:
						num3 = num2 * 4;
						while (true)
						{
							IL_1840:
							array2 = new byte[4];
							while (true)
							{
								IL_1830:
								array3 = new object[4];
								while (true)
								{
									IL_1820:
									array4 = new int[4];
									while (true)
									{
										IL_1810:
										array5 = new int[6];
										while (true)
										{
											IL_1800:
											array6 = new long[4];
											while (true)
											{
												IL_17f0:
												array7 = new object[17];
												while (true)
												{
													IL_17e0:
													array7[0] = this;
													while (true)
													{
														IL_17d5:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IPermissionSetEntryChannelName.getCurrentManagedThreadIdsetRole);
														while (true)
														{
															IL_17cb:
															ptr2 = ptr;
															while (true)
															{
																IL_17b8:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0692:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0682:
																		ptr2++;
																		while (true)
																		{
																			IL_0672:
																			if (b >= 1)
																			{
																				while (b <= 39)
																				{
																					while (true)
																					{
																						IL_0652:
																						if (20 >= b)
																						{
																							while (true)
																							{
																								IL_0642:
																								if (20 > b)
																								{
																									while (true)
																									{
																										IL_0632:
																										if (10 < b)
																										{
																											while (true)
																											{
																												IL_0625:
																												if (15 < b)
																												{
																													while (true)
																													{
																														IL_0615:
																														if (17 >= b)
																														{
																															while (true)
																															{
																																IL_0605:
																																if (17 > b)
																																{
																																	while (16 >= b)
																																	{
																																		num = 74;
																																		while (16 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_05c8:
																																				array2[num5] = array2[num5 - 1];
																																				while (true)
																																				{
																																					IL_059f:
																																					array4[num5 - 0] = array4[num5 - 1];
																																					num = 61;
																																					while (true)
																																					{
																																						IL_0570:
																																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																						num = 336;
																																						while (true)
																																						{
																																							if (num != 336)
																																							{
																																								if (num != 1317)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 139:
																																									break;
																																								default:
																																									continue;
																																								case 61:
																																									goto IL_0570;
																																								case 314:
																																									goto IL_059f;
																																								case 18:
																																								case 229:
																																									goto IL_05c8;
																																								case 74:
																																									goto IL_05e2;
																																								case 172:
																																									goto IL_05f2;
																																								case 219:
																																									goto IL_0605;
																																								case 276:
																																									goto IL_0615;
																																								case 273:
																																									goto IL_0625;
																																								case 170:
																																									goto IL_0632;
																																								case 196:
																																									goto IL_0642;
																																								case 77:
																																									goto IL_0652;
																																								case 3:
																																									goto IL_0662;
																																								case 181:
																																									goto IL_0672;
																																								case 40:
																																									goto IL_0682;
																																								case 163:
																																								case 318:
																																									goto IL_0692;
																																								case 194:
																																									goto IL_069d;
																																								case 25:
																																									goto IL_06a8;
																																								case 68:
																																									goto IL_06b6;
																																								case 39:
																																								case 202:
																																									goto IL_06c9;
																																								case 99:
																																									goto IL_06f2;
																																								case 237:
																																									goto IL_070b;
																																								case 60:
																																									goto IL_0719;
																																								case 191:
																																									goto IL_0724;
																																								case 38:
																																									goto IL_0732;
																																								case 256:
																																									goto IL_075c;
																																								case 44:
																																									goto IL_076a;
																																								case 176:
																																								case 253:
																																									goto IL_0778;
																																								case 175:
																																									goto IL_082f;
																																								case 238:
																																									goto IL_0846;
																																								case 182:
																																									goto IL_0859;
																																								case 37:
																																									goto IL_0867;
																																								case 230:
																																								case 261:
																																									goto IL_087e;
																																								case 114:
																																									goto IL_089c;
																																								case 90:
																																									goto IL_08aa;
																																								case 270:
																																									goto IL_08bd;
																																								case 197:
																																									goto IL_08c8;
																																								case 167:
																																									goto IL_08db;
																																								case 277:
																																									goto IL_08e9;
																																								case 217:
																																								case 265:
																																									goto IL_08f7;
																																								case 263:
																																									goto IL_0937;
																																								case 78:
																																									goto IL_094b;
																																								case 140:
																																								case 278:
																																									goto IL_095e;
																																								case 89:
																																									goto IL_096c;
																																								case 155:
																																								case 280:
																																									goto IL_0989;
																																								case 281:
																																									goto IL_099c;
																																								case 136:
																																									goto IL_09aa;
																																								case 284:
																																									goto IL_09bd;
																																								case 17:
																																									goto IL_09cb;
																																								case 109:
																																									goto IL_09d9;
																																								case 10:
																																									goto IL_09e7;
																																								case 154:
																																									goto IL_09f5;
																																								case 166:
																																									goto IL_0a03;
																																								case 57:
																																								case 251:
																																									goto IL_0a11;
																																								case 272:
																																									goto IL_0a55;
																																								case 36:
																																									goto IL_0a69;
																																								case 71:
																																									goto IL_0a7c;
																																								case 86:
																																									goto IL_0a8a;
																																								case 257:
																																									goto IL_0a98;
																																								case 168:
																																									goto IL_0aab;
																																								case 67:
																																									goto IL_0ab9;
																																								case 53:
																																									goto IL_0ac7;
																																								case 11:
																																									goto IL_0ad2;
																																								case 145:
																																								case 177:
																																									goto IL_0ae0;
																																								case 65:
																																									goto IL_0afe;
																																								case 204:
																																									goto IL_0b0c;
																																								case 221:
																																									goto IL_0b1a;
																																								case 184:
																																									goto IL_0b2d;
																																								case 94:
																																									goto IL_0b3b;
																																								case 180:
																																									goto IL_0b57;
																																								case 64:
																																									goto IL_0b65;
																																								case 19:
																																									goto IL_0b73;
																																								case 42:
																																								case 255:
																																									goto IL_0b81;
																																								case 142:
																																									goto IL_0bdf;
																																								case 243:
																																								case 271:
																																									goto IL_0bf2;
																																								case 62:
																																									goto IL_0c1f;
																																								case 92:
																																									goto IL_0c2d;
																																								case 55:
																																									goto IL_0c44;
																																								case 133:
																																								case 249:
																																									goto IL_0c57;
																																								case 186:
																																									goto IL_0c82;
																																								case 108:
																																								case 200:
																																									goto IL_0c9b;
																																								case 52:
																																									goto IL_0ca9;
																																								case 75:
																																									goto IL_0cc1;
																																								case 224:
																																									goto IL_0ccf;
																																								case 169:
																																									goto IL_0cdd;
																																								case 216:
																																									goto IL_0ce8;
																																								case 134:
																																								case 245:
																																									goto IL_0cf6;
																																								case 104:
																																									goto IL_0d24;
																																								case 218:
																																									goto IL_0d37;
																																								case 285:
																																									goto IL_0d4a;
																																								case 21:
																																									goto IL_0d58;
																																								case 49:
																																								case 128:
																																									goto IL_0d66;
																																								case 26:
																																									goto IL_0d7a;
																																								case 157:
																																									goto IL_0db9;
																																								case 289:
																																									goto IL_0dcc;
																																								case 16:
																																									goto IL_0dda;
																																								case 171:
																																									goto IL_0de8;
																																								case 24:
																																									goto IL_0df3;
																																								case 66:
																																								case 274:
																																									goto IL_0e01;
																																								case 72:
																																									goto IL_0e2a;
																																								case 266:
																																									goto IL_0e38;
																																								case 115:
																																									goto IL_0e4b;
																																								case 31:
																																									goto IL_0e59;
																																								case 290:
																																									goto IL_0e6c;
																																								case 143:
																																								case 295:
																																									goto IL_0e7f;
																																								case 98:
																																									goto IL_0ea9;
																																								case 296:
																																									goto IL_0ec2;
																																								case 164:
																																									goto IL_0ed0;
																																								case 297:
																																									goto IL_0eec;
																																								case 225:
																																									goto IL_0efa;
																																								case 27:
																																								case 298:
																																									goto IL_0f0d;
																																								case 97:
																																								case 299:
																																									goto IL_0f52;
																																								case 32:
																																								case 301:
																																									goto IL_0f97;
																																								case 132:
																																									goto IL_0fe0;
																																								case 208:
																																									goto IL_0ff4;
																																								case 258:
																																								case 302:
																																									goto IL_1007;
																																								case 179:
																																									goto IL_1050;
																																								case 162:
																																									goto IL_1064;
																																								case 306:
																																									goto IL_1077;
																																								case 110:
																																									goto IL_1094;
																																								case 308:
																																									goto IL_10a7;
																																								case 50:
																																									goto IL_10b5;
																																								case 193:
																																								case 313:
																																									goto IL_10c8;
																																								case 315:
																																									goto IL_10f0;
																																								case 248:
																																									goto IL_1104;
																																								case 222:
																																								case 316:
																																									goto IL_1117;
																																								case 2:
																																									goto IL_1179;
																																								case 319:
																																									goto IL_118c;
																																								case 91:
																																								case 161:
																																									goto IL_1197;
																																								case 211:
																																									goto IL_11c0;
																																								case 103:
																																									goto IL_11ce;
																																								case 198:
																																									goto IL_11e1;
																																								case 312:
																																									goto IL_11ef;
																																								case 286:
																																									goto IL_11fd;
																																								case 123:
																																									goto IL_120b;
																																								case 47:
																																								case 309:
																																									goto IL_1219;
																																								case 235:
																																									goto IL_122d;
																																								case 283:
																																									goto IL_12ab;
																																								case 259:
																																									goto IL_12b9;
																																								case 20:
																																								case 189:
																																									goto IL_12cc;
																																								case 126:
																																									goto IL_12e9;
																																								case 76:
																																									goto IL_1335;
																																								case 183:
																																									goto IL_1343;
																																								case 291:
																																									goto IL_1356;
																																								case 149:
																																									goto IL_1361;
																																								case 254:
																																									goto IL_136f;
																																								case 41:
																																								case 213:
																																									goto IL_137d;
																																								case 106:
																																									goto IL_1395;
																																								case 15:
																																									goto IL_13a3;
																																								case 160:
																																									goto IL_13b1;
																																								case 178:
																																									goto IL_13c4;
																																								case 5:
																																								case 102:
																																									goto IL_13d2;
																																								case 118:
																																									goto IL_13fb;
																																								case 246:
																																									goto IL_1409;
																																								case 324:
																																									goto IL_1425;
																																								case 28:
																																								case 129:
																																									goto IL_1430;
																																								case 212:
																																									goto IL_1470;
																																								case 88:
																																									goto IL_1484;
																																								case 279:
																																									goto IL_1497;
																																								case 45:
																																									goto IL_14a5;
																																								case 124:
																																								case 293:
																																									goto IL_14b3;
																																								case 195:
																																									goto IL_14cc;
																																								case 207:
																																									goto IL_14da;
																																								case 203:
																																									goto IL_14e8;
																																								case 252:
																																								case 325:
																																									goto IL_14fb;
																																								case 220:
																																									goto IL_1509;
																																								case 69:
																																									goto IL_152c;
																																								case 223:
																																									goto IL_153f;
																																								case 70:
																																									goto IL_154d;
																																								case 326:
																																									goto IL_1560;
																																								case 188:
																																								case 304:
																																									goto IL_156b;
																																								case 56:
																																									goto IL_158f;
																																								case 310:
																																									goto IL_159d;
																																								case 13:
																																									goto IL_15ab;
																																								case 275:
																																									goto IL_15be;
																																								case 210:
																																									goto IL_15cc;
																																								case 282:
																																								case 311:
																																									goto IL_15da;
																																								case 327:
																																									goto IL_15f6;
																																								case 85:
																																								case 328:
																																									goto IL_1609;
																																								case 22:
																																									goto IL_1623;
																																								case 321:
																																									goto IL_164e;
																																								case 0:
																																									goto IL_1661;
																																								case 96:
																																									goto IL_166c;
																																								case 54:
																																								case 137:
																																									goto IL_167a;
																																								case 122:
																																									goto IL_16b8;
																																								case 152:
																																									goto IL_16d4;
																																								case 231:
																																									goto IL_16e2;
																																								case 121:
																																								case 260:
																																									goto IL_16f0;
																																								case 131:
																																									goto IL_1704;
																																								case 84:
																																									goto IL_173c;
																																								case 12:
																																								case 93:
																																									goto IL_174c;
																																								case 303:
																																									goto IL_175a;
																																								case 6:
																																									goto IL_1787;
																																								case 215:
																																									goto IL_1795;
																																								case 1:
																																								case 7:
																																								case 9:
																																								case 14:
																																								case 30:
																																								case 34:
																																								case 58:
																																								case 73:
																																								case 81:
																																								case 87:
																																								case 95:
																																								case 101:
																																								case 105:
																																								case 107:
																																								case 112:
																																								case 116:
																																								case 117:
																																								case 119:
																																								case 120:
																																								case 127:
																																								case 135:
																																								case 146:
																																								case 156:
																																								case 158:
																																								case 159:
																																								case 165:
																																								case 173:
																																								case 199:
																																								case 205:
																																								case 214:
																																								case 226:
																																								case 227:
																																								case 234:
																																								case 240:
																																								case 241:
																																								case 242:
																																								case 247:
																																								case 269:
																																								case 287:
																																								case 300:
																																								case 307:
																																								case 329:
																																									goto end_IL_055d;
																																								case 4:
																																								case 8:
																																								case 23:
																																								case 29:
																																								case 33:
																																								case 35:
																																								case 59:
																																								case 63:
																																								case 79:
																																								case 80:
																																								case 82:
																																								case 83:
																																								case 100:
																																								case 113:
																																								case 125:
																																								case 130:
																																								case 141:
																																								case 144:
																																								case 147:
																																								case 148:
																																								case 150:
																																								case 151:
																																								case 153:
																																								case 185:
																																								case 187:
																																								case 190:
																																								case 192:
																																								case 201:
																																								case 206:
																																								case 232:
																																								case 233:
																																								case 239:
																																								case 250:
																																								case 264:
																																								case 267:
																																								case 268:
																																								case 288:
																																								case 292:
																																								case 294:
																																								case 317:
																																								case 322:
																																								case 323:
																																									goto IL_17b8;
																																								case 174:
																																									goto IL_17cb;
																																								case 43:
																																									goto IL_17d5;
																																								case 51:
																																									goto IL_17e0;
																																								case 46:
																																									goto IL_17f0;
																																								case 320:
																																									goto IL_1800;
																																								case 236:
																																									goto IL_1810;
																																								case 111:
																																									goto IL_1820;
																																								case 244:
																																									goto IL_1830;
																																								case 228:
																																								case 305:
																																									goto IL_1840;
																																								case 209:
																																									goto IL_1850;
																																								case 138:
																																									goto IL_1860;
																																								case 48:
																																								case 262:
																																									return;
																																								}
																																								goto end_IL_0672;
																																							}
																																							array3[num5] = array3[num5 - 1];
																																							goto IL_164e;
																																							IL_164e:
																																							num5++;
																																							goto IL_17b8;
																																							continue;
																																							end_IL_055d:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																			IL_05e2:;
																																		}
																																		break;
																																		IL_05f2:;
																																	}
																																	break;
																																}
																																goto IL_095e;
																																IL_0ed0:
																																ptr2 += 8;
																																num = 79;
																																goto IL_17b8;
																																IL_095e:
																																array2[num5] = 5;
																																goto IL_096c;
																																IL_096c:
																																array3[num5] = array7[*(int*)(ptr2 + num3)];
																																goto IL_0ec2;
																																IL_0ec2:
																																num5++;
																																goto IL_0ed0;
																															}
																															break;
																														}
																														goto IL_1661;
																														IL_173c:
																														ptr2 += 8;
																														goto IL_17b8;
																														IL_1661:
																														if (18 >= b)
																														{
																															goto IL_166c;
																														}
																														goto IL_16d4;
																														IL_166c:
																														if (18 > b)
																														{
																															break;
																														}
																														goto IL_167a;
																														IL_167a:
																														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																														goto IL_16b8;
																														IL_16b8:
																														num5 -= 3;
																														num = 63;
																														goto IL_17b8;
																														IL_16d4:
																														if (19 < b)
																														{
																															break;
																														}
																														goto IL_16e2;
																														IL_16e2:
																														if (19 > b)
																														{
																															break;
																														}
																														goto IL_16f0;
																														IL_16f0:
																														array2[num5 - 1] = 5;
																														goto IL_1704;
																														IL_1704:
																														array3[num5 - 1] = ((delegate*<string[], string>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																														goto IL_173c;
																													}
																													break;
																												}
																												goto IL_069d;
																												IL_087e:
																												array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																												goto IL_089c;
																												IL_069d:
																												if (15 > b)
																												{
																													goto IL_06a8;
																												}
																												goto IL_06c9;
																												IL_06a8:
																												if (12 >= b)
																												{
																													goto IL_06b6;
																												}
																												goto IL_075c;
																												IL_06b6:
																												if (12 <= b)
																												{
																													goto IL_17b8;
																												}
																												goto IL_0d4a;
																												IL_0d4a:
																												if (11 < b)
																												{
																													break;
																												}
																												goto IL_0d58;
																												IL_0d58:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_0d66;
																												IL_0d66:
																												array2[num5 - 1] = 0;
																												goto IL_0d7a;
																												IL_0d7a:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)getHasCurrentExport[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																												goto IL_0db9;
																												IL_0db9:
																												ptr2 += 8;
																												goto IL_17b8;
																												IL_075c:
																												if (13 >= b)
																												{
																													goto IL_076a;
																												}
																												goto IL_0859;
																												IL_076a:
																												if (13 > b)
																												{
																													break;
																												}
																												goto IL_0778;
																												IL_0778:
																												array8 = array3;
																												num6 = num5;
																												if (array == null)
																												{
																													goto IL_0787;
																												}
																												num7 = ptr2;
																												byte b2 = *num7;
																												ptr2 = num7 + 4;
																												int num8 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num8;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_082f;
																												IL_089c:
																												ptr2 += 8;
																												goto IL_08aa;
																												IL_08aa:
																												num5--;
																												goto IL_17b8;
																												IL_06c9:
																												array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																												goto IL_06f2;
																												IL_082f:
																												array2[num5] = 5;
																												num = 238;
																												goto IL_0846;
																												IL_0846:
																												num5++;
																												goto IL_17b8;
																												IL_0859:
																												if (14 < b)
																												{
																													break;
																												}
																												goto IL_0867;
																												IL_0867:
																												if (14 > b)
																												{
																													break;
																												}
																												num = 261;
																												goto IL_087e;
																												IL_06f2:
																												array2[num5 - 1] = 5;
																												goto IL_17b8;
																											}
																											break;
																										}
																										goto IL_070b;
																										IL_1094:
																										num5--;
																										goto IL_17b8;
																										IL_070b:
																										if (10 > b)
																										{
																											goto IL_0719;
																										}
																										goto IL_1117;
																										IL_0719:
																										if (5 < b)
																										{
																											goto IL_0724;
																										}
																										num = 289;
																										goto IL_0dcc;
																										IL_0724:
																										if (7 >= b)
																										{
																											goto IL_0732;
																										}
																										goto IL_08bd;
																										IL_0732:
																										if (7 > b)
																										{
																											goto IL_099c;
																										}
																										num = 302;
																										goto IL_1007;
																										IL_1179:
																										num5 -= 2;
																										goto IL_17b8;
																										IL_1007:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										num = 179;
																										goto IL_1050;
																										IL_1050:
																										array2[num5 - 2] = 0;
																										goto IL_1064;
																										IL_1064:
																										num5--;
																										goto IL_17b8;
																										IL_099c:
																										if (6 < b)
																										{
																											break;
																										}
																										goto IL_09aa;
																										IL_09aa:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_0f0d;
																										IL_0f0d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_10f0;
																										IL_10f0:
																										array2[num5 - 2] = 0;
																										goto IL_1104;
																										IL_1104:
																										num5--;
																										goto IL_17b8;
																										IL_08bd:
																										if (8 >= b)
																										{
																											goto IL_08c8;
																										}
																										goto IL_08db;
																										IL_08c8:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_0989;
																										IL_0989:
																										num5--;
																										goto IL_17b8;
																										IL_08db:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_08e9;
																										IL_08e9:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_08f7;
																										IL_08f7:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0937;
																										IL_0937:
																										array2[num5 - 2] = 0;
																										goto IL_094b;
																										IL_094b:
																										num5--;
																										goto IL_17b8;
																										IL_1117:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_1179;
																										IL_0dcc:
																										if (5 > b)
																										{
																											goto IL_0dda;
																										}
																										goto IL_0f52;
																										IL_0dda:
																										if (2 < b)
																										{
																											goto IL_0de8;
																										}
																										goto IL_1425;
																										IL_0de8:
																										if (3 >= b)
																										{
																											goto IL_0df3;
																										}
																										goto IL_0e4b;
																										IL_0df3:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0e01;
																										IL_0e01:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0e2a;
																										IL_0e2a:
																										ptr2 += 8;
																										goto IL_0e38;
																										IL_0e38:
																										num5--;
																										goto IL_17b8;
																										IL_0e4b:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_0e59;
																										IL_0e59:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_14fb;
																										IL_14fb:
																										array2[num5] = 0;
																										goto IL_1509;
																										IL_1509:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_152c;
																										IL_152c:
																										array3[num5] = null;
																										num = 223;
																										goto IL_153f;
																										IL_153f:
																										num5++;
																										goto IL_154d;
																										IL_154d:
																										ptr2 += 8;
																										goto IL_17b8;
																										IL_1425:
																										if (2 <= b)
																										{
																											goto IL_1430;
																										}
																										goto IL_1497;
																										IL_1430:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_1470;
																										IL_1470:
																										array2[num5 - 2] = 0;
																										goto IL_1484;
																										IL_1484:
																										num5--;
																										goto IL_17b8;
																										IL_1497:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_14a5;
																										IL_14a5:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_14b3;
																										IL_14b3:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																										goto IL_14cc;
																										IL_14cc:
																										array2[num5] = 0;
																										goto IL_14da;
																										IL_14da:
																										num5++;
																										goto IL_14e8;
																										IL_14e8:
																										ptr2 += 8;
																										goto IL_17b8;
																										IL_0f52:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_1077;
																										IL_1077:
																										array2[num5 - 2] = 0;
																										num = 110;
																										goto IL_1094;
																									}
																									break;
																								}
																								goto IL_174c;
																								IL_1795:
																								ptr2 += 8;
																								goto IL_17b8;
																								IL_174c:
																								array2[num5] = 0;
																								goto IL_175a;
																								IL_175a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getHasCurrentExport[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								num = 6;
																								goto IL_1787;
																								IL_1787:
																								num5++;
																								goto IL_1795;
																							}
																							break;
																						}
																						goto IL_09bd;
																						IL_13fb:
																						num5--;
																						goto IL_1409;
																						IL_09bd:
																						if (30 >= b)
																						{
																							goto IL_09cb;
																						}
																						goto IL_0cc1;
																						IL_09cb:
																						if (30 > b)
																						{
																							goto IL_09d9;
																						}
																						goto IL_0c9b;
																						IL_09d9:
																						if (25 < b)
																						{
																							goto IL_09e7;
																						}
																						goto IL_0aab;
																						IL_09e7:
																						if (27 < b)
																						{
																							goto IL_09f5;
																						}
																						goto IL_0a7c;
																						IL_09f5:
																						if (28 >= b)
																						{
																							goto IL_0a03;
																						}
																						goto IL_10a7;
																						IL_0a03:
																						if (28 > b)
																						{
																							break;
																						}
																						goto IL_0a11;
																						IL_0a11:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0a55;
																						IL_0a55:
																						array2[num5 - 2] = 3;
																						goto IL_0a69;
																						IL_0a69:
																						num5--;
																						goto IL_17b8;
																						IL_10a7:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_10b5;
																						IL_10b5:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_1609;
																						IL_1609:
																						Class171.float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_1623;
																						IL_1623:
																						num5--;
																						goto IL_17b8;
																						IL_0a7c:
																						if (27 > b)
																						{
																							goto IL_0a8a;
																						}
																						goto IL_10c8;
																						IL_0a8a:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0a98;
																						IL_0a98:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_0f97;
																						IL_0f97:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 132;
																						goto IL_0fe0;
																						IL_0fe0:
																						array2[num5 - 2] = 0;
																						goto IL_0ff4;
																						IL_0ff4:
																						num5--;
																						goto IL_17b8;
																						IL_10c8:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 327;
																						goto IL_15f6;
																						IL_15f6:
																						num5--;
																						goto IL_17b8;
																						IL_0aab:
																						if (25 > b)
																						{
																							goto IL_0ab9;
																						}
																						goto IL_0c57;
																						IL_0ab9:
																						if (22 < b)
																						{
																							goto IL_0ac7;
																						}
																						goto IL_0b57;
																						IL_0ac7:
																						if (23 >= b)
																						{
																							goto IL_0ad2;
																						}
																						goto IL_0b2d;
																						IL_0ad2:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0ae0;
																						IL_0ae0:
																						array3[num5] = ((delegate*<float[]>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
																						goto IL_0afe;
																						IL_0afe:
																						array2[num5] = 5;
																						goto IL_0b0c;
																						IL_0b0c:
																						num5++;
																						goto IL_0b1a;
																						IL_0b1a:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_0b2d:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_0b3b;
																						IL_0b3b:
																						if (24 > b)
																						{
																							break;
																						}
																						num = 295;
																						goto IL_0e7f;
																						IL_1409:
																						ptr2 += 8;
																						num = 317;
																						goto IL_17b8;
																						IL_0e7f:
																						*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
																						goto IL_0ea9;
																						IL_0ea9:
																						array2[num5 - 1] = 2;
																						goto IL_17b8;
																						IL_0b57:
																						if (22 > b)
																						{
																							goto IL_0b65;
																						}
																						goto IL_0bf2;
																						IL_0b65:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_0b73;
																						IL_0b73:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0b81;
																						IL_0b81:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0bdf;
																						IL_0bdf:
																						num5--;
																						goto IL_17b8;
																						IL_0bf2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
																						num = 62;
																						goto IL_0c1f;
																						IL_0c1f:
																						array2[num5] = 0;
																						goto IL_0c2d;
																						IL_0c2d:
																						num5++;
																						num = 55;
																						goto IL_0c44;
																						IL_0c44:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_0c57:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_0c82;
																						IL_0c82:
																						array2[num5 - 1] = 0;
																						goto IL_17b8;
																						IL_0c9b:
																						array2[num5] = 15;
																						goto IL_0ca9;
																						IL_0ca9:
																						array4[num5] = *(int*)(ptr2 + num3);
																						goto IL_0eec;
																						IL_0eec:
																						ptr2 += 8;
																						goto IL_0efa;
																						IL_0efa:
																						num5++;
																						goto IL_17b8;
																						IL_0cc1:
																						if (35 < b)
																						{
																							goto IL_0ccf;
																						}
																						goto IL_118c;
																						IL_0ccf:
																						if (37 < b)
																						{
																							goto IL_0cdd;
																						}
																						goto IL_1560;
																						IL_0cdd:
																						if (38 >= b)
																						{
																							goto IL_0ce8;
																						}
																						goto IL_0d37;
																						IL_0ce8:
																						if (38 > b)
																						{
																							break;
																						}
																						goto IL_0cf6;
																						IL_0cf6:
																						((Class173)array3[num5 - 2]).float_2 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_0d24;
																						IL_0d24:
																						num5 -= 2;
																						goto IL_17b8;
																						IL_0d37:
																						if (39 < b)
																						{
																							break;
																						}
																						goto IL_0e6c;
																						IL_0e6c:
																						if (39 > b)
																						{
																						}
																						break;
																						IL_1560:
																						if (37 <= b)
																						{
																							goto IL_156b;
																						}
																						goto IL_15be;
																						IL_156b:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
																						goto IL_158f;
																						IL_158f:
																						array2[num5] = 3;
																						goto IL_159d;
																						IL_159d:
																						num5++;
																						goto IL_15ab;
																						IL_15ab:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_15be:
																						if (36 < b)
																						{
																							break;
																						}
																						goto IL_15cc;
																						IL_15cc:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_15da;
																						IL_15da:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						goto IL_17b8;
																						IL_118c:
																						if (35 <= b)
																						{
																							goto IL_1197;
																						}
																						goto IL_11e1;
																						IL_1197:
																						((delegate*<UnityEngine.Object, void>)getHasCurrentExport[*(int*)(ptr2 + num3)])((Class173)array3[num5 - 1]);
																						goto IL_11c0;
																						IL_11c0:
																						num5--;
																						goto IL_11ce;
																						IL_11ce:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_11e1:
																						if (32 >= b)
																						{
																							goto IL_11ef;
																						}
																						goto IL_1356;
																						IL_11ef:
																						if (32 > b)
																						{
																							goto IL_11fd;
																						}
																						goto IL_12cc;
																						IL_11fd:
																						if (31 < b)
																						{
																							break;
																						}
																						goto IL_120b;
																						IL_120b:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_1219;
																						IL_1219:
																						array2[num5 - 2] = 5;
																						goto IL_122d;
																						IL_122d:
																						array3[num5 - 2] = ((delegate*<ref float, string, string>)getHasCurrentExport[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)getHasCurrentExport[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																						goto IL_12ab;
																						IL_12ab:
																						num5--;
																						goto IL_12b9;
																						IL_12b9:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_12cc:
																						array2[num5 - 2] = 5;
																						num = 126;
																						goto IL_12e9;
																						IL_12e9:
																						array3[num5 - 2] = ((delegate*<string, string, string>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																						goto IL_1335;
																						IL_1335:
																						num5--;
																						goto IL_1343;
																						IL_1343:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_1356:
																						if (33 < b)
																						{
																							goto IL_1361;
																						}
																						goto IL_13c4;
																						IL_1361:
																						if (34 < b)
																						{
																							break;
																						}
																						goto IL_136f;
																						IL_136f:
																						if (34 > b)
																						{
																							break;
																						}
																						goto IL_137d;
																						IL_137d:
																						array3[num5] = array7[*(int*)(ptr2 + num3)];
																						goto IL_1395;
																						IL_1395:
																						array2[num5] = 5;
																						goto IL_13a3;
																						IL_13a3:
																						num5++;
																						goto IL_13b1;
																						IL_13b1:
																						ptr2 += 8;
																						goto IL_17b8;
																						IL_13c4:
																						if (33 > b)
																						{
																							break;
																						}
																						goto IL_13d2;
																						IL_13d2:
																						((delegate*<string, void>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																						goto IL_13fb;
																					}
																					break;
																					IL_0662:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_17b8;
																			continue;
																			end_IL_0672:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0787:
			while (true)
			{
				IL_0787_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_082f_2:
						array2[num5] = 5;
						num = 238;
						while (true)
						{
							IL_0846_2:
							num5++;
							while (true)
							{
								IL_17b8_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0672_2:
											if (b >= 1)
											{
												while (b <= 39)
												{
													while (true)
													{
														IL_0652_2:
														if (20 >= b)
														{
															while (true)
															{
																IL_0642_2:
																if (20 > b)
																{
																	while (true)
																	{
																		IL_0632_2:
																		if (10 < b)
																		{
																			while (true)
																			{
																				IL_0625_2:
																				if (15 < b)
																				{
																					while (true)
																					{
																						IL_0615_2:
																						if (17 >= b)
																						{
																							while (true)
																							{
																								IL_0605_2:
																								if (17 > b)
																								{
																									while (16 >= b)
																									{
																										num = 74;
																										while (16 <= b)
																										{
																											while (true)
																											{
																												IL_05c8_2:
																												array2[num5] = array2[num5 - 1];
																												while (true)
																												{
																													IL_059f_2:
																													array4[num5 - 0] = array4[num5 - 1];
																													num = 61;
																													while (true)
																													{
																														IL_0570_2:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																														num = 336;
																														while (true)
																														{
																															if (num != 336)
																															{
																																if (num != 1317)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 61:
																																	goto IL_0570_2;
																																case 314:
																																	goto IL_059f_2;
																																case 18:
																																case 229:
																																	goto IL_05c8_2;
																																case 74:
																																	goto IL_05e2_2;
																																case 172:
																																	goto IL_05f2_2;
																																case 219:
																																	goto IL_0605_2;
																																case 276:
																																	goto IL_0615_2;
																																case 273:
																																	goto IL_0625_2;
																																case 170:
																																	goto IL_0632_2;
																																case 196:
																																	goto IL_0642_2;
																																case 77:
																																	goto IL_0652_2;
																																case 3:
																																	goto IL_0662_2;
																																case 181:
																																	goto IL_0672_2;
																																case 40:
																																	goto end_IL_0672_2;
																																case 163:
																																case 318:
																																	goto end_IL_0682;
																																case 194:
																																	goto IL_069d_2;
																																case 25:
																																	goto IL_06a8_2;
																																case 68:
																																	goto IL_06b6_2;
																																case 39:
																																case 202:
																																	goto IL_06c9_2;
																																case 99:
																																	goto IL_06f2_2;
																																case 237:
																																	goto IL_070b_2;
																																case 60:
																																	goto IL_0719_2;
																																case 191:
																																	goto IL_0724_2;
																																case 38:
																																	goto IL_0732_2;
																																case 256:
																																	goto IL_075c_2;
																																case 44:
																																	goto IL_076a_2;
																																case 176:
																																case 253:
																																	goto end_IL_0692;
																																case 175:
																																	goto IL_082f_2;
																																case 238:
																																	goto IL_0846_2;
																																case 182:
																																	goto IL_0859_2;
																																case 37:
																																	goto IL_0867_2;
																																case 230:
																																case 261:
																																	goto IL_087e_2;
																																case 114:
																																	goto IL_089c_2;
																																case 90:
																																	goto IL_08aa_2;
																																case 270:
																																	goto IL_08bd_2;
																																case 197:
																																	goto IL_08c8_2;
																																case 167:
																																	goto IL_08db_2;
																																case 277:
																																	goto IL_08e9_2;
																																case 217:
																																case 265:
																																	goto IL_08f7_2;
																																case 263:
																																	goto IL_0937_2;
																																case 78:
																																	goto IL_094b_2;
																																case 140:
																																case 278:
																																	goto IL_095e_2;
																																case 89:
																																	goto IL_096c_2;
																																case 155:
																																case 280:
																																	goto IL_0989_2;
																																case 281:
																																	goto IL_099c_2;
																																case 136:
																																	goto IL_09aa_2;
																																case 284:
																																	goto IL_09bd_2;
																																case 17:
																																	goto IL_09cb_2;
																																case 109:
																																	goto IL_09d9_2;
																																case 10:
																																	goto IL_09e7_2;
																																case 154:
																																	goto IL_09f5_2;
																																case 166:
																																	goto IL_0a03_2;
																																case 57:
																																case 251:
																																	goto IL_0a11_2;
																																case 272:
																																	goto IL_0a55_2;
																																case 36:
																																	goto IL_0a69_2;
																																case 71:
																																	goto IL_0a7c_2;
																																case 86:
																																	goto IL_0a8a_2;
																																case 257:
																																	goto IL_0a98_2;
																																case 168:
																																	goto IL_0aab_2;
																																case 67:
																																	goto IL_0ab9_2;
																																case 53:
																																	goto IL_0ac7_2;
																																case 11:
																																	goto IL_0ad2_2;
																																case 145:
																																case 177:
																																	goto IL_0ae0_2;
																																case 65:
																																	goto IL_0afe_2;
																																case 204:
																																	goto IL_0b0c_2;
																																case 221:
																																	goto IL_0b1a_2;
																																case 184:
																																	goto IL_0b2d_2;
																																case 94:
																																	goto IL_0b3b_2;
																																case 180:
																																	goto IL_0b57_2;
																																case 64:
																																	goto IL_0b65_2;
																																case 19:
																																	goto IL_0b73_2;
																																case 42:
																																case 255:
																																	goto IL_0b81_2;
																																case 142:
																																	goto IL_0bdf_2;
																																case 243:
																																case 271:
																																	goto IL_0bf2_2;
																																case 62:
																																	goto IL_0c1f_2;
																																case 92:
																																	goto IL_0c2d_2;
																																case 55:
																																	goto IL_0c44_2;
																																case 133:
																																case 249:
																																	goto IL_0c57_2;
																																case 186:
																																	goto IL_0c82_2;
																																case 108:
																																case 200:
																																	goto IL_0c9b_2;
																																case 52:
																																	goto IL_0ca9_2;
																																case 75:
																																	goto IL_0cc1_2;
																																case 224:
																																	goto IL_0ccf_2;
																																case 169:
																																	goto IL_0cdd_2;
																																case 216:
																																	goto IL_0ce8_2;
																																case 134:
																																case 245:
																																	goto IL_0cf6_2;
																																case 104:
																																	goto IL_0d24_2;
																																case 218:
																																	goto IL_0d37_2;
																																case 285:
																																	goto IL_0d4a_2;
																																case 21:
																																	goto IL_0d58_2;
																																case 49:
																																case 128:
																																	goto IL_0d66_2;
																																case 26:
																																	goto IL_0d7a_2;
																																case 157:
																																	goto IL_0db9_2;
																																case 289:
																																	goto IL_0dcc_2;
																																case 16:
																																	goto IL_0dda_2;
																																case 171:
																																	goto IL_0de8_2;
																																case 24:
																																	goto IL_0df3_2;
																																case 66:
																																case 274:
																																	goto IL_0e01_2;
																																case 72:
																																	goto IL_0e2a_2;
																																case 266:
																																	goto IL_0e38_2;
																																case 115:
																																	goto IL_0e4b_2;
																																case 31:
																																	goto IL_0e59_2;
																																case 290:
																																	goto IL_0e6c_2;
																																case 143:
																																case 295:
																																	goto IL_0e7f_2;
																																case 98:
																																	goto IL_0ea9_2;
																																case 296:
																																	goto IL_0ec2_2;
																																case 164:
																																	goto IL_0ed0_2;
																																case 297:
																																	goto IL_0eec_2;
																																case 225:
																																	goto IL_0efa_2;
																																case 27:
																																case 298:
																																	goto IL_0f0d_2;
																																case 97:
																																case 299:
																																	goto IL_0f52_2;
																																case 32:
																																case 301:
																																	goto IL_0f97_2;
																																case 132:
																																	goto IL_0fe0_2;
																																case 208:
																																	goto IL_0ff4_2;
																																case 258:
																																case 302:
																																	goto IL_1007_2;
																																case 179:
																																	goto IL_1050_2;
																																case 162:
																																	goto IL_1064_2;
																																case 306:
																																	goto IL_1077_2;
																																case 110:
																																	goto IL_1094_2;
																																case 308:
																																	goto IL_10a7_2;
																																case 50:
																																	goto IL_10b5_2;
																																case 193:
																																case 313:
																																	goto IL_10c8_2;
																																case 315:
																																	goto IL_10f0_2;
																																case 248:
																																	goto IL_1104_2;
																																case 222:
																																case 316:
																																	goto IL_1117_2;
																																case 2:
																																	goto IL_1179_2;
																																case 319:
																																	goto IL_118c_2;
																																case 91:
																																case 161:
																																	goto IL_1197_2;
																																case 211:
																																	goto IL_11c0_2;
																																case 103:
																																	goto IL_11ce_2;
																																case 198:
																																	goto IL_11e1_2;
																																case 312:
																																	goto IL_11ef_2;
																																case 286:
																																	goto IL_11fd_2;
																																case 123:
																																	goto IL_120b_2;
																																case 47:
																																case 309:
																																	goto IL_1219_2;
																																case 235:
																																	goto IL_122d_2;
																																case 283:
																																	goto IL_12ab_2;
																																case 259:
																																	goto IL_12b9_2;
																																case 20:
																																case 189:
																																	goto IL_12cc_2;
																																case 126:
																																	goto IL_12e9_2;
																																case 76:
																																	goto IL_1335_2;
																																case 183:
																																	goto IL_1343_2;
																																case 291:
																																	goto IL_1356_2;
																																case 149:
																																	goto IL_1361_2;
																																case 254:
																																	goto IL_136f_2;
																																case 41:
																																case 213:
																																	goto IL_137d_2;
																																case 106:
																																	goto IL_1395_2;
																																case 15:
																																	goto IL_13a3_2;
																																case 160:
																																	goto IL_13b1_2;
																																case 178:
																																	goto IL_13c4_2;
																																case 5:
																																case 102:
																																	goto IL_13d2_2;
																																case 118:
																																	goto IL_13fb_2;
																																case 246:
																																	goto IL_1409_2;
																																case 324:
																																	goto IL_1425_2;
																																case 28:
																																case 129:
																																	goto IL_1430_2;
																																case 212:
																																	goto IL_1470_2;
																																case 88:
																																	goto IL_1484_2;
																																case 279:
																																	goto IL_1497_2;
																																case 45:
																																	goto IL_14a5_2;
																																case 124:
																																case 293:
																																	goto IL_14b3_2;
																																case 195:
																																	goto IL_14cc_2;
																																case 207:
																																	goto IL_14da_2;
																																case 203:
																																	goto IL_14e8_2;
																																case 252:
																																case 325:
																																	goto IL_14fb_2;
																																case 220:
																																	goto IL_1509_2;
																																case 69:
																																	goto IL_152c_2;
																																case 223:
																																	goto IL_153f_2;
																																case 70:
																																	goto IL_154d_2;
																																case 326:
																																	goto IL_1560_2;
																																case 188:
																																case 304:
																																	goto IL_156b_2;
																																case 56:
																																	goto IL_158f_2;
																																case 310:
																																	goto IL_159d_2;
																																case 13:
																																	goto IL_15ab_2;
																																case 275:
																																	goto IL_15be_2;
																																case 210:
																																	goto IL_15cc_2;
																																case 282:
																																case 311:
																																	goto IL_15da_2;
																																case 327:
																																	goto IL_15f6_2;
																																case 85:
																																case 328:
																																	goto IL_1609_2;
																																case 22:
																																	goto IL_1623_2;
																																case 321:
																																	goto IL_164e_2;
																																case 0:
																																	goto IL_1661_2;
																																case 96:
																																	goto IL_166c_2;
																																case 54:
																																case 137:
																																	goto IL_167a_2;
																																case 122:
																																	goto IL_16b8_2;
																																case 152:
																																	goto IL_16d4_2;
																																case 231:
																																	goto IL_16e2_2;
																																case 121:
																																case 260:
																																	goto IL_16f0_2;
																																case 131:
																																	goto IL_1704_2;
																																case 84:
																																	goto IL_173c_2;
																																case 12:
																																case 93:
																																	goto IL_174c_2;
																																case 303:
																																	goto IL_175a_2;
																																case 6:
																																	goto IL_1787_2;
																																case 215:
																																	goto IL_1795_2;
																																case 1:
																																case 7:
																																case 9:
																																case 14:
																																case 30:
																																case 34:
																																case 58:
																																case 73:
																																case 81:
																																case 87:
																																case 95:
																																case 101:
																																case 105:
																																case 107:
																																case 112:
																																case 116:
																																case 117:
																																case 119:
																																case 120:
																																case 127:
																																case 135:
																																case 146:
																																case 156:
																																case 158:
																																case 159:
																																case 165:
																																case 173:
																																case 199:
																																case 205:
																																case 214:
																																case 226:
																																case 227:
																																case 234:
																																case 240:
																																case 241:
																																case 242:
																																case 247:
																																case 269:
																																case 287:
																																case 300:
																																case 307:
																																case 329:
																																	goto end_IL_055d_2;
																																case 4:
																																case 8:
																																case 23:
																																case 29:
																																case 33:
																																case 35:
																																case 59:
																																case 63:
																																case 79:
																																case 80:
																																case 82:
																																case 83:
																																case 100:
																																case 113:
																																case 125:
																																case 130:
																																case 141:
																																case 144:
																																case 147:
																																case 148:
																																case 150:
																																case 151:
																																case 153:
																																case 185:
																																case 187:
																																case 190:
																																case 192:
																																case 201:
																																case 206:
																																case 232:
																																case 233:
																																case 239:
																																case 250:
																																case 264:
																																case 267:
																																case 268:
																																case 288:
																																case 292:
																																case 294:
																																case 317:
																																case 322:
																																case 323:
																																	goto IL_17b8_2;
																																case 174:
																																	ptr2 = ptr;
																																	goto IL_17b8_2;
																																case 43:
																																	ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IPermissionSetEntryChannelName.getCurrentManagedThreadIdsetRole);
																																	goto case 174;
																																case 51:
																																	array7[0] = this;
																																	goto case 43;
																																case 46:
																																	array7 = new object[17];
																																	goto case 51;
																																case 320:
																																	array6 = new long[4];
																																	goto case 46;
																																case 236:
																																	array5 = new int[6];
																																	goto case 320;
																																case 111:
																																	array4 = new int[4];
																																	goto case 236;
																																case 244:
																																	array3 = new object[4];
																																	goto case 111;
																																case 228:
																																case 305:
																																	array2 = new byte[4];
																																	goto case 244;
																																case 209:
																																	num3 = num2 * 4;
																																	goto case 228;
																																case 138:
																																	num2 = 1;
																																	goto case 209;
																																case 139:
																																	goto end_IL_0795;
																																case 48:
																																case 262:
																																	return;
																																}
																																continue;
																															}
																															array3[num5] = array3[num5 - 1];
																															goto IL_164e_2;
																															IL_164e_2:
																															num5++;
																															goto IL_17b8_2;
																															continue;
																															end_IL_055d_2:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_05e2_2:;
																										}
																										break;
																										IL_05f2_2:;
																									}
																									break;
																								}
																								goto IL_095e_2;
																								IL_0ed0_2:
																								ptr2 += 8;
																								num = 79;
																								goto IL_17b8_2;
																								IL_095e_2:
																								array2[num5] = 5;
																								goto IL_096c_2;
																								IL_096c_2:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0ec2_2;
																								IL_0ec2_2:
																								num5++;
																								goto IL_0ed0_2;
																							}
																							break;
																						}
																						goto IL_1661_2;
																						IL_173c_2:
																						ptr2 += 8;
																						goto IL_17b8_2;
																						IL_1661_2:
																						if (18 >= b)
																						{
																							goto IL_166c_2;
																						}
																						goto IL_16d4_2;
																						IL_166c_2:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_167a_2;
																						IL_167a_2:
																						((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																						goto IL_16b8_2;
																						IL_16b8_2:
																						num5 -= 3;
																						num = 63;
																						goto IL_17b8_2;
																						IL_16d4_2:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_16e2_2;
																						IL_16e2_2:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_16f0_2;
																						IL_16f0_2:
																						array2[num5 - 1] = 5;
																						goto IL_1704_2;
																						IL_1704_2:
																						array3[num5 - 1] = ((delegate*<string[], string>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																						goto IL_173c_2;
																					}
																					break;
																				}
																				goto IL_069d_2;
																				IL_06c9_2:
																				array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																				goto IL_06f2_2;
																				IL_069d_2:
																				if (15 > b)
																				{
																					goto IL_06a8_2;
																				}
																				goto IL_06c9_2;
																				IL_06a8_2:
																				if (12 >= b)
																				{
																					goto IL_06b6_2;
																				}
																				goto IL_075c_2;
																				IL_06b6_2:
																				if (12 <= b)
																				{
																					goto IL_17b8_2;
																				}
																				goto IL_0d4a_2;
																				IL_0d4a_2:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0d58_2;
																				IL_0d58_2:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0d66_2;
																				IL_0d66_2:
																				array2[num5 - 1] = 0;
																				goto IL_0d7a_2;
																				IL_0d7a_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)getHasCurrentExport[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																				goto IL_0db9_2;
																				IL_0db9_2:
																				ptr2 += 8;
																				goto IL_17b8_2;
																				IL_075c_2:
																				if (13 >= b)
																				{
																					goto IL_076a_2;
																				}
																				goto IL_0859_2;
																				IL_076a_2:
																				if (13 > b)
																				{
																					break;
																				}
																				goto end_IL_0692;
																				IL_0859_2:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_0867_2;
																				IL_0867_2:
																				if (14 > b)
																				{
																					break;
																				}
																				num = 261;
																				goto IL_087e_2;
																				IL_06f2_2:
																				array2[num5 - 1] = 5;
																				goto IL_17b8_2;
																				IL_087e_2:
																				array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																				goto IL_089c_2;
																				IL_089c_2:
																				ptr2 += 8;
																				goto IL_08aa_2;
																				IL_08aa_2:
																				num5--;
																				goto IL_17b8_2;
																			}
																			break;
																		}
																		goto IL_070b_2;
																		IL_1094_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_070b_2:
																		if (10 > b)
																		{
																			goto IL_0719_2;
																		}
																		goto IL_1117_2;
																		IL_0719_2:
																		if (5 < b)
																		{
																			goto IL_0724_2;
																		}
																		num = 289;
																		goto IL_0dcc_2;
																		IL_0724_2:
																		if (7 >= b)
																		{
																			goto IL_0732_2;
																		}
																		goto IL_08bd_2;
																		IL_0732_2:
																		if (7 > b)
																		{
																			goto IL_099c_2;
																		}
																		num = 302;
																		goto IL_1007_2;
																		IL_1179_2:
																		num5 -= 2;
																		goto IL_17b8_2;
																		IL_1007_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		num = 179;
																		goto IL_1050_2;
																		IL_1050_2:
																		array2[num5 - 2] = 0;
																		goto IL_1064_2;
																		IL_1064_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_099c_2:
																		if (6 < b)
																		{
																			break;
																		}
																		goto IL_09aa_2;
																		IL_09aa_2:
																		if (6 > b)
																		{
																			break;
																		}
																		goto IL_0f0d_2;
																		IL_0f0d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_10f0_2;
																		IL_10f0_2:
																		array2[num5 - 2] = 0;
																		goto IL_1104_2;
																		IL_1104_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_08bd_2:
																		if (8 >= b)
																		{
																			goto IL_08c8_2;
																		}
																		goto IL_08db_2;
																		IL_08c8_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0989_2;
																		IL_0989_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_08db_2:
																		if (9 < b)
																		{
																			break;
																		}
																		goto IL_08e9_2;
																		IL_08e9_2:
																		if (9 > b)
																		{
																			break;
																		}
																		goto IL_08f7_2;
																		IL_08f7_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0937_2;
																		IL_0937_2:
																		array2[num5 - 2] = 0;
																		goto IL_094b_2;
																		IL_094b_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_1117_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_1179_2;
																		IL_0dcc_2:
																		if (5 > b)
																		{
																			goto IL_0dda_2;
																		}
																		goto IL_0f52_2;
																		IL_0dda_2:
																		if (2 < b)
																		{
																			goto IL_0de8_2;
																		}
																		goto IL_1425_2;
																		IL_0de8_2:
																		if (3 >= b)
																		{
																			goto IL_0df3_2;
																		}
																		goto IL_0e4b_2;
																		IL_0df3_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0e01_2;
																		IL_0e01_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0e2a_2;
																		IL_0e2a_2:
																		ptr2 += 8;
																		goto IL_0e38_2;
																		IL_0e38_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_0e4b_2:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_0e59_2;
																		IL_0e59_2:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_14fb_2;
																		IL_14fb_2:
																		array2[num5] = 0;
																		goto IL_1509_2;
																		IL_1509_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_152c_2;
																		IL_152c_2:
																		array3[num5] = null;
																		num = 223;
																		goto IL_153f_2;
																		IL_153f_2:
																		num5++;
																		goto IL_154d_2;
																		IL_154d_2:
																		ptr2 += 8;
																		goto IL_17b8_2;
																		IL_1425_2:
																		if (2 <= b)
																		{
																			goto IL_1430_2;
																		}
																		goto IL_1497_2;
																		IL_1430_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_1470_2;
																		IL_1470_2:
																		array2[num5 - 2] = 0;
																		goto IL_1484_2;
																		IL_1484_2:
																		num5--;
																		goto IL_17b8_2;
																		IL_1497_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_14a5_2;
																		IL_14a5_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_14b3_2;
																		IL_14b3_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																		goto IL_14cc_2;
																		IL_14cc_2:
																		array2[num5] = 0;
																		goto IL_14da_2;
																		IL_14da_2:
																		num5++;
																		goto IL_14e8_2;
																		IL_14e8_2:
																		ptr2 += 8;
																		goto IL_17b8_2;
																		IL_0f52_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_1077_2;
																		IL_1077_2:
																		array2[num5 - 2] = 0;
																		num = 110;
																		goto IL_1094_2;
																	}
																	break;
																}
																goto IL_174c_2;
																IL_1795_2:
																ptr2 += 8;
																goto IL_17b8_2;
																IL_174c_2:
																array2[num5] = 0;
																goto IL_175a_2;
																IL_175a_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getHasCurrentExport[*(int*)(ptr2 + num3)])() ? 1 : 0);
																num = 6;
																goto IL_1787_2;
																IL_1787_2:
																num5++;
																goto IL_1795_2;
															}
															break;
														}
														goto IL_09bd_2;
														IL_13fb_2:
														num5--;
														goto IL_1409_2;
														IL_09bd_2:
														if (30 >= b)
														{
															goto IL_09cb_2;
														}
														goto IL_0cc1_2;
														IL_09cb_2:
														if (30 > b)
														{
															goto IL_09d9_2;
														}
														goto IL_0c9b_2;
														IL_09d9_2:
														if (25 < b)
														{
															goto IL_09e7_2;
														}
														goto IL_0aab_2;
														IL_09e7_2:
														if (27 < b)
														{
															goto IL_09f5_2;
														}
														goto IL_0a7c_2;
														IL_09f5_2:
														if (28 >= b)
														{
															goto IL_0a03_2;
														}
														goto IL_10a7_2;
														IL_0a03_2:
														if (28 > b)
														{
															break;
														}
														goto IL_0a11_2;
														IL_0a11_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((float[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0a55_2;
														IL_0a55_2:
														array2[num5 - 2] = 3;
														goto IL_0a69_2;
														IL_0a69_2:
														num5--;
														goto IL_17b8_2;
														IL_10a7_2:
														if (29 < b)
														{
															break;
														}
														goto IL_10b5_2;
														IL_10b5_2:
														if (29 > b)
														{
															break;
														}
														goto IL_1609_2;
														IL_1609_2:
														Class171.float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_1623_2;
														IL_1623_2:
														num5--;
														goto IL_17b8_2;
														IL_0a7c_2:
														if (27 > b)
														{
															goto IL_0a8a_2;
														}
														goto IL_10c8_2;
														IL_0a8a_2:
														if (26 < b)
														{
															break;
														}
														goto IL_0a98_2;
														IL_0a98_2:
														if (26 > b)
														{
															break;
														}
														goto IL_0f97_2;
														IL_0f97_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 132;
														goto IL_0fe0_2;
														IL_0fe0_2:
														array2[num5 - 2] = 0;
														goto IL_0ff4_2;
														IL_0ff4_2:
														num5--;
														goto IL_17b8_2;
														IL_10c8_2:
														int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 327;
														goto IL_15f6_2;
														IL_15f6_2:
														num5--;
														goto IL_17b8_2;
														IL_0aab_2:
														if (25 > b)
														{
															goto IL_0ab9_2;
														}
														goto IL_0c57_2;
														IL_0ab9_2:
														if (22 < b)
														{
															goto IL_0ac7_2;
														}
														goto IL_0b57_2;
														IL_0ac7_2:
														if (23 >= b)
														{
															goto IL_0ad2_2;
														}
														goto IL_0b2d_2;
														IL_0ad2_2:
														if (23 > b)
														{
															break;
														}
														goto IL_0ae0_2;
														IL_0ae0_2:
														array3[num5] = ((delegate*<float[]>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
														goto IL_0afe_2;
														IL_0afe_2:
														array2[num5] = 5;
														goto IL_0b0c_2;
														IL_0b0c_2:
														num5++;
														goto IL_0b1a_2;
														IL_0b1a_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_0b2d_2:
														if (24 < b)
														{
															break;
														}
														goto IL_0b3b_2;
														IL_0b3b_2:
														if (24 > b)
														{
															break;
														}
														num = 295;
														goto IL_0e7f_2;
														IL_1409_2:
														ptr2 += 8;
														num = 317;
														goto IL_17b8_2;
														IL_0e7f_2:
														*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((float[])array3[num5 - 1]).LongLength;
														goto IL_0ea9_2;
														IL_0ea9_2:
														array2[num5 - 1] = 2;
														goto IL_17b8_2;
														IL_0b57_2:
														if (22 > b)
														{
															goto IL_0b65_2;
														}
														goto IL_0bf2_2;
														IL_0b65_2:
														if (21 < b)
														{
															break;
														}
														goto IL_0b73_2;
														IL_0b73_2:
														if (21 > b)
														{
															break;
														}
														goto IL_0b81_2;
														IL_0b81_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0bdf_2;
														IL_0bdf_2:
														num5--;
														goto IL_17b8_2;
														IL_0bf2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
														num = 62;
														goto IL_0c1f_2;
														IL_0c1f_2:
														array2[num5] = 0;
														goto IL_0c2d_2;
														IL_0c2d_2:
														num5++;
														num = 55;
														goto IL_0c44_2;
														IL_0c44_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_0c57_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_0c82_2;
														IL_0c82_2:
														array2[num5 - 1] = 0;
														goto IL_17b8_2;
														IL_0c9b_2:
														array2[num5] = 15;
														goto IL_0ca9_2;
														IL_0ca9_2:
														array4[num5] = *(int*)(ptr2 + num3);
														goto IL_0eec_2;
														IL_0eec_2:
														ptr2 += 8;
														goto IL_0efa_2;
														IL_0efa_2:
														num5++;
														goto IL_17b8_2;
														IL_0cc1_2:
														if (35 < b)
														{
															goto IL_0ccf_2;
														}
														goto IL_118c_2;
														IL_0ccf_2:
														if (37 < b)
														{
															goto IL_0cdd_2;
														}
														goto IL_1560_2;
														IL_0cdd_2:
														if (38 >= b)
														{
															goto IL_0ce8_2;
														}
														goto IL_0d37_2;
														IL_0ce8_2:
														if (38 > b)
														{
															break;
														}
														goto IL_0cf6_2;
														IL_0cf6_2:
														((Class173)array3[num5 - 2]).float_2 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_0d24_2;
														IL_0d24_2:
														num5 -= 2;
														goto IL_17b8_2;
														IL_0d37_2:
														if (39 < b)
														{
															break;
														}
														goto IL_0e6c_2;
														IL_0e6c_2:
														if (39 > b)
														{
														}
														break;
														IL_1560_2:
														if (37 <= b)
														{
															goto IL_156b_2;
														}
														goto IL_15be_2;
														IL_156b_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<float>)getHasCurrentExport[*(int*)(ptr2 + num3)])();
														goto IL_158f_2;
														IL_158f_2:
														array2[num5] = 3;
														goto IL_159d_2;
														IL_159d_2:
														num5++;
														goto IL_15ab_2;
														IL_15ab_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_15be_2:
														if (36 < b)
														{
															break;
														}
														goto IL_15cc_2;
														IL_15cc_2:
														if (36 > b)
														{
															break;
														}
														goto IL_15da_2;
														IL_15da_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														goto IL_17b8_2;
														IL_118c_2:
														if (35 <= b)
														{
															goto IL_1197_2;
														}
														goto IL_11e1_2;
														IL_1197_2:
														((delegate*<UnityEngine.Object, void>)getHasCurrentExport[*(int*)(ptr2 + num3)])((Class173)array3[num5 - 1]);
														goto IL_11c0_2;
														IL_11c0_2:
														num5--;
														goto IL_11ce_2;
														IL_11ce_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_11e1_2:
														if (32 >= b)
														{
															goto IL_11ef_2;
														}
														goto IL_1356_2;
														IL_11ef_2:
														if (32 > b)
														{
															goto IL_11fd_2;
														}
														goto IL_12cc_2;
														IL_11fd_2:
														if (31 < b)
														{
															break;
														}
														goto IL_120b_2;
														IL_120b_2:
														if (31 > b)
														{
															break;
														}
														goto IL_1219_2;
														IL_1219_2:
														array2[num5 - 2] = 5;
														goto IL_122d_2;
														IL_122d_2:
														array3[num5 - 2] = ((delegate*<ref float, string, string>)getHasCurrentExport[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)getHasCurrentExport[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
														goto IL_12ab_2;
														IL_12ab_2:
														num5--;
														goto IL_12b9_2;
														IL_12b9_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_12cc_2:
														array2[num5 - 2] = 5;
														num = 126;
														goto IL_12e9_2;
														IL_12e9_2:
														array3[num5 - 2] = ((delegate*<string, string, string>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
														goto IL_1335_2;
														IL_1335_2:
														num5--;
														goto IL_1343_2;
														IL_1343_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_1356_2:
														if (33 < b)
														{
															goto IL_1361_2;
														}
														goto IL_13c4_2;
														IL_1361_2:
														if (34 < b)
														{
															break;
														}
														goto IL_136f_2;
														IL_136f_2:
														if (34 > b)
														{
															break;
														}
														goto IL_137d_2;
														IL_137d_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_1395_2;
														IL_1395_2:
														array2[num5] = 5;
														goto IL_13a3_2;
														IL_13a3_2:
														num5++;
														goto IL_13b1_2;
														IL_13b1_2:
														ptr2 += 8;
														goto IL_17b8_2;
														IL_13c4_2:
														if (33 > b)
														{
															break;
														}
														goto IL_13d2_2;
														IL_13d2_2:
														((delegate*<string, void>)getHasCurrentExport[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_13fb_2;
													}
													break;
													IL_0662_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_17b8_2;
											continue;
											end_IL_0672_2:
											break;
										}
										continue;
										end_IL_0682:
										break;
									}
									continue;
									end_IL_0692:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0787_2;
					}
					continue;
					end_IL_0795:
					break;
				}
				break;
			}
		}
	}

	private static double IDeferredDisposableNameNotFound(double double_2)
	{
		return Math.Tanh(double_2);
	}

	private static float CorElementTypePlay(float float_3)
	{
		return Mathf.Abs(float_3);
	}

	private unsafe static int smethod_0(int int_3, int int_4)
	{
		int num = 70;
		int[] array3 = default(int[]);
		byte* ptr = default(byte*);
		int num4 = default(int);
		long[] array4 = default(long[]);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			num = 69;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 113;
							while (true)
							{
								if (num != 113)
								{
									if (num != 1094)
									{
										goto IL_0330;
									}
									switch (num)
									{
									case 94:
										goto end_IL_01d3;
									case 21:
										goto end_IL_01e3;
									case 25:
									case 40:
										goto end_IL_01ee;
									case 69:
										goto end_IL_01fe;
									case 70:
										goto end_IL_020e;
									case 65:
										goto IL_0240;
									case 14:
										goto IL_024e;
									case 82:
										goto IL_0261;
									case 2:
										goto IL_0274;
									case 31:
										goto IL_027d;
									case 23:
									case 29:
									case 39:
									case 47:
									case 55:
									case 64:
									case 66:
									case 67:
									case 96:
									case 100:
									case 105:
										goto IL_0285;
									case 101:
										goto IL_0295;
									case 85:
										goto IL_029e;
									case 46:
										goto IL_02a7;
									case 95:
										goto IL_02b5;
									case 35:
										goto IL_02c3;
									case 0:
										goto IL_02d1;
									case 27:
										goto IL_02df;
									case 9:
									case 49:
										goto IL_02ed;
									case 22:
									case 83:
										goto IL_02f8;
									case 84:
										goto IL_0306;
									case 57:
									case 79:
										goto IL_0314;
									case 43:
										goto IL_0330;
									case 78:
									case 87:
										goto IL_033e;
									case 93:
										goto IL_037e;
									case 75:
										goto IL_0392;
									case 80:
										goto IL_03a5;
									case 50:
									case 61:
										goto IL_03b0;
									case 48:
										goto IL_03c9;
									case 28:
										goto IL_03d7;
									case 33:
										goto IL_03e5;
									case 1:
										goto IL_03f8;
									case 86:
										goto IL_0406;
									case 41:
									case 58:
										goto IL_0414;
									case 6:
										goto IL_0454;
									case 10:
										goto IL_0468;
									case 97:
										goto IL_047b;
									case 60:
									case 88:
										goto IL_0486;
									case 3:
										goto IL_0494;
									case 56:
										goto IL_04b7;
									case 32:
										goto IL_04c1;
									case 7:
										goto IL_04cf;
									case 45:
										goto IL_04e2;
									case 54:
									case 59:
										goto IL_04f0;
									case 12:
									case 13:
										goto IL_04fe;
									case 34:
										goto IL_050c;
									case 20:
									case 98:
										goto IL_051a;
									case 17:
										goto IL_055a;
									case 89:
										goto IL_056e;
									case 26:
										goto IL_058a;
									case 5:
									case 63:
										goto IL_0598;
									case 68:
										goto IL_05c1;
									case 73:
										goto IL_05cf;
									case 37:
										goto IL_05e2;
									case 36:
									case 53:
										goto IL_05ed;
									case 11:
										goto IL_062d;
									case 72:
										goto IL_0641;
									case 8:
									case 24:
										goto IL_0666;
									case 18:
										goto IL_0671;
									case 103:
										goto IL_0687;
									case 74:
										goto IL_0695;
									case 81:
										goto IL_06a3;
									case 4:
									case 15:
									case 16:
									case 30:
									case 38:
									case 42:
									case 44:
									case 51:
									case 52:
									case 62:
									case 71:
									case 76:
									case 77:
									case 90:
									case 92:
									case 99:
									case 102:
									case 104:
									case 106:
										goto IL_06b6;
									case 19:
									case 91:
										goto IL_06db;
									}
									continue;
								}
								array3 = new int[5];
								goto IL_0240;
								IL_06a3:
								ptr += 8;
								goto IL_0285;
								IL_0687:
								array[num4] = 0;
								goto IL_0695;
								IL_06b6:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_0687;
								IL_0240:
								array4 = new long[3];
								goto IL_024e;
								IL_024e:
								array3[0] = int_3;
								goto IL_0261;
								IL_0261:
								array3[1] = int_4;
								goto IL_0274;
								IL_0274:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getXCertificateArrayList.LabelKerbWorkstationUnlockLogon);
								goto IL_027d;
								IL_027d:
								ptr = ptr2;
								goto IL_0285;
								IL_0285:
								if (num5 != 1)
								{
									goto IL_0295;
								}
								goto IL_06db;
								IL_06db:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								IL_0295:
								num = 85;
								goto IL_029e;
								IL_029e:
								b = *ptr;
								goto IL_02a7;
								IL_02a7:
								ptr++;
								goto IL_02b5;
								IL_02b5:
								if (b >= 1)
								{
									goto IL_02c3;
								}
								goto IL_06b6;
								IL_02c3:
								if (b <= 9)
								{
									goto IL_02d1;
								}
								goto IL_06b6;
								IL_02d1:
								if (5 < b)
								{
									goto IL_02df;
								}
								goto IL_047b;
								IL_02df:
								if (7 < b)
								{
									goto IL_02ed;
								}
								goto IL_03a5;
								IL_02ed:
								if (8 < b)
								{
									goto IL_02f8;
								}
								goto IL_0330;
								IL_02f8:
								if (9 >= b)
								{
									goto IL_0306;
								}
								goto IL_06b6;
								IL_0306:
								if (9 <= b)
								{
									goto IL_0314;
								}
								goto IL_06b6;
								IL_0314:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0285;
								IL_0330:
								if (8 <= b)
								{
									goto IL_033e;
								}
								goto IL_06b6;
								IL_033e:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_037e;
								IL_037e:
								array[num4 - 2] = 0;
								goto IL_0392;
								IL_0392:
								num4--;
								goto IL_0285;
								IL_03a5:
								if (7 <= b)
								{
									goto IL_03b0;
								}
								goto IL_03f8;
								IL_03b0:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr + num3);
								goto IL_03c9;
								IL_03c9:
								array[num4] = 0;
								goto IL_03d7;
								IL_03d7:
								num4++;
								goto IL_03e5;
								IL_03e5:
								ptr += 8;
								goto IL_0285;
								IL_03f8:
								if (6 >= b)
								{
									goto IL_0406;
								}
								goto IL_06b6;
								IL_0406:
								if (6 <= b)
								{
									goto IL_0414;
								}
								goto IL_06b6;
								IL_0414:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_0454;
								IL_0454:
								array[num4 - 2] = 0;
								goto IL_0468;
								IL_0468:
								num4--;
								goto IL_0285;
								IL_047b:
								if (5 <= b)
								{
									goto IL_0486;
								}
								goto IL_04e2;
								IL_0486:
								array[num4] = 0;
								goto IL_0494;
								IL_0494:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_04b7;
								IL_04b7:
								array2[num4] = null;
								goto IL_04c1;
								IL_04c1:
								num4++;
								goto IL_04cf;
								IL_04cf:
								ptr += 8;
								goto IL_0285;
								IL_04e2:
								if (2 < b)
								{
									goto IL_04f0;
								}
								goto IL_05e2;
								IL_04f0:
								if (3 < b)
								{
									goto IL_04fe;
								}
								goto IL_058a;
								IL_04fe:
								if (4 >= b)
								{
									goto IL_050c;
								}
								goto IL_06b6;
								IL_050c:
								if (4 <= b)
								{
									goto IL_051a;
								}
								goto IL_06b6;
								IL_051a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_055a;
								IL_055a:
								array[num4 - 2] = 0;
								goto IL_056e;
								IL_056e:
								num4--;
								num = 55;
								goto IL_0285;
								IL_058a:
								if (3 <= b)
								{
									goto IL_0598;
								}
								goto IL_06b6;
								IL_0598:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_05c1;
								IL_05c1:
								ptr += 8;
								goto IL_05cf;
								IL_05cf:
								num4--;
								goto IL_0285;
								IL_05e2:
								if (2 <= b)
								{
									goto IL_05ed;
								}
								num = 8;
								goto IL_0666;
								IL_05ed:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_062d;
								IL_062d:
								array[num4 - 2] = 0;
								goto IL_0641;
								IL_0641:
								num4--;
								num = 66;
								goto IL_0285;
								IL_0695:
								num4++;
								goto IL_06a3;
								IL_0666:
								if (1 >= b)
								{
									goto IL_0671;
								}
								goto IL_06b6;
								IL_0671:
								if (1 <= b)
								{
									num = 71;
								}
								goto IL_06b6;
								continue;
								end_IL_01d3:
								break;
							}
							continue;
							end_IL_01e3:
							break;
						}
						continue;
						end_IL_01ee:
						break;
					}
					continue;
					end_IL_01fe:
					break;
				}
				continue;
				end_IL_020e:
				break;
			}
		}
	}

	private static double setGroupReflectionOnlyType(double double_2)
	{
		return Math.Tan(double_2);
	}

	private static float SurrogateSelectorSerializationEvents(float float_3, float float_4)
	{
		return Mathf.Min(float_3, float_4);
	}

	private unsafe static int smethod_1(int int_3, int int_4)
	{
		int num = 31;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 22;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 78;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSSECTIONIDEVENTMAPSECTIONIsolatedStorageFileEnumerator.getKeyboardLayoutIdPOLICYGETPRIVATEINFORMATION);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 94;
															while (true)
															{
																if (num != 94)
																{
																	if (num != 1075)
																	{
																		goto IL_0491;
																	}
																	switch (num)
																	{
																	case 68:
																		goto end_IL_0187;
																	case 27:
																		goto IL_01ab;
																	case 82:
																		goto IL_01b9;
																	case 42:
																		goto IL_01c7;
																	case 55:
																		goto IL_01d5;
																	case 48:
																	case 71:
																		goto IL_01e3;
																	case 5:
																		goto IL_01f1;
																	case 59:
																	case 66:
																		goto IL_01fc;
																	case 7:
																		goto IL_020a;
																	case 41:
																	case 57:
																		goto IL_0218;
																	case 51:
																		goto IL_0234;
																	case 52:
																	case 72:
																		goto IL_0242;
																	case 69:
																		goto IL_0250;
																	case 17:
																		goto IL_027c;
																	case 85:
																		goto IL_0286;
																	case 74:
																		goto IL_0294;
																	case 34:
																		goto IL_02a7;
																	case 1:
																	case 2:
																		goto IL_02b5;
																	case 3:
																		goto IL_02c3;
																	case 25:
																	case 75:
																		goto IL_02d1;
																	case 11:
																		goto IL_02e9;
																	case 15:
																		goto IL_02f7;
																	case 79:
																		goto IL_0305;
																	case 40:
																		goto IL_0313;
																	case 14:
																	case 35:
																		goto IL_0321;
																	case 24:
																		goto IL_0361;
																	case 62:
																		goto IL_0375;
																	case 8:
																		goto IL_0391;
																	case 44:
																	case 53:
																		goto IL_039f;
																	case 39:
																		goto IL_0416;
																	case 12:
																		goto IL_0429;
																	case 61:
																		goto IL_0434;
																	case 67:
																	case 73:
																		goto IL_044a;
																	case 0:
																		goto IL_0473;
																	case 21:
																		goto IL_0481;
																	case 9:
																	case 10:
																	case 16:
																	case 18:
																	case 23:
																	case 28:
																	case 36:
																	case 43:
																	case 45:
																	case 60:
																	case 64:
																	case 65:
																	case 77:
																	case 80:
																	case 81:
																	case 86:
																		goto IL_0491;
																	case 63:
																		goto IL_04b4;
																	case 47:
																		goto IL_04c2;
																	case 6:
																		goto IL_04d0;
																	case 4:
																	case 32:
																	case 33:
																	case 46:
																	case 49:
																	case 54:
																	case 56:
																	case 58:
																	case 70:
																	case 76:
																	case 83:
																		goto end_IL_0197;
																	case 13:
																		goto end_IL_04de;
																	case 29:
																		goto end_IL_04f1;
																	case 37:
																		goto end_IL_04fb;
																	case 20:
																		goto end_IL_0506;
																	case 50:
																		goto end_IL_051b;
																	case 78:
																	case 87:
																		goto end_IL_0530;
																	case 19:
																		goto end_IL_0540;
																	case 22:
																	case 26:
																		goto end_IL_0550;
																	case 30:
																		goto end_IL_0569;
																	case 31:
																		goto end_IL_0579;
																	case 38:
																	case 84:
																		goto IL_059d;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_01ab;
																IL_0481:
																num5--;
																goto end_IL_0197;
																IL_04b4:
																array[num5] = 0;
																goto IL_04c2;
																IL_0491:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04b4;
																IL_01ab:
																ptr2++;
																goto IL_01b9;
																IL_01b9:
																if (b >= 1)
																{
																	goto IL_01c7;
																}
																goto IL_0491;
																IL_01c7:
																if (b <= 8)
																{
																	goto IL_01d5;
																}
																goto IL_0491;
																IL_01d5:
																if (4 < b)
																{
																	goto IL_01e3;
																}
																goto IL_02e9;
																IL_01e3:
																if (6 < b)
																{
																	goto IL_01f1;
																}
																goto IL_02a7;
																IL_01f1:
																if (7 < b)
																{
																	goto IL_01fc;
																}
																goto IL_0234;
																IL_01fc:
																if (8 >= b)
																{
																	goto IL_020a;
																}
																goto IL_0491;
																IL_020a:
																if (8 <= b)
																{
																	goto IL_0218;
																}
																goto IL_0491;
																IL_0218:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_0197;
																IL_0234:
																if (7 <= b)
																{
																	goto IL_0242;
																}
																goto IL_0491;
																IL_0242:
																array[num5] = 0;
																goto IL_0250;
																IL_0250:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																num = 17;
																goto IL_027c;
																IL_027c:
																array2[num5] = null;
																goto IL_0286;
																IL_0286:
																num5++;
																goto IL_0294;
																IL_0294:
																ptr2 += 8;
																goto end_IL_0197;
																IL_02a7:
																if (6 <= b)
																{
																	goto end_IL_0197;
																}
																goto IL_02b5;
																IL_02b5:
																if (5 >= b)
																{
																	goto IL_02c3;
																}
																goto IL_0491;
																IL_02c3:
																if (5 <= b)
																{
																	goto IL_02d1;
																}
																goto IL_0491;
																IL_02d1:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0197;
																IL_02e9:
																if (4 > b)
																{
																	goto IL_02f7;
																}
																goto IL_044a;
																IL_02f7:
																if (2 < b)
																{
																	goto IL_0305;
																}
																num = 8;
																goto IL_0391;
																IL_0305:
																if (3 >= b)
																{
																	goto IL_0313;
																}
																goto IL_0491;
																IL_0313:
																if (3 <= b)
																{
																	goto IL_0321;
																}
																goto IL_0491;
																IL_0321:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0361;
																IL_0361:
																array[num5 - 2] = 0;
																goto IL_0375;
																IL_0375:
																num5--;
																goto end_IL_0197;
																IL_04c2:
																num5++;
																goto IL_04d0;
																IL_0391:
																if (2 <= b)
																{
																	goto IL_039f;
																}
																goto IL_0429;
																IL_039f:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 39;
																goto IL_0416;
																IL_0416:
																num5 -= 2;
																goto end_IL_0197;
																IL_0429:
																if (1 >= b)
																{
																	goto IL_0434;
																}
																goto IL_0491;
																IL_0434:
																if (1 > b)
																{
																	num = 65;
																}
																goto IL_0491;
																IL_04d0:
																ptr2 += 8;
																goto end_IL_0197;
																IL_044a:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0473;
																IL_0473:
																ptr2 += 8;
																goto IL_0481;
																continue;
																end_IL_0187:
																break;
															}
															continue;
															end_IL_0197:
															break;
														}
														continue;
													}
													goto IL_059d;
													IL_059d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04de:
													break;
												}
												continue;
												end_IL_04f1:
												break;
											}
											continue;
											end_IL_04fb:
											break;
										}
										continue;
										end_IL_0506:
										break;
									}
									continue;
									end_IL_051b:
									break;
								}
								continue;
								end_IL_0530:
								break;
							}
							continue;
							end_IL_0540:
							break;
						}
						continue;
						end_IL_0550:
						break;
					}
					continue;
					end_IL_0569:
					break;
				}
				continue;
				end_IL_0579:
				break;
			}
		}
	}

	private static int StlocSsetSharedState(int int_3)
	{
		return smethod_2(int_3);
	}

	private static double KoreanEraEnabledForETW(double double_2)
	{
		return Math.Cos(double_2);
	}

	private static ControllerInputPoller DebuggingFlagsGetUpperBound()
	{
		return ControllerInputPoller.instance;
	}

	private unsafe static int smethod_2(int int_3)
	{
		int num = 6;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CallContextPreviousApplicationIdentity.ReadOnlyPermissionSetEnumeratorgetWindowsIdentity);
										num = 109;
										while (true)
										{
											if (num != 109)
											{
												if (num == 1090)
												{
													switch (num)
													{
													case 101:
														goto end_IL_01c3;
													case 52:
														goto end_IL_01d6;
													case 83:
														goto end_IL_01ea;
													case 12:
													case 91:
														goto end_IL_01ff;
													case 45:
														goto end_IL_020f;
													case 3:
													case 19:
														goto end_IL_021f;
													case 5:
														goto end_IL_022f;
													case 6:
														goto end_IL_023f;
													case 14:
													case 24:
													case 27:
													case 41:
													case 44:
													case 47:
													case 56:
													case 66:
													case 68:
													case 81:
													case 82:
													case 87:
													case 97:
														goto IL_0262;
													case 13:
													case 63:
														goto IL_0272;
													case 57:
														goto IL_027b;
													case 94:
														goto IL_0289;
													case 90:
														goto IL_0297;
													case 37:
														goto IL_02a5;
													case 54:
														goto IL_02b3;
													case 65:
													case 69:
														goto IL_02c1;
													case 61:
														goto IL_02cf;
													case 18:
													case 21:
														goto IL_02da;
													case 55:
														goto IL_0303;
													case 98:
														goto IL_0311;
													case 70:
														goto IL_0324;
													case 53:
														goto IL_0332;
													case 50:
													case 62:
														goto IL_0340;
													case 33:
														goto IL_0359;
													case 74:
														goto IL_0367;
													case 23:
														goto IL_0375;
													case 71:
														goto IL_0388;
													case 89:
														goto IL_0393;
													case 49:
													case 78:
														goto IL_03a1;
													case 40:
													case 60:
														goto IL_03c2;
													case 17:
														goto IL_03d9;
													case 32:
													case 34:
														goto IL_03ec;
													case 2:
														goto IL_0403;
													case 31:
														goto IL_0426;
													case 10:
														goto IL_0430;
													case 51:
														goto IL_043e;
													case 30:
													case 102:
														goto IL_0451;
													case 9:
													case 38:
														goto IL_045c;
													case 88:
														goto IL_0467;
													case 29:
													case 72:
														goto IL_0475;
													case 26:
														goto IL_0491;
													case 36:
														goto IL_049f;
													case 96:
														goto IL_04b2;
													case 42:
													case 100:
														goto IL_04c0;
													case 64:
														goto IL_04cb;
													case 0:
													case 43:
														goto IL_04d9;
													case 39:
														goto IL_0519;
													case 4:
														goto IL_052d;
													case 79:
														goto IL_0540;
													case 75:
														goto IL_054e;
													case 80:
													case 92:
														goto IL_055c;
													case 46:
														goto IL_057f;
													case 48:
														goto IL_058d;
													case 84:
														goto IL_059b;
													case 73:
													case 93:
														goto IL_05ae;
													case 15:
														goto IL_0610;
													case 7:
													case 8:
													case 11:
													case 16:
													case 22:
													case 25:
													case 28:
													case 35:
													case 58:
													case 59:
													case 67:
													case 76:
													case 77:
													case 85:
													case 86:
													case 95:
													case 99:
														goto IL_062c;
													case 1:
													case 20:
														goto IL_0644;
													}
													continue;
												}
											}
											else
											{
												ptr2 = ptr;
											}
											goto IL_0262;
											IL_058d:
											num4++;
											goto IL_059b;
											IL_05ae:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_0610;
											IL_059b:
											ptr2 += 8;
											goto IL_0262;
											IL_0262:
											if (num5 != 1)
											{
												goto IL_0272;
											}
											goto IL_0644;
											IL_0644:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											IL_0272:
											b = *ptr2;
											goto IL_027b;
											IL_027b:
											ptr2++;
											goto IL_0289;
											IL_0289:
											if (b >= 1)
											{
												goto IL_0297;
											}
											goto IL_062c;
											IL_0297:
											if (b <= 10)
											{
												goto IL_02a5;
											}
											goto IL_062c;
											IL_02a5:
											if (5 >= b)
											{
												goto IL_02b3;
											}
											goto IL_0451;
											IL_02b3:
											if (5 > b)
											{
												goto IL_02c1;
											}
											goto IL_03ec;
											IL_02c1:
											if (2 >= b)
											{
												goto IL_02cf;
											}
											goto IL_0388;
											IL_02cf:
											if (2 <= b)
											{
												goto IL_02da;
											}
											goto IL_0324;
											IL_02da:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0303;
											IL_0303:
											ptr2 += 8;
											goto IL_0311;
											IL_0311:
											num4--;
											goto IL_0262;
											IL_0324:
											if (1 >= b)
											{
												goto IL_0332;
											}
											goto IL_062c;
											IL_0332:
											if (1 <= b)
											{
												goto IL_0340;
											}
											goto IL_062c;
											IL_0340:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
											goto IL_0359;
											IL_0359:
											array[num4] = 0;
											goto IL_0367;
											IL_0367:
											num4++;
											goto IL_0375;
											IL_0375:
											ptr2 += 8;
											goto IL_0262;
											IL_0388:
											if (3 >= b)
											{
												goto IL_0393;
											}
											num = 60;
											goto IL_03c2;
											IL_0393:
											if (3 <= b)
											{
												goto IL_03a1;
											}
											goto IL_062c;
											IL_03a1:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0262;
											IL_0610:
											num4 -= 2;
											num = 44;
											goto IL_0262;
											IL_03c2:
											if (4 >= b)
											{
												num = 17;
												goto IL_03d9;
											}
											goto IL_062c;
											IL_062c:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0262;
											IL_03d9:
											if (4 <= b)
											{
												goto IL_0262;
											}
											goto IL_062c;
											IL_03ec:
											array[num4] = 0;
											num = 2;
											goto IL_0403;
											IL_0403:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_0426;
											IL_0426:
											array2[num4] = null;
											goto IL_0430;
											IL_0430:
											num4++;
											goto IL_043e;
											IL_043e:
											ptr2 += 8;
											goto IL_0262;
											IL_0451:
											if (8 < b)
											{
												goto IL_045c;
											}
											goto IL_04b2;
											IL_045c:
											if (9 >= b)
											{
												goto IL_0467;
											}
											goto IL_0491;
											IL_0467:
											if (9 <= b)
											{
												goto IL_0475;
											}
											goto IL_062c;
											IL_0475:
											byte* num6 = ptr2;
											num5 = 1;
											ptr2 = num6 + -200;
											goto IL_0262;
											IL_0491:
											if (10 >= b)
											{
												goto IL_049f;
											}
											goto IL_062c;
											IL_049f:
											if (10 > b)
											{
											}
											goto IL_062c;
											IL_04b2:
											if (8 > b)
											{
												goto IL_04c0;
											}
											goto IL_05ae;
											IL_04c0:
											if (6 >= b)
											{
												goto IL_04cb;
											}
											goto IL_0540;
											IL_04cb:
											if (6 <= b)
											{
												goto IL_04d9;
											}
											goto IL_062c;
											IL_04d9:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0519;
											IL_0519:
											array[num4 - 2] = 0;
											goto IL_052d;
											IL_052d:
											num4--;
											goto IL_0262;
											IL_0540:
											if (7 >= b)
											{
												goto IL_054e;
											}
											goto IL_062c;
											IL_054e:
											if (7 <= b)
											{
												goto IL_055c;
											}
											goto IL_062c;
											IL_055c:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_057f;
											IL_057f:
											array[num4] = 0;
											goto IL_058d;
											continue;
											end_IL_01c3:
											break;
										}
										continue;
										end_IL_01d6:
										break;
									}
									continue;
									end_IL_01ea:
									break;
								}
								continue;
								end_IL_01ff:
								break;
							}
							continue;
							end_IL_020f:
							break;
						}
						continue;
						end_IL_021f:
						break;
					}
					continue;
					end_IL_022f:
					break;
				}
				continue;
				end_IL_023f:
				break;
			}
		}
	}

	private static void GenericTypeParameterBuildergetFieldNames(string string_0)
	{
		BundleManager.smethod_61(string_0);
	}

	private static string DeclaredNestedTypesModifier(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	unsafe static Class173()
	{
		int num = 69;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 77;
					while (true)
					{
						int num2 = 1;
						while (true)
						{
							int num3 = num2 * 4;
							while (true)
							{
								byte[] array = new byte[3];
								while (true)
								{
									object[] array2 = new object[3];
									while (true)
									{
										int[] array3 = new int[3];
										while (true)
										{
											long[] array4 = new long[3];
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCapacitymemid.ApplicationTrustBadHash);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02df:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02af:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_02a2:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_0263:
																										((delegate*<Array, RuntimeFieldHandle, void>)SetCreationTimeIsClosed[*(int*)(ptr2 + num3)])((float[])array2[num5 - 2], (RuntimeFieldHandle)array2[num5 - 1]);
																										while (true)
																										{
																											IL_024a:
																											num5 -= 2;
																											num = 138;
																											while (true)
																											{
																												if (num != 138)
																												{
																													if (num != 1119)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 115:
																														goto IL_024a;
																													case 5:
																													case 18:
																														goto IL_0263;
																													case 49:
																														goto IL_02a2;
																													case 106:
																														goto IL_02af;
																													case 75:
																														goto end_IL_02af;
																													case 60:
																														goto end_IL_02bf;
																													case 89:
																														goto IL_02df;
																													case 83:
																														goto end_IL_02df;
																													case 35:
																													case 110:
																														goto end_IL_02ef;
																													case 93:
																														goto IL_030a;
																													case 33:
																														goto IL_0315;
																													case 34:
																													case 52:
																														goto IL_0323;
																													case 45:
																														goto IL_033b;
																													case 10:
																														goto IL_0359;
																													case 24:
																													case 46:
																														goto IL_037f;
																													case 103:
																														goto IL_039b;
																													case 0:
																														goto IL_03b3;
																													case 108:
																														goto IL_03c6;
																													case 59:
																														goto IL_03d1;
																													case 98:
																													case 116:
																														goto IL_03dc;
																													case 47:
																														goto IL_03f6;
																													case 12:
																													case 120:
																														goto IL_0409;
																													case 97:
																													case 121:
																														goto IL_041c;
																													case 114:
																														goto IL_042a;
																													case 122:
																														goto IL_043d;
																													case 25:
																													case 100:
																														goto IL_0448;
																													case 111:
																														goto IL_0471;
																													case 4:
																													case 90:
																														goto IL_0493;
																													case 2:
																													case 88:
																														goto IL_04a1;
																													case 117:
																														goto IL_04ac;
																													case 20:
																													case 99:
																														goto IL_04ba;
																													case 85:
																														goto IL_04d3;
																													case 87:
																														goto IL_04ea;
																													case 64:
																														goto IL_04f8;
																													case 65:
																														goto IL_050b;
																													case 19:
																														goto IL_0519;
																													case 43:
																													case 109:
																														goto IL_0527;
																													case 92:
																														goto IL_0570;
																													case 27:
																														goto IL_0584;
																													case 56:
																														goto IL_0597;
																													case 54:
																													case 105:
																														goto IL_05a2;
																													case 50:
																													case 107:
																														goto IL_05ad;
																													case 118:
																														goto IL_05bb;
																													case 57:
																													case 70:
																														goto IL_05c9;
																													case 14:
																														goto IL_05de;
																													case 6:
																														goto IL_05f1;
																													case 3:
																													case 104:
																														goto IL_0604;
																													case 31:
																														goto IL_0619;
																													case 95:
																													case 124:
																														goto IL_062c;
																													case 127:
																														goto end_IL_0237;
																													case 128:
																														goto IL_0658;
																													case 17:
																													case 40:
																														goto IL_0663;
																													case 131:
																														goto IL_067c;
																													case 44:
																													case 123:
																														goto IL_0687;
																													case 13:
																														goto IL_069a;
																													case 91:
																														goto IL_06a8;
																													case 1:
																													case 9:
																													case 11:
																													case 15:
																													case 16:
																													case 22:
																													case 29:
																													case 30:
																													case 32:
																													case 36:
																													case 39:
																													case 48:
																													case 63:
																													case 72:
																													case 79:
																													case 80:
																													case 81:
																													case 96:
																													case 101:
																													case 102:
																													case 112:
																													case 113:
																													case 119:
																													case 125:
																													case 129:
																														goto end_IL_02cf;
																													case 126:
																														goto IL_06dd;
																													case 28:
																													case 41:
																													case 51:
																													case 55:
																													case 61:
																													case 62:
																													case 66:
																													case 67:
																													case 71:
																													case 74:
																													case 76:
																													case 82:
																													case 84:
																													case 86:
																														goto end_IL_02ff;
																													case 7:
																														goto end_IL_06eb;
																													case 78:
																														goto end_IL_06fe;
																													case 130:
																														goto end_IL_0708;
																													case 8:
																														goto end_IL_0713;
																													case 37:
																														goto end_IL_0723;
																													case 23:
																													case 38:
																														goto end_IL_0733;
																													case 58:
																														goto end_IL_0743;
																													case 21:
																													case 26:
																													case 77:
																														goto end_IL_0753;
																													case 42:
																													case 53:
																														goto end_IL_0763;
																													case 68:
																														goto end_IL_0774;
																													case 69:
																														goto end_IL_0783;
																													case 73:
																													case 94:
																														return;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto end_IL_02ff;
																												continue;
																												end_IL_0237:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_030a;
																								IL_069a:
																								array[num5] = 4;
																								goto IL_06a8;
																								IL_030a:
																								if (7 >= b)
																								{
																									goto IL_0315;
																								}
																								goto IL_037f;
																								IL_0315:
																								if (7 > b)
																								{
																									goto end_IL_02cf;
																								}
																								goto IL_0323;
																								IL_0323:
																								array[num5] = array[num5 - 1];
																								goto IL_033b;
																								IL_033b:
																								array3[num5 - 0] = array3[num5 - 1];
																								goto IL_0359;
																								IL_0359:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_039b;
																								IL_039b:
																								array2[num5] = array2[num5 - 1];
																								goto IL_03b3;
																								IL_03b3:
																								num5++;
																								goto end_IL_02ff;
																								IL_037f:
																								if (8 < b)
																								{
																									num = 11;
																									goto end_IL_02cf;
																								}
																								goto IL_067c;
																								IL_06a8:
																								num5++;
																								goto end_IL_02ff;
																								IL_067c:
																								if (8 > b)
																								{
																									goto end_IL_02cf;
																								}
																								goto IL_0687;
																								IL_0687:
																								array2[num5] = default(RuntimeFieldHandle);
																								goto IL_069a;
																							}
																							goto IL_0645;
																						}
																						goto IL_03c6;
																						IL_0663:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02ff;
																						IL_03c6:
																						if (11 >= b)
																						{
																							goto IL_03d1;
																						}
																						goto IL_0409;
																						IL_03d1:
																						if (11 <= b)
																						{
																							goto IL_03dc;
																						}
																						goto IL_041c;
																						IL_03dc:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03f6;
																						IL_03f6:
																						num5--;
																						goto end_IL_02ff;
																						IL_041c:
																						if (10 < b)
																						{
																							goto end_IL_02cf;
																						}
																						goto IL_042a;
																						IL_042a:
																						if (10 > b)
																						{
																							goto end_IL_02cf;
																						}
																						goto IL_062c;
																						IL_062c:
																						float_0 = (float[])array2[num5 - 1];
																						goto IL_0645;
																						IL_0645:
																						num5--;
																						goto end_IL_02ff;
																						IL_0409:
																						if (12 < b)
																						{
																							goto end_IL_02cf;
																						}
																						goto IL_0658;
																						IL_0658:
																						if (12 > b)
																						{
																							goto end_IL_02cf;
																						}
																						goto IL_0663;
																						continue;
																						end_IL_02af:
																						break;
																					}
																					continue;
																				}
																				goto IL_043d;
																				IL_0604:
																				((delegate*<void>)SetCreationTimeIsClosed[*(int*)(ptr2 + num3)])();
																				goto IL_0619;
																				IL_043d:
																				if (6 <= b)
																				{
																					goto IL_0448;
																				}
																				num = 4;
																				goto IL_0493;
																				IL_0448:
																				array2[num5 - 1] = new float[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0471;
																				IL_0471:
																				array[num5 - 1] = 5;
																				goto end_IL_02ff;
																				IL_0619:
																				ptr2 += 8;
																				goto end_IL_02ff;
																				IL_0493:
																				if (3 < b)
																				{
																					goto IL_04a1;
																				}
																				goto IL_0597;
																				IL_04a1:
																				if (4 >= b)
																				{
																					goto IL_04ac;
																				}
																				goto IL_050b;
																				IL_04ac:
																				if (4 > b)
																				{
																					goto end_IL_02cf;
																				}
																				goto IL_04ba;
																				IL_04ba:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04d3;
																				IL_04d3:
																				array[num5] = 0;
																				num = 87;
																				goto IL_04ea;
																				IL_04ea:
																				num5++;
																				goto IL_04f8;
																				IL_04f8:
																				ptr2 += 8;
																				goto end_IL_02ff;
																				IL_050b:
																				if (5 < b)
																				{
																					goto end_IL_02cf;
																				}
																				goto IL_0519;
																				IL_0519:
																				if (5 > b)
																				{
																					goto end_IL_02cf;
																				}
																				goto IL_0527;
																				IL_0527:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 92;
																				goto IL_0570;
																				IL_0570:
																				array[num5 - 2] = 0;
																				goto IL_0584;
																				IL_0584:
																				num5--;
																				goto end_IL_02ff;
																				IL_0597:
																				if (3 > b)
																				{
																					goto IL_05a2;
																				}
																				goto IL_0604;
																				IL_05a2:
																				if (1 < b)
																				{
																					goto IL_05ad;
																				}
																				goto IL_05f1;
																				IL_05ad:
																				if (2 < b)
																				{
																					goto end_IL_02cf;
																				}
																				goto IL_05bb;
																				IL_05bb:
																				if (2 > b)
																				{
																					goto end_IL_02cf;
																				}
																				goto IL_05c9;
																				IL_05c9:
																				((delegate*<void>)SetCreationTimeIsClosed[*(int*)(ptr2 + num3)])();
																				goto IL_05de;
																				IL_05de:
																				ptr2 += 8;
																				goto end_IL_02ff;
																				IL_05f1:
																				if (1 > b)
																				{
																				}
																				goto end_IL_02cf;
																				continue;
																				end_IL_02bf:
																				break;
																			}
																			continue;
																			end_IL_02cf:
																			break;
																		}
																	}
																	((delegate*<void>)SetCreationTimeIsClosed[*(int*)(ptr2 + num3)])();
																	goto IL_06dd;
																	IL_06dd:
																	ptr2 += 8;
																	goto end_IL_02ff;
																	continue;
																	end_IL_02df:
																	break;
																}
																continue;
																end_IL_02ef:
																break;
															}
															continue;
															end_IL_02ff:
															break;
														}
														continue;
														end_IL_06eb:
														break;
													}
													continue;
													end_IL_06fe:
													break;
												}
												continue;
												end_IL_0708:
												break;
											}
											continue;
											end_IL_0713:
											break;
										}
										continue;
										end_IL_0723:
										break;
									}
									continue;
									end_IL_0733:
									break;
								}
								continue;
								end_IL_0743:
								break;
							}
							continue;
							end_IL_0753:
							break;
						}
						continue;
						end_IL_0763:
						break;
					}
					continue;
					end_IL_0774:
					break;
				}
				continue;
				end_IL_0783:
				break;
			}
		}
	}

	private static double StoreDeploymentMetadataPropertyEnumerationTypeEntry(double double_2)
	{
		return Math.Sqrt(double_2);
	}

	public Class173()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static float ReportGetMonth(Class173 class173_1)
	{
		return class173_1.float_2;
	}

	private unsafe static int smethod_3(int int_3, int int_4)
	{
		int num = 90;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getTickCountsetFailedAssemblyInfo.ProbeForSufficientStackControlEvidence);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0278:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0258:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_024b:
																						if (9 < b)
																						{
																							while (true)
																							{
																								IL_023b:
																								if (10 < b)
																								{
																									while (11 >= b)
																									{
																										while (true)
																										{
																											IL_0218:
																											if (11 > b)
																											{
																												num = 122;
																												while (num != 122)
																												{
																													if (num != 1103)
																													{
																														goto IL_0319;
																													}
																													switch (num)
																													{
																													case 38:
																														goto IL_0218;
																													case 11:
																														goto IL_022b;
																													case 2:
																														goto IL_023b;
																													case 85:
																														goto IL_024b;
																													case 65:
																														goto IL_0258;
																													case 61:
																														goto IL_0268;
																													case 34:
																														goto IL_0278;
																													case 39:
																														goto end_IL_0278;
																													case 56:
																													case 108:
																														goto end_IL_0288;
																													case 58:
																														goto IL_02a3;
																													case 22:
																													case 53:
																														goto IL_02b1;
																													case 30:
																														goto IL_02c5;
																													case 28:
																														goto IL_0319;
																													case 20:
																														goto IL_0327;
																													case 7:
																														goto IL_033a;
																													case 32:
																														goto IL_0345;
																													case 15:
																													case 49:
																														goto IL_0353;
																													case 36:
																													case 67:
																														goto IL_0382;
																													case 78:
																														goto IL_039e;
																													case 35:
																													case 81:
																														goto IL_03ba;
																													case 82:
																														goto IL_03ca;
																													case 87:
																														goto IL_03dd;
																													case 5:
																													case 88:
																														goto IL_03eb;
																													case 14:
																														goto IL_042b;
																													case 40:
																														goto IL_043f;
																													case 98:
																														goto IL_0452;
																													case 42:
																														goto IL_0460;
																													case 95:
																													case 113:
																														goto IL_0473;
																													case 96:
																														goto IL_0486;
																													case 26:
																													case 60:
																														goto IL_0491;
																													case 70:
																														goto IL_04d1;
																													case 23:
																														goto IL_04e5;
																													case 110:
																														goto IL_04f8;
																													case 106:
																														goto IL_0506;
																													case 114:
																														goto IL_0514;
																													case 91:
																														goto IL_0522;
																													case 41:
																														goto IL_0530;
																													case 16:
																													case 77:
																														goto IL_053e;
																													case 68:
																														goto IL_057e;
																													case 76:
																														goto IL_0592;
																													case 79:
																														goto IL_05a5;
																													case 64:
																													case 115:
																														goto IL_05b8;
																													case 48:
																														goto IL_05e1;
																													case 43:
																														goto IL_05ef;
																													case 69:
																														goto IL_060b;
																													case 37:
																														goto IL_0616;
																													case 102:
																														goto IL_0624;
																													case 92:
																													case 112:
																														goto IL_0632;
																													case 107:
																														goto IL_0640;
																													case 47:
																														goto IL_0663;
																													case 100:
																														goto IL_066d;
																													case 63:
																														goto IL_067b;
																													case 25:
																														goto IL_068e;
																													case 94:
																													case 97:
																														goto IL_06a2;
																													case 44:
																														goto IL_06e2;
																													case 8:
																														goto IL_06f6;
																													case 4:
																													case 6:
																													case 12:
																													case 13:
																													case 17:
																													case 29:
																													case 45:
																													case 50:
																													case 51:
																													case 52:
																													case 54:
																													case 55:
																													case 71:
																													case 74:
																													case 80:
																													case 99:
																													case 105:
																													case 111:
																														goto end_IL_0205;
																													case 75:
																														goto IL_0729;
																													case 3:
																														goto IL_0737;
																													case 1:
																														goto IL_0745;
																													case 0:
																													case 10:
																													case 18:
																													case 21:
																													case 24:
																													case 31:
																													case 46:
																													case 57:
																													case 59:
																													case 66:
																													case 72:
																													case 73:
																													case 83:
																														goto end_IL_0298;
																													case 86:
																														goto end_IL_0753;
																													case 33:
																														goto end_IL_0766;
																													case 27:
																														goto end_IL_0770;
																													case 103:
																														goto end_IL_077b;
																													case 101:
																														goto end_IL_0790;
																													case 9:
																													case 19:
																														goto end_IL_07a5;
																													case 104:
																														goto end_IL_07b5;
																													case 62:
																													case 93:
																														goto end_IL_07c5;
																													case 89:
																														goto end_IL_07d5;
																													case 90:
																														goto end_IL_07e5;
																													case 84:
																													case 109:
																														goto IL_0800;
																													}
																													continue;
																													end_IL_0205:
																													break;
																												}
																												break;
																											}
																											goto IL_0382;
																											IL_0382:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											goto end_IL_0298;
																										}
																										break;
																										IL_022b:;
																									}
																									break;
																								}
																								goto IL_03ca;
																								IL_0473:
																								num6--;
																								goto end_IL_0298;
																								IL_03ca:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0473;
																							}
																							break;
																						}
																						goto IL_02a3;
																						IL_042b:
																						array[num6 - 2] = 0;
																						goto IL_043f;
																						IL_02a3:
																						if (9 <= b)
																						{
																							goto IL_02b1;
																						}
																						goto IL_033a;
																						IL_02b1:
																						array[num6 - 2] = 0;
																						goto IL_02c5;
																						IL_02c5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)IsClosedActor[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0319;
																						IL_0319:
																						num6--;
																						goto IL_0327;
																						IL_0327:
																						ptr2 += 8;
																						goto end_IL_0298;
																						IL_033a:
																						if (7 >= b)
																						{
																							goto IL_0345;
																						}
																						num = 35;
																						goto IL_03ba;
																						IL_0345:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0353;
																						IL_0353:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						num = 78;
																						goto IL_039e;
																						IL_039e:
																						array[num6] = 0;
																						num = 98;
																						goto IL_0452;
																						IL_0452:
																						num6++;
																						goto IL_0460;
																						IL_0460:
																						ptr2 += 8;
																						goto end_IL_0298;
																						IL_043f:
																						num6--;
																						goto end_IL_0298;
																						IL_03ba:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_03dd;
																						IL_03dd:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_03eb;
																						IL_03eb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_042b;
																					}
																					break;
																				}
																				goto IL_0486;
																				IL_06e2:
																				array[num6 - 2] = 0;
																				goto IL_06f6;
																				IL_0486:
																				if (6 <= b)
																				{
																					goto IL_0491;
																				}
																				goto IL_04f8;
																				IL_0491:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04d1;
																				IL_04d1:
																				array[num6 - 2] = 0;
																				goto IL_04e5;
																				IL_04e5:
																				num6--;
																				goto end_IL_0298;
																				IL_04f8:
																				if (3 >= b)
																				{
																					goto IL_0506;
																				}
																				goto IL_060b;
																				IL_0506:
																				if (3 > b)
																				{
																					goto IL_0514;
																				}
																				goto IL_05b8;
																				IL_0514:
																				if (1 < b)
																				{
																					goto IL_0522;
																				}
																				goto IL_05a5;
																				IL_0522:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0530;
																				IL_0530:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_053e;
																				IL_053e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_057e;
																				IL_057e:
																				array[num6 - 2] = 0;
																				goto IL_0592;
																				IL_0592:
																				num6--;
																				goto end_IL_0298;
																				IL_05a5:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_05b8:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_05e1;
																				IL_05e1:
																				ptr2 += 8;
																				goto IL_05ef;
																				IL_05ef:
																				num6--;
																				num = 73;
																				goto end_IL_0298;
																				IL_060b:
																				if (4 < b)
																				{
																					goto IL_0616;
																				}
																				goto IL_068e;
																				IL_0616:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0624;
																				IL_0624:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0632;
																				IL_0632:
																				array[num6] = 0;
																				goto IL_0640;
																				IL_0640:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0663;
																				IL_0663:
																				array2[num6] = null;
																				goto IL_066d;
																				IL_066d:
																				num6++;
																				goto IL_067b;
																				IL_067b:
																				ptr2 += 8;
																				goto end_IL_0298;
																				IL_068e:
																				if (4 > b)
																				{
																					break;
																				}
																				num = 97;
																				goto IL_06a2;
																				IL_06f6:
																				num6--;
																				goto end_IL_0298;
																				IL_06a2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_06e2;
																			}
																			break;
																			IL_0268:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0729;
																	IL_0745:
																	ptr2 += 8;
																	goto end_IL_0298;
																	IL_0737:
																	num6++;
																	goto IL_0745;
																	IL_0729:
																	array[num6] = 0;
																	goto IL_0737;
																	continue;
																	end_IL_0278:
																	break;
																}
																continue;
																end_IL_0288:
																break;
															}
															continue;
															end_IL_0298:
															break;
														}
														continue;
													}
													goto IL_0800;
													IL_0800:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0753:
													break;
												}
												continue;
												end_IL_0766:
												break;
											}
											continue;
											end_IL_0770:
											break;
										}
										continue;
										end_IL_077b:
										break;
									}
									continue;
									end_IL_0790:
									break;
								}
								continue;
								end_IL_07a5:
								break;
							}
							continue;
							end_IL_07b5:
							break;
						}
						continue;
						end_IL_07c5:
						break;
					}
					continue;
					end_IL_07d5:
					break;
				}
				continue;
				end_IL_07e5:
				break;
			}
		}
	}

	private static float UnsafeValueTypeAttributeSerTrace()
	{
		return Time.time;
	}

	private static string DispatchWrapperTypeEmitCall(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static float GetSourceLineInfoDelegateHandleToInfo(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.rightControllerIndexFloat;
	}

	private static double ThrowOnUnmappableCharDisabledgetKeys(double double_2)
	{
		return Math.Truncate(double_2);
	}

	private static float GetNamespacesTypeInitializationException(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerIndexFloat;
	}

	private static string getSaltStoreOperationPinDeployment(ref float float_3, string string_0)
	{
		return float_3.ToString(string_0);
	}

	private static int stringBuilderGetHashFromAssemblyFileW(double double_2)
	{
		return Convert.ToInt32(double_2);
	}

	private unsafe void Update()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					IL_00b0:
					num3 = 0;
					while (true)
					{
						IL_00a5:
						if (num3 == 37)
						{
							while (true)
							{
								IL_0097:
								num3 = 0;
								num = 14;
								while (true)
								{
									if (num != 14)
									{
										if (num != 995)
										{
											break;
										}
										switch (num)
										{
										case 4:
											break;
										default:
											continue;
										case 2:
											goto IL_0097;
										case 5:
										case 6:
											goto IL_00a5;
										case 7:
											goto IL_00b0;
										case 0:
											goto end_IL_008a;
										case 1:
											goto end_IL_00b5;
										case 3:
											return;
										}
										goto IL_000e;
									}
									return;
									continue;
									end_IL_008a:
									break;
								}
								break;
							}
							break;
						}
						goto IL_000e;
						IL_000e:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, Class173, void>)TokenRestrictedDeviceClaimAttributesSpinWait[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref num11, this);
					}
					break;
				}
				continue;
				end_IL_00b5:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 52;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 86;
								while (true)
								{
									int[] array3 = new int[5];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											array3[0] = int_3;
											num = 90;
											while (true)
											{
												array3[1] = int_4;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ISerializationSurrogatesetExecution.FUNCFLAGFREQUESTEDITSetSetMethod);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num4 != 1)
															{
																while (true)
																{
																	byte b = *ptr2;
																	num = 112;
																	while (true)
																	{
																		if (num != 112)
																		{
																			if (num != 1093)
																			{
																				goto IL_021d;
																			}
																			switch (num)
																			{
																			case 70:
																			case 105:
																				goto end_IL_01cf;
																			case 43:
																				goto IL_0201;
																			case 88:
																				goto IL_020f;
																			case 37:
																				goto IL_021d;
																			case 66:
																				goto IL_022b;
																			case 16:
																			case 19:
																				goto IL_0236;
																			case 30:
																				goto IL_0244;
																			case 93:
																				goto IL_0267;
																			case 61:
																				goto IL_0271;
																			case 46:
																				goto IL_027f;
																			case 6:
																				goto IL_029b;
																			case 32:
																				goto IL_02a9;
																			case 79:
																			case 101:
																				goto IL_02b4;
																			case 94:
																				goto IL_02c2;
																			case 38:
																			case 74:
																				goto IL_02d5;
																			case 21:
																				goto IL_0315;
																			case 82:
																				goto IL_0329;
																			case 3:
																			case 72:
																				goto IL_034e;
																			case 48:
																			case 104:
																				goto IL_035c;
																			case 25:
																				goto IL_036a;
																			case 0:
																			case 102:
																				goto IL_0378;
																			case 81:
																				goto IL_03b8;
																			case 76:
																				goto IL_03cc;
																			case 49:
																				goto IL_03df;
																			case 55:
																			case 89:
																				goto IL_03f6;
																			case 36:
																				goto IL_041f;
																			case 23:
																				goto IL_042d;
																			case 18:
																				goto IL_0440;
																			case 29:
																				goto IL_044e;
																			case 8:
																			case 85:
																				goto IL_045c;
																			case 69:
																				goto IL_046a;
																			case 10:
																			case 34:
																				goto IL_0478;
																			case 4:
																				goto IL_04b8;
																			case 27:
																				goto IL_04cc;
																			case 20:
																			case 62:
																				goto IL_04df;
																			case 45:
																				goto IL_04f8;
																			case 50:
																				goto IL_0506;
																			case 64:
																				goto IL_0514;
																			case 92:
																				goto IL_0527;
																			case 13:
																			case 33:
																				goto IL_0532;
																			case 35:
																				goto IL_0549;
																			case 68:
																			case 87:
																				goto IL_0557;
																			case 58:
																				goto IL_0573;
																			case 42:
																			case 56:
																				goto IL_057e;
																			case 51:
																				goto IL_05be;
																			case 9:
																				goto IL_05d2;
																			case 5:
																			case 7:
																			case 11:
																			case 17:
																			case 39:
																			case 40:
																			case 44:
																			case 47:
																			case 53:
																			case 54:
																			case 60:
																			case 65:
																			case 80:
																			case 83:
																			case 91:
																			case 95:
																			case 99:
																			case 103:
																				goto IL_05e2;
																			case 59:
																				goto IL_0605;
																			case 22:
																				goto IL_061c;
																			case 14:
																				goto IL_062a;
																			case 1:
																			case 12:
																			case 15:
																			case 26:
																			case 63:
																			case 67:
																			case 71:
																			case 77:
																			case 78:
																			case 84:
																			case 100:
																				goto end_IL_01df;
																			case 98:
																				goto end_IL_0638;
																			case 28:
																				goto end_IL_064b;
																			case 90:
																				goto end_IL_0655;
																			case 2:
																				goto end_IL_0660;
																			case 31:
																				goto end_IL_0675;
																			case 86:
																				goto end_IL_0693;
																			case 24:
																				goto end_IL_06a3;
																			case 73:
																				goto end_IL_06b3;
																			case 52:
																				goto end_IL_06be;
																			case 57:
																				goto end_IL_06ce;
																			case 96:
																				goto end_IL_06de;
																			case 97:
																				goto end_IL_06e9;
																			case 41:
																			case 75:
																				goto IL_0704;
																			}
																			continue;
																		}
																		ptr2++;
																		goto IL_0201;
																		IL_05be:
																		array[num5 - 2] = 0;
																		goto IL_05d2;
																		IL_05e2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0605;
																		IL_05d2:
																		num5--;
																		goto end_IL_01df;
																		IL_0201:
																		if (b >= 1)
																		{
																			goto IL_020f;
																		}
																		goto IL_05e2;
																		IL_020f:
																		if (b <= 9)
																		{
																			goto IL_021d;
																		}
																		goto IL_05e2;
																		IL_021d:
																		if (5 >= b)
																		{
																			goto IL_022b;
																		}
																		goto IL_0440;
																		IL_022b:
																		if (5 <= b)
																		{
																			goto IL_0236;
																		}
																		goto IL_029b;
																		IL_0236:
																		array[num5] = 0;
																		goto IL_0244;
																		IL_0244:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0267;
																		IL_0267:
																		array2[num5] = null;
																		goto IL_0271;
																		IL_0271:
																		num5++;
																		goto IL_027f;
																		IL_027f:
																		ptr2 += 8;
																		num = 78;
																		goto end_IL_01df;
																		IL_029b:
																		if (2 >= b)
																		{
																			goto IL_02a9;
																		}
																		num = 3;
																		goto IL_034e;
																		IL_02a9:
																		if (2 > b)
																		{
																			goto IL_02b4;
																		}
																		goto IL_02d5;
																		IL_02b4:
																		if (1 >= b)
																		{
																			goto IL_02c2;
																		}
																		goto IL_05e2;
																		IL_02c2:
																		if (1 <= b)
																		{
																		}
																		goto IL_05e2;
																		IL_02d5:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0315;
																		IL_0315:
																		array[num5 - 2] = 0;
																		goto IL_0329;
																		IL_0329:
																		num5--;
																		num = 15;
																		goto end_IL_01df;
																		IL_0605:
																		array[num5] = 0;
																		num = 22;
																		goto IL_061c;
																		IL_034e:
																		if (3 < b)
																		{
																			goto IL_035c;
																		}
																		goto IL_03df;
																		IL_035c:
																		if (4 >= b)
																		{
																			goto IL_036a;
																		}
																		goto IL_05e2;
																		IL_036a:
																		if (4 <= b)
																		{
																			goto IL_0378;
																		}
																		goto IL_05e2;
																		IL_0378:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_03b8;
																		IL_03b8:
																		array[num5 - 2] = 0;
																		goto IL_03cc;
																		IL_03cc:
																		num5--;
																		goto end_IL_01df;
																		IL_03df:
																		if (3 <= b)
																		{
																			num = 89;
																			goto IL_03f6;
																		}
																		goto IL_05e2;
																		IL_061c:
																		num5++;
																		goto IL_062a;
																		IL_03f6:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_041f;
																		IL_041f:
																		ptr2 += 8;
																		goto IL_042d;
																		IL_042d:
																		num5--;
																		goto end_IL_01df;
																		IL_0440:
																		if (7 >= b)
																		{
																			goto IL_044e;
																		}
																		goto IL_0527;
																		IL_044e:
																		if (7 > b)
																		{
																			goto IL_045c;
																		}
																		goto IL_04df;
																		IL_045c:
																		if (6 >= b)
																		{
																			goto IL_046a;
																		}
																		goto IL_05e2;
																		IL_046a:
																		if (6 <= b)
																		{
																			goto IL_0478;
																		}
																		goto IL_05e2;
																		IL_0478:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04b8;
																		IL_04b8:
																		array[num5 - 2] = 0;
																		goto IL_04cc;
																		IL_04cc:
																		num5--;
																		goto end_IL_01df;
																		IL_04df:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_04f8;
																		IL_04f8:
																		array[num5] = 0;
																		goto IL_0506;
																		IL_0506:
																		num5++;
																		goto IL_0514;
																		IL_0514:
																		ptr2 += 8;
																		goto end_IL_01df;
																		IL_0527:
																		if (8 < b)
																		{
																			goto IL_0532;
																		}
																		goto IL_0573;
																		IL_0532:
																		if (9 >= b)
																		{
																			num = 35;
																			goto IL_0549;
																		}
																		goto IL_05e2;
																		IL_062a:
																		ptr2 += 8;
																		goto end_IL_01df;
																		IL_0549:
																		if (9 <= b)
																		{
																			goto IL_0557;
																		}
																		goto IL_05e2;
																		IL_0557:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto end_IL_01df;
																		IL_0573:
																		if (8 <= b)
																		{
																			goto IL_057e;
																		}
																		goto IL_05e2;
																		IL_057e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05be;
																		continue;
																		end_IL_01cf:
																		break;
																	}
																	continue;
																	end_IL_01df:
																	break;
																}
																continue;
															}
															goto IL_0704;
															IL_0704:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															continue;
															end_IL_0638:
															break;
														}
														continue;
														end_IL_064b:
														break;
													}
													continue;
													end_IL_0655:
													break;
												}
												continue;
												end_IL_0660:
												break;
											}
											continue;
											end_IL_0675:
											break;
										}
										continue;
										end_IL_0693:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b3:
								break;
							}
							continue;
							end_IL_06be:
							break;
						}
						continue;
						end_IL_06ce:
						break;
					}
					continue;
					end_IL_06de:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private static double VarArgsFilterLevel(double double_2)
	{
		return Math.Sin(double_2);
	}

	private static float DefaultMemberAttributeSorterObjectArray(Class173 class173_1)
	{
		return class173_1.float_1;
	}

	private static float MetadataSectionLocalPathStartEntity()
	{
		return global::_003CModule_003E.float_109;
	}

	private unsafe static int smethod_6(int int_3)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsVerifiedgetTreatControlCAsInput.WrapIUnknownWithComObjectNoError);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0309:
														byte b = *ptr2;
														while (true)
														{
															IL_02f9:
															ptr2++;
															while (true)
															{
																IL_02e9:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02cc:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02bc:
																					if (7 <= b)
																					{
																						while (true)
																						{
																							IL_0297:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							while (true)
																							{
																								IL_0287:
																								array[num5] = 0;
																								while (true)
																								{
																									IL_0277:
																									num5++;
																									while (true)
																									{
																										IL_025e:
																										ptr2 += 8;
																										num = 143;
																										while (num != 143)
																										{
																											if (num != 1124)
																											{
																												goto IL_0353;
																											}
																											switch (num)
																											{
																											case 44:
																												goto IL_025e;
																											case 114:
																												goto IL_0277;
																											case 130:
																												goto IL_0287;
																											case 121:
																											case 125:
																												goto IL_0297;
																											case 106:
																												goto IL_02bc;
																											case 101:
																												goto IL_02cc;
																											case 45:
																												goto IL_02d9;
																											case 47:
																												goto IL_02e9;
																											case 124:
																												goto IL_02f9;
																											case 34:
																											case 79:
																												goto IL_0309;
																											case 53:
																											case 82:
																												goto IL_0314;
																											case 77:
																												goto IL_0322;
																											case 29:
																											case 50:
																												goto IL_032d;
																											case 72:
																											case 87:
																												goto IL_0343;
																											case 103:
																												goto IL_0353;
																											case 107:
																												goto IL_03ac;
																											case 65:
																											case 84:
																												goto IL_03ba;
																											case 1:
																												goto IL_041c;
																											case 68:
																											case 108:
																												goto IL_042f;
																											case 35:
																												goto IL_043a;
																											case 5:
																											case 71:
																												goto IL_0445;
																											case 8:
																											case 26:
																												goto IL_045d;
																											case 51:
																											case 93:
																												goto IL_0468;
																											case 81:
																												goto IL_0476;
																											case 96:
																												goto IL_0489;
																											case 18:
																											case 36:
																												goto IL_0497;
																											case 10:
																												goto IL_04a2;
																											case 73:
																											case 118:
																												goto IL_04c3;
																											case 22:
																											case 94:
																												goto IL_04ce;
																											case 64:
																												goto IL_04dc;
																											case 67:
																												goto IL_04ec;
																											case 76:
																											case 98:
																												goto IL_04fa;
																											case 16:
																												goto IL_0513;
																											case 91:
																												goto IL_0521;
																											case 85:
																												goto IL_052f;
																											case 78:
																											case 122:
																												goto IL_0542;
																											case 21:
																												goto IL_0574;
																											case 116:
																												goto IL_0582;
																											case 54:
																											case 126:
																												goto IL_0595;
																											case 23:
																												goto IL_05a3;
																											case 41:
																												goto IL_05c6;
																											case 129:
																												goto IL_05d0;
																											case 19:
																												goto IL_05de;
																											case 132:
																												goto IL_05f1;
																											case 86:
																												goto IL_05ff;
																											case 55:
																											case 95:
																												goto IL_0618;
																											case 56:
																												goto IL_0658;
																											case 102:
																												goto IL_0675;
																											case 24:
																											case 133:
																												goto IL_0688;
																											case 70:
																												goto IL_0693;
																											case 30:
																											case 31:
																												goto IL_069e;
																											case 7:
																												goto IL_06ac;
																											case 61:
																											case 104:
																												goto IL_06ba;
																											case 74:
																											case 83:
																												goto IL_06cd;
																											case 37:
																												goto IL_06e9;
																											case 17:
																												goto IL_06f7;
																											case 134:
																												goto IL_070a;
																											case 112:
																												goto IL_0718;
																											case 80:
																											case 135:
																												goto IL_0731;
																											case 127:
																												goto IL_0771;
																											case 97:
																												goto IL_0785;
																											case 0:
																											case 3:
																											case 6:
																											case 15:
																											case 28:
																											case 32:
																											case 33:
																											case 38:
																											case 39:
																											case 40:
																											case 49:
																											case 52:
																											case 57:
																											case 58:
																											case 59:
																											case 66:
																											case 75:
																											case 89:
																											case 92:
																											case 100:
																											case 110:
																											case 111:
																											case 117:
																											case 119:
																											case 123:
																											case 131:
																												goto end_IL_02d9;
																											case 2:
																											case 9:
																											case 11:
																											case 14:
																											case 20:
																											case 25:
																											case 48:
																											case 60:
																											case 69:
																											case 88:
																											case 90:
																											case 105:
																											case 109:
																											case 120:
																											case 136:
																												goto end_IL_024b;
																											case 13:
																												goto end_IL_07a8;
																											case 113:
																												goto end_IL_07bb;
																											case 128:
																												goto end_IL_07c5;
																											case 4:
																												goto end_IL_07d0;
																											case 27:
																											case 42:
																												goto end_IL_07e5;
																											case 43:
																												goto end_IL_07f5;
																											case 46:
																											case 99:
																												goto end_IL_0805;
																											case 62:
																												goto end_IL_0815;
																											case 63:
																												goto end_IL_0825;
																											case 12:
																											case 115:
																												goto IL_0840;
																											}
																											continue;
																											end_IL_024b:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_042f;
																					IL_05d0:
																					num5++;
																					goto IL_05de;
																					IL_042f:
																					if (3 >= b)
																					{
																						goto IL_043a;
																					}
																					goto IL_045d;
																					IL_043a:
																					if (3 <= b)
																					{
																						goto IL_0445;
																					}
																					goto IL_04c3;
																					IL_0445:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_04c3:
																					if (1 < b)
																					{
																						goto IL_04ce;
																					}
																					goto IL_04ec;
																					IL_04ce:
																					if (2 < b)
																					{
																						goto end_IL_02d9;
																					}
																					goto IL_04dc;
																					IL_04dc:
																					if (2 > b)
																					{
																						goto end_IL_02d9;
																					}
																					goto IL_0542;
																					IL_0542:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 21;
																					goto IL_0574;
																					IL_0574:
																					ptr2 += 8;
																					goto IL_0582;
																					IL_0582:
																					num5--;
																					break;
																					IL_04ec:
																					if (1 > b)
																					{
																						goto end_IL_02d9;
																					}
																					goto IL_04fa;
																					IL_04fa:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0513;
																					IL_0513:
																					array[num5] = 0;
																					goto IL_0521;
																					IL_0521:
																					num5++;
																					goto IL_052f;
																					IL_052f:
																					ptr2 += 8;
																					break;
																					IL_045d:
																					if (5 < b)
																					{
																						goto IL_0468;
																					}
																					goto IL_0489;
																					IL_0468:
																					if (6 < b)
																					{
																						goto end_IL_02d9;
																					}
																					goto IL_0476;
																					IL_0476:
																					if (6 > b)
																					{
																						goto end_IL_02d9;
																					}
																					goto IL_0731;
																					IL_0731:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0771;
																					IL_0771:
																					array[num5 - 2] = 0;
																					goto IL_0785;
																					IL_0785:
																					num5--;
																					break;
																					IL_0489:
																					if (5 > b)
																					{
																						goto IL_0497;
																					}
																					goto IL_0595;
																					IL_0497:
																					if (4 < b)
																					{
																						num = 89;
																						goto end_IL_02d9;
																					}
																					goto IL_04a2;
																					IL_04a2:
																					if (4 <= b)
																					{
																						break;
																					}
																					goto end_IL_02d9;
																					IL_05de:
																					ptr2 += 8;
																					break;
																					IL_0595:
																					array[num5] = 0;
																					goto IL_05a3;
																					IL_05a3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05c6;
																					IL_05c6:
																					array2[num5] = null;
																					goto IL_05d0;
																				}
																				break;
																			}
																			goto IL_0314;
																			IL_06e9:
																			if (13 < b)
																			{
																				goto end_IL_02d9;
																			}
																			goto IL_06f7;
																			IL_0314:
																			if (10 >= b)
																			{
																				goto IL_0322;
																			}
																			goto IL_0688;
																			IL_0322:
																			if (10 <= b)
																			{
																				goto IL_032d;
																			}
																			goto IL_0343;
																			IL_032d:
																			array[num5 - 2] = 0;
																			goto IL_0353;
																			IL_0353:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AddChannelEventCacheEntry[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_070a;
																			IL_070a:
																			num5--;
																			goto IL_0718;
																			IL_0718:
																			ptr2 += 8;
																			num = 105;
																			break;
																			IL_0343:
																			if (8 >= b)
																			{
																				goto IL_03ac;
																			}
																			goto IL_05f1;
																			IL_03ac:
																			if (8 > b)
																			{
																				goto end_IL_02d9;
																			}
																			goto IL_03ba;
																			IL_03ba:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_041c;
																			IL_041c:
																			num5 -= 2;
																			break;
																			IL_05f1:
																			if (9 < b)
																			{
																				goto end_IL_02d9;
																			}
																			goto IL_05ff;
																			IL_05ff:
																			if (9 > b)
																			{
																				num = 33;
																				goto end_IL_02d9;
																			}
																			goto IL_0618;
																			IL_06f7:
																			if (13 <= b)
																			{
																			}
																			goto end_IL_02d9;
																			IL_0618:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0658;
																			IL_0658:
																			array[num5 - 2] = 0;
																			num = 102;
																			goto IL_0675;
																			IL_0675:
																			num5--;
																			break;
																			IL_0688:
																			if (12 >= b)
																			{
																				goto IL_0693;
																			}
																			goto IL_06e9;
																			IL_0693:
																			if (12 > b)
																			{
																				goto IL_069e;
																			}
																			goto IL_06cd;
																			IL_069e:
																			if (11 < b)
																			{
																				goto end_IL_02d9;
																			}
																			goto IL_06ac;
																			IL_06ac:
																			if (11 > b)
																			{
																				goto end_IL_02d9;
																			}
																			goto IL_06ba;
																			IL_06ba:
																			num5--;
																			break;
																			IL_06cd:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																		}
																		goto end_IL_02e9;
																		continue;
																		end_IL_02d9:
																		break;
																		IL_02d9:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02e9:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0840;
												IL_0840:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07a8:
												break;
											}
											continue;
											end_IL_07bb:
											break;
										}
										continue;
										end_IL_07c5:
										break;
									}
									continue;
									end_IL_07d0:
									break;
								}
								continue;
								end_IL_07e5:
								break;
							}
							continue;
							end_IL_07f5:
							break;
						}
						continue;
						end_IL_0805:
						break;
					}
					continue;
					end_IL_0815:
					break;
				}
				continue;
				end_IL_0825:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 20;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									num = 76;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RemotingExceptionServiceSid.LdfldaGetUnderlyingType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	if (b >= 1)
																	{
																		while (true)
																		{
																			if (b <= 8)
																			{
																				while (true)
																				{
																					if (4 >= b)
																					{
																						num = 92;
																						while (true)
																						{
																							if (num != 92)
																							{
																								if (num == 1073)
																								{
																									switch (num)
																									{
																									case 10:
																										goto end_IL_018d;
																									case 27:
																										goto end_IL_019d;
																									case 81:
																										goto end_IL_01b0;
																									case 29:
																										goto end_IL_01c0;
																									case 16:
																									case 18:
																										goto end_IL_01d0;
																									case 11:
																									case 42:
																										goto IL_01f9;
																									case 78:
																										goto IL_0207;
																									case 30:
																										goto IL_0212;
																									case 58:
																										goto IL_0220;
																									case 44:
																									case 75:
																										goto IL_0233;
																									case 73:
																										goto IL_02aa;
																									case 74:
																										goto IL_02c6;
																									case 9:
																										goto IL_02d4;
																									case 12:
																									case 13:
																										goto IL_02e2;
																									case 21:
																										goto IL_0322;
																									case 28:
																										goto IL_0336;
																									case 22:
																									case 65:
																										goto IL_0349;
																									case 2:
																										goto IL_0372;
																									case 38:
																										goto IL_0380;
																									case 56:
																										goto IL_0393;
																									case 49:
																										goto IL_039e;
																									case 47:
																										goto IL_03ac;
																									case 26:
																										goto IL_03ba;
																									case 41:
																									case 84:
																										goto IL_03c8;
																									case 35:
																										goto IL_03e0;
																									case 37:
																										goto IL_03eb;
																									case 64:
																										goto IL_03f9;
																									case 48:
																									case 50:
																										goto IL_0407;
																									case 71:
																										goto IL_0423;
																									case 6:
																									case 32:
																										goto IL_042e;
																									case 39:
																										goto IL_043c;
																									case 43:
																										goto IL_045f;
																									case 69:
																										goto IL_0469;
																									case 57:
																										goto IL_0477;
																									case 0:
																									case 3:
																									case 5:
																									case 15:
																									case 31:
																									case 36:
																									case 40:
																									case 51:
																									case 52:
																									case 53:
																									case 54:
																									case 61:
																									case 66:
																									case 70:
																									case 82:
																									case 83:
																										goto IL_0490;
																									case 7:
																										goto IL_04b3;
																									case 59:
																										goto IL_04c1;
																									case 23:
																										goto IL_04cf;
																									case 1:
																									case 14:
																									case 24:
																									case 25:
																									case 45:
																									case 46:
																									case 63:
																									case 67:
																									case 72:
																									case 77:
																									case 79:
																										goto end_IL_01e0;
																									case 17:
																										goto end_IL_04dd;
																									case 60:
																										goto end_IL_04f0;
																									case 76:
																										goto end_IL_04fa;
																									case 34:
																										goto end_IL_0505;
																									case 55:
																										goto end_IL_051a;
																									case 8:
																									case 85:
																										goto end_IL_0538;
																									case 33:
																										goto end_IL_0548;
																									case 4:
																									case 68:
																										goto end_IL_0558;
																									case 19:
																										goto end_IL_0568;
																									case 20:
																										goto end_IL_0578;
																									case 62:
																									case 80:
																										goto IL_0593;
																									}
																									continue;
																								}
																							}
																							else if (4 <= b)
																							{
																								goto IL_0349;
																							}
																							goto IL_01f9;
																							IL_0349:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0372;
																							IL_0380:
																							num5--;
																							goto end_IL_01e0;
																							IL_0372:
																							ptr2 += 8;
																							goto IL_0380;
																							IL_01f9:
																							if (2 >= b)
																							{
																								goto IL_0207;
																							}
																							goto IL_02c6;
																							IL_0207:
																							if (2 > b)
																							{
																								goto IL_0212;
																							}
																							goto IL_0233;
																							IL_0212:
																							if (1 >= b)
																							{
																								goto IL_0220;
																							}
																							goto IL_0490;
																							IL_0220:
																							if (1 > b)
																							{
																							}
																							goto IL_0490;
																							IL_0233:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 73;
																							goto IL_02aa;
																							IL_02aa:
																							num5 -= 2;
																							num = 46;
																							goto end_IL_01e0;
																							IL_02c6:
																							if (3 >= b)
																							{
																								goto IL_02d4;
																							}
																							goto IL_0490;
																							IL_02d4:
																							if (3 <= b)
																							{
																								goto IL_02e2;
																							}
																							goto IL_0490;
																							IL_02e2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0322;
																							IL_0322:
																							array[num5 - 2] = 0;
																							goto IL_0336;
																							IL_0336:
																							num5--;
																							goto end_IL_01e0;
																							continue;
																							end_IL_018d:
																							break;
																						}
																						continue;
																					}
																					goto IL_0393;
																					IL_0469:
																					num5++;
																					goto IL_0477;
																					IL_0477:
																					ptr2 += 8;
																					goto end_IL_01e0;
																					IL_0393:
																					if (6 >= b)
																					{
																						goto IL_039e;
																					}
																					goto IL_03e0;
																					IL_039e:
																					if (6 <= b)
																					{
																						goto end_IL_01e0;
																					}
																					goto IL_03ac;
																					IL_03ac:
																					if (5 >= b)
																					{
																						goto IL_03ba;
																					}
																					goto IL_0490;
																					IL_03ba:
																					if (5 <= b)
																					{
																						goto IL_03c8;
																					}
																					goto IL_0490;
																					IL_03c8:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_01e0;
																					IL_03e0:
																					if (7 < b)
																					{
																						goto IL_03eb;
																					}
																					goto IL_0423;
																					IL_03eb:
																					if (8 >= b)
																					{
																						goto IL_03f9;
																					}
																					goto IL_0490;
																					IL_03f9:
																					if (8 <= b)
																					{
																						goto IL_0407;
																					}
																					goto IL_0490;
																					IL_0407:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_01e0;
																					IL_0423:
																					if (7 <= b)
																					{
																						goto IL_042e;
																					}
																					goto IL_0490;
																					IL_042e:
																					array[num5] = 0;
																					goto IL_043c;
																					IL_043c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_045f;
																					IL_045f:
																					array2[num5] = null;
																					goto IL_0469;
																					continue;
																					end_IL_019d:
																					break;
																				}
																				continue;
																			}
																			num = 83;
																			goto IL_0490;
																			continue;
																			end_IL_01b0:
																			break;
																		}
																		continue;
																	}
																	goto IL_0490;
																	IL_04cf:
																	ptr2 += 8;
																	goto end_IL_01e0;
																	IL_0490:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04b3;
																	IL_04b3:
																	array[num5] = 0;
																	goto IL_04c1;
																	IL_04c1:
																	num5++;
																	goto IL_04cf;
																	continue;
																	end_IL_01c0:
																	break;
																}
																continue;
																end_IL_01d0:
																break;
															}
															continue;
															end_IL_01e0:
															break;
														}
														continue;
													}
													goto IL_0593;
													IL_0593:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04dd:
													break;
												}
												continue;
												end_IL_04f0:
												break;
											}
											continue;
											end_IL_04fa:
											break;
										}
										continue;
										end_IL_0505:
										break;
									}
									continue;
									end_IL_051a:
									break;
								}
								continue;
								end_IL_0538:
								break;
							}
							continue;
							end_IL_0548:
							break;
						}
						continue;
						end_IL_0558:
						break;
					}
					continue;
					end_IL_0568:
					break;
				}
				continue;
				end_IL_0578:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_3, int int_4)
	{
		int num = 23;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setSizeUseNewMaxArraySize.LowestgetValues);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 101;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0248:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					if (5 < b)
																					{
																						while (true)
																						{
																							if (7 >= b)
																							{
																								while (true)
																								{
																									if (7 <= b)
																									{
																										num = 2;
																										while (true)
																										{
																											IL_01e4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											num = 109;
																											while (true)
																											{
																												if (num != 109)
																												{
																													if (num != 1090)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 2:
																													case 10:
																														goto IL_01e4;
																													case 44:
																														goto end_IL_01d1;
																													case 92:
																													case 94:
																														goto end_IL_0208;
																													case 95:
																														goto end_IL_0218;
																													case 62:
																														goto end_IL_0228;
																													case 79:
																														goto IL_0248;
																													case 47:
																														goto end_IL_0248;
																													case 101:
																														goto end_IL_0258;
																													case 30:
																														goto end_IL_0268;
																													case 90:
																														goto IL_027e;
																													case 58:
																														goto IL_028c;
																													case 39:
																													case 80:
																														goto IL_029a;
																													case 49:
																														goto IL_02da;
																													case 60:
																														goto IL_02ee;
																													case 55:
																														goto IL_030f;
																													case 93:
																														goto IL_031d;
																													case 82:
																														goto IL_0330;
																													case 36:
																														goto IL_033b;
																													case 46:
																														goto IL_0349;
																													case 5:
																													case 72:
																														goto IL_0357;
																													case 29:
																														goto IL_0373;
																													case 0:
																													case 28:
																														goto IL_0381;
																													case 87:
																														goto IL_03c1;
																													case 26:
																														goto IL_03d5;
																													case 51:
																														goto IL_03e8;
																													case 16:
																													case 19:
																														goto IL_03f6;
																													case 20:
																													case 35:
																														goto IL_0404;
																													case 1:
																													case 45:
																														goto IL_0412;
																													case 21:
																														goto IL_0420;
																													case 32:
																													case 64:
																														goto IL_042e;
																													case 102:
																														goto IL_046e;
																													case 63:
																														goto IL_0482;
																													case 9:
																														goto IL_0495;
																													case 8:
																													case 15:
																														goto IL_04a3;
																													case 52:
																														goto IL_04cc;
																													case 27:
																														goto IL_04da;
																													case 86:
																														goto IL_04ed;
																													case 25:
																													case 42:
																														goto IL_04f8;
																													case 96:
																														goto IL_0538;
																													case 50:
																														goto IL_054c;
																													case 4:
																														goto IL_055f;
																													case 91:
																														goto IL_056a;
																													case 76:
																													case 77:
																														goto IL_0577;
																													case 43:
																														goto IL_0585;
																													case 59:
																														goto IL_05a8;
																													case 70:
																														goto IL_05b2;
																													case 13:
																														goto IL_05c0;
																													case 3:
																													case 6:
																													case 7:
																													case 24:
																													case 34:
																													case 48:
																													case 53:
																													case 57:
																													case 65:
																													case 66:
																													case 67:
																													case 71:
																													case 73:
																													case 83:
																													case 97:
																													case 100:
																														goto end_IL_0238;
																													case 99:
																														goto IL_05f3;
																													case 69:
																														goto IL_0601;
																													case 88:
																														goto IL_060f;
																													case 11:
																													case 12:
																													case 17:
																													case 18:
																													case 31:
																													case 40:
																													case 56:
																													case 74:
																													case 85:
																													case 89:
																													case 98:
																														goto end_IL_0273;
																													case 75:
																														goto end_IL_061d;
																													case 33:
																														goto end_IL_0630;
																													case 37:
																														goto end_IL_063a;
																													case 78:
																														goto end_IL_0645;
																													case 61:
																														goto end_IL_065a;
																													case 38:
																													case 81:
																														goto end_IL_066f;
																													case 68:
																														goto end_IL_067f;
																													case 14:
																													case 54:
																														goto end_IL_068f;
																													case 22:
																														goto end_IL_069f;
																													case 23:
																														goto end_IL_06af;
																													case 41:
																													case 84:
																														goto IL_06ca;
																													}
																													continue;
																												}
																												array[num5] = 0;
																												goto IL_030f;
																												IL_030f:
																												num5++;
																												goto IL_031d;
																												IL_031d:
																												ptr2 += 8;
																												goto end_IL_0273;
																												continue;
																												end_IL_01d1:
																												break;
																											}
																											break;
																										}
																										continue;
																									}
																									goto IL_027e;
																									IL_02da:
																									array[num5 - 2] = 0;
																									goto IL_02ee;
																									IL_02ee:
																									num5--;
																									goto end_IL_0273;
																									IL_027e:
																									if (6 < b)
																									{
																										goto end_IL_0238;
																									}
																									goto IL_028c;
																									IL_028c:
																									if (6 > b)
																									{
																										goto end_IL_0238;
																									}
																									goto IL_029a;
																									IL_029a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_02da;
																									continue;
																									end_IL_0208:
																									break;
																								}
																								continue;
																							}
																							goto IL_0330;
																							IL_03d5:
																							num5--;
																							goto end_IL_0273;
																							IL_0330:
																							if (8 < b)
																							{
																								goto IL_033b;
																							}
																							goto IL_0373;
																							IL_033b:
																							if (9 < b)
																							{
																								goto end_IL_0238;
																							}
																							goto IL_0349;
																							IL_0349:
																							if (9 > b)
																							{
																								goto end_IL_0238;
																							}
																							goto IL_0357;
																							IL_0357:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0273;
																							IL_0373:
																							if (8 > b)
																							{
																								goto end_IL_0238;
																							}
																							goto IL_0381;
																							IL_0381:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03c1;
																							IL_03c1:
																							array[num5 - 2] = 0;
																							goto IL_03d5;
																							continue;
																							end_IL_0218:
																							break;
																						}
																						continue;
																					}
																					goto IL_03e8;
																					IL_05c0:
																					ptr2 += 8;
																					goto end_IL_0273;
																					IL_03e8:
																					if (5 > b)
																					{
																						goto IL_03f6;
																					}
																					goto IL_0577;
																					IL_03f6:
																					if (2 < b)
																					{
																						goto IL_0404;
																					}
																					goto IL_04ed;
																					IL_0404:
																					if (3 < b)
																					{
																						goto IL_0412;
																					}
																					goto IL_0495;
																					IL_0412:
																					if (4 < b)
																					{
																						goto end_IL_0238;
																					}
																					goto IL_0420;
																					IL_0420:
																					if (4 > b)
																					{
																						goto end_IL_0238;
																					}
																					goto IL_042e;
																					IL_042e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_046e;
																					IL_046e:
																					array[num5 - 2] = 0;
																					goto IL_0482;
																					IL_0482:
																					num5--;
																					goto end_IL_0273;
																					IL_0495:
																					if (3 > b)
																					{
																						goto end_IL_0238;
																					}
																					goto IL_04a3;
																					IL_04a3:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04cc;
																					IL_04cc:
																					ptr2 += 8;
																					goto IL_04da;
																					IL_04da:
																					num5--;
																					goto end_IL_0273;
																					IL_04ed:
																					if (2 <= b)
																					{
																						goto IL_04f8;
																					}
																					goto IL_055f;
																					IL_04f8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0538;
																					IL_0538:
																					array[num5 - 2] = 0;
																					goto IL_054c;
																					IL_054c:
																					num5--;
																					goto end_IL_0273;
																					IL_055f:
																					if (1 < b)
																					{
																						goto end_IL_0238;
																					}
																					goto IL_056a;
																					IL_056a:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_0238;
																					IL_0577:
																					array[num5] = 0;
																					goto IL_0585;
																					IL_0585:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05a8;
																					IL_05a8:
																					array2[num5] = null;
																					goto IL_05b2;
																					IL_05b2:
																					num5++;
																					goto IL_05c0;
																					continue;
																					end_IL_0228:
																					break;
																				}
																				continue;
																				end_IL_0238:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05f3;
																		IL_060f:
																		ptr2 += 8;
																		goto end_IL_0273;
																		IL_0601:
																		num5++;
																		goto IL_060f;
																		IL_05f3:
																		array[num5] = 0;
																		goto IL_0601;
																		continue;
																		end_IL_0248:
																		break;
																	}
																	continue;
																	end_IL_0258:
																	break;
																}
																continue;
																end_IL_0268:
																break;
															}
															continue;
															end_IL_0273:
															break;
														}
														continue;
													}
													goto IL_06ca;
													IL_06ca:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_061d:
													break;
												}
												continue;
												end_IL_0630:
												break;
											}
											continue;
											end_IL_063a:
											break;
										}
										continue;
										end_IL_0645:
										break;
									}
									continue;
									end_IL_065a:
									break;
								}
								continue;
								end_IL_066f:
								break;
							}
							continue;
							end_IL_067f:
							break;
						}
						continue;
						end_IL_068f:
						break;
					}
					continue;
					end_IL_069f:
					break;
				}
				continue;
				end_IL_06af:
				break;
			}
		}
	}

	private static float mretValRoleClaimProvider()
	{
		return Class171.float_0;
	}

	private static float PulseAllsetControlThread()
	{
		return Time.time;
	}

	private static float FunctionPtrCreateComInstanceFrom(float float_3, float float_4)
	{
		return Mathf.Max(float_3, float_4);
	}

	private static double UnixModeGB(double double_2)
	{
		return Math.Ceiling(double_2);
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001e, IL_0357, IL_036a, IL_0393, IL_03ad, IL_03bd, IL_03ca, IL_03da, IL_03ea, IL_03fa, IL_040a, IL_041a, IL_042a, IL_0435, IL_0440, IL_044b, IL_045b, IL_046e, IL_0482, IL_04ba, IL_04cd, IL_04db, IL_0519, IL_052c, IL_053a, IL_0552, IL_0569, IL_057c, IL_05a0, IL_05b8, IL_05cb, IL_05d6, IL_05e4, IL_0602, IL_0610, IL_0623, IL_0631, IL_063f, IL_0668, IL_0681, IL_068f, IL_069d, IL_06ab, IL_06b9, IL_06c7, IL_06db, IL_0759, IL_0767, IL_077a, IL_0788, IL_0791, IL_07a8, IL_07bb, IL_07c9, IL_07dc, IL_07e5, IL_07f9, IL_0845, IL_0853, IL_0866, IL_0871, IL_087f, IL_08a8, IL_08b6, IL_08c9, IL_08d7, IL_08e5, IL_0901, IL_090f, IL_092c, IL_097b, IL_0985, IL_09b2, IL_09cf, IL_09dd, IL_09f0, IL_09fe, IL_0a0c, IL_0a1a, IL_0a28, IL_0a36, IL_0a44, IL_0a84, IL_0a98, IL_0aab, IL_0ab4, IL_0ac2, IL_0ad0, IL_0af3, IL_0afd, IL_0b0b, IL_0b27, IL_0b30, IL_0b3b, IL_0b64, IL_0b72, IL_0b85, IL_0b90, IL_0ba3, IL_0bb1, IL_0bbf, IL_0bff, IL_0c13, IL_0c26, IL_0c2f, IL_0c6f, IL_0c83, IL_0c96, IL_0ca4, IL_0caf, IL_0cef, IL_0d03, IL_0d16, IL_0d21, IL_0d2f, IL_0d6f, IL_0d83, IL_0d9f, IL_0dad, IL_0dbb, IL_0dce, IL_0ddc, IL_0dea, IL_0e4c, IL_0e5c, IL_0e67, IL_0e72, IL_0e7d, IL_0e96, IL_0ead, IL_0ebb, IL_0ec9, IL_0edc, IL_0ee6, IL_0ef1, IL_0f01, IL_0f11, IL_0f21, IL_0f31, IL_0f41, IL_0f51, IL_0f61 are reachable both inside and outside the pinned region starting at IL_0f76. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 174;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			object[] array8;
			int num8;
			byte* num9;
			int __rxRef78 = default(int);
			ref int reference = ref __rxRef78;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0f61:
					num2 = 1;
					while (true)
					{
						IL_0f51:
						num3 = num2 * 4;
						while (true)
						{
							IL_0f41:
							array2 = new byte[4];
							while (true)
							{
								IL_0f31:
								array3 = new object[4];
								while (true)
								{
									IL_0f21:
									array4 = new int[4];
									while (true)
									{
										IL_0f11:
										array5 = new int[6];
										while (true)
										{
											IL_0f01:
											array6 = new long[4];
											while (true)
											{
												IL_0ef1:
												array7 = new object[16];
												while (true)
												{
													IL_0ee6:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InvokeMemberCursorSize.IAsyncStateMachineFileIOPermissionAttribute);
													while (true)
													{
														IL_0edc:
														ptr2 = ptr;
														while (true)
														{
															IL_0ec9:
															if (num4 == 1)
															{
																return;
															}
															while (true)
															{
																IL_0435:
																num = 167;
																while (true)
																{
																	IL_042a:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_041a:
																		ptr2++;
																		while (true)
																		{
																			IL_040a:
																			if (b >= 1)
																			{
																				while (b <= 23)
																				{
																					while (true)
																					{
																						IL_03ea:
																						if (12 >= b)
																						{
																							goto IL_0901;
																						}
																						while (true)
																						{
																							IL_03da:
																							if (18 >= b)
																							{
																								while (true)
																								{
																									IL_03ca:
																									if (18 > b)
																									{
																										while (true)
																										{
																											IL_03bd:
																											if (15 >= b)
																											{
																												while (true)
																												{
																													IL_03ad:
																													if (15 <= b)
																													{
																														while (true)
																														{
																															IL_0393:
																															array2[num5] = array2[num5 - 1];
																															while (true)
																															{
																																IL_036a:
																																array4[num5 - 0] = array4[num5 - 1];
																																num = 210;
																																while (true)
																																{
																																	if (num != 210)
																																	{
																																		if (num != 1191)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 174:
																																			break;
																																		default:
																																			continue;
																																		case 149:
																																			goto IL_036a;
																																		case 45:
																																		case 129:
																																			goto IL_0393;
																																		case 202:
																																			goto IL_03ad;
																																		case 17:
																																			goto IL_03bd;
																																		case 26:
																																			goto IL_03ca;
																																		case 132:
																																			goto IL_03da;
																																		case 47:
																																			goto IL_03ea;
																																		case 111:
																																			goto IL_03fa;
																																		case 0:
																																			goto IL_040a;
																																		case 170:
																																			goto IL_041a;
																																		case 167:
																																			goto IL_042a;
																																		case 13:
																																			goto IL_0435;
																																		case 16:
																																			goto IL_0440;
																																		case 32:
																																			goto IL_044b;
																																		case 60:
																																			goto IL_045b;
																																		case 12:
																																		case 105:
																																			goto IL_046e;
																																		case 6:
																																			goto IL_0482;
																																		case 128:
																																			goto IL_04ba;
																																		case 134:
																																			goto IL_04cd;
																																		case 38:
																																		case 166:
																																			goto IL_04db;
																																		case 165:
																																			goto IL_0519;
																																		case 21:
																																		case 181:
																																			goto IL_052c;
																																		case 7:
																																			goto IL_053a;
																																		case 34:
																																			goto IL_0552;
																																		case 122:
																																			goto IL_0569;
																																		case 154:
																																			goto IL_05a0;
																																		case 100:
																																			goto IL_05b8;
																																		case 64:
																																			goto IL_05cb;
																																		case 120:
																																			goto IL_05d6;
																																		case 89:
																																		case 163:
																																			goto IL_05e4;
																																		case 125:
																																			goto IL_0602;
																																		case 196:
																																			goto IL_0610;
																																		case 188:
																																			goto IL_0623;
																																		case 150:
																																			goto IL_0631;
																																		case 109:
																																		case 116:
																																			goto IL_063f;
																																		case 49:
																																			goto IL_0668;
																																		case 2:
																																			goto IL_0681;
																																		case 158:
																																			goto IL_068f;
																																		case 90:
																																			goto IL_069d;
																																		case 135:
																																			goto IL_06ab;
																																		case 185:
																																			goto IL_06b9;
																																		case 51:
																																		case 143:
																																			goto IL_06c7;
																																		case 15:
																																			goto IL_06db;
																																		case 94:
																																			goto IL_0759;
																																		case 203:
																																			goto IL_0767;
																																		case 69:
																																			goto IL_077a;
																																		case 25:
																																		case 61:
																																			goto IL_0791;
																																		case 200:
																																			goto IL_07a8;
																																		case 102:
																																			goto IL_07bb;
																																		case 93:
																																			goto IL_07c9;
																																		case 72:
																																		case 137:
																																			goto IL_07e5;
																																		case 50:
																																			goto IL_07f9;
																																		case 62:
																																			goto IL_0845;
																																		case 85:
																																			goto IL_0853;
																																		case 23:
																																			goto IL_0866;
																																		case 55:
																																			goto IL_0871;
																																		case 36:
																																		case 199:
																																			goto IL_087f;
																																		case 153:
																																			goto IL_08a8;
																																		case 19:
																																			goto IL_08b6;
																																		case 70:
																																			goto IL_08c9;
																																		case 139:
																																			goto IL_08d7;
																																		case 18:
																																		case 184:
																																			goto IL_08e5;
																																		case 162:
																																			goto IL_0901;
																																		case 9:
																																		case 43:
																																			goto IL_090f;
																																		case 84:
																																			goto IL_09cf;
																																		case 197:
																																			goto IL_09dd;
																																		case 83:
																																			goto IL_09f0;
																																		case 22:
																																			goto IL_09fe;
																																		case 131:
																																			goto IL_0a0c;
																																		case 67:
																																			goto IL_0a1a;
																																		case 1:
																																			goto IL_0a28;
																																		case 138:
																																			goto IL_0a36;
																																		case 41:
																																		case 195:
																																			goto IL_0a44;
																																		case 44:
																																			goto IL_0a84;
																																		case 104:
																																			goto IL_0a98;
																																		case 140:
																																			goto IL_0ab4;
																																		case 46:
																																		case 172:
																																			goto IL_0ac2;
																																		case 115:
																																			goto IL_0ad0;
																																		case 8:
																																			goto IL_0af3;
																																		case 82:
																																			goto IL_0afd;
																																		case 29:
																																			goto IL_0b0b;
																																		case 178:
																																			goto IL_0b30;
																																		case 119:
																																		case 148:
																																			goto IL_0b3b;
																																		case 103:
																																			goto IL_0b64;
																																		case 56:
																																			goto IL_0b72;
																																		case 88:
																																			goto IL_0b85;
																																		case 59:
																																			goto IL_0b90;
																																		case 123:
																																			goto IL_0ba3;
																																		case 66:
																																			goto IL_0bb1;
																																		case 20:
																																		case 24:
																																			goto IL_0bbf;
																																		case 126:
																																			goto IL_0bff;
																																		case 98:
																																			goto IL_0c13;
																																		case 5:
																																		case 75:
																																			goto IL_0c2f;
																																		case 160:
																																			goto IL_0c6f;
																																		case 159:
																																			goto IL_0c83;
																																		case 33:
																																			goto IL_0c96;
																																		case 101:
																																			goto IL_0ca4;
																																		case 10:
																																		case 91:
																																			goto IL_0caf;
																																		case 108:
																																			goto IL_0cef;
																																		case 28:
																																			goto IL_0d03;
																																		case 58:
																																			goto IL_0d16;
																																		case 176:
																																			goto IL_0d21;
																																		case 3:
																																		case 40:
																																			goto IL_0d2f;
																																		case 145:
																																			goto end_IL_0357;
																																		case 92:
																																			goto IL_0d83;
																																		case 124:
																																			goto IL_0d9f;
																																		case 177:
																																			goto IL_0dad;
																																		case 37:
																																		case 86:
																																			goto IL_0dbb;
																																		case 78:
																																			goto IL_0dce;
																																		case 48:
																																			goto IL_0ddc;
																																		case 152:
																																		case 182:
																																			goto IL_0dea;
																																		case 190:
																																			goto IL_0e4c;
																																		case 42:
																																			goto IL_0e5c;
																																		case 180:
																																			goto IL_0e67;
																																		case 4:
																																		case 11:
																																		case 14:
																																		case 27:
																																		case 30:
																																		case 54:
																																		case 65:
																																		case 68:
																																		case 71:
																																		case 79:
																																		case 81:
																																		case 97:
																																		case 107:
																																		case 110:
																																		case 112:
																																		case 130:
																																		case 136:
																																		case 141:
																																		case 147:
																																		case 156:
																																		case 157:
																																		case 168:
																																		case 186:
																																		case 191:
																																		case 194:
																																		case 198:
																																			goto end_IL_03fa;
																																		case 161:
																																			goto IL_0e96;
																																		case 53:
																																			goto IL_0ead;
																																		case 171:
																																			goto IL_0ebb;
																																		case 35:
																																		case 39:
																																		case 57:
																																		case 73:
																																		case 74:
																																		case 76:
																																		case 80:
																																		case 87:
																																		case 106:
																																		case 113:
																																		case 114:
																																		case 118:
																																		case 121:
																																		case 142:
																																		case 144:
																																		case 146:
																																		case 155:
																																		case 164:
																																		case 169:
																																		case 175:
																																		case 179:
																																		case 183:
																																		case 187:
																																		case 189:
																																		case 193:
																																		case 201:
																																			goto IL_0ec9;
																																		case 31:
																																			goto IL_0edc;
																																		case 52:
																																			goto IL_0ee6;
																																		case 99:
																																			goto IL_0ef1;
																																		case 63:
																																			goto IL_0f01;
																																		case 95:
																																			goto IL_0f11;
																																		case 151:
																																			goto IL_0f21;
																																		case 133:
																																			goto IL_0f31;
																																		case 77:
																																		case 96:
																																			goto IL_0f41;
																																		case 192:
																																			goto IL_0f51;
																																		case 173:
																																			goto IL_0f61;
																																		case 117:
																																		case 127:
																																			return;
																																		}
																																		goto end_IL_03ea;
																																	}
																																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																	goto IL_05a0;
																																	IL_05a0:
																																	array3[num5] = array3[num5 - 1];
																																	goto IL_05b8;
																																	IL_05b8:
																																	num5++;
																																	goto IL_0ec9;
																																	continue;
																																	end_IL_0357:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_05cb;
																													IL_0668:
																													array2[num5 - 1] = 5;
																													goto IL_0ec9;
																													IL_05cb:
																													if (13 >= b)
																													{
																														goto IL_05d6;
																													}
																													goto IL_0623;
																													IL_05d6:
																													if (13 > b)
																													{
																														goto end_IL_03fa;
																													}
																													goto IL_05e4;
																													IL_05e4:
																													array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																													goto IL_0602;
																													IL_0602:
																													ptr2 += 8;
																													goto IL_0610;
																													IL_0610:
																													num5--;
																													goto IL_0ec9;
																													IL_0623:
																													if (14 < b)
																													{
																														goto end_IL_03fa;
																													}
																													goto IL_0631;
																													IL_0631:
																													if (14 > b)
																													{
																														goto end_IL_03fa;
																													}
																													goto IL_063f;
																													IL_063f:
																													array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																													goto IL_0668;
																												}
																												break;
																											}
																											goto IL_0440;
																											IL_0569:
																											ptr2 += 8;
																											goto IL_0ec9;
																											IL_0440:
																											if (16 < b)
																											{
																												goto IL_044b;
																											}
																											goto IL_045b;
																											IL_044b:
																											if (17 < b)
																											{
																												goto end_IL_03fa;
																											}
																											goto IL_04cd;
																											IL_04cd:
																											if (17 > b)
																											{
																												goto end_IL_03fa;
																											}
																											goto IL_04db;
																											IL_04db:
																											((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																											goto IL_0519;
																											IL_0519:
																											num5 -= 3;
																											goto IL_0ec9;
																											IL_045b:
																											if (16 > b)
																											{
																												goto end_IL_03fa;
																											}
																											goto IL_052c;
																											IL_052c:
																											array2[num5] = 5;
																											goto IL_053a;
																											IL_053a:
																											array3[num5] = array7[*(int*)(ptr2 + num3)];
																											goto IL_0552;
																											IL_0552:
																											num5++;
																											num = 122;
																											goto IL_0569;
																										}
																										break;
																									}
																									goto IL_046e;
																									IL_04ba:
																									ptr2 += 8;
																									goto IL_0ec9;
																									IL_046e:
																									array2[num5 - 1] = 5;
																									goto IL_0482;
																									IL_0482:
																									array3[num5 - 1] = ((delegate*<string[], string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																									goto IL_04ba;
																								}
																								break;
																							}
																							goto IL_0681;
																							IL_08c9:
																							if (23 < b)
																							{
																								goto end_IL_03fa;
																							}
																							goto IL_08d7;
																							IL_0681:
																							if (21 >= b)
																							{
																								goto IL_068f;
																							}
																							goto IL_0866;
																							IL_068f:
																							if (21 > b)
																							{
																								goto IL_069d;
																							}
																							num = 137;
																							goto IL_07e5;
																							IL_069d:
																							if (19 < b)
																							{
																								goto IL_06ab;
																							}
																							goto IL_077a;
																							IL_06ab:
																							if (20 < b)
																							{
																								goto end_IL_03fa;
																							}
																							goto IL_06b9;
																							IL_06b9:
																							if (20 > b)
																							{
																								goto end_IL_03fa;
																							}
																							goto IL_06c7;
																							IL_06c7:
																							array2[num5 - 2] = 5;
																							goto IL_06db;
																							IL_06db:
																							array3[num5 - 2] = ((delegate*<ref float, string, string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)CreateConstructionReturnMessageObjectWithMapTyped[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																							goto IL_0759;
																							IL_0759:
																							num5--;
																							goto IL_0767;
																							IL_0767:
																							ptr2 += 8;
																							goto IL_0ec9;
																							IL_077a:
																							if (19 > b)
																							{
																								goto end_IL_03fa;
																							}
																							num = 25;
																							goto IL_0791;
																							IL_08e5:
																							num6 = ptr2;
																							num7 = -200;
																							num4 = 1;
																							ptr2 = num6 + num7;
																							goto IL_0ec9;
																							IL_0791:
																							array2[num5] = 15;
																							num = 200;
																							goto IL_07a8;
																							IL_07a8:
																							array4[num5] = *(int*)(ptr2 + num3);
																							goto IL_07bb;
																							IL_07bb:
																							ptr2 += 8;
																							goto IL_07c9;
																							IL_07c9:
																							num5++;
																							goto IL_0ec9;
																							IL_08d7:
																							if (23 > b)
																							{
																								goto end_IL_03fa;
																							}
																							goto IL_08e5;
																							IL_07e5:
																							array2[num5 - 2] = 5;
																							goto IL_07f9;
																							IL_07f9:
																							array3[num5 - 2] = ((delegate*<string, string, string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																							goto IL_0845;
																							IL_0845:
																							num5--;
																							goto IL_0853;
																							IL_0853:
																							ptr2 += 8;
																							goto IL_0ec9;
																							IL_0866:
																							if (22 >= b)
																							{
																								goto IL_0871;
																							}
																							goto IL_08c9;
																							IL_0871:
																							if (22 > b)
																							{
																								goto end_IL_03fa;
																							}
																							goto IL_087f;
																							IL_087f:
																							((delegate*<string, void>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																							goto IL_08a8;
																							IL_08a8:
																							num5--;
																							goto IL_08b6;
																							IL_08b6:
																							ptr2 += 8;
																							goto IL_0ec9;
																						}
																						goto IL_0d6f;
																						IL_0dbb:
																						num5--;
																						goto IL_0ec9;
																						IL_0901:
																						if (12 <= b)
																						{
																							goto IL_090f;
																						}
																						goto IL_09f0;
																						IL_090f:
																						array8 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_091e;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						num = 84;
																						goto IL_09cf;
																						IL_0dce:
																						if (10 >= b)
																						{
																							goto IL_0ddc;
																						}
																						goto IL_0e5c;
																						IL_0ddc:
																						if (10 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0dea;
																						IL_0dea:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0e4c;
																						IL_09cf:
																						array2[num5] = 5;
																						goto IL_09dd;
																						IL_09dd:
																						num5++;
																						goto IL_0ec9;
																						IL_09f0:
																						if (6 >= b)
																						{
																							goto IL_09fe;
																						}
																						goto IL_0c96;
																						IL_09fe:
																						if (6 > b)
																						{
																							goto IL_0a0c;
																						}
																						num = 75;
																						goto IL_0c2f;
																						IL_0a0c:
																						if (3 < b)
																						{
																							goto IL_0a1a;
																						}
																						num = 178;
																						goto IL_0b30;
																						IL_0a1a:
																						if (4 < b)
																						{
																							goto IL_0a28;
																						}
																						num = 140;
																						goto IL_0ab4;
																						IL_0a28:
																						if (5 < b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0a36;
																						IL_0a36:
																						if (5 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0a44;
																						IL_0a44:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0a84;
																						IL_0a84:
																						array2[num5 - 2] = 0;
																						goto IL_0a98;
																						IL_0a98:
																						num5--;
																						goto IL_0ec9;
																						IL_0e67:
																						if (11 > b)
																						{
																							goto end_IL_03fa;
																						}
																						num = 175;
																						goto IL_0ec9;
																						IL_0ab4:
																						if (4 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0ac2;
																						IL_0ac2:
																						array2[num5] = 0;
																						goto IL_0ad0;
																						IL_0ad0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0af3;
																						IL_0af3:
																						array3[num5] = null;
																						goto IL_0afd;
																						IL_0afd:
																						num5++;
																						goto IL_0b0b;
																						IL_0b0b:
																						ptr2 += 8;
																						num = 106;
																						goto IL_0ec9;
																						IL_0e5c:
																						if (11 < b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0e67;
																						IL_0b30:
																						if (3 <= b)
																						{
																							goto IL_0b3b;
																						}
																						goto IL_0b85;
																						IL_0b3b:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0b64;
																						IL_0b64:
																						ptr2 += 8;
																						goto IL_0b72;
																						IL_0b72:
																						num5--;
																						goto IL_0ec9;
																						IL_0b85:
																						if (1 >= b)
																						{
																							goto IL_0b90;
																						}
																						goto IL_0ba3;
																						IL_0b90:
																						if (1 > b)
																						{
																						}
																						goto end_IL_03fa;
																						IL_0ba3:
																						if (2 < b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0bb1;
																						IL_0bb1:
																						if (2 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0bbf;
																						IL_0bbf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0bff;
																						IL_0bff:
																						array2[num5 - 2] = 0;
																						goto IL_0c13;
																						IL_0c13:
																						num5--;
																						goto IL_0ec9;
																						IL_0e4c:
																						num5 -= 2;
																						goto IL_0ec9;
																						IL_0c2f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0c6f;
																						IL_0c6f:
																						array2[num5 - 2] = 0;
																						goto IL_0c83;
																						IL_0c83:
																						num5--;
																						goto IL_0ec9;
																						IL_0c96:
																						if (9 >= b)
																						{
																							goto IL_0ca4;
																						}
																						goto IL_0dce;
																						IL_0ca4:
																						if (9 <= b)
																						{
																							goto IL_0caf;
																						}
																						goto IL_0d16;
																						IL_0caf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0cef;
																						IL_0cef:
																						array2[num5 - 2] = 0;
																						goto IL_0d03;
																						IL_0d03:
																						num5--;
																						goto IL_0ec9;
																						IL_0d16:
																						if (7 >= b)
																						{
																							goto IL_0d21;
																						}
																						goto IL_0d9f;
																						IL_0d21:
																						if (7 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0d2f;
																						IL_0d2f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0d6f;
																						IL_0d6f:
																						array2[num5 - 2] = 0;
																						goto IL_0d83;
																						IL_0d83:
																						num5--;
																						num = 164;
																						goto IL_0ec9;
																						IL_0d9f:
																						if (8 < b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0dad;
																						IL_0dad:
																						if (8 > b)
																						{
																							goto end_IL_03fa;
																						}
																						goto IL_0dbb;
																						continue;
																						end_IL_03ea:
																						break;
																					}
																					goto end_IL_040a;
																					continue;
																					end_IL_03fa:
																					break;
																					IL_03fa:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0e96;
																			IL_0ebb:
																			ptr2 += 8;
																			goto IL_0ec9;
																			IL_0ead:
																			num5++;
																			goto IL_0ebb;
																			IL_0e96:
																			array2[num5] = 0;
																			num = 53;
																			goto IL_0ead;
																			continue;
																			end_IL_040a:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_091e:
			while (true)
			{
				IL_091e_2:
				array = new byte[4];
				while (true)
				{
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					num = 84;
					while (true)
					{
						IL_09cf_2:
						array2[num5] = 5;
						while (true)
						{
							IL_09dd_2:
							num5++;
							while (true)
							{
								IL_0ec9_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									num = 167;
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_040a_2:
												if (b >= 1)
												{
													while (b <= 23)
													{
														while (true)
														{
															IL_03ea_2:
															if (12 >= b)
															{
																goto IL_0901_2;
															}
															while (true)
															{
																IL_03da_2:
																if (18 >= b)
																{
																	while (true)
																	{
																		IL_03ca_2:
																		if (18 > b)
																		{
																			while (true)
																			{
																				IL_03bd_2:
																				if (15 >= b)
																				{
																					while (true)
																					{
																						IL_03ad_2:
																						if (15 <= b)
																						{
																							while (true)
																							{
																								IL_0393_2:
																								array2[num5] = array2[num5 - 1];
																								while (true)
																								{
																									IL_036a_2:
																									array4[num5 - 0] = array4[num5 - 1];
																									num = 210;
																									while (true)
																									{
																										if (num != 210)
																										{
																											if (num != 1191)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 149:
																												goto IL_036a_2;
																											case 45:
																											case 129:
																												goto IL_0393_2;
																											case 202:
																												goto IL_03ad_2;
																											case 17:
																												goto IL_03bd_2;
																											case 26:
																												goto IL_03ca_2;
																											case 132:
																												goto IL_03da_2;
																											case 47:
																												goto IL_03ea_2;
																											case 111:
																												goto end_IL_03ea_2;
																											case 0:
																												goto IL_040a_2;
																											case 170:
																												goto end_IL_040a_2;
																											case 167:
																												goto end_IL_041a;
																											case 13:
																												goto end_IL_042a;
																											case 16:
																												goto IL_0440_2;
																											case 32:
																												goto IL_044b_2;
																											case 60:
																												goto IL_045b_2;
																											case 12:
																											case 105:
																												goto IL_046e_2;
																											case 6:
																												goto IL_0482_2;
																											case 128:
																												goto IL_04ba_2;
																											case 134:
																												goto IL_04cd_2;
																											case 38:
																											case 166:
																												goto IL_04db_2;
																											case 165:
																												goto IL_0519_2;
																											case 21:
																											case 181:
																												goto IL_052c_2;
																											case 7:
																												goto IL_053a_2;
																											case 34:
																												goto IL_0552_2;
																											case 122:
																												goto IL_0569_2;
																											case 154:
																												goto IL_05a0_2;
																											case 100:
																												goto IL_05b8_2;
																											case 64:
																												goto IL_05cb_2;
																											case 120:
																												goto IL_05d6_2;
																											case 89:
																											case 163:
																												goto IL_05e4_2;
																											case 125:
																												goto IL_0602_2;
																											case 196:
																												goto IL_0610_2;
																											case 188:
																												goto IL_0623_2;
																											case 150:
																												goto IL_0631_2;
																											case 109:
																											case 116:
																												goto IL_063f_2;
																											case 49:
																												goto IL_0668_2;
																											case 2:
																												goto IL_0681_2;
																											case 158:
																												goto IL_068f_2;
																											case 90:
																												goto IL_069d_2;
																											case 135:
																												goto IL_06ab_2;
																											case 185:
																												goto IL_06b9_2;
																											case 51:
																											case 143:
																												goto IL_06c7_2;
																											case 15:
																												goto IL_06db_2;
																											case 94:
																												goto IL_0759_2;
																											case 203:
																												goto IL_0767_2;
																											case 69:
																												goto IL_077a_2;
																											case 25:
																											case 61:
																												goto IL_0791_2;
																											case 200:
																												goto IL_07a8_2;
																											case 102:
																												goto IL_07bb_2;
																											case 93:
																												goto IL_07c9_2;
																											case 72:
																											case 137:
																												goto IL_07e5_2;
																											case 50:
																												goto IL_07f9_2;
																											case 62:
																												goto IL_0845_2;
																											case 85:
																												goto IL_0853_2;
																											case 23:
																												goto IL_0866_2;
																											case 55:
																												goto IL_0871_2;
																											case 36:
																											case 199:
																												goto IL_087f_2;
																											case 153:
																												goto IL_08a8_2;
																											case 19:
																												goto IL_08b6_2;
																											case 70:
																												goto IL_08c9_2;
																											case 139:
																												goto IL_08d7_2;
																											case 18:
																											case 184:
																												goto IL_08e5_2;
																											case 162:
																												goto IL_0901_2;
																											case 9:
																											case 43:
																												goto end_IL_0435;
																											case 84:
																												goto IL_09cf_2;
																											case 197:
																												goto IL_09dd_2;
																											case 83:
																												goto IL_09f0_2;
																											case 22:
																												goto IL_09fe_2;
																											case 131:
																												goto IL_0a0c_2;
																											case 67:
																												goto IL_0a1a_2;
																											case 1:
																												goto IL_0a28_2;
																											case 138:
																												goto IL_0a36_2;
																											case 41:
																											case 195:
																												goto IL_0a44_2;
																											case 44:
																												goto IL_0a84_2;
																											case 104:
																												goto IL_0a98_2;
																											case 140:
																												goto IL_0ab4_2;
																											case 46:
																											case 172:
																												goto IL_0ac2_2;
																											case 115:
																												goto IL_0ad0_2;
																											case 8:
																												goto IL_0af3_2;
																											case 82:
																												goto IL_0afd_2;
																											case 29:
																												goto IL_0b0b_2;
																											case 178:
																												goto IL_0b30_2;
																											case 119:
																											case 148:
																												goto IL_0b3b_2;
																											case 103:
																												goto IL_0b64_2;
																											case 56:
																												goto IL_0b72_2;
																											case 88:
																												goto IL_0b85_2;
																											case 59:
																												goto IL_0b90_2;
																											case 123:
																												goto IL_0ba3_2;
																											case 66:
																												goto IL_0bb1_2;
																											case 20:
																											case 24:
																												goto IL_0bbf_2;
																											case 126:
																												goto IL_0bff_2;
																											case 98:
																												goto IL_0c13_2;
																											case 5:
																											case 75:
																												goto IL_0c2f_2;
																											case 160:
																												goto IL_0c6f_2;
																											case 159:
																												goto IL_0c83_2;
																											case 33:
																												goto IL_0c96_2;
																											case 101:
																												goto IL_0ca4_2;
																											case 10:
																											case 91:
																												goto IL_0caf_2;
																											case 108:
																												goto IL_0cef_2;
																											case 28:
																												goto IL_0d03_2;
																											case 58:
																												goto IL_0d16_2;
																											case 176:
																												goto IL_0d21_2;
																											case 3:
																											case 40:
																												goto IL_0d2f_2;
																											case 145:
																												goto end_IL_0357_2;
																											case 92:
																												goto IL_0d83_2;
																											case 124:
																												goto IL_0d9f_2;
																											case 177:
																												goto IL_0dad_2;
																											case 37:
																											case 86:
																												goto IL_0dbb_2;
																											case 78:
																												goto IL_0dce_2;
																											case 48:
																												goto IL_0ddc_2;
																											case 152:
																											case 182:
																												goto IL_0dea_2;
																											case 190:
																												goto IL_0e4c_2;
																											case 42:
																												goto IL_0e5c_2;
																											case 180:
																												goto IL_0e67_2;
																											case 4:
																											case 11:
																											case 14:
																											case 27:
																											case 30:
																											case 54:
																											case 65:
																											case 68:
																											case 71:
																											case 79:
																											case 81:
																											case 97:
																											case 107:
																											case 110:
																											case 112:
																											case 130:
																											case 136:
																											case 141:
																											case 147:
																											case 156:
																											case 157:
																											case 168:
																											case 186:
																											case 191:
																											case 194:
																											case 198:
																												goto end_IL_03fa_2;
																											case 161:
																												goto IL_0e96_2;
																											case 53:
																												goto IL_0ead_2;
																											case 171:
																												goto IL_0ebb_2;
																											case 35:
																											case 39:
																											case 57:
																											case 73:
																											case 74:
																											case 76:
																											case 80:
																											case 87:
																											case 106:
																											case 113:
																											case 114:
																											case 118:
																											case 121:
																											case 142:
																											case 144:
																											case 146:
																											case 155:
																											case 164:
																											case 169:
																											case 175:
																											case 179:
																											case 183:
																											case 187:
																											case 189:
																											case 193:
																											case 201:
																												goto IL_0ec9_2;
																											case 31:
																												ptr2 = ptr;
																												goto IL_0ec9_2;
																											case 52:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InvokeMemberCursorSize.IAsyncStateMachineFileIOPermissionAttribute);
																												goto case 31;
																											case 99:
																												array7 = new object[16];
																												goto case 52;
																											case 63:
																												array6 = new long[4];
																												goto case 99;
																											case 95:
																												array5 = new int[6];
																												goto case 63;
																											case 151:
																												array4 = new int[4];
																												goto case 95;
																											case 133:
																												array3 = new object[4];
																												goto case 151;
																											case 77:
																											case 96:
																												array2 = new byte[4];
																												goto case 133;
																											case 192:
																												num3 = num2 * 4;
																												goto case 77;
																											case 173:
																												num2 = 1;
																												goto case 192;
																											case 174:
																												goto end_IL_092c;
																											case 117:
																											case 127:
																												return;
																											}
																											continue;
																										}
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_05a0_2;
																										IL_05a0_2:
																										array3[num5] = array3[num5 - 1];
																										goto IL_05b8_2;
																										IL_05b8_2:
																										num5++;
																										goto IL_0ec9_2;
																										continue;
																										end_IL_0357_2:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_05cb_2;
																						IL_0668_2:
																						array2[num5 - 1] = 5;
																						goto IL_0ec9_2;
																						IL_05cb_2:
																						if (13 >= b)
																						{
																							goto IL_05d6_2;
																						}
																						goto IL_0623_2;
																						IL_05d6_2:
																						if (13 > b)
																						{
																							goto end_IL_03fa_2;
																						}
																						goto IL_05e4_2;
																						IL_05e4_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0602_2;
																						IL_0602_2:
																						ptr2 += 8;
																						goto IL_0610_2;
																						IL_0610_2:
																						num5--;
																						goto IL_0ec9_2;
																						IL_0623_2:
																						if (14 < b)
																						{
																							goto end_IL_03fa_2;
																						}
																						goto IL_0631_2;
																						IL_0631_2:
																						if (14 > b)
																						{
																							goto end_IL_03fa_2;
																						}
																						goto IL_063f_2;
																						IL_063f_2:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_0668_2;
																					}
																					break;
																				}
																				goto IL_0440_2;
																				IL_0569_2:
																				ptr2 += 8;
																				goto IL_0ec9_2;
																				IL_0440_2:
																				if (16 < b)
																				{
																					goto IL_044b_2;
																				}
																				goto IL_045b_2;
																				IL_044b_2:
																				if (17 < b)
																				{
																					goto end_IL_03fa_2;
																				}
																				goto IL_04cd_2;
																				IL_04cd_2:
																				if (17 > b)
																				{
																					goto end_IL_03fa_2;
																				}
																				goto IL_04db_2;
																				IL_04db_2:
																				((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																				goto IL_0519_2;
																				IL_0519_2:
																				num5 -= 3;
																				goto IL_0ec9_2;
																				IL_045b_2:
																				if (16 > b)
																				{
																					goto end_IL_03fa_2;
																				}
																				goto IL_052c_2;
																				IL_052c_2:
																				array2[num5] = 5;
																				goto IL_053a_2;
																				IL_053a_2:
																				array3[num5] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0552_2;
																				IL_0552_2:
																				num5++;
																				num = 122;
																				goto IL_0569_2;
																			}
																			break;
																		}
																		goto IL_046e_2;
																		IL_04ba_2:
																		ptr2 += 8;
																		goto IL_0ec9_2;
																		IL_046e_2:
																		array2[num5 - 1] = 5;
																		goto IL_0482_2;
																		IL_0482_2:
																		array3[num5 - 1] = ((delegate*<string[], string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																		goto IL_04ba_2;
																	}
																	break;
																}
																goto IL_0681_2;
																IL_08c9_2:
																if (23 < b)
																{
																	goto end_IL_03fa_2;
																}
																goto IL_08d7_2;
																IL_0681_2:
																if (21 >= b)
																{
																	goto IL_068f_2;
																}
																goto IL_0866_2;
																IL_068f_2:
																if (21 > b)
																{
																	goto IL_069d_2;
																}
																num = 137;
																goto IL_07e5_2;
																IL_069d_2:
																if (19 < b)
																{
																	goto IL_06ab_2;
																}
																goto IL_077a_2;
																IL_06ab_2:
																if (20 < b)
																{
																	goto end_IL_03fa_2;
																}
																goto IL_06b9_2;
																IL_06b9_2:
																if (20 > b)
																{
																	goto end_IL_03fa_2;
																}
																goto IL_06c7_2;
																IL_06c7_2:
																array2[num5 - 2] = 5;
																goto IL_06db_2;
																IL_06db_2:
																array3[num5 - 2] = ((delegate*<ref float, string, string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref float>)CreateConstructionReturnMessageObjectWithMapTyped[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])), array7, array5), (string)array3[num5 - 1]);
																goto IL_0759_2;
																IL_0759_2:
																num5--;
																goto IL_0767_2;
																IL_0767_2:
																ptr2 += 8;
																goto IL_0ec9_2;
																IL_077a_2:
																if (19 > b)
																{
																	goto end_IL_03fa_2;
																}
																num = 25;
																goto IL_0791_2;
																IL_08e5_2:
																num6 = ptr2;
																num7 = -200;
																num4 = 1;
																ptr2 = num6 + num7;
																goto IL_0ec9_2;
																IL_0791_2:
																array2[num5] = 15;
																num = 200;
																goto IL_07a8_2;
																IL_07a8_2:
																array4[num5] = *(int*)(ptr2 + num3);
																goto IL_07bb_2;
																IL_07bb_2:
																ptr2 += 8;
																goto IL_07c9_2;
																IL_07c9_2:
																num5++;
																goto IL_0ec9_2;
																IL_08d7_2:
																if (23 > b)
																{
																	goto end_IL_03fa_2;
																}
																goto IL_08e5_2;
																IL_07e5_2:
																array2[num5 - 2] = 5;
																goto IL_07f9_2;
																IL_07f9_2:
																array3[num5 - 2] = ((delegate*<string, string, string>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																goto IL_0845_2;
																IL_0845_2:
																num5--;
																goto IL_0853_2;
																IL_0853_2:
																ptr2 += 8;
																goto IL_0ec9_2;
																IL_0866_2:
																if (22 >= b)
																{
																	goto IL_0871_2;
																}
																goto IL_08c9_2;
																IL_0871_2:
																if (22 > b)
																{
																	goto end_IL_03fa_2;
																}
																goto IL_087f_2;
																IL_087f_2:
																((delegate*<string, void>)CreateConstructionReturnMessageObjectWithMapTyped[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																goto IL_08a8_2;
																IL_08a8_2:
																num5--;
																goto IL_08b6_2;
																IL_08b6_2:
																ptr2 += 8;
																goto IL_0ec9_2;
															}
															goto IL_0d6f_2;
															IL_0dea_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0e4c_2;
															IL_0901_2:
															if (12 <= b)
															{
																goto end_IL_0435;
															}
															goto IL_09f0_2;
															IL_09f0_2:
															if (6 >= b)
															{
																goto IL_09fe_2;
															}
															goto IL_0c96_2;
															IL_09fe_2:
															if (6 > b)
															{
																goto IL_0a0c_2;
															}
															num = 75;
															goto IL_0c2f_2;
															IL_0a0c_2:
															if (3 < b)
															{
																goto IL_0a1a_2;
															}
															num = 178;
															goto IL_0b30_2;
															IL_0a1a_2:
															if (4 < b)
															{
																goto IL_0a28_2;
															}
															num = 140;
															goto IL_0ab4_2;
															IL_0a28_2:
															if (5 < b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0a36_2;
															IL_0a36_2:
															if (5 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0a44_2;
															IL_0a44_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0a84_2;
															IL_0a84_2:
															array2[num5 - 2] = 0;
															goto IL_0a98_2;
															IL_0a98_2:
															num5--;
															goto IL_0ec9_2;
															IL_0e67_2:
															if (11 > b)
															{
																goto end_IL_03fa_2;
															}
															num = 175;
															goto IL_0ec9_2;
															IL_0ab4_2:
															if (4 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0ac2_2;
															IL_0ac2_2:
															array2[num5] = 0;
															goto IL_0ad0_2;
															IL_0ad0_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0af3_2;
															IL_0af3_2:
															array3[num5] = null;
															goto IL_0afd_2;
															IL_0afd_2:
															num5++;
															goto IL_0b0b_2;
															IL_0b0b_2:
															ptr2 += 8;
															num = 106;
															goto IL_0ec9_2;
															IL_0e5c_2:
															if (11 < b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0e67_2;
															IL_0b30_2:
															if (3 <= b)
															{
																goto IL_0b3b_2;
															}
															goto IL_0b85_2;
															IL_0b3b_2:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0b64_2;
															IL_0b64_2:
															ptr2 += 8;
															goto IL_0b72_2;
															IL_0b72_2:
															num5--;
															goto IL_0ec9_2;
															IL_0b85_2:
															if (1 >= b)
															{
																goto IL_0b90_2;
															}
															goto IL_0ba3_2;
															IL_0b90_2:
															if (1 > b)
															{
															}
															goto end_IL_03fa_2;
															IL_0ba3_2:
															if (2 < b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0bb1_2;
															IL_0bb1_2:
															if (2 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0bbf_2;
															IL_0bbf_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0bff_2;
															IL_0bff_2:
															array2[num5 - 2] = 0;
															goto IL_0c13_2;
															IL_0c13_2:
															num5--;
															goto IL_0ec9_2;
															IL_0e4c_2:
															num5 -= 2;
															goto IL_0ec9_2;
															IL_0c2f_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0c6f_2;
															IL_0c6f_2:
															array2[num5 - 2] = 0;
															goto IL_0c83_2;
															IL_0c83_2:
															num5--;
															goto IL_0ec9_2;
															IL_0c96_2:
															if (9 >= b)
															{
																goto IL_0ca4_2;
															}
															goto IL_0dce_2;
															IL_0ca4_2:
															if (9 <= b)
															{
																goto IL_0caf_2;
															}
															goto IL_0d16_2;
															IL_0caf_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0cef_2;
															IL_0cef_2:
															array2[num5 - 2] = 0;
															goto IL_0d03_2;
															IL_0d03_2:
															num5--;
															goto IL_0ec9_2;
															IL_0d16_2:
															if (7 >= b)
															{
																goto IL_0d21_2;
															}
															goto IL_0d9f_2;
															IL_0d21_2:
															if (7 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0d2f_2;
															IL_0d2f_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
															goto IL_0d6f_2;
															IL_0d6f_2:
															array2[num5 - 2] = 0;
															goto IL_0d83_2;
															IL_0d83_2:
															num5--;
															num = 164;
															goto IL_0ec9_2;
															IL_0d9f_2:
															if (8 < b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0dad_2;
															IL_0dad_2:
															if (8 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0dbb_2;
															IL_0dbb_2:
															num5--;
															goto IL_0ec9_2;
															IL_0dce_2:
															if (10 >= b)
															{
																goto IL_0ddc_2;
															}
															goto IL_0e5c_2;
															IL_0ddc_2:
															if (10 > b)
															{
																goto end_IL_03fa_2;
															}
															goto IL_0dea_2;
															continue;
															end_IL_03ea_2:
															break;
														}
														continue;
														end_IL_03fa_2:
														break;
													}
												}
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
												goto IL_0e96_2;
												IL_0ebb_2:
												ptr2 += 8;
												goto IL_0ec9_2;
												IL_0ead_2:
												num5++;
												goto IL_0ebb_2;
												IL_0e96_2:
												array2[num5] = 0;
												num = 53;
												goto IL_0ead_2;
												continue;
												end_IL_040a_2:
												break;
											}
											continue;
											end_IL_041a:
											break;
										}
										continue;
										end_IL_042a:
										break;
									}
									continue;
									end_IL_0435:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num8 = num5;
					if (array == null)
					{
						goto IL_091e_2;
					}
					continue;
					end_IL_092c:
					break;
				}
				break;
			}
		}
	}
}
