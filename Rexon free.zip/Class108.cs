using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Strange Wood Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns strange wood.", false, 9, ModType.const_0, false)]
internal class Class108 : Class93
{
	private static float float_0;

	private static int int_3;

	private static float float_1;

	private static double double_1;

	private static int int_4;

	private static bool bool_0;

	private static IntPtr[] getLocalCreatorAuthority;

	private static IntPtr[] ErrorWrapperThaiBuddhistCalendar;

	private static IntPtr[] processorCountgetEras;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_039b, IL_03ae, IL_03c7, IL_042b, IL_043b, IL_044b, IL_0458, IL_0468, IL_0478, IL_0488, IL_0498, IL_04a8, IL_04b8, IL_04c8, IL_04d3, IL_04e1, IL_0521, IL_0535, IL_0548, IL_0556, IL_0564, IL_0572, IL_0580, IL_05c9, IL_05dd, IL_05f0, IL_05fe, IL_063e, IL_0652, IL_0665, IL_0678, IL_0686, IL_0694, IL_06a2, IL_06b0, IL_06be, IL_06cc, IL_06ef, IL_06f9, IL_0710, IL_0723, IL_0731, IL_075a, IL_0768, IL_077b, IL_0786, IL_07c6, IL_07da, IL_07ed, IL_07fb, IL_080e, IL_084e, IL_086b, IL_087e, IL_0892, IL_08ef, IL_08fd, IL_0910, IL_091e, IL_092c, IL_093a, IL_0948, IL_0956, IL_0964, IL_097c, IL_099a, IL_09be, IL_09d6, IL_09f2, IL_0a00, IL_0a29, IL_0a42, IL_0a50, IL_0a5b, IL_0a6e, IL_0a7c, IL_0a8a, IL_0aa7, IL_0af6, IL_0b00, IL_0b2d, IL_0b41, IL_0b4f, IL_0b62, IL_0b80, IL_0b97, IL_0baa, IL_0bb8, IL_0bd0, IL_0bde, IL_0bf1, IL_0bfc, IL_0c07, IL_0c15, IL_0c2d, IL_0c36, IL_0c44, IL_0c52, IL_0c6e, IL_0c7c, IL_0c87, IL_0c95, IL_0ca3, IL_0cb7, IL_0cef, IL_0d02, IL_0d10, IL_0d57, IL_0d6a, IL_0d83, IL_0d91, IL_0d9f, IL_0daf, IL_0dc8, IL_0dd6, IL_0de4, IL_0df2, IL_0e05, IL_0e0f, IL_0e1a, IL_0e2a, IL_0e3a, IL_0e4a, IL_0e5a, IL_0e6a, IL_0e7a, IL_0e8a, IL_0e9a, IL_0ebe are reachable both inside and outside the pinned region starting at IL_0eb8. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 33;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef18 = default(int);
				ref int reference = ref __rxRef18;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e9a:
						num2 = 1;
						num = 158;
						while (true)
						{
							IL_0e8a:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e7a:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e6a:
									array2 = new byte[4];
									while (true)
									{
										IL_0e5a:
										array3 = new object[4];
										while (true)
										{
											IL_0e4a:
											array4 = new int[4];
											while (true)
											{
												IL_0e3a:
												array5 = new int[6];
												while (true)
												{
													IL_0e2a:
													array6 = new long[4];
													while (true)
													{
														IL_0e1a:
														array7 = new object[13];
														while (true)
														{
															IL_0e0f:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InterfaceIsDualSetParameters.JavaBaseCodePageEncoding);
															while (true)
															{
																IL_0e05:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_04c8:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_04b8:
																				ptr2++;
																				while (true)
																				{
																					IL_04a8:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0488:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_0478:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_0468:
																												if (5 < b)
																												{
																													while (true)
																													{
																														IL_0458:
																														if (8 < b)
																														{
																															while (true)
																															{
																																IL_044b:
																																if (9 < b)
																																{
																																	while (10 >= b)
																																	{
																																		while (10 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_03c7:
																																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																				while (true)
																																				{
																																					IL_03ae:
																																					num6 -= 2;
																																					num = 227;
																																					while (num != 227)
																																					{
																																						if (num != 1208)
																																						{
																																							goto IL_0b62;
																																						}
																																						switch (num)
																																						{
																																						case 33:
																																							break;
																																						default:
																																							continue;
																																						case 62:
																																							goto IL_03ae;
																																						case 21:
																																						case 189:
																																							goto IL_03c7;
																																						case 147:
																																							goto IL_042b;
																																						case 14:
																																							goto IL_043b;
																																						case 50:
																																						case 111:
																																							goto IL_044b;
																																						case 74:
																																						case 195:
																																							goto IL_0458;
																																						case 166:
																																						case 179:
																																							goto IL_0468;
																																						case 1:
																																							goto IL_0478;
																																						case 22:
																																							goto IL_0488;
																																						case 198:
																																							goto IL_0498;
																																						case 212:
																																							goto IL_04a8;
																																						case 104:
																																							goto IL_04b8;
																																						case 38:
																																						case 79:
																																							goto IL_04c8;
																																						case 137:
																																							goto IL_04d3;
																																						case 123:
																																						case 205:
																																							goto IL_04e1;
																																						case 84:
																																							goto IL_0521;
																																						case 180:
																																							goto IL_0535;
																																						case 214:
																																							goto IL_0548;
																																						case 61:
																																						case 169:
																																							goto IL_0556;
																																						case 80:
																																						case 206:
																																							goto IL_0564;
																																						case 116:
																																							goto IL_0572;
																																						case 59:
																																						case 112:
																																							goto IL_0580;
																																						case 178:
																																							goto IL_05c9;
																																						case 43:
																																							goto IL_05dd;
																																						case 118:
																																							goto IL_05f0;
																																						case 170:
																																						case 173:
																																							goto IL_05fe;
																																						case 2:
																																							goto IL_063e;
																																						case 215:
																																							goto IL_0652;
																																						case 108:
																																						case 208:
																																							goto IL_0665;
																																						case 114:
																																							goto IL_0678;
																																						case 91:
																																						case 103:
																																							goto IL_0686;
																																						case 100:
																																						case 145:
																																							goto IL_0694;
																																						case 81:
																																						case 101:
																																							goto IL_06a2;
																																						case 34:
																																							goto IL_06b0;
																																						case 13:
																																						case 204:
																																							goto IL_06be;
																																						case 132:
																																							goto IL_06cc;
																																						case 185:
																																							goto IL_06ef;
																																						case 157:
																																							goto IL_06f9;
																																						case 175:
																																							goto IL_0710;
																																						case 168:
																																							goto IL_0723;
																																						case 88:
																																						case 176:
																																							goto IL_0731;
																																						case 136:
																																							goto IL_075a;
																																						case 45:
																																							goto IL_0768;
																																						case 107:
																																							goto IL_077b;
																																						case 141:
																																						case 172:
																																							goto IL_0786;
																																						case 188:
																																							goto IL_07c6;
																																						case 54:
																																							goto IL_07da;
																																						case 95:
																																							goto IL_07ed;
																																						case 86:
																																							goto IL_07fb;
																																						case 49:
																																						case 202:
																																							goto IL_080e;
																																						case 146:
																																							goto IL_084e;
																																						case 143:
																																							goto IL_086b;
																																						case 73:
																																						case 156:
																																							goto IL_087e;
																																						case 85:
																																							goto IL_0892;
																																						case 105:
																																							goto IL_08ef;
																																						case 213:
																																							goto IL_08fd;
																																						case 122:
																																							goto IL_0910;
																																						case 26:
																																							goto IL_091e;
																																						case 78:
																																						case 187:
																																							goto IL_092c;
																																						case 11:
																																						case 106:
																																							goto IL_093a;
																																						case 47:
																																							goto IL_0948;
																																						case 4:
																																							goto IL_0956;
																																						case 48:
																																						case 113:
																																							goto IL_0964;
																																						case 36:
																																							goto IL_097c;
																																						case 181:
																																							goto IL_099a;
																																						case 164:
																																							goto IL_09be;
																																						case 97:
																																							goto IL_09d6;
																																						case 155:
																																							goto IL_09f2;
																																						case 60:
																																						case 126:
																																							goto IL_0a00;
																																						case 191:
																																							goto IL_0a29;
																																						case 211:
																																							goto IL_0a42;
																																						case 75:
																																							goto IL_0a50;
																																						case 18:
																																							goto IL_0a5b;
																																						case 90:
																																							goto IL_0a6e;
																																						case 174:
																																							goto IL_0a7c;
																																						case 25:
																																						case 163:
																																							goto IL_0a8a;
																																						case 23:
																																							goto IL_0b41;
																																						case 27:
																																							goto IL_0b4f;
																																						case 109:
																																						case 209:
																																							goto IL_0b62;
																																						case 121:
																																							goto IL_0b80;
																																						case 96:
																																							goto IL_0b97;
																																						case 115:
																																						case 134:
																																							goto IL_0baa;
																																						case 207:
																																							goto IL_0bb8;
																																						case 87:
																																							goto IL_0bd0;
																																						case 140:
																																							goto IL_0bde;
																																						case 68:
																																						case 200:
																																							goto IL_0bf1;
																																						case 129:
																																						case 186:
																																							goto IL_0bfc;
																																						case 142:
																																							goto IL_0c07;
																																						case 110:
																																						case 144:
																																							goto IL_0c15;
																																						case 52:
																																						case 71:
																																							goto IL_0c36;
																																						case 56:
																																							goto IL_0c44;
																																						case 5:
																																						case 57:
																																							goto IL_0c52;
																																						case 128:
																																							goto IL_0c6e;
																																						case 66:
																																						case 69:
																																							goto IL_0c7c;
																																						case 203:
																																							goto IL_0c87;
																																						case 130:
																																							goto IL_0c95;
																																						case 24:
																																						case 30:
																																							goto IL_0ca3;
																																						case 133:
																																							goto IL_0cb7;
																																						case 154:
																																							goto IL_0cef;
																																						case 199:
																																							goto IL_0d02;
																																						case 184:
																																						case 192:
																																							goto IL_0d10;
																																						case 3:
																																							goto IL_0d57;
																																						case 165:
																																						case 197:
																																							goto IL_0d6a;
																																						case 37:
																																							goto IL_0d83;
																																						case 201:
																																							goto IL_0d91;
																																						case 160:
																																							goto IL_0d9f;
																																						case 7:
																																						case 9:
																																						case 10:
																																						case 16:
																																						case 19:
																																						case 28:
																																						case 29:
																																						case 31:
																																						case 35:
																																						case 40:
																																						case 41:
																																						case 42:
																																						case 53:
																																						case 55:
																																						case 64:
																																						case 65:
																																						case 70:
																																						case 83:
																																						case 102:
																																						case 119:
																																						case 120:
																																						case 124:
																																						case 127:
																																						case 135:
																																						case 138:
																																						case 139:
																																						case 148:
																																						case 151:
																																						case 153:
																																						case 161:
																																						case 162:
																																						case 171:
																																						case 196:
																																						case 210:
																																						case 216:
																																						case 217:
																																						case 218:
																																						case 219:
																																						case 220:
																																							goto end_IL_042b;
																																						case 98:
																																							goto IL_0dc8;
																																						case 72:
																																							goto IL_0dd6;
																																						case 190:
																																							goto IL_0de4;
																																						case 0:
																																						case 15:
																																						case 17:
																																						case 20:
																																						case 39:
																																						case 44:
																																						case 46:
																																						case 51:
																																						case 63:
																																						case 67:
																																						case 76:
																																						case 77:
																																						case 92:
																																						case 99:
																																						case 117:
																																						case 125:
																																						case 149:
																																						case 150:
																																						case 152:
																																						case 159:
																																						case 167:
																																						case 177:
																																						case 182:
																																						case 183:
																																							goto end_IL_039b;
																																						case 8:
																																							goto IL_0e05;
																																						case 94:
																																							goto IL_0e0f;
																																						case 82:
																																							goto IL_0e1a;
																																						case 89:
																																							goto IL_0e2a;
																																						case 6:
																																							goto IL_0e3a;
																																						case 58:
																																							goto IL_0e4a;
																																						case 12:
																																							goto IL_0e5a;
																																						case 194:
																																							goto IL_0e6a;
																																						case 93:
																																							goto IL_0e7a;
																																						case 158:
																																							goto IL_0e8a;
																																						case 32:
																																							goto IL_0e9a;
																																						case 131:
																																						case 193:
																																							goto IL_0ebe;
																																						}
																																						goto end_IL_0df2;
																																						continue;
																																						end_IL_039b:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			goto end_IL_04a8;
																																			continue;
																																			end_IL_042b:
																																			break;
																																			IL_042b:;
																																		}
																																		break;
																																		IL_043b:;
																																	}
																																	break;
																																}
																																goto IL_04d3;
																																IL_0535:
																																num6--;
																																goto end_IL_04a8;
																																IL_04d3:
																																if (9 > b)
																																{
																																	break;
																																}
																																goto IL_04e1;
																																IL_04e1:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0521;
																																IL_0521:
																																array2[num6 - 2] = 0;
																																goto IL_0535;
																															}
																															break;
																														}
																														goto IL_0548;
																														IL_0665:
																														num6--;
																														goto end_IL_04a8;
																														IL_0548:
																														if (8 > b)
																														{
																															goto IL_0556;
																														}
																														goto IL_0665;
																														IL_0556:
																														if (6 < b)
																														{
																															goto IL_0564;
																														}
																														goto IL_05f0;
																														IL_0564:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_0572;
																														IL_0572:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_0580;
																														IL_0580:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														num = 178;
																														goto IL_05c9;
																														IL_05c9:
																														array2[num6 - 2] = 0;
																														goto IL_05dd;
																														IL_05dd:
																														num6--;
																														goto end_IL_04a8;
																														IL_05f0:
																														if (6 > b)
																														{
																															break;
																														}
																														goto IL_05fe;
																														IL_05fe:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_063e;
																														IL_063e:
																														array2[num6 - 2] = 0;
																														goto IL_0652;
																														IL_0652:
																														num6--;
																														goto end_IL_04a8;
																													}
																													break;
																												}
																												goto IL_0678;
																												IL_086b:
																												num6--;
																												goto end_IL_04a8;
																												IL_0678:
																												if (5 > b)
																												{
																													goto IL_0686;
																												}
																												goto IL_080e;
																												IL_0686:
																												if (2 < b)
																												{
																													goto IL_0694;
																												}
																												goto IL_077b;
																												IL_0694:
																												if (3 < b)
																												{
																													goto IL_06a2;
																												}
																												goto IL_0723;
																												IL_06a2:
																												if (4 < b)
																												{
																													break;
																												}
																												goto IL_06b0;
																												IL_06b0:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_06be;
																												IL_06be:
																												array2[num6] = 0;
																												goto IL_06cc;
																												IL_06cc:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																												goto IL_06ef;
																												IL_06ef:
																												array3[num6] = null;
																												goto IL_06f9;
																												IL_06f9:
																												num6++;
																												num = 175;
																												goto IL_0710;
																												IL_0710:
																												ptr2 += 8;
																												goto end_IL_04a8;
																												IL_0723:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_0731;
																												IL_0731:
																												reference = ref array5[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_075a;
																												IL_075a:
																												ptr2 += 8;
																												goto IL_0768;
																												IL_0768:
																												num6--;
																												goto end_IL_04a8;
																												IL_077b:
																												if (2 <= b)
																												{
																													goto IL_0786;
																												}
																												goto IL_07ed;
																												IL_0786:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_07c6;
																												IL_07c6:
																												array2[num6 - 2] = 0;
																												goto IL_07da;
																												IL_07da:
																												num6--;
																												goto end_IL_04a8;
																												IL_07ed:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_07fb;
																												IL_07fb:
																												if (1 <= b)
																												{
																												}
																												break;
																												IL_080e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_084e;
																												IL_084e:
																												array2[num6 - 2] = 0;
																												num = 143;
																												goto IL_086b;
																											}
																											break;
																										}
																										goto IL_087e;
																										IL_08fd:
																										ptr2 += 8;
																										goto end_IL_04a8;
																										IL_087e:
																										array2[num6 - 2] = 0;
																										goto IL_0892;
																										IL_0892:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getLocalCreatorAuthority[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										num = 105;
																										goto IL_08ef;
																										IL_08ef:
																										num6--;
																										goto IL_08fd;
																									}
																									break;
																								}
																								goto IL_0910;
																								IL_0d57:
																								num6 -= 3;
																								goto end_IL_04a8;
																								IL_0910:
																								if (17 >= b)
																								{
																									goto IL_091e;
																								}
																								goto IL_0bf1;
																								IL_091e:
																								if (17 > b)
																								{
																									goto IL_092c;
																								}
																								goto IL_0baa;
																								IL_092c:
																								if (14 < b)
																								{
																									goto IL_093a;
																								}
																								goto IL_0a42;
																								IL_093a:
																								if (15 < b)
																								{
																									goto IL_0948;
																								}
																								goto IL_09f2;
																								IL_0948:
																								if (16 < b)
																								{
																									break;
																								}
																								goto IL_0956;
																								IL_0956:
																								if (16 > b)
																								{
																									break;
																								}
																								goto IL_0964;
																								IL_0964:
																								array2[num6] = array2[num6 - 1];
																								goto IL_097c;
																								IL_097c:
																								array4[num6 - 0] = array4[num6 - 1];
																								goto IL_099a;
																								IL_099a:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09be;
																								IL_09be:
																								array3[num6] = array3[num6 - 1];
																								goto IL_09d6;
																								IL_09d6:
																								num6++;
																								num = 159;
																								goto end_IL_04a8;
																								IL_09f2:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0a00;
																								IL_0a00:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_0a29;
																								IL_0a29:
																								array2[num6 - 1] = 5;
																								goto end_IL_04a8;
																								IL_0a42:
																								if (14 > b)
																								{
																									goto IL_0a50;
																								}
																								goto IL_0b62;
																								IL_0a50:
																								if (12 >= b)
																								{
																									goto IL_0a5b;
																								}
																								goto IL_0a6e;
																								IL_0a5b:
																								if (12 <= b)
																								{
																									goto end_IL_04a8;
																								}
																								break;
																								IL_0a6e:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_0a7c;
																								IL_0a7c:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_0a8a;
																								IL_0a8a:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0a99;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0b41;
																								IL_0d6a:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0d83;
																								IL_0d83:
																								array2[num6] = 1;
																								goto IL_0d91;
																								IL_0d91:
																								num6++;
																								goto IL_0d9f;
																								IL_0b41:
																								array2[num6] = 5;
																								goto IL_0b4f;
																								IL_0b4f:
																								num6++;
																								goto end_IL_04a8;
																								IL_0b62:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0b80;
																								IL_0b80:
																								ptr2 += 8;
																								num = 96;
																								goto IL_0b97;
																								IL_0b97:
																								num6--;
																								goto end_IL_04a8;
																								IL_0baa:
																								array2[num6] = 5;
																								goto IL_0bb8;
																								IL_0bb8:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0bd0;
																								IL_0bd0:
																								num6++;
																								goto IL_0bde;
																								IL_0bde:
																								ptr2 += 8;
																								goto end_IL_04a8;
																								IL_0bf1:
																								if (20 < b)
																								{
																									goto IL_0bfc;
																								}
																								goto IL_0c6e;
																								IL_0bfc:
																								if (21 >= b)
																								{
																									goto IL_0c07;
																								}
																								num = 71;
																								goto IL_0c36;
																								IL_0c07:
																								if (21 > b)
																								{
																									break;
																								}
																								goto IL_0c15;
																								IL_0c15:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_04a8;
																								IL_0d9f:
																								ptr2 += 16;
																								goto end_IL_04a8;
																								IL_0c36:
																								if (22 < b)
																								{
																									break;
																								}
																								goto IL_0c44;
																								IL_0c44:
																								if (22 > b)
																								{
																									break;
																								}
																								goto IL_0c52;
																								IL_0c52:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto end_IL_04a8;
																								IL_0c6e:
																								if (20 > b)
																								{
																									goto IL_0c7c;
																								}
																								goto IL_0d6a;
																								IL_0c7c:
																								if (18 < b)
																								{
																									goto IL_0c87;
																								}
																								goto IL_0d02;
																								IL_0c87:
																								if (19 < b)
																								{
																									break;
																								}
																								goto IL_0c95;
																								IL_0c95:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_0ca3;
																								IL_0ca3:
																								array2[num6 - 1] = 5;
																								goto IL_0cb7;
																								IL_0cb7:
																								array3[num6 - 1] = ((delegate*<string[], string>)getLocalCreatorAuthority[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0cef;
																								IL_0cef:
																								ptr2 += 8;
																								goto end_IL_04a8;
																								IL_0d02:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_0d10;
																								IL_0d10:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								num = 3;
																								goto IL_0d57;
																							}
																							break;
																							IL_0498:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0dc8;
																					IL_0de4:
																					ptr2 += 8;
																					break;
																					IL_0dd6:
																					num6++;
																					goto IL_0de4;
																					IL_0dc8:
																					array2[num6] = 0;
																					goto IL_0dd6;
																					continue;
																					end_IL_04a8:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0ebe;
																	IL_0ebe:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0df2:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0a99:
				while (true)
				{
					IL_0a99_2:
					array = new byte[4];
					while (true)
					{
						IL_0aa7:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0b4f_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_04c8_2:
											byte b = *ptr2;
											while (true)
											{
												IL_04b8_2:
												ptr2++;
												while (true)
												{
													IL_04a8_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_0488_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_0478_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_0468_2:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0458_2:
																						if (8 < b)
																						{
																							while (true)
																							{
																								IL_044b_2:
																								if (9 < b)
																								{
																									while (10 >= b)
																									{
																										while (10 <= b)
																										{
																											while (true)
																											{
																												IL_03c7_2:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												while (true)
																												{
																													IL_03ae_2:
																													num6 -= 2;
																													num = 227;
																													while (num != 227)
																													{
																														if (num != 1208)
																														{
																															goto IL_0b62_2;
																														}
																														switch (num)
																														{
																														case 62:
																															goto IL_03ae_2;
																														case 21:
																														case 189:
																															goto IL_03c7_2;
																														case 147:
																															goto IL_042b_2;
																														case 14:
																															goto IL_043b_2;
																														case 50:
																														case 111:
																															goto IL_044b_2;
																														case 74:
																														case 195:
																															goto IL_0458_2;
																														case 166:
																														case 179:
																															goto IL_0468_2;
																														case 1:
																															goto IL_0478_2;
																														case 22:
																															goto IL_0488_2;
																														case 198:
																															goto IL_0498_2;
																														case 212:
																															goto IL_04a8_2;
																														case 104:
																															goto IL_04b8_2;
																														case 38:
																														case 79:
																															goto IL_04c8_2;
																														case 137:
																															goto IL_04d3_2;
																														case 123:
																														case 205:
																															goto IL_04e1_2;
																														case 84:
																															goto IL_0521_2;
																														case 180:
																															goto IL_0535_2;
																														case 214:
																															goto IL_0548_2;
																														case 61:
																														case 169:
																															goto IL_0556_2;
																														case 80:
																														case 206:
																															goto IL_0564_2;
																														case 116:
																															goto IL_0572_2;
																														case 59:
																														case 112:
																															goto IL_0580_2;
																														case 178:
																															goto IL_05c9_2;
																														case 43:
																															goto IL_05dd_2;
																														case 118:
																															goto IL_05f0_2;
																														case 170:
																														case 173:
																															goto IL_05fe_2;
																														case 2:
																															goto IL_063e_2;
																														case 215:
																															goto IL_0652_2;
																														case 108:
																														case 208:
																															goto IL_0665_2;
																														case 114:
																															goto IL_0678_2;
																														case 91:
																														case 103:
																															goto IL_0686_2;
																														case 100:
																														case 145:
																															goto IL_0694_2;
																														case 81:
																														case 101:
																															goto IL_06a2_2;
																														case 34:
																															goto IL_06b0_2;
																														case 13:
																														case 204:
																															goto IL_06be_2;
																														case 132:
																															goto IL_06cc_2;
																														case 185:
																															goto IL_06ef_2;
																														case 157:
																															goto IL_06f9_2;
																														case 175:
																															goto IL_0710_2;
																														case 168:
																															goto IL_0723_2;
																														case 88:
																														case 176:
																															goto IL_0731_2;
																														case 136:
																															goto IL_075a_2;
																														case 45:
																															goto IL_0768_2;
																														case 107:
																															goto IL_077b_2;
																														case 141:
																														case 172:
																															goto IL_0786_2;
																														case 188:
																															goto IL_07c6_2;
																														case 54:
																															goto IL_07da_2;
																														case 95:
																															goto IL_07ed_2;
																														case 86:
																															goto IL_07fb_2;
																														case 49:
																														case 202:
																															goto IL_080e_2;
																														case 146:
																															goto IL_084e_2;
																														case 143:
																															goto IL_086b_2;
																														case 73:
																														case 156:
																															goto IL_087e_2;
																														case 85:
																															goto IL_0892_2;
																														case 105:
																															goto IL_08ef_2;
																														case 213:
																															goto IL_08fd_2;
																														case 122:
																															goto IL_0910_2;
																														case 26:
																															goto IL_091e_2;
																														case 78:
																														case 187:
																															goto IL_092c_2;
																														case 11:
																														case 106:
																															goto IL_093a_2;
																														case 47:
																															goto IL_0948_2;
																														case 4:
																															goto IL_0956_2;
																														case 48:
																														case 113:
																															goto IL_0964_2;
																														case 36:
																															goto IL_097c_2;
																														case 181:
																															goto IL_099a_2;
																														case 164:
																															goto IL_09be_2;
																														case 97:
																															goto IL_09d6_2;
																														case 155:
																															goto IL_09f2_2;
																														case 60:
																														case 126:
																															goto IL_0a00_2;
																														case 191:
																															goto IL_0a29_2;
																														case 211:
																															goto IL_0a42_2;
																														case 75:
																															goto IL_0a50_2;
																														case 18:
																															goto IL_0a5b_2;
																														case 90:
																															goto IL_0a6e_2;
																														case 174:
																															goto IL_0a7c_2;
																														case 25:
																														case 163:
																															goto IL_0a8a_2;
																														case 23:
																															goto end_IL_0df2_2;
																														case 27:
																															goto IL_0b4f_2;
																														case 109:
																														case 209:
																															goto IL_0b62_2;
																														case 121:
																															goto IL_0b80_2;
																														case 96:
																															goto IL_0b97_2;
																														case 115:
																														case 134:
																															goto IL_0baa_2;
																														case 207:
																															goto IL_0bb8_2;
																														case 87:
																															goto IL_0bd0_2;
																														case 140:
																															goto IL_0bde_2;
																														case 68:
																														case 200:
																															goto IL_0bf1_2;
																														case 129:
																														case 186:
																															goto IL_0bfc_2;
																														case 142:
																															goto IL_0c07_2;
																														case 110:
																														case 144:
																															goto IL_0c15_2;
																														case 52:
																														case 71:
																															goto IL_0c36_2;
																														case 56:
																															goto IL_0c44_2;
																														case 5:
																														case 57:
																															goto IL_0c52_2;
																														case 128:
																															goto IL_0c6e_2;
																														case 66:
																														case 69:
																															goto IL_0c7c_2;
																														case 203:
																															goto IL_0c87_2;
																														case 130:
																															goto IL_0c95_2;
																														case 24:
																														case 30:
																															goto IL_0ca3_2;
																														case 133:
																															goto IL_0cb7_2;
																														case 154:
																															goto IL_0cef_2;
																														case 199:
																															goto IL_0d02_2;
																														case 184:
																														case 192:
																															goto IL_0d10_2;
																														case 3:
																															goto IL_0d57_2;
																														case 165:
																														case 197:
																															goto IL_0d6a_2;
																														case 37:
																															goto IL_0d83_2;
																														case 201:
																															goto IL_0d91_2;
																														case 160:
																															goto IL_0d9f_2;
																														case 7:
																														case 9:
																														case 10:
																														case 16:
																														case 19:
																														case 28:
																														case 29:
																														case 31:
																														case 35:
																														case 40:
																														case 41:
																														case 42:
																														case 53:
																														case 55:
																														case 64:
																														case 65:
																														case 70:
																														case 83:
																														case 102:
																														case 119:
																														case 120:
																														case 124:
																														case 127:
																														case 135:
																														case 138:
																														case 139:
																														case 148:
																														case 151:
																														case 153:
																														case 161:
																														case 162:
																														case 171:
																														case 196:
																														case 210:
																														case 216:
																														case 217:
																														case 218:
																														case 219:
																														case 220:
																															goto end_IL_042b_2;
																														case 98:
																															goto IL_0dc8_2;
																														case 72:
																															goto IL_0dd6_2;
																														case 190:
																															goto IL_0de4_2;
																														case 0:
																														case 15:
																														case 17:
																														case 20:
																														case 39:
																														case 44:
																														case 46:
																														case 51:
																														case 63:
																														case 67:
																														case 76:
																														case 77:
																														case 92:
																														case 99:
																														case 117:
																														case 125:
																														case 149:
																														case 150:
																														case 152:
																														case 159:
																														case 167:
																														case 177:
																														case 182:
																														case 183:
																															goto end_IL_039b_2;
																														case 8:
																															ptr2 = ptr;
																															goto end_IL_039b_2;
																														case 94:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InterfaceIsDualSetParameters.JavaBaseCodePageEncoding);
																															goto case 8;
																														case 82:
																															array7 = new object[13];
																															goto case 94;
																														case 89:
																															array6 = new long[4];
																															goto case 82;
																														case 6:
																															array5 = new int[6];
																															goto case 89;
																														case 58:
																															array4 = new int[4];
																															goto case 6;
																														case 12:
																															array3 = new object[4];
																															goto case 58;
																														case 194:
																															array2 = new byte[4];
																															goto case 12;
																														case 93:
																															num4 = num2 * 8;
																															goto case 194;
																														case 158:
																															num3 = num2 * 4;
																															goto case 93;
																														case 32:
																															num2 = 1;
																															num = 158;
																															goto case 158;
																														case 33:
																															goto end_IL_0b41;
																														case 131:
																														case 193:
																															goto IL_0ebe_2;
																														}
																														continue;
																														end_IL_039b_2:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_04a8_2;
																											continue;
																											end_IL_042b_2:
																											break;
																											IL_042b_2:;
																										}
																										break;
																										IL_043b_2:;
																									}
																									break;
																								}
																								goto IL_04d3_2;
																								IL_0535_2:
																								num6--;
																								goto end_IL_04a8_2;
																								IL_04d3_2:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_04e1_2;
																								IL_04e1_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0521_2;
																								IL_0521_2:
																								array2[num6 - 2] = 0;
																								goto IL_0535_2;
																							}
																							break;
																						}
																						goto IL_0548_2;
																						IL_0665_2:
																						num6--;
																						goto end_IL_04a8_2;
																						IL_0548_2:
																						if (8 > b)
																						{
																							goto IL_0556_2;
																						}
																						goto IL_0665_2;
																						IL_0556_2:
																						if (6 < b)
																						{
																							goto IL_0564_2;
																						}
																						goto IL_05f0_2;
																						IL_0564_2:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0572_2;
																						IL_0572_2:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0580_2;
																						IL_0580_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 178;
																						goto IL_05c9_2;
																						IL_05c9_2:
																						array2[num6 - 2] = 0;
																						goto IL_05dd_2;
																						IL_05dd_2:
																						num6--;
																						goto end_IL_04a8_2;
																						IL_05f0_2:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_05fe_2;
																						IL_05fe_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_063e_2;
																						IL_063e_2:
																						array2[num6 - 2] = 0;
																						goto IL_0652_2;
																						IL_0652_2:
																						num6--;
																						goto end_IL_04a8_2;
																					}
																					break;
																				}
																				goto IL_0678_2;
																				IL_086b_2:
																				num6--;
																				goto end_IL_04a8_2;
																				IL_0678_2:
																				if (5 > b)
																				{
																					goto IL_0686_2;
																				}
																				goto IL_080e_2;
																				IL_0686_2:
																				if (2 < b)
																				{
																					goto IL_0694_2;
																				}
																				goto IL_077b_2;
																				IL_0694_2:
																				if (3 < b)
																				{
																					goto IL_06a2_2;
																				}
																				goto IL_0723_2;
																				IL_06a2_2:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_06b0_2;
																				IL_06b0_2:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_06be_2;
																				IL_06be_2:
																				array2[num6] = 0;
																				goto IL_06cc_2;
																				IL_06cc_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				goto IL_06ef_2;
																				IL_06ef_2:
																				array3[num6] = null;
																				goto IL_06f9_2;
																				IL_06f9_2:
																				num6++;
																				num = 175;
																				goto IL_0710_2;
																				IL_0710_2:
																				ptr2 += 8;
																				goto end_IL_04a8_2;
																				IL_0723_2:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0731_2;
																				IL_0731_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_075a_2;
																				IL_075a_2:
																				ptr2 += 8;
																				goto IL_0768_2;
																				IL_0768_2:
																				num6--;
																				goto end_IL_04a8_2;
																				IL_077b_2:
																				if (2 <= b)
																				{
																					goto IL_0786_2;
																				}
																				goto IL_07ed_2;
																				IL_0786_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_07c6_2;
																				IL_07c6_2:
																				array2[num6 - 2] = 0;
																				goto IL_07da_2;
																				IL_07da_2:
																				num6--;
																				goto end_IL_04a8_2;
																				IL_07ed_2:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_07fb_2;
																				IL_07fb_2:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_080e_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_084e_2;
																				IL_084e_2:
																				array2[num6 - 2] = 0;
																				num = 143;
																				goto IL_086b_2;
																			}
																			break;
																		}
																		goto IL_087e_2;
																		IL_08fd_2:
																		ptr2 += 8;
																		goto end_IL_04a8_2;
																		IL_087e_2:
																		array2[num6 - 2] = 0;
																		goto IL_0892_2;
																		IL_0892_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)getLocalCreatorAuthority[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		num = 105;
																		goto IL_08ef_2;
																		IL_08ef_2:
																		num6--;
																		goto IL_08fd_2;
																	}
																	break;
																}
																goto IL_0910_2;
																IL_0d91_2:
																num6++;
																goto IL_0d9f_2;
																IL_0910_2:
																if (17 >= b)
																{
																	goto IL_091e_2;
																}
																goto IL_0bf1_2;
																IL_091e_2:
																if (17 > b)
																{
																	goto IL_092c_2;
																}
																goto IL_0baa_2;
																IL_092c_2:
																if (14 < b)
																{
																	goto IL_093a_2;
																}
																goto IL_0a42_2;
																IL_093a_2:
																if (15 < b)
																{
																	goto IL_0948_2;
																}
																goto IL_09f2_2;
																IL_0948_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_0956_2;
																IL_0956_2:
																if (16 > b)
																{
																	break;
																}
																goto IL_0964_2;
																IL_0964_2:
																array2[num6] = array2[num6 - 1];
																goto IL_097c_2;
																IL_097c_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_099a_2;
																IL_099a_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09be_2;
																IL_09be_2:
																array3[num6] = array3[num6 - 1];
																goto IL_09d6_2;
																IL_09d6_2:
																num6++;
																num = 159;
																goto end_IL_04a8_2;
																IL_09f2_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_0a00_2;
																IL_0a00_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_0a29_2;
																IL_0a29_2:
																array2[num6 - 1] = 5;
																goto end_IL_04a8_2;
																IL_0a42_2:
																if (14 > b)
																{
																	goto IL_0a50_2;
																}
																goto IL_0b62_2;
																IL_0a50_2:
																if (12 >= b)
																{
																	goto IL_0a5b_2;
																}
																goto IL_0a6e_2;
																IL_0a5b_2:
																if (12 <= b)
																{
																	goto end_IL_04a8_2;
																}
																break;
																IL_0a6e_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_0a7c_2;
																IL_0a7c_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_0a8a_2;
																IL_0a8a_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0a99_2;
																}
																goto IL_0aa7;
																IL_0b62_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0b80_2;
																IL_0b80_2:
																ptr2 += 8;
																num = 96;
																goto IL_0b97_2;
																IL_0b97_2:
																num6--;
																goto end_IL_04a8_2;
																IL_0baa_2:
																array2[num6] = 5;
																goto IL_0bb8_2;
																IL_0bb8_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0bd0_2;
																IL_0bd0_2:
																num6++;
																goto IL_0bde_2;
																IL_0bde_2:
																ptr2 += 8;
																goto end_IL_04a8_2;
																IL_0bf1_2:
																if (20 < b)
																{
																	goto IL_0bfc_2;
																}
																goto IL_0c6e_2;
																IL_0bfc_2:
																if (21 >= b)
																{
																	goto IL_0c07_2;
																}
																num = 71;
																goto IL_0c36_2;
																IL_0c07_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_0c15_2;
																IL_0c15_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_04a8_2;
																IL_0d9f_2:
																ptr2 += 16;
																goto end_IL_04a8_2;
																IL_0c36_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_0c44_2;
																IL_0c44_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_0c52_2;
																IL_0c52_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																goto end_IL_04a8_2;
																IL_0c6e_2:
																if (20 > b)
																{
																	goto IL_0c7c_2;
																}
																goto IL_0d6a_2;
																IL_0c7c_2:
																if (18 < b)
																{
																	goto IL_0c87_2;
																}
																goto IL_0d02_2;
																IL_0c87_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0c95_2;
																IL_0c95_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_0ca3_2;
																IL_0ca3_2:
																array2[num6 - 1] = 5;
																goto IL_0cb7_2;
																IL_0cb7_2:
																array3[num6 - 1] = ((delegate*<string[], string>)getLocalCreatorAuthority[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0cef_2;
																IL_0cef_2:
																ptr2 += 8;
																goto end_IL_04a8_2;
																IL_0d02_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_0d10_2;
																IL_0d10_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																num = 3;
																goto IL_0d57_2;
																IL_0d57_2:
																num6 -= 3;
																goto end_IL_04a8_2;
																IL_0d6a_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0d83_2;
																IL_0d83_2:
																array2[num6] = 1;
																goto IL_0d91_2;
															}
															break;
															IL_0498_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0dc8_2;
													IL_0de4_2:
													ptr2 += 8;
													break;
													IL_0dd6_2:
													num6++;
													goto IL_0de4_2;
													IL_0dc8_2:
													array2[num6] = 0;
													goto IL_0dd6_2;
													continue;
													end_IL_04a8_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0ebe_2;
									IL_0ebe_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0df2_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0b41:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_0367, IL_037a, IL_0393, IL_03a3, IL_03b1, IL_03bf, IL_03cd, IL_03db, IL_03e9, IL_03f4, IL_03ff, IL_040d, IL_0420, IL_0433, IL_0441, IL_044f, IL_0462, IL_046b, IL_0476, IL_0484, IL_0492, IL_04a5, IL_04b3, IL_04be, IL_04cc, IL_04df, IL_04f2, IL_04fd, IL_050b, IL_0516, IL_051f, IL_052a, IL_0538, IL_054b, IL_055e, IL_056c, IL_057c, IL_0587, IL_0595, IL_05a0, IL_05ab, IL_05bb, IL_05cb, IL_05d6, IL_05e6, IL_05f6, IL_0606, IL_0611, IL_061a, IL_0628, IL_0646, IL_0656, IL_0666, IL_0671, IL_06b1, IL_06c5, IL_06d8, IL_06e6, IL_06ef, IL_075a, IL_076d, IL_07ad, IL_07ca, IL_07dd, IL_07f0, IL_0808, IL_082b, IL_0854, IL_086d, IL_0894, IL_08ab, IL_08be, IL_08cc, IL_090a, IL_091d, IL_0936, IL_0944, IL_0952, IL_0965, IL_097d, IL_099a, IL_09e9, IL_09f3, IL_0a20, IL_0a3d, IL_0a4b, IL_0a5e, IL_0a67, IL_0aa7, IL_0abb, IL_0ace, IL_0ae1, IL_0b05, IL_0b1d, IL_0b30, IL_0b70, IL_0b84, IL_0b97, IL_0bb4, IL_0bec, IL_0bff, IL_0c0d, IL_0c25, IL_0c33, IL_0c46, IL_0c6f, IL_0c7d, IL_0c90, IL_0cb3, IL_0cbd, IL_0ccb, IL_0cde, IL_0d1e, IL_0d32, IL_0d42, IL_0d5b, IL_0d72, IL_0d85, IL_0d8f, IL_0d9a, IL_0daa, IL_0dba, IL_0dca, IL_0dda, IL_0dea, IL_0dfa, IL_0e13, IL_0e23, IL_0e3e are reachable both inside and outside the pinned region starting at IL_0e38. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 92;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef19 = default(int);
				ref int reference = ref __rxRef19;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e23:
						num2 = 1;
						while (true)
						{
							IL_0e13:
							num3 = num2 * 4;
							while (true)
							{
								IL_0dfa:
								num4 = num2 * 8;
								num = 67;
								while (true)
								{
									IL_0dea:
									array2 = new byte[4];
									while (true)
									{
										IL_0dda:
										array3 = new object[4];
										while (true)
										{
											IL_0dca:
											array4 = new int[4];
											while (true)
											{
												IL_0dba:
												array5 = new int[6];
												while (true)
												{
													IL_0daa:
													array6 = new long[4];
													while (true)
													{
														IL_0d9a:
														array7 = new object[17];
														while (true)
														{
															IL_0d8f:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BuildGregorianCalendarTypes.setSecurityEnabledsetKeyStore);
															while (true)
															{
																IL_0d85:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d72:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0666:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0656:
																				ptr2++;
																				while (true)
																				{
																					IL_0646:
																					if (b >= 1)
																					{
																						goto IL_03a3;
																					}
																					goto IL_0628;
																					IL_0628:
																					while (true)
																					{
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						while (true)
																						{
																							IL_0393:
																							array2[num6] = 0;
																							while (true)
																							{
																								IL_037a:
																								num6++;
																								num = 214;
																								while (true)
																								{
																									if (num != 214)
																									{
																										if (num != 1195)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 92:
																											break;
																										default:
																											continue;
																										case 24:
																											goto IL_037a;
																										case 23:
																											goto IL_0393;
																										case 27:
																											goto IL_03a3;
																										case 186:
																											goto IL_03b1;
																										case 11:
																											goto IL_03bf;
																										case 44:
																										case 175:
																											goto IL_03cd;
																										case 157:
																											goto IL_03db;
																										case 71:
																											goto IL_03e9;
																										case 154:
																										case 160:
																											goto IL_03f4;
																										case 54:
																										case 118:
																											goto IL_03ff;
																										case 149:
																											goto IL_040d;
																										case 1:
																											goto IL_0420;
																										case 95:
																											goto IL_0433;
																										case 163:
																											goto IL_0441;
																										case 134:
																											goto IL_044f;
																										case 114:
																										case 165:
																											goto IL_046b;
																										case 84:
																										case 146:
																											goto IL_0476;
																										case 20:
																										case 22:
																											goto IL_0484;
																										case 41:
																											goto IL_0492;
																										case 158:
																											goto IL_04a5;
																										case 45:
																										case 119:
																											goto IL_04b3;
																										case 0:
																										case 132:
																											goto IL_04be;
																										case 145:
																											goto IL_04cc;
																										case 81:
																											goto IL_04df;
																										case 86:
																											goto IL_04f2;
																										case 152:
																											goto IL_04fd;
																										case 18:
																										case 77:
																											goto IL_050b;
																										case 102:
																										case 129:
																											goto IL_051f;
																										case 42:
																										case 171:
																											goto IL_052a;
																										case 137:
																											goto IL_0538;
																										case 57:
																											goto IL_054b;
																										case 139:
																											goto IL_055e;
																										case 17:
																										case 151:
																											goto IL_056c;
																										case 10:
																											goto IL_057c;
																										case 172:
																											goto IL_0587;
																										case 179:
																											goto IL_0595;
																										case 116:
																											goto IL_05a0;
																										case 135:
																											goto IL_05ab;
																										case 5:
																											goto IL_05bb;
																										case 170:
																											goto IL_05cb;
																										case 162:
																											goto IL_05d6;
																										case 187:
																											goto IL_05e6;
																										case 189:
																											goto IL_05f6;
																										case 7:
																										case 193:
																											goto IL_0606;
																										case 206:
																											goto IL_061a;
																										case 2:
																										case 3:
																										case 4:
																										case 25:
																										case 28:
																										case 29:
																										case 39:
																										case 43:
																										case 51:
																										case 53:
																										case 68:
																										case 78:
																										case 82:
																										case 87:
																										case 89:
																										case 106:
																										case 109:
																										case 110:
																										case 111:
																										case 122:
																										case 130:
																										case 142:
																										case 144:
																										case 148:
																										case 155:
																										case 156:
																										case 161:
																										case 166:
																										case 168:
																										case 169:
																										case 174:
																										case 180:
																										case 183:
																										case 185:
																										case 200:
																											goto end_IL_0367;
																										case 136:
																											goto IL_0646;
																										case 9:
																											goto IL_0656;
																										case 19:
																										case 131:
																											goto IL_0666;
																										case 26:
																										case 48:
																											goto IL_0671;
																										case 34:
																											goto IL_06b1;
																										case 40:
																											goto IL_06c5;
																										case 37:
																										case 85:
																											goto IL_06ef;
																										case 49:
																											goto IL_075a;
																										case 60:
																										case 98:
																											goto IL_076d;
																										case 32:
																											goto IL_07ad;
																										case 164:
																											goto IL_07ca;
																										case 153:
																										case 181:
																											goto IL_07dd;
																										case 33:
																										case 47:
																											goto IL_07f0;
																										case 124:
																											goto IL_0808;
																										case 61:
																										case 128:
																											goto IL_082b;
																										case 46:
																											goto IL_0854;
																										case 52:
																										case 99:
																											goto IL_086d;
																										case 108:
																											goto IL_0894;
																										case 113:
																											goto IL_08ab;
																										case 50:
																										case 182:
																											goto IL_08cc;
																										case 64:
																											goto IL_090a;
																										case 6:
																										case 14:
																											goto IL_091d;
																										case 107:
																											goto IL_0936;
																										case 79:
																											goto IL_0944;
																										case 70:
																											goto IL_0952;
																										case 83:
																										case 127:
																											goto IL_0965;
																										case 36:
																										case 75:
																											goto IL_097d;
																										case 80:
																											goto IL_0a3d;
																										case 94:
																											goto IL_0a4b;
																										case 65:
																										case 73:
																											goto IL_0a67;
																										case 74:
																											goto IL_0aa7;
																										case 12:
																											goto IL_0abb;
																										case 8:
																										case 190:
																											goto IL_0ace;
																										case 191:
																											goto IL_0ae1;
																										case 103:
																											goto IL_0b05;
																										case 69:
																											goto IL_0b1d;
																										case 55:
																										case 192:
																											goto IL_0b30;
																										case 125:
																											goto IL_0b70;
																										case 123:
																											goto IL_0b84;
																										case 15:
																										case 197:
																											goto IL_0b97;
																										case 194:
																											goto IL_0bb4;
																										case 76:
																											goto IL_0bec;
																										case 101:
																										case 199:
																											goto IL_0bff;
																										case 88:
																											goto IL_0c0d;
																										case 59:
																											goto IL_0c25;
																										case 150:
																											goto IL_0c33;
																										case 13:
																										case 201:
																											goto IL_0c46;
																										case 90:
																											goto IL_0c6f;
																										case 62:
																											goto IL_0c7d;
																										case 202:
																											goto IL_0c90;
																										case 138:
																											goto IL_0cb3;
																										case 105:
																											goto IL_0cbd;
																										case 30:
																											goto IL_0ccb;
																										case 143:
																										case 204:
																											goto IL_0cde;
																										case 72:
																											goto IL_0d1e;
																										case 120:
																											goto IL_0d32;
																										case 16:
																										case 159:
																											goto IL_0d42;
																										case 21:
																										case 31:
																										case 35:
																										case 38:
																										case 56:
																										case 58:
																										case 63:
																										case 66:
																										case 93:
																										case 96:
																										case 97:
																										case 100:
																										case 112:
																										case 117:
																										case 126:
																										case 133:
																										case 140:
																										case 167:
																										case 173:
																										case 178:
																										case 184:
																										case 195:
																										case 198:
																										case 203:
																											goto IL_0d72;
																										case 141:
																											goto IL_0d85;
																										case 176:
																											goto IL_0d8f;
																										case 205:
																											goto IL_0d9a;
																										case 196:
																											goto IL_0daa;
																										case 147:
																											goto IL_0dba;
																										case 177:
																											goto IL_0dca;
																										case 188:
																											goto IL_0dda;
																										case 67:
																											goto IL_0dea;
																										case 104:
																											goto IL_0dfa;
																										case 207:
																											goto IL_0e13;
																										case 91:
																											goto IL_0e23;
																										case 115:
																										case 121:
																											goto IL_0e3e;
																										}
																										goto end_IL_0628;
																									}
																									ptr2 += 8;
																									num = 66;
																									goto IL_0d72;
																									continue;
																									end_IL_0367:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						continue;
																						end_IL_0628:
																						break;
																					}
																					break;
																					IL_03a3:
																					if (b <= 21)
																					{
																						goto IL_03b1;
																					}
																					goto IL_0628;
																					IL_03b1:
																					if (11 >= b)
																					{
																						goto IL_03bf;
																					}
																					goto IL_04f2;
																					IL_03bf:
																					if (11 <= b)
																					{
																						goto IL_0d72;
																					}
																					goto IL_03cd;
																					IL_03cd:
																					if (5 >= b)
																					{
																						goto IL_03db;
																					}
																					num = 114;
																					goto IL_046b;
																					IL_03db:
																					if (5 > b)
																					{
																						goto IL_03e9;
																					}
																					goto IL_0671;
																					IL_03e9:
																					if (2 < b)
																					{
																						goto IL_03f4;
																					}
																					goto IL_0433;
																					IL_03f4:
																					if (3 < b)
																					{
																						goto IL_03ff;
																					}
																					goto IL_0420;
																					IL_03ff:
																					if (4 >= b)
																					{
																						goto IL_040d;
																					}
																					goto IL_0628;
																					IL_040d:
																					if (4 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_0ace;
																					IL_0ace:
																					array2[num6] = 0;
																					goto IL_0c90;
																					IL_0c90:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																					goto IL_0cb3;
																					IL_0cb3:
																					array3[num6] = null;
																					goto IL_0cbd;
																					IL_0cbd:
																					num6++;
																					goto IL_0ccb;
																					IL_0ccb:
																					ptr2 += 8;
																					goto IL_0d72;
																					IL_0420:
																					if (3 > b)
																					{
																						goto IL_0628;
																					}
																					num = 13;
																					goto IL_0c46;
																					IL_0944:
																					num6++;
																					goto IL_0952;
																					IL_0c46:
																					reference = ref array5[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0c6f;
																					IL_0c6f:
																					ptr2 += 8;
																					goto IL_0c7d;
																					IL_0c7d:
																					num6--;
																					goto IL_0d72;
																					IL_0433:
																					if (2 > b)
																					{
																						goto IL_0441;
																					}
																					goto IL_0b30;
																					IL_0441:
																					if (1 >= b)
																					{
																						goto IL_044f;
																					}
																					goto IL_0628;
																					IL_044f:
																					if (1 > b)
																					{
																					}
																					goto IL_0628;
																					IL_0b30:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0b70;
																					IL_0b70:
																					array2[num6 - 2] = 0;
																					goto IL_0b84;
																					IL_0b84:
																					num6--;
																					goto IL_0d72;
																					IL_0671:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_06b1;
																					IL_06b1:
																					array2[num6 - 2] = 0;
																					goto IL_06c5;
																					IL_06c5:
																					num6--;
																					goto IL_0d72;
																					IL_0936:
																					array2[num6] = 1;
																					goto IL_0944;
																					IL_046b:
																					if (8 < b)
																					{
																						goto IL_0476;
																					}
																					goto IL_04a5;
																					IL_0476:
																					if (9 < b)
																					{
																						goto IL_0484;
																					}
																					goto IL_05f6;
																					IL_0484:
																					if (10 >= b)
																					{
																						goto IL_0492;
																					}
																					goto IL_0628;
																					IL_0492:
																					if (10 > b)
																					{
																						goto IL_0628;
																					}
																					num = 85;
																					goto IL_06ef;
																					IL_0952:
																					ptr2 += 16;
																					goto IL_0d72;
																					IL_06ef:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 49;
																					goto IL_075a;
																					IL_075a:
																					num6 -= 2;
																					goto IL_0d72;
																					IL_05f6:
																					if (9 > b)
																					{
																						goto IL_0628;
																					}
																					num = 65;
																					goto IL_0a67;
																					IL_05cb:
																					if (20 >= b)
																					{
																						goto IL_05d6;
																					}
																					goto IL_0606;
																					IL_0a67:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0aa7;
																					IL_0aa7:
																					array2[num6 - 2] = 0;
																					goto IL_0abb;
																					IL_0abb:
																					num6--;
																					goto IL_0d72;
																					IL_04a5:
																					if (8 > b)
																					{
																						goto IL_04b3;
																					}
																					goto IL_07dd;
																					IL_04b3:
																					if (6 < b)
																					{
																						goto IL_04be;
																					}
																					goto IL_04df;
																					IL_04be:
																					if (7 >= b)
																					{
																						goto IL_04cc;
																					}
																					goto IL_0628;
																					IL_04cc:
																					if (7 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_076d;
																					IL_076d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_07ad;
																					IL_07ad:
																					array2[num6 - 2] = 0;
																					num = 164;
																					goto IL_07ca;
																					IL_07ca:
																					num6--;
																					goto IL_0d72;
																					IL_04df:
																					if (6 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_0cde;
																					IL_0cde:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0d1e;
																					IL_0d1e:
																					array2[num6 - 2] = 0;
																					goto IL_0d32;
																					IL_0d32:
																					num6--;
																					goto IL_0d72;
																					IL_07dd:
																					num6--;
																					goto IL_0d72;
																					IL_04f2:
																					if (16 >= b)
																					{
																						goto IL_04fd;
																					}
																					goto IL_057c;
																					IL_04fd:
																					if (16 > b)
																					{
																						goto IL_050b;
																					}
																					goto IL_0bff;
																					IL_050b:
																					if (13 < b)
																					{
																						num = 102;
																						goto IL_051f;
																					}
																					goto IL_055e;
																					IL_05d6:
																					if (20 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_0965;
																					IL_051f:
																					if (14 < b)
																					{
																						goto IL_052a;
																					}
																					goto IL_054b;
																					IL_052a:
																					if (15 >= b)
																					{
																						goto IL_0538;
																					}
																					goto IL_0628;
																					IL_0538:
																					if (15 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_07f0;
																					IL_07f0:
																					array2[num6] = array2[num6 - 1];
																					goto IL_0808;
																					IL_0808:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_0ae1;
																					IL_0ae1:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0b05;
																					IL_0b05:
																					array3[num6] = array3[num6 - 1];
																					goto IL_0b1d;
																					IL_0b1d:
																					num6++;
																					goto IL_0d72;
																					IL_054b:
																					if (14 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_082b;
																					IL_082b:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_0854;
																					IL_0854:
																					array2[num6 - 1] = 5;
																					goto IL_0d72;
																					IL_055e:
																					if (13 > b)
																					{
																						goto IL_056c;
																					}
																					goto IL_086d;
																					IL_056c:
																					if (12 >= b)
																					{
																						goto IL_05e6;
																					}
																					goto IL_0628;
																					IL_05e6:
																					if (12 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_097d;
																					IL_097d:
																					array8 = array3;
																					num7 = num6;
																					if (array == null)
																					{
																						goto IL_098c;
																					}
																					num8 = ptr2;
																					byte b2 = *num8;
																					ptr2 = num8 + 4;
																					int num9 = *(int*)(ptr2 + num3);
																					ptr2 += 8;
																					byte* ptr3 = ptr2 + num9;
																					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																					while (ptr2 != ptr3)
																					{
																						*ptr4 = (byte)(*ptr2 ^ b2);
																						ptr2++;
																						ptr4++;
																					}
																					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																					num = 80;
																					goto IL_0a3d;
																					IL_0965:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_0d72;
																					IL_0606:
																					if (21 >= b)
																					{
																						num = 206;
																						goto IL_061a;
																					}
																					goto IL_0628;
																					IL_0d42:
																					num10 = ptr2;
																					num11 = -200;
																					num5 = 1;
																					ptr2 = num10 + num11;
																					goto IL_0d72;
																					IL_0a3d:
																					array2[num6] = 5;
																					goto IL_0a4b;
																					IL_0a4b:
																					num6++;
																					goto IL_0d72;
																					IL_086d:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					num = 108;
																					goto IL_0894;
																					IL_0894:
																					ptr2 += 8;
																					num = 113;
																					goto IL_08ab;
																					IL_08ab:
																					num6--;
																					goto IL_0d72;
																					IL_0bff:
																					array2[num6] = 5;
																					goto IL_0c0d;
																					IL_0c0d:
																					array3[num6] = array7[*(int*)(ptr2 + num3)];
																					goto IL_0c25;
																					IL_0c25:
																					num6++;
																					goto IL_0c33;
																					IL_0c33:
																					ptr2 += 8;
																					goto IL_0d72;
																					IL_057c:
																					if (19 >= b)
																					{
																						goto IL_0587;
																					}
																					goto IL_05cb;
																					IL_0587:
																					if (19 > b)
																					{
																						goto IL_0595;
																					}
																					goto IL_091d;
																					IL_0595:
																					if (17 < b)
																					{
																						goto IL_05a0;
																					}
																					goto IL_05bb;
																					IL_05a0:
																					if (18 >= b)
																					{
																						goto IL_05ab;
																					}
																					goto IL_0628;
																					IL_05ab:
																					if (18 > b)
																					{
																						goto IL_0628;
																					}
																					num = 15;
																					goto IL_0b97;
																					IL_061a:
																					if (21 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_0d42;
																					IL_0b97:
																					array2[num6 - 1] = 5;
																					num = 194;
																					goto IL_0bb4;
																					IL_0bb4:
																					array3[num6 - 1] = ((delegate*<string[], string>)ErrorWrapperThaiBuddhistCalendar[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																					goto IL_0bec;
																					IL_0bec:
																					ptr2 += 8;
																					goto IL_0d72;
																					IL_05bb:
																					if (17 > b)
																					{
																						goto IL_0628;
																					}
																					goto IL_08cc;
																					IL_08cc:
																					((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																					goto IL_090a;
																					IL_090a:
																					num6 -= 3;
																					goto IL_0d72;
																					IL_091d:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																					goto IL_0936;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0e3e;
																	IL_0e3e:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_098c:
				while (true)
				{
					IL_098c_2:
					array = new byte[4];
					while (true)
					{
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						num = 80;
						while (true)
						{
							IL_0a3d_2:
							array2[num6] = 5;
							while (true)
							{
								IL_0a4b_2:
								num6++;
								while (true)
								{
									IL_0d72_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0646_2:
													if (b >= 1)
													{
														goto IL_03a3_2;
													}
													goto IL_0628_3;
													IL_0628_3:
													while (true)
													{
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														while (true)
														{
															IL_0393_2:
															array2[num6] = 0;
															while (true)
															{
																IL_037a_2:
																num6++;
																num = 214;
																while (true)
																{
																	if (num != 214)
																	{
																		if (num != 1195)
																		{
																			break;
																		}
																		switch (num)
																		{
																		case 24:
																			goto IL_037a_2;
																		case 23:
																			goto IL_0393_2;
																		case 27:
																			goto end_IL_0628_2;
																		case 186:
																			goto IL_03b1_2;
																		case 11:
																			goto IL_03bf_2;
																		case 44:
																		case 175:
																			goto IL_03cd_2;
																		case 157:
																			goto IL_03db_2;
																		case 71:
																			goto IL_03e9_2;
																		case 154:
																		case 160:
																			goto IL_03f4_2;
																		case 54:
																		case 118:
																			goto IL_03ff_2;
																		case 149:
																			goto IL_040d_2;
																		case 1:
																			goto IL_0420_2;
																		case 95:
																			goto IL_0433_2;
																		case 163:
																			goto IL_0441_2;
																		case 134:
																			goto IL_044f_2;
																		case 114:
																		case 165:
																			goto IL_046b_2;
																		case 84:
																		case 146:
																			goto IL_0476_2;
																		case 20:
																		case 22:
																			goto IL_0484_2;
																		case 41:
																			goto IL_0492_2;
																		case 158:
																			goto IL_04a5_2;
																		case 45:
																		case 119:
																			goto IL_04b3_2;
																		case 0:
																		case 132:
																			goto IL_04be_2;
																		case 145:
																			goto IL_04cc_2;
																		case 81:
																			goto IL_04df_2;
																		case 86:
																			goto IL_04f2_2;
																		case 152:
																			goto IL_04fd_2;
																		case 18:
																		case 77:
																			goto IL_050b_2;
																		case 102:
																		case 129:
																			goto IL_051f_2;
																		case 42:
																		case 171:
																			goto IL_052a_2;
																		case 137:
																			goto IL_0538_2;
																		case 57:
																			goto IL_054b_2;
																		case 139:
																			goto IL_055e_2;
																		case 17:
																		case 151:
																			goto IL_056c_2;
																		case 10:
																			goto IL_057c_2;
																		case 172:
																			goto IL_0587_2;
																		case 179:
																			goto IL_0595_2;
																		case 116:
																			goto IL_05a0_2;
																		case 135:
																			goto IL_05ab_2;
																		case 5:
																			goto IL_05bb_2;
																		case 170:
																			goto IL_05cb_2;
																		case 162:
																			goto IL_05d6_2;
																		case 187:
																			goto IL_05e6_2;
																		case 189:
																			goto IL_05f6_2;
																		case 7:
																		case 193:
																			goto IL_0606_2;
																		case 206:
																			goto IL_061a_2;
																		case 2:
																		case 3:
																		case 4:
																		case 25:
																		case 28:
																		case 29:
																		case 39:
																		case 43:
																		case 51:
																		case 53:
																		case 68:
																		case 78:
																		case 82:
																		case 87:
																		case 89:
																		case 106:
																		case 109:
																		case 110:
																		case 111:
																		case 122:
																		case 130:
																		case 142:
																		case 144:
																		case 148:
																		case 155:
																		case 156:
																		case 161:
																		case 166:
																		case 168:
																		case 169:
																		case 174:
																		case 180:
																		case 183:
																		case 185:
																		case 200:
																			goto end_IL_0367_2;
																		case 136:
																			goto IL_0646_2;
																		case 9:
																			goto end_IL_0646;
																		case 19:
																		case 131:
																			goto end_IL_0656;
																		case 26:
																		case 48:
																			goto IL_0671_2;
																		case 34:
																			goto IL_06b1_2;
																		case 40:
																			goto IL_06c5_2;
																		case 37:
																		case 85:
																			goto IL_06ef_2;
																		case 49:
																			goto IL_075a_2;
																		case 60:
																		case 98:
																			goto IL_076d_2;
																		case 32:
																			goto IL_07ad_2;
																		case 164:
																			goto IL_07ca_2;
																		case 153:
																		case 181:
																			goto IL_07dd_2;
																		case 33:
																		case 47:
																			goto IL_07f0_2;
																		case 124:
																			goto IL_0808_2;
																		case 61:
																		case 128:
																			goto IL_082b_2;
																		case 46:
																			goto IL_0854_2;
																		case 52:
																		case 99:
																			goto IL_086d_2;
																		case 108:
																			goto IL_0894_2;
																		case 113:
																			goto IL_08ab_2;
																		case 50:
																		case 182:
																			goto IL_08cc_2;
																		case 64:
																			goto IL_090a_2;
																		case 6:
																		case 14:
																			goto IL_091d_2;
																		case 107:
																			goto IL_0936_2;
																		case 79:
																			goto IL_0944_2;
																		case 70:
																			goto IL_0952_2;
																		case 83:
																		case 127:
																			goto IL_0965_2;
																		case 36:
																		case 75:
																			goto end_IL_0666;
																		case 80:
																			goto IL_0a3d_2;
																		case 94:
																			goto IL_0a4b_2;
																		case 65:
																		case 73:
																			goto IL_0a67_2;
																		case 74:
																			goto IL_0aa7_2;
																		case 12:
																			goto IL_0abb_2;
																		case 8:
																		case 190:
																			goto IL_0ace_2;
																		case 191:
																			goto IL_0ae1_2;
																		case 103:
																			goto IL_0b05_2;
																		case 69:
																			goto IL_0b1d_2;
																		case 55:
																		case 192:
																			goto IL_0b30_2;
																		case 125:
																			goto IL_0b70_2;
																		case 123:
																			goto IL_0b84_2;
																		case 15:
																		case 197:
																			goto IL_0b97_2;
																		case 194:
																			goto IL_0bb4_2;
																		case 76:
																			goto IL_0bec_2;
																		case 101:
																		case 199:
																			goto IL_0bff_2;
																		case 88:
																			goto IL_0c0d_2;
																		case 59:
																			goto IL_0c25_2;
																		case 150:
																			goto IL_0c33_2;
																		case 13:
																		case 201:
																			goto IL_0c46_2;
																		case 90:
																			goto IL_0c6f_2;
																		case 62:
																			goto IL_0c7d_2;
																		case 202:
																			goto IL_0c90_2;
																		case 138:
																			goto IL_0cb3_2;
																		case 105:
																			goto IL_0cbd_2;
																		case 30:
																			goto IL_0ccb_2;
																		case 143:
																		case 204:
																			goto IL_0cde_2;
																		case 72:
																			goto IL_0d1e_2;
																		case 120:
																			goto IL_0d32_2;
																		case 16:
																		case 159:
																			goto IL_0d42_2;
																		case 21:
																		case 31:
																		case 35:
																		case 38:
																		case 56:
																		case 58:
																		case 63:
																		case 66:
																		case 93:
																		case 96:
																		case 97:
																		case 100:
																		case 112:
																		case 117:
																		case 126:
																		case 133:
																		case 140:
																		case 167:
																		case 173:
																		case 178:
																		case 184:
																		case 195:
																		case 198:
																		case 203:
																			goto IL_0d72_2;
																		case 141:
																			ptr2 = ptr;
																			goto IL_0d72_2;
																		case 176:
																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BuildGregorianCalendarTypes.setSecurityEnabledsetKeyStore);
																			goto case 141;
																		case 205:
																			array7 = new object[17];
																			goto case 176;
																		case 196:
																			array6 = new long[4];
																			goto case 205;
																		case 147:
																			array5 = new int[6];
																			goto case 196;
																		case 177:
																			array4 = new int[4];
																			goto case 147;
																		case 188:
																			array3 = new object[4];
																			goto case 177;
																		case 67:
																			array2 = new byte[4];
																			goto case 188;
																		case 104:
																			num4 = num2 * 8;
																			num = 67;
																			goto case 67;
																		case 207:
																			num3 = num2 * 4;
																			goto case 104;
																		case 91:
																			num2 = 1;
																			goto case 207;
																		case 92:
																			goto end_IL_099a;
																		case 115:
																		case 121:
																			goto IL_0e3e_2;
																		}
																		continue;
																	}
																	ptr2 += 8;
																	num = 66;
																	goto IL_0d72_2;
																	continue;
																	end_IL_0367_2:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0628_2:
														break;
													}
													goto IL_03a3_2;
													IL_03a3_2:
													if (b <= 21)
													{
														goto IL_03b1_2;
													}
													goto IL_0628_3;
													IL_03b1_2:
													if (11 >= b)
													{
														goto IL_03bf_2;
													}
													goto IL_04f2_2;
													IL_03bf_2:
													if (11 <= b)
													{
														goto IL_0d72_2;
													}
													goto IL_03cd_2;
													IL_03cd_2:
													if (5 >= b)
													{
														goto IL_03db_2;
													}
													num = 114;
													goto IL_046b_2;
													IL_03db_2:
													if (5 > b)
													{
														goto IL_03e9_2;
													}
													goto IL_0671_2;
													IL_03e9_2:
													if (2 < b)
													{
														goto IL_03f4_2;
													}
													goto IL_0433_2;
													IL_03f4_2:
													if (3 < b)
													{
														goto IL_03ff_2;
													}
													goto IL_0420_2;
													IL_03ff_2:
													if (4 >= b)
													{
														goto IL_040d_2;
													}
													goto IL_0628_3;
													IL_040d_2:
													if (4 > b)
													{
														goto IL_0628_3;
													}
													goto IL_0ace_2;
													IL_0ace_2:
													array2[num6] = 0;
													goto IL_0c90_2;
													IL_0c90_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
													goto IL_0cb3_2;
													IL_0cb3_2:
													array3[num6] = null;
													goto IL_0cbd_2;
													IL_0cbd_2:
													num6++;
													goto IL_0ccb_2;
													IL_0ccb_2:
													ptr2 += 8;
													goto IL_0d72_2;
													IL_0420_2:
													if (3 > b)
													{
														goto IL_0628_3;
													}
													num = 13;
													goto IL_0c46_2;
													IL_05d6_2:
													if (20 > b)
													{
														goto IL_0628_3;
													}
													goto IL_0965_2;
													IL_0c46_2:
													reference = ref array5[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_0c6f_2;
													IL_0c6f_2:
													ptr2 += 8;
													goto IL_0c7d_2;
													IL_0c7d_2:
													num6--;
													goto IL_0d72_2;
													IL_0433_2:
													if (2 > b)
													{
														goto IL_0441_2;
													}
													goto IL_0b30_2;
													IL_0441_2:
													if (1 >= b)
													{
														goto IL_044f_2;
													}
													goto IL_0628_3;
													IL_044f_2:
													if (1 > b)
													{
													}
													goto IL_0628_3;
													IL_0b30_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_0b70_2;
													IL_0b70_2:
													array2[num6 - 2] = 0;
													goto IL_0b84_2;
													IL_0b84_2:
													num6--;
													goto IL_0d72_2;
													IL_0671_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_06b1_2;
													IL_06b1_2:
													array2[num6 - 2] = 0;
													goto IL_06c5_2;
													IL_06c5_2:
													num6--;
													goto IL_0d72_2;
													IL_05cb_2:
													if (20 >= b)
													{
														goto IL_05d6_2;
													}
													goto IL_0606_2;
													IL_046b_2:
													if (8 < b)
													{
														goto IL_0476_2;
													}
													goto IL_04a5_2;
													IL_0476_2:
													if (9 < b)
													{
														goto IL_0484_2;
													}
													goto IL_05f6_2;
													IL_0484_2:
													if (10 >= b)
													{
														goto IL_0492_2;
													}
													goto IL_0628_3;
													IL_0492_2:
													if (10 > b)
													{
														goto IL_0628_3;
													}
													num = 85;
													goto IL_06ef_2;
													IL_0965_2:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0d72_2;
													IL_06ef_2:
													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													num = 49;
													goto IL_075a_2;
													IL_075a_2:
													num6 -= 2;
													goto IL_0d72_2;
													IL_05f6_2:
													if (9 > b)
													{
														goto IL_0628_3;
													}
													num = 65;
													goto IL_0a67_2;
													IL_0606_2:
													if (21 >= b)
													{
														num = 206;
														goto IL_061a_2;
													}
													goto IL_0628_3;
													IL_0a67_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_0aa7_2;
													IL_0aa7_2:
													array2[num6 - 2] = 0;
													goto IL_0abb_2;
													IL_0abb_2:
													num6--;
													goto IL_0d72_2;
													IL_04a5_2:
													if (8 > b)
													{
														goto IL_04b3_2;
													}
													goto IL_07dd_2;
													IL_04b3_2:
													if (6 < b)
													{
														goto IL_04be_2;
													}
													goto IL_04df_2;
													IL_04be_2:
													if (7 >= b)
													{
														goto IL_04cc_2;
													}
													goto IL_0628_3;
													IL_04cc_2:
													if (7 > b)
													{
														goto IL_0628_3;
													}
													goto IL_076d_2;
													IL_076d_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_07ad_2;
													IL_07ad_2:
													array2[num6 - 2] = 0;
													num = 164;
													goto IL_07ca_2;
													IL_07ca_2:
													num6--;
													goto IL_0d72_2;
													IL_04df_2:
													if (6 > b)
													{
														goto IL_0628_3;
													}
													goto IL_0cde_2;
													IL_0cde_2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_0d1e_2;
													IL_0d1e_2:
													array2[num6 - 2] = 0;
													goto IL_0d32_2;
													IL_0d32_2:
													num6--;
													goto IL_0d72_2;
													IL_07dd_2:
													num6--;
													goto IL_0d72_2;
													IL_04f2_2:
													if (16 >= b)
													{
														goto IL_04fd_2;
													}
													goto IL_057c_2;
													IL_04fd_2:
													if (16 > b)
													{
														goto IL_050b_2;
													}
													goto IL_0bff_2;
													IL_050b_2:
													if (13 < b)
													{
														num = 102;
														goto IL_051f_2;
													}
													goto IL_055e_2;
													IL_0d42_2:
													num10 = ptr2;
													num11 = -200;
													num5 = 1;
													ptr2 = num10 + num11;
													goto IL_0d72_2;
													IL_051f_2:
													if (14 < b)
													{
														goto IL_052a_2;
													}
													goto IL_054b_2;
													IL_052a_2:
													if (15 >= b)
													{
														goto IL_0538_2;
													}
													goto IL_0628_3;
													IL_0538_2:
													if (15 > b)
													{
														goto IL_0628_3;
													}
													goto IL_07f0_2;
													IL_07f0_2:
													array2[num6] = array2[num6 - 1];
													goto IL_0808_2;
													IL_0808_2:
													array4[num6 - 0] = array4[num6 - 1];
													goto IL_0ae1_2;
													IL_0ae1_2:
													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
													goto IL_0b05_2;
													IL_0b05_2:
													array3[num6] = array3[num6 - 1];
													goto IL_0b1d_2;
													IL_0b1d_2:
													num6++;
													goto IL_0d72_2;
													IL_054b_2:
													if (14 > b)
													{
														goto IL_0628_3;
													}
													goto IL_082b_2;
													IL_082b_2:
													array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
													goto IL_0854_2;
													IL_0854_2:
													array2[num6 - 1] = 5;
													goto IL_0d72_2;
													IL_055e_2:
													if (13 > b)
													{
														goto IL_056c_2;
													}
													goto IL_086d_2;
													IL_056c_2:
													if (12 >= b)
													{
														goto IL_05e6_2;
													}
													goto IL_0628_3;
													IL_05e6_2:
													if (12 <= b)
													{
														goto end_IL_0666;
													}
													goto IL_0628_3;
													IL_086d_2:
													array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
													num = 108;
													goto IL_0894_2;
													IL_0894_2:
													ptr2 += 8;
													num = 113;
													goto IL_08ab_2;
													IL_08ab_2:
													num6--;
													goto IL_0d72_2;
													IL_0bff_2:
													array2[num6] = 5;
													goto IL_0c0d_2;
													IL_0c0d_2:
													array3[num6] = array7[*(int*)(ptr2 + num3)];
													goto IL_0c25_2;
													IL_0c25_2:
													num6++;
													goto IL_0c33_2;
													IL_0c33_2:
													ptr2 += 8;
													goto IL_0d72_2;
													IL_057c_2:
													if (19 >= b)
													{
														goto IL_0587_2;
													}
													goto IL_05cb_2;
													IL_0587_2:
													if (19 > b)
													{
														goto IL_0595_2;
													}
													goto IL_091d_2;
													IL_0595_2:
													if (17 < b)
													{
														goto IL_05a0_2;
													}
													goto IL_05bb_2;
													IL_05a0_2:
													if (18 >= b)
													{
														goto IL_05ab_2;
													}
													goto IL_0628_3;
													IL_05ab_2:
													if (18 > b)
													{
														goto IL_0628_3;
													}
													num = 15;
													goto IL_0b97_2;
													IL_061a_2:
													if (21 > b)
													{
														goto IL_0628_3;
													}
													goto IL_0d42_2;
													IL_0b97_2:
													array2[num6 - 1] = 5;
													num = 194;
													goto IL_0bb4_2;
													IL_0bb4_2:
													array3[num6 - 1] = ((delegate*<string[], string>)ErrorWrapperThaiBuddhistCalendar[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
													goto IL_0bec_2;
													IL_0bec_2:
													ptr2 += 8;
													goto IL_0d72_2;
													IL_05bb_2:
													if (17 > b)
													{
														goto IL_0628_3;
													}
													goto IL_08cc_2;
													IL_08cc_2:
													((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
													goto IL_090a_2;
													IL_090a_2:
													num6 -= 3;
													goto IL_0d72_2;
													IL_091d_2:
													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
													goto IL_0936_2;
													IL_0936_2:
													array2[num6] = 1;
													goto IL_0944_2;
													IL_0944_2:
													num6++;
													goto IL_0952_2;
													IL_0952_2:
													ptr2 += 16;
													goto IL_0d72_2;
													continue;
													end_IL_0646:
													break;
												}
												continue;
												end_IL_0656:
												break;
											}
											continue;
											end_IL_0666:
											break;
										}
										break;
									}
									goto IL_0e3e_2;
									IL_0e3e_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							break;
						}
						array8 = array3;
						num7 = num6;
						if (array == null)
						{
							goto IL_098c_2;
						}
						continue;
						end_IL_099a:
						break;
					}
					break;
				}
			}
		}
	}

	public Class108()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_5, int int_6)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 41;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MacrofromInclusive.getCategoryImportant);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0212:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01f2:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01df:
																						if (4 > b)
																						{
																							num = 86;
																							while (true)
																							{
																								IL_01d2:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01c2:
																										if (3 < b)
																										{
																											num = 97;
																											while (num != 97 && num == 1078)
																											{
																												switch (num)
																												{
																												case 5:
																													goto IL_01c2;
																												case 86:
																												case 90:
																													goto IL_01d2;
																												case 60:
																													goto IL_01df;
																												case 40:
																													goto IL_01f2;
																												case 63:
																													goto IL_0202;
																												case 59:
																													goto IL_0212;
																												case 42:
																													goto end_IL_0212;
																												case 35:
																												case 53:
																													goto end_IL_0222;
																												case 2:
																													goto IL_023d;
																												case 54:
																													goto IL_0250;
																												case 13:
																												case 50:
																													goto IL_025b;
																												case 18:
																													goto IL_02ce;
																												case 65:
																													goto IL_02dc;
																												case 46:
																												case 67:
																													goto IL_02ef;
																												case 37:
																													goto IL_032f;
																												case 71:
																													goto IL_0343;
																												case 14:
																												case 78:
																													goto IL_0356;
																												case 6:
																												case 57:
																													goto IL_0361;
																												case 15:
																													goto IL_036c;
																												case 7:
																													goto IL_037f;
																												case 8:
																													goto IL_038d;
																												case 27:
																													goto IL_039b;
																												case 26:
																												case 34:
																													goto IL_03a9;
																												case 74:
																												case 81:
																													goto IL_03c1;
																												case 38:
																													goto IL_03cf;
																												case 52:
																												case 79:
																													goto IL_03dd;
																												case 85:
																													goto IL_03f9;
																												case 83:
																												case 89:
																													goto IL_040c;
																												case 20:
																													goto IL_041a;
																												case 70:
																													goto IL_043d;
																												case 43:
																													goto IL_0447;
																												case 30:
																													goto IL_0455;
																												case 39:
																												case 48:
																													goto IL_0468;
																												case 3:
																													goto IL_0491;
																												case 51:
																													goto IL_049f;
																												case 0:
																												case 4:
																												case 10:
																												case 11:
																												case 22:
																												case 23:
																												case 24:
																												case 28:
																												case 29:
																												case 31:
																												case 49:
																												case 55:
																												case 58:
																												case 68:
																												case 72:
																												case 73:
																												case 80:
																													goto end_IL_01af;
																												case 25:
																													goto IL_04d2;
																												case 19:
																													goto IL_04e0;
																												case 44:
																													goto IL_04ee;
																												case 9:
																												case 12:
																												case 17:
																												case 33:
																												case 45:
																												case 47:
																												case 56:
																												case 62:
																												case 69:
																												case 82:
																												case 88:
																													goto end_IL_0232;
																												case 87:
																													goto end_IL_04fc;
																												case 36:
																													goto end_IL_050f;
																												case 1:
																													goto end_IL_0519;
																												case 77:
																													goto end_IL_0524;
																												case 16:
																													goto end_IL_0539;
																												case 21:
																												case 64:
																													goto end_IL_054e;
																												case 41:
																													goto end_IL_055e;
																												case 61:
																												case 66:
																													goto end_IL_056e;
																												case 75:
																													goto end_IL_057e;
																												case 76:
																													goto end_IL_0597;
																												case 32:
																												case 84:
																													goto IL_05b2;
																												}
																												continue;
																												end_IL_01af:
																												break;
																											}
																											break;
																										}
																										goto IL_023d;
																										IL_032f:
																										array[num5 - 2] = 0;
																										goto IL_0343;
																										IL_0343:
																										num5--;
																										goto end_IL_0232;
																										IL_023d:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_02ef;
																										IL_02ef:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_032f;
																									}
																									break;
																								}
																								goto IL_0250;
																								IL_02dc:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0250:
																								if (2 <= b)
																								{
																									goto IL_025b;
																								}
																								goto IL_02ce;
																								IL_025b:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_03f9;
																								IL_03f9:
																								num5 -= 2;
																								goto end_IL_0232;
																								IL_02ce:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_02dc;
																							}
																							break;
																						}
																						goto IL_0468;
																						IL_0491:
																						ptr2 += 8;
																						goto IL_049f;
																						IL_049f:
																						num5--;
																						goto end_IL_0232;
																						IL_0468:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0491;
																					}
																					break;
																				}
																				goto IL_0356;
																				IL_03a9:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0232;
																				IL_0356:
																				if (6 < b)
																				{
																					goto IL_0361;
																				}
																				goto IL_037f;
																				IL_0361:
																				if (7 >= b)
																				{
																					goto IL_036c;
																				}
																				goto IL_03c1;
																				IL_036c:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_040c;
																				IL_040c:
																				array[num5] = 0;
																				goto IL_041a;
																				IL_041a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_043d;
																				IL_043d:
																				array2[num5] = null;
																				goto IL_0447;
																				IL_0447:
																				num5++;
																				goto IL_0455;
																				IL_0455:
																				ptr2 += 8;
																				goto end_IL_0232;
																				IL_03c1:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03dd;
																				IL_03dd:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0232;
																				IL_037f:
																				if (6 <= b)
																				{
																					goto end_IL_0232;
																				}
																				goto IL_038d;
																				IL_038d:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_039b;
																				IL_039b:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03a9;
																			}
																			break;
																			IL_0202:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d2;
																	IL_04ee:
																	ptr2 += 8;
																	goto end_IL_0232;
																	IL_04e0:
																	num5++;
																	goto IL_04ee;
																	IL_04d2:
																	array[num5] = 0;
																	goto IL_04e0;
																	continue;
																	end_IL_0212:
																	break;
																}
																continue;
																end_IL_0222:
																break;
															}
															continue;
															end_IL_0232:
															break;
														}
														continue;
													}
													goto IL_05b2;
													IL_05b2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04fc:
													break;
												}
												continue;
												end_IL_050f:
												break;
											}
											continue;
											end_IL_0519:
											break;
										}
										continue;
										end_IL_0524:
										break;
									}
									continue;
									end_IL_0539:
									break;
								}
								continue;
								end_IL_054e:
								break;
							}
							continue;
							end_IL_055e:
							break;
						}
						continue;
						end_IL_056e:
						break;
					}
					continue;
					end_IL_057e:
					break;
				}
				continue;
				end_IL_0597:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_5, int int_6)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 71;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							IL_0570:
							int[] array3 = new int[3];
							while (true)
							{
								IL_0560:
								long[] array4 = new long[2];
								while (true)
								{
									IL_054b:
									array3[0] = int_5;
									while (true)
									{
										IL_0536:
										array3[1] = int_6;
										while (true)
										{
											IL_052b:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AttentionContextLevelActivator.SecurityBindingRedirectsDefineEvent);
											while (true)
											{
												IL_0521:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_050e:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0218:
															num = 64;
															while (true)
															{
																IL_020d:
																byte b = *ptr2;
																while (true)
																{
																	IL_01fd:
																	ptr2++;
																	while (true)
																	{
																		IL_01ed:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01cd:
																					if (4 < b)
																					{
																						while (true)
																						{
																							IL_01c0:
																							if (6 < b)
																							{
																								while (true)
																								{
																									IL_01b0:
																									if (7 >= b)
																									{
																										num = 96;
																										while (true)
																										{
																											if (num != 96)
																											{
																												if (num != 1077)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 85:
																													goto IL_01b0;
																												case 9:
																												case 87:
																													goto IL_01c0;
																												case 38:
																													goto IL_01cd;
																												case 70:
																													goto IL_01dd;
																												case 0:
																													goto IL_01ed;
																												case 50:
																													goto IL_01fd;
																												case 64:
																													goto IL_020d;
																												case 3:
																													goto IL_0218;
																												case 29:
																													goto IL_0223;
																												case 33:
																													goto IL_023c;
																												case 6:
																												case 7:
																													goto IL_024a;
																												case 41:
																													goto IL_025d;
																												case 42:
																													goto IL_0270;
																												case 35:
																												case 40:
																													goto IL_027b;
																												case 26:
																													goto IL_02a4;
																												case 15:
																													goto IL_02b4;
																												case 10:
																												case 34:
																													goto IL_02bf;
																												case 20:
																													goto IL_02cd;
																												case 2:
																													goto IL_02e0;
																												case 24:
																												case 54:
																													goto IL_02f9;
																												case 76:
																													goto IL_0315;
																												case 5:
																												case 77:
																													goto IL_0328;
																												case 18:
																													goto IL_0396;
																												case 63:
																												case 78:
																													goto IL_03a9;
																												case 21:
																													goto IL_03e9;
																												case 16:
																													goto IL_03fd;
																												case 83:
																													goto IL_0410;
																												case 28:
																													goto IL_041e;
																												case 88:
																													goto IL_0431;
																												case 8:
																												case 52:
																													goto IL_043c;
																												case 66:
																												case 67:
																													goto IL_045f;
																												case 4:
																													goto IL_046d;
																												case 22:
																													goto IL_0490;
																												case 55:
																													goto IL_049a;
																												case 27:
																													goto IL_04a8;
																												case 12:
																												case 14:
																												case 25:
																												case 32:
																												case 48:
																												case 51:
																												case 53:
																												case 56:
																												case 57:
																												case 59:
																												case 60:
																												case 61:
																												case 65:
																												case 68:
																												case 73:
																												case 79:
																												case 82:
																												case 89:
																													goto end_IL_01dd;
																												case 17:
																													goto IL_04db;
																												case 86:
																													goto IL_04e9;
																												case 36:
																													goto IL_04f7;
																												case 19:
																												case 30:
																												case 31:
																												case 44:
																												case 45:
																												case 47:
																												case 49:
																												case 58:
																												case 69:
																												case 80:
																												case 81:
																													goto IL_050e;
																												case 84:
																													goto IL_0521;
																												case 11:
																													goto IL_052b;
																												case 37:
																													goto IL_0536;
																												case 1:
																													goto IL_054b;
																												case 75:
																													goto IL_0560;
																												case 43:
																												case 46:
																													goto IL_0570;
																												case 74:
																													goto end_IL_019d;
																												case 39:
																												case 62:
																													goto end_IL_0580;
																												case 71:
																													goto end_IL_0590;
																												case 72:
																													goto end_IL_05a0;
																												case 13:
																												case 23:
																													goto IL_05c4;
																												}
																												continue;
																											}
																											if (7 > b)
																											{
																												goto end_IL_01dd;
																											}
																											goto IL_045f;
																											IL_0490:
																											array2[num5] = null;
																											goto IL_049a;
																											IL_04a8:
																											ptr2 += 8;
																											goto IL_050e;
																											IL_049a:
																											num5++;
																											goto IL_04a8;
																											IL_045f:
																											array[num5] = 0;
																											goto IL_046d;
																											IL_046d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0490;
																											continue;
																											end_IL_019d:
																											break;
																										}
																										break;
																									}
																									goto IL_0223;
																									IL_02f9:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto IL_050e;
																									IL_025d:
																									if (8 > b)
																									{
																										goto end_IL_01dd;
																									}
																									goto IL_02f9;
																									IL_0223:
																									if (8 < b)
																									{
																										num = 14;
																										goto end_IL_01dd;
																									}
																									goto IL_025d;
																								}
																								break;
																							}
																							goto IL_023c;
																							IL_043c:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_050e;
																							IL_023c:
																							if (6 <= b)
																							{
																								goto IL_050e;
																							}
																							goto IL_024a;
																							IL_024a:
																							if (5 < b)
																							{
																								goto end_IL_01dd;
																							}
																							goto IL_0431;
																							IL_0431:
																							if (5 > b)
																							{
																								goto end_IL_01dd;
																							}
																							goto IL_043c;
																						}
																						break;
																					}
																					goto IL_0270;
																					IL_0410:
																					if (1 < b)
																					{
																						goto end_IL_01dd;
																					}
																					goto IL_041e;
																					IL_0270:
																					if (4 <= b)
																					{
																						goto IL_027b;
																					}
																					goto IL_02b4;
																					IL_027b:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02a4;
																					IL_02a4:
																					ptr2 += 8;
																					goto IL_0315;
																					IL_0315:
																					num5--;
																					goto IL_050e;
																					IL_02b4:
																					if (2 < b)
																					{
																						goto IL_02bf;
																					}
																					goto IL_02e0;
																					IL_02bf:
																					if (3 < b)
																					{
																						goto end_IL_01dd;
																					}
																					goto IL_02cd;
																					IL_02cd:
																					if (3 > b)
																					{
																						goto end_IL_01dd;
																					}
																					goto IL_03a9;
																					IL_03a9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03e9;
																					IL_03e9:
																					array[num5 - 2] = 0;
																					goto IL_03fd;
																					IL_03fd:
																					num5--;
																					goto IL_050e;
																					IL_02e0:
																					if (2 <= b)
																					{
																						num = 5;
																						goto IL_0328;
																					}
																					goto IL_0410;
																					IL_041e:
																					if (1 > b)
																					{
																					}
																					goto end_IL_01dd;
																					IL_0328:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0396;
																					IL_0396:
																					num5 -= 2;
																					goto IL_050e;
																				}
																				goto end_IL_01ed;
																				continue;
																				end_IL_01dd:
																				break;
																				IL_01dd:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04db;
																		IL_04f7:
																		ptr2 += 8;
																		num = 44;
																		goto IL_050e;
																		IL_04e9:
																		num5++;
																		goto IL_04f7;
																		IL_04db:
																		array[num5] = 0;
																		goto IL_04e9;
																		continue;
																		end_IL_01ed:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_05c4;
													IL_05c4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0580:
						break;
					}
					continue;
					end_IL_0590:
					break;
				}
				continue;
				end_IL_05a0:
				break;
			}
		}
	}

	private static int smethod_15(int int_5)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num6;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_5;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_5;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 108;
		num6 = 4;
		num4 = 27;
		num6 = 140;
		num6 = 35;
		int num7 = smethod_14(27, 35);
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_16()
	{
		int num = 157;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 156;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								num = 21;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SystemAlarmCallbackmdata.getFilterLevelCMSTIMEUNITTYPEDAYS);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02d0:
														byte b = *ptr2;
														while (true)
														{
															IL_02b7:
															ptr2++;
															num = 166;
															while (true)
															{
																if (num != 166)
																{
																	if (num != 1147)
																	{
																		break;
																	}
																	switch (num)
																	{
																	case 146:
																		goto IL_02b7;
																	case 36:
																	case 73:
																		goto IL_02d0;
																	case 145:
																		goto IL_02e9;
																	case 7:
																		goto IL_02f7;
																	case 96:
																		goto IL_0305;
																	case 106:
																		goto IL_0313;
																	case 18:
																		goto IL_0321;
																	case 134:
																		goto IL_032f;
																	case 26:
																	case 131:
																		goto IL_033d;
																	case 92:
																		goto IL_034b;
																	case 29:
																	case 125:
																		goto IL_0359;
																	case 8:
																		goto IL_0367;
																	case 30:
																		goto IL_038a;
																	case 130:
																		goto IL_0394;
																	case 65:
																		goto IL_03ab;
																	case 77:
																	case 91:
																		goto IL_03be;
																	case 104:
																		goto IL_0402;
																	case 148:
																		goto IL_0416;
																	case 63:
																		goto IL_0429;
																	case 27:
																		goto IL_0437;
																	case 87:
																	case 150:
																		goto IL_0445;
																	case 137:
																		goto IL_0485;
																	case 129:
																		goto IL_0499;
																	case 58:
																	case 151:
																		goto IL_04ac;
																	case 57:
																		goto IL_050e;
																	case 142:
																		goto IL_0521;
																	case 38:
																	case 53:
																		goto IL_052c;
																	case 35:
																	case 120:
																		goto IL_0537;
																	case 47:
																		goto IL_0545;
																	case 112:
																		goto IL_0558;
																	case 132:
																	case 140:
																		goto IL_0566;
																	case 62:
																		goto IL_0582;
																	case 48:
																	case 75:
																		goto IL_0590;
																	case 119:
																		goto IL_059e;
																	case 46:
																	case 79:
																		goto IL_05ac;
																	case 24:
																		goto IL_05c0;
																	case 85:
																		goto IL_05ff;
																	case 76:
																	case 81:
																		goto IL_0612;
																	case 50:
																		goto IL_062e;
																	case 5:
																		goto IL_063c;
																	case 97:
																		goto IL_0653;
																	case 89:
																	case 113:
																		goto IL_065e;
																	case 25:
																		goto IL_067c;
																	case 83:
																		goto IL_0693;
																	case 152:
																		goto IL_06af;
																	case 10:
																	case 37:
																		goto IL_06ba;
																	case 124:
																		goto IL_06c8;
																	case 13:
																	case 128:
																		goto IL_06d6;
																	case 49:
																		goto IL_06ff;
																	case 33:
																		goto IL_0718;
																	case 90:
																	case 144:
																		goto IL_072c;
																	case 107:
																		goto IL_073a;
																	case 71:
																	case 80:
																		goto IL_0748;
																	case 135:
																		goto IL_0761;
																	case 0:
																		goto IL_076f;
																	case 23:
																		goto IL_0786;
																	case 111:
																	case 159:
																		goto IL_0799;
																	case 41:
																		goto IL_07d9;
																	case 123:
																		goto IL_07ed;
																	case 154:
																		goto IL_0800;
																	case 153:
																		goto IL_080e;
																	case 6:
																	case 78:
																		goto IL_0819;
																	case 98:
																		goto IL_0858;
																	case 84:
																		goto IL_086b;
																	case 17:
																		goto IL_0879;
																	case 20:
																	case 155:
																		goto IL_0890;
																	case 3:
																		goto IL_089e;
																	case 69:
																		goto IL_08b6;
																	case 121:
																		goto IL_08c4;
																	case 44:
																		goto IL_08d7;
																	case 28:
																		goto IL_08e2;
																	case 51:
																	case 147:
																		goto IL_08ed;
																	case 95:
																		goto IL_0916;
																	case 67:
																		goto IL_0924;
																	case 55:
																		goto IL_0934;
																	case 42:
																		goto IL_093f;
																	case 39:
																	case 64:
																		goto IL_094a;
																	case 1:
																	case 4:
																	case 9:
																	case 11:
																	case 12:
																	case 14:
																	case 16:
																	case 22:
																	case 32:
																	case 40:
																	case 54:
																	case 61:
																	case 70:
																	case 72:
																	case 74:
																	case 88:
																	case 93:
																	case 99:
																	case 103:
																	case 108:
																	case 114:
																	case 116:
																	case 118:
																	case 122:
																	case 126:
																	case 138:
																	case 139:
																	case 141:
																		goto IL_095f;
																	case 2:
																	case 19:
																	case 31:
																	case 34:
																	case 43:
																	case 52:
																	case 56:
																	case 60:
																	case 68:
																	case 82:
																	case 86:
																	case 94:
																	case 100:
																	case 101:
																	case 105:
																	case 117:
																	case 133:
																	case 136:
																	case 143:
																	case 149:
																		goto end_IL_02a7;
																	case 59:
																		goto end_IL_0972;
																	case 109:
																		goto end_IL_0985;
																	case 21:
																		goto end_IL_098f;
																	case 66:
																		goto end_IL_099a;
																	case 110:
																	case 127:
																		goto end_IL_09aa;
																	case 45:
																		goto end_IL_09c3;
																	case 15:
																	case 115:
																		goto end_IL_09d3;
																	case 156:
																		goto end_IL_09e3;
																	case 157:
																		goto end_IL_09f3;
																	case 102:
																	case 158:
																		goto IL_0a17;
																	}
																	continue;
																}
																if (b >= 1)
																{
																	goto IL_02e9;
																}
																goto IL_095f;
																IL_08ed:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0916;
																IL_0924:
																num5--;
																break;
																IL_0916:
																ptr2 += 8;
																goto IL_0924;
																IL_02e9:
																if (b <= 17)
																{
																	goto IL_02f7;
																}
																goto IL_095f;
																IL_02f7:
																if (9 < b)
																{
																	goto IL_0305;
																}
																num = 50;
																goto IL_062e;
																IL_0305:
																if (13 >= b)
																{
																	goto IL_0313;
																}
																goto IL_0521;
																IL_0313:
																if (13 > b)
																{
																	goto IL_0321;
																}
																goto IL_04ac;
																IL_0321:
																if (11 >= b)
																{
																	goto IL_032f;
																}
																goto IL_0429;
																IL_032f:
																if (11 > b)
																{
																	goto IL_033d;
																}
																goto IL_03be;
																IL_033d:
																if (10 >= b)
																{
																	goto IL_034b;
																}
																goto IL_095f;
																IL_034b:
																if (10 <= b)
																{
																	goto IL_0359;
																}
																goto IL_095f;
																IL_0359:
																array[num5] = 0;
																goto IL_0367;
																IL_0367:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_038a;
																IL_038a:
																array2[num5] = null;
																goto IL_0394;
																IL_0394:
																num5++;
																num = 65;
																goto IL_03ab;
																IL_03ab:
																ptr2 += 8;
																break;
																IL_03be:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_0402;
																IL_0402:
																array[num5 - 2] = 0;
																goto IL_0416;
																IL_0416:
																num5--;
																break;
																IL_0429:
																if (12 >= b)
																{
																	goto IL_0437;
																}
																goto IL_095f;
																IL_0437:
																if (12 <= b)
																{
																	goto IL_0445;
																}
																goto IL_095f;
																IL_0445:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0485;
																IL_0485:
																array[num5 - 2] = 0;
																goto IL_0499;
																IL_0499:
																num5--;
																break;
																IL_04ac:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_050e;
																IL_050e:
																num5 -= 2;
																break;
																IL_0521:
																if (15 < b)
																{
																	goto IL_052c;
																}
																goto IL_0582;
																IL_052c:
																if (16 < b)
																{
																	goto IL_0537;
																}
																goto IL_0558;
																IL_0537:
																if (17 >= b)
																{
																	goto IL_0545;
																}
																goto IL_095f;
																IL_0545:
																if (17 > b)
																{
																}
																goto IL_095f;
																IL_0558:
																if (16 <= b)
																{
																	goto IL_0566;
																}
																goto IL_095f;
																IL_0566:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																break;
																IL_0582:
																if (15 > b)
																{
																	goto IL_0590;
																}
																goto IL_0612;
																IL_0590:
																if (14 >= b)
																{
																	goto IL_059e;
																}
																goto IL_095f;
																IL_059e:
																if (14 <= b)
																{
																	goto IL_05ac;
																}
																goto IL_095f;
																IL_05ac:
																array[num5 - 1] = 0;
																goto IL_05c0;
																IL_05c0:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)processorCountgetEras[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_05ff;
																IL_05ff:
																ptr2 += 8;
																break;
																IL_0612:
																num5--;
																break;
																IL_0934:
																if (8 >= b)
																{
																	goto IL_093f;
																}
																goto IL_095f;
																IL_062e:
																if (9 <= b)
																{
																	break;
																}
																goto IL_063c;
																IL_063c:
																if (4 >= b)
																{
																	num = 97;
																	goto IL_0653;
																}
																goto IL_0800;
																IL_093f:
																if (8 <= b)
																{
																	goto IL_094a;
																}
																goto IL_095f;
																IL_0653:
																if (4 <= b)
																{
																	goto IL_065e;
																}
																goto IL_06af;
																IL_065e:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_067c;
																IL_067c:
																ptr2 += 8;
																num = 83;
																goto IL_0693;
																IL_0693:
																num5--;
																num = 31;
																break;
																IL_06af:
																if (2 < b)
																{
																	goto IL_06ba;
																}
																goto IL_0718;
																IL_06ba:
																if (3 >= b)
																{
																	goto IL_06c8;
																}
																goto IL_095f;
																IL_06c8:
																if (3 <= b)
																{
																	goto IL_06d6;
																}
																goto IL_095f;
																IL_06d6:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_06ff;
																IL_06ff:
																array[num5 - 1] = 5;
																break;
																IL_0718:
																if (2 > b)
																{
																	num = 90;
																	goto IL_072c;
																}
																goto IL_0799;
																IL_094a:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_072c:
																if (1 >= b)
																{
																	goto IL_073a;
																}
																goto IL_095f;
																IL_073a:
																if (1 <= b)
																{
																	goto IL_0748;
																}
																goto IL_095f;
																IL_0748:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0761;
																IL_0761:
																array[num5] = 0;
																goto IL_076f;
																IL_076f:
																num5++;
																num = 23;
																goto IL_0786;
																IL_0786:
																ptr2 += 8;
																break;
																IL_0799:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_07d9;
																IL_07d9:
																array[num5 - 2] = 0;
																goto IL_07ed;
																IL_07ed:
																num5--;
																break;
																IL_0800:
																if (6 >= b)
																{
																	goto IL_080e;
																}
																goto IL_08d7;
																IL_080e:
																if (6 <= b)
																{
																	goto IL_0819;
																}
																goto IL_086b;
																IL_0819:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0858;
																IL_0858:
																num5 -= 3;
																break;
																IL_086b:
																if (5 >= b)
																{
																	goto IL_0879;
																}
																goto IL_095f;
																IL_0879:
																if (5 <= b)
																{
																	num = 155;
																	goto IL_0890;
																}
																goto IL_095f;
																IL_095f:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0890:
																array[num5] = 5;
																goto IL_089e;
																IL_089e:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_08b6;
																IL_08b6:
																num5++;
																goto IL_08c4;
																IL_08c4:
																ptr2 += 8;
																break;
																IL_08d7:
																if (7 >= b)
																{
																	goto IL_08e2;
																}
																goto IL_0934;
																IL_08e2:
																if (7 <= b)
																{
																	goto IL_08ed;
																}
																goto IL_095f;
																continue;
																end_IL_02a7:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a17;
												IL_0a17:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0972:
												break;
											}
											continue;
											end_IL_0985:
											break;
										}
										continue;
										end_IL_098f:
										break;
									}
									continue;
									end_IL_099a:
									break;
								}
								continue;
								end_IL_09aa:
								break;
							}
							continue;
							end_IL_09c3:
							break;
						}
						continue;
						end_IL_09d3:
						break;
					}
					continue;
					end_IL_09e3:
					break;
				}
				continue;
				end_IL_09f3:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_5, int int_6)
	{
		int num = 19;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 35;
					while (true)
					{
						object[] array2 = new object[2];
						num = 70;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSASSEMBLYDEPLOYMENTFLAGBEFOREAPPLICATIONSTARTUPWriteOnlyArrayAttribute.WinSecurityControlPrincipal);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 4;
															while (true)
															{
																IL_0208:
																ptr2++;
																while (true)
																{
																	IL_01f8:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01d8:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01c8:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01b8:
																								if (7 < b)
																								{
																									while (true)
																									{
																										IL_01a8:
																										if (8 < b)
																										{
																											num = 94;
																											while (num != 94)
																											{
																												if (num != 1075)
																												{
																													goto end_IL_01f8;
																												}
																												switch (num)
																												{
																												case 33:
																												case 40:
																													goto IL_01a8;
																												case 15:
																													goto IL_01b8;
																												case 36:
																												case 45:
																													goto IL_01c8;
																												case 1:
																													goto IL_01d8;
																												case 47:
																													goto IL_01e8;
																												case 41:
																													goto IL_01f8;
																												case 4:
																													goto IL_0208;
																												case 21:
																												case 85:
																													goto end_IL_01f8;
																												case 75:
																													goto IL_022c;
																												case 76:
																												case 80:
																													goto IL_023a;
																												case 65:
																													goto IL_025f;
																												case 16:
																												case 17:
																													goto IL_026d;
																												case 12:
																													goto IL_027b;
																												case 13:
																													goto IL_02a7;
																												case 29:
																													goto IL_02b1;
																												case 78:
																													goto IL_02bf;
																												case 54:
																													goto IL_02d2;
																												case 64:
																													goto IL_02e0;
																												case 82:
																													goto IL_02ee;
																												case 6:
																												case 39:
																													goto IL_02fc;
																												case 25:
																													goto IL_0314;
																												case 2:
																												case 48:
																													goto IL_031f;
																												case 11:
																													goto IL_0348;
																												case 86:
																													goto IL_0356;
																												case 53:
																													goto IL_0369;
																												case 68:
																													goto IL_0377;
																												case 67:
																													goto IL_0382;
																												case 84:
																													goto IL_0390;
																												case 57:
																												case 72:
																													goto IL_03a3;
																												case 61:
																													goto IL_0411;
																												case 22:
																													goto IL_0424;
																												case 32:
																													goto IL_042f;
																												case 20:
																												case 79:
																													goto IL_043a;
																												case 81:
																													goto IL_047a;
																												case 87:
																													goto IL_048e;
																												case 9:
																												case 10:
																												case 23:
																												case 24:
																												case 27:
																												case 34:
																												case 43:
																												case 46:
																												case 49:
																												case 50:
																												case 51:
																												case 62:
																												case 66:
																												case 69:
																												case 71:
																												case 73:
																													goto end_IL_0195;
																												case 31:
																													goto IL_04c1;
																												case 55:
																													goto IL_04cf;
																												case 74:
																													goto IL_04dd;
																												case 0:
																												case 3:
																												case 26:
																												case 28:
																												case 38:
																												case 42:
																												case 44:
																												case 56:
																												case 58:
																												case 59:
																												case 60:
																													goto end_IL_0218;
																												case 5:
																													goto end_IL_04eb;
																												case 83:
																													goto end_IL_04fe;
																												case 30:
																													goto end_IL_0508;
																												case 63:
																													goto end_IL_0513;
																												case 14:
																													goto end_IL_0528;
																												case 7:
																												case 70:
																													goto end_IL_053d;
																												case 35:
																													goto end_IL_054d;
																												case 8:
																												case 77:
																													goto end_IL_055d;
																												case 18:
																													goto end_IL_0576;
																												case 19:
																													goto end_IL_058f;
																												case 37:
																												case 52:
																													goto IL_05aa;
																												}
																												continue;
																												end_IL_0195:
																												break;
																											}
																											break;
																										}
																										goto IL_022c;
																										IL_022c:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_023a;
																										IL_023a:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										num = 58;
																										goto end_IL_0218;
																									}
																									break;
																								}
																								goto IL_025f;
																								IL_02bf:
																								ptr2 += 8;
																								goto end_IL_0218;
																								IL_025f:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_026d;
																								IL_026d:
																								array[num6] = 0;
																								goto IL_027b;
																								IL_027b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								num = 13;
																								goto IL_02a7;
																								IL_02a7:
																								array2[num6] = null;
																								goto IL_02b1;
																								IL_02b1:
																								num6++;
																								goto IL_02bf;
																							}
																							break;
																						}
																						goto IL_02d2;
																						IL_02fc:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0218;
																						IL_02d2:
																						if (6 <= b)
																						{
																							goto end_IL_0218;
																						}
																						goto IL_02e0;
																						IL_02e0:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02ee;
																						IL_02ee:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02fc;
																					}
																					break;
																				}
																				goto IL_0314;
																				IL_048e:
																				num6--;
																				goto end_IL_0218;
																				IL_0314:
																				if (4 <= b)
																				{
																					goto IL_031f;
																				}
																				goto IL_0369;
																				IL_031f:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0348;
																				IL_0348:
																				ptr2 += 8;
																				goto IL_0356;
																				IL_0356:
																				num6--;
																				goto end_IL_0218;
																				IL_0369:
																				if (2 >= b)
																				{
																					goto IL_0377;
																				}
																				goto IL_0424;
																				IL_0377:
																				if (2 > b)
																				{
																					goto IL_0382;
																				}
																				goto IL_03a3;
																				IL_0382:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0390;
																				IL_0390:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_03a3:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0411;
																				IL_0411:
																				num6 -= 2;
																				goto end_IL_0218;
																				IL_0424:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_042f;
																				IL_042f:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_043a;
																				IL_043a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_047a;
																				IL_047a:
																				array[num6 - 2] = 0;
																				goto IL_048e;
																			}
																			break;
																			IL_01e8:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c1;
																	IL_04dd:
																	ptr2 += 8;
																	goto end_IL_0218;
																	IL_04cf:
																	num6++;
																	goto IL_04dd;
																	IL_04c1:
																	array[num6] = 0;
																	goto IL_04cf;
																	continue;
																	end_IL_01f8:
																	break;
																}
																break;
															}
															continue;
															end_IL_0218:
															break;
														}
														continue;
													}
													goto IL_05aa;
													IL_05aa:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04eb:
													break;
												}
												continue;
												end_IL_04fe:
												break;
											}
											continue;
											end_IL_0508:
											break;
										}
										continue;
										end_IL_0513:
										break;
									}
									continue;
									end_IL_0528:
									break;
								}
								continue;
								end_IL_053d:
								break;
							}
							continue;
							end_IL_054d:
							break;
						}
						continue;
						end_IL_055d:
						break;
					}
					continue;
					end_IL_0576:
					break;
				}
				continue;
				end_IL_058f:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_5)
	{
		int num = 80;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RestAggregateException.CreateActContextParametersSourceDefinitionAppidCODEBASELASTMOD);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0274:
														byte b = *ptr2;
														while (true)
														{
															IL_0264:
															ptr2++;
															while (true)
															{
																IL_0254:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0234:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0227:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0217:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_0207:
																									if (3 >= b)
																									{
																										while (3 <= b)
																										{
																											num = 113;
																											while (true)
																											{
																												if (num != 113)
																												{
																													if (num != 1094)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 75:
																														goto IL_01f4;
																													case 99:
																														goto IL_0207;
																													case 57:
																														goto IL_0217;
																													case 66:
																														goto IL_0227;
																													case 22:
																														goto IL_0234;
																													case 37:
																														goto IL_0244;
																													case 32:
																														goto IL_0254;
																													case 64:
																														goto IL_0264;
																													case 19:
																													case 90:
																														goto IL_0274;
																													case 10:
																													case 43:
																														goto IL_027f;
																													case 70:
																														goto IL_028d;
																													case 0:
																														goto IL_02b0;
																													case 17:
																														goto IL_02ba;
																													case 72:
																														goto IL_02cd;
																													case 78:
																														goto IL_02da;
																													case 76:
																														goto IL_02e8;
																													case 13:
																													case 81:
																														goto IL_02fb;
																													case 61:
																														goto IL_0309;
																													case 65:
																													case 89:
																														goto IL_0317;
																													case 59:
																													case 93:
																														goto IL_0332;
																													case 58:
																														goto IL_0364;
																													case 9:
																														goto IL_0372;
																													case 97:
																														goto IL_0385;
																													case 104:
																														goto IL_0398;
																													case 100:
																														goto IL_03a6;
																													case 71:
																														goto IL_03bd;
																													case 56:
																														goto IL_03d0;
																													case 30:
																														goto IL_03e8;
																													case 49:
																													case 54:
																														goto IL_03f3;
																													case 63:
																														goto IL_03fe;
																													case 46:
																													case 47:
																														goto IL_040c;
																													case 2:
																													case 40:
																														goto IL_0428;
																													case 24:
																														goto IL_0436;
																													case 6:
																														goto IL_0452;
																													case 44:
																													case 94:
																														goto IL_0460;
																													case 98:
																														goto IL_046b;
																													case 27:
																													case 50:
																														goto IL_0479;
																													case 8:
																														goto IL_04b9;
																													case 34:
																														goto IL_04cd;
																													case 14:
																														goto IL_04e0;
																													case 73:
																														goto IL_04ee;
																													case 48:
																													case 55:
																														goto IL_04fc;
																													case 82:
																														goto IL_051f;
																													case 31:
																														goto IL_052d;
																													case 87:
																														goto IL_0544;
																													case 5:
																													case 21:
																														goto IL_0557;
																													case 96:
																														goto IL_05b9;
																													case 4:
																													case 15:
																													case 23:
																													case 25:
																													case 26:
																													case 33:
																													case 35:
																													case 36:
																													case 41:
																													case 51:
																													case 52:
																													case 60:
																													case 62:
																													case 74:
																													case 77:
																													case 84:
																													case 86:
																													case 88:
																													case 92:
																													case 95:
																													case 103:
																													case 106:
																														goto end_IL_01f4;
																													case 3:
																													case 11:
																													case 12:
																													case 16:
																													case 20:
																													case 29:
																													case 38:
																													case 39:
																													case 42:
																													case 45:
																													case 67:
																													case 83:
																													case 105:
																														goto end_IL_01e1;
																													case 102:
																														goto end_IL_05dc;
																													case 68:
																														goto end_IL_05ef;
																													case 28:
																														goto end_IL_05f9;
																													case 85:
																														goto end_IL_0604;
																													case 69:
																													case 101:
																														goto end_IL_0619;
																													case 7:
																														goto end_IL_0629;
																													case 1:
																													case 53:
																														goto end_IL_0639;
																													case 79:
																														goto end_IL_0649;
																													case 80:
																														goto end_IL_0659;
																													case 18:
																													case 91:
																														goto IL_0674;
																													}
																													continue;
																												}
																												goto IL_03d0;
																												IL_03d0:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												break;
																												continue;
																												end_IL_01e1:
																												break;
																											}
																											goto end_IL_0254;
																											continue;
																											end_IL_01f4:
																											break;
																											IL_01f4:;
																										}
																										break;
																									}
																									goto IL_02da;
																									IL_02e8:
																									if (4 <= b)
																									{
																										goto end_IL_0254;
																									}
																									break;
																									IL_02da:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_02e8;
																								}
																								break;
																							}
																							goto IL_02cd;
																							IL_0372:
																							num5--;
																							goto end_IL_0254;
																							IL_02cd:
																							if (2 > b)
																							{
																								goto IL_02fb;
																							}
																							goto IL_0332;
																							IL_02fb:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0309;
																							IL_0309:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0317;
																							IL_0317:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0398;
																							IL_0398:
																							array[num5] = 0;
																							goto IL_03a6;
																							IL_03a6:
																							num5++;
																							num = 71;
																							goto IL_03bd;
																							IL_03bd:
																							ptr2 += 8;
																							goto end_IL_0254;
																							IL_0332:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 58;
																							goto IL_0364;
																							IL_0364:
																							ptr2 += 8;
																							goto IL_0372;
																						}
																						break;
																					}
																					goto IL_027f;
																					IL_0385:
																					ptr2 += 8;
																					goto end_IL_0254;
																					IL_027f:
																					array[num5] = 0;
																					goto IL_028d;
																					IL_028d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02b0;
																					IL_02b0:
																					array2[num5] = null;
																					goto IL_02ba;
																					IL_02ba:
																					num5++;
																					goto IL_0385;
																				}
																				break;
																			}
																			goto IL_03e8;
																			IL_0557:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05b9;
																			IL_03e8:
																			if (8 < b)
																			{
																				goto IL_03f3;
																			}
																			goto IL_0452;
																			IL_03f3:
																			if (9 >= b)
																			{
																				goto IL_03fe;
																			}
																			goto IL_0428;
																			IL_03fe:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_040c;
																			IL_040c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0254;
																			IL_0428:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0436;
																			IL_0436:
																			if (10 > b)
																			{
																				num = 106;
																			}
																			break;
																			IL_05b9:
																			num5 -= 2;
																			goto end_IL_0254;
																			IL_0452:
																			if (8 > b)
																			{
																				goto IL_0460;
																			}
																			goto IL_0557;
																			IL_0460:
																			if (6 >= b)
																			{
																				goto IL_046b;
																			}
																			goto IL_04e0;
																			IL_046b:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0479;
																			IL_0479:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b9;
																			IL_04b9:
																			array[num5 - 2] = 0;
																			goto IL_04cd;
																			IL_04cd:
																			num5--;
																			goto end_IL_0254;
																			IL_04e0:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04ee;
																			IL_04ee:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04fc;
																			IL_04fc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_051f;
																			IL_051f:
																			array[num5] = 0;
																			goto IL_052d;
																			IL_052d:
																			num5++;
																			num = 87;
																			goto IL_0544;
																			IL_0544:
																			ptr2 += 8;
																			goto end_IL_0254;
																		}
																		break;
																		IL_0244:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0254:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0674;
												IL_0674:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05dc:
												break;
											}
											continue;
											end_IL_05ef:
											break;
										}
										continue;
										end_IL_05f9:
										break;
									}
									continue;
									end_IL_0604:
									break;
								}
								continue;
								end_IL_0619:
								break;
							}
							continue;
							end_IL_0629:
							break;
						}
						continue;
						end_IL_0639:
						break;
					}
					continue;
					end_IL_0649:
					break;
				}
				continue;
				end_IL_0659:
				break;
			}
		}
	}

	private unsafe static int smethod_19(int int_5, int int_6)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 71;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										IL_0659:
										array3[1] = int_6;
										while (true)
										{
											IL_064e:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct78.AssemblyIsolationByUserIgnoreSymbols);
											while (true)
											{
												IL_063b:
												byte* ptr2 = ptr;
												num = 22;
												while (true)
												{
													IL_0628:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0257:
															byte b = *ptr2;
															while (true)
															{
																IL_0247:
																ptr2++;
																while (true)
																{
																	IL_0237:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0217:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_020a:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_01fa:
																								if (7 <= b)
																								{
																									while (true)
																									{
																										IL_01d6:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 109;
																										while (true)
																										{
																											if (num != 109)
																											{
																												if (num != 1090)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 53:
																												case 68:
																													goto IL_01d6;
																												case 34:
																													goto IL_01fa;
																												case 94:
																													goto IL_020a;
																												case 19:
																													goto IL_0217;
																												case 5:
																													goto IL_0227;
																												case 93:
																													goto IL_0237;
																												case 80:
																													goto IL_0247;
																												case 32:
																												case 37:
																													goto IL_0257;
																												case 18:
																													goto IL_0262;
																												case 13:
																												case 20:
																													goto IL_026d;
																												case 47:
																													goto IL_027b;
																												case 73:
																													goto IL_028e;
																												case 24:
																												case 61:
																													goto IL_029c;
																												case 64:
																													goto IL_02dc;
																												case 66:
																												case 74:
																													goto IL_02f2;
																												case 30:
																													goto IL_0300;
																												case 7:
																												case 26:
																													goto IL_030e;
																												case 81:
																													goto IL_0350;
																												case 83:
																													goto IL_0363;
																												case 29:
																													goto IL_0377;
																												case 48:
																												case 87:
																													goto IL_038a;
																												case 89:
																													goto IL_03a6;
																												case 85:
																													goto IL_03b4;
																												case 27:
																												case 40:
																													goto IL_03bf;
																												case 35:
																													goto IL_03ca;
																												case 1:
																												case 54:
																													goto IL_03d8;
																												case 55:
																													goto IL_0401;
																												case 43:
																													goto IL_041d;
																												case 36:
																													goto IL_042b;
																												case 77:
																													goto IL_043e;
																												case 39:
																												case 69:
																													goto IL_0449;
																												case 88:
																													goto IL_0489;
																												case 4:
																													goto IL_049d;
																												case 45:
																													goto IL_04b0;
																												case 46:
																													goto IL_04be;
																												case 62:
																												case 72:
																													goto IL_04d1;
																												case 90:
																													goto IL_04e8;
																												case 63:
																													goto IL_050b;
																												case 75:
																													goto IL_0515;
																												case 91:
																													goto IL_0525;
																												case 92:
																													goto IL_0538;
																												case 49:
																												case 98:
																													goto IL_054b;
																												case 58:
																													goto IL_058b;
																												case 8:
																													goto IL_059f;
																												case 2:
																													goto IL_05bd;
																												case 9:
																													goto IL_05cb;
																												case 0:
																												case 6:
																												case 14:
																												case 16:
																												case 17:
																												case 21:
																												case 23:
																												case 33:
																												case 51:
																												case 57:
																												case 65:
																												case 67:
																												case 82:
																												case 86:
																												case 95:
																												case 96:
																												case 97:
																													goto end_IL_0227;
																												case 28:
																													goto IL_05fe;
																												case 15:
																													goto IL_060c;
																												case 31:
																													goto IL_061a;
																												case 10:
																												case 22:
																												case 50:
																												case 59:
																												case 60:
																												case 70:
																												case 78:
																												case 79:
																												case 84:
																												case 99:
																												case 102:
																													goto IL_0628;
																												case 38:
																													goto IL_063b;
																												case 44:
																													goto IL_064e;
																												case 25:
																													goto IL_0659;
																												case 12:
																													goto end_IL_01c3;
																												case 41:
																													goto end_IL_066e;
																												case 3:
																												case 71:
																													goto end_IL_0683;
																												case 56:
																													goto end_IL_0693;
																												case 11:
																												case 76:
																													goto end_IL_06a3;
																												case 100:
																													goto end_IL_06bc;
																												case 101:
																													goto end_IL_06cc;
																												case 42:
																												case 52:
																													goto IL_06e7;
																												}
																												continue;
																											}
																											array[num5] = 0;
																											goto IL_05bd;
																											IL_05bd:
																											num5++;
																											goto IL_05cb;
																											IL_05cb:
																											ptr2 += 8;
																											goto IL_0628;
																											continue;
																											end_IL_01c3:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02f2;
																								IL_0377:
																								num5--;
																								goto IL_0628;
																								IL_02f2:
																								if (6 < b)
																								{
																									goto end_IL_0227;
																								}
																								goto IL_0300;
																								IL_0300:
																								if (6 > b)
																								{
																									goto end_IL_0227;
																								}
																								goto IL_030e;
																								IL_030e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0363;
																								IL_0363:
																								array[num5 - 2] = 0;
																								goto IL_0377;
																							}
																							break;
																						}
																						goto IL_0262;
																						IL_0350:
																						num5--;
																						goto IL_0628;
																						IL_0262:
																						if (8 < b)
																						{
																							goto IL_026d;
																						}
																						goto IL_028e;
																						IL_026d:
																						if (9 < b)
																						{
																							goto end_IL_0227;
																						}
																						goto IL_027b;
																						IL_027b:
																						if (9 > b)
																						{
																							goto end_IL_0227;
																						}
																						goto IL_038a;
																						IL_038a:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto IL_0628;
																						IL_028e:
																						if (8 > b)
																						{
																							goto end_IL_0227;
																						}
																						goto IL_029c;
																						IL_029c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02dc;
																						IL_02dc:
																						array[num5 - 2] = 0;
																						goto IL_0350;
																					}
																					break;
																				}
																				goto IL_03a6;
																				IL_0538:
																				ptr2 += 8;
																				goto IL_0628;
																				IL_03a6:
																				if (5 > b)
																				{
																					goto IL_03b4;
																				}
																				goto IL_04d1;
																				IL_03b4:
																				if (2 < b)
																				{
																					goto IL_03bf;
																				}
																				goto IL_043e;
																				IL_03bf:
																				if (3 >= b)
																				{
																					goto IL_03ca;
																				}
																				goto IL_041d;
																				IL_03ca:
																				if (3 > b)
																				{
																					goto end_IL_0227;
																				}
																				goto IL_03d8;
																				IL_03d8:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0401;
																				IL_0401:
																				ptr2 += 8;
																				num = 91;
																				goto IL_0525;
																				IL_0525:
																				num5--;
																				goto IL_0628;
																				IL_041d:
																				if (4 < b)
																				{
																					goto end_IL_0227;
																				}
																				goto IL_042b;
																				IL_042b:
																				if (4 > b)
																				{
																					goto end_IL_0227;
																				}
																				goto IL_054b;
																				IL_054b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_058b;
																				IL_058b:
																				array[num5 - 2] = 0;
																				goto IL_059f;
																				IL_059f:
																				num5--;
																				goto IL_0628;
																				IL_043e:
																				if (2 <= b)
																				{
																					goto IL_0449;
																				}
																				goto IL_04b0;
																				IL_0449:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0489;
																				IL_0489:
																				array[num5 - 2] = 0;
																				goto IL_049d;
																				IL_049d:
																				num5--;
																				goto IL_0628;
																				IL_04b0:
																				if (1 < b)
																				{
																					goto end_IL_0227;
																				}
																				goto IL_04be;
																				IL_04be:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0227;
																				IL_04d1:
																				array[num5] = 0;
																				num = 90;
																				goto IL_04e8;
																				IL_04e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_050b;
																				IL_050b:
																				array2[num5] = null;
																				goto IL_0515;
																				IL_0515:
																				num5++;
																				goto IL_0538;
																			}
																			goto end_IL_0237;
																			continue;
																			end_IL_0227:
																			break;
																			IL_0227:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05fe;
																	IL_061a:
																	ptr2 += 8;
																	goto IL_0628;
																	IL_060c:
																	num5++;
																	goto IL_061a;
																	IL_05fe:
																	array[num5] = 0;
																	goto IL_060c;
																	continue;
																	end_IL_0237:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_06e7;
													IL_06e7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_066e:
									break;
								}
								continue;
								end_IL_0683:
								break;
							}
							continue;
							end_IL_0693:
							break;
						}
						continue;
						end_IL_06a3:
						break;
					}
					continue;
					end_IL_06bc:
					break;
				}
				continue;
				end_IL_06cc:
				break;
			}
		}
	}

	private unsafe static int smethod_20()
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadBooleanSerializable.LASTCALENDARDeclaredMembers);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0308:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02eb:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02db:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02cb:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02bb:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02ab:
																											if (10 > b)
																											{
																												while (true)
																												{
																													IL_0298:
																													if (9 < b)
																													{
																														num = 154;
																														while (num != 154)
																														{
																															if (num != 1135)
																															{
																																goto IL_04dc;
																															}
																															switch (num)
																															{
																															case 74:
																															case 140:
																																goto IL_0298;
																															case 1:
																																goto IL_02ab;
																															case 88:
																															case 110:
																																goto IL_02bb;
																															case 123:
																																goto IL_02cb;
																															case 93:
																																goto IL_02db;
																															case 27:
																																goto IL_02eb;
																															case 8:
																																goto IL_02f8;
																															case 121:
																																goto IL_0308;
																															case 132:
																																goto end_IL_0308;
																															case 55:
																															case 56:
																																goto end_IL_0318;
																															case 11:
																																goto IL_0333;
																															case 100:
																															case 103:
																																goto IL_0341;
																															case 36:
																																goto IL_034c;
																															case 115:
																																goto IL_035f;
																															case 32:
																																goto IL_036a;
																															case 30:
																															case 33:
																																goto IL_0375;
																															case 49:
																																goto IL_03b4;
																															case 63:
																																goto IL_03c7;
																															case 58:
																																goto IL_03d7;
																															case 31:
																																goto IL_03e2;
																															case 54:
																															case 116:
																																goto IL_0403;
																															case 119:
																																goto IL_041b;
																															case 51:
																															case 109:
																																goto IL_0429;
																															case 104:
																															case 133:
																																goto IL_043c;
																															case 135:
																																goto IL_045f;
																															case 4:
																																goto IL_046a;
																															case 44:
																																goto IL_0478;
																															case 15:
																															case 45:
																																goto IL_0486;
																															case 48:
																																goto IL_04af;
																															case 102:
																																goto IL_04d1;
																															case 37:
																															case 106:
																																goto IL_04dc;
																															case 69:
																																goto IL_04ea;
																															case 7:
																															case 20:
																																goto IL_04fd;
																															case 137:
																																goto IL_0542;
																															case 97:
																																goto IL_055a;
																															case 12:
																																goto IL_0568;
																															case 66:
																															case 138:
																																goto IL_057b;
																															case 117:
																																goto IL_05a4;
																															case 24:
																																goto IL_05b2;
																															case 13:
																															case 139:
																																goto IL_05c5;
																															case 124:
																																goto IL_05de;
																															case 78:
																																goto IL_05ec;
																															case 92:
																																goto IL_05fa;
																															case 53:
																															case 141:
																																goto IL_060d;
																															case 46:
																															case 114:
																																goto IL_0618;
																															case 64:
																																goto IL_0626;
																															case 34:
																																goto IL_0639;
																															case 5:
																															case 17:
																																goto IL_0644;
																															case 126:
																																goto IL_0669;
																															case 0:
																																goto IL_0677;
																															case 99:
																															case 101:
																																goto IL_0685;
																															case 59:
																																goto IL_06e7;
																															case 143:
																																goto IL_06fa;
																															case 77:
																																goto IL_0708;
																															case 144:
																																goto IL_071b;
																															case 3:
																																goto IL_072f;
																															case 35:
																															case 146:
																																goto IL_074b;
																															case 129:
																																goto IL_0759;
																															case 28:
																															case 111:
																																goto IL_0767;
																															case 50:
																																goto IL_07ab;
																															case 125:
																																goto IL_07bf;
																															case 145:
																																goto IL_07d2;
																															case 87:
																															case 131:
																																goto IL_07e5;
																															case 14:
																																goto IL_07f3;
																															case 62:
																																goto IL_0816;
																															case 76:
																																goto IL_0820;
																															case 84:
																																goto IL_082e;
																															case 47:
																															case 65:
																																goto IL_0841;
																															case 16:
																																goto IL_0881;
																															case 96:
																																goto IL_0895;
																															case 2:
																															case 9:
																															case 19:
																															case 21:
																															case 22:
																															case 23:
																															case 25:
																															case 29:
																															case 41:
																															case 43:
																															case 57:
																															case 67:
																															case 68:
																															case 71:
																															case 75:
																															case 79:
																															case 80:
																															case 81:
																															case 85:
																															case 91:
																															case 95:
																															case 113:
																															case 127:
																															case 136:
																															case 142:
																															case 147:
																																goto end_IL_0285;
																															case 18:
																															case 26:
																															case 38:
																															case 52:
																															case 61:
																															case 72:
																															case 73:
																															case 89:
																															case 90:
																															case 98:
																															case 105:
																															case 108:
																															case 112:
																															case 118:
																															case 120:
																															case 122:
																															case 130:
																															case 134:
																																goto end_IL_0328;
																															case 40:
																																goto end_IL_08c1;
																															case 94:
																																goto end_IL_08d4;
																															case 42:
																																goto end_IL_08de;
																															case 60:
																																goto end_IL_08e9;
																															case 6:
																															case 107:
																																goto end_IL_08f9;
																															case 10:
																																goto end_IL_0909;
																															case 39:
																															case 128:
																																goto end_IL_0919;
																															case 82:
																																goto end_IL_0929;
																															case 83:
																																goto end_IL_0939;
																															case 70:
																															case 86:
																																goto IL_0954;
																															}
																															continue;
																															end_IL_0285:
																															break;
																														}
																														break;
																													}
																													goto IL_07d2;
																													IL_07d2:
																													if (9 > b)
																													{
																														break;
																													}
																													goto end_IL_0328;
																												}
																												break;
																											}
																											goto IL_07e5;
																											IL_082e:
																											ptr2 += 8;
																											goto end_IL_0328;
																											IL_07e5:
																											array[num5] = 0;
																											goto IL_07f3;
																											IL_07f3:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0816;
																											IL_0816:
																											array2[num5] = null;
																											goto IL_0820;
																											IL_0820:
																											num5++;
																											goto IL_082e;
																										}
																										break;
																									}
																									goto IL_074b;
																									IL_07bf:
																									num5--;
																									goto end_IL_0328;
																									IL_074b:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_0759;
																									IL_0759:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_0767;
																									IL_0767:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_07ab;
																									IL_07ab:
																									array[num5 - 2] = 0;
																									goto IL_07bf;
																								}
																								break;
																							}
																							goto IL_0841;
																							IL_0895:
																							num5--;
																							goto end_IL_0328;
																							IL_0841:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0881;
																							IL_0881:
																							array[num5 - 2] = 0;
																							goto IL_0895;
																						}
																						break;
																					}
																					goto IL_060d;
																					IL_06e7:
																					num5 -= 2;
																					goto end_IL_0328;
																					IL_060d:
																					if (14 < b)
																					{
																						goto IL_0618;
																					}
																					goto IL_0639;
																					IL_0618:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0626;
																					IL_0626:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_0639:
																					if (14 <= b)
																					{
																						goto IL_0644;
																					}
																					goto IL_0669;
																					IL_0644:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 26;
																					goto end_IL_0328;
																					IL_0669:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0677;
																					IL_0677:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0685;
																					IL_0685:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_06e7;
																				}
																				break;
																			}
																			goto IL_0333;
																			IL_05b2:
																			num5--;
																			goto end_IL_0328;
																			IL_0333:
																			if (8 > b)
																			{
																				goto IL_0341;
																			}
																			goto IL_0403;
																			IL_0341:
																			if (4 >= b)
																			{
																				goto IL_034c;
																			}
																			goto IL_035f;
																			IL_034c:
																			if (4 <= b)
																			{
																				goto IL_043c;
																			}
																			goto IL_045f;
																			IL_043c:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_06fa;
																			IL_06fa:
																			ptr2 += 8;
																			goto IL_0708;
																			IL_0708:
																			num5--;
																			goto end_IL_0328;
																			IL_045f:
																			if (2 < b)
																			{
																				goto IL_046a;
																			}
																			num = 102;
																			goto IL_04d1;
																			IL_046a:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0478;
																			IL_0478:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0486;
																			IL_0486:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_04af;
																			IL_04af:
																			array[num5 - 1] = 5;
																			goto end_IL_0328;
																			IL_0403:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0328;
																			IL_04d1:
																			if (2 > b)
																			{
																				goto IL_04dc;
																			}
																			goto IL_04fd;
																			IL_04dc:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04ea;
																			IL_04ea:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05c5;
																			IL_05c5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05de;
																			IL_05de:
																			array[num5] = 0;
																			goto IL_05ec;
																			IL_05ec:
																			num5++;
																			goto IL_05fa;
																			IL_05fa:
																			ptr2 += 8;
																			goto end_IL_0328;
																			IL_04fd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_071b;
																			IL_071b:
																			array[num5 - 2] = 0;
																			goto IL_072f;
																			IL_072f:
																			num5--;
																			num = 122;
																			goto end_IL_0328;
																			IL_035f:
																			if (6 >= b)
																			{
																				goto IL_036a;
																			}
																			goto IL_03d7;
																			IL_036a:
																			if (6 <= b)
																			{
																				goto IL_0375;
																			}
																			goto IL_03c7;
																			IL_0375:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03b4;
																			IL_03b4:
																			num5 -= 3;
																			goto end_IL_0328;
																			IL_03c7:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_041b;
																			IL_041b:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0429;
																			IL_0429:
																			array[num5] = 5;
																			goto IL_0542;
																			IL_0542:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_055a;
																			IL_055a:
																			num5++;
																			goto IL_0568;
																			IL_0568:
																			ptr2 += 8;
																			goto end_IL_0328;
																			IL_03d7:
																			if (7 < b)
																			{
																				num = 57;
																				break;
																			}
																			goto IL_03e2;
																			IL_03e2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_057b;
																			IL_057b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05a4;
																			IL_05a4:
																			ptr2 += 8;
																			goto IL_05b2;
																		}
																		break;
																		IL_02f8:;
																	}
																}
																else
																{
																	num = 68;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0328;
																continue;
																end_IL_0308:
																break;
															}
															continue;
															end_IL_0318:
															break;
														}
														continue;
														end_IL_0328:
														break;
													}
													continue;
												}
												goto IL_0954;
												IL_0954:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c1:
												break;
											}
											continue;
											end_IL_08d4:
											break;
										}
										continue;
										end_IL_08de:
										break;
									}
									continue;
									end_IL_08e9:
									break;
								}
								continue;
								end_IL_08f9:
								break;
							}
							continue;
							end_IL_0909:
							break;
						}
						continue;
						end_IL_0919:
						break;
					}
					continue;
					end_IL_0929:
					break;
				}
				continue;
				end_IL_0939:
				break;
			}
		}
	}

	static Class108()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 4:
							case 5:
							case 6:
								goto end_IL_003d;
							case 2:
								goto end_IL_004a;
							case 3:
								goto end_IL_0062;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_0062:
				break;
			}
		}
	}
}
