using System;
using System.Runtime.CompilerServices;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Point Gun", "Rig", "Point at other players.", false, 43, ModType.const_0, false)]
internal class Class193 : MonoBehaviour
{
	private static string string_0;

	private static double double_0;

	private static int int_0;

	private static bool bool_0;

	private static float float_0;

	private static bool bool_1;

	private static double double_1;

	private static float float_1;

	private static IntPtr[] RegistryValueOptionsEventSource;

	private static IntPtr[] IIDENTITYAUTHORITYDEFINITIONIDENTITYTOTEXTFLAGCANONICALgetGlobalAssemblyCache;

	private static IntPtr[] ctimegetProcessorArchitecture;

	private static IntPtr[] ParameterInfoSystemThreadingTasksTaskSchedulerDebugView;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001e, IL_09fb, IL_0a0e, IL_0a27, IL_0a37, IL_0a5d, IL_0a6d, IL_0a7d, IL_0a8d, IL_0a9a, IL_0aaa, IL_0aba, IL_0aca, IL_0ada, IL_0aea, IL_0afa, IL_0b0a, IL_0b15, IL_0b20, IL_0b2e, IL_0b3c, IL_0b4a, IL_0b67, IL_0ba6, IL_0bb9, IL_0bc4, IL_0bd2, IL_0be0, IL_0bfe, IL_0c32, IL_0c4b, IL_0c56, IL_0c93, IL_0ca1, IL_0cb4, IL_0cc2, IL_0cd0, IL_0cde, IL_0ce9, IL_0cfd, IL_0d3a, IL_0d4d, IL_0d5b, IL_0d69, IL_0d7d, IL_0db5, IL_0dc8, IL_0dd3, IL_0de6, IL_0df4, IL_0e02, IL_0e16, IL_0e67, IL_0e75, IL_0e88, IL_0e91, IL_0ea4, IL_0eaf, IL_0ebd, IL_0ed1, IL_0f23, IL_0f31, IL_0f3f, IL_0f4d, IL_0f99, IL_0fa7, IL_0fb5, IL_0fc3, IL_0fcc, IL_0fda, IL_0ff7, IL_1036, IL_1049, IL_1054, IL_1067, IL_1075, IL_1083, IL_1097, IL_10d6, IL_10e9, IL_10f7, IL_1115, IL_1123, IL_1136, IL_114f, IL_1162, IL_1176, IL_1189, IL_11b2, IL_11c9, IL_11dc, IL_11ea, IL_11f5, IL_1209, IL_1241, IL_1254, IL_1262, IL_126c, IL_127a, IL_128d, IL_129b, IL_12b8, IL_12f7, IL_130a, IL_1318, IL_1326, IL_1334, IL_133f, IL_134d, IL_1370, IL_137e, IL_138c, IL_139f, IL_13ad, IL_13bb, IL_13d4, IL_13df, IL_13ed, IL_13fb, IL_140f, IL_1447, IL_145a, IL_146e, IL_14ab, IL_14c7, IL_14db, IL_1518, IL_152b, IL_1536, IL_154f, IL_1562, IL_1570, IL_157b, IL_1594, IL_15a2, IL_15ab, IL_15b9, IL_15c2, IL_15df, IL_161c, IL_1638, IL_1643, IL_1651, IL_1674, IL_1682, IL_1690, IL_16ac, IL_16ba, IL_16c8, IL_16dc, IL_172d, IL_173b, IL_174e, IL_1759, IL_1777, IL_1785, IL_1793, IL_17a6, IL_17b4, IL_17bf, IL_17f7, IL_180b, IL_181e, IL_182c, IL_183a, IL_1848, IL_1866, IL_1874, IL_1887, IL_1895, IL_18a3, IL_18ea, IL_18f8, IL_1914, IL_1937, IL_1945, IL_1953, IL_1966, IL_197d, IL_1990, IL_19e1, IL_19ef, IL_1a0b, IL_1a1e, IL_1a5b, IL_1a6e, IL_1a7c, IL_1a87, IL_1a9b, IL_1ada, IL_1af6, IL_1b04, IL_1b12, IL_1b2b, IL_1b3e, IL_1b49, IL_1b57, IL_1b8f, IL_1ba3, IL_1bb6, IL_1bc4, IL_1bd2, IL_1c0a, IL_1c1e, IL_1c31, IL_1c3f, IL_1c52, IL_1c5d, IL_1c79, IL_1c87, IL_1c92, IL_1caf, IL_1ce7, IL_1cfa, IL_1d08, IL_1d16, IL_1d24, IL_1d32, IL_1d40, IL_1d54, IL_1da8, IL_1db6, IL_1dc9, IL_1dd7, IL_1de5, IL_1e47, IL_1e5a, IL_1e65, IL_1e78, IL_1e86, IL_1e94, IL_1eb1, IL_1f00, IL_1f0a, IL_1f37, IL_1f4b, IL_1f59, IL_1f6c, IL_1f93, IL_1fa1, IL_1fb4, IL_1fc2, IL_1fd0, IL_1fe8, IL_2006, IL_202a, IL_2042, IL_2055, IL_2063, IL_2071, IL_209a, IL_20b3, IL_20be, IL_20cc, IL_20da, IL_20f2, IL_2109, IL_211c, IL_212a, IL_2138, IL_2176, IL_2189, IL_2192, IL_21a0, IL_21ae, IL_21bc, IL_21c7, IL_2207, IL_2224, IL_2237, IL_2245, IL_2253, IL_2293, IL_22a7, IL_22ba, IL_22c5, IL_22d3, IL_22e1, IL_22f4, IL_22fd, IL_230b, IL_2354, IL_2371, IL_2384, IL_238d, IL_2398, IL_23a6, IL_23c9, IL_23d3, IL_23e1, IL_23f4, IL_2402, IL_240d, IL_241b, IL_2429, IL_2442, IL_2450, IL_245e, IL_2471, IL_24b1, IL_24c5, IL_24e1, IL_24ef, IL_24fd, IL_2526, IL_2534, IL_2547, IL_2587, IL_259b, IL_25b7, IL_25c5, IL_25d3, IL_25e1, IL_25ec, IL_263e, IL_2651, IL_265f, IL_266a, IL_2682, IL_2690, IL_269e, IL_26b7, IL_26c5, IL_26d3, IL_26e6, IL_26f4, IL_2702, IL_2743, IL_2757, IL_276a, IL_2778, IL_2783, IL_27c1, IL_27d5, IL_27e8, IL_27f6, IL_2804, IL_2827, IL_2835, IL_2843, IL_2856, IL_2861, IL_286f, IL_28cd, IL_28e0, IL_28ee, IL_28fc, IL_2915, IL_2923, IL_293a, IL_294d, IL_2961, IL_29a0, IL_29b3, IL_29c1, IL_29cf, IL_29dd, IL_29e8, IL_29fc, IL_2a3b, IL_2a4e, IL_2a5c, IL_2a6a, IL_2aaa, IL_2abe, IL_2ad1, IL_2adc, IL_2aea, IL_2b22, IL_2b36, IL_2b49, IL_2b57, IL_2b60, IL_2b6e, IL_2bb6, IL_2bc9, IL_2c09, IL_2c1d, IL_2c30, IL_2c3e, IL_2c49, IL_2c57, IL_2c65, IL_2c6e, IL_2c88, IL_2c96, IL_2cad, IL_2cc0, IL_2cd4, IL_2d65, IL_2d73, IL_2d86, IL_2d91, IL_2d9f, IL_2db8, IL_2dcb, IL_2dd6, IL_2de1, IL_2df5, IL_2e34, IL_2e44, IL_2e57, IL_2e6a, IL_2e74, IL_2e7f, IL_2e8f, IL_2e9f, IL_2eaf, IL_2ebf, IL_2ecf, IL_2edf, IL_2ef8, IL_2f08 are reachable both inside and outside the pinned region starting at IL_2f26. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 229;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef91 = default(int);
			ref int reference = ref __rxRef91;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2f08:
					num2 = 1;
					num = 596;
					while (true)
					{
						IL_2ef8:
						num3 = num2 * 4;
						while (true)
						{
							IL_2edf:
							num4 = num2 * 8;
							num = 511;
							while (true)
							{
								IL_2ecf:
								array2 = new byte[5];
								while (true)
								{
									IL_2ebf:
									array3 = new object[5];
									while (true)
									{
										IL_2eaf:
										array4 = new int[5];
										while (true)
										{
											IL_2e9f:
											array5 = new int[7];
											while (true)
											{
												IL_2e8f:
												array6 = new long[5];
												while (true)
												{
													IL_2e7f:
													array7 = new object[8];
													while (true)
													{
														IL_2e74:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OutOfMemoryExceptionCCSYSCALL.IndexOfValueDirectoryString);
														while (true)
														{
															IL_2e6a:
															ptr2 = ptr;
															while (true)
															{
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0b0a:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0afa:
																		ptr2++;
																		while (true)
																		{
																			IL_0aea:
																			if (b >= 1)
																			{
																				while (b <= 76)
																				{
																					while (true)
																					{
																						IL_0aca:
																						if (38 < b)
																						{
																							while (true)
																							{
																								IL_0aba:
																								if (57 < b)
																								{
																									while (true)
																									{
																										IL_0aaa:
																										if (67 < b)
																										{
																											while (true)
																											{
																												IL_0a9a:
																												if (72 < b)
																												{
																													while (true)
																													{
																														IL_0a8d:
																														if (74 < b)
																														{
																															while (true)
																															{
																																IL_0a7d:
																																if (75 >= b)
																																{
																																	while (75 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_0a5d:
																																			array2[num6] = 0;
																																			while (true)
																																			{
																																				IL_0a37:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])() ? 1 : 0);
																																				while (true)
																																				{
																																					IL_0a27:
																																					num6++;
																																					while (true)
																																					{
																																						IL_0a0e:
																																						ptr2 += 8;
																																						num = 635;
																																						while (num != 635)
																																						{
																																							if (num != 1616)
																																							{
																																								goto IL_2a4e;
																																							}
																																							switch (num)
																																							{
																																							case 229:
																																								break;
																																							default:
																																								continue;
																																							case 361:
																																								goto IL_0a0e;
																																							case 92:
																																								goto IL_0a27;
																																							case 188:
																																								goto IL_0a37;
																																							case 404:
																																							case 592:
																																								goto IL_0a5d;
																																							case 481:
																																								goto IL_0a6d;
																																							case 12:
																																								goto IL_0a7d;
																																							case 432:
																																								goto IL_0a8d;
																																							case 615:
																																								goto IL_0a9a;
																																							case 440:
																																								goto IL_0aaa;
																																							case 581:
																																								goto IL_0aba;
																																							case 504:
																																								goto IL_0aca;
																																							case 319:
																																								goto IL_0ada;
																																							case 85:
																																								goto IL_0aea;
																																							case 18:
																																								goto IL_0afa;
																																							case 356:
																																							case 549:
																																								goto IL_0b0a;
																																							case 96:
																																								goto IL_0b15;
																																							case 332:
																																								goto IL_0b2e;
																																							case 17:
																																								goto IL_0b3c;
																																							case 89:
																																							case 328:
																																								goto IL_0b4a;
																																							case 30:
																																								goto IL_0b67;
																																							case 47:
																																								goto IL_0ba6;
																																							case 374:
																																								goto IL_0bb9;
																																							case 13:
																																								goto IL_0bc4;
																																							case 24:
																																								goto IL_0bd2;
																																							case 191:
																																							case 192:
																																								goto IL_0be0;
																																							case 40:
																																							case 261:
																																								goto IL_0bfe;
																																							case 79:
																																								goto IL_0c32;
																																							case 514:
																																								goto IL_0c4b;
																																							case 156:
																																							case 509:
																																								goto IL_0c56;
																																							case 418:
																																								goto IL_0c93;
																																							case 50:
																																								goto IL_0ca1;
																																							case 265:
																																								goto IL_0cb4;
																																							case 312:
																																								goto IL_0cc2;
																																							case 465:
																																								goto IL_0cd0;
																																							case 439:
																																								goto IL_0cde;
																																							case 44:
																																							case 298:
																																								goto IL_0ce9;
																																							case 212:
																																								goto IL_0cfd;
																																							case 56:
																																								goto IL_0d3a;
																																							case 443:
																																								goto IL_0d4d;
																																							case 368:
																																								goto IL_0d5b;
																																							case 75:
																																							case 449:
																																								goto IL_0d69;
																																							case 478:
																																								goto IL_0d7d;
																																							case 119:
																																								goto IL_0db5;
																																							case 21:
																																								goto IL_0dc8;
																																							case 78:
																																								goto IL_0dd3;
																																							case 313:
																																								goto IL_0de6;
																																							case 54:
																																								goto IL_0df4;
																																							case 194:
																																							case 462:
																																								goto IL_0e02;
																																							case 317:
																																								goto IL_0e16;
																																							case 84:
																																								goto IL_0e67;
																																							case 354:
																																								goto IL_0e75;
																																							case 284:
																																								goto IL_0e91;
																																							case 527:
																																								goto IL_0ea4;
																																							case 174:
																																								goto IL_0eaf;
																																							case 250:
																																							case 455:
																																								goto IL_0ebd;
																																							case 264:
																																								goto IL_0ed1;
																																							case 170:
																																								goto IL_0f23;
																																							case 61:
																																								goto IL_0f31;
																																							case 386:
																																								goto IL_0f3f;
																																							case 16:
																																							case 411:
																																								goto IL_0f4d;
																																							case 530:
																																								goto IL_0f99;
																																							case 88:
																																								goto IL_0fa7;
																																							case 241:
																																								goto IL_0fb5;
																																							case 486:
																																								goto IL_0fcc;
																																							case 392:
																																							case 413:
																																								goto IL_0fda;
																																							case 452:
																																								goto IL_0ff7;
																																							case 262:
																																								goto IL_1036;
																																							case 288:
																																								goto IL_1049;
																																							case 225:
																																								goto IL_1054;
																																							case 397:
																																								goto IL_1067;
																																							case 183:
																																								goto IL_1075;
																																							case 82:
																																							case 137:
																																								goto IL_1083;
																																							case 275:
																																								goto IL_1097;
																																							case 10:
																																								goto IL_10d6;
																																							case 120:
																																							case 537:
																																								goto IL_10e9;
																																							case 208:
																																								goto IL_10f7;
																																							case 476:
																																								goto IL_1115;
																																							case 485:
																																								goto IL_1123;
																																							case 157:
																																							case 553:
																																								goto IL_1136;
																																							case 344:
																																								goto IL_114f;
																																							case 562:
																																								goto IL_1162;
																																							case 430:
																																								goto IL_1176;
																																							case 347:
																																							case 571:
																																								goto IL_1189;
																																							case 166:
																																								goto IL_11b2;
																																							case 337:
																																								goto IL_11c9;
																																							case 574:
																																								goto IL_11dc;
																																							case 253:
																																							case 584:
																																								goto IL_11f5;
																																							case 251:
																																								goto IL_1209;
																																							case 302:
																																								goto IL_1241;
																																							case 591:
																																								goto IL_1254;
																																							case 116:
																																							case 159:
																																								goto IL_1262;
																																							case 554:
																																								goto IL_126c;
																																							case 472:
																																								goto IL_127a;
																																							case 598:
																																								goto IL_128d;
																																							case 162:
																																							case 588:
																																								goto IL_129b;
																																							case 42:
																																								goto IL_12b8;
																																							case 213:
																																								goto IL_12f7;
																																							case 605:
																																								goto IL_130a;
																																							case 71:
																																								goto IL_1318;
																																							case 2:
																																								goto IL_1326;
																																							case 268:
																																								goto IL_1334;
																																							case 203:
																																								goto IL_133f;
																																							case 204:
																																							case 310:
																																								goto IL_134d;
																																							case 492:
																																								goto IL_1370;
																																							case 296:
																																								goto IL_137e;
																																							case 497:
																																								goto IL_138c;
																																							case 583:
																																								goto IL_139f;
																																							case 305:
																																								goto IL_13ad;
																																							case 73:
																																							case 546:
																																								goto IL_13bb;
																																							case 428:
																																								goto IL_13d4;
																																							case 349:
																																								goto IL_13df;
																																							case 115:
																																								goto IL_13ed;
																																							case 64:
																																							case 471:
																																								goto IL_13fb;
																																							case 139:
																																								goto IL_140f;
																																							case 70:
																																								goto IL_1447;
																																							case 161:
																																							case 260:
																																								goto IL_145a;
																																							case 435:
																																								goto IL_146e;
																																							case 138:
																																								goto IL_14ab;
																																							case 299:
																																							case 496:
																																								goto IL_14c7;
																																							case 534:
																																								goto IL_14db;
																																							case 390:
																																								goto IL_1518;
																																							case 606:
																																								goto IL_152b;
																																							case 77:
																																							case 107:
																																								goto IL_1536;
																																							case 36:
																																								goto IL_154f;
																																							case 366:
																																								goto IL_1562;
																																							case 126:
																																								goto IL_1570;
																																							case 39:
																																							case 290:
																																								goto IL_157b;
																																							case 99:
																																								goto IL_1594;
																																							case 525:
																																								goto IL_15ab;
																																							case 58:
																																							case 224:
																																								goto IL_15c2;
																																							case 444:
																																								goto IL_15df;
																																							case 144:
																																								goto IL_161c;
																																							case 388:
																																								goto IL_1638;
																																							case 155:
																																								goto IL_1643;
																																							case 254:
																																							case 561:
																																								goto IL_1651;
																																							case 20:
																																								goto IL_1674;
																																							case 521:
																																								goto IL_1682;
																																							case 394:
																																								goto IL_1690;
																																							case 528:
																																								goto IL_16ac;
																																							case 593:
																																								goto IL_16ba;
																																							case 273:
																																							case 501:
																																								goto IL_16c8;
																																							case 283:
																																								goto IL_16dc;
																																							case 498:
																																								goto IL_172d;
																																							case 563:
																																								goto IL_173b;
																																							case 609:
																																								goto IL_174e;
																																							case 249:
																																							case 393:
																																								goto IL_1759;
																																							case 243:
																																								goto IL_1777;
																																							case 580:
																																								goto IL_1785;
																																							case 48:
																																								goto IL_1793;
																																							case 164:
																																								goto IL_17a6;
																																							case 49:
																																								goto IL_17b4;
																																							case 324:
																																							case 484:
																																								goto IL_17bf;
																																							case 382:
																																								goto IL_17f7;
																																							case 23:
																																								goto IL_180b;
																																							case 242:
																																								goto IL_181e;
																																							case 294:
																																								goto IL_182c;
																																							case 320:
																																							case 495:
																																								goto IL_183a;
																																							case 463:
																																								goto IL_1848;
																																							case 603:
																																								goto IL_1866;
																																							case 442:
																																								goto IL_1874;
																																							case 291:
																																								goto IL_1887;
																																							case 601:
																																								goto IL_1895;
																																							case 272:
																																							case 436:
																																								goto IL_18a3;
																																							case 589:
																																								goto IL_18ea;
																																							case 512:
																																								goto IL_18f8;
																																							case 140:
																																							case 614:
																																								goto IL_1914;
																																							case 193:
																																								goto IL_1937;
																																							case 28:
																																								goto IL_1945;
																																							case 326:
																																								goto IL_1953;
																																							case 616:
																																								goto IL_1966;
																																							case 541:
																																								goto IL_197d;
																																							case 618:
																																								goto IL_1990;
																																							case 508:
																																								goto IL_19e1;
																																							case 76:
																																								goto IL_19ef;
																																							case 621:
																																								goto IL_1a0b;
																																							case 622:
																																								goto IL_1a1e;
																																							case 102:
																																								goto IL_1a5b;
																																							case 625:
																																								goto IL_1a6e;
																																							case 457:
																																								goto IL_1a7c;
																																							case 321:
																																							case 533:
																																								goto IL_1a87;
																																							case 117:
																																								goto IL_1a9b;
																																							case 151:
																																								goto IL_1ada;
																																							case 103:
																																								goto IL_1af6;
																																							case 454:
																																								goto IL_1b04;
																																							case 111:
																																							case 323:
																																								goto IL_1b12;
																																							case 342:
																																								goto IL_1b2b;
																																							case 237:
																																								goto IL_1b3e;
																																							case 373:
																																								goto IL_1b49;
																																							case 322:
																																							case 351:
																																								goto IL_1b57;
																																							case 270:
																																								goto IL_1b8f;
																																							case 189:
																																								goto IL_1ba3;
																																							case 125:
																																								goto IL_1bb6;
																																							case 370:
																																								goto IL_1bc4;
																																							case 197:
																																							case 222:
																																								goto IL_1bd2;
																																							case 325:
																																								goto IL_1c0a;
																																							case 145:
																																								goto IL_1c1e;
																																							case 505:
																																								goto IL_1c31;
																																							case 522:
																																								goto IL_1c3f;
																																							case 33:
																																								goto IL_1c52;
																																							case 124:
																																							case 400:
																																								goto IL_1c5d;
																																							case 38:
																																								goto IL_1c79;
																																							case 72:
																																								goto IL_1c87;
																																							case 398:
																																							case 578:
																																								goto IL_1c92;
																																							case 348:
																																								goto IL_1caf;
																																							case 240:
																																								goto IL_1ce7;
																																							case 600:
																																								goto IL_1cfa;
																																							case 187:
																																								goto IL_1d08;
																																							case 235:
																																								goto IL_1d16;
																																							case 401:
																																								goto IL_1d24;
																																							case 232:
																																								goto IL_1d32;
																																							case 123:
																																							case 540:
																																								goto IL_1d40;
																																							case 198:
																																								goto IL_1d54;
																																							case 83:
																																								goto IL_1da8;
																																							case 333:
																																								goto IL_1db6;
																																							case 239:
																																								goto IL_1dc9;
																																							case 8:
																																								goto IL_1dd7;
																																							case 31:
																																							case 132:
																																								goto IL_1de5;
																																							case 568:
																																								goto IL_1e47;
																																							case 405:
																																								goto IL_1e5a;
																																							case 570:
																																								goto IL_1e65;
																																							case 380:
																																								goto IL_1e78;
																																							case 617:
																																								goto IL_1e86;
																																							case 364:
																																							case 406:
																																								goto IL_1e94;
																																							case 451:
																																								goto IL_1f4b;
																																							case 131:
																																								goto IL_1f59;
																																							case 215:
																																							case 410:
																																								goto IL_1f6c;
																																							case 519:
																																								goto IL_1f93;
																																							case 586:
																																								goto IL_1fa1;
																																							case 81:
																																								goto IL_1fb4;
																																							case 474:
																																								goto IL_1fc2;
																																							case 29:
																																							case 363:
																																								goto IL_1fd0;
																																							case 267:
																																								goto IL_1fe8;
																																							case 86:
																																								goto IL_2006;
																																							case 375:
																																								goto IL_202a;
																																							case 491:
																																								goto IL_2042;
																																							case 178:
																																								goto IL_2055;
																																							case 445:
																																								goto IL_2063;
																																							case 147:
																																							case 292:
																																								goto IL_2071;
																																							case 5:
																																								goto IL_209a;
																																							case 285:
																																								goto IL_20b3;
																																							case 520:
																																								goto IL_20be;
																																							case 314:
																																							case 510:
																																								goto IL_20cc;
																																							case 576:
																																								goto IL_20da;
																																							case 420:
																																								goto IL_20f2;
																																							case 585:
																																								goto IL_2109;
																																							case 74:
																																								goto IL_211c;
																																							case 365:
																																								goto IL_212a;
																																							case 112:
																																							case 200:
																																								goto IL_2138;
																																							case 532:
																																								goto IL_2176;
																																							case 488:
																																								goto IL_2192;
																																							case 154:
																																								goto IL_21a0;
																																							case 150:
																																								goto IL_21ae;
																																							case 623:
																																								goto IL_21bc;
																																							case 148:
																																							case 421:
																																								goto IL_21c7;
																																							case 590:
																																								goto IL_2207;
																																							case 458:
																																								goto IL_2224;
																																							case 121:
																																								goto IL_2237;
																																							case 108:
																																								goto IL_2245;
																																							case 68:
																																							case 558:
																																								goto IL_2253;
																																							case 422:
																																								goto IL_2293;
																																							case 529:
																																								goto IL_22a7;
																																							case 582:
																																								goto IL_22ba;
																																							case 565:
																																								goto IL_22c5;
																																							case 278:
																																								goto IL_22d3;
																																							case 153:
																																							case 359:
																																								goto IL_22e1;
																																							case 25:
																																								goto IL_22fd;
																																							case 109:
																																							case 173:
																																								goto IL_230b;
																																							case 395:
																																								goto IL_2354;
																																							case 408:
																																								goto IL_2371;
																																							case 627:
																																								goto IL_238d;
																																							case 446:
																																							case 475:
																																								goto IL_2398;
																																							case 318:
																																								goto IL_23a6;
																																							case 279:
																																								goto IL_23c9;
																																							case 216:
																																								goto IL_23d3;
																																							case 557:
																																								goto IL_23e1;
																																							case 466:
																																								goto IL_23f4;
																																							case 367:
																																								goto IL_2402;
																																							case 536:
																																								goto IL_240d;
																																							case 500:
																																								goto IL_241b;
																																							case 376:
																																							case 599:
																																								goto IL_2429;
																																							case 9:
																																								goto IL_2442;
																																							case 573:
																																								goto IL_2450;
																																							case 345:
																																								goto IL_245e;
																																							case 186:
																																							case 518:
																																								goto IL_2471;
																																							case 263:
																																								goto IL_24b1;
																																							case 340:
																																								goto IL_24c5;
																																							case 339:
																																								goto IL_24e1;
																																							case 135:
																																								goto IL_24ef;
																																							case 217:
																																							case 441:
																																								goto IL_24fd;
																																							case 184:
																																								goto IL_2526;
																																							case 572:
																																								goto IL_2534;
																																							case 459:
																																							case 493:
																																								goto IL_2547;
																																							case 612:
																																								goto IL_2587;
																																							case 566:
																																								goto IL_259b;
																																							case 93:
																																								goto IL_25b7;
																																							case 419:
																																								goto IL_25c5;
																																							case 22:
																																								goto IL_25d3;
																																							case 163:
																																								goto IL_25e1;
																																							case 105:
																																							case 346:
																																								goto IL_25ec;
																																							case 502:
																																								goto IL_263e;
																																							case 482:
																																								goto IL_2651;
																																							case 246:
																																								goto IL_265f;
																																							case 80:
																																							case 517:
																																								goto IL_266a;
																																							case 499:
																																								goto IL_2682;
																																							case 620:
																																								goto IL_2690;
																																							case 91:
																																							case 453:
																																								goto IL_269e;
																																							case 219:
																																								goto IL_26b7;
																																							case 110:
																																								goto IL_26c5;
																																							case 447:
																																								goto IL_26d3;
																																							case 179:
																																								goto IL_26e6;
																																							case 379:
																																								goto IL_26f4;
																																							case 141:
																																							case 248:
																																								goto IL_2702;
																																							case 60:
																																								goto IL_2743;
																																							case 503:
																																								goto IL_2757;
																																							case 516:
																																								goto IL_276a;
																																							case 221:
																																								goto IL_2778;
																																							case 233:
																																							case 236:
																																								goto IL_2783;
																																							case 456:
																																								goto IL_27c1;
																																							case 507:
																																								goto IL_27d5;
																																							case 295:
																																								goto IL_27e8;
																																							case 626:
																																								goto IL_27f6;
																																							case 35:
																																							case 369:
																																								goto IL_2804;
																																							case 181:
																																								goto IL_2827;
																																							case 437:
																																								goto IL_2835;
																																							case 306:
																																								goto IL_2843;
																																							case 266:
																																								goto IL_2856;
																																							case 383:
																																								goto IL_2861;
																																							case 245:
																																							case 276:
																																								goto IL_286f;
																																							case 143:
																																								goto IL_28cd;
																																							case 214:
																																								goto IL_28e0;
																																							case 106:
																																								goto IL_28ee;
																																							case 308:
																																							case 560:
																																								goto IL_28fc;
																																							case 146:
																																								goto IL_2915;
																																							case 538:
																																								goto IL_2923;
																																							case 53:
																																								goto IL_293a;
																																							case 417:
																																							case 564:
																																								goto IL_294d;
																																							case 608:
																																								goto IL_2961;
																																							case 341:
																																								goto IL_29a0;
																																							case 269:
																																								goto IL_29b3;
																																							case 384:
																																								goto IL_29c1;
																																							case 133:
																																								goto IL_29cf;
																																							case 343:
																																								goto IL_29dd;
																																							case 307:
																																							case 559:
																																								goto IL_29e8;
																																							case 238:
																																								goto IL_29fc;
																																							case 479:
																																								goto IL_2a3b;
																																							case 316:
																																								goto IL_2a4e;
																																							case 210:
																																								goto IL_2a5c;
																																							case 175:
																																							case 281:
																																								goto IL_2a6a;
																																							case 67:
																																								goto IL_2aaa;
																																							case 223:
																																								goto IL_2abe;
																																							case 297:
																																								goto IL_2ad1;
																																							case 494:
																																								goto IL_2adc;
																																							case 63:
																																							case 523:
																																								goto IL_2aea;
																																							case 41:
																																								goto IL_2b22;
																																							case 226:
																																								goto IL_2b36;
																																							case 152:
																																								goto IL_2b49;
																																							case 407:
																																								goto IL_2b60;
																																							case 51:
																																							case 234:
																																								goto IL_2b6e;
																																							case 227:
																																								goto IL_2bb6;
																																							case 425:
																																							case 619:
																																								goto IL_2bc9;
																																							case 489:
																																								goto IL_2c09;
																																							case 352:
																																								goto IL_2c1d;
																																							case 182:
																																								goto IL_2c30;
																																							case 218:
																																								goto IL_2c3e;
																																							case 211:
																																								goto IL_2c49;
																																							case 169:
																																								goto IL_2c57;
																																							case 69:
																																							case 286:
																																								goto IL_2c6e;
																																							case 461:
																																								goto IL_2c88;
																																							case 304:
																																								goto IL_2c96;
																																							case 309:
																																								goto IL_2cad;
																																							case 172:
																																							case 555:
																																								goto IL_2cc0;
																																							case 412:
																																								goto IL_2cd4;
																																							case 114:
																																								goto IL_2d65;
																																							case 381:
																																								goto IL_2d73;
																																							case 424:
																																								goto IL_2d86;
																																							case 127:
																																								goto IL_2d91;
																																							case 168:
																																							case 327:
																																								goto IL_2d9f;
																																							case 113:
																																								goto IL_2db8;
																																							case 480:
																																								goto IL_2dcb;
																																							case 98:
																																								goto IL_2dd6;
																																							case 357:
																																							case 575:
																																								goto IL_2de1;
																																							case 483:
																																								goto IL_2df5;
																																							case 336:
																																								goto IL_2e34;
																																							case 0:
																																							case 1:
																																							case 3:
																																							case 11:
																																							case 14:
																																							case 15:
																																							case 26:
																																							case 46:
																																							case 55:
																																							case 57:
																																							case 62:
																																							case 65:
																																							case 95:
																																							case 100:
																																							case 101:
																																							case 104:
																																							case 129:
																																							case 134:
																																							case 149:
																																							case 158:
																																							case 160:
																																							case 165:
																																							case 180:
																																							case 190:
																																							case 196:
																																							case 199:
																																							case 205:
																																							case 206:
																																							case 207:
																																							case 231:
																																							case 244:
																																							case 247:
																																							case 257:
																																							case 258:
																																							case 259:
																																							case 271:
																																							case 280:
																																							case 282:
																																							case 287:
																																							case 289:
																																							case 293:
																																							case 301:
																																							case 311:
																																							case 334:
																																							case 350:
																																							case 355:
																																							case 358:
																																							case 360:
																																							case 371:
																																							case 372:
																																							case 385:
																																							case 399:
																																							case 409:
																																							case 414:
																																							case 429:
																																							case 433:
																																							case 438:
																																							case 450:
																																							case 460:
																																							case 464:
																																							case 467:
																																							case 468:
																																							case 469:
																																							case 473:
																																							case 490:
																																							case 513:
																																							case 524:
																																							case 531:
																																							case 535:
																																							case 539:
																																							case 543:
																																							case 544:
																																							case 552:
																																							case 567:
																																							case 577:
																																							case 602:
																																							case 607:
																																							case 610:
																																							case 613:
																																								goto end_IL_0a6d;
																																							case 4:
																																							case 6:
																																							case 19:
																																							case 27:
																																							case 32:
																																							case 34:
																																							case 43:
																																							case 45:
																																							case 52:
																																							case 66:
																																							case 87:
																																							case 90:
																																							case 94:
																																							case 97:
																																							case 118:
																																							case 122:
																																							case 128:
																																							case 130:
																																							case 136:
																																							case 142:
																																							case 167:
																																							case 171:
																																							case 176:
																																							case 185:
																																							case 201:
																																							case 202:
																																							case 209:
																																							case 220:
																																							case 230:
																																							case 252:
																																							case 255:
																																							case 256:
																																							case 274:
																																							case 277:
																																							case 300:
																																							case 303:
																																							case 329:
																																							case 335:
																																							case 338:
																																							case 353:
																																							case 377:
																																							case 378:
																																							case 387:
																																							case 389:
																																							case 391:
																																							case 396:
																																							case 402:
																																							case 403:
																																							case 415:
																																							case 416:
																																							case 423:
																																							case 426:
																																							case 427:
																																							case 431:
																																							case 434:
																																							case 448:
																																							case 470:
																																							case 477:
																																							case 487:
																																							case 506:
																																							case 515:
																																							case 526:
																																							case 542:
																																							case 545:
																																							case 547:
																																							case 548:
																																							case 550:
																																							case 551:
																																							case 556:
																																							case 569:
																																							case 579:
																																							case 594:
																																							case 595:
																																							case 597:
																																							case 604:
																																							case 611:
																																							case 624:
																																							case 628:
																																								goto end_IL_09fb;
																																							case 59:
																																								goto IL_2e6a;
																																							case 177:
																																								goto IL_2e74;
																																							case 7:
																																								goto IL_2e7f;
																																							case 330:
																																								goto IL_2e8f;
																																							case 315:
																																								goto IL_2e9f;
																																							case 195:
																																								goto IL_2eaf;
																																							case 362:
																																								goto IL_2ebf;
																																							case 511:
																																								goto IL_2ecf;
																																							case 587:
																																								goto IL_2edf;
																																							case 596:
																																								goto IL_2ef8;
																																							case 228:
																																								goto IL_2f08;
																																							case 37:
																																							case 331:
																																								return;
																																							}
																																							goto end_IL_2e57;
																																							continue;
																																							end_IL_09fb:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_0aea;
																																		continue;
																																		end_IL_0a6d:
																																		break;
																																		IL_0a6d:;
																																	}
																																	break;
																																}
																																goto IL_1c31;
																																IL_1c3f:
																																if (76 > b)
																																{
																																}
																																break;
																																IL_1c31:
																																if (76 < b)
																																{
																																	break;
																																}
																																goto IL_1c3f;
																															}
																															break;
																														}
																														goto IL_0b15;
																														IL_0b67:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_0ba6;
																														IL_0b15:
																														if (74 > b)
																														{
																															goto IL_0b2e;
																														}
																														num = 347;
																														goto IL_1189;
																														IL_0ba6:
																														ptr2 += 8;
																														goto end_IL_0aea;
																														IL_1189:
																														((delegate*<string, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																														goto IL_11b2;
																														IL_11b2:
																														num6--;
																														num = 337;
																														goto IL_11c9;
																														IL_11c9:
																														ptr2 += 8;
																														goto end_IL_0aea;
																														IL_0b2e:
																														if (73 < b)
																														{
																															break;
																														}
																														goto IL_0b3c;
																														IL_0b3c:
																														if (73 > b)
																														{
																															break;
																														}
																														goto IL_0b4a;
																														IL_0b4a:
																														array2[num6 - 1] = 3;
																														num = 30;
																														goto IL_0b67;
																													}
																													break;
																												}
																												goto IL_152b;
																												IL_16dc:
																												array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																												goto IL_172d;
																												IL_152b:
																												if (72 <= b)
																												{
																													goto IL_1536;
																												}
																												goto IL_1562;
																												IL_1536:
																												global::_003CModule_003E.quaternion_7 = (Quaternion)array3[num6 - 1];
																												goto IL_154f;
																												IL_154f:
																												num6--;
																												goto end_IL_0aea;
																												IL_1562:
																												if (69 >= b)
																												{
																													goto IL_1570;
																												}
																												goto IL_1638;
																												IL_1570:
																												if (69 <= b)
																												{
																													goto IL_157b;
																												}
																												goto IL_1594;
																												IL_157b:
																												array2[num6 - 1] = 4;
																												goto IL_1a1e;
																												IL_1a1e:
																												array3[num6 - 1] = ((delegate*<Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 1]);
																												goto IL_1a5b;
																												IL_1a5b:
																												ptr2 += 8;
																												goto end_IL_0aea;
																												IL_1594:
																												if (68 < b)
																												{
																													break;
																												}
																												num = 525;
																												goto IL_15ab;
																												IL_172d:
																												num6--;
																												goto IL_173b;
																												IL_15ab:
																												if (68 > b)
																												{
																													break;
																												}
																												num = 58;
																												goto IL_15c2;
																												IL_173b:
																												ptr2 += 8;
																												goto end_IL_0aea;
																												IL_15c2:
																												array2[num6 - 1] = 4;
																												num = 444;
																												goto IL_15df;
																												IL_15df:
																												array3[num6 - 1] = ((delegate*<Transform, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																												goto IL_161c;
																												IL_161c:
																												ptr2 += 8;
																												num = 448;
																												goto end_IL_0aea;
																												IL_1638:
																												if (70 >= b)
																												{
																													goto IL_1643;
																												}
																												goto IL_16ac;
																												IL_1643:
																												if (70 > b)
																												{
																													break;
																												}
																												goto IL_1651;
																												IL_1651:
																												array3[num6] = ((delegate*<Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																												goto IL_1674;
																												IL_1674:
																												array2[num6] = 4;
																												goto IL_1682;
																												IL_1682:
																												num6++;
																												goto IL_1690;
																												IL_1690:
																												ptr2 += 8;
																												num = 487;
																												goto end_IL_0aea;
																												IL_16ac:
																												if (71 < b)
																												{
																													break;
																												}
																												goto IL_16ba;
																												IL_16ba:
																												if (71 > b)
																												{
																													break;
																												}
																												goto IL_16c8;
																												IL_16c8:
																												array2[num6 - 2] = 4;
																												goto IL_16dc;
																											}
																											break;
																										}
																										goto IL_0bb9;
																										IL_12f7:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_0bb9:
																										if (67 > b)
																										{
																											goto IL_0bc4;
																										}
																										goto IL_0bfe;
																										IL_0bc4:
																										if (62 >= b)
																										{
																											goto IL_0bd2;
																										}
																										goto IL_0ea4;
																										IL_0bd2:
																										if (62 <= b)
																										{
																											goto IL_0be0;
																										}
																										goto IL_0f99;
																										IL_0be0:
																										global::_003CModule_003E.vector3_151 = (Vector3)array3[num6 - 1];
																										goto IL_1a0b;
																										IL_1a0b:
																										num6--;
																										goto end_IL_0aea;
																										IL_0f99:
																										if (59 >= b)
																										{
																											goto IL_0fa7;
																										}
																										goto IL_1049;
																										IL_0fa7:
																										if (59 > b)
																										{
																											goto IL_0fb5;
																										}
																										goto IL_11f5;
																										IL_0fb5:
																										if (58 < b)
																										{
																											break;
																										}
																										num = 486;
																										goto IL_0fcc;
																										IL_0bfe:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										num = 79;
																										goto IL_0c32;
																										IL_0fcc:
																										if (58 > b)
																										{
																											break;
																										}
																										goto IL_0fda;
																										IL_0fda:
																										array2[num6 - 1] = 3;
																										num = 452;
																										goto IL_0ff7;
																										IL_0ff7:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_1036;
																										IL_1036:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_11f5:
																										array2[num6 - 1] = 5;
																										goto IL_1209;
																										IL_1209:
																										array3[num6 - 1] = ((delegate*<Player, VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
																										goto IL_1241;
																										IL_1241:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_1049:
																										if (60 >= b)
																										{
																											goto IL_1054;
																										}
																										goto IL_1067;
																										IL_1054:
																										if (60 > b)
																										{
																											break;
																										}
																										goto IL_1136;
																										IL_1136:
																										global::_003CModule_003E.v_003CbUQdVVYR = (VRRig)array3[num6 - 1];
																										goto IL_114f;
																										IL_114f:
																										num6--;
																										goto end_IL_0aea;
																										IL_1067:
																										if (61 < b)
																										{
																											break;
																										}
																										goto IL_1075;
																										IL_1075:
																										if (61 > b)
																										{
																											break;
																										}
																										goto IL_1083;
																										IL_1083:
																										array2[num6 - 1] = 3;
																										goto IL_1097;
																										IL_1097:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_10d6;
																										IL_10d6:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_0ea4:
																										if (64 >= b)
																										{
																											goto IL_0eaf;
																										}
																										goto IL_0f23;
																										IL_0eaf:
																										if (64 <= b)
																										{
																											goto IL_0ebd;
																										}
																										goto IL_11dc;
																										IL_0ebd:
																										array2[num6 - 2] = 0;
																										goto IL_0ed1;
																										IL_0ed1:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																										goto IL_1966;
																										IL_1966:
																										num6--;
																										num = 541;
																										goto IL_197d;
																										IL_197d:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_11dc:
																										if (63 < b)
																										{
																											break;
																										}
																										num = 591;
																										goto IL_1254;
																										IL_0c32:
																										array2[num6 - 1] = 0;
																										goto end_IL_0aea;
																										IL_1254:
																										if (63 > b)
																										{
																											break;
																										}
																										goto IL_1262;
																										IL_1262:
																										array3[num6] = null;
																										goto IL_126c;
																										IL_126c:
																										array2[num6] = 5;
																										goto IL_127a;
																										IL_127a:
																										num6++;
																										goto end_IL_0aea;
																										IL_0f23:
																										if (65 < b)
																										{
																											goto IL_0f31;
																										}
																										goto IL_128d;
																										IL_0f31:
																										if (66 < b)
																										{
																											break;
																										}
																										goto IL_0f3f;
																										IL_0f3f:
																										if (66 > b)
																										{
																											break;
																										}
																										goto IL_0f4d;
																										IL_0f4d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																										num = 562;
																										goto IL_1162;
																										IL_1162:
																										array2[num6 - 1] = 0;
																										goto IL_1176;
																										IL_1176:
																										ptr2 += 8;
																										goto end_IL_0aea;
																										IL_128d:
																										if (65 > b)
																										{
																											break;
																										}
																										goto IL_129b;
																										IL_129b:
																										array2[num6 - 1] = 3;
																										num = 42;
																										goto IL_12b8;
																										IL_12b8:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_12f7;
																									}
																									break;
																								}
																								goto IL_0c4b;
																								IL_14db:
																								array3[num6 - 1] = ((delegate*<Vector3, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																								goto IL_1518;
																								IL_0c4b:
																								if (57 <= b)
																								{
																									goto IL_0c56;
																								}
																								goto IL_0cb4;
																								IL_0c56:
																								((delegate*<Transform, Quaternion, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																								goto IL_0c93;
																								IL_0c93:
																								num6 -= 2;
																								goto IL_0ca1;
																								IL_0ca1:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_0cb4:
																								if (47 < b)
																								{
																									goto IL_0cc2;
																								}
																								goto IL_130a;
																								IL_0cc2:
																								if (52 < b)
																								{
																									goto IL_0cd0;
																								}
																								num = 284;
																								goto IL_0e91;
																								IL_0cd0:
																								if (54 >= b)
																								{
																									goto IL_0cde;
																								}
																								goto IL_0dc8;
																								IL_0cde:
																								if (54 <= b)
																								{
																									goto IL_0ce9;
																								}
																								goto IL_0d4d;
																								IL_0ce9:
																								array2[num6 - 1] = 4;
																								goto IL_0cfd;
																								IL_0cfd:
																								array3[num6 - 1] = ((delegate*<Transform, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																								goto IL_0d3a;
																								IL_0d3a:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_0d4d:
																								if (53 < b)
																								{
																									break;
																								}
																								goto IL_0d5b;
																								IL_0d5b:
																								if (53 > b)
																								{
																									break;
																								}
																								goto IL_0d69;
																								IL_0d69:
																								array2[num6 - 1] = 5;
																								goto IL_0d7d;
																								IL_0d7d:
																								array3[num6 - 1] = ((delegate*<Component, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																								goto IL_0db5;
																								IL_0db5:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_0dc8:
																								if (55 >= b)
																								{
																									goto IL_0dd3;
																								}
																								goto IL_0de6;
																								IL_0dd3:
																								if (55 > b)
																								{
																									break;
																								}
																								goto IL_1914;
																								IL_1914:
																								array3[num6] = ((delegate*<Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																								goto IL_1937;
																								IL_1937:
																								array2[num6] = 4;
																								goto IL_1945;
																								IL_1945:
																								num6++;
																								goto IL_1953;
																								IL_1953:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_0de6:
																								if (56 < b)
																								{
																									break;
																								}
																								goto IL_0df4;
																								IL_0df4:
																								if (56 > b)
																								{
																									break;
																								}
																								goto IL_0e02;
																								IL_0e02:
																								array2[num6 - 2] = 4;
																								goto IL_0e16;
																								IL_0e16:
																								array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																								goto IL_0e67;
																								IL_0e67:
																								num6--;
																								goto IL_0e75;
																								IL_0e75:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_1518:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_0e91:
																								if (52 <= b)
																								{
																									goto IL_10e9;
																								}
																								goto IL_1a6e;
																								IL_10e9:
																								array2[num6] = 5;
																								goto IL_10f7;
																								IL_10f7:
																								array3[num6] = ((delegate*<GorillaTagger>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																								goto IL_1115;
																								IL_1115:
																								num6++;
																								goto IL_1123;
																								IL_1123:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_1a6e:
																								if (49 >= b)
																								{
																									goto IL_1a7c;
																								}
																								goto IL_1b3e;
																								IL_1a7c:
																								if (49 <= b)
																								{
																									goto IL_1a87;
																								}
																								goto IL_1af6;
																								IL_1a87:
																								array2[num6 - 1] = 3;
																								goto IL_1a9b;
																								IL_1a9b:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1ada;
																								IL_1ada:
																								ptr2 += 8;
																								num = 32;
																								goto end_IL_0aea;
																								IL_1af6:
																								if (48 < b)
																								{
																									break;
																								}
																								goto IL_1b04;
																								IL_1b04:
																								if (48 > b)
																								{
																									break;
																								}
																								goto IL_1b12;
																								IL_1b12:
																								global::_003CModule_003E.quaternion_6 = (Quaternion)array3[num6 - 1];
																								goto IL_1b2b;
																								IL_1b2b:
																								num6--;
																								goto end_IL_0aea;
																								IL_1b3e:
																								if (50 >= b)
																								{
																									goto IL_1b49;
																								}
																								goto IL_1bb6;
																								IL_1b49:
																								if (50 > b)
																								{
																									break;
																								}
																								goto IL_1b57;
																								IL_1b57:
																								array3[num6 - 1] = ((delegate*<VRRig, VRMap>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																								goto IL_1b8f;
																								IL_1b8f:
																								array2[num6 - 1] = 5;
																								goto IL_1ba3;
																								IL_1ba3:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_1bb6:
																								if (51 < b)
																								{
																									break;
																								}
																								goto IL_1bc4;
																								IL_1bc4:
																								if (51 > b)
																								{
																									break;
																								}
																								goto IL_1bd2;
																								IL_1bd2:
																								array3[num6 - 1] = ((delegate*<VRMap, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRMap)array3[num6 - 1]);
																								goto IL_1c0a;
																								IL_1c0a:
																								array2[num6 - 1] = 5;
																								goto IL_1c1e;
																								IL_1c1e:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_130a:
																								if (47 > b)
																								{
																									goto IL_1318;
																								}
																								goto IL_14c7;
																								IL_1318:
																								if (42 < b)
																								{
																									goto IL_1326;
																								}
																								goto IL_174e;
																								IL_1326:
																								if (44 < b)
																								{
																									goto IL_1334;
																								}
																								goto IL_13d4;
																								IL_1334:
																								if (45 >= b)
																								{
																									goto IL_133f;
																								}
																								goto IL_139f;
																								IL_133f:
																								if (45 > b)
																								{
																									break;
																								}
																								goto IL_134d;
																								IL_134d:
																								array3[num6] = ((delegate*<Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																								goto IL_1370;
																								IL_1370:
																								array2[num6] = 4;
																								goto IL_137e;
																								IL_137e:
																								num6++;
																								goto IL_138c;
																								IL_138c:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_139f:
																								if (46 < b)
																								{
																									break;
																								}
																								goto IL_13ad;
																								IL_13ad:
																								if (46 > b)
																								{
																									break;
																								}
																								goto IL_13bb;
																								IL_13bb:
																								array2[num6 - 2] = 4;
																								goto IL_1990;
																								IL_1990:
																								array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																								goto IL_19e1;
																								IL_19e1:
																								num6--;
																								goto IL_19ef;
																								IL_19ef:
																								ptr2 += 8;
																								num = 19;
																								goto end_IL_0aea;
																								IL_13d4:
																								if (44 > b)
																								{
																									goto IL_13df;
																								}
																								goto IL_145a;
																								IL_13df:
																								if (43 < b)
																								{
																									break;
																								}
																								goto IL_13ed;
																								IL_13ed:
																								if (43 > b)
																								{
																									break;
																								}
																								goto IL_13fb;
																								IL_13fb:
																								array2[num6 - 1] = 5;
																								goto IL_140f;
																								IL_140f:
																								array3[num6 - 1] = ((delegate*<Component, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																								goto IL_1447;
																								IL_1447:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_145a:
																								array2[num6 - 1] = 4;
																								goto IL_146e;
																								IL_146e:
																								array3[num6 - 1] = ((delegate*<Transform, Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																								goto IL_14ab;
																								IL_14ab:
																								ptr2 += 8;
																								num = 378;
																								goto end_IL_0aea;
																								IL_174e:
																								if (42 <= b)
																								{
																									goto IL_1759;
																								}
																								goto IL_17a6;
																								IL_1759:
																								array3[num6] = ((delegate*<VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																								goto IL_1777;
																								IL_1777:
																								array2[num6] = 5;
																								goto IL_1785;
																								IL_1785:
																								num6++;
																								goto IL_1793;
																								IL_1793:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_17a6:
																								if (40 >= b)
																								{
																									goto IL_17b4;
																								}
																								goto IL_1887;
																								IL_17b4:
																								if (40 <= b)
																								{
																									goto IL_17bf;
																								}
																								goto IL_181e;
																								IL_17bf:
																								array3[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																								goto IL_17f7;
																								IL_17f7:
																								array2[num6 - 1] = 5;
																								goto IL_180b;
																								IL_180b:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_181e:
																								if (39 < b)
																								{
																									break;
																								}
																								goto IL_182c;
																								IL_182c:
																								if (39 > b)
																								{
																									break;
																								}
																								goto IL_183a;
																								IL_183a:
																								array2[num6] = 5;
																								goto IL_1848;
																								IL_1848:
																								array3[num6] = ((delegate*<GorillaTagger>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																								goto IL_1866;
																								IL_1866:
																								num6++;
																								goto IL_1874;
																								IL_1874:
																								ptr2 += 8;
																								goto end_IL_0aea;
																								IL_1887:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_1895;
																								IL_1895:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_18a3;
																								IL_18a3:
																								((delegate*<Behaviour, bool, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																								num = 589;
																								goto IL_18ea;
																								IL_18ea:
																								num6 -= 2;
																								goto IL_18f8;
																								IL_18f8:
																								ptr2 += 8;
																								num = 4;
																								goto end_IL_0aea;
																								IL_14c7:
																								array2[num6 - 1] = 4;
																								goto IL_14db;
																							}
																							break;
																						}
																						goto IL_1c52;
																						IL_2d86:
																						if (36 >= b)
																						{
																							goto IL_2d91;
																						}
																						goto IL_2dcb;
																						IL_1c52:
																						if (38 <= b)
																						{
																							goto IL_1c5d;
																						}
																						goto IL_1c79;
																						IL_1c5d:
																						num7 = ptr2;
																						num8 = -200;
																						num5 = 1;
																						ptr2 = num7 + num8;
																						goto end_IL_0aea;
																						IL_1c79:
																						if (19 >= b)
																						{
																							goto IL_1c87;
																						}
																						goto IL_25b7;
																						IL_1c87:
																						if (19 <= b)
																						{
																							goto IL_1c92;
																						}
																						goto IL_1cfa;
																						IL_1c92:
																						array2[num6 - 1] = 5;
																						num = 348;
																						goto IL_1caf;
																						IL_1caf:
																						array3[num6 - 1] = ((delegate*<string[], string>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_1ce7;
																						IL_1ce7:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_1cfa:
																						if (9 < b)
																						{
																							goto IL_1d08;
																						}
																						num = 488;
																						goto IL_2192;
																						IL_1d08:
																						if (14 >= b)
																						{
																							goto IL_1d16;
																						}
																						goto IL_1fb4;
																						IL_1d16:
																						if (14 > b)
																						{
																							goto IL_1d24;
																						}
																						goto IL_1f6c;
																						IL_1d24:
																						if (11 >= b)
																						{
																							goto IL_1d32;
																						}
																						goto IL_1e5a;
																						IL_1d32:
																						if (11 <= b)
																						{
																							goto IL_1d40;
																						}
																						goto IL_1dc9;
																						IL_1d40:
																						array2[num6 - 2] = 0;
																						goto IL_1d54;
																						IL_1d54:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1da8;
																						IL_1da8:
																						num6--;
																						goto IL_1db6;
																						IL_1db6:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_1dc9:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_1dd7;
																						IL_1dd7:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_1de5;
																						IL_1de5:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1e47;
																						IL_1e47:
																						num6 -= 2;
																						goto end_IL_0aea;
																						IL_1e5a:
																						if (12 >= b)
																						{
																							goto IL_1e65;
																						}
																						goto IL_1e78;
																						IL_1e65:
																						if (12 > b)
																						{
																							break;
																						}
																						goto end_IL_0aea;
																						IL_1e78:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_1e86;
																						IL_1e86:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_1e94;
																						IL_1e94:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_1ea3;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_1f4b;
																						IL_2d9f:
																						global::_003CModule_003E.gunResult_8 = (Class8.GunResult)array3[num6 - 1];
																						goto IL_2db8;
																						IL_2db8:
																						num6--;
																						goto end_IL_0aea;
																						IL_2dcb:
																						if (37 < b)
																						{
																							break;
																						}
																						goto IL_2dd6;
																						IL_1f4b:
																						array2[num6] = 5;
																						goto IL_1f59;
																						IL_1f59:
																						num6++;
																						goto end_IL_0aea;
																						IL_1f6c:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						num = 519;
																						goto IL_1f93;
																						IL_1f93:
																						ptr2 += 8;
																						goto IL_1fa1;
																						IL_1fa1:
																						num6--;
																						goto end_IL_0aea;
																						IL_1fb4:
																						if (16 >= b)
																						{
																							goto IL_1fc2;
																						}
																						goto IL_20b3;
																						IL_1fc2:
																						if (16 <= b)
																						{
																							goto IL_1fd0;
																						}
																						goto IL_2055;
																						IL_1fd0:
																						array2[num6] = array2[num6 - 1];
																						goto IL_1fe8;
																						IL_1fe8:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_2006;
																						IL_2006:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_202a;
																						IL_202a:
																						array3[num6] = array3[num6 - 1];
																						goto IL_2042;
																						IL_2042:
																						num6++;
																						goto end_IL_0aea;
																						IL_2055:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_2063;
																						IL_2063:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_2071;
																						IL_2071:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_209a;
																						IL_209a:
																						array2[num6 - 1] = 5;
																						goto end_IL_0aea;
																						IL_20b3:
																						if (17 >= b)
																						{
																							goto IL_20be;
																						}
																						goto IL_211c;
																						IL_20be:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_20cc;
																						IL_20cc:
																						array2[num6] = 5;
																						goto IL_20da;
																						IL_20da:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_20f2;
																						IL_20f2:
																						num6++;
																						num = 585;
																						goto IL_2109;
																						IL_2109:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_211c:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_212a;
																						IL_212a:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_2138;
																						IL_2138:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_2176;
																						IL_2176:
																						num6 -= 3;
																						goto end_IL_0aea;
																						IL_2d91:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_2d9f;
																						IL_2192:
																						if (9 > b)
																						{
																							goto IL_21a0;
																						}
																						goto IL_2547;
																						IL_21a0:
																						if (4 < b)
																						{
																							goto IL_21ae;
																						}
																						num = 627;
																						goto IL_238d;
																						IL_21ae:
																						if (6 >= b)
																						{
																							goto IL_21bc;
																						}
																						goto IL_22ba;
																						IL_21bc:
																						if (6 <= b)
																						{
																							goto IL_21c7;
																						}
																						goto IL_2237;
																						IL_21c7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2207;
																						IL_2207:
																						array2[num6 - 2] = 0;
																						num = 458;
																						goto IL_2224;
																						IL_2224:
																						num6--;
																						goto end_IL_0aea;
																						IL_2237:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_2245;
																						IL_2245:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_2253;
																						IL_2253:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2293;
																						IL_2293:
																						array2[num6 - 2] = 0;
																						goto IL_22a7;
																						IL_22a7:
																						num6--;
																						goto end_IL_0aea;
																						IL_22ba:
																						if (7 < b)
																						{
																							goto IL_22c5;
																						}
																						num = 25;
																						goto IL_22fd;
																						IL_22c5:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_22d3;
																						IL_22d3:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_22e1;
																						IL_22e1:
																						num6--;
																						goto end_IL_0aea;
																						IL_2de1:
																						array2[num6 - 1] = 3;
																						goto IL_2df5;
																						IL_22fd:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_230b;
																						IL_230b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 395;
																						goto IL_2354;
																						IL_2354:
																						array2[num6 - 2] = 0;
																						num = 408;
																						goto IL_2371;
																						IL_2371:
																						num6--;
																						goto end_IL_0aea;
																						IL_2dd6:
																						if (37 > b)
																						{
																							break;
																						}
																						goto IL_2de1;
																						IL_238d:
																						if (4 <= b)
																						{
																							goto IL_2398;
																						}
																						goto IL_23f4;
																						IL_2398:
																						array2[num6] = 0;
																						goto IL_23a6;
																						IL_23a6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_23c9;
																						IL_23c9:
																						array3[num6] = null;
																						goto IL_23d3;
																						IL_23d3:
																						num6++;
																						goto IL_23e1;
																						IL_23e1:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_23f4:
																						if (2 >= b)
																						{
																							goto IL_2402;
																						}
																						goto IL_24e1;
																						IL_2402:
																						if (2 > b)
																						{
																							goto IL_240d;
																						}
																						goto IL_2471;
																						IL_240d:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_241b;
																						IL_241b:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_2429;
																						IL_2429:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_2442;
																						IL_2442:
																						array2[num6] = 0;
																						goto IL_2450;
																						IL_2450:
																						num6++;
																						goto IL_245e;
																						IL_245e:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2471:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_24b1;
																						IL_24b1:
																						array2[num6 - 2] = 0;
																						goto IL_24c5;
																						IL_24c5:
																						num6--;
																						num = 387;
																						goto end_IL_0aea;
																						IL_24e1:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_24ef;
																						IL_24ef:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_24fd;
																						IL_24fd:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2526;
																						IL_2526:
																						ptr2 += 8;
																						goto IL_2534;
																						IL_2534:
																						num6--;
																						goto end_IL_0aea;
																						IL_2547:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2587;
																						IL_2587:
																						array2[num6 - 2] = 0;
																						goto IL_259b;
																						IL_259b:
																						num6--;
																						num = 423;
																						goto end_IL_0aea;
																						IL_25b7:
																						if (28 >= b)
																						{
																							goto IL_25c5;
																						}
																						goto IL_29b3;
																						IL_25c5:
																						if (28 > b)
																						{
																							goto IL_25d3;
																						}
																						goto IL_294d;
																						IL_25d3:
																						if (23 >= b)
																						{
																							goto IL_25e1;
																						}
																						goto IL_276a;
																						IL_25e1:
																						if (23 <= b)
																						{
																							goto IL_25ec;
																						}
																						goto IL_2651;
																						IL_25ec:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_263e;
																						IL_263e:
																						num6--;
																						goto end_IL_0aea;
																						IL_2651:
																						if (21 >= b)
																						{
																							goto IL_265f;
																						}
																						goto IL_26e6;
																						IL_265f:
																						if (21 <= b)
																						{
																							goto IL_266a;
																						}
																						goto IL_2682;
																						IL_266a:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0aea;
																						IL_2682:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_2690;
																						IL_2690:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_269e;
																						IL_269e:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_26b7;
																						IL_26b7:
																						array2[num6] = 1;
																						goto IL_26c5;
																						IL_26c5:
																						num6++;
																						goto IL_26d3;
																						IL_26d3:
																						ptr2 += 16;
																						goto end_IL_0aea;
																						IL_26e6:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_26f4;
																						IL_26f4:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_2702;
																						IL_2702:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_2743;
																						IL_2743:
																						array2[num6 - 2] = 0;
																						goto IL_2757;
																						IL_2757:
																						num6--;
																						goto end_IL_0aea;
																						IL_276a:
																						if (25 >= b)
																						{
																							goto IL_2778;
																						}
																						goto IL_2856;
																						IL_2778:
																						if (25 <= b)
																						{
																							goto IL_2783;
																						}
																						goto IL_27e8;
																						IL_2783:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																						goto IL_27c1;
																						IL_27c1:
																						array2[num6 - 1] = 0;
																						goto IL_27d5;
																						IL_27d5:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_27e8:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_27f6;
																						IL_27f6:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_2804;
																						IL_2804:
																						array3[num6] = ((delegate*<Class8.GunResult>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																						goto IL_2827;
																						IL_2827:
																						array2[num6] = 4;
																						goto IL_2835;
																						IL_2835:
																						num6++;
																						goto IL_2843;
																						IL_2843:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2856:
																						if (26 >= b)
																						{
																							goto IL_2861;
																						}
																						goto IL_28e0;
																						IL_2861:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_286f;
																						IL_286f:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_28cd;
																						IL_28cd:
																						num6--;
																						goto end_IL_0aea;
																						IL_28e0:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_28ee;
																						IL_28ee:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_28fc;
																						IL_28fc:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_2915;
																						IL_2915:
																						array2[num6] = 3;
																						goto IL_2923;
																						IL_2923:
																						num6++;
																						num = 53;
																						goto IL_293a;
																						IL_293a:
																						ptr2 += 16;
																						goto end_IL_0aea;
																						IL_294d:
																						array2[num6 - 1] = 3;
																						goto IL_2961;
																						IL_2961:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_29a0;
																						IL_29a0:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_29b3:
																						if (33 >= b)
																						{
																							goto IL_29c1;
																						}
																						goto IL_2c30;
																						IL_29c1:
																						if (33 > b)
																						{
																							goto IL_29cf;
																						}
																						goto IL_2bc9;
																						IL_29cf:
																						if (30 >= b)
																						{
																							goto IL_29dd;
																						}
																						goto IL_2ad1;
																						IL_29dd:
																						if (30 <= b)
																						{
																							goto IL_29e8;
																						}
																						goto IL_2a4e;
																						IL_29e8:
																						array2[num6 - 1] = 0;
																						goto IL_29fc;
																						IL_29fc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_2a3b;
																						IL_2a3b:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2a4e:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_2a5c;
																						IL_2a5c:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_2a6a;
																						IL_2a6a:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2aaa;
																						IL_2aaa:
																						array2[num6 - 2] = 3;
																						goto IL_2abe;
																						IL_2abe:
																						num6--;
																						goto end_IL_0aea;
																						IL_2ad1:
																						if (31 >= b)
																						{
																							goto IL_2adc;
																						}
																						goto IL_2b49;
																						IL_2adc:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_2aea;
																						IL_2aea:
																						array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
																						goto IL_2b22;
																						IL_2b22:
																						array2[num6 - 1] = 5;
																						goto IL_2b36;
																						IL_2b36:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2b49:
																						if (32 < b)
																						{
																							break;
																						}
																						num = 407;
																						goto IL_2b60;
																						IL_2df5:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_2e34;
																						IL_2b60:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_2b6e;
																						IL_2b6e:
																						ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_2bb6;
																						IL_2bb6:
																						num6--;
																						goto end_IL_0aea;
																						IL_2bc9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_2c09;
																						IL_2c09:
																						array2[num6 - 2] = 3;
																						goto IL_2c1d;
																						IL_2c1d:
																						num6--;
																						goto end_IL_0aea;
																						IL_2c30:
																						if (35 >= b)
																						{
																							goto IL_2c3e;
																						}
																						goto IL_2d86;
																						IL_2c3e:
																						if (35 > b)
																						{
																							goto IL_2c49;
																						}
																						goto IL_2cc0;
																						IL_2c49:
																						if (34 < b)
																						{
																							break;
																						}
																						goto IL_2c57;
																						IL_2c57:
																						if (34 > b)
																						{
																							break;
																						}
																						num = 69;
																						goto IL_2c6e;
																						IL_2e34:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2c6e:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																						goto IL_2c88;
																						IL_2c88:
																						array2[num6] = 3;
																						goto IL_2c96;
																						IL_2c96:
																						num6++;
																						num = 309;
																						goto IL_2cad;
																						IL_2cad:
																						ptr2 += 8;
																						goto end_IL_0aea;
																						IL_2cc0:
																						array2[num6 - 5] = 4;
																						goto IL_2cd4;
																						IL_2cd4:
																						array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																						goto IL_2d65;
																						IL_2d65:
																						num6 -= 4;
																						goto IL_2d73;
																						IL_2d73:
																						ptr2 += 8;
																						goto end_IL_0aea;
																					}
																					break;
																					IL_0ada:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_0aea:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_2e57:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1ea3:
			while (true)
			{
				IL_1ea3_2:
				array = new byte[4];
				while (true)
				{
					IL_1eb1:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_1f59_2:
							num6++;
							while (true)
							{
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_0b0a_2:
									byte b = *ptr2;
									while (true)
									{
										IL_0afa_2:
										ptr2++;
										while (true)
										{
											IL_0aea_2:
											if (b >= 1)
											{
												while (b <= 76)
												{
													while (true)
													{
														IL_0aca_2:
														if (38 < b)
														{
															while (true)
															{
																IL_0aba_2:
																if (57 < b)
																{
																	while (true)
																	{
																		IL_0aaa_2:
																		if (67 < b)
																		{
																			while (true)
																			{
																				IL_0a9a_2:
																				if (72 < b)
																				{
																					while (true)
																					{
																						IL_0a8d_2:
																						if (74 < b)
																						{
																							while (true)
																							{
																								IL_0a7d_2:
																								if (75 >= b)
																								{
																									while (75 <= b)
																									{
																										while (true)
																										{
																											IL_0a5d_2:
																											array2[num6] = 0;
																											while (true)
																											{
																												IL_0a37_2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])() ? 1 : 0);
																												while (true)
																												{
																													IL_0a27_2:
																													num6++;
																													while (true)
																													{
																														IL_0a0e_2:
																														ptr2 += 8;
																														num = 635;
																														while (num != 635)
																														{
																															if (num != 1616)
																															{
																																goto IL_2a4e_2;
																															}
																															switch (num)
																															{
																															case 361:
																																goto IL_0a0e_2;
																															case 92:
																																goto IL_0a27_2;
																															case 188:
																																goto IL_0a37_2;
																															case 404:
																															case 592:
																																goto IL_0a5d_2;
																															case 481:
																																goto IL_0a6d_2;
																															case 12:
																																goto IL_0a7d_2;
																															case 432:
																																goto IL_0a8d_2;
																															case 615:
																																goto IL_0a9a_2;
																															case 440:
																																goto IL_0aaa_2;
																															case 581:
																																goto IL_0aba_2;
																															case 504:
																																goto IL_0aca_2;
																															case 319:
																																goto IL_0ada_2;
																															case 85:
																																goto IL_0aea_2;
																															case 18:
																																goto IL_0afa_2;
																															case 356:
																															case 549:
																																goto IL_0b0a_2;
																															case 96:
																																goto IL_0b15_2;
																															case 332:
																																goto IL_0b2e_2;
																															case 17:
																																goto IL_0b3c_2;
																															case 89:
																															case 328:
																																goto IL_0b4a_2;
																															case 30:
																																goto IL_0b67_2;
																															case 47:
																																goto IL_0ba6_2;
																															case 374:
																																goto IL_0bb9_2;
																															case 13:
																																goto IL_0bc4_2;
																															case 24:
																																goto IL_0bd2_2;
																															case 191:
																															case 192:
																																goto IL_0be0_2;
																															case 40:
																															case 261:
																																goto IL_0bfe_2;
																															case 79:
																																goto IL_0c32_2;
																															case 514:
																																goto IL_0c4b_2;
																															case 156:
																															case 509:
																																goto IL_0c56_2;
																															case 418:
																																goto IL_0c93_2;
																															case 50:
																																goto IL_0ca1_2;
																															case 265:
																																goto IL_0cb4_2;
																															case 312:
																																goto IL_0cc2_2;
																															case 465:
																																goto IL_0cd0_2;
																															case 439:
																																goto IL_0cde_2;
																															case 44:
																															case 298:
																																goto IL_0ce9_2;
																															case 212:
																																goto IL_0cfd_2;
																															case 56:
																																goto IL_0d3a_2;
																															case 443:
																																goto IL_0d4d_2;
																															case 368:
																																goto IL_0d5b_2;
																															case 75:
																															case 449:
																																goto IL_0d69_2;
																															case 478:
																																goto IL_0d7d_2;
																															case 119:
																																goto IL_0db5_2;
																															case 21:
																																goto IL_0dc8_2;
																															case 78:
																																goto IL_0dd3_2;
																															case 313:
																																goto IL_0de6_2;
																															case 54:
																																goto IL_0df4_2;
																															case 194:
																															case 462:
																																goto IL_0e02_2;
																															case 317:
																																goto IL_0e16_2;
																															case 84:
																																goto IL_0e67_2;
																															case 354:
																																goto IL_0e75_2;
																															case 284:
																																goto IL_0e91_2;
																															case 527:
																																goto IL_0ea4_2;
																															case 174:
																																goto IL_0eaf_2;
																															case 250:
																															case 455:
																																goto IL_0ebd_2;
																															case 264:
																																goto IL_0ed1_2;
																															case 170:
																																goto IL_0f23_2;
																															case 61:
																																goto IL_0f31_2;
																															case 386:
																																goto IL_0f3f_2;
																															case 16:
																															case 411:
																																goto IL_0f4d_2;
																															case 530:
																																goto IL_0f99_2;
																															case 88:
																																goto IL_0fa7_2;
																															case 241:
																																goto IL_0fb5_2;
																															case 486:
																																goto IL_0fcc_2;
																															case 392:
																															case 413:
																																goto IL_0fda_2;
																															case 452:
																																goto IL_0ff7_2;
																															case 262:
																																goto IL_1036_2;
																															case 288:
																																goto IL_1049_2;
																															case 225:
																																goto IL_1054_2;
																															case 397:
																																goto IL_1067_2;
																															case 183:
																																goto IL_1075_2;
																															case 82:
																															case 137:
																																goto IL_1083_2;
																															case 275:
																																goto IL_1097_2;
																															case 10:
																																goto IL_10d6_2;
																															case 120:
																															case 537:
																																goto IL_10e9_2;
																															case 208:
																																goto IL_10f7_2;
																															case 476:
																																goto IL_1115_2;
																															case 485:
																																goto IL_1123_2;
																															case 157:
																															case 553:
																																goto IL_1136_2;
																															case 344:
																																goto IL_114f_2;
																															case 562:
																																goto IL_1162_2;
																															case 430:
																																goto IL_1176_2;
																															case 347:
																															case 571:
																																goto IL_1189_2;
																															case 166:
																																goto IL_11b2_2;
																															case 337:
																																goto IL_11c9_2;
																															case 574:
																																goto IL_11dc_2;
																															case 253:
																															case 584:
																																goto IL_11f5_2;
																															case 251:
																																goto IL_1209_2;
																															case 302:
																																goto IL_1241_2;
																															case 591:
																																goto IL_1254_2;
																															case 116:
																															case 159:
																																goto IL_1262_2;
																															case 554:
																																goto IL_126c_2;
																															case 472:
																																goto IL_127a_2;
																															case 598:
																																goto IL_128d_2;
																															case 162:
																															case 588:
																																goto IL_129b_2;
																															case 42:
																																goto IL_12b8_2;
																															case 213:
																																goto IL_12f7_2;
																															case 605:
																																goto IL_130a_2;
																															case 71:
																																goto IL_1318_2;
																															case 2:
																																goto IL_1326_2;
																															case 268:
																																goto IL_1334_2;
																															case 203:
																																goto IL_133f_2;
																															case 204:
																															case 310:
																																goto IL_134d_2;
																															case 492:
																																goto IL_1370_2;
																															case 296:
																																goto IL_137e_2;
																															case 497:
																																goto IL_138c_2;
																															case 583:
																																goto IL_139f_2;
																															case 305:
																																goto IL_13ad_2;
																															case 73:
																															case 546:
																																goto IL_13bb_2;
																															case 428:
																																goto IL_13d4_2;
																															case 349:
																																goto IL_13df_2;
																															case 115:
																																goto IL_13ed_2;
																															case 64:
																															case 471:
																																goto IL_13fb_2;
																															case 139:
																																goto IL_140f_2;
																															case 70:
																																goto IL_1447_2;
																															case 161:
																															case 260:
																																goto IL_145a_2;
																															case 435:
																																goto IL_146e_2;
																															case 138:
																																goto IL_14ab_2;
																															case 299:
																															case 496:
																																goto IL_14c7_2;
																															case 534:
																																goto IL_14db_2;
																															case 390:
																																goto IL_1518_2;
																															case 606:
																																goto IL_152b_2;
																															case 77:
																															case 107:
																																goto IL_1536_2;
																															case 36:
																																goto IL_154f_2;
																															case 366:
																																goto IL_1562_2;
																															case 126:
																																goto IL_1570_2;
																															case 39:
																															case 290:
																																goto IL_157b_2;
																															case 99:
																																goto IL_1594_2;
																															case 525:
																																goto IL_15ab_2;
																															case 58:
																															case 224:
																																goto IL_15c2_2;
																															case 444:
																																goto IL_15df_2;
																															case 144:
																																goto IL_161c_2;
																															case 388:
																																goto IL_1638_2;
																															case 155:
																																goto IL_1643_2;
																															case 254:
																															case 561:
																																goto IL_1651_2;
																															case 20:
																																goto IL_1674_2;
																															case 521:
																																goto IL_1682_2;
																															case 394:
																																goto IL_1690_2;
																															case 528:
																																goto IL_16ac_2;
																															case 593:
																																goto IL_16ba_2;
																															case 273:
																															case 501:
																																goto IL_16c8_2;
																															case 283:
																																goto IL_16dc_2;
																															case 498:
																																goto IL_172d_2;
																															case 563:
																																goto IL_173b_2;
																															case 609:
																																goto IL_174e_2;
																															case 249:
																															case 393:
																																goto IL_1759_2;
																															case 243:
																																goto IL_1777_2;
																															case 580:
																																goto IL_1785_2;
																															case 48:
																																goto IL_1793_2;
																															case 164:
																																goto IL_17a6_2;
																															case 49:
																																goto IL_17b4_2;
																															case 324:
																															case 484:
																																goto IL_17bf_2;
																															case 382:
																																goto IL_17f7_2;
																															case 23:
																																goto IL_180b_2;
																															case 242:
																																goto IL_181e_2;
																															case 294:
																																goto IL_182c_2;
																															case 320:
																															case 495:
																																goto IL_183a_2;
																															case 463:
																																goto IL_1848_2;
																															case 603:
																																goto IL_1866_2;
																															case 442:
																																goto IL_1874_2;
																															case 291:
																																goto IL_1887_2;
																															case 601:
																																goto IL_1895_2;
																															case 272:
																															case 436:
																																goto IL_18a3_2;
																															case 589:
																																goto IL_18ea_2;
																															case 512:
																																goto IL_18f8_2;
																															case 140:
																															case 614:
																																goto IL_1914_2;
																															case 193:
																																goto IL_1937_2;
																															case 28:
																																goto IL_1945_2;
																															case 326:
																																goto IL_1953_2;
																															case 616:
																																goto IL_1966_2;
																															case 541:
																																goto IL_197d_2;
																															case 618:
																																goto IL_1990_2;
																															case 508:
																																goto IL_19e1_2;
																															case 76:
																																goto IL_19ef_2;
																															case 621:
																																goto IL_1a0b_2;
																															case 622:
																																goto IL_1a1e_2;
																															case 102:
																																goto IL_1a5b_2;
																															case 625:
																																goto IL_1a6e_2;
																															case 457:
																																goto IL_1a7c_2;
																															case 321:
																															case 533:
																																goto IL_1a87_2;
																															case 117:
																																goto IL_1a9b_2;
																															case 151:
																																goto IL_1ada_2;
																															case 103:
																																goto IL_1af6_2;
																															case 454:
																																goto IL_1b04_2;
																															case 111:
																															case 323:
																																goto IL_1b12_2;
																															case 342:
																																goto IL_1b2b_2;
																															case 237:
																																goto IL_1b3e_2;
																															case 373:
																																goto IL_1b49_2;
																															case 322:
																															case 351:
																																goto IL_1b57_2;
																															case 270:
																																goto IL_1b8f_2;
																															case 189:
																																goto IL_1ba3_2;
																															case 125:
																																goto IL_1bb6_2;
																															case 370:
																																goto IL_1bc4_2;
																															case 197:
																															case 222:
																																goto IL_1bd2_2;
																															case 325:
																																goto IL_1c0a_2;
																															case 145:
																																goto IL_1c1e_2;
																															case 505:
																																goto IL_1c31_2;
																															case 522:
																																goto IL_1c3f_2;
																															case 33:
																																goto IL_1c52_2;
																															case 124:
																															case 400:
																																goto IL_1c5d_2;
																															case 38:
																																goto IL_1c79_2;
																															case 72:
																																goto IL_1c87_2;
																															case 398:
																															case 578:
																																goto IL_1c92_2;
																															case 348:
																																goto IL_1caf_2;
																															case 240:
																																goto IL_1ce7_2;
																															case 600:
																																goto IL_1cfa_2;
																															case 187:
																																goto IL_1d08_2;
																															case 235:
																																goto IL_1d16_2;
																															case 401:
																																goto IL_1d24_2;
																															case 232:
																																goto IL_1d32_2;
																															case 123:
																															case 540:
																																goto IL_1d40_2;
																															case 198:
																																goto IL_1d54_2;
																															case 83:
																																goto IL_1da8_2;
																															case 333:
																																goto IL_1db6_2;
																															case 239:
																																goto IL_1dc9_2;
																															case 8:
																																goto IL_1dd7_2;
																															case 31:
																															case 132:
																																goto IL_1de5_2;
																															case 568:
																																goto IL_1e47_2;
																															case 405:
																																goto IL_1e5a_2;
																															case 570:
																																goto IL_1e65_2;
																															case 380:
																																goto IL_1e78_2;
																															case 617:
																																goto IL_1e86_2;
																															case 364:
																															case 406:
																																goto IL_1e94_2;
																															case 451:
																																goto end_IL_2e57_2;
																															case 131:
																																goto IL_1f59_2;
																															case 215:
																															case 410:
																																goto IL_1f6c_2;
																															case 519:
																																goto IL_1f93_2;
																															case 586:
																																goto IL_1fa1_2;
																															case 81:
																																goto IL_1fb4_2;
																															case 474:
																																goto IL_1fc2_2;
																															case 29:
																															case 363:
																																goto IL_1fd0_2;
																															case 267:
																																goto IL_1fe8_2;
																															case 86:
																																goto IL_2006_2;
																															case 375:
																																goto IL_202a_2;
																															case 491:
																																goto IL_2042_2;
																															case 178:
																																goto IL_2055_2;
																															case 445:
																																goto IL_2063_2;
																															case 147:
																															case 292:
																																goto IL_2071_2;
																															case 5:
																																goto IL_209a_2;
																															case 285:
																																goto IL_20b3_2;
																															case 520:
																																goto IL_20be_2;
																															case 314:
																															case 510:
																																goto IL_20cc_2;
																															case 576:
																																goto IL_20da_2;
																															case 420:
																																goto IL_20f2_2;
																															case 585:
																																goto IL_2109_2;
																															case 74:
																																goto IL_211c_2;
																															case 365:
																																goto IL_212a_2;
																															case 112:
																															case 200:
																																goto IL_2138_2;
																															case 532:
																																goto IL_2176_2;
																															case 488:
																																goto IL_2192_2;
																															case 154:
																																goto IL_21a0_2;
																															case 150:
																																goto IL_21ae_2;
																															case 623:
																																goto IL_21bc_2;
																															case 148:
																															case 421:
																																goto IL_21c7_2;
																															case 590:
																																goto IL_2207_2;
																															case 458:
																																goto IL_2224_2;
																															case 121:
																																goto IL_2237_2;
																															case 108:
																																goto IL_2245_2;
																															case 68:
																															case 558:
																																goto IL_2253_2;
																															case 422:
																																goto IL_2293_2;
																															case 529:
																																goto IL_22a7_2;
																															case 582:
																																goto IL_22ba_2;
																															case 565:
																																goto IL_22c5_2;
																															case 278:
																																goto IL_22d3_2;
																															case 153:
																															case 359:
																																goto IL_22e1_2;
																															case 25:
																																goto IL_22fd_2;
																															case 109:
																															case 173:
																																goto IL_230b_2;
																															case 395:
																																goto IL_2354_2;
																															case 408:
																																goto IL_2371_2;
																															case 627:
																																goto IL_238d_2;
																															case 446:
																															case 475:
																																goto IL_2398_2;
																															case 318:
																																goto IL_23a6_2;
																															case 279:
																																goto IL_23c9_2;
																															case 216:
																																goto IL_23d3_2;
																															case 557:
																																goto IL_23e1_2;
																															case 466:
																																goto IL_23f4_2;
																															case 367:
																																goto IL_2402_2;
																															case 536:
																																goto IL_240d_2;
																															case 500:
																																goto IL_241b_2;
																															case 376:
																															case 599:
																																goto IL_2429_2;
																															case 9:
																																goto IL_2442_2;
																															case 573:
																																goto IL_2450_2;
																															case 345:
																																goto IL_245e_2;
																															case 186:
																															case 518:
																																goto IL_2471_2;
																															case 263:
																																goto IL_24b1_2;
																															case 340:
																																goto IL_24c5_2;
																															case 339:
																																goto IL_24e1_2;
																															case 135:
																																goto IL_24ef_2;
																															case 217:
																															case 441:
																																goto IL_24fd_2;
																															case 184:
																																goto IL_2526_2;
																															case 572:
																																goto IL_2534_2;
																															case 459:
																															case 493:
																																goto IL_2547_2;
																															case 612:
																																goto IL_2587_2;
																															case 566:
																																goto IL_259b_2;
																															case 93:
																																goto IL_25b7_2;
																															case 419:
																																goto IL_25c5_2;
																															case 22:
																																goto IL_25d3_2;
																															case 163:
																																goto IL_25e1_2;
																															case 105:
																															case 346:
																																goto IL_25ec_2;
																															case 502:
																																goto IL_263e_2;
																															case 482:
																																goto IL_2651_2;
																															case 246:
																																goto IL_265f_2;
																															case 80:
																															case 517:
																																goto IL_266a_2;
																															case 499:
																																goto IL_2682_2;
																															case 620:
																																goto IL_2690_2;
																															case 91:
																															case 453:
																																goto IL_269e_2;
																															case 219:
																																goto IL_26b7_2;
																															case 110:
																																goto IL_26c5_2;
																															case 447:
																																goto IL_26d3_2;
																															case 179:
																																goto IL_26e6_2;
																															case 379:
																																goto IL_26f4_2;
																															case 141:
																															case 248:
																																goto IL_2702_2;
																															case 60:
																																goto IL_2743_2;
																															case 503:
																																goto IL_2757_2;
																															case 516:
																																goto IL_276a_2;
																															case 221:
																																goto IL_2778_2;
																															case 233:
																															case 236:
																																goto IL_2783_2;
																															case 456:
																																goto IL_27c1_2;
																															case 507:
																																goto IL_27d5_2;
																															case 295:
																																goto IL_27e8_2;
																															case 626:
																																goto IL_27f6_2;
																															case 35:
																															case 369:
																																goto IL_2804_2;
																															case 181:
																																goto IL_2827_2;
																															case 437:
																																goto IL_2835_2;
																															case 306:
																																goto IL_2843_2;
																															case 266:
																																goto IL_2856_2;
																															case 383:
																																goto IL_2861_2;
																															case 245:
																															case 276:
																																goto IL_286f_2;
																															case 143:
																																goto IL_28cd_2;
																															case 214:
																																goto IL_28e0_2;
																															case 106:
																																goto IL_28ee_2;
																															case 308:
																															case 560:
																																goto IL_28fc_2;
																															case 146:
																																goto IL_2915_2;
																															case 538:
																																goto IL_2923_2;
																															case 53:
																																goto IL_293a_2;
																															case 417:
																															case 564:
																																goto IL_294d_2;
																															case 608:
																																goto IL_2961_2;
																															case 341:
																																goto IL_29a0_2;
																															case 269:
																																goto IL_29b3_2;
																															case 384:
																																goto IL_29c1_2;
																															case 133:
																																goto IL_29cf_2;
																															case 343:
																																goto IL_29dd_2;
																															case 307:
																															case 559:
																																goto IL_29e8_2;
																															case 238:
																																goto IL_29fc_2;
																															case 479:
																																goto IL_2a3b_2;
																															case 316:
																																goto IL_2a4e_2;
																															case 210:
																																goto IL_2a5c_2;
																															case 175:
																															case 281:
																																goto IL_2a6a_2;
																															case 67:
																																goto IL_2aaa_2;
																															case 223:
																																goto IL_2abe_2;
																															case 297:
																																goto IL_2ad1_2;
																															case 494:
																																goto IL_2adc_2;
																															case 63:
																															case 523:
																																goto IL_2aea_2;
																															case 41:
																																goto IL_2b22_2;
																															case 226:
																																goto IL_2b36_2;
																															case 152:
																																goto IL_2b49_2;
																															case 407:
																																goto IL_2b60_2;
																															case 51:
																															case 234:
																																goto IL_2b6e_2;
																															case 227:
																																goto IL_2bb6_2;
																															case 425:
																															case 619:
																																goto IL_2bc9_2;
																															case 489:
																																goto IL_2c09_2;
																															case 352:
																																goto IL_2c1d_2;
																															case 182:
																																goto IL_2c30_2;
																															case 218:
																																goto IL_2c3e_2;
																															case 211:
																																goto IL_2c49_2;
																															case 169:
																																goto IL_2c57_2;
																															case 69:
																															case 286:
																																goto IL_2c6e_2;
																															case 461:
																																goto IL_2c88_2;
																															case 304:
																																goto IL_2c96_2;
																															case 309:
																																goto IL_2cad_2;
																															case 172:
																															case 555:
																																goto IL_2cc0_2;
																															case 412:
																																goto IL_2cd4_2;
																															case 114:
																																goto IL_2d65_2;
																															case 381:
																																goto IL_2d73_2;
																															case 424:
																																goto IL_2d86_2;
																															case 127:
																																goto IL_2d91_2;
																															case 168:
																															case 327:
																																goto IL_2d9f_2;
																															case 113:
																																goto IL_2db8_2;
																															case 480:
																																goto IL_2dcb_2;
																															case 98:
																																goto IL_2dd6_2;
																															case 357:
																															case 575:
																																goto IL_2de1_2;
																															case 483:
																																goto IL_2df5_2;
																															case 336:
																																goto IL_2e34_2;
																															case 0:
																															case 1:
																															case 3:
																															case 11:
																															case 14:
																															case 15:
																															case 26:
																															case 46:
																															case 55:
																															case 57:
																															case 62:
																															case 65:
																															case 95:
																															case 100:
																															case 101:
																															case 104:
																															case 129:
																															case 134:
																															case 149:
																															case 158:
																															case 160:
																															case 165:
																															case 180:
																															case 190:
																															case 196:
																															case 199:
																															case 205:
																															case 206:
																															case 207:
																															case 231:
																															case 244:
																															case 247:
																															case 257:
																															case 258:
																															case 259:
																															case 271:
																															case 280:
																															case 282:
																															case 287:
																															case 289:
																															case 293:
																															case 301:
																															case 311:
																															case 334:
																															case 350:
																															case 355:
																															case 358:
																															case 360:
																															case 371:
																															case 372:
																															case 385:
																															case 399:
																															case 409:
																															case 414:
																															case 429:
																															case 433:
																															case 438:
																															case 450:
																															case 460:
																															case 464:
																															case 467:
																															case 468:
																															case 469:
																															case 473:
																															case 490:
																															case 513:
																															case 524:
																															case 531:
																															case 535:
																															case 539:
																															case 543:
																															case 544:
																															case 552:
																															case 567:
																															case 577:
																															case 602:
																															case 607:
																															case 610:
																															case 613:
																																goto end_IL_0a6d_2;
																															case 4:
																															case 6:
																															case 19:
																															case 27:
																															case 32:
																															case 34:
																															case 43:
																															case 45:
																															case 52:
																															case 66:
																															case 87:
																															case 90:
																															case 94:
																															case 97:
																															case 118:
																															case 122:
																															case 128:
																															case 130:
																															case 136:
																															case 142:
																															case 167:
																															case 171:
																															case 176:
																															case 185:
																															case 201:
																															case 202:
																															case 209:
																															case 220:
																															case 230:
																															case 252:
																															case 255:
																															case 256:
																															case 274:
																															case 277:
																															case 300:
																															case 303:
																															case 329:
																															case 335:
																															case 338:
																															case 353:
																															case 377:
																															case 378:
																															case 387:
																															case 389:
																															case 391:
																															case 396:
																															case 402:
																															case 403:
																															case 415:
																															case 416:
																															case 423:
																															case 426:
																															case 427:
																															case 431:
																															case 434:
																															case 448:
																															case 470:
																															case 477:
																															case 487:
																															case 506:
																															case 515:
																															case 526:
																															case 542:
																															case 545:
																															case 547:
																															case 548:
																															case 550:
																															case 551:
																															case 556:
																															case 569:
																															case 579:
																															case 594:
																															case 595:
																															case 597:
																															case 604:
																															case 611:
																															case 624:
																															case 628:
																																goto end_IL_09fb_2;
																															case 59:
																																ptr2 = ptr;
																																goto end_IL_09fb_2;
																															case 177:
																																ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OutOfMemoryExceptionCCSYSCALL.IndexOfValueDirectoryString);
																																goto case 59;
																															case 7:
																																array7 = new object[8];
																																goto case 177;
																															case 330:
																																array6 = new long[5];
																																goto case 7;
																															case 315:
																																array5 = new int[7];
																																goto case 330;
																															case 195:
																																array4 = new int[5];
																																goto case 315;
																															case 362:
																																array3 = new object[5];
																																goto case 195;
																															case 511:
																																array2 = new byte[5];
																																goto case 362;
																															case 587:
																																num4 = num2 * 8;
																																num = 511;
																																goto case 511;
																															case 596:
																																num3 = num2 * 4;
																																goto case 587;
																															case 228:
																																num2 = 1;
																																num = 596;
																																goto case 596;
																															case 229:
																																goto end_IL_1f4b;
																															case 37:
																															case 331:
																																return;
																															}
																															continue;
																															end_IL_09fb_2:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto end_IL_0aea_2;
																										continue;
																										end_IL_0a6d_2:
																										break;
																										IL_0a6d_2:;
																									}
																									break;
																								}
																								goto IL_1c31_2;
																								IL_1c3f_2:
																								if (76 > b)
																								{
																								}
																								break;
																								IL_1c31_2:
																								if (76 < b)
																								{
																									break;
																								}
																								goto IL_1c3f_2;
																							}
																							break;
																						}
																						goto IL_0b15_2;
																						IL_0b67_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_0ba6_2;
																						IL_0b15_2:
																						if (74 > b)
																						{
																							goto IL_0b2e_2;
																						}
																						num = 347;
																						goto IL_1189_2;
																						IL_0ba6_2:
																						ptr2 += 8;
																						goto end_IL_0aea_2;
																						IL_1189_2:
																						((delegate*<string, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_11b2_2;
																						IL_11b2_2:
																						num6--;
																						num = 337;
																						goto IL_11c9_2;
																						IL_11c9_2:
																						ptr2 += 8;
																						goto end_IL_0aea_2;
																						IL_0b2e_2:
																						if (73 < b)
																						{
																							break;
																						}
																						goto IL_0b3c_2;
																						IL_0b3c_2:
																						if (73 > b)
																						{
																							break;
																						}
																						goto IL_0b4a_2;
																						IL_0b4a_2:
																						array2[num6 - 1] = 3;
																						num = 30;
																						goto IL_0b67_2;
																					}
																					break;
																				}
																				goto IL_152b_2;
																				IL_16dc_2:
																				array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																				goto IL_172d_2;
																				IL_152b_2:
																				if (72 <= b)
																				{
																					goto IL_1536_2;
																				}
																				goto IL_1562_2;
																				IL_1536_2:
																				global::_003CModule_003E.quaternion_7 = (Quaternion)array3[num6 - 1];
																				goto IL_154f_2;
																				IL_154f_2:
																				num6--;
																				goto end_IL_0aea_2;
																				IL_1562_2:
																				if (69 >= b)
																				{
																					goto IL_1570_2;
																				}
																				goto IL_1638_2;
																				IL_1570_2:
																				if (69 <= b)
																				{
																					goto IL_157b_2;
																				}
																				goto IL_1594_2;
																				IL_157b_2:
																				array2[num6 - 1] = 4;
																				goto IL_1a1e_2;
																				IL_1a1e_2:
																				array3[num6 - 1] = ((delegate*<Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 1]);
																				goto IL_1a5b_2;
																				IL_1a5b_2:
																				ptr2 += 8;
																				goto end_IL_0aea_2;
																				IL_1594_2:
																				if (68 < b)
																				{
																					break;
																				}
																				num = 525;
																				goto IL_15ab_2;
																				IL_172d_2:
																				num6--;
																				goto IL_173b_2;
																				IL_15ab_2:
																				if (68 > b)
																				{
																					break;
																				}
																				num = 58;
																				goto IL_15c2_2;
																				IL_173b_2:
																				ptr2 += 8;
																				goto end_IL_0aea_2;
																				IL_15c2_2:
																				array2[num6 - 1] = 4;
																				num = 444;
																				goto IL_15df_2;
																				IL_15df_2:
																				array3[num6 - 1] = ((delegate*<Transform, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																				goto IL_161c_2;
																				IL_161c_2:
																				ptr2 += 8;
																				num = 448;
																				goto end_IL_0aea_2;
																				IL_1638_2:
																				if (70 >= b)
																				{
																					goto IL_1643_2;
																				}
																				goto IL_16ac_2;
																				IL_1643_2:
																				if (70 > b)
																				{
																					break;
																				}
																				goto IL_1651_2;
																				IL_1651_2:
																				array3[num6] = ((delegate*<Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																				goto IL_1674_2;
																				IL_1674_2:
																				array2[num6] = 4;
																				goto IL_1682_2;
																				IL_1682_2:
																				num6++;
																				goto IL_1690_2;
																				IL_1690_2:
																				ptr2 += 8;
																				num = 487;
																				goto end_IL_0aea_2;
																				IL_16ac_2:
																				if (71 < b)
																				{
																					break;
																				}
																				goto IL_16ba_2;
																				IL_16ba_2:
																				if (71 > b)
																				{
																					break;
																				}
																				goto IL_16c8_2;
																				IL_16c8_2:
																				array2[num6 - 2] = 4;
																				goto IL_16dc_2;
																			}
																			break;
																		}
																		goto IL_0bb9_2;
																		IL_12f7_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_0bb9_2:
																		if (67 > b)
																		{
																			goto IL_0bc4_2;
																		}
																		goto IL_0bfe_2;
																		IL_0bc4_2:
																		if (62 >= b)
																		{
																			goto IL_0bd2_2;
																		}
																		goto IL_0ea4_2;
																		IL_0bd2_2:
																		if (62 <= b)
																		{
																			goto IL_0be0_2;
																		}
																		goto IL_0f99_2;
																		IL_0be0_2:
																		global::_003CModule_003E.vector3_151 = (Vector3)array3[num6 - 1];
																		goto IL_1a0b_2;
																		IL_1a0b_2:
																		num6--;
																		goto end_IL_0aea_2;
																		IL_0f99_2:
																		if (59 >= b)
																		{
																			goto IL_0fa7_2;
																		}
																		goto IL_1049_2;
																		IL_0fa7_2:
																		if (59 > b)
																		{
																			goto IL_0fb5_2;
																		}
																		goto IL_11f5_2;
																		IL_0fb5_2:
																		if (58 < b)
																		{
																			break;
																		}
																		num = 486;
																		goto IL_0fcc_2;
																		IL_0bfe_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 79;
																		goto IL_0c32_2;
																		IL_0fcc_2:
																		if (58 > b)
																		{
																			break;
																		}
																		goto IL_0fda_2;
																		IL_0fda_2:
																		array2[num6 - 1] = 3;
																		num = 452;
																		goto IL_0ff7_2;
																		IL_0ff7_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1036_2;
																		IL_1036_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_11f5_2:
																		array2[num6 - 1] = 5;
																		goto IL_1209_2;
																		IL_1209_2:
																		array3[num6 - 1] = ((delegate*<Player, VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Player)array3[num6 - 1]);
																		goto IL_1241_2;
																		IL_1241_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_1049_2:
																		if (60 >= b)
																		{
																			goto IL_1054_2;
																		}
																		goto IL_1067_2;
																		IL_1054_2:
																		if (60 > b)
																		{
																			break;
																		}
																		goto IL_1136_2;
																		IL_1136_2:
																		global::_003CModule_003E.v_003CbUQdVVYR = (VRRig)array3[num6 - 1];
																		goto IL_114f_2;
																		IL_114f_2:
																		num6--;
																		goto end_IL_0aea_2;
																		IL_1067_2:
																		if (61 < b)
																		{
																			break;
																		}
																		goto IL_1075_2;
																		IL_1075_2:
																		if (61 > b)
																		{
																			break;
																		}
																		goto IL_1083_2;
																		IL_1083_2:
																		array2[num6 - 1] = 3;
																		goto IL_1097_2;
																		IL_1097_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_10d6_2;
																		IL_10d6_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_0ea4_2:
																		if (64 >= b)
																		{
																			goto IL_0eaf_2;
																		}
																		goto IL_0f23_2;
																		IL_0eaf_2:
																		if (64 <= b)
																		{
																			goto IL_0ebd_2;
																		}
																		goto IL_11dc_2;
																		IL_0ebd_2:
																		array2[num6 - 2] = 0;
																		goto IL_0ed1_2;
																		IL_0ed1_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																		goto IL_1966_2;
																		IL_1966_2:
																		num6--;
																		num = 541;
																		goto IL_197d_2;
																		IL_197d_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_11dc_2:
																		if (63 < b)
																		{
																			break;
																		}
																		num = 591;
																		goto IL_1254_2;
																		IL_0c32_2:
																		array2[num6 - 1] = 0;
																		goto end_IL_0aea_2;
																		IL_1254_2:
																		if (63 > b)
																		{
																			break;
																		}
																		goto IL_1262_2;
																		IL_1262_2:
																		array3[num6] = null;
																		goto IL_126c_2;
																		IL_126c_2:
																		array2[num6] = 5;
																		goto IL_127a_2;
																		IL_127a_2:
																		num6++;
																		goto end_IL_0aea_2;
																		IL_0f23_2:
																		if (65 < b)
																		{
																			goto IL_0f31_2;
																		}
																		goto IL_128d_2;
																		IL_0f31_2:
																		if (66 < b)
																		{
																			break;
																		}
																		goto IL_0f3f_2;
																		IL_0f3f_2:
																		if (66 > b)
																		{
																			break;
																		}
																		goto IL_0f4d_2;
																		IL_0f4d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																		num = 562;
																		goto IL_1162_2;
																		IL_1162_2:
																		array2[num6 - 1] = 0;
																		goto IL_1176_2;
																		IL_1176_2:
																		ptr2 += 8;
																		goto end_IL_0aea_2;
																		IL_128d_2:
																		if (65 > b)
																		{
																			break;
																		}
																		goto IL_129b_2;
																		IL_129b_2:
																		array2[num6 - 1] = 3;
																		num = 42;
																		goto IL_12b8_2;
																		IL_12b8_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_12f7_2;
																	}
																	break;
																}
																goto IL_0c4b_2;
																IL_14db_2:
																array3[num6 - 1] = ((delegate*<Vector3, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 1]);
																goto IL_1518_2;
																IL_0c4b_2:
																if (57 <= b)
																{
																	goto IL_0c56_2;
																}
																goto IL_0cb4_2;
																IL_0c56_2:
																((delegate*<Transform, Quaternion, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																goto IL_0c93_2;
																IL_0c93_2:
																num6 -= 2;
																goto IL_0ca1_2;
																IL_0ca1_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_0cb4_2:
																if (47 < b)
																{
																	goto IL_0cc2_2;
																}
																goto IL_130a_2;
																IL_0cc2_2:
																if (52 < b)
																{
																	goto IL_0cd0_2;
																}
																num = 284;
																goto IL_0e91_2;
																IL_0cd0_2:
																if (54 >= b)
																{
																	goto IL_0cde_2;
																}
																goto IL_0dc8_2;
																IL_0cde_2:
																if (54 <= b)
																{
																	goto IL_0ce9_2;
																}
																goto IL_0d4d_2;
																IL_0ce9_2:
																array2[num6 - 1] = 4;
																goto IL_0cfd_2;
																IL_0cfd_2:
																array3[num6 - 1] = ((delegate*<Transform, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																goto IL_0d3a_2;
																IL_0d3a_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_0d4d_2:
																if (53 < b)
																{
																	break;
																}
																goto IL_0d5b_2;
																IL_0d5b_2:
																if (53 > b)
																{
																	break;
																}
																goto IL_0d69_2;
																IL_0d69_2:
																array2[num6 - 1] = 5;
																goto IL_0d7d_2;
																IL_0d7d_2:
																array3[num6 - 1] = ((delegate*<Component, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																goto IL_0db5_2;
																IL_0db5_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_0dc8_2:
																if (55 >= b)
																{
																	goto IL_0dd3_2;
																}
																goto IL_0de6_2;
																IL_0dd3_2:
																if (55 > b)
																{
																	break;
																}
																goto IL_1914_2;
																IL_1914_2:
																array3[num6] = ((delegate*<Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																goto IL_1937_2;
																IL_1937_2:
																array2[num6] = 4;
																goto IL_1945_2;
																IL_1945_2:
																num6++;
																goto IL_1953_2;
																IL_1953_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_0de6_2:
																if (56 < b)
																{
																	break;
																}
																goto IL_0df4_2;
																IL_0df4_2:
																if (56 > b)
																{
																	break;
																}
																goto IL_0e02_2;
																IL_0e02_2:
																array2[num6 - 2] = 4;
																goto IL_0e16_2;
																IL_0e16_2:
																array3[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Quaternion)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																goto IL_0e67_2;
																IL_0e67_2:
																num6--;
																goto IL_0e75_2;
																IL_0e75_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_1518_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_0e91_2:
																if (52 <= b)
																{
																	goto IL_10e9_2;
																}
																goto IL_1a6e_2;
																IL_10e9_2:
																array2[num6] = 5;
																goto IL_10f7_2;
																IL_10f7_2:
																array3[num6] = ((delegate*<GorillaTagger>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																goto IL_1115_2;
																IL_1115_2:
																num6++;
																goto IL_1123_2;
																IL_1123_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_1a6e_2:
																if (49 >= b)
																{
																	goto IL_1a7c_2;
																}
																goto IL_1b3e_2;
																IL_1a7c_2:
																if (49 <= b)
																{
																	goto IL_1a87_2;
																}
																goto IL_1af6_2;
																IL_1a87_2:
																array2[num6 - 1] = 3;
																goto IL_1a9b_2;
																IL_1a9b_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1ada_2;
																IL_1ada_2:
																ptr2 += 8;
																num = 32;
																goto end_IL_0aea_2;
																IL_1af6_2:
																if (48 < b)
																{
																	break;
																}
																goto IL_1b04_2;
																IL_1b04_2:
																if (48 > b)
																{
																	break;
																}
																goto IL_1b12_2;
																IL_1b12_2:
																global::_003CModule_003E.quaternion_6 = (Quaternion)array3[num6 - 1];
																goto IL_1b2b_2;
																IL_1b2b_2:
																num6--;
																goto end_IL_0aea_2;
																IL_1b3e_2:
																if (50 >= b)
																{
																	goto IL_1b49_2;
																}
																goto IL_1bb6_2;
																IL_1b49_2:
																if (50 > b)
																{
																	break;
																}
																goto IL_1b57_2;
																IL_1b57_2:
																array3[num6 - 1] = ((delegate*<VRRig, VRMap>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																goto IL_1b8f_2;
																IL_1b8f_2:
																array2[num6 - 1] = 5;
																goto IL_1ba3_2;
																IL_1ba3_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_1bb6_2:
																if (51 < b)
																{
																	break;
																}
																goto IL_1bc4_2;
																IL_1bc4_2:
																if (51 > b)
																{
																	break;
																}
																goto IL_1bd2_2;
																IL_1bd2_2:
																array3[num6 - 1] = ((delegate*<VRMap, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRMap)array3[num6 - 1]);
																goto IL_1c0a_2;
																IL_1c0a_2:
																array2[num6 - 1] = 5;
																goto IL_1c1e_2;
																IL_1c1e_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_130a_2:
																if (47 > b)
																{
																	goto IL_1318_2;
																}
																goto IL_14c7_2;
																IL_1318_2:
																if (42 < b)
																{
																	goto IL_1326_2;
																}
																goto IL_174e_2;
																IL_1326_2:
																if (44 < b)
																{
																	goto IL_1334_2;
																}
																goto IL_13d4_2;
																IL_1334_2:
																if (45 >= b)
																{
																	goto IL_133f_2;
																}
																goto IL_139f_2;
																IL_133f_2:
																if (45 > b)
																{
																	break;
																}
																goto IL_134d_2;
																IL_134d_2:
																array3[num6] = ((delegate*<Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																goto IL_1370_2;
																IL_1370_2:
																array2[num6] = 4;
																goto IL_137e_2;
																IL_137e_2:
																num6++;
																goto IL_138c_2;
																IL_138c_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_139f_2:
																if (46 < b)
																{
																	break;
																}
																goto IL_13ad_2;
																IL_13ad_2:
																if (46 > b)
																{
																	break;
																}
																goto IL_13bb_2;
																IL_13bb_2:
																array2[num6 - 2] = 4;
																goto IL_1990_2;
																IL_1990_2:
																array3[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]);
																goto IL_19e1_2;
																IL_19e1_2:
																num6--;
																goto IL_19ef_2;
																IL_19ef_2:
																ptr2 += 8;
																num = 19;
																goto end_IL_0aea_2;
																IL_13d4_2:
																if (44 > b)
																{
																	goto IL_13df_2;
																}
																goto IL_145a_2;
																IL_13df_2:
																if (43 < b)
																{
																	break;
																}
																goto IL_13ed_2;
																IL_13ed_2:
																if (43 > b)
																{
																	break;
																}
																goto IL_13fb_2;
																IL_13fb_2:
																array2[num6 - 1] = 5;
																goto IL_140f_2;
																IL_140f_2:
																array3[num6 - 1] = ((delegate*<Component, Transform>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 1]);
																goto IL_1447_2;
																IL_1447_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_145a_2:
																array2[num6 - 1] = 4;
																goto IL_146e_2;
																IL_146e_2:
																array3[num6 - 1] = ((delegate*<Transform, Vector3>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Transform)array3[num6 - 1]);
																goto IL_14ab_2;
																IL_14ab_2:
																ptr2 += 8;
																num = 378;
																goto end_IL_0aea_2;
																IL_174e_2:
																if (42 <= b)
																{
																	goto IL_1759_2;
																}
																goto IL_17a6_2;
																IL_1759_2:
																array3[num6] = ((delegate*<VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																goto IL_1777_2;
																IL_1777_2:
																array2[num6] = 5;
																goto IL_1785_2;
																IL_1785_2:
																num6++;
																goto IL_1793_2;
																IL_1793_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_17a6_2:
																if (40 >= b)
																{
																	goto IL_17b4_2;
																}
																goto IL_1887_2;
																IL_17b4_2:
																if (40 <= b)
																{
																	goto IL_17bf_2;
																}
																goto IL_181e_2;
																IL_17bf_2:
																array3[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																goto IL_17f7_2;
																IL_17f7_2:
																array2[num6 - 1] = 5;
																goto IL_180b_2;
																IL_180b_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_181e_2:
																if (39 < b)
																{
																	break;
																}
																goto IL_182c_2;
																IL_182c_2:
																if (39 > b)
																{
																	break;
																}
																goto IL_183a_2;
																IL_183a_2:
																array2[num6] = 5;
																goto IL_1848_2;
																IL_1848_2:
																array3[num6] = ((delegate*<GorillaTagger>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
																goto IL_1866_2;
																IL_1866_2:
																num6++;
																goto IL_1874_2;
																IL_1874_2:
																ptr2 += 8;
																goto end_IL_0aea_2;
																IL_1887_2:
																if (41 < b)
																{
																	break;
																}
																goto IL_1895_2;
																IL_1895_2:
																if (41 > b)
																{
																	break;
																}
																goto IL_18a3_2;
																IL_18a3_2:
																((delegate*<Behaviour, bool, void>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																num = 589;
																goto IL_18ea_2;
																IL_18ea_2:
																num6 -= 2;
																goto IL_18f8_2;
																IL_18f8_2:
																ptr2 += 8;
																num = 4;
																goto end_IL_0aea_2;
																IL_14c7_2:
																array2[num6 - 1] = 4;
																goto IL_14db_2;
															}
															break;
														}
														goto IL_1c52_2;
														IL_2db8_2:
														num6--;
														goto end_IL_0aea_2;
														IL_1c52_2:
														if (38 <= b)
														{
															goto IL_1c5d_2;
														}
														goto IL_1c79_2;
														IL_1c5d_2:
														num7 = ptr2;
														num8 = -200;
														num5 = 1;
														ptr2 = num7 + num8;
														goto end_IL_0aea_2;
														IL_1c79_2:
														if (19 >= b)
														{
															goto IL_1c87_2;
														}
														goto IL_25b7_2;
														IL_1c87_2:
														if (19 <= b)
														{
															goto IL_1c92_2;
														}
														goto IL_1cfa_2;
														IL_1c92_2:
														array2[num6 - 1] = 5;
														num = 348;
														goto IL_1caf_2;
														IL_1caf_2:
														array3[num6 - 1] = ((delegate*<string[], string>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_1ce7_2;
														IL_1ce7_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_1cfa_2:
														if (9 < b)
														{
															goto IL_1d08_2;
														}
														num = 488;
														goto IL_2192_2;
														IL_1d08_2:
														if (14 >= b)
														{
															goto IL_1d16_2;
														}
														goto IL_1fb4_2;
														IL_1d16_2:
														if (14 > b)
														{
															goto IL_1d24_2;
														}
														goto IL_1f6c_2;
														IL_1d24_2:
														if (11 >= b)
														{
															goto IL_1d32_2;
														}
														goto IL_1e5a_2;
														IL_1d32_2:
														if (11 <= b)
														{
															goto IL_1d40_2;
														}
														goto IL_1dc9_2;
														IL_1d40_2:
														array2[num6 - 2] = 0;
														goto IL_1d54_2;
														IL_1d54_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1da8_2;
														IL_1da8_2:
														num6--;
														goto IL_1db6_2;
														IL_1db6_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_1dc9_2:
														if (10 < b)
														{
															break;
														}
														goto IL_1dd7_2;
														IL_1dd7_2:
														if (10 > b)
														{
															break;
														}
														goto IL_1de5_2;
														IL_1de5_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1e47_2;
														IL_1e47_2:
														num6 -= 2;
														goto end_IL_0aea_2;
														IL_1e5a_2:
														if (12 >= b)
														{
															goto IL_1e65_2;
														}
														goto IL_1e78_2;
														IL_1e65_2:
														if (12 > b)
														{
															break;
														}
														goto end_IL_0aea_2;
														IL_1e78_2:
														if (13 < b)
														{
															break;
														}
														goto IL_1e86_2;
														IL_1e86_2:
														if (13 > b)
														{
															break;
														}
														goto IL_1e94_2;
														IL_1e94_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_1ea3_2;
														}
														goto IL_1eb1;
														IL_1f6c_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														num = 519;
														goto IL_1f93_2;
														IL_1f93_2:
														ptr2 += 8;
														goto IL_1fa1_2;
														IL_1fa1_2:
														num6--;
														goto end_IL_0aea_2;
														IL_1fb4_2:
														if (16 >= b)
														{
															goto IL_1fc2_2;
														}
														goto IL_20b3_2;
														IL_1fc2_2:
														if (16 <= b)
														{
															goto IL_1fd0_2;
														}
														goto IL_2055_2;
														IL_1fd0_2:
														array2[num6] = array2[num6 - 1];
														goto IL_1fe8_2;
														IL_1fe8_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_2006_2;
														IL_2006_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_202a_2;
														IL_202a_2:
														array3[num6] = array3[num6 - 1];
														goto IL_2042_2;
														IL_2042_2:
														num6++;
														goto end_IL_0aea_2;
														IL_2055_2:
														if (15 < b)
														{
															break;
														}
														goto IL_2063_2;
														IL_2063_2:
														if (15 > b)
														{
															break;
														}
														goto IL_2071_2;
														IL_2071_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_209a_2;
														IL_209a_2:
														array2[num6 - 1] = 5;
														goto end_IL_0aea_2;
														IL_20b3_2:
														if (17 >= b)
														{
															goto IL_20be_2;
														}
														goto IL_211c_2;
														IL_20be_2:
														if (17 > b)
														{
															break;
														}
														goto IL_20cc_2;
														IL_20cc_2:
														array2[num6] = 5;
														goto IL_20da_2;
														IL_20da_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_20f2_2;
														IL_20f2_2:
														num6++;
														num = 585;
														goto IL_2109_2;
														IL_2109_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_211c_2:
														if (18 < b)
														{
															break;
														}
														goto IL_212a_2;
														IL_212a_2:
														if (18 > b)
														{
															break;
														}
														goto IL_2138_2;
														IL_2138_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_2176_2;
														IL_2176_2:
														num6 -= 3;
														goto end_IL_0aea_2;
														IL_2dcb_2:
														if (37 < b)
														{
															break;
														}
														goto IL_2dd6_2;
														IL_2192_2:
														if (9 > b)
														{
															goto IL_21a0_2;
														}
														goto IL_2547_2;
														IL_21a0_2:
														if (4 < b)
														{
															goto IL_21ae_2;
														}
														num = 627;
														goto IL_238d_2;
														IL_21ae_2:
														if (6 >= b)
														{
															goto IL_21bc_2;
														}
														goto IL_22ba_2;
														IL_21bc_2:
														if (6 <= b)
														{
															goto IL_21c7_2;
														}
														goto IL_2237_2;
														IL_21c7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2207_2;
														IL_2207_2:
														array2[num6 - 2] = 0;
														num = 458;
														goto IL_2224_2;
														IL_2224_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2237_2:
														if (5 < b)
														{
															break;
														}
														goto IL_2245_2;
														IL_2245_2:
														if (5 > b)
														{
															break;
														}
														goto IL_2253_2;
														IL_2253_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2293_2;
														IL_2293_2:
														array2[num6 - 2] = 0;
														goto IL_22a7_2;
														IL_22a7_2:
														num6--;
														goto end_IL_0aea_2;
														IL_22ba_2:
														if (7 < b)
														{
															goto IL_22c5_2;
														}
														num = 25;
														goto IL_22fd_2;
														IL_22c5_2:
														if (8 < b)
														{
															break;
														}
														goto IL_22d3_2;
														IL_22d3_2:
														if (8 > b)
														{
															break;
														}
														goto IL_22e1_2;
														IL_22e1_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2de1_2:
														array2[num6 - 1] = 3;
														goto IL_2df5_2;
														IL_22fd_2:
														if (7 > b)
														{
															break;
														}
														goto IL_230b_2;
														IL_230b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 395;
														goto IL_2354_2;
														IL_2354_2:
														array2[num6 - 2] = 0;
														num = 408;
														goto IL_2371_2;
														IL_2371_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2dd6_2:
														if (37 > b)
														{
															break;
														}
														goto IL_2de1_2;
														IL_238d_2:
														if (4 <= b)
														{
															goto IL_2398_2;
														}
														goto IL_23f4_2;
														IL_2398_2:
														array2[num6] = 0;
														goto IL_23a6_2;
														IL_23a6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_23c9_2;
														IL_23c9_2:
														array3[num6] = null;
														goto IL_23d3_2;
														IL_23d3_2:
														num6++;
														goto IL_23e1_2;
														IL_23e1_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_23f4_2:
														if (2 >= b)
														{
															goto IL_2402_2;
														}
														goto IL_24e1_2;
														IL_2402_2:
														if (2 > b)
														{
															goto IL_240d_2;
														}
														goto IL_2471_2;
														IL_240d_2:
														if (1 < b)
														{
															break;
														}
														goto IL_241b_2;
														IL_241b_2:
														if (1 > b)
														{
															break;
														}
														goto IL_2429_2;
														IL_2429_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_2442_2;
														IL_2442_2:
														array2[num6] = 0;
														goto IL_2450_2;
														IL_2450_2:
														num6++;
														goto IL_245e_2;
														IL_245e_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2471_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_24b1_2;
														IL_24b1_2:
														array2[num6 - 2] = 0;
														goto IL_24c5_2;
														IL_24c5_2:
														num6--;
														num = 387;
														goto end_IL_0aea_2;
														IL_24e1_2:
														if (3 < b)
														{
															break;
														}
														goto IL_24ef_2;
														IL_24ef_2:
														if (3 > b)
														{
															break;
														}
														goto IL_24fd_2;
														IL_24fd_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2526_2;
														IL_2526_2:
														ptr2 += 8;
														goto IL_2534_2;
														IL_2534_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2547_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2587_2;
														IL_2587_2:
														array2[num6 - 2] = 0;
														goto IL_259b_2;
														IL_259b_2:
														num6--;
														num = 423;
														goto end_IL_0aea_2;
														IL_25b7_2:
														if (28 >= b)
														{
															goto IL_25c5_2;
														}
														goto IL_29b3_2;
														IL_25c5_2:
														if (28 > b)
														{
															goto IL_25d3_2;
														}
														goto IL_294d_2;
														IL_25d3_2:
														if (23 >= b)
														{
															goto IL_25e1_2;
														}
														goto IL_276a_2;
														IL_25e1_2:
														if (23 <= b)
														{
															goto IL_25ec_2;
														}
														goto IL_2651_2;
														IL_25ec_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_263e_2;
														IL_263e_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2651_2:
														if (21 >= b)
														{
															goto IL_265f_2;
														}
														goto IL_26e6_2;
														IL_265f_2:
														if (21 <= b)
														{
															goto IL_266a_2;
														}
														goto IL_2682_2;
														IL_266a_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto end_IL_0aea_2;
														IL_2682_2:
														if (20 < b)
														{
															break;
														}
														goto IL_2690_2;
														IL_2690_2:
														if (20 > b)
														{
															break;
														}
														goto IL_269e_2;
														IL_269e_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_26b7_2;
														IL_26b7_2:
														array2[num6] = 1;
														goto IL_26c5_2;
														IL_26c5_2:
														num6++;
														goto IL_26d3_2;
														IL_26d3_2:
														ptr2 += 16;
														goto end_IL_0aea_2;
														IL_26e6_2:
														if (22 < b)
														{
															break;
														}
														goto IL_26f4_2;
														IL_26f4_2:
														if (22 > b)
														{
															break;
														}
														goto IL_2702_2;
														IL_2702_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_2743_2;
														IL_2743_2:
														array2[num6 - 2] = 0;
														goto IL_2757_2;
														IL_2757_2:
														num6--;
														goto end_IL_0aea_2;
														IL_276a_2:
														if (25 >= b)
														{
															goto IL_2778_2;
														}
														goto IL_2856_2;
														IL_2778_2:
														if (25 <= b)
														{
															goto IL_2783_2;
														}
														goto IL_27e8_2;
														IL_2783_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														goto IL_27c1_2;
														IL_27c1_2:
														array2[num6 - 1] = 0;
														goto IL_27d5_2;
														IL_27d5_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_27e8_2:
														if (24 < b)
														{
															break;
														}
														goto IL_27f6_2;
														IL_27f6_2:
														if (24 > b)
														{
															break;
														}
														goto IL_2804_2;
														IL_2804_2:
														array3[num6] = ((delegate*<Class8.GunResult>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])();
														goto IL_2827_2;
														IL_2827_2:
														array2[num6] = 4;
														goto IL_2835_2;
														IL_2835_2:
														num6++;
														goto IL_2843_2;
														IL_2843_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2856_2:
														if (26 >= b)
														{
															goto IL_2861_2;
														}
														goto IL_28e0_2;
														IL_2861_2:
														if (26 > b)
														{
															break;
														}
														goto IL_286f_2;
														IL_286f_2:
														ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_28cd_2;
														IL_28cd_2:
														num6--;
														goto end_IL_0aea_2;
														IL_28e0_2:
														if (27 < b)
														{
															break;
														}
														goto IL_28ee_2;
														IL_28ee_2:
														if (27 > b)
														{
															break;
														}
														goto IL_28fc_2;
														IL_28fc_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_2915_2;
														IL_2915_2:
														array2[num6] = 3;
														goto IL_2923_2;
														IL_2923_2:
														num6++;
														num = 53;
														goto IL_293a_2;
														IL_293a_2:
														ptr2 += 16;
														goto end_IL_0aea_2;
														IL_294d_2:
														array2[num6 - 1] = 3;
														goto IL_2961_2;
														IL_2961_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_29a0_2;
														IL_29a0_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_29b3_2:
														if (33 >= b)
														{
															goto IL_29c1_2;
														}
														goto IL_2c30_2;
														IL_29c1_2:
														if (33 > b)
														{
															goto IL_29cf_2;
														}
														goto IL_2bc9_2;
														IL_29cf_2:
														if (30 >= b)
														{
															goto IL_29dd_2;
														}
														goto IL_2ad1_2;
														IL_29dd_2:
														if (30 <= b)
														{
															goto IL_29e8_2;
														}
														goto IL_2a4e_2;
														IL_29e8_2:
														array2[num6 - 1] = 0;
														goto IL_29fc_2;
														IL_29fc_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2a3b_2;
														IL_2a3b_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2a4e_2:
														if (29 < b)
														{
															break;
														}
														goto IL_2a5c_2;
														IL_2a5c_2:
														if (29 > b)
														{
															break;
														}
														goto IL_2a6a_2;
														IL_2a6a_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2aaa_2;
														IL_2aaa_2:
														array2[num6 - 2] = 3;
														goto IL_2abe_2;
														IL_2abe_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2ad1_2:
														if (31 >= b)
														{
															goto IL_2adc_2;
														}
														goto IL_2b49_2;
														IL_2adc_2:
														if (31 > b)
														{
															break;
														}
														goto IL_2aea_2;
														IL_2aea_2:
														array3[num6 - 1] = ((delegate*<Class8.GunResult, Player>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]);
														goto IL_2b22_2;
														IL_2b22_2:
														array2[num6 - 1] = 5;
														goto IL_2b36_2;
														IL_2b36_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2b49_2:
														if (32 < b)
														{
															break;
														}
														num = 407;
														goto IL_2b60_2;
														IL_2df5_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2e34_2;
														IL_2b60_2:
														if (32 > b)
														{
															break;
														}
														goto IL_2b6e_2;
														IL_2b6e_2:
														ptr2 = ((array3[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_2bb6_2;
														IL_2bb6_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2bc9_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_2c09_2;
														IL_2c09_2:
														array2[num6 - 2] = 3;
														goto IL_2c1d_2;
														IL_2c1d_2:
														num6--;
														goto end_IL_0aea_2;
														IL_2c30_2:
														if (35 >= b)
														{
															goto IL_2c3e_2;
														}
														goto IL_2d86_2;
														IL_2c3e_2:
														if (35 > b)
														{
															goto IL_2c49_2;
														}
														goto IL_2cc0_2;
														IL_2c49_2:
														if (34 < b)
														{
															break;
														}
														goto IL_2c57_2;
														IL_2c57_2:
														if (34 > b)
														{
															break;
														}
														num = 69;
														goto IL_2c6e_2;
														IL_2e34_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2c6e_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
														goto IL_2c88_2;
														IL_2c88_2:
														array2[num6] = 3;
														goto IL_2c96_2;
														IL_2c96_2:
														num6++;
														num = 309;
														goto IL_2cad_2;
														IL_2cad_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2cc0_2:
														array2[num6 - 5] = 4;
														goto IL_2cd4_2;
														IL_2cd4_2:
														array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)RegistryValueOptionsEventSource[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
														goto IL_2d65_2;
														IL_2d65_2:
														num6 -= 4;
														goto IL_2d73_2;
														IL_2d73_2:
														ptr2 += 8;
														goto end_IL_0aea_2;
														IL_2d86_2:
														if (36 >= b)
														{
															goto IL_2d91_2;
														}
														goto IL_2dcb_2;
														IL_2d91_2:
														if (36 > b)
														{
															break;
														}
														goto IL_2d9f_2;
														IL_2d9f_2:
														global::_003CModule_003E.gunResult_8 = (Class8.GunResult)array3[num6 - 1];
														goto IL_2db8_2;
													}
													break;
													IL_0ada_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											break;
											continue;
											end_IL_0aea_2:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_2e57_2:
								break;
							}
							break;
						}
						continue;
						end_IL_1f4b:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private void OnDisable()
	{
		smethod_9(this);
	}

	private unsafe void method_0()
	{
		int num = 109;
		int num5 = default(int);
		int num7 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								num = 58;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref YieldAwaiterContextCallback.KeyLengthgetFailure);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03ba:
																	if (b >= 1)
																	{
																		while (b <= 23)
																		{
																			while (true)
																			{
																				IL_039d:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_038d:
																						if (18 < b)
																						{
																							while (true)
																							{
																								IL_0380:
																								if (21 < b)
																								{
																									while (true)
																									{
																										IL_0373:
																										if (22 < b)
																										{
																											while (23 >= b)
																											{
																												num = 204;
																												while (true)
																												{
																													if (num != 204)
																													{
																														if (num != 1185)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 3:
																															goto IL_0360;
																														case 81:
																															goto IL_0373;
																														case 189:
																															goto IL_0380;
																														case 191:
																															goto IL_038d;
																														case 48:
																															goto IL_039d;
																														case 115:
																															goto IL_03aa;
																														case 140:
																															goto IL_03ba;
																														case 195:
																															goto end_IL_03ba;
																														case 11:
																														case 117:
																															goto end_IL_03ca;
																														case 0:
																															goto IL_03e5;
																														case 51:
																															goto IL_03f5;
																														case 85:
																															goto IL_0408;
																														case 13:
																														case 74:
																															goto IL_0413;
																														case 60:
																															goto IL_042c;
																														case 80:
																															goto IL_043a;
																														case 46:
																															goto IL_044d;
																														case 7:
																															goto IL_0458;
																														case 43:
																														case 113:
																															goto IL_046b;
																														case 63:
																															goto IL_047f;
																														case 132:
																															goto IL_04c3;
																														case 23:
																															goto IL_04d1;
																														case 106:
																															goto IL_04dc;
																														case 14:
																															goto IL_04ea;
																														case 36:
																															goto IL_04f5;
																														case 107:
																															goto IL_0508;
																														case 105:
																															goto IL_051f;
																														case 97:
																															goto IL_0532;
																														case 82:
																															goto IL_0540;
																														case 104:
																															goto IL_054e;
																														case 141:
																															goto IL_0561;
																														case 5:
																															goto IL_056f;
																														case 137:
																														case 142:
																															goto IL_0582;
																														case 143:
																															goto IL_059e;
																														case 126:
																															goto IL_05ac;
																														case 110:
																														case 118:
																															goto IL_05ba;
																														case 49:
																															goto IL_05ce;
																														case 52:
																															goto IL_060d;
																														case 18:
																														case 145:
																															goto IL_0620;
																														case 94:
																															goto IL_0660;
																														case 125:
																															goto IL_0674;
																														case 150:
																															goto IL_0687;
																														case 21:
																														case 152:
																															goto IL_069a;
																														case 134:
																														case 153:
																															goto IL_06df;
																														case 26:
																															goto IL_0741;
																														case 8:
																														case 158:
																															goto IL_0754;
																														case 61:
																															goto IL_077d;
																														case 136:
																															goto IL_078b;
																														case 163:
																															goto IL_079e;
																														case 70:
																														case 99:
																															goto IL_07a9;
																														case 37:
																															goto IL_07c2;
																														case 32:
																															goto IL_07d0;
																														case 159:
																															goto IL_07de;
																														case 29:
																															goto IL_07f1;
																														case 157:
																															goto IL_07ff;
																														case 24:
																															goto IL_080d;
																														case 123:
																															goto IL_0818;
																														case 34:
																														case 127:
																															goto IL_0826;
																														case 77:
																															goto IL_083e;
																														case 147:
																															goto IL_0855;
																														case 62:
																														case 151:
																															goto IL_0863;
																														case 30:
																															goto IL_08a4;
																														case 44:
																															goto IL_08b8;
																														case 31:
																														case 130:
																															goto IL_08d4;
																														case 12:
																															goto IL_0926;
																														case 170:
																															goto IL_0939;
																														case 41:
																														case 69:
																															goto IL_0944;
																														case 10:
																															goto IL_0989;
																														case 156:
																															goto IL_0994;
																														case 53:
																															goto IL_09a2;
																														case 20:
																														case 79:
																															goto IL_09b0;
																														case 162:
																															goto IL_09c3;
																														case 35:
																														case 101:
																															goto IL_09da;
																														case 172:
																															goto IL_0a1f;
																														case 90:
																														case 131:
																															goto IL_0a2d;
																														case 84:
																															goto IL_0a3b;
																														case 168:
																															goto IL_0a5e;
																														case 119:
																															goto IL_0a68;
																														case 1:
																															goto IL_0a76;
																														case 173:
																															goto IL_0a89;
																														case 174:
																														case 176:
																															goto IL_0a9c;
																														case 148:
																															goto IL_0ab5;
																														case 66:
																															goto IL_0ac3;
																														case 47:
																															goto IL_0ad1;
																														case 177:
																															goto IL_0ae4;
																														case 135:
																															goto IL_0af2;
																														case 22:
																														case 27:
																															goto IL_0b00;
																														case 181:
																															goto IL_0b40;
																														case 169:
																															goto IL_0b54;
																														case 182:
																															goto IL_0b67;
																														case 124:
																															goto IL_0b7b;
																														case 185:
																															goto IL_0b8e;
																														case 186:
																															goto IL_0ba1;
																														case 71:
																															goto IL_0bb5;
																														case 188:
																															goto IL_0bc8;
																														case 190:
																															goto IL_0bdb;
																														case 86:
																															goto IL_0bef;
																														case 67:
																														case 193:
																															goto IL_0c0b;
																														case 194:
																															goto IL_0c4b;
																														case 64:
																															goto IL_0c5f;
																														case 197:
																															goto IL_0c72;
																														case 55:
																															goto IL_0c7d;
																														case 6:
																														case 161:
																															goto IL_0c8b;
																														case 15:
																															goto IL_0ca3;
																														case 133:
																															goto IL_0cb1;
																														case 155:
																															goto IL_0cbf;
																														case 187:
																															goto IL_0cd2;
																														case 40:
																															goto IL_0cdd;
																														case 98:
																														case 139:
																															goto IL_0ce8;
																														case 184:
																															goto IL_0d11;
																														case 112:
																															goto IL_0d1f;
																														case 4:
																														case 17:
																														case 25:
																														case 28:
																														case 33:
																														case 45:
																														case 56:
																														case 72:
																														case 76:
																														case 87:
																														case 88:
																														case 89:
																														case 91:
																														case 92:
																														case 95:
																														case 96:
																														case 100:
																														case 103:
																														case 120:
																														case 122:
																														case 129:
																														case 138:
																														case 149:
																														case 164:
																														case 179:
																														case 192:
																															goto end_IL_034d;
																														case 2:
																														case 16:
																														case 38:
																														case 42:
																														case 50:
																														case 54:
																														case 59:
																														case 65:
																														case 68:
																														case 73:
																														case 75:
																														case 78:
																														case 83:
																														case 102:
																														case 111:
																														case 114:
																														case 128:
																														case 165:
																														case 166:
																														case 167:
																														case 171:
																														case 175:
																														case 178:
																														case 180:
																														case 183:
																														case 196:
																															goto end_IL_03da;
																														case 57:
																															goto end_IL_0d56;
																														case 121:
																															goto end_IL_0d69;
																														case 19:
																															goto end_IL_0d73;
																														case 9:
																															goto end_IL_0d7e;
																														case 58:
																															goto end_IL_0d8e;
																														case 144:
																														case 160:
																															goto end_IL_0d9e;
																														case 39:
																															goto end_IL_0dae;
																														case 93:
																															goto end_IL_0dc7;
																														case 146:
																															goto end_IL_0dd7;
																														case 108:
																															goto end_IL_0de7;
																														case 109:
																															goto end_IL_0df7;
																														case 116:
																														case 154:
																															return;
																														}
																														continue;
																													}
																													if (23 <= b)
																													{
																														num = 96;
																													}
																													break;
																													continue;
																													end_IL_034d:
																													break;
																												}
																												break;
																												IL_0360:;
																											}
																											break;
																										}
																										goto IL_03f5;
																										IL_0582:
																										byte* num6 = ptr2;
																										num5 = 1;
																										ptr2 = num6 + -200;
																										goto end_IL_03da;
																										IL_03f5:
																										if (22 > b)
																										{
																											break;
																										}
																										goto IL_0582;
																									}
																									break;
																								}
																								goto IL_03e5;
																								IL_0bc8:
																								ptr2 += 8;
																								goto end_IL_03da;
																								IL_03e5:
																								if (21 <= b)
																								{
																									goto IL_046b;
																								}
																								goto IL_059e;
																								IL_059e:
																								if (19 >= b)
																								{
																									goto IL_05ac;
																								}
																								goto IL_0ae4;
																								IL_05ac:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_05ba;
																								IL_05ba:
																								array[num7 - 1] = 3;
																								goto IL_05ce;
																								IL_05ce:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, double>)IIDENTITYAUTHORITYDEFINITIONIDENTITYTOTEXTFLAGCANONICALgetGlobalAssemblyCache[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
																								goto IL_060d;
																								IL_060d:
																								ptr2 += 8;
																								goto end_IL_03da;
																								IL_0ae4:
																								if (20 < b)
																								{
																									break;
																								}
																								goto IL_0af2;
																								IL_0af2:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_0b00;
																								IL_0b00:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																								goto IL_0b40;
																								IL_0b40:
																								array[num7 - 2] = 3;
																								goto IL_0b54;
																								IL_0b54:
																								num7--;
																								goto end_IL_03da;
																								IL_046b:
																								array[num7 - 1] = 0;
																								goto IL_047f;
																								IL_047f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, int>)IIDENTITYAUTHORITYDEFINITIONIDENTITYTOTEXTFLAGCANONICALgetGlobalAssemblyCache[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
																								goto IL_0bc8;
																							}
																							break;
																						}
																						goto IL_079e;
																						IL_0d11:
																						num7--;
																						goto IL_0d1f;
																						IL_079e:
																						if (18 <= b)
																						{
																							goto IL_07a9;
																						}
																						goto IL_07f1;
																						IL_07a9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(double*)(ptr2 + num4);
																						goto IL_07c2;
																						IL_07c2:
																						array[num7] = 3;
																						goto IL_07d0;
																						IL_07d0:
																						num7++;
																						goto IL_07de;
																						IL_07de:
																						ptr2 += 16;
																						goto end_IL_03da;
																						IL_07f1:
																						if (15 >= b)
																						{
																							goto IL_07ff;
																						}
																						goto IL_0c72;
																						IL_07ff:
																						if (15 > b)
																						{
																							goto IL_080d;
																						}
																						goto IL_08d4;
																						IL_080d:
																						if (13 >= b)
																						{
																							goto IL_0818;
																						}
																						goto IL_083e;
																						IL_0818:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_0826;
																						IL_0826:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_03da;
																						IL_083e:
																						if (14 < b)
																						{
																							break;
																						}
																						num = 147;
																						goto IL_0855;
																						IL_0d1f:
																						ptr2 += 8;
																						goto end_IL_03da;
																						IL_0855:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0863;
																						IL_0863:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0);
																						goto IL_08a4;
																						IL_08a4:
																						array[num7 - 2] = 0;
																						goto IL_08b8;
																						IL_08b8:
																						num7--;
																						num = 196;
																						goto end_IL_03da;
																						IL_08d4:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0926;
																						IL_0926:
																						num7--;
																						goto end_IL_03da;
																						IL_0c72:
																						if (16 >= b)
																						{
																							goto IL_0c7d;
																						}
																						goto IL_0cd2;
																						IL_0c7d:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_0c8b;
																						IL_0c8b:
																						array2[num7] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0ca3;
																						IL_0ca3:
																						array[num7] = 5;
																						goto IL_0cb1;
																						IL_0cb1:
																						num7++;
																						goto IL_0cbf;
																						IL_0cbf:
																						ptr2 += 8;
																						goto end_IL_03da;
																						IL_0cd2:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0cdd;
																						IL_0cdd:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0ce8;
																						IL_0ce8:
																						((delegate*<Class193, void>)IIDENTITYAUTHORITYDEFINITIONIDENTITYTOTEXTFLAGCANONICALgetGlobalAssemblyCache[*(int*)(ptr2 + num3)])((Class193)array2[num7 - 1]);
																						goto IL_0d11;
																					}
																					break;
																				}
																				goto IL_0408;
																				IL_0620:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0660;
																				IL_0408:
																				if (12 <= b)
																				{
																					goto IL_0413;
																				}
																				goto IL_044d;
																				IL_0413:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(long*)(ptr2 + num4);
																				goto IL_042c;
																				IL_042c:
																				array[num7] = 1;
																				goto IL_043a;
																				IL_043a:
																				num7++;
																				goto IL_0687;
																				IL_0687:
																				ptr2 += 16;
																				goto end_IL_03da;
																				IL_044d:
																				if (6 < b)
																				{
																					goto IL_0458;
																				}
																				goto IL_04c3;
																				IL_0458:
																				if (9 < b)
																				{
																					goto IL_0561;
																				}
																				goto IL_0939;
																				IL_0939:
																				if (9 <= b)
																				{
																					goto IL_0944;
																				}
																				goto IL_0989;
																				IL_0944:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0ba1;
																				IL_0ba1:
																				array[num7 - 2] = 0;
																				goto IL_0bb5;
																				IL_0bb5:
																				num7--;
																				goto end_IL_03da;
																				IL_0989:
																				if (7 < b)
																				{
																					goto IL_0994;
																				}
																				goto IL_09c3;
																				IL_0994:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_09a2;
																				IL_09a2:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_09b0;
																				IL_09b0:
																				num7--;
																				goto end_IL_03da;
																				IL_09c3:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 35;
																				goto IL_09da;
																				IL_0660:
																				array[num7 - 2] = 0;
																				goto IL_0674;
																				IL_09da:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0b67;
																				IL_0b67:
																				array[num7 - 2] = 0;
																				goto IL_0b7b;
																				IL_0b7b:
																				num7--;
																				goto end_IL_03da;
																				IL_0561:
																				if (10 >= b)
																				{
																					goto IL_056f;
																				}
																				goto IL_0a89;
																				IL_056f:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_06df;
																				IL_06df:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0741;
																				IL_0741:
																				num7 -= 2;
																				goto end_IL_03da;
																				IL_0a89:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0b8e;
																				IL_0b8e:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_03da;
																				IL_04c3:
																				if (6 > b)
																				{
																					goto IL_04d1;
																				}
																				goto IL_0620;
																				IL_04d1:
																				if (3 >= b)
																				{
																					goto IL_04dc;
																				}
																				goto IL_0532;
																				IL_04dc:
																				if (3 > b)
																				{
																					goto IL_04ea;
																				}
																				goto IL_0754;
																				IL_04ea:
																				if (1 >= b)
																				{
																					goto IL_04f5;
																				}
																				goto IL_0508;
																				IL_04f5:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0a9c;
																				IL_0a9c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(int*)(ptr2 + num3);
																				goto IL_0ab5;
																				IL_0ab5:
																				array[num7] = 0;
																				goto IL_0ac3;
																				IL_0ac3:
																				num7++;
																				goto IL_0ad1;
																				IL_0ad1:
																				ptr2 += 8;
																				goto end_IL_03da;
																				IL_0508:
																				if (2 < b)
																				{
																					break;
																				}
																				num = 105;
																				goto IL_051f;
																				IL_0674:
																				num7--;
																				goto end_IL_03da;
																				IL_051f:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0c0b;
																				IL_0c0b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0c4b;
																				IL_0c4b:
																				array[num7 - 2] = 0;
																				goto IL_0c5f;
																				IL_0c5f:
																				num7--;
																				goto end_IL_03da;
																				IL_0754:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_077d;
																				IL_077d:
																				ptr2 += 8;
																				goto IL_078b;
																				IL_078b:
																				num7--;
																				goto end_IL_03da;
																				IL_0532:
																				if (4 < b)
																				{
																					goto IL_0540;
																				}
																				goto IL_0a1f;
																				IL_0540:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_054e;
																				IL_054e:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_069a;
																				IL_069a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0bdb;
																				IL_0bdb:
																				array[num7 - 2] = 0;
																				goto IL_0bef;
																				IL_0bef:
																				num7--;
																				num = 178;
																				goto end_IL_03da;
																				IL_0a1f:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0a2d;
																				IL_0a2d:
																				array[num7] = 0;
																				goto IL_0a3b;
																				IL_0a3b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0a5e;
																				IL_0a5e:
																				array2[num7] = null;
																				goto IL_0a68;
																				IL_0a68:
																				num7++;
																				goto IL_0a76;
																				IL_0a76:
																				ptr2 += 8;
																				goto end_IL_03da;
																			}
																			break;
																			IL_03aa:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_03da;
																	continue;
																	end_IL_03ba:
																	break;
																}
																continue;
																end_IL_03ca:
																break;
															}
															continue;
															end_IL_03da:
															break;
														}
														continue;
														end_IL_0d56:
														break;
													}
													continue;
													end_IL_0d69:
													break;
												}
												continue;
												end_IL_0d73:
												break;
											}
											continue;
											end_IL_0d7e:
											break;
										}
										continue;
										end_IL_0d8e:
										break;
									}
									continue;
									end_IL_0d9e:
									break;
								}
								continue;
								end_IL_0dae:
								break;
							}
							continue;
							end_IL_0dc7:
							break;
						}
						continue;
						end_IL_0dd7:
						break;
					}
					continue;
					end_IL_0de7:
					break;
				}
				continue;
				end_IL_0df7:
				break;
			}
		}
	}

	private unsafe void method_1()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_0527, IL_053a, IL_054d, IL_0560, IL_0570, IL_0580, IL_0590, IL_059d, IL_05ad, IL_05bd, IL_05cd, IL_05dd, IL_05ed, IL_05f8, IL_0608, IL_0616, IL_0629, IL_0637, IL_0642, IL_064d, IL_0692, IL_06a2, IL_06b0, IL_06c3, IL_06d1, IL_06da, IL_0725, IL_0733, IL_0741, IL_0764, IL_0778, IL_078b, IL_079e, IL_07de, IL_07f7, IL_081e, IL_085e, IL_0872, IL_0885, IL_0893, IL_08a1, IL_08b4, IL_08c2, IL_08d9, IL_08ec, IL_0957, IL_096a, IL_0978, IL_098b, IL_0999, IL_09a7, IL_09b5, IL_09f5, IL_0a09, IL_0a1c, IL_0a33, IL_0a56, IL_0a69, IL_0a77, IL_0a8a, IL_0a9d, IL_0aab, IL_0ab9, IL_0ae2, IL_0af0, IL_0b03, IL_0b11, IL_0b1f, IL_0b38, IL_0b46, IL_0b54, IL_0b67, IL_0b7b, IL_0b8e, IL_0bb7, IL_0bd0, IL_0bed, IL_0c3c, IL_0c46, IL_0c73, IL_0c87, IL_0c95, IL_0ca8, IL_0cb6, IL_0cc1, IL_0ccf, IL_0ce7, IL_0cf5, IL_0d08, IL_0d16, IL_0d24, IL_0d3c, IL_0d5a, IL_0d7e, IL_0d96, IL_0da9, IL_0db4, IL_0dc2, IL_0e00, IL_0e13, IL_0e21, IL_0e2f, IL_0e38, IL_0e4c, IL_0e84, IL_0e97, IL_0ea5, IL_0eb0, IL_0ec4, IL_0f03, IL_0f16, IL_0f24, IL_0f32, IL_0f40, IL_0f4b, IL_0f8c, IL_0fa0, IL_0fbc, IL_0fca, IL_0fd8, IL_0ff0, IL_0ffe, IL_100c, IL_105e, IL_1071, IL_107f, IL_109d, IL_10ab, IL_10be, IL_10cc, IL_10da, IL_10e8, IL_10fc, IL_1149, IL_1157, IL_116a, IL_1178, IL_1186, IL_119f, IL_11ad, IL_11bb, IL_11ce, IL_11d7, IL_11e2, IL_11f0, IL_11fe, IL_1236, IL_124a, IL_125d, IL_1270, IL_127e, IL_1291, IL_129f, IL_12ad, IL_12c1, IL_130e, IL_131c, IL_1338, IL_1346, IL_1351, IL_1365, IL_13a4, IL_13b7, IL_13c5, IL_13d3, IL_1413, IL_1427, IL_143a, IL_1445, IL_1453, IL_1485, IL_1493, IL_14a6, IL_14b4, IL_14bd, IL_14cb, IL_14df, IL_1527, IL_153a, IL_1548, IL_1553, IL_1591, IL_159f, IL_15b2, IL_15c0, IL_15ce, IL_160e, IL_1622, IL_1632, IL_163d, IL_1648, IL_1661, IL_166c, IL_1677, IL_168a, IL_169d, IL_16a7, IL_16b2, IL_16c2, IL_16d2, IL_16e2, IL_16f2, IL_1702, IL_171b, IL_172b, IL_173b are reachable both inside and outside the pinned region starting at IL_1750. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 31;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef92 = default(int);
			ref int reference = ref __rxRef92;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_173b:
					num2 = 1;
					while (true)
					{
						IL_172b:
						num3 = num2 * 4;
						while (true)
						{
							IL_171b:
							num4 = num2 * 8;
							while (true)
							{
								IL_1702:
								array2 = new byte[4];
								num = 2;
								while (true)
								{
									IL_16f2:
									array3 = new object[4];
									while (true)
									{
										IL_16e2:
										array4 = new int[4];
										while (true)
										{
											IL_16d2:
											array5 = new int[7];
											while (true)
											{
												IL_16c2:
												array6 = new long[4];
												while (true)
												{
													IL_16b2:
													array7 = new object[8];
													while (true)
													{
														IL_16a7:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSectionNameContainsGenericParameters.AssemblyReferenceDependentAssemblyFlagsDequeue);
														while (true)
														{
															IL_169d:
															ptr2 = ptr;
															while (true)
															{
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_05ed:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_05dd:
																		ptr2++;
																		while (true)
																		{
																			IL_05cd:
																			if (b >= 1)
																			{
																				while (b <= 37)
																				{
																					while (true)
																					{
																						IL_05ad:
																						if (19 >= b)
																						{
																							while (true)
																							{
																								IL_059d:
																								if (19 > b)
																								{
																									while (true)
																									{
																										IL_0590:
																										if (9 < b)
																										{
																											while (true)
																											{
																												IL_0580:
																												if (14 >= b)
																												{
																													while (true)
																													{
																														IL_0570:
																														if (14 > b)
																														{
																															while (true)
																															{
																																IL_0560:
																																if (11 < b)
																																{
																																	while (true)
																																	{
																																		IL_054d:
																																		if (12 >= b)
																																		{
																																			num = 74;
																																			while (12 <= b)
																																			{
																																				num = 319;
																																				while (true)
																																				{
																																					if (num != 319)
																																					{
																																						if (num != 1300)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 31:
																																							break;
																																						default:
																																							continue;
																																						case 74:
																																							goto IL_053a;
																																						case 264:
																																							goto IL_054d;
																																						case 200:
																																							goto IL_0560;
																																						case 5:
																																							goto IL_0570;
																																						case 66:
																																							goto IL_0580;
																																						case 108:
																																							goto IL_0590;
																																						case 136:
																																							goto IL_059d;
																																						case 42:
																																							goto IL_05ad;
																																						case 169:
																																							goto IL_05bd;
																																						case 167:
																																							goto IL_05cd;
																																						case 283:
																																							goto IL_05dd;
																																						case 215:
																																						case 282:
																																							goto IL_05ed;
																																						case 81:
																																							goto IL_05f8;
																																						case 122:
																																							goto IL_0608;
																																						case 23:
																																							goto IL_0616;
																																						case 129:
																																							goto IL_0629;
																																						case 149:
																																							goto IL_0637;
																																						case 104:
																																							goto IL_0642;
																																						case 27:
																																						case 83:
																																							goto IL_064d;
																																						case 151:
																																							goto IL_0692;
																																						case 166:
																																							goto IL_06a2;
																																						case 84:
																																							goto IL_06b0;
																																						case 191:
																																							goto IL_06c3;
																																						case 28:
																																						case 194:
																																							goto IL_06da;
																																						case 202:
																																							goto IL_0725;
																																						case 198:
																																							goto IL_0733;
																																						case 72:
																																						case 195:
																																							goto IL_0741;
																																						case 209:
																																							goto IL_0764;
																																						case 124:
																																							goto IL_0778;
																																						case 230:
																																							goto IL_078b;
																																						case 188:
																																						case 238:
																																							goto IL_079e;
																																						case 128:
																																							goto IL_07de;
																																						case 147:
																																						case 257:
																																							goto IL_07f7;
																																						case 146:
																																						case 261:
																																							goto IL_081e;
																																						case 133:
																																							goto IL_085e;
																																						case 180:
																																							goto IL_0872;
																																						case 271:
																																							goto IL_0885;
																																						case 57:
																																							goto IL_0893;
																																						case 113:
																																						case 237:
																																							goto IL_08a1;
																																						case 276:
																																							goto IL_08b4;
																																						case 210:
																																							goto IL_08c2;
																																						case 203:
																																							goto IL_08d9;
																																						case 9:
																																						case 281:
																																							goto IL_08ec;
																																						case 6:
																																							goto IL_0957;
																																						case 289:
																																							goto IL_096a;
																																						case 224:
																																							goto IL_0978;
																																						case 294:
																																							goto IL_098b;
																																						case 25:
																																							goto IL_0999;
																																						case 102:
																																							goto IL_09a7;
																																						case 13:
																																						case 228:
																																							goto IL_09b5;
																																						case 248:
																																							goto IL_09f5;
																																						case 240:
																																							goto IL_0a09;
																																						case 131:
																																						case 277:
																																							goto IL_0a1c;
																																						case 252:
																																							goto IL_0a33;
																																						case 177:
																																							goto IL_0a56;
																																						case 185:
																																							goto IL_0a69;
																																						case 86:
																																							goto IL_0a77;
																																						case 298:
																																							goto IL_0a8a;
																																						case 301:
																																							goto IL_0a9d;
																																						case 212:
																																							goto IL_0aab;
																																						case 41:
																																						case 111:
																																							goto IL_0ab9;
																																						case 266:
																																							goto IL_0ae2;
																																						case 292:
																																							goto IL_0af0;
																																						case 302:
																																							goto IL_0b03;
																																						case 208:
																																							goto IL_0b11;
																																						case 53:
																																						case 300:
																																							goto IL_0b1f;
																																						case 29:
																																							goto IL_0b38;
																																						case 211:
																																							goto IL_0b46;
																																						case 157:
																																							goto IL_0b54;
																																						case 307:
																																							goto IL_0b67;
																																						case 62:
																																							goto IL_0b7b;
																																						case 218:
																																						case 311:
																																							goto IL_0b8e;
																																						case 75:
																																							goto IL_0bb7;
																																						case 270:
																																							goto IL_0bd0;
																																						case 297:
																																							goto IL_0c87;
																																						case 114:
																																							goto IL_0c95;
																																						case 304:
																																							goto IL_0ca8;
																																						case 286:
																																							goto IL_0cb6;
																																						case 98:
																																						case 231:
																																							goto IL_0cc1;
																																						case 8:
																																							goto IL_0ccf;
																																						case 96:
																																							goto IL_0ce7;
																																						case 82:
																																							goto IL_0cf5;
																																						case 109:
																																							goto IL_0d08;
																																						case 137:
																																							goto IL_0d16;
																																						case 99:
																																						case 197:
																																							goto IL_0d24;
																																						case 103:
																																							goto IL_0d3c;
																																						case 85:
																																							goto IL_0d5a;
																																						case 279:
																																							goto IL_0d7e;
																																						case 119:
																																							goto IL_0d96;
																																						case 144:
																																							goto IL_0da9;
																																						case 115:
																																							goto IL_0db4;
																																						case 10:
																																						case 39:
																																							goto IL_0dc2;
																																						case 48:
																																							goto IL_0e00;
																																						case 73:
																																							goto IL_0e13;
																																						case 213:
																																							goto IL_0e21;
																																						case 54:
																																						case 192:
																																							goto IL_0e38;
																																						case 101:
																																							goto IL_0e4c;
																																						case 221:
																																							goto IL_0e84;
																																						case 196:
																																							goto IL_0e97;
																																						case 186:
																																							goto IL_0ea5;
																																						case 7:
																																						case 181:
																																							goto IL_0eb0;
																																						case 36:
																																							goto IL_0ec4;
																																						case 285:
																																							goto IL_0f03;
																																						case 243:
																																							goto IL_0f16;
																																						case 170:
																																							goto IL_0f24;
																																						case 71:
																																							goto IL_0f32;
																																						case 229:
																																							goto IL_0f40;
																																						case 65:
																																						case 199:
																																							goto IL_0f4b;
																																						case 1:
																																							goto IL_0f8c;
																																						case 284:
																																							goto IL_0fa0;
																																						case 95:
																																							goto IL_0fbc;
																																						case 70:
																																							goto IL_0fca;
																																						case 120:
																																						case 125:
																																							goto IL_0fd8;
																																						case 4:
																																							goto IL_0ff0;
																																						case 61:
																																							goto IL_0ffe;
																																						case 24:
																																						case 268:
																																							goto IL_100c;
																																						case 14:
																																							goto IL_105e;
																																						case 274:
																																						case 275:
																																							goto IL_1071;
																																						case 91:
																																							goto IL_107f;
																																						case 310:
																																							goto IL_109d;
																																						case 88:
																																							goto IL_10ab;
																																						case 256:
																																							goto IL_10be;
																																						case 153:
																																							goto IL_10cc;
																																						case 100:
																																							goto IL_10da;
																																						case 242:
																																						case 309:
																																							goto IL_10e8;
																																						case 295:
																																							goto IL_10fc;
																																						case 18:
																																							goto IL_1149;
																																						case 262:
																																							goto IL_1157;
																																						case 3:
																																							goto IL_116a;
																																						case 21:
																																							goto IL_1178;
																																						case 50:
																																						case 227:
																																							goto IL_1186;
																																						case 299:
																																							goto IL_119f;
																																						case 172:
																																							goto IL_11ad;
																																						case 148:
																																							goto IL_11bb;
																																						case 290:
																																							goto IL_11d7;
																																						case 164:
																																							goto IL_11e2;
																																						case 43:
																																							goto IL_11f0;
																																						case 15:
																																						case 94:
																																							goto IL_11fe;
																																						case 154:
																																							goto IL_1236;
																																						case 150:
																																							goto IL_124a;
																																						case 118:
																																						case 160:
																																							goto IL_125d;
																																						case 87:
																																							goto IL_1270;
																																						case 296:
																																							goto IL_127e;
																																						case 135:
																																							goto IL_1291;
																																						case 97:
																																							goto IL_129f;
																																						case 175:
																																						case 269:
																																							goto IL_12ad;
																																						case 126:
																																							goto IL_12c1;
																																						case 251:
																																							goto IL_130e;
																																						case 123:
																																							goto IL_131c;
																																						case 214:
																																							goto IL_1338;
																																						case 207:
																																							goto IL_1346;
																																						case 139:
																																						case 143:
																																							goto IL_1351;
																																						case 204:
																																							goto IL_1365;
																																						case 245:
																																							goto IL_13a4;
																																						case 206:
																																							goto IL_13b7;
																																						case 93:
																																							goto IL_13c5;
																																						case 235:
																																						case 253:
																																							goto IL_13d3;
																																						case 89:
																																							goto IL_1413;
																																						case 193:
																																							goto IL_1427;
																																						case 34:
																																							goto IL_143a;
																																						case 45:
																																							goto IL_1445;
																																						case 106:
																																						case 187:
																																							goto IL_1453;
																																						case 267:
																																							goto IL_1485;
																																						case 32:
																																							goto IL_1493;
																																						case 90:
																																							goto IL_14a6;
																																						case 265:
																																							goto IL_14bd;
																																						case 67:
																																						case 76:
																																							goto IL_14cb;
																																						case 52:
																																							goto IL_14df;
																																						case 272:
																																							goto IL_1527;
																																						case 44:
																																							goto IL_153a;
																																						case 58:
																																							goto IL_1548;
																																						case 110:
																																						case 306:
																																							goto IL_1553;
																																						case 56:
																																							goto IL_1591;
																																						case 140:
																																							goto IL_159f;
																																						case 247:
																																							goto IL_15b2;
																																						case 121:
																																							goto IL_15c0;
																																						case 127:
																																						case 171:
																																							goto IL_15ce;
																																						case 303:
																																							goto IL_160e;
																																						case 20:
																																							goto IL_1622;
																																						case 241:
																																							goto IL_1632;
																																						case 77:
																																							goto IL_163d;
																																						case 80:
																																						case 201:
																																							goto IL_1648;
																																						case 158:
																																							goto IL_1661;
																																						case 156:
																																							goto IL_166c;
																																						case 0:
																																						case 11:
																																						case 16:
																																						case 17:
																																						case 19:
																																						case 35:
																																						case 37:
																																						case 40:
																																						case 47:
																																						case 49:
																																						case 63:
																																						case 64:
																																						case 78:
																																						case 92:
																																						case 105:
																																						case 107:
																																						case 112:
																																						case 116:
																																						case 134:
																																						case 161:
																																						case 162:
																																						case 173:
																																						case 176:
																																						case 182:
																																						case 184:
																																						case 189:
																																						case 190:
																																						case 219:
																																						case 225:
																																						case 233:
																																						case 250:
																																						case 255:
																																						case 258:
																																						case 259:
																																						case 273:
																																						case 278:
																																						case 280:
																																						case 287:
																																						case 288:
																																						case 312:
																																							goto end_IL_053a;
																																						case 12:
																																						case 22:
																																						case 26:
																																						case 38:
																																						case 46:
																																						case 51:
																																						case 55:
																																						case 59:
																																						case 60:
																																						case 68:
																																						case 79:
																																						case 117:
																																						case 130:
																																						case 141:
																																						case 145:
																																						case 155:
																																						case 163:
																																						case 165:
																																						case 168:
																																						case 174:
																																						case 178:
																																						case 205:
																																						case 216:
																																						case 217:
																																						case 220:
																																						case 222:
																																						case 226:
																																						case 232:
																																						case 234:
																																						case 236:
																																						case 239:
																																						case 244:
																																						case 246:
																																						case 249:
																																						case 254:
																																						case 260:
																																						case 263:
																																						case 291:
																																						case 293:
																																						case 308:
																																							goto end_IL_0527;
																																						case 152:
																																							goto IL_169d;
																																						case 305:
																																							goto IL_16a7;
																																						case 142:
																																							goto IL_16b2;
																																						case 223:
																																							goto IL_16c2;
																																						case 179:
																																							goto IL_16d2;
																																						case 33:
																																							goto IL_16e2;
																																						case 2:
																																							goto IL_16f2;
																																						case 138:
																																							goto IL_1702;
																																						case 69:
																																							goto IL_171b;
																																						case 183:
																																							goto IL_172b;
																																						case 30:
																																							goto IL_173b;
																																						case 132:
																																						case 159:
																																							return;
																																						}
																																						goto end_IL_168a;
																																					}
																																					goto IL_0bd0;
																																					IL_0c95:
																																					num6++;
																																					break;
																																					IL_0c87:
																																					array2[num6] = 5;
																																					goto IL_0c95;
																																					IL_0bd0:
																																					array8 = array3;
																																					num7 = num6;
																																					if (array == null)
																																					{
																																						goto IL_0bdf;
																																					}
																																					num8 = ptr2;
																																					byte b2 = *num8;
																																					ptr2 = num8 + 4;
																																					int num9 = *(int*)(ptr2 + num3);
																																					ptr2 += 8;
																																					byte* ptr3 = ptr2 + num9;
																																					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																																					while (ptr2 != ptr3)
																																					{
																																						*ptr4 = (byte)(*ptr2 ^ b2);
																																						ptr2++;
																																						ptr4++;
																																					}
																																					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																																					goto IL_0c87;
																																					continue;
																																					end_IL_0527:
																																					break;
																																				}
																																				goto end_IL_05cd;
																																				continue;
																																				end_IL_053a:
																																				break;
																																				IL_053a:;
																																			}
																																			break;
																																		}
																																		goto IL_0725;
																																		IL_096a:
																																		ptr2 += 8;
																																		goto IL_0978;
																																		IL_0978:
																																		num6--;
																																		goto end_IL_05cd;
																																		IL_0725:
																																		if (13 < b)
																																		{
																																			break;
																																		}
																																		goto IL_0733;
																																		IL_0733:
																																		if (13 > b)
																																		{
																																			break;
																																		}
																																		goto IL_0741;
																																		IL_0741:
																																		array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																		goto IL_096a;
																																	}
																																	break;
																																}
																																goto IL_0608;
																																IL_0957:
																																num6 -= 2;
																																goto end_IL_05cd;
																																IL_0608:
																																if (11 <= b)
																																{
																																	goto end_IL_05cd;
																																}
																																goto IL_0616;
																																IL_0616:
																																if (10 < b)
																																{
																																	break;
																																}
																																goto IL_078b;
																																IL_078b:
																																if (10 > b)
																																{
																																	break;
																																}
																																goto IL_08ec;
																																IL_08ec:
																																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																num = 6;
																																goto IL_0957;
																															}
																															break;
																														}
																														goto IL_0b8e;
																														IL_0bb7:
																														array2[num6 - 1] = 5;
																														goto end_IL_05cd;
																														IL_0b8e:
																														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														goto IL_0bb7;
																													}
																													break;
																												}
																												goto IL_0ca8;
																												IL_0e4c:
																												array3[num6 - 1] = ((delegate*<string[], string>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																												goto IL_0e84;
																												IL_0ca8:
																												if (16 >= b)
																												{
																													goto IL_0cb6;
																												}
																												goto IL_0da9;
																												IL_0cb6:
																												if (16 <= b)
																												{
																													goto IL_0cc1;
																												}
																												goto IL_0d08;
																												IL_0cc1:
																												array2[num6] = 5;
																												goto IL_0ccf;
																												IL_0ccf:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0ce7;
																												IL_0ce7:
																												num6++;
																												goto IL_0cf5;
																												IL_0cf5:
																												ptr2 += 8;
																												goto end_IL_05cd;
																												IL_0d08:
																												if (15 < b)
																												{
																													break;
																												}
																												goto IL_0d16;
																												IL_0d16:
																												if (15 > b)
																												{
																													break;
																												}
																												goto IL_0d24;
																												IL_0d24:
																												array2[num6] = array2[num6 - 1];
																												goto IL_0d3c;
																												IL_0d3c:
																												array4[num6 - 0] = array4[num6 - 1];
																												goto IL_0d5a;
																												IL_0d5a:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0d7e;
																												IL_0d7e:
																												array3[num6] = array3[num6 - 1];
																												goto IL_0d96;
																												IL_0d96:
																												num6++;
																												goto end_IL_05cd;
																												IL_0da9:
																												if (17 >= b)
																												{
																													goto IL_0db4;
																												}
																												goto IL_0e13;
																												IL_0db4:
																												if (17 > b)
																												{
																													break;
																												}
																												goto IL_0dc2;
																												IL_0dc2:
																												((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																												goto IL_0e00;
																												IL_0e00:
																												num6 -= 3;
																												goto end_IL_05cd;
																												IL_0e13:
																												if (18 < b)
																												{
																													break;
																												}
																												goto IL_0e21;
																												IL_0e21:
																												if (18 > b)
																												{
																													break;
																												}
																												num = 54;
																												goto IL_0e38;
																												IL_0e84:
																												ptr2 += 8;
																												goto end_IL_05cd;
																												IL_0e38:
																												array2[num6 - 1] = 5;
																												goto IL_0e4c;
																											}
																											break;
																										}
																										goto IL_05f8;
																										IL_0a69:
																										num6++;
																										goto IL_0a77;
																										IL_05f8:
																										if (9 > b)
																										{
																											goto IL_0629;
																										}
																										goto IL_081e;
																										IL_081e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_085e;
																										IL_085e:
																										array2[num6 - 2] = 0;
																										goto IL_0872;
																										IL_0872:
																										num6--;
																										goto end_IL_05cd;
																										IL_0629:
																										if (4 < b)
																										{
																											goto IL_0637;
																										}
																										goto IL_098b;
																										IL_0637:
																										if (6 >= b)
																										{
																											goto IL_0642;
																										}
																										goto IL_0692;
																										IL_0642:
																										if (6 <= b)
																										{
																											goto IL_064d;
																										}
																										goto IL_06a2;
																										IL_064d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0b67;
																										IL_0b67:
																										array2[num6 - 2] = 0;
																										goto IL_0b7b;
																										IL_0b7b:
																										num6--;
																										goto end_IL_05cd;
																										IL_06a2:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_06b0;
																										IL_06b0:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_079e;
																										IL_079e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_07de;
																										IL_07de:
																										array2[num6 - 2] = 0;
																										goto IL_0a8a;
																										IL_0a8a:
																										num6--;
																										goto end_IL_05cd;
																										IL_0692:
																										if (7 >= b)
																										{
																											goto IL_06c3;
																										}
																										goto IL_0885;
																										IL_06c3:
																										if (7 > b)
																										{
																											break;
																										}
																										num = 194;
																										goto IL_06da;
																										IL_0a77:
																										ptr2 += 8;
																										goto end_IL_05cd;
																										IL_06da:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										num = 209;
																										goto IL_0764;
																										IL_0764:
																										array2[num6 - 2] = 0;
																										goto IL_0778;
																										IL_0778:
																										num6--;
																										goto end_IL_05cd;
																										IL_0885:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0893;
																										IL_0893:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_08a1;
																										IL_08a1:
																										num6--;
																										goto end_IL_05cd;
																										IL_098b:
																										if (4 > b)
																										{
																											goto IL_0999;
																										}
																										goto IL_0a1c;
																										IL_0999:
																										if (2 >= b)
																										{
																											goto IL_09a7;
																										}
																										goto IL_0a9d;
																										IL_09a7:
																										if (2 <= b)
																										{
																											goto IL_09b5;
																										}
																										goto IL_0b03;
																										IL_09b5:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_09f5;
																										IL_09f5:
																										array2[num6 - 2] = 0;
																										goto IL_0a09;
																										IL_0a09:
																										num6--;
																										goto end_IL_05cd;
																										IL_0b03:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_0b11;
																										IL_0b11:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_0b1f;
																										IL_0b1f:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																										goto IL_0b38;
																										IL_0b38:
																										array2[num6] = 0;
																										goto IL_0b46;
																										IL_0b46:
																										num6++;
																										goto IL_0b54;
																										IL_0b54:
																										ptr2 += 8;
																										goto end_IL_05cd;
																										IL_0a9d:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_0aab;
																										IL_0aab:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0ab9;
																										IL_0ab9:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0ae2;
																										IL_0ae2:
																										ptr2 += 8;
																										goto IL_0af0;
																										IL_0af0:
																										num6--;
																										goto end_IL_05cd;
																										IL_0a1c:
																										array2[num6] = 0;
																										num = 252;
																										goto IL_0a33;
																										IL_0a33:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_0a56;
																										IL_0a56:
																										array3[num6] = null;
																										num = 185;
																										goto IL_0a69;
																									}
																									break;
																								}
																								goto IL_07f7;
																								IL_08d9:
																								ptr2 += 16;
																								goto end_IL_05cd;
																								IL_07f7:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								num = 276;
																								goto IL_08b4;
																								IL_08b4:
																								array2[num6] = 1;
																								goto IL_08c2;
																								IL_08c2:
																								num6++;
																								num = 203;
																								goto IL_08d9;
																							}
																							break;
																						}
																						goto IL_0e97;
																						IL_1648:
																						num10 = ptr2;
																						num11 = -200;
																						num5 = 1;
																						ptr2 = num10 + num11;
																						goto end_IL_05cd;
																						IL_0e97:
																						if (28 >= b)
																						{
																							goto IL_0ea5;
																						}
																						goto IL_1291;
																						IL_0ea5:
																						if (28 <= b)
																						{
																							goto IL_0eb0;
																						}
																						goto IL_0f16;
																						IL_0eb0:
																						array2[num6 - 1] = 3;
																						goto IL_0ec4;
																						IL_0ec4:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_0f03;
																						IL_0f03:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_0f16:
																						if (23 >= b)
																						{
																							goto IL_0f24;
																						}
																						goto IL_10be;
																						IL_0f24:
																						if (23 > b)
																						{
																							goto IL_0f32;
																						}
																						goto IL_1071;
																						IL_0f32:
																						if (21 >= b)
																						{
																							goto IL_0f40;
																						}
																						goto IL_0ff0;
																						IL_0f40:
																						if (21 <= b)
																						{
																							goto IL_0f4b;
																						}
																						goto IL_0fbc;
																						IL_0f4b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_0f8c;
																						IL_0f8c:
																						array2[num6 - 2] = 0;
																						goto IL_0fa0;
																						IL_0fa0:
																						num6--;
																						num = 234;
																						goto end_IL_05cd;
																						IL_0fbc:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_0fca;
																						IL_0fca:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0fd8;
																						IL_0fd8:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_05cd;
																						IL_0ff0:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_0ffe;
																						IL_0ffe:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_100c;
																						IL_100c:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_105e;
																						IL_105e:
																						num6--;
																						goto end_IL_05cd;
																						IL_1071:
																						array2[num6] = 5;
																						goto IL_107f;
																						IL_107f:
																						array3[num6] = ((delegate*<GorillaTagger>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])();
																						goto IL_109d;
																						IL_109d:
																						num6++;
																						goto IL_10ab;
																						IL_10ab:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_10be:
																						if (25 < b)
																						{
																							goto IL_10cc;
																						}
																						num = 290;
																						goto IL_11d7;
																						IL_10cc:
																						if (26 >= b)
																						{
																							goto IL_10da;
																						}
																						goto IL_116a;
																						IL_10da:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_10e8;
																						IL_10e8:
																						array2[num6 - 2] = 0;
																						goto IL_10fc;
																						IL_10fc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																						goto IL_1149;
																						IL_1149:
																						num6--;
																						goto IL_1157;
																						IL_1157:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_116a:
																						if (27 < b)
																						{
																							break;
																						}
																						goto IL_1178;
																						IL_1178:
																						if (27 > b)
																						{
																							break;
																						}
																						goto IL_1186;
																						IL_1186:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_119f;
																						IL_119f:
																						array2[num6] = 3;
																						goto IL_11ad;
																						IL_11ad:
																						num6++;
																						goto IL_11bb;
																						IL_11bb:
																						ptr2 += 16;
																						goto end_IL_05cd;
																						IL_1661:
																						if (37 < b)
																						{
																							break;
																						}
																						goto IL_166c;
																						IL_11d7:
																						if (25 > b)
																						{
																							goto IL_11e2;
																						}
																						goto IL_125d;
																						IL_11e2:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_11f0;
																						IL_11f0:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_11fe;
																						IL_11fe:
																						array3[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
																						goto IL_1236;
																						IL_1236:
																						array2[num6 - 1] = 5;
																						goto IL_124a;
																						IL_124a:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_125d:
																						array3[num6] = null;
																						num = 87;
																						goto IL_1270;
																						IL_1270:
																						array2[num6] = 5;
																						goto IL_127e;
																						IL_127e:
																						num6++;
																						goto end_IL_05cd;
																						IL_1291:
																						if (33 >= b)
																						{
																							goto IL_129f;
																						}
																						goto IL_153a;
																						IL_129f:
																						if (33 <= b)
																						{
																							goto IL_12ad;
																						}
																						goto IL_1338;
																						IL_12ad:
																						array2[num6 - 2] = 0;
																						goto IL_12c1;
																						IL_12c1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
																						goto IL_130e;
																						IL_130e:
																						num6--;
																						goto IL_131c;
																						IL_131c:
																						ptr2 += 8;
																						num = 246;
																						goto end_IL_05cd;
																						IL_1338:
																						if (30 >= b)
																						{
																							goto IL_1346;
																						}
																						goto IL_143a;
																						IL_1346:
																						if (30 <= b)
																						{
																							goto IL_1351;
																						}
																						goto IL_13b7;
																						IL_1351:
																						array2[num6 - 1] = 0;
																						goto IL_1365;
																						IL_1365:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_13a4;
																						IL_13a4:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_13b7:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_13c5;
																						IL_13c5:
																						if (29 > b)
																						{
																							break;
																						}
																						goto IL_13d3;
																						IL_13d3:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1413;
																						IL_1413:
																						array2[num6 - 2] = 3;
																						goto IL_1427;
																						IL_1427:
																						num6--;
																						goto end_IL_05cd;
																						IL_143a:
																						if (31 >= b)
																						{
																							goto IL_1445;
																						}
																						goto IL_14a6;
																						IL_1445:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_1453;
																						IL_1453:
																						((delegate*<string, void>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						num = 267;
																						goto IL_1485;
																						IL_1485:
																						num6--;
																						goto IL_1493;
																						IL_1493:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_14a6:
																						if (32 < b)
																						{
																							break;
																						}
																						num = 265;
																						goto IL_14bd;
																						IL_166c:
																						if (37 <= b)
																						{
																						}
																						break;
																						IL_14bd:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_14cb;
																						IL_14cb:
																						array2[num6 - 1] = 3;
																						goto IL_14df;
																						IL_14df:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						num = 272;
																						goto IL_1527;
																						IL_1527:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_153a:
																						if (35 >= b)
																						{
																							goto IL_1548;
																						}
																						goto IL_1632;
																						IL_1548:
																						if (35 <= b)
																						{
																							goto IL_1553;
																						}
																						goto IL_15b2;
																						IL_1553:
																						((delegate*<Behaviour, bool, void>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																						goto IL_1591;
																						IL_1591:
																						num6 -= 2;
																						goto IL_159f;
																						IL_159f:
																						ptr2 += 8;
																						goto end_IL_05cd;
																						IL_15b2:
																						if (34 < b)
																						{
																							break;
																						}
																						goto IL_15c0;
																						IL_15c0:
																						if (34 > b)
																						{
																							break;
																						}
																						goto IL_15ce;
																						IL_15ce:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_160e;
																						IL_160e:
																						array2[num6 - 2] = 3;
																						goto IL_1622;
																						IL_1622:
																						num6--;
																						goto end_IL_05cd;
																						IL_1632:
																						if (36 >= b)
																						{
																							goto IL_163d;
																						}
																						goto IL_1661;
																						IL_163d:
																						if (36 > b)
																						{
																							break;
																						}
																						goto IL_1648;
																					}
																					break;
																					IL_05bd:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			continue;
																			end_IL_05cd:
																			break;
																		}
																		break;
																	}
																	break;
																}
																continue;
																end_IL_168a:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0bdf:
			while (true)
			{
				IL_0bdf_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0c87_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0c95_2:
							num6++;
							while (true)
							{
								IL_168a_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									IL_05ed_2:
									byte b = *ptr2;
									while (true)
									{
										IL_05dd_2:
										ptr2++;
										while (true)
										{
											IL_05cd_2:
											if (b >= 1)
											{
												while (b <= 37)
												{
													while (true)
													{
														IL_05ad_2:
														if (19 >= b)
														{
															while (true)
															{
																IL_059d_2:
																if (19 > b)
																{
																	while (true)
																	{
																		IL_0590_2:
																		if (9 < b)
																		{
																			while (true)
																			{
																				IL_0580_2:
																				if (14 >= b)
																				{
																					while (true)
																					{
																						IL_0570_2:
																						if (14 > b)
																						{
																							while (true)
																							{
																								IL_0560_2:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_054d_2:
																										if (12 >= b)
																										{
																											num = 74;
																											while (12 <= b)
																											{
																												num = 319;
																												while (num != 319)
																												{
																													if (num != 1300)
																													{
																														goto IL_168a_2;
																													}
																													switch (num)
																													{
																													case 74:
																														goto IL_053a_2;
																													case 264:
																														goto IL_054d_2;
																													case 200:
																														goto IL_0560_2;
																													case 5:
																														goto IL_0570_2;
																													case 66:
																														goto IL_0580_2;
																													case 108:
																														goto IL_0590_2;
																													case 136:
																														goto IL_059d_2;
																													case 42:
																														goto IL_05ad_2;
																													case 169:
																														goto IL_05bd_2;
																													case 167:
																														goto IL_05cd_2;
																													case 283:
																														goto IL_05dd_2;
																													case 215:
																													case 282:
																														goto IL_05ed_2;
																													case 81:
																														goto IL_05f8_2;
																													case 122:
																														goto IL_0608_2;
																													case 23:
																														goto IL_0616_2;
																													case 129:
																														goto IL_0629_2;
																													case 149:
																														goto IL_0637_2;
																													case 104:
																														goto IL_0642_2;
																													case 27:
																													case 83:
																														goto IL_064d_2;
																													case 151:
																														goto IL_0692_2;
																													case 166:
																														goto IL_06a2_2;
																													case 84:
																														goto IL_06b0_2;
																													case 191:
																														goto IL_06c3_2;
																													case 28:
																													case 194:
																														goto IL_06da_2;
																													case 202:
																														goto IL_0725_2;
																													case 198:
																														goto IL_0733_2;
																													case 72:
																													case 195:
																														goto IL_0741_2;
																													case 209:
																														goto IL_0764_2;
																													case 124:
																														goto IL_0778_2;
																													case 230:
																														goto IL_078b_2;
																													case 188:
																													case 238:
																														goto IL_079e_2;
																													case 128:
																														goto IL_07de_2;
																													case 147:
																													case 257:
																														goto IL_07f7_2;
																													case 146:
																													case 261:
																														goto IL_081e_2;
																													case 133:
																														goto IL_085e_2;
																													case 180:
																														goto IL_0872_2;
																													case 271:
																														goto IL_0885_2;
																													case 57:
																														goto IL_0893_2;
																													case 113:
																													case 237:
																														goto IL_08a1_2;
																													case 276:
																														goto IL_08b4_2;
																													case 210:
																														goto IL_08c2_2;
																													case 203:
																														goto IL_08d9_2;
																													case 9:
																													case 281:
																														goto IL_08ec_2;
																													case 6:
																														goto IL_0957_2;
																													case 289:
																														goto IL_096a_2;
																													case 224:
																														goto IL_0978_2;
																													case 294:
																														goto IL_098b_2;
																													case 25:
																														goto IL_0999_2;
																													case 102:
																														goto IL_09a7_2;
																													case 13:
																													case 228:
																														goto IL_09b5_2;
																													case 248:
																														goto IL_09f5_2;
																													case 240:
																														goto IL_0a09_2;
																													case 131:
																													case 277:
																														goto IL_0a1c_2;
																													case 252:
																														goto IL_0a33_2;
																													case 177:
																														goto IL_0a56_2;
																													case 185:
																														goto IL_0a69_2;
																													case 86:
																														goto IL_0a77_2;
																													case 298:
																														goto IL_0a8a_2;
																													case 301:
																														goto IL_0a9d_2;
																													case 212:
																														goto IL_0aab_2;
																													case 41:
																													case 111:
																														goto IL_0ab9_2;
																													case 266:
																														goto IL_0ae2_2;
																													case 292:
																														goto IL_0af0_2;
																													case 302:
																														goto IL_0b03_2;
																													case 208:
																														goto IL_0b11_2;
																													case 53:
																													case 300:
																														goto IL_0b1f_2;
																													case 29:
																														goto IL_0b38_2;
																													case 211:
																														goto IL_0b46_2;
																													case 157:
																														goto IL_0b54_2;
																													case 307:
																														goto IL_0b67_2;
																													case 62:
																														goto IL_0b7b_2;
																													case 218:
																													case 311:
																														goto IL_0b8e_2;
																													case 75:
																														goto IL_0bb7_2;
																													case 270:
																														goto end_IL_0527_2;
																													case 297:
																														goto IL_0c87_2;
																													case 114:
																														goto IL_0c95_2;
																													case 304:
																														goto IL_0ca8_2;
																													case 286:
																														goto IL_0cb6_2;
																													case 98:
																													case 231:
																														goto IL_0cc1_2;
																													case 8:
																														goto IL_0ccf_2;
																													case 96:
																														goto IL_0ce7_2;
																													case 82:
																														goto IL_0cf5_2;
																													case 109:
																														goto IL_0d08_2;
																													case 137:
																														goto IL_0d16_2;
																													case 99:
																													case 197:
																														goto IL_0d24_2;
																													case 103:
																														goto IL_0d3c_2;
																													case 85:
																														goto IL_0d5a_2;
																													case 279:
																														goto IL_0d7e_2;
																													case 119:
																														goto IL_0d96_2;
																													case 144:
																														goto IL_0da9_2;
																													case 115:
																														goto IL_0db4_2;
																													case 10:
																													case 39:
																														goto IL_0dc2_2;
																													case 48:
																														goto IL_0e00_2;
																													case 73:
																														goto IL_0e13_2;
																													case 213:
																														goto IL_0e21_2;
																													case 54:
																													case 192:
																														goto IL_0e38_2;
																													case 101:
																														goto IL_0e4c_2;
																													case 221:
																														goto IL_0e84_2;
																													case 196:
																														goto IL_0e97_2;
																													case 186:
																														goto IL_0ea5_2;
																													case 7:
																													case 181:
																														goto IL_0eb0_2;
																													case 36:
																														goto IL_0ec4_2;
																													case 285:
																														goto IL_0f03_2;
																													case 243:
																														goto IL_0f16_2;
																													case 170:
																														goto IL_0f24_2;
																													case 71:
																														goto IL_0f32_2;
																													case 229:
																														goto IL_0f40_2;
																													case 65:
																													case 199:
																														goto IL_0f4b_2;
																													case 1:
																														goto IL_0f8c_2;
																													case 284:
																														goto IL_0fa0_2;
																													case 95:
																														goto IL_0fbc_2;
																													case 70:
																														goto IL_0fca_2;
																													case 120:
																													case 125:
																														goto IL_0fd8_2;
																													case 4:
																														goto IL_0ff0_2;
																													case 61:
																														goto IL_0ffe_2;
																													case 24:
																													case 268:
																														goto IL_100c_2;
																													case 14:
																														goto IL_105e_2;
																													case 274:
																													case 275:
																														goto IL_1071_2;
																													case 91:
																														goto IL_107f_2;
																													case 310:
																														goto IL_109d_2;
																													case 88:
																														goto IL_10ab_2;
																													case 256:
																														goto IL_10be_2;
																													case 153:
																														goto IL_10cc_2;
																													case 100:
																														goto IL_10da_2;
																													case 242:
																													case 309:
																														goto IL_10e8_2;
																													case 295:
																														goto IL_10fc_2;
																													case 18:
																														goto IL_1149_2;
																													case 262:
																														goto IL_1157_2;
																													case 3:
																														goto IL_116a_2;
																													case 21:
																														goto IL_1178_2;
																													case 50:
																													case 227:
																														goto IL_1186_2;
																													case 299:
																														goto IL_119f_2;
																													case 172:
																														goto IL_11ad_2;
																													case 148:
																														goto IL_11bb_2;
																													case 290:
																														goto IL_11d7_2;
																													case 164:
																														goto IL_11e2_2;
																													case 43:
																														goto IL_11f0_2;
																													case 15:
																													case 94:
																														goto IL_11fe_2;
																													case 154:
																														goto IL_1236_2;
																													case 150:
																														goto IL_124a_2;
																													case 118:
																													case 160:
																														goto IL_125d_2;
																													case 87:
																														goto IL_1270_2;
																													case 296:
																														goto IL_127e_2;
																													case 135:
																														goto IL_1291_2;
																													case 97:
																														goto IL_129f_2;
																													case 175:
																													case 269:
																														goto IL_12ad_2;
																													case 126:
																														goto IL_12c1_2;
																													case 251:
																														goto IL_130e_2;
																													case 123:
																														goto IL_131c_2;
																													case 214:
																														goto IL_1338_2;
																													case 207:
																														goto IL_1346_2;
																													case 139:
																													case 143:
																														goto IL_1351_2;
																													case 204:
																														goto IL_1365_2;
																													case 245:
																														goto IL_13a4_2;
																													case 206:
																														goto IL_13b7_2;
																													case 93:
																														goto IL_13c5_2;
																													case 235:
																													case 253:
																														goto IL_13d3_2;
																													case 89:
																														goto IL_1413_2;
																													case 193:
																														goto IL_1427_2;
																													case 34:
																														goto IL_143a_2;
																													case 45:
																														goto IL_1445_2;
																													case 106:
																													case 187:
																														goto IL_1453_2;
																													case 267:
																														goto IL_1485_2;
																													case 32:
																														goto IL_1493_2;
																													case 90:
																														goto IL_14a6_2;
																													case 265:
																														goto IL_14bd_2;
																													case 67:
																													case 76:
																														goto IL_14cb_2;
																													case 52:
																														goto IL_14df_2;
																													case 272:
																														goto IL_1527_2;
																													case 44:
																														goto IL_153a_2;
																													case 58:
																														goto IL_1548_2;
																													case 110:
																													case 306:
																														goto IL_1553_2;
																													case 56:
																														goto IL_1591_2;
																													case 140:
																														goto IL_159f_2;
																													case 247:
																														goto IL_15b2_2;
																													case 121:
																														goto IL_15c0_2;
																													case 127:
																													case 171:
																														goto IL_15ce_2;
																													case 303:
																														goto IL_160e_2;
																													case 20:
																														goto IL_1622_2;
																													case 241:
																														goto IL_1632_2;
																													case 77:
																														goto IL_163d_2;
																													case 80:
																													case 201:
																														goto IL_1648_2;
																													case 158:
																														goto IL_1661_2;
																													case 156:
																														goto IL_166c_2;
																													case 0:
																													case 11:
																													case 16:
																													case 17:
																													case 19:
																													case 35:
																													case 37:
																													case 40:
																													case 47:
																													case 49:
																													case 63:
																													case 64:
																													case 78:
																													case 92:
																													case 105:
																													case 107:
																													case 112:
																													case 116:
																													case 134:
																													case 161:
																													case 162:
																													case 173:
																													case 176:
																													case 182:
																													case 184:
																													case 189:
																													case 190:
																													case 219:
																													case 225:
																													case 233:
																													case 250:
																													case 255:
																													case 258:
																													case 259:
																													case 273:
																													case 278:
																													case 280:
																													case 287:
																													case 288:
																													case 312:
																														goto end_IL_053a_2;
																													case 12:
																													case 22:
																													case 26:
																													case 38:
																													case 46:
																													case 51:
																													case 55:
																													case 59:
																													case 60:
																													case 68:
																													case 79:
																													case 117:
																													case 130:
																													case 141:
																													case 145:
																													case 155:
																													case 163:
																													case 165:
																													case 168:
																													case 174:
																													case 178:
																													case 205:
																													case 216:
																													case 217:
																													case 220:
																													case 222:
																													case 226:
																													case 232:
																													case 234:
																													case 236:
																													case 239:
																													case 244:
																													case 246:
																													case 249:
																													case 254:
																													case 260:
																													case 263:
																													case 291:
																													case 293:
																													case 308:
																														goto IL_168a_2;
																													case 152:
																														ptr2 = ptr;
																														goto IL_168a_2;
																													case 305:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSectionNameContainsGenericParameters.AssemblyReferenceDependentAssemblyFlagsDequeue);
																														goto case 152;
																													case 142:
																														array7 = new object[8];
																														goto case 305;
																													case 223:
																														array6 = new long[4];
																														goto case 142;
																													case 179:
																														array5 = new int[7];
																														goto case 223;
																													case 33:
																														array4 = new int[4];
																														goto case 179;
																													case 2:
																														array3 = new object[4];
																														goto case 33;
																													case 138:
																														array2 = new byte[4];
																														num = 2;
																														goto case 2;
																													case 69:
																														num4 = num2 * 8;
																														goto case 138;
																													case 183:
																														num3 = num2 * 4;
																														goto case 69;
																													case 30:
																														num2 = 1;
																														goto case 183;
																													case 31:
																														goto end_IL_0bed;
																													case 132:
																													case 159:
																														return;
																													}
																													continue;
																													end_IL_0527_2:
																													break;
																												}
																												goto end_IL_05cd_2;
																												continue;
																												end_IL_053a_2:
																												break;
																												IL_053a_2:;
																											}
																											break;
																										}
																										goto IL_0725_2;
																										IL_096a_2:
																										ptr2 += 8;
																										goto IL_0978_2;
																										IL_0978_2:
																										num6--;
																										goto IL_168a_2;
																										IL_0725_2:
																										if (13 < b)
																										{
																											break;
																										}
																										goto IL_0733_2;
																										IL_0733_2:
																										if (13 > b)
																										{
																											break;
																										}
																										goto IL_0741_2;
																										IL_0741_2:
																										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										goto IL_096a_2;
																									}
																									break;
																								}
																								goto IL_0608_2;
																								IL_0957_2:
																								num6 -= 2;
																								goto IL_168a_2;
																								IL_0608_2:
																								if (11 <= b)
																								{
																									goto IL_168a_2;
																								}
																								goto IL_0616_2;
																								IL_0616_2:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_078b_2;
																								IL_078b_2:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_08ec_2;
																								IL_08ec_2:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								num = 6;
																								goto IL_0957_2;
																							}
																							break;
																						}
																						goto IL_0b8e_2;
																						IL_0bb7_2:
																						array2[num6 - 1] = 5;
																						goto IL_168a_2;
																						IL_0b8e_2:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_0bb7_2;
																					}
																					break;
																				}
																				goto IL_0ca8_2;
																				IL_0e4c_2:
																				array3[num6 - 1] = ((delegate*<string[], string>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																				goto IL_0e84_2;
																				IL_0ca8_2:
																				if (16 >= b)
																				{
																					goto IL_0cb6_2;
																				}
																				goto IL_0da9_2;
																				IL_0cb6_2:
																				if (16 <= b)
																				{
																					goto IL_0cc1_2;
																				}
																				goto IL_0d08_2;
																				IL_0cc1_2:
																				array2[num6] = 5;
																				goto IL_0ccf_2;
																				IL_0ccf_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0ce7_2;
																				IL_0ce7_2:
																				num6++;
																				goto IL_0cf5_2;
																				IL_0cf5_2:
																				ptr2 += 8;
																				goto IL_168a_2;
																				IL_0d08_2:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_0d16_2;
																				IL_0d16_2:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0d24_2;
																				IL_0d24_2:
																				array2[num6] = array2[num6 - 1];
																				goto IL_0d3c_2;
																				IL_0d3c_2:
																				array4[num6 - 0] = array4[num6 - 1];
																				goto IL_0d5a_2;
																				IL_0d5a_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0d7e_2;
																				IL_0d7e_2:
																				array3[num6] = array3[num6 - 1];
																				goto IL_0d96_2;
																				IL_0d96_2:
																				num6++;
																				goto IL_168a_2;
																				IL_0da9_2:
																				if (17 >= b)
																				{
																					goto IL_0db4_2;
																				}
																				goto IL_0e13_2;
																				IL_0db4_2:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_0dc2_2;
																				IL_0dc2_2:
																				((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																				goto IL_0e00_2;
																				IL_0e00_2:
																				num6 -= 3;
																				goto IL_168a_2;
																				IL_0e13_2:
																				if (18 < b)
																				{
																					break;
																				}
																				goto IL_0e21_2;
																				IL_0e21_2:
																				if (18 > b)
																				{
																					break;
																				}
																				num = 54;
																				goto IL_0e38_2;
																				IL_0e84_2:
																				ptr2 += 8;
																				goto IL_168a_2;
																				IL_0e38_2:
																				array2[num6 - 1] = 5;
																				goto IL_0e4c_2;
																			}
																			break;
																		}
																		goto IL_05f8_2;
																		IL_0a69_2:
																		num6++;
																		goto IL_0a77_2;
																		IL_05f8_2:
																		if (9 > b)
																		{
																			goto IL_0629_2;
																		}
																		goto IL_081e_2;
																		IL_081e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_085e_2;
																		IL_085e_2:
																		array2[num6 - 2] = 0;
																		goto IL_0872_2;
																		IL_0872_2:
																		num6--;
																		goto IL_168a_2;
																		IL_0629_2:
																		if (4 < b)
																		{
																			goto IL_0637_2;
																		}
																		goto IL_098b_2;
																		IL_0637_2:
																		if (6 >= b)
																		{
																			goto IL_0642_2;
																		}
																		goto IL_0692_2;
																		IL_0642_2:
																		if (6 <= b)
																		{
																			goto IL_064d_2;
																		}
																		goto IL_06a2_2;
																		IL_064d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b67_2;
																		IL_0b67_2:
																		array2[num6 - 2] = 0;
																		goto IL_0b7b_2;
																		IL_0b7b_2:
																		num6--;
																		goto IL_168a_2;
																		IL_06a2_2:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_06b0_2;
																		IL_06b0_2:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_079e_2;
																		IL_079e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_07de_2;
																		IL_07de_2:
																		array2[num6 - 2] = 0;
																		goto IL_0a8a_2;
																		IL_0a8a_2:
																		num6--;
																		goto IL_168a_2;
																		IL_0692_2:
																		if (7 >= b)
																		{
																			goto IL_06c3_2;
																		}
																		goto IL_0885_2;
																		IL_06c3_2:
																		if (7 > b)
																		{
																			break;
																		}
																		num = 194;
																		goto IL_06da_2;
																		IL_0a77_2:
																		ptr2 += 8;
																		goto IL_168a_2;
																		IL_06da_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 209;
																		goto IL_0764_2;
																		IL_0764_2:
																		array2[num6 - 2] = 0;
																		goto IL_0778_2;
																		IL_0778_2:
																		num6--;
																		goto IL_168a_2;
																		IL_0885_2:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_0893_2;
																		IL_0893_2:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_08a1_2;
																		IL_08a1_2:
																		num6--;
																		goto IL_168a_2;
																		IL_098b_2:
																		if (4 > b)
																		{
																			goto IL_0999_2;
																		}
																		goto IL_0a1c_2;
																		IL_0999_2:
																		if (2 >= b)
																		{
																			goto IL_09a7_2;
																		}
																		goto IL_0a9d_2;
																		IL_09a7_2:
																		if (2 <= b)
																		{
																			goto IL_09b5_2;
																		}
																		goto IL_0b03_2;
																		IL_09b5_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_09f5_2;
																		IL_09f5_2:
																		array2[num6 - 2] = 0;
																		goto IL_0a09_2;
																		IL_0a09_2:
																		num6--;
																		goto IL_168a_2;
																		IL_0b03_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0b11_2;
																		IL_0b11_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_0b1f_2;
																		IL_0b1f_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0b38_2;
																		IL_0b38_2:
																		array2[num6] = 0;
																		goto IL_0b46_2;
																		IL_0b46_2:
																		num6++;
																		goto IL_0b54_2;
																		IL_0b54_2:
																		ptr2 += 8;
																		goto IL_168a_2;
																		IL_0a9d_2:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_0aab_2;
																		IL_0aab_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0ab9_2;
																		IL_0ab9_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0ae2_2;
																		IL_0ae2_2:
																		ptr2 += 8;
																		goto IL_0af0_2;
																		IL_0af0_2:
																		num6--;
																		goto IL_168a_2;
																		IL_0a1c_2:
																		array2[num6] = 0;
																		num = 252;
																		goto IL_0a33_2;
																		IL_0a33_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_0a56_2;
																		IL_0a56_2:
																		array3[num6] = null;
																		num = 185;
																		goto IL_0a69_2;
																	}
																	break;
																}
																goto IL_07f7_2;
																IL_08d9_2:
																ptr2 += 16;
																goto IL_168a_2;
																IL_07f7_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																num = 276;
																goto IL_08b4_2;
																IL_08b4_2:
																array2[num6] = 1;
																goto IL_08c2_2;
																IL_08c2_2:
																num6++;
																num = 203;
																goto IL_08d9_2;
															}
															break;
														}
														goto IL_0e97_2;
														IL_1648_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_168a_2;
														IL_0e97_2:
														if (28 >= b)
														{
															goto IL_0ea5_2;
														}
														goto IL_1291_2;
														IL_0ea5_2:
														if (28 <= b)
														{
															goto IL_0eb0_2;
														}
														goto IL_0f16_2;
														IL_0eb0_2:
														array2[num6 - 1] = 3;
														goto IL_0ec4_2;
														IL_0ec4_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_0f03_2;
														IL_0f03_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_0f16_2:
														if (23 >= b)
														{
															goto IL_0f24_2;
														}
														goto IL_10be_2;
														IL_0f24_2:
														if (23 > b)
														{
															goto IL_0f32_2;
														}
														goto IL_1071_2;
														IL_0f32_2:
														if (21 >= b)
														{
															goto IL_0f40_2;
														}
														goto IL_0ff0_2;
														IL_0f40_2:
														if (21 <= b)
														{
															goto IL_0f4b_2;
														}
														goto IL_0fbc_2;
														IL_0f4b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_0f8c_2;
														IL_0f8c_2:
														array2[num6 - 2] = 0;
														goto IL_0fa0_2;
														IL_0fa0_2:
														num6--;
														num = 234;
														goto IL_168a_2;
														IL_0fbc_2:
														if (20 < b)
														{
															break;
														}
														goto IL_0fca_2;
														IL_0fca_2:
														if (20 > b)
														{
															break;
														}
														goto IL_0fd8_2;
														IL_0fd8_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_168a_2;
														IL_0ff0_2:
														if (22 < b)
														{
															break;
														}
														goto IL_0ffe_2;
														IL_0ffe_2:
														if (22 > b)
														{
															break;
														}
														goto IL_100c_2;
														IL_100c_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_105e_2;
														IL_105e_2:
														num6--;
														goto IL_168a_2;
														IL_1071_2:
														array2[num6] = 5;
														goto IL_107f_2;
														IL_107f_2:
														array3[num6] = ((delegate*<GorillaTagger>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])();
														goto IL_109d_2;
														IL_109d_2:
														num6++;
														goto IL_10ab_2;
														IL_10ab_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_10be_2:
														if (25 < b)
														{
															goto IL_10cc_2;
														}
														num = 290;
														goto IL_11d7_2;
														IL_10cc_2:
														if (26 >= b)
														{
															goto IL_10da_2;
														}
														goto IL_116a_2;
														IL_10da_2:
														if (26 > b)
														{
															break;
														}
														goto IL_10e8_2;
														IL_10e8_2:
														array2[num6 - 2] = 0;
														goto IL_10fc_2;
														IL_10fc_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														goto IL_1149_2;
														IL_1149_2:
														num6--;
														goto IL_1157_2;
														IL_1157_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_116a_2:
														if (27 < b)
														{
															break;
														}
														goto IL_1178_2;
														IL_1178_2:
														if (27 > b)
														{
															break;
														}
														goto IL_1186_2;
														IL_1186_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_119f_2;
														IL_119f_2:
														array2[num6] = 3;
														goto IL_11ad_2;
														IL_11ad_2:
														num6++;
														goto IL_11bb_2;
														IL_11bb_2:
														ptr2 += 16;
														goto IL_168a_2;
														IL_1661_2:
														if (37 < b)
														{
															break;
														}
														goto IL_166c_2;
														IL_11d7_2:
														if (25 > b)
														{
															goto IL_11e2_2;
														}
														goto IL_125d_2;
														IL_11e2_2:
														if (24 < b)
														{
															break;
														}
														goto IL_11f0_2;
														IL_11f0_2:
														if (24 > b)
														{
															break;
														}
														goto IL_11fe_2;
														IL_11fe_2:
														array3[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 1]);
														goto IL_1236_2;
														IL_1236_2:
														array2[num6 - 1] = 5;
														goto IL_124a_2;
														IL_124a_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_125d_2:
														array3[num6] = null;
														num = 87;
														goto IL_1270_2;
														IL_1270_2:
														array2[num6] = 5;
														goto IL_127e_2;
														IL_127e_2:
														num6++;
														goto IL_168a_2;
														IL_1291_2:
														if (33 >= b)
														{
															goto IL_129f_2;
														}
														goto IL_153a_2;
														IL_129f_2:
														if (33 <= b)
														{
															goto IL_12ad_2;
														}
														goto IL_1338_2;
														IL_12ad_2:
														array2[num6 - 2] = 0;
														goto IL_12c1_2;
														IL_12c1_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((GorillaTagger)array3[num6 - 2], (UnityEngine.Object)array3[num6 - 1]) ? 1 : 0);
														goto IL_130e_2;
														IL_130e_2:
														num6--;
														goto IL_131c_2;
														IL_131c_2:
														ptr2 += 8;
														num = 246;
														goto IL_168a_2;
														IL_1338_2:
														if (30 >= b)
														{
															goto IL_1346_2;
														}
														goto IL_143a_2;
														IL_1346_2:
														if (30 <= b)
														{
															goto IL_1351_2;
														}
														goto IL_13b7_2;
														IL_1351_2:
														array2[num6 - 1] = 0;
														goto IL_1365_2;
														IL_1365_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_13a4_2;
														IL_13a4_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_13b7_2:
														if (29 < b)
														{
															break;
														}
														goto IL_13c5_2;
														IL_13c5_2:
														if (29 > b)
														{
															break;
														}
														goto IL_13d3_2;
														IL_13d3_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1413_2;
														IL_1413_2:
														array2[num6 - 2] = 3;
														goto IL_1427_2;
														IL_1427_2:
														num6--;
														goto IL_168a_2;
														IL_143a_2:
														if (31 >= b)
														{
															goto IL_1445_2;
														}
														goto IL_14a6_2;
														IL_1445_2:
														if (31 > b)
														{
															break;
														}
														goto IL_1453_2;
														IL_1453_2:
														((delegate*<string, void>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														num = 267;
														goto IL_1485_2;
														IL_1485_2:
														num6--;
														goto IL_1493_2;
														IL_1493_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_14a6_2:
														if (32 < b)
														{
															break;
														}
														num = 265;
														goto IL_14bd_2;
														IL_166c_2:
														if (37 <= b)
														{
														}
														break;
														IL_14bd_2:
														if (32 > b)
														{
															break;
														}
														goto IL_14cb_2;
														IL_14cb_2:
														array2[num6 - 1] = 3;
														goto IL_14df_2;
														IL_14df_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 272;
														goto IL_1527_2;
														IL_1527_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_153a_2:
														if (35 >= b)
														{
															goto IL_1548_2;
														}
														goto IL_1632_2;
														IL_1548_2:
														if (35 <= b)
														{
															goto IL_1553_2;
														}
														goto IL_15b2_2;
														IL_1553_2:
														((delegate*<Behaviour, bool, void>)ctimegetProcessorArchitecture[*(int*)(ptr2 + num3)])((VRRig)array3[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
														goto IL_1591_2;
														IL_1591_2:
														num6 -= 2;
														goto IL_159f_2;
														IL_159f_2:
														ptr2 += 8;
														goto IL_168a_2;
														IL_15b2_2:
														if (34 < b)
														{
															break;
														}
														goto IL_15c0_2;
														IL_15c0_2:
														if (34 > b)
														{
															break;
														}
														goto IL_15ce_2;
														IL_15ce_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_160e_2;
														IL_160e_2:
														array2[num6 - 2] = 3;
														goto IL_1622_2;
														IL_1622_2:
														num6--;
														goto IL_168a_2;
														IL_1632_2:
														if (36 >= b)
														{
															goto IL_163d_2;
														}
														goto IL_1661_2;
														IL_163d_2:
														if (36 > b)
														{
															break;
														}
														goto IL_1648_2;
													}
													break;
													IL_05bd_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_168a_2;
											continue;
											end_IL_05cd_2:
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0bdf_2;
					}
					continue;
					end_IL_0bed:
					break;
				}
				break;
			}
		}
	}

	public Class193()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 60;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									num = 23;
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OverflowExceptionAtNmTokens.OSPlatformsetVersionCompatibility);
											num = 98;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_033f:
															byte b = *ptr2;
															while (true)
															{
																IL_032f:
																ptr2++;
																while (true)
																{
																	IL_031f:
																	if (b >= 1)
																	{
																		goto IL_01d6;
																	}
																	goto IL_02fe;
																	IL_02fe:
																	while (true)
																	{
																		IL_02fe_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 109;
																		while (num != 109)
																		{
																			if (num != 1090)
																			{
																				goto IL_02fe_2;
																			}
																			switch (num)
																			{
																			case 89:
																				goto IL_01d6;
																			case 20:
																				goto IL_01e4;
																			case 68:
																				goto IL_01ef;
																			case 55:
																				goto IL_01fd;
																			case 38:
																				goto IL_0208;
																			case 87:
																				goto IL_0213;
																			case 13:
																				goto IL_0226;
																			case 51:
																				goto IL_0234;
																			case 49:
																				goto IL_0247;
																			case 8:
																				goto IL_0252;
																			case 91:
																				goto IL_0262;
																			case 76:
																			case 92:
																				goto IL_0270;
																			case 78:
																				goto IL_027e;
																			case 97:
																				goto IL_028e;
																			case 15:
																			case 53:
																				goto IL_0299;
																			case 85:
																				goto IL_02a4;
																			case 35:
																				goto IL_02b1;
																			case 99:
																				goto IL_02c1;
																			case 86:
																				goto IL_02cc;
																			case 69:
																				goto IL_02dc;
																			case 36:
																				goto IL_02e7;
																			case 1:
																			case 2:
																			case 3:
																			case 12:
																			case 21:
																			case 22:
																			case 24:
																			case 28:
																			case 34:
																			case 41:
																			case 44:
																			case 45:
																			case 47:
																			case 48:
																			case 59:
																			case 65:
																			case 66:
																			case 72:
																			case 75:
																			case 84:
																				goto IL_02fe_2;
																			case 18:
																				goto IL_031f;
																			case 37:
																				goto IL_032f;
																			case 0:
																			case 26:
																				goto IL_033f;
																			case 32:
																			case 50:
																				goto IL_034a;
																			case 67:
																				goto IL_0358;
																			case 71:
																			case 79:
																				goto IL_0380;
																			case 88:
																				goto IL_03eb;
																			case 40:
																			case 46:
																				goto IL_03fe;
																			case 6:
																				goto IL_0427;
																			case 5:
																				goto IL_0435;
																			case 30:
																			case 33:
																				goto IL_0451;
																			case 9:
																				goto IL_046a;
																			case 11:
																				goto IL_0481;
																			case 90:
																				goto IL_048f;
																			case 95:
																				goto IL_04a2;
																			case 63:
																				goto IL_04ac;
																			case 7:
																				goto IL_04ba;
																			case 56:
																			case 70:
																				goto IL_04d6;
																			case 16:
																			case 61:
																				goto IL_04f2;
																			case 57:
																				goto IL_0532;
																			case 14:
																				goto IL_0546;
																			case 42:
																			case 54:
																				goto IL_0556;
																			case 43:
																				goto IL_0579;
																			case 52:
																				goto IL_0587;
																			case 29:
																				goto IL_0595;
																			case 62:
																			case 100:
																				goto IL_05a5;
																			case 4:
																			case 27:
																			case 31:
																			case 39:
																			case 58:
																			case 64:
																			case 77:
																			case 80:
																			case 82:
																			case 93:
																			case 96:
																			case 102:
																				goto end_IL_01c3;
																			case 98:
																				goto end_IL_05b8;
																			case 10:
																				goto end_IL_05cb;
																			case 23:
																				goto end_IL_05d5;
																			case 19:
																				goto end_IL_05e9;
																			case 25:
																			case 83:
																				goto end_IL_05fe;
																			case 17:
																				goto end_IL_0617;
																			case 60:
																				goto end_IL_0627;
																			case 81:
																				goto end_IL_0637;
																			case 73:
																				goto end_IL_0647;
																			case 74:
																				goto end_IL_0652;
																			case 94:
																			case 101:
																				goto IL_066d;
																			}
																			continue;
																			end_IL_01c3:
																			break;
																		}
																		break;
																	}
																	break;
																	IL_01d6:
																	if (b <= 10)
																	{
																		goto IL_01e4;
																	}
																	goto IL_02fe;
																	IL_01e4:
																	if (5 >= b)
																	{
																		goto IL_01ef;
																	}
																	goto IL_0247;
																	IL_01ef:
																	if (5 > b)
																	{
																		goto IL_01fd;
																	}
																	goto IL_034a;
																	IL_01fd:
																	if (2 < b)
																	{
																		goto IL_0208;
																	}
																	goto IL_0262;
																	IL_0208:
																	if (3 >= b)
																	{
																		goto IL_0213;
																	}
																	goto IL_0226;
																	IL_0213:
																	if (3 > b)
																	{
																		goto IL_02fe;
																	}
																	goto IL_05a5;
																	IL_05a5:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_0226:
																	if (4 >= b)
																	{
																		goto IL_0234;
																	}
																	goto IL_02fe;
																	IL_0234:
																	if (4 <= b)
																	{
																		break;
																	}
																	goto IL_02fe;
																	IL_0262:
																	if (2 > b)
																	{
																		goto IL_0270;
																	}
																	goto IL_03fe;
																	IL_0270:
																	if (1 >= b)
																	{
																		goto IL_027e;
																	}
																	goto IL_02fe;
																	IL_027e:
																	if (1 > b)
																	{
																		goto IL_02fe;
																	}
																	goto IL_0451;
																	IL_0451:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_046a;
																	IL_046a:
																	array[num5] = 0;
																	num = 11;
																	goto IL_0481;
																	IL_0481:
																	num5++;
																	goto IL_048f;
																	IL_048f:
																	ptr2 += 8;
																	break;
																	IL_03fe:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0427;
																	IL_0427:
																	ptr2 += 8;
																	goto IL_0435;
																	IL_0435:
																	num5--;
																	num = 80;
																	break;
																	IL_034a:
																	array[num5] = 0;
																	goto IL_0358;
																	IL_0358:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04a2;
																	IL_04a2:
																	array2[num5] = null;
																	goto IL_04ac;
																	IL_04ac:
																	num5++;
																	goto IL_04ba;
																	IL_04ba:
																	ptr2 += 8;
																	break;
																	IL_0247:
																	if (8 >= b)
																	{
																		goto IL_0252;
																	}
																	goto IL_028e;
																	IL_0252:
																	if (8 > b)
																	{
																		goto IL_02c1;
																	}
																	goto IL_0380;
																	IL_0380:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	num = 88;
																	goto IL_03eb;
																	IL_03eb:
																	num5 -= 2;
																	break;
																	IL_02c1:
																	if (6 >= b)
																	{
																		goto IL_02cc;
																	}
																	goto IL_02dc;
																	IL_02cc:
																	if (6 > b)
																	{
																		goto IL_02fe;
																	}
																	goto IL_04f2;
																	IL_04f2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0532;
																	IL_0532:
																	array[num5 - 2] = 0;
																	goto IL_0546;
																	IL_0546:
																	num5--;
																	break;
																	IL_02dc:
																	if (7 >= b)
																	{
																		goto IL_02e7;
																	}
																	goto IL_02fe;
																	IL_02e7:
																	if (7 > b)
																	{
																		num = 59;
																		goto IL_02fe;
																	}
																	goto IL_0556;
																	IL_04d6:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_0556:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0579;
																	IL_0579:
																	array[num5] = 0;
																	goto IL_0587;
																	IL_0587:
																	num5++;
																	goto IL_0595;
																	IL_0595:
																	ptr2 += 8;
																	break;
																	IL_028e:
																	if (9 < b)
																	{
																		goto IL_0299;
																	}
																	goto IL_02b1;
																	IL_0299:
																	if (10 >= b)
																	{
																		goto IL_02a4;
																	}
																	goto IL_02fe;
																	IL_02a4:
																	if (10 <= b)
																	{
																	}
																	goto IL_02fe;
																	IL_02b1:
																	if (9 > b)
																	{
																		goto IL_02fe;
																	}
																	num = 56;
																	goto IL_04d6;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_066d;
													IL_066d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05b8:
													break;
												}
												continue;
												end_IL_05cb:
												break;
											}
											continue;
											end_IL_05d5:
											break;
										}
										continue;
										end_IL_05e9:
										break;
									}
									continue;
									end_IL_05fe:
									break;
								}
								continue;
								end_IL_0617:
								break;
							}
							continue;
							end_IL_0627:
							break;
						}
						continue;
						end_IL_0637:
						break;
					}
					continue;
					end_IL_0647:
					break;
				}
				continue;
				end_IL_0652:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref haveWrittenPreambleDISPPARAMS.getPublisherLineNumberInfo);
										num = 90;
										while (true)
										{
											byte* ptr2 = ptr;
											num = 41;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0251:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		num = 44;
																		while (true)
																		{
																			IL_022e:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_021e:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0211:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01fe:
																									if (3 < b)
																									{
																										num = 112;
																										while (true)
																										{
																											if (num != 112)
																											{
																												if (num != 1093)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 36:
																													goto IL_01fe;
																												case 49:
																												case 101:
																													goto IL_0211;
																												case 14:
																													goto IL_021e;
																												case 44:
																													goto IL_022e;
																												case 52:
																													goto IL_023e;
																												case 104:
																													goto IL_0251;
																												case 12:
																													goto end_IL_0251;
																												case 35:
																												case 65:
																													goto end_IL_0261;
																												case 45:
																													goto IL_027c;
																												case 23:
																												case 48:
																													goto IL_0287;
																												case 37:
																													goto IL_02b0;
																												case 76:
																													goto IL_02c9;
																												case 24:
																												case 69:
																													goto IL_02d7;
																												case 3:
																												case 95:
																													goto IL_02ef;
																												case 16:
																													goto IL_02fd;
																												case 0:
																												case 55:
																													goto IL_030b;
																												case 92:
																													goto IL_0324;
																												case 98:
																													goto IL_0334;
																												case 102:
																													goto IL_0347;
																												case 10:
																													goto IL_0355;
																												case 19:
																													goto IL_0368;
																												case 64:
																													goto IL_0376;
																												case 22:
																												case 81:
																													goto IL_0392;
																												case 68:
																													goto IL_03a0;
																												case 72:
																													goto IL_03c3;
																												case 56:
																													goto IL_03cd;
																												case 50:
																													goto IL_03db;
																												case 46:
																													goto IL_03ee;
																												case 20:
																													goto IL_03f9;
																												case 42:
																												case 57:
																													goto IL_0404;
																												case 84:
																													goto IL_0412;
																												case 105:
																													goto IL_0425;
																												case 59:
																												case 97:
																													goto IL_0433;
																												case 78:
																													goto IL_044f;
																												case 26:
																												case 91:
																													goto IL_045a;
																												case 103:
																													goto IL_04bc;
																												case 89:
																													goto IL_04cf;
																												case 13:
																												case 75:
																													goto IL_04da;
																												case 79:
																													goto IL_04e8;
																												case 85:
																												case 87:
																													goto IL_04f6;
																												case 67:
																													goto IL_0519;
																												case 9:
																													goto IL_0527;
																												case 80:
																													goto IL_0535;
																												case 100:
																													goto IL_0548;
																												case 6:
																												case 43:
																													goto IL_0553;
																												case 99:
																													goto IL_0593;
																												case 88:
																													goto IL_05a7;
																												case 5:
																												case 11:
																												case 15:
																												case 18:
																												case 21:
																												case 28:
																												case 31:
																												case 33:
																												case 34:
																												case 38:
																												case 39:
																												case 40:
																												case 47:
																												case 53:
																												case 60:
																												case 62:
																												case 66:
																												case 70:
																												case 71:
																												case 73:
																													goto end_IL_01eb;
																												case 4:
																												case 7:
																												case 32:
																												case 41:
																												case 51:
																												case 54:
																												case 58:
																												case 74:
																												case 83:
																												case 86:
																												case 93:
																												case 94:
																												case 96:
																													goto end_IL_0271;
																												case 90:
																													goto end_IL_05d3;
																												case 82:
																													goto end_IL_05e6;
																												case 17:
																													goto end_IL_05f9;
																												case 8:
																													goto end_IL_060d;
																												case 1:
																												case 77:
																													goto end_IL_0622;
																												case 2:
																													goto end_IL_0632;
																												case 27:
																												case 61:
																													goto end_IL_0642;
																												case 29:
																													goto end_IL_0652;
																												case 30:
																													goto end_IL_0662;
																												case 25:
																												case 63:
																													goto IL_067d;
																												}
																												continue;
																											}
																											goto IL_0368;
																											IL_0368:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0376;
																											IL_0376:
																											if (4 <= b)
																											{
																												goto end_IL_0271;
																											}
																											num = 60;
																											break;
																											continue;
																											end_IL_01eb:
																											break;
																										}
																										break;
																									}
																									goto IL_02c9;
																									IL_02c9:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_02d7;
																									IL_02d7:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0271;
																								}
																								break;
																							}
																							goto IL_027c;
																							IL_0355:
																							ptr2 += 8;
																							goto end_IL_0271;
																							IL_027c:
																							if (2 <= b)
																							{
																								goto IL_0287;
																							}
																							goto IL_02ef;
																							IL_0287:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02b0;
																							IL_02b0:
																							ptr2 += 8;
																							num = 98;
																							goto IL_0334;
																							IL_0334:
																							num5--;
																							goto end_IL_0271;
																							IL_02ef:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_02fd;
																							IL_02fd:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_030b;
																							IL_030b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0324;
																							IL_0324:
																							array[num5] = 0;
																							goto IL_0347;
																							IL_0347:
																							num5++;
																							goto IL_0355;
																						}
																						break;
																					}
																					goto IL_0392;
																					IL_03db:
																					ptr2 += 8;
																					goto end_IL_0271;
																					IL_0392:
																					array[num5] = 0;
																					goto IL_03a0;
																					IL_03a0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03c3;
																					IL_03c3:
																					array2[num5] = null;
																					goto IL_03cd;
																					IL_03cd:
																					num5++;
																					goto IL_03db;
																				}
																				break;
																			}
																			goto IL_03ee;
																			IL_05a7:
																			num5--;
																			goto end_IL_0271;
																			IL_03ee:
																			if (8 < b)
																			{
																				goto IL_03f9;
																			}
																			goto IL_044f;
																			IL_03f9:
																			if (9 < b)
																			{
																				goto IL_0404;
																			}
																			goto IL_0425;
																			IL_0404:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0412;
																			IL_0412:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_0425:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0433;
																			IL_0433:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0271;
																			IL_044f:
																			if (8 <= b)
																			{
																				goto IL_045a;
																			}
																			goto IL_04cf;
																			IL_045a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04bc;
																			IL_04bc:
																			num5 -= 2;
																			goto end_IL_0271;
																			IL_04cf:
																			if (6 < b)
																			{
																				goto IL_04da;
																			}
																			goto IL_0548;
																			IL_04da:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04e8;
																			IL_04e8:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04f6;
																			IL_04f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0519;
																			IL_0519:
																			array[num5] = 0;
																			goto IL_0527;
																			IL_0527:
																			num5++;
																			goto IL_0535;
																			IL_0535:
																			ptr2 += 8;
																			goto end_IL_0271;
																			IL_0548:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0553;
																			IL_0553:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0593;
																			IL_0593:
																			array[num5 - 2] = 0;
																			goto IL_05a7;
																		}
																		break;
																		IL_023e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 7;
																goto end_IL_0271;
																continue;
																end_IL_0251:
																break;
															}
															continue;
															end_IL_0261:
															break;
														}
														continue;
														end_IL_0271:
														break;
													}
													continue;
												}
												goto IL_067d;
												IL_067d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d3:
												break;
											}
											continue;
											end_IL_05e6:
											break;
										}
										continue;
										end_IL_05f9:
										break;
									}
									continue;
									end_IL_060d:
									break;
								}
								continue;
								end_IL_0622:
								break;
							}
							continue;
							end_IL_0632:
							break;
						}
						continue;
						end_IL_0642:
						break;
					}
					continue;
					end_IL_0652:
					break;
				}
				continue;
				end_IL_0662:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PInvokeAttributessetSource.tailHighgetRegisteredHandlers);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_036c:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_034f:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_033f:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_032f:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_031f:
																									if (10 < b)
																									{
																										while (11 >= b)
																										{
																											while (11 <= b)
																											{
																												while (true)
																												{
																													IL_02b9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													while (true)
																													{
																														IL_029a:
																														array[num5 - 2] = 0;
																														num = 158;
																														while (true)
																														{
																															if (num != 158)
																															{
																																if (num != 1139)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 68:
																																	goto IL_029a;
																																case 24:
																																case 125:
																																	goto IL_02b9;
																																case 90:
																																	goto IL_02ff;
																																case 59:
																																case 144:
																																	goto IL_030f;
																																case 61:
																																	goto IL_031f;
																																case 150:
																																	goto IL_032f;
																																case 19:
																																	goto IL_033f;
																																case 97:
																																	goto IL_034f;
																																case 82:
																																	goto IL_035c;
																																case 151:
																																	goto IL_036c;
																																case 29:
																																	goto end_IL_036c;
																																case 15:
																																case 105:
																																	goto end_IL_037c;
																																case 86:
																																	goto IL_0397;
																																case 70:
																																case 115:
																																	goto IL_03a5;
																																case 135:
																																	goto IL_03bd;
																																case 9:
																																case 85:
																																	goto IL_03c8;
																																case 87:
																																	goto IL_03d6;
																																case 51:
																																	goto IL_03fb;
																																case 136:
																																	goto IL_0409;
																																case 141:
																																	goto IL_041c;
																																case 8:
																																	goto IL_0426;
																																case 21:
																																	goto IL_0434;
																																case 101:
																																case 146:
																																	goto IL_0447;
																																case 94:
																																case 110:
																																	goto IL_0455;
																																case 84:
																																	goto IL_0463;
																																case 62:
																																case 98:
																																	goto IL_046e;
																																case 138:
																																	goto IL_047c;
																																case 53:
																																case 111:
																																	goto IL_048a;
																																case 2:
																																	goto IL_0498;
																																case 106:
																																	goto IL_04b0;
																																case 114:
																																	goto IL_04be;
																																case 56:
																																case 81:
																																	goto IL_04d1;
																																case 102:
																																	goto IL_0519;
																																case 17:
																																	goto IL_052c;
																																case 40:
																																case 50:
																																	goto IL_0543;
																																case 6:
																																	goto IL_0551;
																																case 92:
																																case 128:
																																	goto IL_055c;
																																case 113:
																																	goto IL_056a;
																																case 42:
																																case 129:
																																	goto IL_0578;
																																case 31:
																																	goto IL_0591;
																																case 139:
																																	goto IL_059f;
																																case 131:
																																	goto IL_05ad;
																																case 36:
																																case 119:
																																	goto IL_05c0;
																																case 89:
																																	goto IL_0600;
																																case 103:
																																	goto IL_061d;
																																case 43:
																																	goto IL_0639;
																																case 33:
																																	goto IL_0647;
																																case 5:
																																case 41:
																																	goto IL_0660;
																																case 112:
																																	goto IL_0689;
																																case 67:
																																case 108:
																																	goto IL_06a2;
																																case 57:
																																	goto IL_06c0;
																																case 65:
																																	goto IL_06ce;
																																case 148:
																																	goto IL_06e1;
																																case 117:
																																	goto IL_06ef;
																																case 1:
																																case 109:
																																	goto end_IL_0287;
																																case 104:
																																	goto IL_0726;
																																case 47:
																																	goto IL_0734;
																																case 20:
																																case 28:
																																	goto IL_076c;
																																case 79:
																																	goto IL_07b5;
																																case 12:
																																	goto IL_07c9;
																																case 127:
																																	goto IL_07dc;
																																case 30:
																																	goto IL_07ea;
																																case 37:
																																case 130:
																																	goto IL_07f8;
																																case 99:
																																	goto IL_0806;
																																case 25:
																																case 34:
																																	goto IL_0811;
																																case 26:
																																	goto IL_0873;
																																case 73:
																																case 96:
																																	goto IL_088e;
																																case 54:
																																	goto IL_08b0;
																																case 18:
																																	goto IL_08bb;
																																case 3:
																																case 4:
																																case 10:
																																case 11:
																																case 14:
																																case 16:
																																case 38:
																																case 39:
																																case 46:
																																case 48:
																																case 52:
																																case 55:
																																case 63:
																																case 69:
																																case 71:
																																case 72:
																																case 74:
																																case 75:
																																case 78:
																																case 80:
																																case 83:
																																case 91:
																																case 93:
																																case 116:
																																case 120:
																																case 121:
																																case 132:
																																case 140:
																																case 145:
																																case 147:
																																case 149:
																																	goto end_IL_02ff;
																																case 0:
																																case 22:
																																case 27:
																																case 32:
																																case 35:
																																case 45:
																																case 49:
																																case 58:
																																case 60:
																																case 66:
																																case 100:
																																case 118:
																																case 122:
																																case 124:
																																case 126:
																																case 134:
																																case 142:
																																case 143:
																																	goto end_IL_038c;
																																case 95:
																																	goto end_IL_08d9;
																																case 44:
																																	goto end_IL_08ec;
																																case 123:
																																	goto end_IL_08f6;
																																case 107:
																																	goto end_IL_0901;
																																case 7:
																																case 133:
																																	goto end_IL_0911;
																																case 88:
																																	goto end_IL_0921;
																																case 23:
																																case 137:
																																	goto end_IL_0931;
																																case 76:
																																	goto end_IL_0941;
																																case 77:
																																	goto end_IL_0951;
																																case 13:
																																case 64:
																																	goto IL_096c;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_038c;
																															continue;
																															end_IL_0287:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_06fd;
																												continue;
																												end_IL_02ff:
																												break;
																												IL_02ff:;
																											}
																											break;
																											IL_030f:;
																										}
																										break;
																									}
																									goto IL_03bd;
																									IL_0409:
																									if (9 > b)
																									{
																										break;
																									}
																									goto end_IL_038c;
																									IL_03bd:
																									if (10 <= b)
																									{
																										goto IL_03c8;
																									}
																									goto IL_03fb;
																									IL_03c8:
																									array[num5] = 0;
																									goto IL_03d6;
																									IL_03d6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_041c;
																									IL_041c:
																									array2[num5] = null;
																									goto IL_0426;
																									IL_0426:
																									num5++;
																									goto IL_0434;
																									IL_0434:
																									ptr2 += 8;
																									goto end_IL_038c;
																									IL_03fb:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_0409;
																								}
																								break;
																							}
																							num = 28;
																							goto IL_076c;
																							IL_07b5:
																							array[num5 - 2] = 0;
																							goto IL_07c9;
																							IL_07c9:
																							num5--;
																							goto end_IL_038c;
																							IL_076c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 79;
																							goto IL_07b5;
																						}
																						break;
																					}
																					goto IL_07dc;
																					IL_08b0:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_08bb;
																					IL_07dc:
																					if (14 >= b)
																					{
																						goto IL_07ea;
																					}
																					goto IL_08b0;
																					IL_07ea:
																					if (14 > b)
																					{
																						goto IL_07f8;
																					}
																					goto IL_088e;
																					IL_07f8:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0806;
																					IL_0806:
																					if (13 > b)
																					{
																						num = 80;
																						break;
																					}
																					goto IL_0811;
																					IL_0811:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0873;
																					IL_0873:
																					num5 -= 2;
																					goto end_IL_038c;
																					IL_08bb:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_088e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 32;
																					goto end_IL_038c;
																				}
																				break;
																			}
																			goto IL_0397;
																			IL_06a2:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_06c0;
																			IL_0397:
																			if (8 <= b)
																			{
																				goto IL_03a5;
																			}
																			goto IL_0447;
																			IL_03a5:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_038c;
																			IL_0447:
																			if (4 < b)
																			{
																				goto IL_0455;
																			}
																			goto IL_052c;
																			IL_0455:
																			if (6 >= b)
																			{
																				goto IL_0463;
																			}
																			goto IL_06e1;
																			IL_0463:
																			if (6 > b)
																			{
																				goto IL_046e;
																			}
																			goto IL_04d1;
																			IL_046e:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_047c;
																			IL_047c:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_048a;
																			IL_048a:
																			array[num5] = 5;
																			goto IL_0498;
																			IL_0498:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_04b0;
																			IL_04b0:
																			num5++;
																			goto IL_04be;
																			IL_04be:
																			ptr2 += 8;
																			goto end_IL_038c;
																			IL_04d1:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 102;
																			goto IL_0519;
																			IL_0519:
																			num5 -= 3;
																			goto end_IL_038c;
																			IL_06e1:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_06ef;
																			IL_06ef:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_06fd;
																			IL_06fd:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0726;
																			IL_0726:
																			ptr2 += 8;
																			goto IL_0734;
																			IL_0734:
																			num5--;
																			num = 134;
																			goto end_IL_038c;
																			IL_052c:
																			if (4 > b)
																			{
																				num = 50;
																				goto IL_0543;
																			}
																			goto IL_06a2;
																			IL_06c0:
																			ptr2 += 8;
																			goto IL_06ce;
																			IL_0543:
																			if (2 >= b)
																			{
																				goto IL_0551;
																			}
																			goto IL_0639;
																			IL_0551:
																			if (2 > b)
																			{
																				goto IL_055c;
																			}
																			goto IL_05c0;
																			IL_055c:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_056a;
																			IL_056a:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0578;
																			IL_0578:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0591;
																			IL_0591:
																			array[num5] = 0;
																			goto IL_059f;
																			IL_059f:
																			num5++;
																			goto IL_05ad;
																			IL_05ad:
																			ptr2 += 8;
																			goto end_IL_038c;
																			IL_05c0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0600;
																			IL_0600:
																			array[num5 - 2] = 0;
																			num = 103;
																			goto IL_061d;
																			IL_061d:
																			num5--;
																			num = 122;
																			goto end_IL_038c;
																			IL_0639:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0647;
																			IL_0647:
																			if (3 > b)
																			{
																				num = 14;
																				break;
																			}
																			goto IL_0660;
																			IL_06ce:
																			num5--;
																			goto end_IL_038c;
																			IL_0660:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0689;
																			IL_0689:
																			array[num5 - 1] = 5;
																			goto end_IL_038c;
																		}
																		break;
																		IL_035c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_038c;
																continue;
																end_IL_036c:
																break;
															}
															continue;
															end_IL_037c:
															break;
														}
														continue;
														end_IL_038c:
														break;
													}
													continue;
												}
												goto IL_096c;
												IL_096c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d9:
												break;
											}
											continue;
											end_IL_08ec:
											break;
										}
										continue;
										end_IL_08f6:
										break;
									}
									continue;
									end_IL_0901:
									break;
								}
								continue;
								end_IL_0911:
								break;
							}
							continue;
							end_IL_0921:
							break;
						}
						continue;
						end_IL_0931:
						break;
					}
					continue;
					end_IL_0941:
					break;
				}
				continue;
				end_IL_0951:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 12;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							IL_06bf:
							int[] array3 = new int[4];
							while (true)
							{
								IL_06af:
								long[] array4 = new long[3];
								while (true)
								{
									IL_069a:
									array3[0] = int_1;
									while (true)
									{
										IL_068f:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getAddressKindFormIdnaDisallowUnassigned.LogRemotingStageByValArray);
										while (true)
										{
											IL_0685:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0672:
												if (num4 != 1)
												{
													while (true)
													{
														IL_01e7:
														num = 114;
														while (true)
														{
															if (num != 114)
															{
																if (num != 1095)
																{
																	break;
																}
																switch (num)
																{
																case 5:
																	goto IL_01e7;
																case 65:
																	goto IL_01fb;
																case 22:
																	goto IL_0209;
																case 39:
																	goto IL_0220;
																case 31:
																	goto IL_022e;
																case 15:
																case 94:
																	goto IL_023c;
																case 52:
																	goto IL_0247;
																case 93:
																	goto IL_0252;
																case 104:
																	goto IL_0260;
																case 20:
																	goto IL_0273;
																case 23:
																case 100:
																	goto IL_0281;
																case 57:
																	goto IL_02a6;
																case 2:
																case 90:
																	goto IL_02ba;
																case 49:
																	goto IL_031c;
																case 53:
																	goto IL_032f;
																case 14:
																	goto IL_033d;
																case 74:
																case 99:
																	goto IL_0354;
																case 71:
																	goto IL_0394;
																case 54:
																	goto IL_03a8;
																case 88:
																case 89:
																	goto IL_03c4;
																case 8:
																	goto IL_03d2;
																case 3:
																case 69:
																	goto IL_03e9;
																case 0:
																	goto IL_040c;
																case 67:
																	goto IL_041a;
																case 30:
																	goto IL_0428;
																case 61:
																	goto IL_043b;
																case 33:
																	goto IL_0449;
																case 18:
																case 43:
																	goto IL_0457;
																case 103:
																	goto IL_0462;
																case 58:
																	goto IL_0475;
																case 38:
																	goto IL_0483;
																case 78:
																case 87:
																	goto IL_049a;
																case 95:
																	goto IL_04a8;
																case 46:
																	goto IL_04d4;
																case 37:
																	goto IL_04e7;
																case 35:
																	goto IL_04f5;
																case 68:
																	goto IL_0508;
																case 55:
																case 72:
																	goto IL_0513;
																case 77:
																	goto IL_052b;
																case 56:
																	goto IL_0536;
																case 40:
																case 86:
																	goto IL_0544;
																case 70:
																	goto IL_055d;
																case 21:
																	goto IL_056b;
																case 36:
																	goto IL_0579;
																case 62:
																	goto IL_058c;
																case 66:
																	goto IL_059a;
																case 82:
																case 96:
																	goto IL_05a8;
																case 34:
																	goto IL_05d1;
																case 48:
																	goto IL_05df;
																case 4:
																case 97:
																	goto IL_05f2;
																case 1:
																	goto IL_0632;
																case 91:
																	goto IL_0646;
																case 7:
																case 9:
																case 17:
																case 26:
																case 27:
																case 41:
																case 42:
																case 50:
																case 51:
																case 63:
																case 64:
																case 76:
																case 79:
																case 80:
																case 85:
																case 92:
																case 98:
																	goto IL_0656;
																case 6:
																case 13:
																case 19:
																case 24:
																case 28:
																case 29:
																case 32:
																case 59:
																case 73:
																case 84:
																case 102:
																case 105:
																case 106:
																case 107:
																	goto IL_0672;
																case 25:
																	goto IL_0685;
																case 101:
																	goto IL_068f;
																case 10:
																	goto IL_069a;
																case 75:
																	goto IL_06af;
																case 16:
																case 81:
																	goto IL_06bf;
																case 83:
																	goto end_IL_01d7;
																case 44:
																case 60:
																	goto end_IL_06cf;
																case 11:
																	goto end_IL_06df;
																case 12:
																	goto end_IL_06ef;
																case 45:
																case 47:
																	goto IL_070a;
																}
																continue;
															}
															b = *ptr2;
															goto IL_01fb;
															IL_058c:
															if (2 >= b)
															{
																goto IL_059a;
															}
															goto IL_0656;
															IL_05a8:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_05d1;
															IL_059a:
															if (2 <= b)
															{
																goto IL_05a8;
															}
															goto IL_0656;
															IL_01fb:
															ptr2++;
															goto IL_0209;
															IL_0209:
															if (b >= 1)
															{
																num = 39;
																goto IL_0220;
															}
															goto IL_0656;
															IL_05d1:
															ptr2 += 8;
															goto IL_05df;
															IL_0220:
															if (b <= 11)
															{
																goto IL_022e;
															}
															goto IL_0656;
															IL_022e:
															if (6 < b)
															{
																goto IL_023c;
															}
															goto IL_043b;
															IL_023c:
															if (9 < b)
															{
																goto IL_0247;
															}
															num = 57;
															goto IL_02a6;
															IL_0247:
															if (10 < b)
															{
																goto IL_0252;
															}
															goto IL_0273;
															IL_0252:
															if (11 >= b)
															{
																goto IL_0260;
															}
															goto IL_0656;
															IL_0260:
															if (11 > b)
															{
															}
															goto IL_0656;
															IL_0273:
															if (10 <= b)
															{
																goto IL_0281;
															}
															goto IL_0656;
															IL_0281:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto IL_0672;
															IL_05df:
															num5--;
															goto IL_0672;
															IL_02a6:
															if (9 <= b)
															{
																num = 2;
																goto IL_02ba;
															}
															goto IL_032f;
															IL_05f2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0632;
															IL_02ba:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_031c;
															IL_031c:
															num5 -= 2;
															goto IL_0672;
															IL_032f:
															if (7 >= b)
															{
																goto IL_033d;
															}
															goto IL_03c4;
															IL_033d:
															if (7 <= b)
															{
																num = 99;
																goto IL_0354;
															}
															goto IL_0656;
															IL_0632:
															array[num5 - 2] = 0;
															goto IL_0646;
															IL_0354:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0394;
															IL_0394:
															array[num5 - 2] = 0;
															goto IL_03a8;
															IL_03a8:
															num5--;
															num = 59;
															goto IL_0672;
															IL_03c4:
															if (8 >= b)
															{
																goto IL_03d2;
															}
															goto IL_0656;
															IL_03d2:
															if (8 <= b)
															{
																num = 3;
																goto IL_03e9;
															}
															goto IL_0656;
															IL_0646:
															num5--;
															goto IL_0672;
															IL_03e9:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_040c;
															IL_040c:
															array[num5] = 0;
															goto IL_041a;
															IL_041a:
															num5++;
															goto IL_0428;
															IL_0428:
															ptr2 += 8;
															goto IL_0672;
															IL_043b:
															if (6 > b)
															{
																goto IL_0449;
															}
															goto IL_05f2;
															IL_0449:
															if (3 < b)
															{
																goto IL_0457;
															}
															goto IL_0508;
															IL_0457:
															if (4 >= b)
															{
																goto IL_0462;
															}
															goto IL_0475;
															IL_0462:
															if (4 <= b)
															{
																goto IL_0672;
															}
															goto IL_0656;
															IL_0475:
															if (5 >= b)
															{
																goto IL_0483;
															}
															goto IL_0656;
															IL_0483:
															if (5 <= b)
															{
																num = 87;
																goto IL_049a;
															}
															goto IL_0656;
															IL_0656:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															num = 6;
															goto IL_0672;
															IL_049a:
															array[num5] = 0;
															goto IL_04a8;
															IL_04a8:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															num = 46;
															goto IL_04d4;
															IL_04d4:
															array2[num5] = null;
															num = 37;
															goto IL_04e7;
															IL_04e7:
															num5++;
															goto IL_04f5;
															IL_04f5:
															ptr2 += 8;
															goto IL_0672;
															IL_0508:
															if (3 <= b)
															{
																goto IL_0513;
															}
															goto IL_052b;
															IL_0513:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_0672;
															IL_052b:
															if (1 >= b)
															{
																goto IL_0536;
															}
															goto IL_058c;
															IL_0536:
															if (1 <= b)
															{
																goto IL_0544;
															}
															goto IL_0656;
															IL_0544:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_055d;
															IL_055d:
															array[num5] = 0;
															goto IL_056b;
															IL_056b:
															num5++;
															goto IL_0579;
															IL_0579:
															ptr2 += 8;
															goto IL_0672;
															continue;
															end_IL_01d7:
															break;
														}
														break;
													}
													break;
												}
												goto IL_070a;
												IL_070a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_06cf:
						break;
					}
					continue;
					end_IL_06df:
					break;
				}
				continue;
				end_IL_06ef:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 102;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 55;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TNtCollect.InitSidNameUse);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 109;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_031d:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0300:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02f0:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_02e0:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_02d0:
																									if (5 >= b)
																									{
																										while (true)
																										{
																											IL_02c0:
																											if (5 <= b)
																											{
																												while (true)
																												{
																													IL_02b0:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_028b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_027f:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_0266:
																																num5++;
																																num = 145;
																																while (true)
																																{
																																	if (num != 145)
																																	{
																																		if (num != 1126)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 117:
																																			goto IL_0266;
																																		case 4:
																																			goto IL_027f;
																																		case 125:
																																			goto IL_028b;
																																		case 17:
																																		case 120:
																																			goto IL_02b0;
																																		case 93:
																																			goto IL_02c0;
																																		case 95:
																																		case 122:
																																			goto IL_02d0;
																																		case 32:
																																		case 87:
																																			goto IL_02e0;
																																		case 108:
																																			goto IL_02f0;
																																		case 79:
																																			goto IL_0300;
																																		case 104:
																																			goto IL_030d;
																																		case 89:
																																			goto IL_031d;
																																		case 3:
																																			goto end_IL_031d;
																																		case 57:
																																		case 96:
																																			goto end_IL_032d;
																																		case 8:
																																		case 40:
																																			goto IL_0348;
																																		case 16:
																																		case 58:
																																			goto IL_0358;
																																		case 65:
																																			goto IL_0366;
																																		case 90:
																																			goto IL_0379;
																																		case 22:
																																		case 86:
																																			goto IL_0390;
																																		case 41:
																																			goto IL_03a4;
																																		case 76:
																																			goto IL_03e3;
																																		case 85:
																																		case 127:
																																			goto IL_03f6;
																																		case 10:
																																			goto IL_0401;
																																		case 78:
																																		case 115:
																																			goto IL_040c;
																																		case 72:
																																			goto IL_0428;
																																		case 124:
																																			goto IL_0436;
																																		case 92:
																																		case 118:
																																			goto IL_0444;
																																		case 106:
																																			goto IL_0457;
																																		case 110:
																																			goto IL_0462;
																																		case 137:
																																			goto IL_0483;
																																		case 91:
																																			goto IL_0491;
																																		case 13:
																																		case 62:
																																			goto IL_049c;
																																		case 84:
																																			goto IL_0507;
																																		case 48:
																																			goto IL_051a;
																																		case 56:
																																			goto IL_0528;
																																		case 77:
																																		case 107:
																																			goto IL_0533;
																																		case 38:
																																			goto IL_0556;
																																		case 0:
																																			goto IL_0564;
																																		case 35:
																																			goto IL_0572;
																																		case 26:
																																		case 98:
																																			goto IL_059c;
																																		case 66:
																																			goto IL_05aa;
																																		case 7:
																																		case 14:
																																			goto IL_05b8;
																																		case 61:
																																			goto IL_05f8;
																																		case 54:
																																			goto IL_060c;
																																		case 70:
																																			goto IL_063b;
																																		case 111:
																																			goto IL_0646;
																																		case 52:
																																		case 136:
																																			goto IL_0654;
																																		case 101:
																																			goto IL_0694;
																																		case 114:
																																			goto IL_06a8;
																																		case 60:
																																			goto IL_06c9;
																																		case 100:
																																			goto IL_06d7;
																																		case 81:
																																		case 88:
																																			goto IL_06e2;
																																		case 123:
																																			goto IL_06f0;
																																		case 74:
																																		case 121:
																																			goto IL_06fe;
																																		case 113:
																																			goto IL_0730;
																																		case 138:
																																			goto IL_073e;
																																		case 39:
																																			goto IL_0751;
																																		case 19:
																																		case 134:
																																			goto IL_075f;
																																		case 133:
																																			goto IL_0778;
																																		case 23:
																																			goto IL_0786;
																																		case 53:
																																			goto IL_0794;
																																		case 20:
																																		case 51:
																																			goto IL_07a7;
																																		case 45:
																																		case 49:
																																			goto IL_07c8;
																																		case 71:
																																			goto IL_0808;
																																		case 27:
																																			goto IL_081c;
																																		case 6:
																																		case 9:
																																		case 11:
																																		case 12:
																																		case 24:
																																		case 29:
																																		case 30:
																																		case 34:
																																		case 36:
																																		case 42:
																																		case 44:
																																		case 46:
																																		case 47:
																																		case 63:
																																		case 64:
																																		case 67:
																																		case 69:
																																		case 73:
																																		case 75:
																																		case 82:
																																		case 83:
																																		case 97:
																																		case 119:
																																		case 132:
																																		case 135:
																																			goto end_IL_0253;
																																		case 1:
																																		case 2:
																																		case 18:
																																		case 25:
																																		case 28:
																																		case 37:
																																		case 50:
																																		case 59:
																																		case 68:
																																		case 99:
																																		case 105:
																																		case 109:
																																		case 112:
																																		case 126:
																																		case 128:
																																		case 130:
																																		case 131:
																																			goto end_IL_033d;
																																		case 5:
																																			goto end_IL_0848;
																																		case 129:
																																			goto end_IL_085b;
																																		case 21:
																																			goto end_IL_086e;
																																		case 43:
																																			goto end_IL_0879;
																																		case 80:
																																		case 94:
																																			goto end_IL_088e;
																																		case 55:
																																			goto end_IL_089e;
																																		case 31:
																																		case 33:
																																			goto end_IL_08ae;
																																		case 102:
																																			goto end_IL_08be;
																																		case 103:
																																			goto end_IL_08d7;
																																		case 15:
																																		case 116:
																																			goto IL_08fb;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_033d;
																																	continue;
																																	end_IL_0253:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0358;
																											IL_0366:
																											if (4 > b)
																											{
																												break;
																											}
																											goto end_IL_033d;
																											IL_0358:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0366;
																										}
																										break;
																									}
																									goto IL_063b;
																									IL_06a8:
																									num5--;
																									goto end_IL_033d;
																									IL_063b:
																									if (6 < b)
																									{
																										num = 82;
																										break;
																									}
																									goto IL_0646;
																									IL_0646:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0654;
																									IL_0654:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0694;
																									IL_0694:
																									array[num5 - 2] = 0;
																									goto IL_06a8;
																								}
																								break;
																							}
																							goto IL_06c9;
																							IL_07a7:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 59;
																							goto end_IL_033d;
																							IL_06c9:
																							if (3 > b)
																							{
																								goto IL_06d7;
																							}
																							goto IL_07a7;
																							IL_06d7:
																							if (1 < b)
																							{
																								goto IL_06e2;
																							}
																							goto IL_0751;
																							IL_06e2:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_06f0;
																							IL_06f0:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_06fe;
																							IL_06fe:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 113;
																							goto IL_0730;
																							IL_0730:
																							ptr2 += 8;
																							goto IL_073e;
																							IL_073e:
																							num5--;
																							goto end_IL_033d;
																							IL_0751:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_075f;
																							IL_075f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0778;
																							IL_0778:
																							array[num5] = 0;
																							goto IL_0786;
																							IL_0786:
																							num5++;
																							goto IL_0794;
																							IL_0794:
																							ptr2 += 8;
																							goto end_IL_033d;
																						}
																						break;
																					}
																					goto IL_07c8;
																					IL_081c:
																					num5--;
																					num = 28;
																					goto end_IL_033d;
																					IL_07c8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0808;
																					IL_0808:
																					array[num5 - 2] = 0;
																					goto IL_081c;
																				}
																				break;
																			}
																			goto IL_0348;
																			IL_059c:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_05aa;
																			IL_0348:
																			if (11 >= b)
																			{
																				goto IL_0379;
																			}
																			goto IL_03f6;
																			IL_03f6:
																			if (13 >= b)
																			{
																				goto IL_0401;
																			}
																			goto IL_0457;
																			IL_0401:
																			if (13 <= b)
																			{
																				goto IL_040c;
																			}
																			goto IL_0428;
																			IL_040c:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_033d;
																			IL_0428:
																			if (12 < b)
																			{
																				break;
																			}
																			goto IL_0436;
																			IL_0436:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_0444;
																			IL_0444:
																			num5--;
																			goto end_IL_033d;
																			IL_0457:
																			if (14 < b)
																			{
																				num = 12;
																				break;
																			}
																			goto IL_0462;
																			IL_0462:
																			if (14 <= b)
																			{
																			}
																			break;
																			IL_05aa:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_05b8;
																			IL_0379:
																			if (11 <= b)
																			{
																				num = 86;
																				goto IL_0390;
																			}
																			goto IL_0483;
																			IL_05b8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05f8;
																			IL_0390:
																			array[num5 - 1] = 0;
																			goto IL_03a4;
																			IL_03a4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ParameterInfoSystemThreadingTasksTaskSchedulerDebugView[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_03e3;
																			IL_03e3:
																			ptr2 += 8;
																			goto end_IL_033d;
																			IL_0483:
																			if (9 >= b)
																			{
																				goto IL_0491;
																			}
																			num = 26;
																			goto IL_059c;
																			IL_0491:
																			if (9 <= b)
																			{
																				goto IL_049c;
																			}
																			goto IL_051a;
																			IL_049c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 84;
																			goto IL_0507;
																			IL_0507:
																			num5 -= 2;
																			goto end_IL_033d;
																			IL_051a:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0528;
																			IL_0528:
																			if (8 > b)
																			{
																				num = 46;
																				break;
																			}
																			goto IL_0533;
																			IL_0533:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0556;
																			IL_0556:
																			array[num5] = 0;
																			goto IL_0564;
																			IL_0564:
																			num5++;
																			goto IL_0572;
																			IL_0572:
																			ptr2 += 8;
																			goto end_IL_033d;
																			IL_060c:
																			num5--;
																			num = 130;
																			goto end_IL_033d;
																			IL_05f8:
																			array[num5 - 2] = 0;
																			goto IL_060c;
																		}
																		break;
																		IL_030d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_033d;
																continue;
																end_IL_031d:
																break;
															}
															continue;
															end_IL_032d:
															break;
														}
														continue;
														end_IL_033d:
														break;
													}
													continue;
												}
												goto IL_08fb;
												IL_08fb:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0848:
												break;
											}
											continue;
											end_IL_085b:
											break;
										}
										continue;
										end_IL_086e:
										break;
									}
									continue;
									end_IL_0879:
									break;
								}
								continue;
								end_IL_088e:
								break;
							}
							continue;
							end_IL_089e:
							break;
						}
						continue;
						end_IL_08ae:
						break;
					}
					continue;
					end_IL_08be:
					break;
				}
				continue;
				end_IL_08d7:
				break;
			}
		}
	}

	private static int smethod_5(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 235;
		num2 = 47;
		num += 47;
		num2 = 35;
		num2 = 7;
		int num6 = smethod_3(7);
		num2 = num6;
		return num;
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetSecurityDescriptorSddlFormGetPublicKey.FormatIntSetFault);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 93;
												while (true)
												{
													if (num == 93 || num != 1074)
													{
														goto IL_0239;
													}
													switch (num)
													{
													case 39:
														goto end_IL_0183;
													case 7:
														goto end_IL_0196;
													case 16:
														goto end_IL_01a9;
													case 82:
														goto end_IL_01b4;
													case 59:
														goto end_IL_01c9;
													case 52:
													case 76:
														goto end_IL_01de;
													case 78:
														goto end_IL_01ee;
													case 9:
													case 51:
														goto end_IL_01fe;
													case 60:
														goto end_IL_020e;
													case 61:
														goto end_IL_021e;
													case 6:
													case 10:
													case 14:
													case 17:
													case 18:
													case 33:
													case 47:
													case 68:
													case 74:
													case 83:
														goto IL_0239;
													case 58:
													case 72:
														goto IL_0249;
													case 27:
														goto IL_0252;
													case 20:
														goto IL_0260;
													case 80:
														goto IL_026e;
													case 15:
														goto IL_027c;
													case 11:
														goto IL_028a;
													case 53:
														goto IL_0298;
													case 1:
													case 46:
														goto IL_02a6;
													case 86:
														goto IL_02b4;
													case 73:
													case 75:
														goto IL_02c2;
													case 26:
														goto IL_0302;
													case 12:
														goto IL_0316;
													case 25:
														goto IL_0329;
													case 2:
													case 28:
														goto IL_0334;
													case 29:
														goto IL_0342;
													case 42:
													case 55:
														goto IL_0355;
													case 50:
														goto IL_03c3;
													case 56:
													case 63:
														goto IL_03d6;
													case 24:
														goto IL_03ff;
													case 41:
														goto IL_040d;
													case 45:
													case 84:
														goto IL_0429;
													case 65:
														goto IL_043d;
													case 44:
														goto IL_044b;
													case 23:
														goto IL_0459;
													case 43:
													case 77:
														goto IL_0467;
													case 85:
														goto IL_047f;
													case 37:
														goto IL_048a;
													case 32:
													case 62:
														goto IL_0498;
													case 22:
														goto IL_04a6;
													case 35:
														goto IL_04c9;
													case 31:
														goto IL_04d3;
													case 57:
														goto IL_04e1;
													case 71:
														goto IL_04f4;
													case 36:
														goto IL_04ff;
													case 19:
													case 49:
														goto IL_050a;
													case 79:
														goto IL_0526;
													case 3:
														goto IL_0534;
													case 40:
														goto IL_0542;
													case 0:
													case 5:
													case 13:
													case 21:
													case 30:
													case 34:
													case 38:
													case 48:
													case 54:
													case 64:
													case 66:
													case 67:
													case 69:
													case 70:
													case 81:
														goto IL_0555;
													case 4:
													case 8:
														goto IL_057a;
													}
													continue;
													IL_0526:
													array[num4] = 0;
													goto IL_0534;
													IL_0534:
													num4++;
													goto IL_0542;
													IL_0239:
													if (num5 != 1)
													{
														goto IL_0249;
													}
													goto IL_057a;
													IL_057a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0249:
													b = *ptr2;
													goto IL_0252;
													IL_0252:
													ptr2++;
													goto IL_0260;
													IL_0260:
													if (b >= 1)
													{
														goto IL_026e;
													}
													goto IL_0555;
													IL_026e:
													if (b <= 8)
													{
														goto IL_027c;
													}
													goto IL_0555;
													IL_027c:
													if (4 >= b)
													{
														goto IL_028a;
													}
													goto IL_0429;
													IL_028a:
													if (4 > b)
													{
														goto IL_0298;
													}
													goto IL_03d6;
													IL_0298:
													if (2 < b)
													{
														goto IL_02a6;
													}
													goto IL_0329;
													IL_02a6:
													if (3 >= b)
													{
														goto IL_02b4;
													}
													goto IL_0555;
													IL_02b4:
													if (3 <= b)
													{
														goto IL_02c2;
													}
													goto IL_0555;
													IL_02c2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0302;
													IL_0302:
													array[num4 - 2] = 0;
													goto IL_0316;
													IL_0316:
													num4--;
													goto IL_0239;
													IL_0329:
													if (2 > b)
													{
														goto IL_0334;
													}
													goto IL_0355;
													IL_0334:
													if (1 >= b)
													{
														goto IL_0342;
													}
													goto IL_0555;
													IL_0342:
													if (1 <= b)
													{
													}
													goto IL_0555;
													IL_0355:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_03c3;
													IL_03c3:
													num4 -= 2;
													goto IL_0239;
													IL_03d6:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_03ff;
													IL_03ff:
													ptr2 += 8;
													goto IL_040d;
													IL_040d:
													num4--;
													num = 17;
													goto IL_0239;
													IL_0429:
													if (6 >= b)
													{
														num = 65;
														goto IL_043d;
													}
													goto IL_047f;
													IL_0542:
													ptr2 += 8;
													goto IL_0239;
													IL_043d:
													if (6 <= b)
													{
														goto IL_0239;
													}
													goto IL_044b;
													IL_044b:
													if (5 >= b)
													{
														goto IL_0459;
													}
													goto IL_0555;
													IL_0459:
													if (5 <= b)
													{
														goto IL_0467;
													}
													goto IL_0555;
													IL_0467:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0239;
													IL_047f:
													if (7 >= b)
													{
														goto IL_048a;
													}
													goto IL_04f4;
													IL_048a:
													if (7 <= b)
													{
														goto IL_0498;
													}
													goto IL_0555;
													IL_0498:
													array[num4] = 0;
													goto IL_04a6;
													IL_04a6:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_04c9;
													IL_04c9:
													array2[num4] = null;
													goto IL_04d3;
													IL_04d3:
													num4++;
													goto IL_04e1;
													IL_04e1:
													ptr2 += 8;
													goto IL_0239;
													IL_04f4:
													if (8 >= b)
													{
														goto IL_04ff;
													}
													goto IL_0555;
													IL_04ff:
													if (8 <= b)
													{
														goto IL_050a;
													}
													goto IL_0555;
													IL_050a:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0239;
													IL_0555:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0526;
													continue;
													end_IL_0183:
													break;
												}
												continue;
												end_IL_0196:
												break;
											}
											continue;
											end_IL_01a9:
											break;
										}
										continue;
										end_IL_01b4:
										break;
									}
									continue;
									end_IL_01c9:
									break;
								}
								continue;
								end_IL_01de:
								break;
							}
							continue;
							end_IL_01ee:
							break;
						}
						continue;
						end_IL_01fe:
						break;
					}
					continue;
					end_IL_020e:
					break;
				}
				continue;
				end_IL_021e:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 17;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CriticalMultiDomain.pAttributeVCompatibilitySwitch);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02a3:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0283:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0276:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0266:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0256:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0246:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_021b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_020b:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_01f2:
																																num5++;
																																num = 116;
																																while (true)
																																{
																																	if (num != 116)
																																	{
																																		if (num != 1097)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 51:
																																			goto IL_01f2;
																																		case 70:
																																			goto IL_020b;
																																		case 66:
																																		case 67:
																																			goto IL_021b;
																																		case 7:
																																			goto IL_0236;
																																		case 98:
																																			goto IL_0246;
																																		case 61:
																																			goto IL_0256;
																																		case 20:
																																			goto IL_0266;
																																		case 89:
																																			goto IL_0276;
																																		case 74:
																																			goto IL_0283;
																																		case 72:
																																			goto IL_0293;
																																		case 92:
																																			goto IL_02a3;
																																		case 45:
																																			goto end_IL_02a3;
																																		case 0:
																																		case 35:
																																			goto end_IL_02b3;
																																		case 1:
																																		case 28:
																																			goto IL_02ce;
																																		case 41:
																																		case 54:
																																			goto IL_0313;
																																		case 25:
																																			goto IL_0321;
																																		case 62:
																																			goto IL_032f;
																																		case 34:
																																			goto IL_033a;
																																		case 2:
																																		case 10:
																																			goto IL_0351;
																																		case 30:
																																			goto IL_0396;
																																		case 59:
																																			goto IL_03a4;
																																		case 40:
																																		case 60:
																																			goto IL_03b2;
																																		case 13:
																																			goto IL_03d5;
																																		case 63:
																																			goto IL_03e8;
																																		case 12:
																																			goto IL_03f3;
																																		case 14:
																																			goto IL_0406;
																																		case 29:
																																			goto IL_0414;
																																		case 27:
																																		case 69:
																																			goto end_IL_01df;
																																		case 71:
																																			goto IL_043f;
																																		case 18:
																																			goto IL_0453;
																																		case 11:
																																		case 81:
																																			goto IL_0466;
																																		case 43:
																																			goto IL_04c8;
																																		case 85:
																																		case 90:
																																			goto IL_04db;
																																		case 47:
																																		case 86:
																																			goto IL_04e9;
																																		case 50:
																																			goto IL_04f7;
																																		case 37:
																																		case 79:
																																			goto IL_0505;
																																		case 91:
																																			goto IL_0515;
																																		case 96:
																																			goto IL_0531;
																																		case 33:
																																			goto IL_055d;
																																		case 24:
																																			goto IL_0567;
																																		case 31:
																																			goto IL_057e;
																																		case 97:
																																			goto IL_0591;
																																		case 99:
																																			goto IL_05a4;
																																		case 102:
																																			goto IL_05ba;
																																		case 104:
																																			goto IL_05cd;
																																		case 39:
																																		case 109:
																																			goto IL_05e0;
																																		case 107:
																																			goto IL_060c;
																																		case 65:
																																			goto IL_0617;
																																		case 15:
																																		case 38:
																																			goto IL_0622;
																																		case 95:
																																			goto IL_064b;
																																		case 106:
																																			goto IL_0659;
																																		case 3:
																																		case 8:
																																		case 9:
																																		case 16:
																																		case 19:
																																		case 26:
																																		case 36:
																																		case 42:
																																		case 44:
																																		case 49:
																																		case 57:
																																		case 68:
																																		case 75:
																																		case 77:
																																		case 84:
																																		case 87:
																																		case 100:
																																		case 103:
																																		case 108:
																																			goto end_IL_0236;
																																		case 5:
																																		case 21:
																																		case 22:
																																		case 46:
																																		case 48:
																																		case 52:
																																		case 53:
																																		case 58:
																																		case 73:
																																		case 78:
																																		case 80:
																																		case 82:
																																		case 88:
																																		case 105:
																																			goto end_IL_02c3;
																																		case 94:
																																			goto end_IL_067c;
																																		case 17:
																																			goto end_IL_068f;
																																		case 93:
																																			goto end_IL_0699;
																																		case 83:
																																			goto end_IL_06a4;
																																		case 32:
																																		case 76:
																																			goto end_IL_06c2;
																																		case 4:
																																			goto end_IL_06d2;
																																		case 64:
																																		case 101:
																																			goto end_IL_06e2;
																																		case 55:
																																			goto end_IL_06f2;
																																		case 56:
																																			goto end_IL_0702;
																																		case 6:
																																		case 23:
																																			goto IL_071d;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto end_IL_02c3;
																																	continue;
																																	end_IL_01df:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_0427;
																													continue;
																													end_IL_0236:
																													break;
																													IL_0236:;
																												}
																												break;
																											}
																											goto IL_060c;
																											IL_0659:
																											num5--;
																											goto end_IL_02c3;
																											IL_060c:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0617;
																											IL_0617:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0622;
																											IL_0622:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_064b;
																											IL_064b:
																											ptr2 += 8;
																											goto IL_0659;
																										}
																										break;
																									}
																									goto IL_0427;
																									IL_0427:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02c3;
																								}
																								break;
																							}
																							goto IL_04db;
																							IL_0591:
																							if (4 <= b)
																							{
																								goto end_IL_02c3;
																							}
																							break;
																							IL_04db:
																							if (4 < b)
																							{
																								goto IL_04e9;
																							}
																							goto IL_0591;
																							IL_04e9:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_04f7;
																							IL_04f7:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0505;
																							IL_0505:
																							array[num5] = 0;
																							goto IL_0531;
																							IL_0531:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							num = 33;
																							goto IL_055d;
																							IL_055d:
																							array2[num5] = null;
																							goto IL_0567;
																							IL_0567:
																							num5++;
																							num = 31;
																							goto IL_057e;
																							IL_057e:
																							ptr2 += 8;
																							goto end_IL_02c3;
																						}
																						break;
																					}
																					goto IL_02ce;
																					IL_0453:
																					num5--;
																					goto end_IL_02c3;
																					IL_02ce:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_043f;
																					IL_043f:
																					array[num5 - 2] = 0;
																					goto IL_0453;
																				}
																				break;
																			}
																			goto IL_0313;
																			IL_0406:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0414;
																			IL_0313:
																			if (9 >= b)
																			{
																				goto IL_0321;
																			}
																			goto IL_03e8;
																			IL_0321:
																			if (9 > b)
																			{
																				goto IL_032f;
																			}
																			goto IL_0466;
																			IL_032f:
																			if (7 >= b)
																			{
																				goto IL_033a;
																			}
																			goto IL_0396;
																			IL_033a:
																			if (7 > b)
																			{
																				break;
																			}
																			num = 10;
																			goto IL_0351;
																			IL_0414:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_0351:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05a4;
																			IL_05a4:
																			array[num5 - 2] = 0;
																			goto IL_05cd;
																			IL_05cd:
																			num5--;
																			goto end_IL_02c3;
																			IL_0396:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03a4;
																			IL_03a4:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_03b2;
																			IL_03b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03d5;
																			IL_03d5:
																			array[num5] = 0;
																			goto IL_0515;
																			IL_0515:
																			num5++;
																			num = 102;
																			goto IL_05ba;
																			IL_05ba:
																			ptr2 += 8;
																			goto end_IL_02c3;
																			IL_0466:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04c8;
																			IL_04c8:
																			num5 -= 2;
																			goto end_IL_02c3;
																			IL_03e8:
																			if (10 >= b)
																			{
																				goto IL_03f3;
																			}
																			goto IL_0406;
																			IL_03f3:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_05e0;
																			IL_05e0:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02c3;
																		}
																		break;
																		IL_0293:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02c3;
																continue;
																end_IL_02a3:
																break;
															}
															continue;
															end_IL_02b3:
															break;
														}
														continue;
														end_IL_02c3:
														break;
													}
													continue;
												}
												goto IL_071d;
												IL_071d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067c:
												break;
											}
											continue;
											end_IL_068f:
											break;
										}
										continue;
										end_IL_0699:
										break;
									}
									continue;
									end_IL_06a4:
									break;
								}
								continue;
								end_IL_06c2:
								break;
							}
							continue;
							end_IL_06d2:
							break;
						}
						continue;
						end_IL_06e2:
						break;
					}
					continue;
					end_IL_06f2:
					break;
				}
				continue;
				end_IL_0702:
				break;
			}
		}
	}

	static Class193()
	{
		int num = 9;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 2;
					while (true)
					{
						IL_0059:
						num = 16;
						while (true)
						{
							if (num != 16)
							{
								if (num != 997)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 2:
								case 3:
									goto IL_0059;
								case 1:
								case 4:
								case 5:
								case 6:
									goto end_IL_004c;
								case 8:
									goto end_IL_006b;
								case 9:
									goto end_IL_0080;
								case 7:
									return;
								}
								continue;
							}
							string_0 = "PointGun";
							return;
							continue;
							end_IL_004c:
							break;
						}
						break;
					}
					continue;
					end_IL_006b:
					break;
				}
				continue;
				end_IL_0080:
				break;
			}
		}
	}

	private static void smethod_9(Class193 class193_1)
	{
		class193_1.method_1();
	}
}
