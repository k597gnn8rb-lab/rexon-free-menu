using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 222)]
internal struct AddOnLogMessageAssemblyReferenceDependentAssemblyHashAlgorithm
{
	internal static AddOnLogMessageAssemblyReferenceDependentAssemblyHashAlgorithm GetSizeAccessedThroughPropertyAttribute/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 01 01 00 00 00 01 00 00 00 00 00 00 00 00 02 00 00 00 02 02 00 00 00 03 00 00 00 66 66 00 00 00 04 05 00 00 00 01 01 00 00 00 05 00 00 00 02 02 00 00 00 06 02 00 00 00 01 01 00 00 00 05 00 00 00 02 02 00 00 00 01 00 00 00 01 01 00 00 00 06 02 00 00 00 02 02 00 00 00 04 05 00 00 00 02 02 00 00 00 07 00 00 00 00 00 00 00 00 08 00 00 00 2D 2D 00 00 00 00 00 00 B7 B7 00 00 00 0D 00 00 00 B7 B7 00 00 00 04 05 00 00 00 02 02 00 00 00 07 00 00 00 00 00 00 00 00 08 00 00 00 2D 2D 00 00 00 00 00 00 B7 B7 00 00 00 05 00 00 00 01 01 00 00 00 01 00 00 00 82 82 00 00 00 01 00 00 00 05 05 00 00 00 09 0A 00 00 00 00 00 00 00 00 0B 0C) */;
}
