using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti Guardian Mods Self", "Safety", "Block guardian mod effects on self.", false, 8, ModType.const_0, false)]
internal class Class143 : MonoBehaviour
{
	internal static bool bool_0;

	private static bool bool_1;

	private static double double_0;

	private static int int_0;

	private static bool bool_2;

	private static float float_0;

	private static bool bool_3;

	private static float float_1;

	private static IntPtr[] DaylightTimeStubHelpers;

	private static IntPtr[] VTBSTRDomainCompressedStack;

	private static IntPtr[] intptr_0;

	private static IntPtr[] setPercentNegativePatternEndScope;

	private unsafe void OnEnable()
	{
		int num = 137;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CorrelationHintAppDomain.LogicalCallContextUseExisting);
									num = 31;
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_0284:
														if (b < 1)
														{
															num = 149;
															while (num != 149)
															{
																if (num != 1130)
																{
																	goto IL_087b;
																}
																switch (num)
																{
																case 44:
																	goto IL_0284;
																case 60:
																	goto end_IL_0284;
																case 38:
																case 41:
																	goto end_IL_0294;
																case 133:
																	goto IL_02af;
																case 88:
																	goto IL_02bd;
																case 48:
																case 51:
																	goto IL_02cb;
																case 108:
																case 109:
																	goto IL_02d9;
																case 57:
																case 81:
																	goto IL_02e4;
																case 35:
																	goto IL_02f2;
																case 65:
																case 69:
																	goto IL_0300;
																case 9:
																	goto IL_031c;
																case 117:
																	goto IL_0327;
																case 67:
																	goto IL_0335;
																case 50:
																case 112:
																	goto IL_0348;
																case 126:
																	goto IL_0362;
																case 4:
																	goto IL_0375;
																case 34:
																	goto IL_0383;
																case 66:
																case 70:
																	goto IL_0391;
																case 96:
																	goto IL_039f;
																case 24:
																case 32:
																	goto IL_03ad;
																case 129:
																	goto IL_040f;
																case 85:
																	goto IL_0422;
																case 118:
																	goto IL_042d;
																case 17:
																	goto IL_043b;
																case 16:
																case 54:
																	goto IL_0449;
																case 3:
																case 14:
																	goto IL_045c;
																case 15:
																	goto IL_049c;
																case 28:
																	goto IL_04b0;
																case 18:
																case 39:
																	goto IL_04c3;
																case 52:
																	goto IL_04dc;
																case 87:
																case 104:
																	goto IL_04ea;
																case 45:
																	goto IL_0533;
																case 99:
																	goto IL_0547;
																case 139:
																	goto IL_0568;
																case 56:
																	goto IL_05bc;
																case 106:
																	goto IL_05ca;
																case 43:
																case 140:
																	goto IL_05dd;
																case 107:
																	goto IL_05eb;
																case 10:
																case 53:
																	goto IL_05f9;
																case 11:
																case 19:
																	goto IL_0607;
																case 76:
																	goto IL_0615;
																case 113:
																case 138:
																	goto IL_0623;
																case 62:
																	goto IL_0663;
																case 114:
																	goto IL_0677;
																case 111:
																	goto IL_068a;
																case 80:
																case 121:
																	goto IL_069d;
																case 73:
																	goto IL_06c6;
																case 68:
																	goto IL_06d4;
																case 141:
																	goto IL_06e7;
																case 47:
																	goto IL_06f5;
																case 82:
																case 105:
																	goto IL_0709;
																case 5:
																	goto IL_0749;
																case 49:
																	goto IL_075d;
																case 2:
																	goto IL_0770;
																case 55:
																	goto IL_077e;
																case 42:
																case 91:
																	goto IL_078c;
																case 103:
																	goto IL_079a;
																case 97:
																	goto IL_07bd;
																case 94:
																	goto IL_07c7;
																case 83:
																	goto IL_07d5;
																case 127:
																	goto IL_07e8;
																case 37:
																	goto IL_07f3;
																case 125:
																case 142:
																	goto IL_07fe;
																case 72:
																	goto IL_083e;
																case 95:
																	goto IL_0852;
																case 0:
																case 6:
																case 8:
																case 12:
																case 13:
																case 20:
																case 21:
																case 23:
																case 25:
																case 27:
																case 30:
																case 36:
																case 64:
																case 71:
																case 77:
																case 84:
																case 100:
																case 101:
																case 115:
																case 122:
																case 124:
																case 128:
																case 130:
																case 131:
																case 134:
																case 135:
																	goto end_IL_0271;
																case 132:
																	goto IL_087b;
																case 74:
																	goto IL_0889;
																case 98:
																	goto IL_0897;
																case 1:
																case 7:
																case 29:
																case 40:
																case 46:
																case 59:
																case 63:
																case 75:
																case 78:
																case 79:
																case 86:
																case 89:
																case 90:
																case 102:
																case 116:
																case 120:
																case 123:
																	goto end_IL_02a4;
																case 31:
																	goto end_IL_08a5;
																case 61:
																	goto end_IL_08b5;
																case 26:
																	goto end_IL_08bf;
																case 33:
																case 92:
																	goto end_IL_08d3;
																case 119:
																	goto end_IL_08e3;
																case 58:
																case 110:
																	goto end_IL_08f3;
																case 136:
																	goto end_IL_0903;
																case 137:
																	goto end_IL_0913;
																case 22:
																case 93:
																	return;
																}
																continue;
																end_IL_0271:
																break;
															}
															goto IL_0862;
														}
														goto IL_02af;
														IL_0862:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_087b;
														IL_087b:
														array[num5] = 0;
														goto IL_0889;
														IL_02af:
														if (b <= 14)
														{
															goto IL_02bd;
														}
														num = 27;
														goto IL_0862;
														IL_02bd:
														if (7 < b)
														{
															goto IL_02cb;
														}
														goto IL_04dc;
														IL_02cb:
														if (11 < b)
														{
															goto IL_02d9;
														}
														goto IL_0375;
														IL_02d9:
														if (13 < b)
														{
															goto IL_02e4;
														}
														goto IL_031c;
														IL_02e4:
														if (14 >= b)
														{
															goto IL_02f2;
														}
														goto IL_0862;
														IL_02f2:
														if (14 <= b)
														{
															goto IL_0300;
														}
														goto IL_0862;
														IL_0300:
														byte* num6 = ptr2;
														num4 = 1;
														ptr2 = num6 + -200;
														goto end_IL_02a4;
														IL_031c:
														if (13 > b)
														{
															goto IL_0327;
														}
														goto IL_0348;
														IL_0327:
														if (12 >= b)
														{
															goto IL_0335;
														}
														goto IL_0862;
														IL_0335:
														if (12 <= b)
														{
															goto end_IL_02a4;
														}
														goto IL_0862;
														IL_0348:
														bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														goto IL_0362;
														IL_0362:
														num5--;
														goto end_IL_02a4;
														IL_0375:
														if (11 > b)
														{
															goto IL_0383;
														}
														goto IL_04c3;
														IL_0383:
														if (9 < b)
														{
															goto IL_0391;
														}
														goto IL_0422;
														IL_0391:
														if (10 >= b)
														{
															goto IL_039f;
														}
														goto IL_0862;
														IL_039f:
														if (10 <= b)
														{
															goto IL_03ad;
														}
														goto IL_0862;
														IL_03ad:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_040f;
														IL_040f:
														num5 -= 2;
														goto end_IL_02a4;
														IL_0422:
														if (9 > b)
														{
															goto IL_042d;
														}
														goto IL_045c;
														IL_042d:
														if (8 >= b)
														{
															goto IL_043b;
														}
														goto IL_0862;
														IL_043b:
														if (8 <= b)
														{
															goto IL_0449;
														}
														goto IL_0862;
														IL_0449:
														num5--;
														goto end_IL_02a4;
														IL_045c:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_049c;
														IL_049c:
														array[num5 - 2] = 0;
														goto IL_04b0;
														IL_04b0:
														num5--;
														goto end_IL_02a4;
														IL_04c3:
														array[num5 - 2] = 0;
														goto IL_0568;
														IL_0568:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)DaylightTimeStubHelpers[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_05bc;
														IL_05bc:
														num5--;
														goto IL_05ca;
														IL_05ca:
														ptr2 += 8;
														goto end_IL_02a4;
														IL_04dc:
														if (7 <= b)
														{
															goto IL_04ea;
														}
														goto IL_05dd;
														IL_04ea:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														num = 45;
														goto IL_0533;
														IL_0533:
														array[num5 - 2] = 0;
														goto IL_0547;
														IL_0547:
														num5--;
														goto end_IL_02a4;
														IL_05dd:
														if (3 >= b)
														{
															goto IL_05eb;
														}
														goto IL_06e7;
														IL_05eb:
														if (3 > b)
														{
															goto IL_05f9;
														}
														goto IL_069d;
														IL_05f9:
														if (1 < b)
														{
															goto IL_0607;
														}
														goto IL_068a;
														IL_0607:
														if (2 >= b)
														{
															goto IL_0615;
														}
														goto IL_0862;
														IL_0615:
														if (2 <= b)
														{
															goto IL_0623;
														}
														goto IL_0862;
														IL_0623:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0663;
														IL_0663:
														array[num5 - 2] = 0;
														goto IL_0677;
														IL_0677:
														num5--;
														goto end_IL_02a4;
														IL_068a:
														if (1 > b)
														{
														}
														goto IL_0862;
														IL_069d:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_06c6;
														IL_06c6:
														ptr2 += 8;
														goto IL_06d4;
														IL_06d4:
														num5--;
														goto end_IL_02a4;
														IL_06e7:
														if (5 >= b)
														{
															goto IL_06f5;
														}
														goto IL_07e8;
														IL_06f5:
														if (5 <= b)
														{
															num = 82;
															goto IL_0709;
														}
														goto IL_0770;
														IL_0897:
														ptr2 += 8;
														goto end_IL_02a4;
														IL_0709:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0749;
														IL_0749:
														array[num5 - 2] = 0;
														goto IL_075d;
														IL_075d:
														num5--;
														goto end_IL_02a4;
														IL_0770:
														if (4 >= b)
														{
															goto IL_077e;
														}
														goto IL_0862;
														IL_077e:
														if (4 <= b)
														{
															goto IL_078c;
														}
														goto IL_0862;
														IL_078c:
														array[num5] = 0;
														goto IL_079a;
														IL_079a:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
														goto IL_07bd;
														IL_07bd:
														array2[num5] = null;
														goto IL_07c7;
														IL_07c7:
														num5++;
														goto IL_07d5;
														IL_07d5:
														ptr2 += 8;
														goto end_IL_02a4;
														IL_07e8:
														if (6 >= b)
														{
															goto IL_07f3;
														}
														goto IL_0862;
														IL_07f3:
														if (6 <= b)
														{
															goto IL_07fe;
														}
														goto IL_0862;
														IL_07fe:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_083e;
														IL_083e:
														array[num5 - 2] = 0;
														goto IL_0852;
														IL_0852:
														num5--;
														goto end_IL_02a4;
														IL_0889:
														num5++;
														goto IL_0897;
														continue;
														end_IL_0284:
														break;
													}
													continue;
													end_IL_0294:
													break;
												}
												continue;
												end_IL_02a4:
												break;
											}
											continue;
											end_IL_08a5:
											break;
										}
										continue;
										end_IL_08b5:
										break;
									}
									continue;
									end_IL_08bf:
									break;
								}
								continue;
								end_IL_08d3:
								break;
							}
							continue;
							end_IL_08e3:
							break;
						}
						continue;
						end_IL_08f3:
						break;
					}
					continue;
					end_IL_0903:
					break;
				}
				continue;
				end_IL_0913:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 133;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OpenScopegetWriterSeqNum.getCompletedSynchronouslygetIsParamDef);
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												IL_0360:
												byte b = *ptr2;
												while (true)
												{
													IL_0350:
													ptr2++;
													while (true)
													{
														IL_0340:
														if (b >= 1)
														{
															while (b <= 14)
															{
																while (true)
																{
																	IL_0320:
																	if (7 >= b)
																	{
																		while (true)
																		{
																			IL_0313:
																			if (7 > b)
																			{
																				while (true)
																				{
																					IL_0303:
																					if (3 < b)
																					{
																						while (true)
																						{
																							IL_02f3:
																							if (5 >= b)
																							{
																								while (true)
																								{
																									IL_02e3:
																									if (5 <= b)
																									{
																										while (true)
																										{
																											IL_02a1:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_028b:
																												array[num5 - 2] = 0;
																												while (true)
																												{
																													IL_0272:
																													num5--;
																													num = 148;
																													while (num != 148)
																													{
																														if (num != 1129)
																														{
																															goto end_IL_0330;
																														}
																														switch (num)
																														{
																														case 53:
																															goto IL_0272;
																														case 138:
																															goto IL_028b;
																														case 87:
																														case 96:
																															goto IL_02a1;
																														case 111:
																															goto IL_02e3;
																														case 66:
																															goto IL_02f3;
																														case 127:
																															goto IL_0303;
																														case 38:
																															goto IL_0313;
																														case 39:
																															goto IL_0320;
																														case 108:
																															goto IL_0330;
																														case 61:
																															goto IL_0340;
																														case 130:
																															goto IL_0350;
																														case 51:
																														case 106:
																															goto IL_0360;
																														case 4:
																														case 14:
																															goto IL_036b;
																														case 71:
																															goto IL_03ab;
																														case 45:
																														case 94:
																															goto IL_03c1;
																														case 10:
																															goto IL_03cf;
																														case 99:
																															goto IL_03df;
																														case 5:
																														case 101:
																															goto IL_03f2;
																														case 92:
																															goto IL_0400;
																														case 30:
																															goto IL_042c;
																														case 88:
																															goto IL_0436;
																														case 105:
																															goto IL_0444;
																														case 128:
																															goto IL_0457;
																														case 22:
																														case 120:
																															goto IL_0462;
																														case 72:
																															goto IL_048b;
																														case 34:
																															goto IL_04a2;
																														case 102:
																															goto IL_04b5;
																														case 68:
																															goto IL_04c0;
																														case 73:
																															goto IL_04d3;
																														case 17:
																															goto IL_04e1;
																														case 56:
																														case 103:
																															goto IL_04ef;
																														case 83:
																															goto IL_0538;
																														case 60:
																															goto IL_054c;
																														case 26:
																														case 141:
																															goto IL_055f;
																														case 116:
																															goto IL_056d;
																														case 36:
																														case 131:
																															goto IL_057b;
																														case 63:
																															goto IL_05bb;
																														case 59:
																															goto IL_05cf;
																														case 40:
																															goto IL_05e2;
																														case 115:
																															goto IL_05f0;
																														case 74:
																														case 134:
																															goto IL_05fe;
																														case 136:
																															goto IL_0612;
																														case 25:
																															goto IL_0666;
																														case 125:
																															goto IL_0674;
																														case 23:
																														case 79:
																															goto IL_0687;
																														case 62:
																															goto IL_0695;
																														case 67:
																														case 70:
																															goto IL_06a0;
																														case 135:
																															goto IL_06ae;
																														case 77:
																														case 86:
																															goto IL_06bc;
																														case 37:
																														case 126:
																															goto IL_06cf;
																														case 19:
																															goto IL_0718;
																														case 8:
																															goto IL_0735;
																														case 13:
																															goto IL_0748;
																														case 15:
																															goto IL_0756;
																														case 2:
																														case 140:
																															goto IL_0764;
																														case 57:
																															goto IL_07c6;
																														case 32:
																														case 124:
																															goto IL_07d9;
																														case 29:
																															goto IL_07e4;
																														case 64:
																														case 65:
																															goto IL_07ef;
																														case 50:
																															goto IL_07fa;
																														case 9:
																														case 123:
																															goto IL_0815;
																														case 84:
																															goto IL_082f;
																														case 114:
																															goto IL_084b;
																														case 121:
																															goto IL_0856;
																														case 46:
																														case 49:
																															goto IL_0861;
																														case 0:
																														case 1:
																														case 3:
																														case 6:
																														case 12:
																														case 18:
																														case 28:
																														case 35:
																														case 43:
																														case 47:
																														case 48:
																														case 54:
																														case 55:
																														case 58:
																														case 69:
																														case 75:
																														case 81:
																														case 90:
																														case 91:
																														case 95:
																														case 97:
																														case 98:
																														case 100:
																														case 109:
																														case 110:
																														case 112:
																														case 117:
																															goto end_IL_0330;
																														case 31:
																															goto IL_08a5;
																														case 20:
																															goto IL_08b3;
																														case 122:
																															goto IL_08c1;
																														case 11:
																														case 21:
																														case 24:
																														case 27:
																														case 33:
																														case 41:
																														case 44:
																														case 52:
																														case 78:
																														case 89:
																														case 104:
																														case 107:
																														case 118:
																														case 129:
																														case 137:
																														case 139:
																															goto end_IL_025f;
																														case 85:
																															goto end_IL_08d8;
																														case 80:
																															goto end_IL_08e8;
																														case 7:
																															goto end_IL_08f2;
																														case 82:
																														case 93:
																															goto end_IL_08fd;
																														case 16:
																															goto end_IL_090d;
																														case 42:
																														case 76:
																															goto end_IL_091d;
																														case 132:
																															goto end_IL_092d;
																														case 133:
																															goto end_IL_093d;
																														case 113:
																														case 119:
																															return;
																														}
																														continue;
																														end_IL_025f:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03c1;
																									IL_0444:
																									ptr2 += 8;
																									break;
																									IL_03c1:
																									if (4 < b)
																									{
																										goto end_IL_0330;
																									}
																									goto IL_03cf;
																									IL_03cf:
																									if (4 > b)
																									{
																										goto end_IL_0330;
																									}
																									goto IL_03f2;
																									IL_03f2:
																									array[num5] = 0;
																									goto IL_0400;
																									IL_0400:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									num = 30;
																									goto IL_042c;
																									IL_042c:
																									array2[num5] = null;
																									goto IL_0436;
																									IL_0436:
																									num5++;
																									goto IL_0444;
																								}
																								break;
																							}
																							goto IL_055f;
																							IL_05cf:
																							num5--;
																							break;
																							IL_055f:
																							if (6 < b)
																							{
																								goto end_IL_0330;
																							}
																							goto IL_056d;
																							IL_056d:
																							if (6 > b)
																							{
																								goto end_IL_0330;
																							}
																							goto IL_057b;
																							IL_057b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05bb;
																							IL_05bb:
																							array[num5 - 2] = 0;
																							goto IL_05cf;
																						}
																						break;
																					}
																					goto IL_0457;
																					IL_054c:
																					num5--;
																					break;
																					IL_0457:
																					if (3 <= b)
																					{
																						goto IL_0462;
																					}
																					goto IL_04b5;
																					IL_0462:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_048b;
																					IL_048b:
																					ptr2 += 8;
																					num = 34;
																					goto IL_04a2;
																					IL_04a2:
																					num5--;
																					break;
																					IL_04b5:
																					if (1 >= b)
																					{
																						goto IL_04c0;
																					}
																					goto IL_04d3;
																					IL_04c0:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_0330;
																					IL_04d3:
																					if (2 < b)
																					{
																						goto end_IL_0330;
																					}
																					goto IL_04e1;
																					IL_04e1:
																					if (2 > b)
																					{
																						goto end_IL_0330;
																					}
																					goto IL_04ef;
																					IL_04ef:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 83;
																					goto IL_0538;
																					IL_0538:
																					array[num5 - 2] = 0;
																					goto IL_054c;
																				}
																				break;
																			}
																			goto IL_036b;
																			IL_03df:
																			num5--;
																			break;
																			IL_036b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03ab;
																			IL_03ab:
																			array[num5 - 2] = 0;
																			goto IL_03df;
																		}
																		break;
																	}
																	goto IL_05e2;
																	IL_0856:
																	if (14 > b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_0861;
																	IL_05e2:
																	if (11 >= b)
																	{
																		goto IL_05f0;
																	}
																	goto IL_07d9;
																	IL_05f0:
																	if (11 <= b)
																	{
																		goto IL_05fe;
																	}
																	goto IL_0687;
																	IL_05fe:
																	array[num5 - 2] = 0;
																	goto IL_0612;
																	IL_0612:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)VTBSTRDomainCompressedStack[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	goto IL_0666;
																	IL_0666:
																	num5--;
																	goto IL_0674;
																	IL_0674:
																	ptr2 += 8;
																	break;
																	IL_0687:
																	if (9 >= b)
																	{
																		goto IL_0695;
																	}
																	goto IL_0748;
																	IL_0695:
																	if (9 > b)
																	{
																		goto IL_06a0;
																	}
																	goto IL_06cf;
																	IL_06a0:
																	if (8 < b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_06ae;
																	IL_06ae:
																	if (8 > b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_06bc;
																	IL_06bc:
																	num5--;
																	break;
																	IL_06cf:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	num = 19;
																	goto IL_0718;
																	IL_0718:
																	array[num5 - 2] = 0;
																	num = 8;
																	goto IL_0735;
																	IL_0735:
																	num5--;
																	break;
																	IL_0748:
																	if (10 < b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_0756;
																	IL_0756:
																	if (10 > b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_0764;
																	IL_0764:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_07c6;
																	IL_07c6:
																	num5 -= 2;
																	break;
																	IL_07d9:
																	if (13 >= b)
																	{
																		goto IL_07e4;
																	}
																	goto IL_084b;
																	IL_07e4:
																	if (13 > b)
																	{
																		goto IL_07ef;
																	}
																	goto IL_0815;
																	IL_07ef:
																	if (12 < b)
																	{
																		num = 100;
																		goto end_IL_0330;
																	}
																	goto IL_07fa;
																	IL_07fa:
																	if (12 > b)
																	{
																		goto end_IL_0330;
																	}
																	break;
																	IL_0861:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_0815:
																	bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																	goto IL_082f;
																	IL_082f:
																	num5--;
																	num = 33;
																	break;
																	IL_084b:
																	if (14 < b)
																	{
																		goto end_IL_0330;
																	}
																	goto IL_0856;
																}
																goto end_IL_0340;
																continue;
																end_IL_0330:
																break;
																IL_0330:;
															}
														}
														else
														{
															num = 35;
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														num = 31;
														goto IL_08a5;
														IL_08b3:
														num5++;
														goto IL_08c1;
														IL_08c1:
														ptr2 += 8;
														num = 52;
														break;
														IL_08a5:
														array[num5] = 0;
														goto IL_08b3;
														continue;
														end_IL_0340:
														break;
													}
													break;
												}
												break;
											}
											continue;
											end_IL_08d8:
											break;
										}
										continue;
										end_IL_08e8:
										break;
									}
									continue;
									end_IL_08f2:
									break;
								}
								continue;
								end_IL_08fd:
								break;
							}
							continue;
							end_IL_090d:
							break;
						}
						continue;
						end_IL_091d:
						break;
					}
					continue;
					end_IL_092d:
					break;
				}
				continue;
				end_IL_093d:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		int num = 8;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 7;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContractFailedEventArgsgetPercentSymbol.VarArgsSoapNegativeInteger);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													IL_03ad:
													byte b = *ptr2;
													num = 76;
													while (true)
													{
														IL_0394:
														ptr2++;
														num = 161;
														while (true)
														{
															IL_0384:
															if (b >= 1)
															{
																while (b <= 21)
																{
																	num = 131;
																	while (true)
																	{
																		IL_0361:
																		if (11 >= b)
																		{
																			while (11 > b)
																			{
																				while (true)
																				{
																					IL_0341:
																					if (5 >= b)
																					{
																						goto IL_05ff;
																					}
																					while (true)
																					{
																						IL_0331:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_031e:
																								if (8 <= b)
																								{
																									num = 184;
																									while (true)
																									{
																										if (num != 184)
																										{
																											if (num != 1165)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 134:
																												goto IL_031e;
																											case 23:
																												goto IL_0331;
																											case 91:
																												goto IL_0341;
																											case 116:
																												goto end_IL_0341;
																											case 131:
																												goto IL_0361;
																											case 20:
																												goto IL_0371;
																											case 161:
																												goto IL_0384;
																											case 76:
																												goto IL_0394;
																											case 106:
																											case 172:
																												goto IL_03ad;
																											case 54:
																												goto IL_03c1;
																											case 21:
																												goto IL_03d5;
																											case 4:
																											case 37:
																												goto IL_03e3;
																											case 93:
																												goto IL_0428;
																											case 73:
																												goto IL_0436;
																											case 28:
																											case 159:
																												goto IL_0444;
																											case 82:
																												goto IL_0484;
																											case 84:
																												goto IL_0498;
																											case 164:
																												goto IL_04ab;
																											case 19:
																												goto IL_04bf;
																											case 140:
																												goto IL_04d2;
																											case 13:
																												goto IL_04e5;
																											case 96:
																												goto IL_04f0;
																											case 9:
																											case 52:
																												goto IL_04fe;
																											case 176:
																												goto IL_053e;
																											case 174:
																												goto IL_055b;
																											case 57:
																												goto IL_056e;
																											case 22:
																												goto IL_057c;
																											case 94:
																											case 97:
																												goto IL_058a;
																											case 6:
																												goto IL_05ec;
																											case 160:
																												goto IL_05ff;
																											case 15:
																											case 154:
																												goto IL_060a;
																											case 135:
																												goto IL_064a;
																											case 162:
																												goto IL_0667;
																											case 10:
																												goto IL_067a;
																											case 177:
																												goto IL_0688;
																											case 16:
																											case 30:
																												goto IL_0693;
																											case 132:
																												goto IL_06d3;
																											case 81:
																												goto IL_06f0;
																											case 122:
																												goto IL_0703;
																											case 3:
																												goto IL_0711;
																											case 17:
																											case 26:
																												goto IL_071f;
																											case 110:
																												goto IL_0738;
																											case 163:
																												goto IL_0746;
																											case 147:
																												goto IL_075d;
																											case 53:
																												goto IL_0770;
																											case 107:
																												goto IL_077b;
																											case 55:
																											case 86:
																												goto IL_0789;
																											case 102:
																												goto IL_07b2;
																											case 99:
																												goto end_IL_030b;
																											case 41:
																												goto IL_07d3;
																											case 88:
																												goto IL_07e1;
																											case 24:
																											case 78:
																												goto IL_07ef;
																											case 47:
																												goto IL_07fd;
																											case 36:
																												goto IL_0820;
																											case 77:
																												goto IL_082a;
																											case 98:
																												goto IL_0838;
																											case 133:
																												goto IL_084b;
																											case 105:
																												goto IL_0859;
																											case 125:
																												goto IL_0867;
																											case 48:
																											case 72:
																												goto IL_0872;
																											case 69:
																												goto IL_0886;
																											case 70:
																												goto IL_08c5;
																											case 113:
																												goto IL_08d8;
																											case 111:
																												goto IL_08e6;
																											case 33:
																												goto IL_08f4;
																											case 5:
																											case 32:
																												goto IL_0902;
																											case 25:
																												goto IL_0942;
																											case 119:
																												goto IL_0956;
																											case 158:
																												goto IL_0969;
																											case 14:
																											case 58:
																												goto IL_0977;
																											case 118:
																												goto IL_0990;
																											case 175:
																												goto IL_099e;
																											case 59:
																												goto IL_09b5;
																											case 95:
																												goto IL_09c8;
																											case 126:
																												goto IL_09d3;
																											case 127:
																											case 166:
																												goto IL_09e1;
																											case 104:
																												goto IL_09fd;
																											case 40:
																												goto IL_0a0b;
																											case 142:
																												goto IL_0a1e;
																											case 46:
																											case 49:
																												goto IL_0a29;
																											case 168:
																												goto IL_0a43;
																											case 2:
																												goto IL_0a56;
																											case 71:
																												goto IL_0a64;
																											case 83:
																											case 85:
																												goto IL_0a6f;
																											case 171:
																												goto IL_0a87;
																											case 44:
																												goto IL_0a95;
																											case 74:
																											case 108:
																												goto IL_0aac;
																											case 61:
																												goto IL_0ac5;
																											case 79:
																												goto IL_0ad3;
																											case 139:
																												goto IL_0ae1;
																											case 112:
																												goto IL_0af4;
																											case 35:
																												goto IL_0aff;
																											case 100:
																											case 101:
																												goto IL_0b0d;
																											case 50:
																												goto IL_0b4e;
																											case 143:
																												goto IL_0b62;
																											case 130:
																												goto IL_0b75;
																											case 60:
																												goto IL_0b89;
																											case 31:
																											case 51:
																												goto IL_0b94;
																											case 45:
																												goto IL_0be6;
																											case 0:
																											case 1:
																											case 18:
																											case 27:
																											case 42:
																											case 66:
																											case 67:
																											case 75:
																											case 80:
																											case 89:
																											case 103:
																											case 115:
																											case 121:
																											case 123:
																											case 128:
																											case 136:
																											case 137:
																											case 138:
																											case 149:
																											case 155:
																											case 156:
																											case 165:
																											case 169:
																											case 170:
																												goto end_IL_0371;
																											case 11:
																											case 12:
																											case 29:
																											case 34:
																											case 38:
																											case 39:
																											case 43:
																											case 56:
																											case 62:
																											case 65:
																											case 68:
																											case 87:
																											case 92:
																											case 109:
																											case 129:
																											case 141:
																											case 146:
																											case 148:
																											case 150:
																											case 151:
																											case 152:
																											case 153:
																											case 157:
																											case 173:
																												goto end_IL_0351;
																											case 90:
																												goto end_IL_0c09;
																											case 167:
																												goto end_IL_0c1c;
																											case 124:
																												goto end_IL_0c26;
																											case 63:
																											case 114:
																												goto end_IL_0c31;
																											case 64:
																												goto end_IL_0c41;
																											case 144:
																												goto end_IL_0c51;
																											case 117:
																												goto end_IL_0c61;
																											case 7:
																												goto end_IL_0c71;
																											case 8:
																												goto end_IL_0c81;
																											case 120:
																											case 145:
																												return;
																											}
																											continue;
																										}
																										goto IL_04d2;
																										IL_04d2:
																										num6--;
																										goto end_IL_0351;
																										continue;
																										end_IL_030b:
																										break;
																									}
																									break;
																								}
																								goto IL_03c1;
																								IL_0444:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0484;
																								IL_0484:
																								array[num6 - 2] = 0;
																								goto IL_0498;
																								IL_03c1:
																								if (6 >= b)
																								{
																									num = 21;
																									goto IL_03d5;
																								}
																								goto IL_0428;
																								IL_0498:
																								num6--;
																								goto end_IL_0351;
																								IL_03d5:
																								if (6 > b)
																								{
																									goto end_IL_0371;
																								}
																								goto IL_03e3;
																								IL_03e3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_04ab;
																								IL_04ab:
																								array[num6 - 2] = 0;
																								goto IL_04bf;
																								IL_04bf:
																								num6--;
																								goto end_IL_0351;
																								IL_0428:
																								if (7 < b)
																								{
																									goto end_IL_0371;
																								}
																								goto IL_0436;
																								IL_0436:
																								if (7 > b)
																								{
																									goto end_IL_0371;
																								}
																								goto IL_0444;
																							}
																							break;
																						}
																						goto IL_04e5;
																						IL_05ec:
																						num6 -= 2;
																						goto end_IL_0351;
																						IL_04e5:
																						if (9 >= b)
																						{
																							goto IL_04f0;
																						}
																						goto IL_056e;
																						IL_04f0:
																						if (9 > b)
																						{
																							goto end_IL_0371;
																						}
																						goto IL_04fe;
																						IL_04fe:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_053e;
																						IL_053e:
																						array[num6 - 2] = 0;
																						num = 174;
																						goto IL_055b;
																						IL_055b:
																						num6--;
																						goto end_IL_0351;
																						IL_056e:
																						if (10 < b)
																						{
																							goto end_IL_0371;
																						}
																						goto IL_057c;
																						IL_057c:
																						if (10 > b)
																						{
																							goto end_IL_0371;
																						}
																						goto IL_058a;
																						IL_058a:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_05ec;
																					}
																					goto IL_07c0;
																					IL_0838:
																					ptr2 += 8;
																					goto end_IL_0351;
																					IL_05ff:
																					if (5 <= b)
																					{
																						goto IL_060a;
																					}
																					goto IL_067a;
																					IL_060a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_064a;
																					IL_064a:
																					array[num6 - 2] = 0;
																					num = 162;
																					goto IL_0667;
																					IL_0667:
																					num6--;
																					goto end_IL_0351;
																					IL_067a:
																					if (2 >= b)
																					{
																						goto IL_0688;
																					}
																					goto IL_0770;
																					IL_0688:
																					if (2 <= b)
																					{
																						goto IL_0693;
																					}
																					goto IL_0703;
																					IL_0693:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_06d3;
																					IL_06d3:
																					array[num6 - 2] = 0;
																					num = 81;
																					goto IL_06f0;
																					IL_06f0:
																					num6--;
																					goto end_IL_0351;
																					IL_0703:
																					if (1 < b)
																					{
																						goto end_IL_0371;
																					}
																					goto IL_0711;
																					IL_0711:
																					if (1 > b)
																					{
																						goto end_IL_0371;
																					}
																					goto IL_071f;
																					IL_071f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0738;
																					IL_0738:
																					array[num6] = 0;
																					goto IL_0746;
																					IL_0746:
																					num6++;
																					num = 147;
																					goto IL_075d;
																					IL_075d:
																					ptr2 += 8;
																					goto end_IL_0351;
																					IL_0770:
																					if (3 >= b)
																					{
																						goto IL_077b;
																					}
																					goto IL_07d3;
																					IL_077b:
																					if (3 > b)
																					{
																						goto end_IL_0371;
																					}
																					goto IL_0789;
																					IL_0789:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_07b2;
																					IL_07b2:
																					ptr2 += 8;
																					goto IL_07c0;
																					IL_07c0:
																					num6--;
																					goto end_IL_0351;
																					IL_07d3:
																					if (4 < b)
																					{
																						goto end_IL_0371;
																					}
																					goto IL_07e1;
																					IL_07e1:
																					if (4 > b)
																					{
																						goto end_IL_0371;
																					}
																					goto IL_07ef;
																					IL_07ef:
																					array[num6] = 0;
																					goto IL_07fd;
																					IL_07fd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0820;
																					IL_0820:
																					array2[num6] = null;
																					goto IL_082a;
																					IL_082a:
																					num6++;
																					goto IL_0838;
																					continue;
																					end_IL_0341:
																					break;
																				}
																				continue;
																				end_IL_0351:
																				break;
																			}
																			break;
																		}
																		goto IL_084b;
																		IL_0b89:
																		if (15 > b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0b94;
																		IL_084b:
																		if (16 < b)
																		{
																			goto IL_0859;
																		}
																		goto IL_0a1e;
																		IL_0859:
																		if (19 >= b)
																		{
																			goto IL_0867;
																		}
																		goto IL_09c8;
																		IL_0867:
																		if (19 <= b)
																		{
																			goto IL_0872;
																		}
																		goto IL_08d8;
																		IL_0872:
																		array[num6 - 1] = 0;
																		goto IL_0886;
																		IL_0886:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)intptr_0[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_08c5;
																		IL_08c5:
																		ptr2 += 8;
																		break;
																		IL_08d8:
																		if (17 < b)
																		{
																			goto IL_08e6;
																		}
																		goto IL_0969;
																		IL_08e6:
																		if (18 < b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_08f4;
																		IL_08f4:
																		if (18 > b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0902;
																		IL_0902:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0942;
																		IL_0942:
																		array[num6 - 2] = 3;
																		goto IL_0956;
																		IL_0956:
																		num6--;
																		break;
																		IL_0969:
																		if (17 > b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0977;
																		IL_0977:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0990;
																		IL_0990:
																		array[num6] = 3;
																		goto IL_099e;
																		IL_099e:
																		num6++;
																		num = 59;
																		goto IL_09b5;
																		IL_09b5:
																		ptr2 += 16;
																		break;
																		IL_09c8:
																		if (20 >= b)
																		{
																			goto IL_09d3;
																		}
																		goto IL_09fd;
																		IL_09d3:
																		if (20 > b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_09e1;
																		IL_09e1:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		break;
																		IL_09fd:
																		if (21 < b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0a0b;
																		IL_0a0b:
																		if (21 > b)
																		{
																		}
																		goto end_IL_0371;
																		IL_0a1e:
																		if (16 <= b)
																		{
																			goto IL_0a29;
																		}
																		goto IL_0a56;
																		IL_0a29:
																		bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																		goto IL_0a43;
																		IL_0a43:
																		num6--;
																		break;
																		IL_0a56:
																		if (13 >= b)
																		{
																			goto IL_0a64;
																		}
																		goto IL_0af4;
																		IL_0a64:
																		if (13 <= b)
																		{
																			goto IL_0a6f;
																		}
																		goto IL_0a87;
																		IL_0a6f:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		IL_0a87:
																		if (12 < b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0a95;
																		IL_0a95:
																		if (12 > b)
																		{
																			goto end_IL_0371;
																		}
																		num = 74;
																		goto IL_0aac;
																		IL_0b94:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0be6;
																		IL_0aac:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0ac5;
																		IL_0ac5:
																		array[num6] = 1;
																		goto IL_0ad3;
																		IL_0ad3:
																		num6++;
																		goto IL_0ae1;
																		IL_0ae1:
																		ptr2 += 16;
																		break;
																		IL_0af4:
																		if (14 >= b)
																		{
																			goto IL_0aff;
																		}
																		goto IL_0b75;
																		IL_0aff:
																		if (14 > b)
																		{
																			goto end_IL_0371;
																		}
																		goto IL_0b0d;
																		IL_0b0d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																		goto IL_0b4e;
																		IL_0b4e:
																		array[num6 - 2] = 0;
																		goto IL_0b62;
																		IL_0b62:
																		num6--;
																		break;
																		IL_0b75:
																		if (15 < b)
																		{
																			goto end_IL_0371;
																		}
																		num = 60;
																		goto IL_0b89;
																		IL_0be6:
																		num6--;
																		break;
																	}
																	goto end_IL_0384;
																	continue;
																	end_IL_0371:
																	break;
																	IL_0371:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															continue;
															end_IL_0384:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_0c09:
												break;
											}
											continue;
											end_IL_0c1c:
											break;
										}
										continue;
										end_IL_0c26:
										break;
									}
									continue;
									end_IL_0c31:
									break;
								}
								continue;
								end_IL_0c41:
								break;
							}
							continue;
							end_IL_0c51:
							break;
						}
						continue;
						end_IL_0c61:
						break;
					}
					continue;
					end_IL_0c71:
					break;
				}
				continue;
				end_IL_0c81:
				break;
			}
		}
	}

	public Class143()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										num = 78;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AbsTKINDENUM.NullReferenceExceptionOnAVServerChannelSinkStack);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0218:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_01f8:
																				if (5 >= b)
																				{
																					num = 114;
																					while (true)
																					{
																						if (num != 114)
																						{
																							if (num != 1095)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 62:
																								goto IL_01f8;
																							case 59:
																								goto IL_0208;
																							case 84:
																								goto IL_0218;
																							case 9:
																								goto end_IL_0218;
																							case 38:
																							case 50:
																								goto end_IL_0228;
																							case 51:
																								goto IL_0243;
																							case 3:
																							case 46:
																								goto IL_024e;
																							case 25:
																								goto IL_025e;
																							case 56:
																							case 70:
																								goto IL_026c;
																							case 72:
																								goto IL_028a;
																							case 8:
																							case 66:
																								goto IL_0298;
																							case 47:
																								goto IL_02d8;
																							case 75:
																								goto IL_02ec;
																							case 34:
																							case 80:
																								goto IL_02ff;
																							case 90:
																								goto IL_030d;
																							case 61:
																							case 65:
																								goto IL_031b;
																							case 93:
																							case 95:
																								goto IL_0337;
																							case 36:
																								goto IL_034e;
																							case 67:
																							case 89:
																								goto IL_035c;
																							case 85:
																								goto IL_039c;
																							case 12:
																								goto IL_03b0;
																							case 98:
																								goto IL_03c3;
																							case 91:
																								goto IL_03d1;
																							case 77:
																								goto IL_03df;
																							case 5:
																							case 52:
																								goto IL_03fd;
																							case 69:
																								goto IL_040b;
																							case 106:
																								goto IL_042e;
																							case 35:
																								goto IL_0438;
																							case 68:
																								goto IL_0446;
																							case 102:
																								goto IL_0459;
																							case 27:
																								goto IL_0467;
																							case 41:
																								goto IL_0472;
																							case 11:
																							case 16:
																								goto IL_0480;
																							case 29:
																								goto IL_04a9;
																							case 31:
																								goto IL_04b7;
																							case 37:
																							case 86:
																								goto IL_04ca;
																							case 74:
																								goto IL_04d8;
																							case 79:
																							case 83:
																								goto IL_04e6;
																							case 92:
																								goto IL_0526;
																							case 14:
																								goto IL_053a;
																							case 96:
																								goto IL_054d;
																							case 1:
																							case 60:
																								goto IL_0558;
																							case 53:
																								goto IL_0598;
																							case 107:
																								goto IL_05ac;
																							case 48:
																								goto IL_05bf;
																							case 88:
																								goto IL_05ca;
																							case 6:
																							case 10:
																							case 13:
																							case 15:
																							case 17:
																							case 18:
																							case 19:
																							case 22:
																							case 23:
																							case 28:
																							case 32:
																							case 33:
																							case 43:
																							case 45:
																							case 58:
																							case 71:
																							case 76:
																							case 87:
																							case 99:
																							case 104:
																							case 105:
																								goto end_IL_01e5;
																							case 97:
																								goto IL_0603;
																							case 24:
																								goto IL_061a;
																							case 82:
																								goto IL_0628;
																							case 0:
																							case 2:
																							case 7:
																							case 39:
																							case 42:
																							case 49:
																							case 63:
																							case 73:
																							case 81:
																							case 94:
																							case 103:
																								goto end_IL_0238;
																							case 101:
																								goto end_IL_063f;
																							case 78:
																								goto end_IL_0652;
																							case 64:
																								goto end_IL_065c;
																							case 40:
																								goto end_IL_0667;
																							case 30:
																								goto end_IL_0685;
																							case 4:
																							case 44:
																								goto end_IL_069a;
																							case 26:
																								goto end_IL_06aa;
																							case 55:
																							case 100:
																								goto end_IL_06ba;
																							case 20:
																								goto end_IL_06ca;
																							case 21:
																								goto end_IL_06da;
																							case 54:
																							case 57:
																								goto IL_06f5;
																							}
																							continue;
																						}
																						if (5 <= b)
																						{
																							goto IL_03fd;
																						}
																						goto IL_0459;
																						IL_05ac:
																						num5--;
																						goto end_IL_0238;
																						IL_05ca:
																						if (1 <= b)
																						{
																						}
																						break;
																						IL_05bf:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_05ca;
																						IL_03fd:
																						array[num5] = 0;
																						goto IL_040b;
																						IL_040b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_042e;
																						IL_042e:
																						array2[num5] = null;
																						goto IL_0438;
																						IL_0438:
																						num5++;
																						goto IL_0446;
																						IL_0446:
																						ptr2 += 8;
																						goto end_IL_0238;
																						IL_0459:
																						if (2 < b)
																						{
																							goto IL_0467;
																						}
																						goto IL_054d;
																						IL_0467:
																						if (3 >= b)
																						{
																							goto IL_0472;
																						}
																						goto IL_04ca;
																						IL_0472:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0480;
																						IL_0480:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04a9;
																						IL_04a9:
																						ptr2 += 8;
																						goto IL_04b7;
																						IL_04b7:
																						num5--;
																						goto end_IL_0238;
																						IL_04ca:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_04d8;
																						IL_04d8:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_04e6;
																						IL_04e6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0526;
																						IL_0526:
																						array[num5 - 2] = 0;
																						goto IL_053a;
																						IL_053a:
																						num5--;
																						goto end_IL_0238;
																						IL_054d:
																						if (2 <= b)
																						{
																							goto IL_0558;
																						}
																						goto IL_05bf;
																						IL_0558:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0598;
																						IL_0598:
																						array[num5 - 2] = 0;
																						goto IL_05ac;
																						continue;
																						end_IL_01e5:
																						break;
																					}
																					break;
																				}
																				goto IL_0243;
																				IL_035c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_039c;
																				IL_039c:
																				array[num5 - 2] = 0;
																				goto IL_03b0;
																				IL_0243:
																				if (7 < b)
																				{
																					goto IL_024e;
																				}
																				goto IL_025e;
																				IL_024e:
																				if (8 >= b)
																				{
																					goto IL_028a;
																				}
																				goto IL_02ff;
																				IL_02ff:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_030d;
																				IL_030d:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_031b;
																				IL_031b:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0238;
																				IL_028a:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0298;
																				IL_0298:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02d8;
																				IL_02d8:
																				array[num5 - 2] = 0;
																				goto IL_02ec;
																				IL_02ec:
																				num5--;
																				goto end_IL_0238;
																				IL_025e:
																				if (7 <= b)
																				{
																					goto IL_026c;
																				}
																				goto IL_0337;
																				IL_026c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_03c3;
																				IL_03c3:
																				array[num5] = 0;
																				goto IL_03d1;
																				IL_03d1:
																				num5++;
																				goto IL_03df;
																				IL_03df:
																				ptr2 += 8;
																				goto end_IL_0238;
																				IL_0337:
																				if (6 < b)
																				{
																					break;
																				}
																				num = 36;
																				goto IL_034e;
																				IL_03b0:
																				num5--;
																				goto end_IL_0238;
																				IL_034e:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_035c;
																			}
																			break;
																			IL_0208:;
																		}
																	}
																	else
																	{
																		num = 22;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0603;
																	IL_061a:
																	num5++;
																	goto IL_0628;
																	IL_0628:
																	ptr2 += 8;
																	num = 2;
																	goto end_IL_0238;
																	IL_0603:
																	array[num5] = 0;
																	num = 24;
																	goto IL_061a;
																	continue;
																	end_IL_0218:
																	break;
																}
																continue;
																end_IL_0228:
																break;
															}
															continue;
															end_IL_0238:
															break;
														}
														continue;
													}
													goto IL_06f5;
													IL_06f5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_063f:
													break;
												}
												continue;
												end_IL_0652:
												break;
											}
											continue;
											end_IL_065c:
											break;
										}
										continue;
										end_IL_0667:
										break;
									}
									continue;
									end_IL_0685:
									break;
								}
								continue;
								end_IL_069a:
								break;
							}
							continue;
							end_IL_06aa:
							break;
						}
						continue;
						end_IL_06ba:
						break;
					}
					continue;
					end_IL_06ca:
					break;
				}
				continue;
				end_IL_06da:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 10;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										IL_0605:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getEndOnCompleted.FinallyToString);
										while (true)
										{
											IL_05fb:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_05e8:
												if (num4 != 1)
												{
													while (true)
													{
														IL_026b:
														byte b = *ptr2;
														while (true)
														{
															IL_025b:
															ptr2++;
															while (true)
															{
																IL_024b:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		num = 48;
																		while (true)
																		{
																			IL_022b:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0218:
																					if (5 > b)
																					{
																						num = 50;
																						while (true)
																						{
																							IL_0208:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01f8:
																									if (3 >= b)
																									{
																										num = 107;
																										while (true)
																										{
																											if (num != 107)
																											{
																												if (num != 1088)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 6:
																												case 62:
																													goto IL_01f8;
																												case 32:
																												case 50:
																													goto IL_0208;
																												case 44:
																													goto IL_0218;
																												case 48:
																													goto IL_022b;
																												case 78:
																													goto IL_0238;
																												case 100:
																													goto IL_024b;
																												case 21:
																													goto IL_025b;
																												case 18:
																												case 47:
																													goto IL_026b;
																												case 17:
																													goto IL_0276;
																												case 22:
																													goto IL_0284;
																												case 37:
																												case 69:
																													goto IL_02a0;
																												case 3:
																													goto IL_02ab;
																												case 60:
																													goto IL_02bb;
																												case 80:
																													goto IL_02c6;
																												case 82:
																													goto IL_02d9;
																												case 14:
																												case 90:
																													goto IL_02e7;
																												case 34:
																												case 91:
																													goto IL_0303;
																												case 43:
																													goto IL_0365;
																												case 96:
																													goto IL_0378;
																												case 98:
																													goto IL_038b;
																												case 36:
																													goto IL_0399;
																												case 1:
																												case 7:
																													goto IL_03a7;
																												case 11:
																													goto IL_03e7;
																												case 42:
																													goto IL_0404;
																												case 24:
																													goto IL_0420;
																												case 86:
																													goto IL_042e;
																												case 5:
																												case 12:
																													goto IL_043c;
																												case 40:
																													goto IL_045f;
																												case 35:
																													goto IL_046d;
																												case 55:
																													goto IL_047b;
																												case 73:
																												case 85:
																													goto IL_049c;
																												case 93:
																													goto IL_04b4;
																												case 58:
																													goto IL_04bf;
																												case 83:
																													goto IL_04cd;
																												case 28:
																												case 75:
																													goto IL_04db;
																												case 29:
																													goto IL_04f4;
																												case 39:
																													goto IL_0502;
																												case 74:
																													goto IL_0510;
																												case 66:
																												case 72:
																													goto IL_0523;
																												case 63:
																													goto IL_054c;
																												case 67:
																													goto IL_055a;
																												case 4:
																												case 64:
																													goto IL_056a;
																												case 26:
																													goto IL_0578;
																												case 87:
																													goto IL_05a4;
																												case 38:
																													goto IL_05ae;
																												case 46:
																													goto IL_05c5;
																												case 0:
																												case 13:
																												case 16:
																												case 25:
																												case 41:
																												case 49:
																												case 51:
																												case 53:
																												case 57:
																												case 61:
																												case 65:
																												case 71:
																												case 79:
																												case 81:
																												case 89:
																												case 92:
																												case 99:
																													goto end_IL_0238;
																												case 8:
																												case 15:
																												case 19:
																												case 20:
																												case 27:
																												case 31:
																												case 45:
																												case 52:
																												case 54:
																												case 59:
																												case 94:
																												case 95:
																												case 97:
																													goto IL_05e8;
																												case 77:
																													goto IL_05fb;
																												case 84:
																													goto IL_0605;
																												case 33:
																													goto end_IL_01e5;
																												case 23:
																													goto end_IL_0610;
																												case 56:
																												case 88:
																													goto end_IL_0625;
																												case 30:
																													goto end_IL_0635;
																												case 2:
																												case 76:
																													goto end_IL_0645;
																												case 9:
																													goto end_IL_0655;
																												case 10:
																													goto end_IL_0665;
																												case 68:
																												case 70:
																													goto IL_0680;
																												}
																												continue;
																											}
																											if (3 > b)
																											{
																												goto end_IL_0238;
																											}
																											goto IL_049c;
																											IL_049c:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_05e8;
																											continue;
																											end_IL_01e5:
																											break;
																										}
																										break;
																									}
																									goto IL_0276;
																									IL_0276:
																									if (4 < b)
																									{
																										goto end_IL_0238;
																									}
																									goto IL_0284;
																									IL_0284:
																									if (4 > b)
																									{
																										goto end_IL_0238;
																									}
																									num = 27;
																									goto IL_05e8;
																								}
																								break;
																							}
																							goto IL_04b4;
																							IL_055a:
																							num5--;
																							goto IL_05e8;
																							IL_04b4:
																							if (2 > b)
																							{
																								goto IL_04bf;
																							}
																							goto IL_0523;
																							IL_04bf:
																							if (1 < b)
																							{
																								goto end_IL_0238;
																							}
																							goto IL_04cd;
																							IL_04cd:
																							if (1 > b)
																							{
																								goto end_IL_0238;
																							}
																							goto IL_04db;
																							IL_04db:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_04f4;
																							IL_04f4:
																							array[num5] = 0;
																							goto IL_0502;
																							IL_0502:
																							num5++;
																							goto IL_0510;
																							IL_0510:
																							ptr2 += 8;
																							goto IL_05e8;
																							IL_0523:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_054c;
																							IL_054c:
																							ptr2 += 8;
																							goto IL_055a;
																						}
																						break;
																					}
																					goto IL_056a;
																					IL_05ae:
																					num5++;
																					num = 46;
																					goto IL_05c5;
																					IL_05c5:
																					ptr2 += 8;
																					goto IL_05e8;
																					IL_056a:
																					array[num5] = 0;
																					goto IL_0578;
																					IL_0578:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 87;
																					goto IL_05a4;
																					IL_05a4:
																					array2[num5] = null;
																					goto IL_05ae;
																				}
																				break;
																			}
																			goto IL_02a0;
																			IL_02e7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_05e8;
																			IL_02a0:
																			if (8 >= b)
																			{
																				goto IL_02ab;
																			}
																			goto IL_02bb;
																			IL_02ab:
																			if (8 <= b)
																			{
																				goto IL_0303;
																			}
																			goto IL_038b;
																			IL_0303:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0365;
																			IL_0365:
																			num5 -= 2;
																			goto IL_05e8;
																			IL_038b:
																			if (6 >= b)
																			{
																				goto IL_0399;
																			}
																			goto IL_0420;
																			IL_0399:
																			if (6 > b)
																			{
																				goto end_IL_0238;
																			}
																			goto IL_03a7;
																			IL_03a7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03e7;
																			IL_03e7:
																			array[num5 - 2] = 0;
																			num = 42;
																			goto IL_0404;
																			IL_0404:
																			num5--;
																			num = 95;
																			goto IL_05e8;
																			IL_0420:
																			if (7 < b)
																			{
																				goto end_IL_0238;
																			}
																			goto IL_042e;
																			IL_042e:
																			if (7 > b)
																			{
																				goto end_IL_0238;
																			}
																			goto IL_043c;
																			IL_043c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_045f;
																			IL_045f:
																			array[num5] = 0;
																			goto IL_046d;
																			IL_046d:
																			num5++;
																			goto IL_047b;
																			IL_047b:
																			ptr2 += 8;
																			goto IL_05e8;
																			IL_02bb:
																			if (9 < b)
																			{
																				goto IL_02c6;
																			}
																			goto IL_02d9;
																			IL_02c6:
																			if (10 < b)
																			{
																				goto end_IL_0238;
																			}
																			goto IL_0378;
																			IL_0378:
																			if (10 > b)
																			{
																			}
																			goto end_IL_0238;
																			IL_02d9:
																			if (9 > b)
																			{
																				goto end_IL_0238;
																			}
																			goto IL_02e7;
																		}
																		goto end_IL_024b;
																		continue;
																		end_IL_0238:
																		break;
																		IL_0238:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_05e8;
																continue;
																end_IL_024b:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_0680;
												IL_0680:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0610:
									break;
								}
								continue;
								end_IL_0625:
								break;
							}
							continue;
							end_IL_0635:
							break;
						}
						continue;
						end_IL_0645:
						break;
					}
					continue;
					end_IL_0655:
					break;
				}
				continue;
				end_IL_0665:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 45;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 89;
					while (true)
					{
						object[] array2 = new object[3];
						num = 25;
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 14;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ControlEvidenceReflectionOnlyType.getCopyrightUnsafeDeserializeMethodResponse);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0285:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0265:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0255:
																						if (5 > b)
																						{
																							num = 9;
																							while (true)
																							{
																								IL_0245:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0235:
																										if (2 <= b)
																										{
																											num = 47;
																											while (true)
																											{
																												IL_01ea:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 107;
																												while (true)
																												{
																													if (num != 107)
																													{
																														if (num != 1088)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 47:
																														case 77:
																															goto IL_01ea;
																														case 18:
																															goto IL_0235;
																														case 9:
																														case 67:
																															goto IL_0245;
																														case 99:
																															goto IL_0255;
																														case 35:
																															goto IL_0265;
																														case 11:
																															goto end_IL_0265;
																														case 39:
																															goto IL_0285;
																														case 41:
																															goto end_IL_0285;
																														case 60:
																														case 82:
																															goto end_IL_0295;
																														case 13:
																															goto IL_02b0;
																														case 3:
																														case 58:
																															goto IL_02c3;
																														case 26:
																															goto IL_02d1;
																														case 37:
																															goto IL_02f4;
																														case 51:
																															goto IL_02fe;
																														case 5:
																															goto IL_030c;
																														case 31:
																														case 87:
																															goto end_IL_01d7;
																														case 40:
																															goto IL_032a;
																														case 43:
																															goto IL_0335;
																														case 6:
																															goto IL_0343;
																														case 46:
																														case 71:
																															goto IL_0356;
																														case 79:
																															goto IL_036f;
																														case 21:
																															goto IL_0386;
																														case 50:
																															goto IL_0394;
																														case 54:
																															goto IL_03a7;
																														case 59:
																															goto IL_03b2;
																														case 85:
																															goto IL_03c0;
																														case 57:
																															goto IL_03d3;
																														case 16:
																														case 70:
																															goto IL_03e1;
																														case 2:
																															goto IL_0421;
																														case 81:
																															goto IL_0435;
																														case 55:
																														case 88:
																															goto IL_0448;
																														case 27:
																															goto IL_0488;
																														case 86:
																															goto IL_049c;
																														case 90:
																															goto IL_04af;
																														case 7:
																														case 96:
																															goto IL_04c2;
																														case 53:
																															goto IL_04fb;
																														case 92:
																															goto IL_050e;
																														case 32:
																															goto IL_0519;
																														case 4:
																														case 84:
																															goto IL_0527;
																														case 66:
																															goto IL_0550;
																														case 75:
																															goto IL_055e;
																														case 30:
																															goto IL_0571;
																														case 76:
																															goto IL_057c;
																														case 38:
																														case 91:
																															goto IL_0587;
																														case 98:
																															goto IL_05c7;
																														case 28:
																															goto IL_05db;
																														case 12:
																														case 20:
																														case 22:
																														case 23:
																														case 29:
																														case 33:
																														case 48:
																														case 56:
																														case 61:
																														case 62:
																														case 68:
																														case 73:
																														case 74:
																														case 93:
																														case 94:
																														case 100:
																															goto end_IL_0275;
																														case 1:
																															goto IL_060e;
																														case 0:
																															goto IL_061c;
																														case 65:
																															goto IL_062a;
																														case 15:
																														case 17:
																														case 24:
																														case 36:
																														case 42:
																														case 63:
																														case 72:
																														case 78:
																														case 80:
																														case 83:
																														case 95:
																															goto end_IL_02a5;
																														case 8:
																															goto end_IL_0638;
																														case 19:
																															goto end_IL_064b;
																														case 14:
																															goto end_IL_0655;
																														case 69:
																															goto end_IL_0660;
																														case 52:
																															goto end_IL_0675;
																														case 25:
																														case 34:
																															goto end_IL_0693;
																														case 89:
																															goto end_IL_06a3;
																														case 49:
																														case 97:
																															goto end_IL_06b3;
																														case 44:
																															goto end_IL_06cc;
																														case 45:
																															goto end_IL_06e5;
																														case 10:
																														case 64:
																															goto IL_0700;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													num = 53;
																													goto IL_04fb;
																													IL_04fb:
																													num5--;
																													goto end_IL_02a5;
																													continue;
																													end_IL_01d7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02b0;
																										IL_02b0:
																										if (1 < b)
																										{
																											goto end_IL_0275;
																										}
																										goto IL_04af;
																										IL_04af:
																										if (1 > b)
																										{
																										}
																										goto end_IL_0275;
																									}
																									break;
																								}
																								goto IL_050e;
																								IL_05db:
																								num5--;
																								goto end_IL_02a5;
																								IL_050e:
																								if (3 >= b)
																								{
																									goto IL_0519;
																								}
																								goto IL_0571;
																								IL_0519:
																								if (3 > b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_0527;
																								IL_0527:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0550;
																								IL_0550:
																								ptr2 += 8;
																								goto IL_055e;
																								IL_055e:
																								num5--;
																								goto end_IL_02a5;
																								IL_0571:
																								if (4 < b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_057c;
																								IL_057c:
																								if (4 > b)
																								{
																									goto end_IL_0275;
																								}
																								goto IL_0587;
																								IL_0587:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05c7;
																								IL_05c7:
																								array[num5 - 2] = 0;
																								goto IL_05db;
																							}
																							break;
																						}
																						goto IL_02c3;
																						IL_02fe:
																						num5++;
																						goto IL_030c;
																						IL_030c:
																						ptr2 += 8;
																						goto end_IL_02a5;
																						IL_02c3:
																						array[num5] = 0;
																						goto IL_02d1;
																						IL_02d1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02f4;
																						IL_02f4:
																						array2[num5] = null;
																						goto IL_02fe;
																					}
																				}
																				if (7 >= b)
																				{
																					goto IL_032a;
																				}
																				goto IL_03a7;
																				IL_0435:
																				num5--;
																				goto end_IL_02a5;
																				IL_0421:
																				array[num5 - 2] = 0;
																				goto IL_0435;
																				IL_032a:
																				if (7 > b)
																				{
																					goto IL_0335;
																				}
																				goto IL_0356;
																				IL_0335:
																				if (6 < b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_0343;
																				IL_0343:
																				if (6 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_0448;
																				IL_0448:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0488;
																				IL_0488:
																				array[num5 - 2] = 0;
																				goto IL_049c;
																				IL_049c:
																				num5--;
																				goto end_IL_02a5;
																				IL_0356:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_036f;
																				IL_036f:
																				array[num5] = 0;
																				num = 21;
																				goto IL_0386;
																				IL_0386:
																				num5++;
																				goto IL_0394;
																				IL_0394:
																				ptr2 += 8;
																				goto end_IL_02a5;
																				IL_03a7:
																				if (8 < b)
																				{
																					goto IL_03b2;
																				}
																				goto IL_03d3;
																				IL_03b2:
																				if (9 < b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_03c0;
																				IL_03c0:
																				if (9 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_04c2;
																				IL_04c2:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02a5;
																				IL_03d3:
																				if (8 > b)
																				{
																					goto end_IL_0275;
																				}
																				goto IL_03e1;
																				IL_03e1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0421;
																				continue;
																				end_IL_0265:
																				break;
																			}
																			continue;
																			end_IL_0275:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060e;
																	IL_062a:
																	ptr2 += 8;
																	goto end_IL_02a5;
																	IL_061c:
																	num5++;
																	goto IL_062a;
																	IL_060e:
																	array[num5] = 0;
																	goto IL_061c;
																	continue;
																	end_IL_0285:
																	break;
																}
																continue;
																end_IL_0295:
																break;
															}
															continue;
															end_IL_02a5:
															break;
														}
														continue;
													}
													goto IL_0700;
													IL_0700:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0638:
													break;
												}
												continue;
												end_IL_064b:
												break;
											}
											continue;
											end_IL_0655:
											break;
										}
										continue;
										end_IL_0660:
										break;
									}
									continue;
									end_IL_0675:
									break;
								}
								continue;
								end_IL_0693:
								break;
							}
							continue;
							end_IL_06a3:
							break;
						}
						continue;
						end_IL_06b3:
						break;
					}
					continue;
					end_IL_06cc:
					break;
				}
				continue;
				end_IL_06e5:
				break;
			}
		}
	}

	private static int smethod_3(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 396;
		num4 = 36;
		int num5 = smethod_2(36, 2);
		num4 = num5;
		return num;
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									num = 25;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OidGroupSwitchValueState.SkipSecurityChecksTargetTypeAssembly);
											while (true)
											{
												IL_0645:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0377:
															byte b = *ptr2;
															while (true)
															{
																IL_0367:
																ptr2++;
																while (true)
																{
																	IL_0357:
																	if (b >= 1)
																	{
																		goto IL_0220;
																	}
																	goto IL_032f;
																	IL_032f:
																	while (true)
																	{
																		IL_032f_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_0207:
																			array[num5] = 0;
																			num = 53;
																			while (true)
																			{
																				IL_01f7:
																				num5++;
																				while (true)
																				{
																					IL_01de:
																					ptr2 += 8;
																					num = 111;
																					while (num != 111)
																					{
																						if (num != 1092)
																						{
																							goto end_IL_0632;
																						}
																						switch (num)
																						{
																						case 38:
																							goto IL_01de;
																						case 53:
																							goto IL_01f7;
																						case 62:
																							goto IL_0207;
																						case 55:
																							goto IL_0220;
																						case 49:
																							goto IL_022e;
																						case 13:
																							goto IL_0239;
																						case 37:
																							goto IL_0247;
																						case 3:
																							goto IL_0255;
																						case 51:
																							goto IL_0263;
																						case 57:
																							goto IL_0271;
																						case 74:
																							goto IL_0284;
																						case 42:
																							goto IL_028f;
																						case 27:
																						case 56:
																							goto IL_029f;
																						case 54:
																							goto IL_02aa;
																						case 10:
																							goto IL_02ba;
																						case 31:
																							goto IL_02c5;
																						case 75:
																							goto IL_02e0;
																						case 68:
																							goto IL_02eb;
																						case 104:
																							goto IL_02fb;
																						case 79:
																						case 95:
																							goto IL_0306;
																						case 66:
																							goto IL_0311;
																						case 100:
																							goto IL_0321;
																						case 0:
																						case 4:
																						case 6:
																						case 14:
																						case 30:
																						case 33:
																						case 36:
																						case 46:
																						case 48:
																						case 52:
																						case 69:
																						case 71:
																						case 72:
																						case 76:
																						case 77:
																						case 78:
																						case 80:
																						case 97:
																						case 99:
																						case 101:
																							goto IL_032f_2;
																						case 5:
																							goto IL_0357;
																						case 59:
																							goto IL_0367;
																						case 60:
																						case 103:
																							goto IL_0377;
																						case 19:
																						case 65:
																							goto IL_0382;
																						case 9:
																							goto IL_03c2;
																						case 23:
																						case 39:
																							goto IL_03db;
																						case 44:
																							goto IL_03f4;
																						case 35:
																						case 67:
																							goto IL_0404;
																						case 32:
																							goto IL_0444;
																						case 29:
																							goto IL_0458;
																						case 83:
																							goto IL_046b;
																						case 84:
																							goto IL_047e;
																						case 21:
																						case 86:
																							goto IL_048e;
																						case 88:
																							goto IL_04aa;
																						case 41:
																						case 94:
																							goto IL_04c6;
																						case 92:
																							goto IL_0506;
																						case 61:
																							goto IL_051a;
																						case 70:
																						case 102:
																							goto IL_052d;
																						case 43:
																							goto IL_053b;
																						case 1:
																							goto IL_055e;
																						case 20:
																							goto IL_0568;
																						case 50:
																							goto IL_0576;
																						case 28:
																						case 85:
																							goto IL_0589;
																						case 22:
																							goto IL_05c9;
																						case 64:
																							goto IL_05dd;
																						case 17:
																						case 98:
																							goto IL_05ed;
																						case 91:
																							goto IL_0616;
																						case 18:
																							goto IL_0624;
																						case 12:
																						case 16:
																						case 40:
																						case 45:
																						case 63:
																						case 73:
																						case 81:
																						case 82:
																						case 87:
																						case 96:
																							goto end_IL_01cb;
																						case 2:
																							goto IL_0645;
																						case 89:
																							goto end_IL_0632;
																						case 25:
																							goto end_IL_064f;
																						case 34:
																							goto end_IL_065a;
																						case 90:
																							goto end_IL_066f;
																						case 24:
																						case 93:
																							goto end_IL_068d;
																						case 15:
																							goto end_IL_069d;
																						case 26:
																						case 47:
																							goto end_IL_06ad;
																						case 7:
																							goto end_IL_06bd;
																						case 8:
																							goto end_IL_06cd;
																						case 11:
																						case 58:
																							goto IL_06e8;
																						}
																						continue;
																						end_IL_01cb:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																	IL_0220:
																	if (b <= 9)
																	{
																		goto IL_022e;
																	}
																	goto IL_032f;
																	IL_022e:
																	if (5 >= b)
																	{
																		goto IL_0239;
																	}
																	goto IL_0284;
																	IL_0239:
																	if (5 > b)
																	{
																		goto IL_0247;
																	}
																	goto IL_052d;
																	IL_0247:
																	if (2 >= b)
																	{
																		goto IL_0255;
																	}
																	goto IL_02fb;
																	IL_0255:
																	if (2 > b)
																	{
																		goto IL_0263;
																	}
																	goto IL_0382;
																	IL_0263:
																	if (1 >= b)
																	{
																		goto IL_0271;
																	}
																	goto IL_032f;
																	IL_0271:
																	if (1 <= b)
																	{
																	}
																	goto IL_032f;
																	IL_0382:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_03c2;
																	IL_03c2:
																	array[num5 - 2] = 0;
																	goto IL_046b;
																	IL_046b:
																	num5--;
																	break;
																	IL_02fb:
																	if (3 < b)
																	{
																		goto IL_0306;
																	}
																	goto IL_0321;
																	IL_0306:
																	if (4 >= b)
																	{
																		goto IL_0311;
																	}
																	goto IL_032f;
																	IL_0311:
																	if (4 > b)
																	{
																		goto IL_032f;
																	}
																	goto IL_0589;
																	IL_0589:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05c9;
																	IL_05c9:
																	array[num5 - 2] = 0;
																	goto IL_05dd;
																	IL_05dd:
																	num5--;
																	break;
																	IL_0321:
																	if (3 > b)
																	{
																		goto IL_032f;
																	}
																	goto IL_05ed;
																	IL_05ed:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0616;
																	IL_0616:
																	ptr2 += 8;
																	goto IL_0624;
																	IL_0624:
																	num5--;
																	break;
																	IL_052d:
																	array[num5] = 0;
																	goto IL_053b;
																	IL_053b:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_055e;
																	IL_055e:
																	array2[num5] = null;
																	goto IL_0568;
																	IL_0568:
																	num5++;
																	goto IL_0576;
																	IL_0576:
																	ptr2 += 8;
																	break;
																	IL_0284:
																	if (7 >= b)
																	{
																		goto IL_028f;
																	}
																	goto IL_029f;
																	IL_028f:
																	if (7 > b)
																	{
																		goto IL_02e0;
																	}
																	goto IL_03db;
																	IL_02e0:
																	if (6 >= b)
																	{
																		goto IL_02eb;
																	}
																	goto IL_032f;
																	IL_02eb:
																	if (6 > b)
																	{
																		goto IL_032f;
																	}
																	goto IL_04c6;
																	IL_04c6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0506;
																	IL_0506:
																	array[num5 - 2] = 0;
																	goto IL_051a;
																	IL_051a:
																	num5--;
																	break;
																	IL_03db:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_03f4;
																	IL_03f4:
																	array[num5] = 0;
																	goto IL_047e;
																	IL_047e:
																	num5++;
																	goto IL_04aa;
																	IL_04aa:
																	ptr2 += 8;
																	num = 96;
																	break;
																	IL_029f:
																	if (8 >= b)
																	{
																		goto IL_02aa;
																	}
																	goto IL_02ba;
																	IL_02aa:
																	if (8 > b)
																	{
																		goto IL_032f;
																	}
																	goto IL_0404;
																	IL_0404:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0444;
																	IL_0444:
																	array[num5 - 2] = 0;
																	goto IL_0458;
																	IL_0458:
																	num5--;
																	break;
																	IL_02ba:
																	if (9 >= b)
																	{
																		goto IL_02c5;
																	}
																	num = 99;
																	goto IL_032f;
																	IL_02c5:
																	if (9 > b)
																	{
																		goto IL_032f;
																	}
																	goto IL_048e;
																	IL_048e:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06e8;
													IL_06e8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0632:
													break;
												}
												break;
											}
											continue;
											end_IL_064f:
											break;
										}
										continue;
										end_IL_065a:
										break;
									}
									continue;
									end_IL_066f:
									break;
								}
								continue;
								end_IL_068d:
								break;
							}
							continue;
							end_IL_069d:
							break;
						}
						continue;
						end_IL_06ad:
						break;
					}
					continue;
					end_IL_06bd:
					break;
				}
				continue;
				end_IL_06cd:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 16;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeLimitingDeserializationBinderSecurityBindingRedirects.TTTExpirationTime);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0250:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0230:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0223:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0213:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0203:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												num = 112;
																												while (true)
																												{
																													if (num != 112)
																													{
																														if (num != 1093)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 63:
																															goto IL_01f0;
																														case 99:
																															goto IL_0203;
																														case 94:
																															goto IL_0213;
																														case 49:
																															goto IL_0223;
																														case 81:
																															goto IL_0230;
																														case 66:
																															goto IL_0240;
																														case 76:
																															goto IL_0250;
																														case 1:
																															goto end_IL_0250;
																														case 54:
																														case 88:
																															goto end_IL_0260;
																														case 8:
																														case 29:
																															goto IL_027b;
																														case 23:
																															goto IL_0289;
																														case 22:
																															goto IL_02ac;
																														case 42:
																														case 48:
																															goto IL_02c1;
																														case 55:
																														case 57:
																															goto IL_0303;
																														case 37:
																															goto IL_030e;
																														case 65:
																															goto IL_0321;
																														case 74:
																															goto IL_032f;
																														case 97:
																															goto IL_0342;
																														case 50:
																															goto IL_0356;
																														case 69:
																														case 102:
																															goto IL_0369;
																														case 32:
																															goto IL_0377;
																														case 5:
																														case 26:
																															goto IL_0385;
																														case 38:
																															goto IL_03c5;
																														case 100:
																															goto IL_03d9;
																														case 35:
																														case 105:
																															goto end_IL_01dd;
																														case 60:
																															goto IL_0415;
																														case 36:
																															goto IL_0423;
																														case 103:
																															goto IL_0452;
																														case 17:
																															goto IL_0460;
																														case 6:
																														case 43:
																															goto IL_046b;
																														case 77:
																															goto IL_0479;
																														case 59:
																														case 98:
																															goto IL_0487;
																														case 30:
																															goto IL_04a3;
																														case 72:
																														case 84:
																															goto IL_04b1;
																														case 78:
																															goto IL_04f1;
																														case 19:
																															goto IL_0505;
																														case 25:
																															goto IL_0518;
																														case 95:
																															goto IL_0526;
																														case 67:
																															goto IL_0531;
																														case 4:
																														case 80:
																															goto IL_053c;
																														case 86:
																															goto IL_057c;
																														case 71:
																															goto IL_0590;
																														case 2:
																														case 3:
																														case 18:
																														case 20:
																														case 24:
																														case 31:
																														case 39:
																														case 44:
																														case 45:
																														case 46:
																														case 47:
																														case 53:
																														case 61:
																														case 62:
																														case 75:
																														case 82:
																														case 83:
																														case 85:
																														case 96:
																														case 101:
																															goto end_IL_01f0;
																														case 7:
																															goto IL_05c6;
																														case 13:
																															goto IL_05d4;
																														case 52:
																															goto IL_05e2;
																														case 40:
																														case 104:
																															goto IL_05f2;
																														case 14:
																															goto IL_0614;
																														case 64:
																															goto IL_0622;
																														case 10:
																															goto IL_0630;
																														case 0:
																														case 12:
																														case 27:
																														case 28:
																														case 34:
																														case 51:
																														case 56:
																														case 70:
																														case 89:
																														case 91:
																														case 92:
																															goto end_IL_0270;
																														case 33:
																															goto end_IL_063e;
																														case 87:
																															goto end_IL_0651;
																														case 73:
																															goto end_IL_065b;
																														case 9:
																															goto end_IL_0666;
																														case 93:
																															goto end_IL_067b;
																														case 21:
																														case 41:
																															goto end_IL_0690;
																														case 58:
																															goto end_IL_06a0;
																														case 11:
																														case 90:
																															goto end_IL_06b0;
																														case 15:
																															goto end_IL_06c0;
																														case 16:
																															goto end_IL_06d0;
																														case 68:
																														case 79:
																															goto IL_06eb;
																														}
																														continue;
																													}
																													if (1 > b)
																													{
																														num = 44;
																													}
																													goto end_IL_01f0;
																													continue;
																													end_IL_01dd:
																													break;
																												}
																												goto IL_03ec;
																												continue;
																												end_IL_01f0:
																												break;
																												IL_01f0:;
																											}
																											break;
																										}
																										goto IL_02c1;
																										IL_0356:
																										num5--;
																										goto end_IL_0270;
																										IL_02c1:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0342;
																										IL_0342:
																										array[num5 - 2] = 0;
																										goto IL_0356;
																									}
																									break;
																								}
																								goto IL_0303;
																								IL_03d9:
																								num5--;
																								goto end_IL_0270;
																								IL_0303:
																								if (3 >= b)
																								{
																									goto IL_030e;
																								}
																								goto IL_0369;
																								IL_030e:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_03ec;
																								IL_03ec:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0415;
																								IL_0415:
																								ptr2 += 8;
																								goto IL_0423;
																								IL_0423:
																								num5--;
																								goto end_IL_0270;
																								IL_0369:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0377;
																								IL_0377:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0385;
																								IL_0385:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03c5;
																								IL_03c5:
																								array[num5 - 2] = 0;
																								goto IL_03d9;
																							}
																							break;
																						}
																						goto IL_027b;
																						IL_032f:
																						ptr2 += 8;
																						goto end_IL_0270;
																						IL_027b:
																						array[num5] = 0;
																						goto IL_0289;
																						IL_0289:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02ac;
																						IL_02ac:
																						array2[num5] = null;
																						num = 65;
																						goto IL_0321;
																						IL_0321:
																						num5++;
																						goto IL_032f;
																					}
																					break;
																				}
																				goto IL_0452;
																				IL_0630:
																				ptr2 += 8;
																				goto end_IL_0270;
																				IL_0452:
																				if (7 < b)
																				{
																					goto IL_0460;
																				}
																				goto IL_0518;
																				IL_0460:
																				if (8 < b)
																				{
																					goto IL_046b;
																				}
																				goto IL_04a3;
																				IL_046b:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0479;
																				IL_0479:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0487;
																				IL_0487:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0270;
																				IL_04a3:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04b1;
																				IL_04b1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f1;
																				IL_04f1:
																				array[num5 - 2] = 0;
																				goto IL_0505;
																				IL_0505:
																				num5--;
																				goto end_IL_0270;
																				IL_0518:
																				if (7 > b)
																				{
																					goto IL_0526;
																				}
																				goto IL_05f2;
																				IL_0526:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0531;
																				IL_0531:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_053c;
																				IL_053c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_057c;
																				IL_057c:
																				array[num5 - 2] = 0;
																				goto IL_0590;
																				IL_0590:
																				num5--;
																				goto end_IL_0270;
																				IL_05f2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 14;
																				goto IL_0614;
																				IL_0614:
																				array[num5] = 0;
																				goto IL_0622;
																				IL_0622:
																				num5++;
																				goto IL_0630;
																			}
																			break;
																			IL_0240:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05c6;
																	IL_05e2:
																	ptr2 += 8;
																	goto end_IL_0270;
																	IL_05d4:
																	num5++;
																	goto IL_05e2;
																	IL_05c6:
																	array[num5] = 0;
																	goto IL_05d4;
																	continue;
																	end_IL_0250:
																	break;
																}
																continue;
																end_IL_0260:
																break;
															}
															continue;
															end_IL_0270:
															break;
														}
														continue;
													}
													goto IL_06eb;
													IL_06eb:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_063e:
													break;
												}
												continue;
												end_IL_0651:
												break;
											}
											continue;
											end_IL_065b:
											break;
										}
										continue;
										end_IL_0666:
										break;
									}
									continue;
									end_IL_067b:
									break;
								}
								continue;
								end_IL_0690:
								break;
							}
							continue;
							end_IL_06a0:
							break;
						}
						continue;
						end_IL_06b0:
						break;
					}
					continue;
					end_IL_06c0:
					break;
				}
				continue;
				end_IL_06d0:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 11;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 75;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setMonitoringIsEnabledUnSafeCharBuffer.QuerySourceGetServerContextSink);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0274:
															byte b = *ptr2;
															while (true)
															{
																IL_0264:
																ptr2++;
																while (true)
																{
																	IL_0254:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0234:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0224:
																						if (7 < b)
																						{
																							while (true)
																							{
																								IL_0217:
																								if (8 < b)
																								{
																									while (9 >= b)
																									{
																										while (true)
																										{
																											IL_01f4:
																											if (9 > b)
																											{
																												num = 113;
																												while (num != 113)
																												{
																													if (num != 1094)
																													{
																														goto end_IL_0254;
																													}
																													switch (num)
																													{
																													case 90:
																														goto IL_01f4;
																													case 34:
																														goto IL_0207;
																													case 54:
																													case 79:
																														goto IL_0217;
																													case 37:
																													case 57:
																														goto IL_0224;
																													case 100:
																														goto IL_0234;
																													case 22:
																														goto IL_0244;
																													case 41:
																														goto IL_0254;
																													case 25:
																														goto IL_0264;
																													case 64:
																													case 66:
																														goto IL_0274;
																													case 23:
																														goto IL_027f;
																													case 16:
																													case 40:
																														goto IL_028d;
																													case 13:
																													case 58:
																														goto IL_02cf;
																													case 102:
																														goto IL_02eb;
																													case 1:
																														goto IL_02ff;
																													case 7:
																														goto IL_0312;
																													case 19:
																													case 44:
																														goto IL_031d;
																													case 89:
																														goto IL_0336;
																													case 4:
																														goto IL_0344;
																													case 20:
																														goto IL_035b;
																													case 51:
																														goto IL_036e;
																													case 103:
																														goto IL_037c;
																													case 87:
																													case 88:
																														goto IL_038a;
																													case 43:
																														goto IL_03ca;
																													case 14:
																														goto IL_03de;
																													case 71:
																														goto IL_03f1;
																													case 85:
																													case 96:
																														goto IL_03ff;
																													case 28:
																													case 45:
																														goto IL_040d;
																													case 49:
																														goto IL_0418;
																													case 27:
																													case 47:
																														goto IL_0426;
																													case 46:
																														goto IL_044f;
																													case 72:
																														goto IL_045d;
																													case 35:
																														goto IL_0470;
																													case 84:
																														goto IL_047e;
																													case 59:
																													case 74:
																														goto IL_048c;
																													case 21:
																														goto IL_04cc;
																													case 0:
																														goto IL_04e0;
																													case 53:
																														goto IL_04f3;
																													case 9:
																													case 81:
																														goto IL_04fe;
																													case 80:
																														goto IL_053e;
																													case 65:
																														goto IL_0552;
																													case 94:
																													case 98:
																														goto IL_0565;
																													case 17:
																														goto IL_0570;
																													case 42:
																													case 67:
																														goto IL_057d;
																													case 33:
																														goto IL_058b;
																													case 70:
																														goto IL_05ae;
																													case 106:
																														goto IL_05b8;
																													case 29:
																														goto IL_05c6;
																													case 3:
																													case 5:
																													case 15:
																													case 18:
																													case 24:
																													case 30:
																													case 31:
																													case 32:
																													case 38:
																													case 39:
																													case 50:
																													case 56:
																													case 60:
																													case 61:
																													case 68:
																													case 69:
																													case 91:
																													case 101:
																														goto end_IL_01e1;
																													case 26:
																														goto IL_05f9;
																													case 97:
																														goto IL_0607;
																													case 78:
																														goto IL_0615;
																													case 2:
																													case 8:
																													case 12:
																													case 55:
																													case 77:
																													case 82:
																													case 83:
																													case 92:
																													case 93:
																													case 104:
																													case 105:
																														goto end_IL_0254;
																													case 73:
																														goto end_IL_062c;
																													case 95:
																														goto end_IL_063f;
																													case 99:
																														goto end_IL_0649;
																													case 48:
																														goto end_IL_0654;
																													case 63:
																														goto end_IL_0669;
																													case 36:
																													case 76:
																														goto end_IL_067e;
																													case 62:
																														goto end_IL_068e;
																													case 75:
																													case 86:
																														goto end_IL_069e;
																													case 10:
																														goto end_IL_06ae;
																													case 11:
																														goto end_IL_06be;
																													case 6:
																													case 52:
																														goto IL_06e2;
																													}
																													continue;
																													end_IL_01e1:
																													break;
																												}
																												break;
																											}
																											goto IL_02cf;
																											IL_02cf:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											goto end_IL_0254;
																										}
																										break;
																										IL_0207:;
																									}
																									break;
																								}
																								goto IL_027f;
																								IL_02ff:
																								num6--;
																								goto end_IL_0254;
																								IL_027f:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_028d;
																								IL_028d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_02eb;
																								IL_02eb:
																								array[num6 - 2] = 0;
																								goto IL_02ff;
																							}
																							break;
																						}
																						goto IL_0312;
																						IL_03de:
																						num6--;
																						goto end_IL_0254;
																						IL_0312:
																						if (7 <= b)
																						{
																							goto IL_031d;
																						}
																						goto IL_036e;
																						IL_031d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0336;
																						IL_0336:
																						array[num6] = 0;
																						goto IL_0344;
																						IL_0344:
																						num6++;
																						num = 20;
																						goto IL_035b;
																						IL_035b:
																						ptr2 += 8;
																						goto end_IL_0254;
																						IL_036e:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_037c;
																						IL_037c:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_038a;
																						IL_038a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_03ca;
																						IL_03ca:
																						array[num6 - 2] = 0;
																						goto IL_03de;
																					}
																					break;
																				}
																				goto IL_03f1;
																				IL_05c6:
																				ptr2 += 8;
																				goto end_IL_0254;
																				IL_03f1:
																				if (5 > b)
																				{
																					goto IL_03ff;
																				}
																				goto IL_057d;
																				IL_03ff:
																				if (2 < b)
																				{
																					goto IL_040d;
																				}
																				goto IL_04f3;
																				IL_040d:
																				if (3 >= b)
																				{
																					goto IL_0418;
																				}
																				goto IL_0470;
																				IL_0418:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0426;
																				IL_0426:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_044f;
																				IL_044f:
																				ptr2 += 8;
																				goto IL_045d;
																				IL_045d:
																				num6--;
																				goto end_IL_0254;
																				IL_0470:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_047e;
																				IL_047e:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_048c;
																				IL_048c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_04cc;
																				IL_04cc:
																				array[num6 - 2] = 0;
																				goto IL_04e0;
																				IL_04e0:
																				num6--;
																				goto end_IL_0254;
																				IL_04f3:
																				if (2 <= b)
																				{
																					goto IL_04fe;
																				}
																				goto IL_0565;
																				IL_04fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_053e;
																				IL_053e:
																				array[num6 - 2] = 0;
																				goto IL_0552;
																				IL_0552:
																				num6--;
																				goto end_IL_0254;
																				IL_0565:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0570;
																				IL_0570:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_057d:
																				array[num6] = 0;
																				goto IL_058b;
																				IL_058b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05ae;
																				IL_05ae:
																				array2[num6] = null;
																				goto IL_05b8;
																				IL_05b8:
																				num6++;
																				goto IL_05c6;
																			}
																			break;
																			IL_0244:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_05f9;
																	IL_0615:
																	ptr2 += 8;
																	num = 105;
																	break;
																	IL_0607:
																	num6++;
																	goto IL_0615;
																	IL_05f9:
																	array[num6] = 0;
																	goto IL_0607;
																	continue;
																	end_IL_0254:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06e2;
													IL_06e2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_062c:
													break;
												}
												continue;
												end_IL_063f:
												break;
											}
											continue;
											end_IL_0649:
											break;
										}
										continue;
										end_IL_0654:
										break;
									}
									continue;
									end_IL_0669:
									break;
								}
								continue;
								end_IL_067e:
								break;
							}
							continue;
							end_IL_068e:
							break;
						}
						continue;
						end_IL_069e:
						break;
					}
					continue;
					end_IL_06ae:
					break;
				}
				continue;
				end_IL_06be:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_1;
									num = 70;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NodeKeyValueEnumeratorgetXCertificate.IsTypeVisibleFromComSuppressChangeType);
										num = 82;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02ce:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02ae:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02a1:
																					if (7 <= b)
																					{
																						while (true)
																						{
																							IL_027c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							while (true)
																							{
																								IL_0263:
																								array[num5] = 0;
																								num = 124;
																								while (true)
																								{
																									IL_024a:
																									num5++;
																									num = 138;
																									while (true)
																									{
																										if (num != 138)
																										{
																											if (num != 1119)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 124:
																												goto IL_024a;
																											case 121:
																												goto IL_0263;
																											case 38:
																											case 125:
																												goto IL_027c;
																											case 65:
																												goto IL_02a1;
																											case 6:
																												goto IL_02ae;
																											case 16:
																												goto IL_02be;
																											case 77:
																												goto IL_02ce;
																											case 30:
																												goto end_IL_02ce;
																											case 34:
																											case 131:
																												goto end_IL_02de;
																											case 9:
																											case 66:
																												goto IL_02f9;
																											case 36:
																											case 50:
																												goto IL_0304;
																											case 100:
																												goto IL_0312;
																											case 90:
																												goto IL_031d;
																											case 84:
																											case 119:
																												goto IL_0330;
																											case 29:
																												goto IL_033e;
																											case 122:
																												goto IL_0366;
																											case 15:
																											case 35:
																												goto IL_0374;
																											case 40:
																											case 117:
																												goto IL_037f;
																											case 94:
																												goto IL_038d;
																											case 64:
																											case 113:
																												goto IL_039b;
																											case 109:
																												goto IL_03c4;
																											case 22:
																												goto IL_03d2;
																											case 99:
																												goto IL_03e5;
																											case 51:
																											case 55:
																												goto IL_03f3;
																											case 69:
																												goto IL_040c;
																											case 95:
																												goto IL_041a;
																											case 42:
																												goto IL_0428;
																											case 25:
																											case 27:
																												goto IL_043b;
																											case 126:
																												goto IL_0453;
																											case 59:
																												goto IL_045d;
																											case 13:
																												goto IL_046b;
																											case 128:
																												goto IL_047e;
																											case 37:
																											case 129:
																												goto IL_0491;
																											case 83:
																												goto IL_049f;
																											case 112:
																											case 116:
																												goto IL_04ad;
																											case 81:
																												goto IL_04ed;
																											case 0:
																												goto IL_0501;
																											case 91:
																												goto IL_0527;
																											case 1:
																											case 97:
																												goto IL_0535;
																											case 10:
																												goto IL_0540;
																											case 111:
																											case 127:
																												goto IL_054b;
																											case 48:
																												goto IL_0559;
																											case 28:
																											case 92:
																												goto IL_0567;
																											case 58:
																											case 80:
																												goto IL_0583;
																											case 89:
																											case 105:
																												goto IL_059f;
																											case 11:
																												goto IL_05ad;
																											case 44:
																												goto IL_05c0;
																											case 73:
																												goto IL_05ce;
																											case 43:
																												goto IL_05dc;
																											case 24:
																												goto IL_05ea;
																											case 88:
																											case 96:
																												goto IL_05f8;
																											case 120:
																												goto IL_0638;
																											case 87:
																												goto IL_064c;
																											case 118:
																												goto IL_065f;
																											case 8:
																											case 32:
																												goto IL_066d;
																											case 26:
																												goto IL_06cf;
																											case 57:
																											case 102:
																												goto IL_06e2;
																											case 33:
																												goto IL_06f6;
																											case 46:
																												goto IL_074a;
																											case 75:
																												goto IL_0758;
																											case 12:
																											case 17:
																											case 19:
																											case 23:
																											case 39:
																											case 41:
																											case 45:
																											case 47:
																											case 49:
																											case 56:
																											case 60:
																											case 62:
																											case 63:
																											case 68:
																											case 71:
																											case 72:
																											case 74:
																											case 78:
																											case 79:
																											case 98:
																											case 103:
																											case 104:
																											case 115:
																												goto end_IL_0237;
																											case 5:
																											case 18:
																											case 20:
																											case 31:
																											case 52:
																											case 53:
																											case 54:
																											case 61:
																											case 76:
																											case 85:
																											case 86:
																											case 93:
																											case 108:
																											case 110:
																											case 114:
																											case 123:
																												goto end_IL_02ee;
																											case 82:
																												goto end_IL_077b;
																											case 70:
																												goto end_IL_078e;
																											case 4:
																												goto end_IL_0798;
																											case 67:
																												goto end_IL_07ac;
																											case 7:
																											case 130:
																												goto end_IL_07ca;
																											case 107:
																												goto end_IL_07da;
																											case 21:
																											case 101:
																												goto end_IL_07ea;
																											case 2:
																												goto end_IL_07fa;
																											case 3:
																												goto end_IL_080a;
																											case 14:
																											case 106:
																												goto IL_0825;
																											}
																											continue;
																										}
																										ptr2 += 8;
																										goto end_IL_02ee;
																										continue;
																										end_IL_0237:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_02f9;
																					IL_043b:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02ee;
																					IL_02f9:
																					if (3 < b)
																					{
																						goto IL_0304;
																					}
																					goto IL_0366;
																					IL_0304:
																					if (5 >= b)
																					{
																						goto IL_0312;
																					}
																					goto IL_0491;
																					IL_0312:
																					if (5 > b)
																					{
																						goto IL_031d;
																					}
																					goto IL_0330;
																					IL_031d:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_047e;
																					IL_047e:
																					if (4 <= b)
																					{
																						goto end_IL_02ee;
																					}
																					break;
																					IL_0330:
																					array[num5] = 0;
																					goto IL_033e;
																					IL_033e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0453;
																					IL_0453:
																					array2[num5] = null;
																					goto IL_045d;
																					IL_045d:
																					num5++;
																					goto IL_046b;
																					IL_046b:
																					ptr2 += 8;
																					goto end_IL_02ee;
																					IL_0491:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_049f;
																					IL_049f:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_04ad;
																					IL_04ad:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04ed;
																					IL_04ed:
																					array[num5 - 2] = 0;
																					goto IL_0501;
																					IL_0501:
																					num5--;
																					goto end_IL_02ee;
																					IL_0366:
																					if (3 > b)
																					{
																						goto IL_0374;
																					}
																					goto IL_043b;
																					IL_0374:
																					if (1 < b)
																					{
																						goto IL_037f;
																					}
																					goto IL_03e5;
																					IL_037f:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_038d;
																					IL_038d:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_039b;
																					IL_039b:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c4;
																					IL_03c4:
																					ptr2 += 8;
																					goto IL_03d2;
																					IL_03d2:
																					num5--;
																					goto end_IL_02ee;
																					IL_03e5:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_03f3;
																					IL_03f3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_040c;
																					IL_040c:
																					array[num5] = 0;
																					goto IL_041a;
																					IL_041a:
																					num5++;
																					goto IL_0428;
																					IL_0428:
																					ptr2 += 8;
																					goto end_IL_02ee;
																				}
																				break;
																			}
																			goto IL_0527;
																			IL_0758:
																			ptr2 += 8;
																			goto end_IL_02ee;
																			IL_0527:
																			if (10 < b)
																			{
																				goto IL_0535;
																			}
																			goto IL_05c0;
																			IL_0535:
																			if (12 >= b)
																			{
																				goto IL_0540;
																			}
																			goto IL_059f;
																			IL_0540:
																			if (12 > b)
																			{
																				goto IL_054b;
																			}
																			goto IL_0583;
																			IL_054b:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0559;
																			IL_0559:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0567;
																			IL_0567:
																			num5--;
																			num = 18;
																			goto end_IL_02ee;
																			IL_0583:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02ee;
																			IL_059f:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_05ad;
																			IL_05ad:
																			if (13 > b)
																			{
																			}
																			break;
																			IL_05c0:
																			if (10 > b)
																			{
																				goto IL_05ce;
																			}
																			goto IL_06e2;
																			IL_05ce:
																			if (8 < b)
																			{
																				goto IL_05dc;
																			}
																			goto IL_065f;
																			IL_05dc:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_05ea;
																			IL_05ea:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_05f8;
																			IL_05f8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0638;
																			IL_0638:
																			array[num5 - 2] = 0;
																			goto IL_064c;
																			IL_064c:
																			num5--;
																			goto end_IL_02ee;
																			IL_065f:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_066d;
																			IL_066d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06cf;
																			IL_06cf:
																			num5 -= 2;
																			goto end_IL_02ee;
																			IL_06e2:
																			array[num5 - 2] = 0;
																			goto IL_06f6;
																			IL_06f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)setPercentNegativePatternEndScope[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_074a;
																			IL_074a:
																			num5--;
																			goto IL_0758;
																		}
																		break;
																		IL_02be:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ee;
																continue;
																end_IL_02ce:
																break;
															}
															continue;
															end_IL_02de:
															break;
														}
														continue;
														end_IL_02ee:
														break;
													}
													continue;
												}
												goto IL_0825;
												IL_0825:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_077b:
												break;
											}
											continue;
											end_IL_078e:
											break;
										}
										continue;
										end_IL_0798:
										break;
									}
									continue;
									end_IL_07ac:
									break;
								}
								continue;
								end_IL_07ca:
								break;
							}
							continue;
							end_IL_07da:
							break;
						}
						continue;
						end_IL_07ea:
						break;
					}
					continue;
					end_IL_07fa:
					break;
				}
				continue;
				end_IL_080a:
				break;
			}
		}
	}

	static Class143()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 14;
			while (true)
			{
				if (num != 14)
				{
					if (num == 995)
					{
						switch (num)
						{
						default:
							continue;
						case 4:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 3:
							return;
						case 5:
							return;
						case 6:
							return;
						case 7:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
