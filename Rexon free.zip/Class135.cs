using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Platform Color: Purple", "Settings", "Cycle platform colors", false, 2, ModType.const_1, false)]
internal class Class135 : MonoBehaviour
{
	internal readonly struct ColorOption
	{
		public readonly string string_0;

		public readonly Color color_0;

		private static IntPtr[] getSafeFileHandlePassesActivityFilter;

		internal static object object_0;

		public unsafe ColorOption(string name, Color value)
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
			int num = 0;
			int num2 = 0;
			num2 = 0;
			int num3 = default(int);
			while (num2 != 1)
			{
				((delegate*<ref int, ref int, ref int, ref ColorOption, string, Color, void>)getSafeFileHandlePassesActivityFilter[num])(ref num, ref num2, ref num3, ref this, name, value);
			}
			num2 = 0;
		}

		static ColorOption()
		{
			int num = 2;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					num = 9;
					while (true)
					{
						if (num == 9 || num != 990)
						{
							return;
						}
						switch (num)
						{
						case 1:
							goto end_IL_002d;
						case 2:
							goto end_IL_003a;
						case 0:
							return;
						}
						continue;
						end_IL_002d:
						break;
					}
					continue;
					end_IL_003a:
					break;
				}
			}
		}

		internal static bool smethod_0()
		{
			return object_0 == null;
		}

		internal static object smethod_1()
		{
			return object_0;
		}
	}

	private static int int_0;

	private static Color color_0;

	private static bool bool_0;

	private static ColorOption[] colorOption_0;

	private static int int_1;

	private static bool bool_1;

	private static double double_0;

	private static float float_0;

	private static IntPtr[] UriMarshalersetKeyAlgorithm;

	private static IntPtr[] GetArgNameCOMServerEntry;

	private static IntPtr[] EndWriteCLAIMSECURITYATTRIBUTEFQBNVALUE;

	private static IntPtr[] InitOnlyCancelFullGCNotification;

	private static IntPtr[] getindexGetTypeFlags;

	private static IntPtr[] ThreeLetterISOLanguageNameGetNativeDataSize;

	private static IntPtr[] GetSecondCallConvStdcall;

	private static IntPtr[] CookiesgetEndOfStream;

	private static IntPtr[] addDomainUnloadCatchType;

	private static IntPtr[] Fqbnroot;

	private static IntPtr[] RightArrowgetContainsGenericParameters;

	public unsafe static Color CurrentColor
	{
		get
		{
			return color_0;
		}
		set
		{
			int num = 142;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											while (true)
											{
												array5[0] = value;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FormatterAddFullTrustAssembly.UnregisterAssemblygetNumberNegativePattern);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																IL_038e:
																byte b = *ptr2;
																while (true)
																{
																	IL_037e:
																	ptr2++;
																	while (true)
																	{
																		IL_036e:
																		if (b >= 1)
																		{
																			while (b <= 17)
																			{
																				num = 140;
																				while (true)
																				{
																					IL_034b:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_033e:
																							if (13 < b)
																							{
																								while (true)
																								{
																									IL_0331:
																									if (15 >= b)
																									{
																										while (true)
																										{
																											IL_0321:
																											if (15 > b)
																											{
																												while (14 >= b)
																												{
																													num = 180;
																													while (true)
																													{
																														if (num != 180)
																														{
																															if (num != 1161)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 128:
																															case 155:
																																goto IL_030e;
																															case 99:
																																goto IL_0321;
																															case 98:
																															case 160:
																																goto IL_0331;
																															case 81:
																																goto IL_033e;
																															case 140:
																																goto IL_034b;
																															case 145:
																																goto IL_035b;
																															case 1:
																																goto IL_036e;
																															case 112:
																																goto IL_037e;
																															case 0:
																															case 170:
																																goto IL_038e;
																															case 65:
																															case 78:
																																goto IL_0399;
																															case 85:
																																goto IL_03b5;
																															case 94:
																															case 120:
																																goto IL_03c3;
																															case 80:
																																goto IL_03d1;
																															case 47:
																															case 96:
																																goto IL_03df;
																															case 108:
																																goto IL_03f3;
																															case 111:
																																goto IL_0447;
																															case 56:
																																goto IL_0460;
																															case 92:
																																goto IL_0470;
																															case 121:
																																goto IL_047e;
																															case 127:
																																goto IL_0491;
																															case 139:
																																goto IL_04a4;
																															case 33:
																															case 84:
																																goto IL_04b2;
																															case 125:
																															case 147:
																																goto IL_0519;
																															case 113:
																																goto IL_053b;
																															case 137:
																																goto IL_0549;
																															case 138:
																																goto IL_0557;
																															case 130:
																															case 149:
																																goto IL_056a;
																															case 76:
																																goto IL_0578;
																															case 24:
																															case 27:
																																goto IL_0586;
																															case 150:
																																goto IL_05a2;
																															case 166:
																																goto IL_05b5;
																															case 22:
																															case 164:
																																goto IL_05c3;
																															case 79:
																																goto IL_05dc;
																															case 4:
																															case 73:
																																goto IL_05fa;
																															case 21:
																															case 32:
																																goto IL_0620;
																															case 12:
																																goto IL_0642;
																															case 25:
																																goto IL_0650;
																															case 57:
																																goto IL_065e;
																															case 53:
																																goto IL_067a;
																															case 69:
																															case 97:
																																goto IL_0688;
																															case 158:
																															case 163:
																																goto IL_0696;
																															case 168:
																																goto IL_06a4;
																															case 123:
																															case 156:
																																goto IL_06b2;
																															case 20:
																																goto IL_06c9;
																															case 29:
																															case 90:
																																goto IL_06d7;
																															case 2:
																																goto IL_0717;
																															case 144:
																																goto IL_072b;
																															case 72:
																															case 162:
																																goto IL_073e;
																															case 61:
																																goto IL_077e;
																															case 135:
																																goto IL_0792;
																															case 86:
																																goto IL_07a5;
																															case 143:
																																goto IL_07b3;
																															case 52:
																															case 167:
																																goto IL_07cc;
																															case 165:
																																goto IL_080c;
																															case 66:
																																goto IL_0820;
																															case 117:
																																goto IL_0833;
																															case 71:
																																goto IL_0841;
																															case 89:
																															case 132:
																																goto IL_084f;
																															case 104:
																																goto IL_0862;
																															case 58:
																																goto IL_0870;
																															case 122:
																																goto IL_087e;
																															case 51:
																															case 54:
																																goto IL_0889;
																															case 124:
																																goto IL_0897;
																															case 34:
																															case 102:
																																goto IL_08b3;
																															case 70:
																																goto IL_08f3;
																															case 18:
																																goto IL_0907;
																															case 95:
																																goto IL_091a;
																															case 45:
																																goto IL_0928;
																															case 8:
																															case 31:
																																goto IL_0936;
																															case 59:
																																goto IL_095f;
																															case 60:
																																goto IL_0976;
																															case 106:
																															case 169:
																																goto IL_0992;
																															case 55:
																																goto IL_09a0;
																															case 13:
																																goto IL_09c3;
																															case 39:
																																goto IL_09cd;
																															case 103:
																																goto IL_09db;
																															case 14:
																															case 105:
																																goto IL_09ee;
																															case 46:
																																goto IL_0a2e;
																															case 115:
																																goto IL_0a42;
																															case 3:
																															case 9:
																															case 17:
																															case 19:
																															case 23:
																															case 28:
																															case 30:
																															case 41:
																															case 48:
																															case 63:
																															case 64:
																															case 67:
																															case 68:
																															case 77:
																															case 82:
																															case 83:
																															case 93:
																															case 101:
																															case 109:
																															case 116:
																															case 118:
																															case 126:
																															case 131:
																															case 133:
																															case 146:
																															case 148:
																															case 152:
																															case 154:
																															case 157:
																															case 159:
																															case 161:
																															case 171:
																															case 173:
																																goto end_IL_030e;
																															case 87:
																																goto IL_0a6b;
																															case 114:
																																goto IL_0a79;
																															case 119:
																																goto IL_0a87;
																															case 7:
																															case 10:
																															case 11:
																															case 26:
																															case 36:
																															case 40:
																															case 42:
																															case 44:
																															case 49:
																															case 50:
																															case 62:
																															case 74:
																															case 91:
																															case 100:
																															case 107:
																															case 110:
																															case 129:
																															case 134:
																															case 136:
																															case 151:
																																goto end_IL_02fb;
																															case 35:
																																goto end_IL_0a95;
																															case 153:
																																goto end_IL_0aa8;
																															case 75:
																																goto end_IL_0ab2;
																															case 6:
																																goto end_IL_0abd;
																															case 43:
																																goto end_IL_0ad2;
																															case 5:
																															case 88:
																																goto end_IL_0ae2;
																															case 172:
																																goto end_IL_0af2;
																															case 38:
																																goto end_IL_0b02;
																															case 37:
																																goto end_IL_0b12;
																															case 141:
																																goto end_IL_0b22;
																															case 142:
																																goto end_IL_0b32;
																															case 15:
																															case 16:
																																return;
																															}
																															continue;
																														}
																														if (14 > b)
																														{
																															num = 154;
																															goto end_IL_030e;
																														}
																														goto IL_05fa;
																														IL_05fa:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														break;
																														continue;
																														end_IL_02fb:
																														break;
																													}
																													goto end_IL_036e;
																													continue;
																													end_IL_030e:
																													break;
																													IL_030e:;
																												}
																												break;
																											}
																											goto IL_0620;
																											IL_065e:
																											ptr2 += 8;
																											goto end_IL_036e;
																											IL_0620:
																											array2[num6] = (Color)array5[*(int*)(ptr2 + num3)];
																											goto IL_0642;
																											IL_0642:
																											array[num6] = 4;
																											goto IL_0650;
																											IL_0650:
																											num6++;
																											goto IL_065e;
																										}
																										break;
																									}
																									goto IL_0399;
																									IL_05c3:
																									color_0 = (Color)array2[num6 - 1];
																									goto IL_05dc;
																									IL_0399:
																									if (16 < b)
																									{
																										num = 149;
																										goto IL_056a;
																									}
																									goto IL_05b5;
																									IL_05dc:
																									num6--;
																									goto end_IL_036e;
																									IL_056a:
																									if (17 < b)
																									{
																										break;
																									}
																									goto IL_0578;
																									IL_0578:
																									if (17 > b)
																									{
																										break;
																									}
																									goto IL_0586;
																									IL_0586:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_036e;
																									IL_05b5:
																									if (16 > b)
																									{
																										break;
																									}
																									goto IL_05c3;
																								}
																								break;
																							}
																							goto IL_03b5;
																							IL_0557:
																							ptr2 += 16;
																							goto end_IL_036e;
																							IL_03b5:
																							if (13 > b)
																							{
																								goto IL_03c3;
																							}
																							goto IL_0519;
																							IL_03c3:
																							if (11 >= b)
																							{
																								goto IL_03d1;
																							}
																							goto IL_0470;
																							IL_03d1:
																							if (11 <= b)
																							{
																								goto IL_03df;
																							}
																							goto IL_0460;
																							IL_03df:
																							array[num6 - 2] = 0;
																							goto IL_03f3;
																							IL_03f3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)UriMarshalersetKeyAlgorithm[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0447;
																							IL_0447:
																							num6--;
																							num = 127;
																							goto IL_0491;
																							IL_0491:
																							ptr2 += 8;
																							goto end_IL_036e;
																							IL_0460:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_04a4;
																							IL_04a4:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_04b2;
																							IL_04b2:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_05a2;
																							IL_05a2:
																							num6 -= 2;
																							goto end_IL_036e;
																							IL_0470:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_047e;
																							IL_047e:
																							if (12 > b)
																							{
																								break;
																							}
																							goto end_IL_036e;
																							IL_0519:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																							num = 113;
																							goto IL_053b;
																							IL_053b:
																							array[num6] = 1;
																							goto IL_0549;
																							IL_0549:
																							num6++;
																							goto IL_0557;
																						}
																						break;
																					}
																					num = 53;
																					goto IL_067a;
																					IL_09c3:
																					array2[num6] = null;
																					goto IL_09cd;
																					IL_09cd:
																					num6++;
																					goto IL_09db;
																					IL_067a:
																					if (9 > b)
																					{
																						goto IL_0688;
																					}
																					goto IL_09ee;
																					IL_0688:
																					if (4 < b)
																					{
																						goto IL_0696;
																					}
																					goto IL_0862;
																					IL_0696:
																					if (6 >= b)
																					{
																						goto IL_06a4;
																					}
																					goto IL_07a5;
																					IL_06a4:
																					if (6 > b)
																					{
																						goto IL_06b2;
																					}
																					goto IL_073e;
																					IL_06b2:
																					if (5 < b)
																					{
																						break;
																					}
																					num = 20;
																					goto IL_06c9;
																					IL_09db:
																					ptr2 += 8;
																					goto end_IL_036e;
																					IL_06c9:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_06d7;
																					IL_06d7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0717;
																					IL_0717:
																					array[num6 - 2] = 0;
																					goto IL_072b;
																					IL_072b:
																					num6--;
																					goto end_IL_036e;
																					IL_073e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_077e;
																					IL_077e:
																					array[num6 - 2] = 0;
																					goto IL_0792;
																					IL_0792:
																					num6--;
																					goto end_IL_036e;
																					IL_07a5:
																					if (7 >= b)
																					{
																						goto IL_07b3;
																					}
																					goto IL_0833;
																					IL_07b3:
																					if (7 > b)
																					{
																						num = 30;
																						break;
																					}
																					goto IL_07cc;
																					IL_09ee:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0a2e;
																					IL_07cc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_080c;
																					IL_080c:
																					array[num6 - 2] = 0;
																					goto IL_0820;
																					IL_0820:
																					num6--;
																					goto end_IL_036e;
																					IL_0833:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0841;
																					IL_0841:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_084f;
																					IL_084f:
																					num6--;
																					goto end_IL_036e;
																					IL_0862:
																					if (4 > b)
																					{
																						goto IL_0870;
																					}
																					num = 106;
																					goto IL_0992;
																					IL_0870:
																					if (2 >= b)
																					{
																						goto IL_087e;
																					}
																					goto IL_091a;
																					IL_087e:
																					if (2 > b)
																					{
																						goto IL_0889;
																					}
																					goto IL_08b3;
																					IL_0889:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_0897;
																					IL_0897:
																					if (1 > b)
																					{
																						num = 77;
																					}
																					break;
																					IL_0a42:
																					num6--;
																					goto end_IL_036e;
																					IL_08b3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_08f3;
																					IL_08f3:
																					array[num6 - 2] = 0;
																					goto IL_0907;
																					IL_0907:
																					num6--;
																					goto end_IL_036e;
																					IL_091a:
																					if (3 < b)
																					{
																						break;
																					}
																					goto IL_0928;
																					IL_0928:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0936;
																					IL_0936:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_095f;
																					IL_095f:
																					ptr2 += 8;
																					num = 60;
																					goto IL_0976;
																					IL_0976:
																					num6--;
																					goto end_IL_036e;
																					IL_0a2e:
																					array[num6 - 2] = 0;
																					goto IL_0a42;
																					IL_0992:
																					array[num6] = 0;
																					goto IL_09a0;
																					IL_09a0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_09c3;
																				}
																				break;
																				IL_035b:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a6b;
																		IL_0a87:
																		ptr2 += 8;
																		break;
																		IL_0a79:
																		num6++;
																		goto IL_0a87;
																		IL_0a6b:
																		array[num6] = 0;
																		goto IL_0a79;
																		continue;
																		end_IL_036e:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_0a95:
															break;
														}
														continue;
														end_IL_0aa8:
														break;
													}
													continue;
													end_IL_0ab2:
													break;
												}
												continue;
												end_IL_0abd:
												break;
											}
											continue;
											end_IL_0ad2:
											break;
										}
										continue;
										end_IL_0ae2:
										break;
									}
									continue;
									end_IL_0af2:
									break;
								}
								continue;
								end_IL_0b02:
								break;
							}
							continue;
							end_IL_0b12:
							break;
						}
						continue;
						end_IL_0b22:
						break;
					}
					continue;
					end_IL_0b32:
					break;
				}
			}
		}
	}

	public unsafe static bool IsRainbow
	{
		get
		{
			int num = 42;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								num = 115;
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IIDENTITYAUTHORITYREFERENCEIDENTITYTOTEXTFLAGSMetadataEnumResult.NumberBufferToDecimalIsProperty);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 62;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0318:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_02f8:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02e8:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02d8:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02c8:
																										if (4 <= b)
																										{
																											num = 166;
																											while (true)
																											{
																												if (num != 166)
																												{
																													if (num != 1147)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 129:
																														goto IL_02c8;
																													case 75:
																														goto IL_02d8;
																													case 4:
																														goto IL_02e8;
																													case 11:
																														goto IL_02f8;
																													case 29:
																														goto IL_0308;
																													case 43:
																														goto IL_0318;
																													case 99:
																														goto end_IL_0318;
																													case 123:
																													case 125:
																														goto end_IL_0328;
																													case 69:
																														goto IL_0343;
																													case 89:
																														goto IL_0351;
																													case 37:
																													case 106:
																														goto IL_036a;
																													case 87:
																													case 109:
																														goto IL_037d;
																													case 24:
																														goto IL_03c6;
																													case 107:
																														goto IL_03da;
																													case 50:
																													case 114:
																														goto IL_03ed;
																													case 119:
																														goto IL_0400;
																													case 47:
																														goto IL_040e;
																													case 30:
																													case 103:
																														goto IL_041c;
																													case 34:
																														goto IL_045c;
																													case 56:
																														goto IL_0479;
																													case 128:
																														goto IL_048c;
																													case 141:
																														goto IL_049f;
																													case 19:
																													case 94:
																														goto IL_04aa;
																													case 91:
																														goto IL_04b8;
																													case 61:
																													case 131:
																														goto IL_04cb;
																													case 58:
																														goto IL_050b;
																													case 77:
																														goto IL_051f;
																													case 26:
																													case 146:
																														goto IL_0532;
																													case 117:
																													case 150:
																														goto IL_0545;
																													case 49:
																													case 152:
																														goto IL_055e;
																													case 157:
																														goto IL_05a0;
																													case 6:
																													case 68:
																														goto IL_05ae;
																													case 48:
																														goto IL_05d7;
																													case 95:
																														goto IL_05e5;
																													case 158:
																														goto IL_05f8;
																													case 98:
																														goto IL_060c;
																													case 137:
																														goto IL_061f;
																													case 3:
																														goto IL_062d;
																													case 0:
																														goto IL_0650;
																													case 84:
																														goto IL_065a;
																													case 21:
																														goto IL_0668;
																													case 12:
																														goto IL_067b;
																													case 93:
																														goto IL_0689;
																													case 80:
																														goto IL_0697;
																													case 36:
																													case 130:
																														goto IL_06a2;
																													case 45:
																														goto IL_06b0;
																													case 14:
																													case 122:
																														goto IL_06be;
																													case 138:
																														goto IL_06da;
																													case 53:
																													case 127:
																														goto IL_06e8;
																													case 149:
																														goto IL_070c;
																													case 20:
																														goto IL_071a;
																													case 65:
																														goto IL_0728;
																													case 144:
																														goto IL_073b;
																													case 23:
																														goto IL_0746;
																													case 116:
																														goto IL_0751;
																													case 57:
																													case 66:
																														goto IL_075f;
																													case 39:
																														goto IL_0778;
																													case 70:
																														goto IL_0786;
																													case 40:
																														goto IL_0794;
																													case 54:
																													case 76:
																														goto IL_07b5;
																													case 60:
																														goto IL_07cd;
																													case 83:
																													case 90:
																														goto IL_07e4;
																													case 133:
																														goto IL_07f2;
																													case 92:
																													case 108:
																														goto IL_0800;
																													case 33:
																														goto IL_080e;
																													case 38:
																													case 63:
																														goto IL_081c;
																													case 46:
																														goto IL_085c;
																													case 13:
																														goto IL_0870;
																													case 52:
																													case 105:
																														goto IL_0883;
																													case 74:
																														goto IL_08e5;
																													case 81:
																														goto IL_08f8;
																													case 71:
																														goto IL_0906;
																													case 18:
																													case 88:
																														goto IL_0914;
																													case 86:
																														goto IL_0928;
																													case 82:
																														goto IL_097c;
																													case 22:
																														goto IL_098a;
																													case 5:
																													case 7:
																													case 8:
																													case 9:
																													case 10:
																													case 15:
																													case 17:
																													case 44:
																													case 59:
																													case 64:
																													case 67:
																													case 73:
																													case 78:
																													case 85:
																													case 97:
																													case 100:
																													case 101:
																													case 102:
																													case 121:
																													case 124:
																													case 134:
																													case 135:
																													case 136:
																													case 139:
																													case 140:
																													case 143:
																													case 151:
																													case 155:
																													case 159:
																														goto end_IL_02b5;
																													case 55:
																														goto IL_09b3;
																													case 145:
																														goto IL_09c1;
																													case 79:
																														goto IL_09d8;
																													case 1:
																													case 2:
																													case 16:
																													case 25:
																													case 27:
																													case 51:
																													case 62:
																													case 96:
																													case 104:
																													case 110:
																													case 112:
																													case 113:
																													case 120:
																													case 126:
																													case 132:
																													case 147:
																													case 148:
																													case 153:
																													case 156:
																														goto end_IL_0338;
																													case 35:
																														goto end_IL_09e6;
																													case 28:
																														goto end_IL_09f9;
																													case 31:
																														goto end_IL_0a0c;
																													case 115:
																													case 154:
																														goto end_IL_0a17;
																													case 118:
																														goto end_IL_0a27;
																													case 142:
																														goto end_IL_0a37;
																													case 111:
																														goto end_IL_0a50;
																													case 41:
																														goto end_IL_0a60;
																													case 42:
																														goto end_IL_0a70;
																													case 32:
																													case 72:
																														goto IL_0a8b;
																													}
																													continue;
																												}
																												goto IL_061f;
																												IL_065a:
																												num6++;
																												goto IL_0668;
																												IL_0668:
																												ptr2 += 8;
																												goto end_IL_0338;
																												IL_061f:
																												array[num6] = 0;
																												goto IL_062d;
																												IL_062d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0650;
																												IL_0650:
																												array2[num6] = null;
																												goto IL_065a;
																												continue;
																												end_IL_02b5:
																												break;
																											}
																											break;
																										}
																										goto IL_0343;
																										IL_05a0:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_05ae;
																										IL_05ae:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_05d7;
																										IL_0343:
																										if (2 >= b)
																										{
																											goto IL_0351;
																										}
																										goto IL_0545;
																										IL_0351:
																										if (2 <= b)
																										{
																											goto IL_037d;
																										}
																										num = 114;
																										goto IL_03ed;
																										IL_05d7:
																										ptr2 += 8;
																										goto IL_05e5;
																										IL_03ed:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_048c;
																										IL_048c:
																										if (1 <= b)
																										{
																										}
																										break;
																										IL_037d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 24;
																										goto IL_03c6;
																										IL_03c6:
																										array[num6 - 2] = 0;
																										goto IL_03da;
																										IL_03da:
																										num6--;
																										goto end_IL_0338;
																										IL_0545:
																										if (3 < b)
																										{
																											num = 102;
																											break;
																										}
																										goto IL_05a0;
																										IL_05e5:
																										num6--;
																										goto end_IL_0338;
																									}
																									break;
																								}
																								goto IL_036a;
																								IL_0479:
																								num6--;
																								goto end_IL_0338;
																								IL_036a:
																								if (6 < b)
																								{
																									goto IL_0400;
																								}
																								goto IL_049f;
																								IL_049f:
																								if (6 > b)
																								{
																									goto IL_04aa;
																								}
																								goto IL_04cb;
																								IL_04aa:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_04b8;
																								IL_04b8:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_055e;
																								IL_055e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_05f8;
																								IL_05f8:
																								array[num6 - 2] = 0;
																								goto IL_060c;
																								IL_060c:
																								num6--;
																								goto end_IL_0338;
																								IL_04cb:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_050b;
																								IL_050b:
																								array[num6 - 2] = 0;
																								goto IL_051f;
																								IL_051f:
																								num6--;
																								goto end_IL_0338;
																								IL_0400:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_040e;
																								IL_040e:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_041c;
																								IL_041c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_045c;
																								IL_045c:
																								array[num6 - 2] = 0;
																								num = 56;
																								goto IL_0479;
																							}
																							break;
																						}
																						goto IL_0532;
																						IL_0532:
																						num6--;
																						goto end_IL_0338;
																					}
																					break;
																				}
																				goto IL_067b;
																				IL_0928:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)GetArgNameCOMServerEntry[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_097c;
																				IL_067b:
																				if (12 < b)
																				{
																					goto IL_0689;
																				}
																				goto IL_07cd;
																				IL_0689:
																				if (14 < b)
																				{
																					goto IL_0697;
																				}
																				goto IL_073b;
																				IL_0697:
																				if (15 < b)
																				{
																					goto IL_06a2;
																				}
																				goto IL_06da;
																				IL_06a2:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_06b0;
																				IL_06b0:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_06be;
																				IL_06be:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0338;
																				IL_06da:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_06e8;
																				IL_06e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)GetArgNameCOMServerEntry[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_070c;
																				IL_070c:
																				array[num6] = 0;
																				goto IL_071a;
																				IL_071a:
																				num6++;
																				goto IL_0728;
																				IL_0728:
																				ptr2 += 8;
																				goto end_IL_0338;
																				IL_073b:
																				if (14 > b)
																				{
																					goto IL_0746;
																				}
																				goto IL_07b5;
																				IL_0746:
																				if (13 < b)
																				{
																					num = 44;
																					break;
																				}
																				goto IL_0751;
																				IL_0751:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_075f;
																				IL_075f:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0778;
																				IL_0778:
																				array[num6] = 1;
																				goto IL_0786;
																				IL_0786:
																				num6++;
																				goto IL_0794;
																				IL_0794:
																				ptr2 += 16;
																				goto end_IL_0338;
																				IL_097c:
																				num6--;
																				goto IL_098a;
																				IL_07b5:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0338;
																				IL_07cd:
																				if (12 <= b)
																				{
																					goto end_IL_0338;
																				}
																				num = 83;
																				goto IL_07e4;
																				IL_098a:
																				ptr2 += 8;
																				goto end_IL_0338;
																				IL_07e4:
																				if (10 >= b)
																				{
																					goto IL_07f2;
																				}
																				goto IL_08f8;
																				IL_07f2:
																				if (10 > b)
																				{
																					goto IL_0800;
																				}
																				goto IL_0883;
																				IL_0800:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_080e;
																				IL_080e:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_081c;
																				IL_081c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_085c;
																				IL_085c:
																				array[num6 - 2] = 0;
																				goto IL_0870;
																				IL_0870:
																				num6--;
																				goto end_IL_0338;
																				IL_0883:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08e5;
																				IL_08e5:
																				num6 -= 2;
																				goto end_IL_0338;
																				IL_08f8:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0906;
																				IL_0906:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_0914;
																				IL_0914:
																				array[num6 - 2] = 0;
																				goto IL_0928;
																			}
																			break;
																			IL_0308:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_09b3;
																	IL_09d8:
																	ptr2 += 8;
																	goto end_IL_0338;
																	IL_09c1:
																	num6++;
																	num = 79;
																	goto IL_09d8;
																	IL_09b3:
																	array[num6] = 0;
																	goto IL_09c1;
																	continue;
																	end_IL_0318:
																	break;
																}
																continue;
																end_IL_0328:
																break;
															}
															continue;
															end_IL_0338:
															break;
														}
														continue;
													}
													goto IL_0a8b;
													IL_0a8b:
													return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
													continue;
													end_IL_09e6:
													break;
												}
												continue;
												end_IL_09f9:
												break;
											}
											continue;
											end_IL_0a0c:
											break;
										}
										continue;
										end_IL_0a17:
										break;
									}
									continue;
									end_IL_0a27:
									break;
								}
								continue;
								end_IL_0a37:
								break;
							}
							continue;
							end_IL_0a50:
							break;
						}
						continue;
						end_IL_0a60:
						break;
					}
					continue;
					end_IL_0a70:
					break;
				}
			}
		}
		private set
		{
			int num = 87;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					IL_0a2f:
					int num3 = num2 * 4;
					while (true)
					{
						IL_0a1f:
						int num4 = num2 * 8;
						while (true)
						{
							IL_0a0f:
							byte[] array = new byte[3];
							while (true)
							{
								IL_09ff:
								object[] array2 = new object[3];
								while (true)
								{
									IL_09e6:
									sbyte[] array3 = new sbyte[1];
									num = 71;
									while (true)
									{
										IL_09d6:
										int[] array4 = new int[6];
										while (true)
										{
											IL_09bd:
											long[] array5 = new long[3];
											num = 120;
											while (true)
											{
												IL_099f:
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												num = 133;
												while (true)
												{
													IL_0994:
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReservedMaskgetActivationContext.TargetTypeAssemblyAllLocalFiles);
													while (true)
													{
														IL_0981:
														byte* ptr2 = ptr;
														num = 142;
														while (true)
														{
															IL_0976:
															num = 26;
															while (true)
															{
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_03c8:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_03b8:
																			ptr2++;
																			while (true)
																			{
																				IL_03a8:
																				if (b >= 1)
																				{
																					while (b <= 16)
																					{
																						while (true)
																						{
																							IL_038b:
																							if (8 < b)
																							{
																								while (true)
																								{
																									IL_037b:
																									if (12 >= b)
																									{
																										while (true)
																										{
																											IL_036b:
																											if (12 > b)
																											{
																												while (true)
																												{
																													IL_035b:
																													if (10 >= b)
																													{
																														while (true)
																														{
																															IL_034b:
																															if (10 > b)
																															{
																																while (true)
																																{
																																	IL_033b:
																																	if (9 >= b)
																																	{
																																		while (9 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_02e9:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																				while (true)
																																				{
																																					IL_02d3:
																																					array[num6 - 2] = 0;
																																					while (true)
																																					{
																																						IL_02ba:
																																						num6--;
																																						num = 166;
																																						while (num != 166)
																																						{
																																							if (num != 1147)
																																							{
																																								goto end_IL_0963;
																																							}
																																							switch (num)
																																							{
																																							case 110:
																																								goto IL_02ba;
																																							case 31:
																																								goto IL_02d3;
																																							case 94:
																																							case 123:
																																								goto IL_02e9;
																																							case 76:
																																								goto IL_032b;
																																							case 20:
																																							case 139:
																																								goto IL_033b;
																																							case 78:
																																								goto IL_034b;
																																							case 111:
																																								goto IL_035b;
																																							case 17:
																																								goto IL_036b;
																																							case 65:
																																								goto IL_037b;
																																							case 68:
																																								goto IL_038b;
																																							case 53:
																																								goto IL_0398;
																																							case 24:
																																								goto IL_03a8;
																																							case 25:
																																								goto IL_03b8;
																																							case 69:
																																							case 93:
																																								goto IL_03c8;
																																							case 4:
																																								goto IL_03d3;
																																							case 33:
																																							case 42:
																																								goto IL_03de;
																																							case 43:
																																								goto IL_03f1;
																																							case 55:
																																							case 89:
																																								goto IL_03fe;
																																							case 3:
																																								goto IL_0417;
																																							case 32:
																																								goto IL_0425;
																																							case 11:
																																								goto IL_0433;
																																							case 84:
																																							case 101:
																																								goto IL_0446;
																																							case 92:
																																								goto IL_0454;
																																							case 49:
																																								goto IL_0462;
																																							case 103:
																																								goto IL_0475;
																																							case 1:
																																							case 18:
																																								goto IL_0483;
																																							case 35:
																																								goto IL_0491;
																																							case 0:
																																								goto IL_04b4;
																																							case 38:
																																								goto IL_04be;
																																							case 95:
																																								goto IL_04cc;
																																							case 117:
																																								goto IL_04e8;
																																							case 77:
																																								goto IL_04f6;
																																							case 108:
																																							case 119:
																																								goto IL_0509;
																																							case 23:
																																								goto IL_0549;
																																							case 112:
																																								goto IL_055d;
																																							case 140:
																																								goto IL_0570;
																																							case 73:
																																							case 122:
																																								goto IL_057e;
																																							case 91:
																																								goto IL_05be;
																																							case 154:
																																								goto IL_05d2;
																																							case 143:
																																							case 155:
																																								goto IL_05e5;
																																							case 27:
																																								goto IL_062e;
																																							case 40:
																																								goto IL_0642;
																																							case 131:
																																							case 159:
																																								goto IL_0655;
																																							case 114:
																																								goto IL_0663;
																																							case 90:
																																							case 128:
																																								goto IL_066e;
																																							case 2:
																																								goto IL_067c;
																																							case 61:
																																							case 138:
																																								goto IL_068f;
																																							case 158:
																																								goto IL_06cf;
																																							case 150:
																																								goto IL_06e3;
																																							case 85:
																																								goto IL_06f6;
																																							case 7:
																																								goto IL_0704;
																																							case 72:
																																							case 115:
																																								goto IL_0712;
																																							case 127:
																																								goto IL_073b;
																																							case 63:
																																								goto IL_0749;
																																							case 39:
																																							case 45:
																																								goto IL_076a;
																																							case 14:
																																								goto IL_07cc;
																																							case 19:
																																								goto IL_07df;
																																							case 116:
																																								goto IL_07ed;
																																							case 79:
																																								goto IL_0800;
																																							case 66:
																																								goto IL_080e;
																																							case 59:
																																							case 104:
																																								goto IL_0819;
																																							case 152:
																																								goto IL_0827;
																																							case 47:
																																							case 67:
																																								goto IL_0835;
																																							case 136:
																																							case 141:
																																								goto IL_084d;
																																							case 56:
																																								goto IL_0870;
																																							case 83:
																																								goto IL_087e;
																																							case 99:
																																								goto IL_088c;
																																							case 82:
																																								goto IL_08a8;
																																							case 62:
																																								goto IL_08bc;
																																							case 88:
																																							case 107:
																																								goto IL_08c7;
																																							case 34:
																																								goto IL_08e1;
																																							case 153:
																																								goto IL_08f1;
																																							case 64:
																																								goto IL_08fc;
																																							case 9:
																																							case 132:
																																								goto IL_0907;
																																							case 10:
																																							case 12:
																																							case 13:
																																							case 22:
																																							case 46:
																																							case 50:
																																							case 51:
																																							case 52:
																																							case 60:
																																							case 75:
																																							case 80:
																																							case 81:
																																							case 96:
																																							case 97:
																																							case 100:
																																							case 102:
																																							case 106:
																																							case 109:
																																							case 113:
																																							case 121:
																																							case 126:
																																							case 130:
																																							case 134:
																																							case 135:
																																							case 137:
																																							case 146:
																																							case 147:
																																							case 149:
																																							case 151:
																																							case 156:
																																							case 157:
																																								goto end_IL_032b;
																																							case 148:
																																								goto IL_0939;
																																							case 57:
																																								goto IL_0947;
																																							case 125:
																																								goto IL_0955;
																																							case 5:
																																							case 6:
																																							case 8:
																																							case 15:
																																							case 16:
																																							case 21:
																																							case 26:
																																							case 36:
																																							case 37:
																																							case 44:
																																							case 54:
																																							case 58:
																																							case 70:
																																							case 74:
																																							case 105:
																																							case 124:
																																							case 129:
																																								goto end_IL_02a7;
																																							case 142:
																																								goto IL_0976;
																																							case 41:
																																								goto IL_0981;
																																							case 133:
																																								goto IL_0994;
																																							case 120:
																																								goto IL_099f;
																																							case 29:
																																								goto IL_09bd;
																																							case 71:
																																								goto IL_09d6;
																																							case 30:
																																							case 118:
																																								goto IL_09e6;
																																							case 144:
																																								goto IL_09ff;
																																							case 48:
																																								goto IL_0a0f;
																																							case 145:
																																								goto IL_0a1f;
																																							case 86:
																																								goto IL_0a2f;
																																							case 87:
																																								goto end_IL_0963;
																																							case 28:
																																							case 98:
																																								return;
																																							}
																																							continue;
																																							end_IL_02a7:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			goto end_IL_03a8;
																																			continue;
																																			end_IL_032b:
																																			break;
																																			IL_032b:;
																																		}
																																	}
																																	else
																																	{
																																		num = 135;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_076a;
																															IL_07cc:
																															num6 -= 2;
																															goto end_IL_03a8;
																															IL_076a:
																															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_07cc;
																														}
																														break;
																													}
																													goto IL_07df;
																													IL_07ed:
																													if (11 <= b)
																													{
																														goto end_IL_03a8;
																													}
																													break;
																													IL_07df:
																													if (11 < b)
																													{
																														break;
																													}
																													goto IL_07ed;
																												}
																												break;
																											}
																											goto IL_03fe;
																											IL_0433:
																											ptr2 += 16;
																											goto end_IL_03a8;
																											IL_03fe:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																											goto IL_0417;
																											IL_0417:
																											array[num6] = 1;
																											goto IL_0425;
																											IL_0425:
																											num6++;
																											goto IL_0433;
																										}
																										break;
																									}
																									goto IL_0800;
																									IL_08fc:
																									if (16 > b)
																									{
																										break;
																									}
																									goto IL_0907;
																									IL_0800:
																									if (14 >= b)
																									{
																										goto IL_080e;
																									}
																									goto IL_08a8;
																									IL_080e:
																									if (14 > b)
																									{
																										goto IL_0819;
																									}
																									goto IL_084d;
																									IL_0819:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_0827;
																									IL_0827:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_0835;
																									IL_0835:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_03a8;
																									IL_084d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0870;
																									IL_0870:
																									array[num6] = 0;
																									goto IL_087e;
																									IL_087e:
																									num6++;
																									goto IL_088c;
																									IL_088c:
																									ptr2 += 8;
																									num = 124;
																									goto end_IL_03a8;
																									IL_08a8:
																									if (15 >= b)
																									{
																										num = 62;
																										goto IL_08bc;
																									}
																									goto IL_08f1;
																									IL_0907:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_03a8;
																									IL_08bc:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_08c7;
																									IL_08c7:
																									bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																									goto IL_08e1;
																									IL_08e1:
																									num6--;
																									goto end_IL_03a8;
																									IL_08f1:
																									if (16 < b)
																									{
																										break;
																									}
																									goto IL_08fc;
																								}
																								break;
																							}
																							goto IL_03d3;
																							IL_0749:
																							num6--;
																							goto end_IL_03a8;
																							IL_03d3:
																							if (8 <= b)
																							{
																								goto IL_03de;
																							}
																							goto IL_03f1;
																							IL_03de:
																							num6--;
																							goto end_IL_03a8;
																							IL_03f1:
																							if (4 < b)
																							{
																								goto IL_0446;
																							}
																							goto IL_0475;
																							IL_0446:
																							if (6 >= b)
																							{
																								goto IL_0454;
																							}
																							goto IL_04e8;
																							IL_0454:
																							if (6 > b)
																							{
																								goto IL_0462;
																							}
																							goto IL_0509;
																							IL_0462:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0570;
																							IL_0570:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_057e;
																							IL_057e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_05be;
																							IL_05be:
																							array[num6 - 2] = 0;
																							goto IL_05d2;
																							IL_05d2:
																							num6--;
																							goto end_IL_03a8;
																							IL_0509:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_0549;
																							IL_0549:
																							array[num6 - 2] = 0;
																							goto IL_055d;
																							IL_055d:
																							num6--;
																							goto end_IL_03a8;
																							IL_04e8:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_04f6;
																							IL_04f6:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_05e5;
																							IL_05e5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							num = 27;
																							goto IL_062e;
																							IL_062e:
																							array[num6 - 2] = 0;
																							goto IL_0642;
																							IL_0642:
																							num6--;
																							goto end_IL_03a8;
																							IL_0475:
																							if (4 <= b)
																							{
																								goto IL_0483;
																							}
																							goto IL_0655;
																							IL_0483:
																							array[num6] = 0;
																							goto IL_0491;
																							IL_0491:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																							goto IL_04b4;
																							IL_04b4:
																							array2[num6] = null;
																							goto IL_04be;
																							IL_04be:
																							num6++;
																							goto IL_04cc;
																							IL_04cc:
																							ptr2 += 8;
																							num = 70;
																							goto end_IL_03a8;
																							IL_0655:
																							if (2 >= b)
																							{
																								goto IL_0663;
																							}
																							goto IL_06f6;
																							IL_0663:
																							if (2 > b)
																							{
																								goto IL_066e;
																							}
																							goto IL_068f;
																							IL_066e:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_067c;
																							IL_067c:
																							if (1 <= b)
																							{
																							}
																							break;
																							IL_068f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_06cf;
																							IL_06cf:
																							array[num6 - 2] = 0;
																							goto IL_06e3;
																							IL_06e3:
																							num6--;
																							goto end_IL_03a8;
																							IL_06f6:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0704;
																							IL_0704:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0712;
																							IL_0712:
																							ref int reference = ref array4[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_073b;
																							IL_073b:
																							ptr2 += 8;
																							goto IL_0749;
																						}
																						break;
																						IL_0398:;
																					}
																				}
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0939;
																				IL_0955:
																				ptr2 += 8;
																				break;
																				IL_0947:
																				num6++;
																				goto IL_0955;
																				IL_0939:
																				array[num6] = 0;
																				goto IL_0947;
																				continue;
																				end_IL_03a8:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	continue;
																}
																num = 28;
																return;
																continue;
																end_IL_0963:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public unsafe static int CurrentIndex
	{
		get
		{
			int num = 42;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setAsUigetIndex.GetAwaiterParseFlags);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 98;
																while (true)
																{
																	IL_0348:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_032b:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_031b:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_030b:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_02fb:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_0299:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														while (true)
																														{
																															IL_027a:
																															array[num6 - 2] = 0;
																															num = 150;
																															while (true)
																															{
																																if (num != 150)
																																{
																																	if (num != 1131)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 31:
																																		goto IL_027a;
																																	case 64:
																																	case 91:
																																		goto IL_0299;
																																	case 4:
																																		goto IL_02db;
																																	case 10:
																																	case 24:
																																		goto IL_02eb;
																																	case 13:
																																	case 131:
																																		goto IL_02fb;
																																	case 82:
																																	case 142:
																																		goto IL_030b;
																																	case 23:
																																		goto IL_031b;
																																	case 55:
																																		goto IL_032b;
																																	case 76:
																																		goto IL_0338;
																																	case 98:
																																		goto IL_0348;
																																	case 65:
																																		goto end_IL_0348;
																																	case 61:
																																	case 109:
																																		goto end_IL_0358;
																																	case 0:
																																		goto IL_037c;
																																	case 40:
																																	case 66:
																																		goto IL_038a;
																																	case 70:
																																	case 115:
																																		goto IL_039e;
																																	case 45:
																																		goto IL_03ac;
																																	case 27:
																																	case 72:
																																		goto IL_03c5;
																																	case 122:
																																		goto IL_03e1;
																																	case 25:
																																		goto IL_03ec;
																																	case 89:
																																		goto IL_03fa;
																																	case 14:
																																	case 60:
																																		goto IL_0408;
																																	case 107:
																																	case 128:
																																		goto IL_0420;
																																	case 84:
																																		goto IL_0444;
																																	case 108:
																																		goto IL_0452;
																																	case 68:
																																		goto IL_0460;
																																	case 143:
																																		goto IL_0473;
																																	case 15:
																																		goto IL_0481;
																																	case 48:
																																		goto IL_048c;
																																	case 17:
																																		goto IL_049a;
																																	case 136:
																																		goto IL_04ad;
																																	case 35:
																																	case 120:
																																		goto IL_04c4;
																																	case 117:
																																		goto IL_04d2;
																																	case 77:
																																	case 106:
																																		goto IL_04e0;
																																	case 56:
																																		goto IL_0520;
																																	case 116:
																																		goto IL_0534;
																																	case 18:
																																	case 44:
																																		goto IL_0547;
																																	case 102:
																																		goto IL_05a9;
																																	case 50:
																																	case 127:
																																		goto IL_05bc;
																																	case 39:
																																		goto IL_05d5;
																																	case 7:
																																		goto IL_05e3;
																																	case 62:
																																		goto IL_05f1;
																																	case 88:
																																		goto IL_0617;
																																	case 33:
																																	case 59:
																																		goto IL_0622;
																																	case 12:
																																		goto IL_0662;
																																	case 1:
																																		goto IL_0676;
																																	case 49:
																																		goto IL_0692;
																																	case 83:
																																		goto IL_06a0;
																																	case 47:
																																	case 93:
																																		goto IL_06ae;
																																	case 140:
																																		goto IL_06f7;
																																	case 52:
																																		goto IL_070b;
																																	case 92:
																																		goto IL_071e;
																																	case 21:
																																	case 80:
																																		goto IL_0729;
																																	case 16:
																																		goto IL_0737;
																																	case 125:
																																		goto IL_075a;
																																	case 67:
																																		goto IL_0764;
																																	case 75:
																																		goto IL_0772;
																																	case 96:
																																		goto IL_0785;
																																	case 57:
																																		goto IL_0790;
																																	case 118:
																																		goto IL_079e;
																																	case 28:
																																	case 137:
																																		goto IL_07ac;
																																	case 9:
																																		goto IL_07d5;
																																	case 11:
																																		goto IL_07e3;
																																	case 103:
																																		goto IL_07ff;
																																	case 30:
																																	case 123:
																																		goto IL_080a;
																																	case 121:
																																		goto IL_084a;
																																	case 78:
																																		goto IL_085e;
																																	case 100:
																																		goto IL_086e;
																																	case 32:
																																		goto IL_0879;
																																	case 3:
																																	case 19:
																																		goto IL_0886;
																																	case 5:
																																	case 20:
																																	case 29:
																																	case 43:
																																	case 46:
																																	case 53:
																																	case 54:
																																	case 58:
																																	case 63:
																																	case 71:
																																	case 73:
																																	case 79:
																																	case 87:
																																	case 99:
																																	case 101:
																																	case 105:
																																	case 111:
																																	case 129:
																																	case 132:
																																	case 134:
																																	case 135:
																																	case 138:
																																		goto end_IL_0267;
																																	case 130:
																																		goto IL_08af;
																																	case 69:
																																		goto IL_08bd;
																																	case 2:
																																		goto IL_08cb;
																																	case 6:
																																	case 8:
																																	case 22:
																																	case 26:
																																	case 36:
																																	case 37:
																																	case 38:
																																	case 51:
																																	case 74:
																																	case 86:
																																	case 90:
																																	case 110:
																																	case 112:
																																	case 114:
																																	case 126:
																																	case 133:
																																	case 139:
																																	case 141:
																																		goto end_IL_0371;
																																	case 81:
																																		goto end_IL_08d9;
																																	case 97:
																																		goto end_IL_08ec;
																																	case 85:
																																		goto end_IL_08f6;
																																	case 94:
																																	case 95:
																																		goto end_IL_0901;
																																	case 34:
																																		goto end_IL_0911;
																																	case 104:
																																		goto end_IL_0921;
																																	case 113:
																																		goto end_IL_0931;
																																	case 41:
																																		goto end_IL_0941;
																																	case 42:
																																		goto end_IL_0951;
																																	case 119:
																																	case 124:
																																		goto IL_096c;
																																	}
																																	continue;
																																}
																																num6--;
																																goto end_IL_0371;
																																continue;
																																end_IL_0267:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																													IL_02db:;
																												}
																												break;
																												IL_02eb:;
																											}
																											break;
																										}
																										goto IL_0617;
																										IL_070b:
																										num6--;
																										goto end_IL_0371;
																										IL_0617:
																										if (6 <= b)
																										{
																											goto IL_0622;
																										}
																										goto IL_0692;
																										IL_0622:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0662;
																										IL_0662:
																										array[num6 - 2] = 0;
																										goto IL_0676;
																										IL_0676:
																										num6--;
																										num = 8;
																										goto end_IL_0371;
																										IL_0692:
																										if (5 < b)
																										{
																											break;
																										}
																										goto IL_06a0;
																										IL_06a0:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_06ae;
																										IL_06ae:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 140;
																										goto IL_06f7;
																										IL_06f7:
																										array[num6 - 2] = 0;
																										goto IL_070b;
																									}
																									break;
																								}
																								goto IL_071e;
																								IL_086e:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0879;
																								IL_071e:
																								if (4 <= b)
																								{
																									goto IL_0729;
																								}
																								goto IL_0785;
																								IL_0729:
																								array[num6] = 0;
																								goto IL_0737;
																								IL_0737:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_075a;
																								IL_075a:
																								array2[num6] = null;
																								goto IL_0764;
																								IL_0764:
																								num6++;
																								goto IL_0772;
																								IL_0772:
																								ptr2 += 8;
																								goto end_IL_0371;
																								IL_0785:
																								if (2 < b)
																								{
																									goto IL_0790;
																								}
																								num = 103;
																								goto IL_07ff;
																								IL_0790:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_079e;
																								IL_079e:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_07ac;
																								IL_07ac:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_07d5;
																								IL_07d5:
																								ptr2 += 8;
																								goto IL_07e3;
																								IL_07e3:
																								num6--;
																								goto end_IL_0371;
																								IL_0879:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_07ff:
																								if (2 <= b)
																								{
																									goto IL_080a;
																								}
																								goto IL_086e;
																								IL_080a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_084a;
																								IL_084a:
																								array[num6 - 2] = 0;
																								goto IL_085e;
																								IL_085e:
																								num6--;
																								goto end_IL_0371;
																							}
																							break;
																						}
																						goto IL_0886;
																						IL_0886:
																						num6--;
																						goto end_IL_0371;
																					}
																					break;
																				}
																				goto IL_037c;
																				IL_05bc:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_05d5;
																				IL_037c:
																				if (12 < b)
																				{
																					goto IL_038a;
																				}
																				goto IL_0473;
																				IL_038a:
																				if (14 < b)
																				{
																					num = 70;
																					goto IL_039e;
																				}
																				goto IL_03e1;
																				IL_05d5:
																				array[num6] = 1;
																				goto IL_05e3;
																				IL_039e:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_03ac;
																				IL_03ac:
																				if (15 > b)
																				{
																					num = 111;
																					break;
																				}
																				goto IL_03c5;
																				IL_05e3:
																				num6++;
																				goto IL_05f1;
																				IL_03c5:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0371;
																				IL_03e1:
																				if (14 > b)
																				{
																					goto IL_03ec;
																				}
																				goto IL_0420;
																				IL_03ec:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_03fa;
																				IL_03fa:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0408;
																				IL_0408:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0371;
																				IL_0420:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getindexGetTypeFlags[*(int*)(ptr2 + num3)])();
																				goto IL_0444;
																				IL_0444:
																				array[num6] = 0;
																				goto IL_0452;
																				IL_0452:
																				num6++;
																				goto IL_0460;
																				IL_0460:
																				ptr2 += 8;
																				goto end_IL_0371;
																				IL_0473:
																				if (12 > b)
																				{
																					goto IL_0481;
																				}
																				goto IL_05bc;
																				IL_0481:
																				if (10 < b)
																				{
																					goto IL_048c;
																				}
																				goto IL_04ad;
																				IL_048c:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_049a;
																				IL_049a:
																				if (11 <= b)
																				{
																					goto end_IL_0371;
																				}
																				break;
																				IL_04ad:
																				if (10 > b)
																				{
																					num = 35;
																					goto IL_04c4;
																				}
																				goto IL_0547;
																				IL_05f1:
																				ptr2 += 16;
																				goto end_IL_0371;
																				IL_04c4:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_04d2;
																				IL_04d2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_04e0;
																				IL_04e0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0520;
																				IL_0520:
																				array[num6 - 2] = 0;
																				goto IL_0534;
																				IL_0534:
																				num6--;
																				goto end_IL_0371;
																				IL_0547:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05a9;
																				IL_05a9:
																				num6 -= 2;
																				goto end_IL_0371;
																			}
																			break;
																			IL_0338:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_08af;
																	IL_08cb:
																	ptr2 += 8;
																	goto end_IL_0371;
																	IL_08bd:
																	num6++;
																	goto IL_08cb;
																	IL_08af:
																	array[num6] = 0;
																	goto IL_08bd;
																	continue;
																	end_IL_0348:
																	break;
																}
																continue;
																end_IL_0358:
																break;
															}
															continue;
															end_IL_0371:
															break;
														}
														continue;
													}
													goto IL_096c;
													IL_096c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_08d9:
													break;
												}
												continue;
												end_IL_08ec:
												break;
											}
											continue;
											end_IL_08f6:
											break;
										}
										continue;
										end_IL_0901:
										break;
									}
									continue;
									end_IL_0911:
									break;
								}
								continue;
								end_IL_0921:
								break;
							}
							continue;
							end_IL_0931:
							break;
						}
						continue;
						end_IL_0941:
						break;
					}
					continue;
					end_IL_0951:
					break;
				}
			}
		}
		set
		{
			int num = 205;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						num = 19;
						while (true)
						{
							byte[] array = new byte[4];
							while (true)
							{
								object[] array2 = new object[4];
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[4];
										while (true)
										{
											array3[0] = value;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ManagedKeyNotFoundException.ForkJoinLunisolarCalendar);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0471:
																	if (b >= 1)
																	{
																		while (b <= 22)
																		{
																			num = 26;
																			while (true)
																			{
																				IL_044e:
																				if (11 >= b)
																				{
																					while (true)
																					{
																						IL_043e:
																						if (11 > b)
																						{
																							while (true)
																							{
																								IL_0431:
																								if (5 < b)
																								{
																									while (true)
																									{
																										IL_0421:
																										if (8 < b)
																										{
																											while (true)
																											{
																												IL_0411:
																												if (9 >= b)
																												{
																													while (9 <= b)
																													{
																														while (true)
																														{
																															IL_03bf:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															while (true)
																															{
																																IL_03a0:
																																array[num6 - 2] = 0;
																																num = 220;
																																while (true)
																																{
																																	if (num != 220)
																																	{
																																		if (num != 1201)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 183:
																																			goto IL_03a0;
																																		case 21:
																																		case 54:
																																			goto IL_03bf;
																																		case 36:
																																			goto IL_0401;
																																		case 203:
																																			goto IL_0411;
																																		case 166:
																																			goto IL_0421;
																																		case 59:
																																		case 124:
																																			goto IL_0431;
																																		case 56:
																																			goto IL_043e;
																																		case 26:
																																			goto IL_044e;
																																		case 48:
																																			goto IL_045e;
																																		case 67:
																																			goto IL_0471;
																																		case 159:
																																			goto end_IL_0471;
																																		case 84:
																																		case 113:
																																			goto end_IL_0481;
																																		case 51:
																																			goto IL_04a5;
																																		case 62:
																																			goto IL_04b8;
																																		case 3:
																																		case 103:
																																			goto IL_04c8;
																																		case 132:
																																			goto IL_04db;
																																		case 71:
																																		case 108:
																																			goto IL_04e6;
																																		case 122:
																																			goto IL_04f4;
																																		case 13:
																																		case 102:
																																			goto IL_0502;
																																		case 24:
																																			goto IL_0542;
																																		case 5:
																																			goto IL_055b;
																																		case 28:
																																		case 149:
																																			goto IL_056b;
																																		case 141:
																																		case 156:
																																			goto IL_057e;
																																		case 146:
																																			goto IL_05c7;
																																		case 139:
																																			goto IL_05db;
																																		case 176:
																																			goto IL_05ee;
																																		case 78:
																																		case 165:
																																			goto IL_05fc;
																																		case 161:
																																			goto IL_065e;
																																		case 179:
																																			goto IL_0671;
																																		case 180:
																																			goto IL_0684;
																																		case 87:
																																		case 99:
																																			goto IL_068f;
																																		case 116:
																																		case 168:
																																			goto IL_069d;
																																		case 66:
																																			goto IL_06ab;
																																		case 11:
																																		case 41:
																																			goto IL_06b9;
																																		case 114:
																																			goto IL_06c7;
																																		case 129:
																																			goto IL_06ef;
																																		case 95:
																																		case 181:
																																			goto IL_0702;
																																		case 145:
																																			goto IL_0742;
																																		case 7:
																																			goto IL_0756;
																																		case 188:
																																			goto IL_0769;
																																		case 192:
																																			goto IL_077c;
																																		case 88:
																																			goto IL_0786;
																																		case 75:
																																		case 196:
																																			goto IL_0796;
																																		case 131:
																																			goto IL_07d6;
																																		case 44:
																																			goto IL_07ea;
																																		case 207:
																																			goto IL_07fd;
																																		case 208:
																																			goto IL_080d;
																																		case 211:
																																			goto IL_0820;
																																		case 58:
																																		case 212:
																																			goto IL_0833;
																																		case 158:
																																			goto IL_085c;
																																		case 198:
																																			goto IL_086a;
																																		case 25:
																																		case 187:
																																			goto IL_0890;
																																		case 63:
																																			goto IL_08a4;
																																		case 50:
																																			goto IL_08f8;
																																		case 177:
																																			goto IL_0906;
																																		case 79:
																																			goto IL_0919;
																																		case 12:
																																			goto IL_0930;
																																		case 6:
																																		case 130:
																																			goto IL_093b;
																																		case 61:
																																			goto IL_0965;
																																		case 160:
																																			goto IL_097e;
																																		case 144:
																																			goto IL_098c;
																																		case 101:
																																		case 134:
																																			goto IL_099a;
																																		case 4:
																																		case 52:
																																			goto IL_09a5;
																																		case 53:
																																			goto IL_09b3;
																																		case 38:
																																		case 121:
																																			goto IL_09c1;
																																		case 83:
																																			goto IL_09da;
																																		case 174:
																																			goto IL_09e8;
																																		case 80:
																																			goto IL_09f6;
																																		case 69:
																																			goto IL_0a09;
																																		case 8:
																																		case 136:
																																			goto end_IL_038d;
																																		case 127:
																																			goto IL_0a34;
																																		case 185:
																																			goto IL_0a3f;
																																		case 43:
																																		case 92:
																																			goto IL_0a4d;
																																		case 213:
																																			goto IL_0a70;
																																		case 42:
																																			goto IL_0a7e;
																																		case 2:
																																			goto IL_0a95;
																																		case 197:
																																			goto IL_0aa8;
																																		case 10:
																																			goto IL_0ab6;
																																		case 100:
																																		case 182:
																																			goto IL_0ac1;
																																		case 202:
																																			goto IL_0adf;
																																		case 123:
																																			goto IL_0aed;
																																		case 16:
																																			goto IL_0afb;
																																		case 30:
																																			goto IL_0b1c;
																																		case 97:
																																		case 117:
																																			goto IL_0b27;
																																		case 91:
																																			goto IL_0b32;
																																		case 17:
																																		case 147:
																																			goto IL_0b40;
																																		case 126:
																																			goto IL_0b5a;
																																		case 169:
																																			goto IL_0b6d;
																																		case 9:
																																			goto IL_0b7b;
																																		case 112:
																																		case 190:
																																			goto IL_0b89;
																																		case 60:
																																			goto IL_0ba5;
																																		case 162:
																																		case 172:
																																			goto IL_0bb3;
																																		case 40:
																																		case 164:
																																			goto IL_0bc1;
																																		case 195:
																																			goto IL_0bcf;
																																		case 35:
																																		case 199:
																																			goto IL_0bdd;
																																		case 193:
																																			goto IL_0c1d;
																																		case 32:
																																			goto IL_0c31;
																																		case 96:
																																			goto IL_0c44;
																																		case 107:
																																		case 178:
																																			goto IL_0c5d;
																																		case 133:
																																			goto IL_0c91;
																																		case 39:
																																		case 151:
																																			goto IL_0caa;
																																		case 55:
																																			goto IL_0cbe;
																																		case 209:
																																			goto IL_0d27;
																																		case 191:
																																			goto IL_0d3e;
																																		case 0:
																																		case 18:
																																		case 20:
																																		case 22:
																																		case 29:
																																		case 33:
																																		case 34:
																																		case 45:
																																		case 64:
																																		case 72:
																																		case 73:
																																		case 76:
																																		case 77:
																																		case 82:
																																		case 86:
																																		case 89:
																																		case 90:
																																		case 98:
																																		case 104:
																																		case 105:
																																		case 106:
																																		case 109:
																																		case 110:
																																		case 118:
																																		case 119:
																																		case 125:
																																		case 138:
																																		case 140:
																																		case 150:
																																		case 153:
																																		case 155:
																																		case 170:
																																		case 171:
																																		case 173:
																																		case 175:
																																		case 189:
																																		case 200:
																																		case 201:
																																			goto end_IL_0401;
																																		case 85:
																																			goto IL_0d67;
																																		case 120:
																																			goto IL_0d75;
																																		case 68:
																																			goto IL_0d83;
																																		case 1:
																																		case 14:
																																		case 15:
																																		case 23:
																																		case 27:
																																		case 31:
																																		case 46:
																																		case 74:
																																		case 81:
																																		case 93:
																																		case 94:
																																		case 111:
																																		case 115:
																																		case 135:
																																		case 137:
																																		case 142:
																																		case 148:
																																		case 152:
																																		case 154:
																																		case 157:
																																		case 163:
																																		case 167:
																																		case 184:
																																		case 186:
																																		case 206:
																																			goto end_IL_0491;
																																		case 143:
																																			goto end_IL_0d91;
																																		case 70:
																																			goto end_IL_0da4;
																																		case 128:
																																			goto end_IL_0dae;
																																		case 57:
																																			goto end_IL_0db9;
																																		case 37:
																																		case 210:
																																			goto end_IL_0dce;
																																		case 65:
																																			goto end_IL_0dde;
																																		case 19:
																																			goto end_IL_0dee;
																																		case 47:
																																			goto end_IL_0dfe;
																																		case 204:
																																			goto end_IL_0e0e;
																																		case 205:
																																			goto end_IL_0e27;
																																		case 49:
																																		case 194:
																																			return;
																																		}
																																		continue;
																																	}
																																	num6--;
																																	goto end_IL_0491;
																																	continue;
																																	end_IL_038d:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0a1c;
																														continue;
																														end_IL_0401:
																														break;
																														IL_0401:;
																													}
																													break;
																												}
																												goto IL_04c8;
																												IL_065e:
																												num6 -= 2;
																												goto end_IL_0491;
																												IL_04c8:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_05ee;
																												IL_05ee:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_05fc;
																												IL_05fc:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_065e;
																											}
																											break;
																										}
																										goto IL_04b8;
																										IL_05db:
																										num6--;
																										goto end_IL_0491;
																										IL_04b8:
																										if (8 > b)
																										{
																											goto IL_04db;
																										}
																										goto IL_056b;
																										IL_056b:
																										num6--;
																										goto end_IL_0491;
																										IL_04db:
																										if (6 < b)
																										{
																											goto IL_04e6;
																										}
																										goto IL_055b;
																										IL_04e6:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_04f4;
																										IL_04f4:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0502;
																										IL_0502:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0542;
																										IL_0542:
																										array[num6 - 2] = 0;
																										goto IL_0671;
																										IL_0671:
																										num6--;
																										goto end_IL_0491;
																										IL_055b:
																										if (6 > b)
																										{
																											break;
																										}
																										goto IL_057e;
																										IL_057e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 146;
																										goto IL_05c7;
																										IL_05c7:
																										array[num6 - 2] = 0;
																										goto IL_05db;
																									}
																									break;
																								}
																								num = 51;
																								goto IL_04a5;
																								IL_07fd:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0820;
																								IL_0820:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_04a5:
																								if (5 > b)
																								{
																									goto IL_0684;
																								}
																								goto IL_0702;
																								IL_0702:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0742;
																								IL_0742:
																								array[num6 - 2] = 0;
																								goto IL_0756;
																								IL_0756:
																								num6--;
																								goto end_IL_0491;
																								IL_0684:
																								if (2 < b)
																								{
																									goto IL_068f;
																								}
																								goto IL_06ef;
																								IL_068f:
																								if (3 < b)
																								{
																									goto IL_069d;
																								}
																								goto IL_0769;
																								IL_069d:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_06ab;
																								IL_06ab:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_06b9;
																								IL_06b9:
																								array[num6] = 0;
																								goto IL_06c7;
																								IL_06c7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_077c;
																								IL_077c:
																								array2[num6] = null;
																								goto IL_0786;
																								IL_0786:
																								num6++;
																								goto IL_080d;
																								IL_080d:
																								ptr2 += 8;
																								goto end_IL_0491;
																								IL_0769:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0833;
																								IL_0833:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_085c;
																								IL_085c:
																								ptr2 += 8;
																								goto IL_086a;
																								IL_086a:
																								num6--;
																								goto end_IL_0491;
																								IL_06ef:
																								if (2 <= b)
																								{
																									goto IL_0796;
																								}
																								goto IL_07fd;
																								IL_0796:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_07d6;
																								IL_07d6:
																								array[num6 - 2] = 0;
																								goto IL_07ea;
																								IL_07ea:
																								num6--;
																								goto end_IL_0491;
																							}
																							break;
																						}
																						goto IL_0890;
																						IL_0906:
																						ptr2 += 8;
																						goto end_IL_0491;
																						IL_0890:
																						array[num6 - 2] = 0;
																						goto IL_08a4;
																						IL_08a4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)ThreeLetterISOLanguageNameGetNativeDataSize[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_08f8;
																						IL_08f8:
																						num6--;
																						goto IL_0906;
																					}
																					break;
																				}
																				goto IL_0919;
																				IL_0caa:
																				array[num6 - 3] = 0;
																				goto IL_0cbe;
																				IL_0919:
																				if (17 >= b)
																				{
																					num = 12;
																					goto IL_0930;
																				}
																				goto IL_0b1c;
																				IL_0cbe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]) = ((delegate*<int, int, int, int>)ThreeLetterISOLanguageNameGetNativeDataSize[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0d27;
																				IL_0930:
																				if (17 <= b)
																				{
																					goto IL_093b;
																				}
																				goto IL_097e;
																				IL_093b:
																				*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((ColorOption[])array2[num6 - 1]).LongLength;
																				goto IL_0965;
																				IL_0965:
																				array[num6 - 1] = 2;
																				goto end_IL_0491;
																				IL_097e:
																				if (14 >= b)
																				{
																					goto IL_098c;
																				}
																				goto IL_0a34;
																				IL_098c:
																				if (14 > b)
																				{
																					goto IL_099a;
																				}
																				goto IL_0a1c;
																				IL_099a:
																				if (12 < b)
																				{
																					goto IL_09a5;
																				}
																				goto IL_0a09;
																				IL_09a5:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_09b3;
																				IL_09b3:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_09c1;
																				IL_09c1:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_09da;
																				IL_09da:
																				array[num6] = 1;
																				goto IL_09e8;
																				IL_09e8:
																				num6++;
																				goto IL_09f6;
																				IL_09f6:
																				ptr2 += 16;
																				goto end_IL_0491;
																				IL_0a09:
																				if (12 <= b)
																				{
																					goto end_IL_0491;
																				}
																				break;
																				IL_0a1c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0491;
																				IL_0a34:
																				if (15 >= b)
																				{
																					goto IL_0a3f;
																				}
																				goto IL_0aa8;
																				IL_0a3f:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0a4d;
																				IL_0a4d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0a70;
																				IL_0a70:
																				array[num6] = 0;
																				goto IL_0a7e;
																				IL_0a7e:
																				num6++;
																				num = 2;
																				goto IL_0a95;
																				IL_0a95:
																				ptr2 += 8;
																				goto end_IL_0491;
																				IL_0aa8:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_0ab6;
																				IL_0ab6:
																				if (16 > b)
																				{
																					num = 76;
																					break;
																				}
																				goto IL_0ac1;
																				IL_0ac1:
																				array2[num6] = ((delegate*<ColorOption[]>)ThreeLetterISOLanguageNameGetNativeDataSize[*(int*)(ptr2 + num3)])();
																				goto IL_0adf;
																				IL_0adf:
																				array[num6] = 5;
																				goto IL_0aed;
																				IL_0aed:
																				num6++;
																				goto IL_0afb;
																				IL_0afb:
																				ptr2 += 8;
																				goto end_IL_0491;
																				IL_0d27:
																				num6 -= 2;
																				num = 191;
																				goto IL_0d3e;
																				IL_0b1c:
																				if (20 < b)
																				{
																					goto IL_0b27;
																				}
																				goto IL_0ba5;
																				IL_0b27:
																				if (21 >= b)
																				{
																					goto IL_0b32;
																				}
																				goto IL_0b6d;
																				IL_0b32:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_0b40;
																				IL_0b40:
																				int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0b5a;
																				IL_0b5a:
																				num6--;
																				goto end_IL_0491;
																				IL_0b6d:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0b7b;
																				IL_0b7b:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_0b89;
																				IL_0b89:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0491;
																				IL_0ba5:
																				if (20 > b)
																				{
																					goto IL_0bb3;
																				}
																				goto IL_0caa;
																				IL_0bb3:
																				if (18 < b)
																				{
																					goto IL_0bc1;
																				}
																				goto IL_0c44;
																				IL_0bc1:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_0bcf;
																				IL_0bcf:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_0bdd;
																				IL_0bdd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0c1d;
																				IL_0c1d:
																				array[num6 - 2] = 0;
																				goto IL_0c31;
																				IL_0c31:
																				num6--;
																				goto end_IL_0491;
																				IL_0c44:
																				if (18 > b)
																				{
																					num = 118;
																					break;
																				}
																				goto IL_0c5d;
																				IL_0d3e:
																				ptr2 += 8;
																				goto end_IL_0491;
																				IL_0c5d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				num = 133;
																				goto IL_0c91;
																				IL_0c91:
																				array[num6 - 1] = 0;
																				goto end_IL_0491;
																			}
																			break;
																			IL_045e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0d67;
																	IL_0d83:
																	ptr2 += 8;
																	goto end_IL_0491;
																	IL_0d75:
																	num6++;
																	goto IL_0d83;
																	IL_0d67:
																	array[num6] = 0;
																	goto IL_0d75;
																	continue;
																	end_IL_0471:
																	break;
																}
																continue;
																end_IL_0481:
																break;
															}
															continue;
															end_IL_0491:
															break;
														}
														continue;
														end_IL_0d91:
														break;
													}
													continue;
													end_IL_0da4:
													break;
												}
												continue;
												end_IL_0dae:
												break;
											}
											continue;
											end_IL_0db9:
											break;
										}
										continue;
										end_IL_0dce:
										break;
									}
									continue;
									end_IL_0dde:
									break;
								}
								continue;
								end_IL_0dee:
								break;
							}
							continue;
							end_IL_0dfe:
							break;
						}
						continue;
						end_IL_0e0e:
						break;
					}
					continue;
					end_IL_0e27:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 165;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 164;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackOverflowExceptionRunClassConstructor.CMSASSEMBLYREFERENCEFLAGPREREQUISITEInlineMethod);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 143;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0608:
																if (b < 1)
																{
																	goto IL_05da;
																}
																goto IL_05f8;
																IL_05f8:
																if (b <= 20)
																{
																	goto IL_0373;
																}
																goto IL_05da;
																IL_05da:
																while (true)
																{
																	IL_05da_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	while (true)
																	{
																		IL_0363:
																		array[num5] = 0;
																		while (true)
																		{
																			IL_034a:
																			num5++;
																			num = 202;
																			while (true)
																			{
																				if (num != 202)
																				{
																					if (num != 1183)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 74:
																						goto IL_034a;
																					case 126:
																						goto IL_0363;
																					case 20:
																						goto IL_0373;
																					case 0:
																						goto IL_037e;
																					case 94:
																						goto IL_039a;
																					case 19:
																					case 152:
																						goto IL_03a8;
																					case 30:
																						goto IL_03b3;
																					case 149:
																						goto IL_03be;
																					case 60:
																					case 89:
																						goto IL_03cc;
																					case 59:
																						goto end_IL_0337;
																					case 138:
																						goto IL_03ed;
																					case 92:
																						goto IL_0409;
																					case 174:
																						goto IL_041c;
																					case 62:
																						goto IL_042a;
																					case 163:
																						goto IL_0435;
																					case 43:
																						goto IL_0443;
																					case 12:
																						goto IL_0451;
																					case 105:
																						goto IL_0464;
																					case 7:
																						goto IL_046f;
																					case 50:
																						goto IL_0482;
																					case 112:
																						goto IL_0490;
																					case 179:
																						goto IL_04a3;
																					case 73:
																					case 96:
																						goto IL_04ae;
																					case 49:
																						goto IL_04b9;
																					case 135:
																						goto IL_04cc;
																					case 177:
																						goto IL_04da;
																					case 72:
																						goto IL_04ed;
																					case 130:
																						goto IL_04fb;
																					case 83:
																					case 171:
																						goto IL_0506;
																					case 70:
																						goto IL_0519;
																					case 182:
																						goto IL_052c;
																					case 118:
																					case 183:
																						goto IL_053f;
																					case 25:
																					case 65:
																						goto IL_054a;
																					case 35:
																					case 178:
																						goto IL_0555;
																					case 181:
																						goto IL_0560;
																					case 33:
																						goto IL_0570;
																					case 144:
																						goto IL_0580;
																					case 107:
																					case 125:
																						goto IL_0597;
																					case 185:
																						goto IL_05a4;
																					case 186:
																						goto IL_05b4;
																					case 84:
																					case 189:
																						goto IL_05c1;
																					case 123:
																						goto IL_05cc;
																					case 3:
																					case 8:
																					case 10:
																					case 22:
																					case 23:
																					case 28:
																					case 29:
																					case 32:
																					case 38:
																					case 44:
																					case 45:
																					case 48:
																					case 54:
																					case 56:
																					case 63:
																					case 64:
																					case 68:
																					case 69:
																					case 81:
																					case 85:
																					case 90:
																					case 109:
																					case 111:
																					case 127:
																					case 129:
																					case 136:
																					case 142:
																					case 147:
																					case 148:
																					case 150:
																					case 151:
																					case 159:
																					case 168:
																					case 192:
																						goto IL_05da_2;
																					case 82:
																						goto IL_05f8;
																					case 13:
																						goto IL_0608;
																					case 170:
																						goto end_IL_0608;
																					case 18:
																					case 153:
																						goto end_IL_0615;
																					case 6:
																					case 121:
																						goto IL_0630;
																					case 31:
																						goto IL_0692;
																					case 78:
																					case 106:
																						goto IL_06a5;
																					case 11:
																					case 80:
																						goto IL_06ea;
																					case 58:
																					case 108:
																						goto IL_06fd;
																					case 133:
																						goto IL_073d;
																					case 46:
																						goto IL_0751;
																					case 172:
																						goto IL_076d;
																					case 145:
																						goto IL_078a;
																					case 42:
																					case 161:
																						goto IL_07a6;
																					case 154:
																						goto IL_07d1;
																					case 14:
																					case 122:
																						goto IL_07ea;
																					case 47:
																						goto IL_080e;
																					case 79:
																						goto IL_081c;
																					case 66:
																						goto IL_082a;
																					case 110:
																					case 167:
																						goto IL_083d;
																					case 51:
																						goto IL_0867;
																					case 158:
																					case 176:
																						goto IL_0880;
																					case 155:
																						goto IL_08a7;
																					case 86:
																					case 141:
																						goto IL_08ba;
																					case 104:
																						goto IL_08e3;
																					case 88:
																						goto IL_08f1;
																					case 97:
																					case 132:
																						goto IL_0904;
																					case 75:
																					case 99:
																						goto IL_0949;
																					case 24:
																						goto IL_0989;
																					case 173:
																						goto IL_099d;
																					case 55:
																					case 98:
																						goto IL_09b0;
																					case 53:
																						goto IL_09be;
																					case 95:
																						goto IL_09e1;
																					case 40:
																						goto IL_09eb;
																					case 162:
																						goto IL_09f9;
																					case 1:
																					case 134:
																						goto IL_0a0c;
																					case 119:
																						goto IL_0a3e;
																					case 36:
																						goto IL_0a4c;
																					case 26:
																					case 114:
																						goto IL_0a5f;
																					case 93:
																						goto IL_0a9f;
																					case 34:
																						goto IL_0ab3;
																					case 87:
																					case 184:
																						goto IL_0ac6;
																					case 15:
																					case 146:
																						goto IL_0ae2;
																					case 128:
																						goto IL_0afc;
																					case 188:
																						goto IL_0b0f;
																					case 115:
																						goto IL_0b23;
																					case 16:
																					case 187:
																						goto IL_0b36;
																					case 91:
																						goto IL_0b76;
																					case 139:
																						goto IL_0b8a;
																					case 194:
																						goto IL_0b9a;
																					case 2:
																						goto IL_0ba8;
																					case 57:
																					case 195:
																						goto IL_0bb8;
																					case 169:
																						goto IL_0bd0;
																					case 131:
																						goto IL_0bde;
																					case 120:
																						goto IL_0bec;
																					case 4:
																					case 21:
																					case 27:
																					case 37:
																					case 39:
																					case 41:
																					case 67:
																					case 71:
																					case 76:
																					case 100:
																					case 102:
																					case 103:
																					case 116:
																					case 117:
																					case 124:
																					case 137:
																					case 140:
																					case 143:
																					case 156:
																					case 157:
																					case 160:
																					case 166:
																					case 180:
																						goto end_IL_0625;
																					case 5:
																						goto end_IL_0c0a;
																					case 193:
																						goto end_IL_0c1d;
																					case 9:
																						goto end_IL_0c30;
																					case 77:
																						goto end_IL_0c3b;
																					case 17:
																						goto end_IL_0c4b;
																					case 61:
																					case 113:
																						goto end_IL_0c5b;
																					case 190:
																						goto end_IL_0c6b;
																					case 52:
																					case 101:
																						goto end_IL_0c7b;
																					case 164:
																						goto end_IL_0c8b;
																					case 165:
																						goto end_IL_0c9b;
																					case 175:
																					case 191:
																						return;
																					}
																					continue;
																				}
																				ptr2 += 8;
																				goto end_IL_0625;
																				continue;
																				end_IL_0337:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_03df;
																IL_0373:
																if (10 < b)
																{
																	goto IL_037e;
																}
																goto IL_039a;
																IL_037e:
																if (15 >= b)
																{
																	num = 174;
																	goto IL_041c;
																}
																goto IL_04a3;
																IL_073d:
																array[num5 - 2] = 0;
																goto IL_0751;
																IL_041c:
																if (15 > b)
																{
																	goto IL_042a;
																}
																num = 161;
																goto IL_07a6;
																IL_042a:
																if (12 >= b)
																{
																	goto IL_0435;
																}
																goto IL_0464;
																IL_0435:
																if (12 > b)
																{
																	goto IL_0443;
																}
																goto IL_07ea;
																IL_0443:
																if (11 >= b)
																{
																	goto IL_0451;
																}
																goto IL_05da;
																IL_0451:
																if (11 <= b)
																{
																	goto end_IL_0625;
																}
																goto IL_05da;
																IL_07ea:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)EndWriteCLAIMSECURITYATTRIBUTEFQBNVALUE[*(int*)(ptr2 + num3)])();
																goto IL_080e;
																IL_080e:
																array[num5] = 0;
																goto IL_081c;
																IL_081c:
																num5++;
																goto IL_082a;
																IL_082a:
																ptr2 += 8;
																goto end_IL_0625;
																IL_0464:
																if (13 >= b)
																{
																	goto IL_046f;
																}
																goto IL_0482;
																IL_046f:
																if (13 > b)
																{
																	goto IL_05da;
																}
																goto IL_0880;
																IL_0880:
																array2[num5] = ((delegate*<ColorOption[]>)EndWriteCLAIMSECURITYATTRIBUTEFQBNVALUE[*(int*)(ptr2 + num3)])();
																num = 155;
																goto IL_08a7;
																IL_08a7:
																array[num5] = 5;
																goto IL_0b9a;
																IL_0b9a:
																num5++;
																goto IL_0ba8;
																IL_0ba8:
																ptr2 += 8;
																goto end_IL_0625;
																IL_0482:
																if (14 >= b)
																{
																	goto IL_0490;
																}
																goto IL_05da;
																IL_0490:
																if (14 > b)
																{
																	goto IL_05da;
																}
																goto IL_083d;
																IL_083d:
																*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((ColorOption[])array2[num5 - 1]).LongLength;
																goto IL_0867;
																IL_0867:
																array[num5 - 1] = 2;
																goto end_IL_0625;
																IL_0751:
																num5--;
																num = 76;
																goto end_IL_0625;
																IL_07a6:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																goto IL_07d1;
																IL_07d1:
																array[num5 - 1] = 0;
																goto end_IL_0625;
																IL_04a3:
																if (18 < b)
																{
																	goto IL_04ae;
																}
																goto IL_04ed;
																IL_04ae:
																if (19 >= b)
																{
																	goto IL_04b9;
																}
																goto IL_04cc;
																IL_04b9:
																if (19 > b)
																{
																	goto IL_05da;
																}
																goto IL_08ba;
																IL_08ba:
																((delegate*<Class135, void>)EndWriteCLAIMSECURITYATTRIBUTEFQBNVALUE[*(int*)(ptr2 + num3)])((Class135)array2[num5 - 1]);
																goto IL_08e3;
																IL_08e3:
																num5--;
																goto IL_08f1;
																IL_08f1:
																ptr2 += 8;
																goto end_IL_0625;
																IL_04cc:
																if (20 >= b)
																{
																	goto IL_04da;
																}
																goto IL_05da;
																IL_04da:
																if (20 > b)
																{
																	goto IL_05da;
																}
																goto IL_0ac6;
																IL_0ac6:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_0625;
																IL_04ed:
																if (18 > b)
																{
																	goto IL_04fb;
																}
																goto IL_0bb8;
																IL_04fb:
																if (16 < b)
																{
																	goto IL_0506;
																}
																goto IL_0519;
																IL_0506:
																if (17 >= b)
																{
																	goto IL_05a4;
																}
																goto IL_05da;
																IL_05a4:
																if (17 > b)
																{
																	goto IL_05da;
																}
																goto IL_0ae2;
																IL_0ae2:
																int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0afc;
																IL_0afc:
																num5--;
																goto end_IL_0625;
																IL_0519:
																if (16 > b)
																{
																	goto IL_05da;
																}
																goto IL_0904;
																IL_0904:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0b0f;
																IL_0b0f:
																array[num5 - 2] = 0;
																goto IL_0b23;
																IL_0b23:
																num5--;
																goto end_IL_0625;
																IL_0bb8:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_0bd0;
																IL_0bd0:
																array[num5] = 5;
																goto IL_0bde;
																IL_0bde:
																num5++;
																goto IL_0bec;
																IL_0bec:
																ptr2 += 8;
																goto end_IL_0625;
																IL_039a:
																if (10 > b)
																{
																	goto IL_03a8;
																}
																goto IL_0630;
																IL_03a8:
																if (5 < b)
																{
																	goto IL_03b3;
																}
																num = 92;
																goto IL_0409;
																IL_03b3:
																if (7 >= b)
																{
																	goto IL_03be;
																}
																goto IL_03df;
																IL_03be:
																if (7 > b)
																{
																	goto IL_03cc;
																}
																goto IL_06a5;
																IL_03cc:
																if (6 >= b)
																{
																	goto IL_052c;
																}
																goto IL_05da;
																IL_052c:
																if (6 > b)
																{
																	goto IL_05da;
																}
																goto IL_0949;
																IL_0949:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0989;
																IL_0989:
																array[num5 - 2] = 0;
																goto IL_099d;
																IL_099d:
																num5--;
																goto end_IL_0625;
																IL_06a5:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_076d;
																IL_076d:
																array[num5 - 2] = 0;
																num = 145;
																goto IL_078a;
																IL_078a:
																num5--;
																goto end_IL_0625;
																IL_03df:
																if (8 >= b)
																{
																	goto IL_03ed;
																}
																goto IL_05c1;
																IL_03ed:
																if (8 > b)
																{
																	goto IL_05da;
																}
																goto IL_06ea;
																IL_06ea:
																num5--;
																goto end_IL_0625;
																IL_05c1:
																if (9 >= b)
																{
																	goto IL_05cc;
																}
																goto IL_05da;
																IL_05cc:
																if (9 > b)
																{
																	goto IL_05da;
																}
																goto IL_0b36;
																IL_0b36:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0b76;
																IL_0b76:
																array[num5 - 2] = 0;
																goto IL_0b8a;
																IL_0b8a:
																num5--;
																goto end_IL_0625;
																IL_0630:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0692;
																IL_0409:
																if (5 > b)
																{
																	goto IL_053f;
																}
																goto IL_06fd;
																IL_053f:
																if (2 < b)
																{
																	goto IL_054a;
																}
																goto IL_0580;
																IL_054a:
																if (3 < b)
																{
																	goto IL_0555;
																}
																goto IL_0570;
																IL_0555:
																if (4 >= b)
																{
																	goto IL_0560;
																}
																goto IL_05da;
																IL_0560:
																if (4 > b)
																{
																	goto IL_05da;
																}
																goto IL_09b0;
																IL_09b0:
																array[num5] = 0;
																goto IL_09be;
																IL_09be:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_09e1;
																IL_09e1:
																array2[num5] = null;
																goto IL_09eb;
																IL_09eb:
																num5++;
																goto IL_09f9;
																IL_09f9:
																ptr2 += 8;
																goto end_IL_0625;
																IL_0570:
																if (3 > b)
																{
																	goto IL_05da;
																}
																goto IL_0a0c;
																IL_0a0c:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																num = 119;
																goto IL_0a3e;
																IL_0a3e:
																ptr2 += 8;
																goto IL_0a4c;
																IL_0a4c:
																num5--;
																goto end_IL_0625;
																IL_0580:
																if (2 > b)
																{
																	num = 125;
																	goto IL_0597;
																}
																goto IL_0a5f;
																IL_0692:
																num5 -= 2;
																goto end_IL_0625;
																IL_0597:
																if (1 >= b)
																{
																	goto IL_05b4;
																}
																goto IL_05da;
																IL_05b4:
																if (1 > b)
																{
																}
																goto IL_05da;
																IL_0a5f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0a9f;
																IL_0a9f:
																array[num5 - 2] = 0;
																goto IL_0ab3;
																IL_0ab3:
																num5--;
																goto end_IL_0625;
																IL_06fd:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_073d;
																continue;
																end_IL_0608:
																break;
															}
															continue;
															end_IL_0615:
															break;
														}
														continue;
														end_IL_0625:
														break;
													}
													continue;
													end_IL_0c0a:
													break;
												}
												continue;
												end_IL_0c1d:
												break;
											}
											continue;
											end_IL_0c30:
											break;
										}
										continue;
										end_IL_0c3b:
										break;
									}
									continue;
									end_IL_0c4b:
									break;
								}
								continue;
								end_IL_0c5b:
								break;
							}
							continue;
							end_IL_0c6b:
							break;
						}
						continue;
						end_IL_0c7b:
						break;
					}
					continue;
					end_IL_0c8b:
					break;
				}
				continue;
				end_IL_0c9b:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001e, IL_062f, IL_063f, IL_064a, IL_0653, IL_0661, IL_066f, IL_067d, IL_068b, IL_0699, IL_06a7, IL_06b2, IL_06f2, IL_0706, IL_0719, IL_0727, IL_0735, IL_0740, IL_0749, IL_0757, IL_0781, IL_0798, IL_07ab, IL_07b9, IL_07c7, IL_07db, IL_081a, IL_082d, IL_0841, IL_088d, IL_089b, IL_08ae, IL_08bc, IL_08ca, IL_08d8, IL_08ec, IL_092b, IL_093e, IL_094c, IL_097e, IL_098c, IL_099f, IL_09ad, IL_09b8, IL_09f8, IL_0a0c, IL_0a1f, IL_0a2a, IL_0a38, IL_0a46, IL_0a6f, IL_0a7d, IL_0a90, IL_0a9e, IL_0aa7, IL_0ae4, IL_0af8, IL_0b0b, IL_0b16, IL_0b24, IL_0b40, IL_0b4e, IL_0b5c, IL_0b6a, IL_0b78, IL_0b86, IL_0b91, IL_0ba5, IL_0be4, IL_0bf7, IL_0c05, IL_0c13, IL_0c1e, IL_0c2c, IL_0c4a, IL_0c58, IL_0c6f, IL_0c82, IL_0c90, IL_0c9e, IL_0cc2, IL_0cd0, IL_0cde, IL_0cf1, IL_0d2e, IL_0d42, IL_0d55, IL_0d60, IL_0d6e, IL_0d87, IL_0d9a, IL_0da8, IL_0db6, IL_0dcf, IL_0ddd, IL_0df4, IL_0e10, IL_0e1e, IL_0e27, IL_0e32, IL_0e55, IL_0e63, IL_0e71, IL_0e84, IL_0e92, IL_0ea0, IL_0eae, IL_0ec2, IL_0f01, IL_0f14, IL_0f1d, IL_0f2b, IL_0f6b, IL_0f7f, IL_0f92, IL_0f9d, IL_0fab, IL_0fb4, IL_0fec, IL_1000, IL_1013, IL_1021, IL_102a, IL_1038, IL_1055, IL_10a7, IL_10b5, IL_10c8, IL_10d1, IL_10e5, IL_1124, IL_1137, IL_1145, IL_1153, IL_115e, IL_1172, IL_11b1, IL_11c4, IL_11d2, IL_11e0, IL_11ee, IL_11fc, IL_120a, IL_126c, IL_127f, IL_128d, IL_12cd, IL_12e1, IL_12f4, IL_1302, IL_130d, IL_131b, IL_135b, IL_136f, IL_1382, IL_1390, IL_139e, IL_13de, IL_13f2, IL_1405, IL_1418, IL_1421, IL_142c, IL_146c, IL_1480, IL_1493, IL_14a1, IL_14ac, IL_14ba, IL_14c8, IL_14e1, IL_14ef, IL_14fd, IL_1510, IL_1550, IL_1564, IL_1577, IL_1582, IL_158b, IL_1599, IL_15c2, IL_15d0, IL_15e3, IL_15f1, IL_15ff, IL_160d, IL_1630, IL_163a, IL_1648, IL_165b, IL_1669, IL_1674, IL_1682, IL_169a, IL_16a8, IL_16bb, IL_16c9, IL_16d4, IL_16fb, IL_1709, IL_171c, IL_1727, IL_173a, IL_1748, IL_1756, IL_1773, IL_17c2, IL_17cc, IL_17f9, IL_180d, IL_181b, IL_182e, IL_1839, IL_1847, IL_1879, IL_1892, IL_18a0, IL_18ae, IL_18c6, IL_18e4, IL_1911, IL_1929, IL_193c, IL_194a, IL_1958, IL_1966, IL_1974, IL_1982, IL_198b, IL_199f, IL_19d7, IL_19f3, IL_1a01, IL_1a48, IL_1a5b, IL_1a74, IL_1a8b, IL_1a99, IL_1aac, IL_1ab7, IL_1ac5, IL_1add, IL_1aeb, IL_1af9, IL_1b3a, IL_1b4e, IL_1b5e, IL_1bb9, IL_1bc9, IL_1bdc, IL_1bef, IL_1bfa, IL_1c04, IL_1c0f, IL_1c1f, IL_1c2f, IL_1c3f, IL_1c4f, IL_1c5f, IL_1c6f, IL_1c7f, IL_1c8f are reachable both inside and outside the pinned region starting at IL_1ca4. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 16;
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef51 = default(int);
			ref int reference = ref __rxRef51;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1c8f:
					num2 = 1;
					while (true)
					{
						IL_1c7f:
						num3 = num2 * 4;
						while (true)
						{
							IL_1c6f:
							num4 = num2 * 8;
							while (true)
							{
								IL_1c5f:
								array2 = new byte[4];
								while (true)
								{
									IL_1c4f:
									array3 = new object[4];
									while (true)
									{
										IL_1c3f:
										array4 = new int[4];
										while (true)
										{
											IL_1c2f:
											array5 = new int[7];
											while (true)
											{
												IL_1c1f:
												array6 = new long[4];
												while (true)
												{
													IL_1c0f:
													array7 = new object[18];
													while (true)
													{
														IL_1c04:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClaimsNewarr.NullTypeInfoToLocalTime);
														while (true)
														{
															IL_1bfa:
															ptr2 = ptr;
															while (true)
															{
																IL_1bef:
																num = 336;
																while (true)
																{
																	IL_1bdc:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_063f:
																		num = 392;
																		while (true)
																		{
																			if (num != 392)
																			{
																				if (num != 1373)
																				{
																					goto IL_1172;
																				}
																				switch (num)
																				{
																				case 16:
																					break;
																				default:
																					continue;
																				case 116:
																					goto IL_063f;
																				case 366:
																					goto IL_0653;
																				case 146:
																					goto IL_0661;
																				case 189:
																					goto IL_066f;
																				case 40:
																					goto IL_067d;
																				case 31:
																					goto IL_068b;
																				case 297:
																					goto IL_0699;
																				case 12:
																					goto IL_06a7;
																				case 149:
																				case 172:
																					goto IL_06b2;
																				case 328:
																					goto IL_06f2;
																				case 237:
																					goto IL_0706;
																				case 125:
																					goto IL_0719;
																				case 302:
																					goto IL_0727;
																				case 317:
																					goto IL_0735;
																				case 43:
																					goto IL_0749;
																				case 179:
																				case 344:
																					goto IL_0757;
																				case 236:
																					goto IL_0781;
																				case 28:
																					goto IL_0798;
																				case 376:
																					goto IL_07ab;
																				case 150:
																					goto IL_07b9;
																				case 17:
																				case 221:
																					goto IL_07c7;
																				case 329:
																					goto IL_07db;
																				case 8:
																					goto IL_081a;
																				case 89:
																				case 144:
																					goto IL_082d;
																				case 195:
																					goto IL_0841;
																				case 239:
																					goto IL_088d;
																				case 326:
																					goto IL_089b;
																				case 248:
																					goto IL_08ae;
																				case 227:
																					goto IL_08bc;
																				case 185:
																					goto IL_08ca;
																				case 220:
																				case 257:
																					goto IL_08d8;
																				case 216:
																					goto IL_08ec;
																				case 247:
																					goto IL_092b;
																				case 162:
																					goto IL_093e;
																				case 48:
																				case 108:
																					goto IL_094c;
																				case 367:
																					goto IL_097e;
																				case 225:
																					goto IL_098c;
																				case 316:
																					goto IL_099f;
																				case 156:
																					goto IL_09ad;
																				case 241:
																				case 335:
																					goto IL_09b8;
																				case 266:
																					goto IL_09f8;
																				case 232:
																					goto IL_0a0c;
																				case 10:
																					goto IL_0a1f;
																				case 260:
																					goto IL_0a2a;
																				case 120:
																					goto IL_0a38;
																				case 263:
																				case 364:
																					goto IL_0a46;
																				case 327:
																					goto IL_0a6f;
																				case 169:
																					goto IL_0a7d;
																				case 375:
																					goto IL_0a90;
																				case 86:
																				case 311:
																					goto IL_0aa7;
																				case 270:
																					goto IL_0ae4;
																				case 282:
																					goto IL_0af8;
																				case 242:
																					goto IL_0b0b;
																				case 52:
																					goto IL_0b16;
																				case 37:
																				case 274:
																					goto IL_0b24;
																				case 90:
																					goto IL_0b40;
																				case 385:
																					goto IL_0b4e;
																				case 78:
																					goto IL_0b6a;
																				case 283:
																					goto IL_0b78;
																				case 339:
																					goto IL_0b86;
																				case 33:
																				case 374:
																					goto IL_0b91;
																				case 315:
																					goto IL_0ba5;
																				case 77:
																					goto IL_0be4;
																				case 135:
																					goto IL_0bf7;
																				case 209:
																					goto IL_0c05;
																				case 312:
																					goto IL_0c13;
																				case 193:
																					goto IL_0c1e;
																				case 275:
																				case 301:
																					goto IL_0c2c;
																				case 253:
																					goto IL_0c4a;
																				case 39:
																					goto IL_0c58;
																				case 188:
																					goto IL_0c6f;
																				case 109:
																					goto IL_0c82;
																				case 378:
																					goto IL_0c90;
																				case 100:
																				case 252:
																					goto IL_0c9e;
																				case 73:
																					goto IL_0cc2;
																				case 321:
																					goto IL_0cd0;
																				case 347:
																					goto IL_0cde;
																				case 178:
																				case 346:
																					goto IL_0cf1;
																				case 314:
																					goto IL_0d2e;
																				case 72:
																					goto IL_0d42;
																				case 101:
																					goto IL_0d55;
																				case 98:
																					goto IL_0d60;
																				case 85:
																				case 199:
																					goto IL_0d6e;
																				case 214:
																					goto IL_0d87;
																				case 192:
																					goto IL_0d9a;
																				case 267:
																					goto IL_0da8;
																				case 219:
																				case 290:
																					goto IL_0db6;
																				case 57:
																					goto IL_0dcf;
																				case 238:
																					goto IL_0ddd;
																				case 206:
																					goto IL_0df4;
																				case 194:
																					goto IL_0e10;
																				case 170:
																					goto IL_0e27;
																				case 136:
																				case 360:
																					goto IL_0e32;
																				case 359:
																					goto IL_0e55;
																				case 154:
																					goto IL_0e63;
																				case 240:
																					goto IL_0e71;
																				case 61:
																					goto IL_0e84;
																				case 166:
																					goto IL_0e92;
																				case 207:
																					goto IL_0ea0;
																				case 113:
																				case 133:
																					goto IL_0eae;
																				case 121:
																					goto IL_0ec2;
																				case 55:
																					goto IL_0f01;
																				case 289:
																					goto IL_0f1d;
																				case 4:
																				case 70:
																					goto IL_0f2b;
																				case 277:
																					goto IL_0f6b;
																				case 255:
																					goto IL_0f7f;
																				case 244:
																					goto IL_0f92;
																				case 68:
																					goto IL_0f9d;
																				case 153:
																				case 351:
																					goto IL_0fb4;
																				case 107:
																					goto IL_0fec;
																				case 56:
																					goto IL_1000;
																				case 104:
																					goto IL_1013;
																				case 99:
																					goto IL_102a;
																				case 83:
																				case 97:
																					goto IL_1038;
																				case 190:
																					goto IL_1055;
																				case 331:
																					goto IL_10a7;
																				case 299:
																					goto IL_10b5;
																				case 234:
																				case 279:
																					goto IL_10d1;
																				case 358:
																					goto IL_10e5;
																				case 373:
																					goto IL_1124;
																				case 208:
																					goto IL_1137;
																				case 143:
																					goto IL_1145;
																				case 49:
																					goto IL_1153;
																				case 137:
																				case 343:
																					goto IL_115e;
																				case 291:
																					goto IL_1172;
																				case 168:
																					goto IL_11b1;
																				case 222:
																					goto IL_11c4;
																				case 191:
																					goto IL_11d2;
																				case 167:
																					goto IL_11e0;
																				case 58:
																					goto IL_11ee;
																				case 92:
																					goto IL_11fc;
																				case 224:
																				case 353:
																					goto IL_120a;
																				case 91:
																					goto IL_126c;
																				case 372:
																					goto IL_127f;
																				case 159:
																				case 383:
																					goto IL_128d;
																				case 349:
																					goto IL_12cd;
																				case 32:
																					goto IL_12e1;
																				case 362:
																					goto IL_12f4;
																				case 205:
																					goto IL_1302;
																				case 300:
																					goto IL_130d;
																				case 269:
																				case 305:
																					goto IL_131b;
																				case 379:
																					goto IL_135b;
																				case 35:
																					goto IL_136f;
																				case 370:
																					goto IL_1382;
																				case 75:
																					goto IL_1390;
																				case 22:
																				case 231:
																					goto IL_139e;
																				case 295:
																					goto IL_13de;
																				case 65:
																					goto IL_13f2;
																				case 151:
																				case 337:
																					goto IL_1405;
																				case 324:
																					goto IL_1421;
																				case 67:
																				case 306:
																					goto IL_142c;
																				case 103:
																					goto IL_146c;
																				case 74:
																					goto IL_1480;
																				case 233:
																					goto IL_1493;
																				case 307:
																					goto IL_14a1;
																				case 140:
																					goto IL_14ac;
																				case 147:
																					goto IL_14ba;
																				case 26:
																				case 258:
																					goto IL_14c8;
																				case 114:
																					goto IL_14e1;
																				case 62:
																					goto IL_14ef;
																				case 286:
																					goto IL_14fd;
																				case 27:
																				case 142:
																					goto IL_1510;
																				case 210:
																					goto IL_1550;
																				case 93:
																					goto IL_1564;
																				case 132:
																					goto IL_1577;
																				case 47:
																					goto IL_158b;
																				case 211:
																				case 338:
																					goto IL_1599;
																				case 139:
																					goto IL_15c2;
																				case 356:
																					goto IL_15d0;
																				case 340:
																					goto IL_15e3;
																				case 320:
																					goto IL_15f1;
																				case 184:
																				case 281:
																					goto IL_15ff;
																				case 175:
																					goto IL_160d;
																				case 21:
																					goto IL_1630;
																				case 148:
																					goto IL_163a;
																				case 382:
																					goto IL_1648;
																				case 171:
																					goto IL_165b;
																				case 127:
																					goto IL_1669;
																				case 6:
																				case 361:
																					goto IL_1674;
																				case 105:
																					goto IL_1682;
																				case 183:
																					goto IL_169a;
																				case 341:
																					goto IL_16a8;
																				case 176:
																					goto IL_16bb;
																				case 250:
																					goto IL_16c9;
																				case 217:
																				case 288:
																					goto IL_16d4;
																				case 51:
																					goto IL_16fb;
																				case 322:
																					goto IL_1709;
																				case 14:
																					goto IL_171c;
																				case 0:
																					goto IL_1727;
																				case 226:
																					goto IL_173a;
																				case 50:
																					goto IL_1748;
																				case 79:
																				case 332:
																					goto IL_1756;
																				case 38:
																					goto IL_180d;
																				case 271:
																					goto IL_181b;
																				case 319:
																					goto IL_182e;
																				case 115:
																					goto IL_1839;
																				case 63:
																				case 313:
																					goto IL_1847;
																				case 9:
																					goto IL_1879;
																				case 5:
																					goto IL_1892;
																				case 363:
																					goto IL_18a0;
																				case 34:
																				case 118:
																					goto IL_18ae;
																				case 368:
																					goto IL_18c6;
																				case 158:
																					goto IL_18e4;
																				case 292:
																					goto IL_1911;
																				case 53:
																					goto IL_1929;
																				case 229:
																					goto IL_193c;
																				case 128:
																					goto IL_194a;
																				case 354:
																					goto IL_1958;
																				case 265:
																					goto IL_1966;
																				case 303:
																					goto IL_1974;
																				case 278:
																				case 296:
																					goto IL_198b;
																				case 96:
																					goto IL_199f;
																				case 197:
																					goto IL_19d7;
																				case 174:
																					goto IL_19f3;
																				case 218:
																				case 355:
																					goto IL_1a01;
																				case 163:
																					goto IL_1a48;
																				case 145:
																				case 308:
																					goto IL_1a5b;
																				case 204:
																					goto IL_1a74;
																				case 323:
																					goto IL_1a8b;
																				case 160:
																					goto IL_1a99;
																				case 212:
																					goto IL_1aac;
																				case 36:
																					goto IL_1ab7;
																				case 82:
																				case 377:
																					goto IL_1ac5;
																				case 110:
																					goto IL_1add;
																				case 173:
																					goto IL_1aeb;
																				case 213:
																				case 287:
																					goto IL_1af9;
																				case 124:
																					goto IL_1b3a;
																				case 29:
																					goto IL_1b4e;
																				case 76:
																				case 141:
																					goto IL_1b5e;
																				case 126:
																					goto IL_1bb9;
																				case 1:
																				case 7:
																				case 11:
																				case 13:
																				case 24:
																				case 25:
																				case 30:
																				case 41:
																				case 44:
																				case 46:
																				case 59:
																				case 84:
																				case 87:
																				case 106:
																				case 111:
																				case 112:
																				case 122:
																				case 123:
																				case 130:
																				case 131:
																				case 134:
																				case 157:
																				case 161:
																				case 164:
																				case 177:
																				case 181:
																				case 186:
																				case 187:
																				case 196:
																				case 198:
																				case 201:
																				case 223:
																				case 235:
																				case 251:
																				case 256:
																				case 259:
																				case 262:
																				case 268:
																				case 273:
																				case 276:
																				case 284:
																				case 293:
																				case 298:
																				case 304:
																				case 310:
																				case 325:
																				case 357:
																				case 365:
																				case 371:
																					goto IL_1bc9;
																				case 3:
																				case 18:
																				case 19:
																				case 23:
																				case 42:
																				case 45:
																				case 54:
																				case 60:
																				case 80:
																				case 81:
																				case 94:
																				case 95:
																				case 102:
																				case 117:
																				case 129:
																				case 138:
																				case 152:
																				case 155:
																				case 180:
																				case 182:
																				case 200:
																				case 202:
																				case 203:
																				case 215:
																				case 228:
																				case 230:
																				case 243:
																				case 245:
																				case 246:
																				case 249:
																				case 254:
																				case 264:
																				case 280:
																				case 285:
																				case 294:
																				case 318:
																				case 330:
																				case 333:
																				case 334:
																				case 336:
																				case 342:
																				case 345:
																				case 348:
																				case 350:
																				case 352:
																				case 380:
																				case 381:
																				case 384:
																					goto IL_1bdc;
																				case 69:
																					goto IL_1bef;
																				case 272:
																					goto IL_1bfa;
																				case 261:
																					goto IL_1c04;
																				case 165:
																					goto IL_1c0f;
																				case 2:
																					goto IL_1c1f;
																				case 369:
																					goto IL_1c2f;
																				case 66:
																					goto IL_1c3f;
																				case 20:
																					goto IL_1c4f;
																				case 88:
																					goto IL_1c5f;
																				case 64:
																					goto IL_1c6f;
																				case 71:
																					goto IL_1c7f;
																				case 15:
																					goto IL_1c8f;
																				case 119:
																				case 309:
																					return;
																				}
																				break;
																			}
																			b = *ptr2;
																			goto IL_0653;
																			IL_1a01:
																			((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																			num = 163;
																			goto IL_1a48;
																			IL_1a5b:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																			goto IL_1a74;
																			IL_1a48:
																			num6 -= 3;
																			goto IL_1bdc;
																			IL_0653:
																			ptr2++;
																			goto IL_0661;
																			IL_0661:
																			if (b >= 1)
																			{
																				goto IL_066f;
																			}
																			goto IL_1bc9;
																			IL_066f:
																			if (b <= 46)
																			{
																				goto IL_067d;
																			}
																			goto IL_1bc9;
																			IL_067d:
																			if (23 < b)
																			{
																				goto IL_068b;
																			}
																			goto IL_1137;
																			IL_068b:
																			if (35 < b)
																			{
																				goto IL_0699;
																			}
																			goto IL_0b6a;
																			IL_0699:
																			if (41 >= b)
																			{
																				goto IL_06a7;
																			}
																			goto IL_099f;
																			IL_06a7:
																			if (41 <= b)
																			{
																				goto IL_06b2;
																			}
																			goto IL_0719;
																			IL_06b2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_06f2;
																			IL_06f2:
																			array2[num6 - 2] = 3;
																			goto IL_0706;
																			IL_0706:
																			num6--;
																			goto IL_1bdc;
																			IL_0719:
																			if (38 >= b)
																			{
																				goto IL_0727;
																			}
																			goto IL_08ae;
																			IL_0727:
																			if (38 > b)
																			{
																				goto IL_0735;
																			}
																			goto IL_082d;
																			IL_0735:
																			if (36 >= b)
																			{
																				num = 43;
																				goto IL_0749;
																			}
																			goto IL_07ab;
																			IL_1a74:
																			array2[num6] = 1;
																			num = 323;
																			goto IL_1a8b;
																			IL_0749:
																			if (36 <= b)
																			{
																				goto IL_0757;
																			}
																			goto IL_1bc9;
																			IL_0757:
																			((delegate*<bool, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																			goto IL_0781;
																			IL_0781:
																			num6--;
																			num = 28;
																			goto IL_0798;
																			IL_0798:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_07ab:
																			if (37 >= b)
																			{
																				goto IL_07b9;
																			}
																			goto IL_1bc9;
																			IL_07b9:
																			if (37 <= b)
																			{
																				goto IL_07c7;
																			}
																			goto IL_1bc9;
																			IL_07c7:
																			array2[num6 - 1] = 3;
																			goto IL_07db;
																			IL_07db:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_081a;
																			IL_081a:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_082d:
																			array2[num6 - 2] = 5;
																			goto IL_0841;
																			IL_0841:
																			array3[num6 - 2] = ((delegate*<string, string, string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																			goto IL_088d;
																			IL_088d:
																			num6--;
																			goto IL_089b;
																			IL_089b:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_08ae:
																			if (39 < b)
																			{
																				goto IL_08bc;
																			}
																			goto IL_093e;
																			IL_08bc:
																			if (40 >= b)
																			{
																				goto IL_08ca;
																			}
																			goto IL_1bc9;
																			IL_08ca:
																			if (40 <= b)
																			{
																				goto IL_08d8;
																			}
																			goto IL_1bc9;
																			IL_08d8:
																			array2[num6 - 1] = 3;
																			goto IL_08ec;
																			IL_08ec:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_092b;
																			IL_092b:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_093e:
																			if (39 <= b)
																			{
																				goto IL_094c;
																			}
																			goto IL_1bc9;
																			IL_094c:
																			((delegate*<string, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																			num = 367;
																			goto IL_097e;
																			IL_097e:
																			num6--;
																			goto IL_098c;
																			IL_098c:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_099f:
																			if (44 >= b)
																			{
																				goto IL_09ad;
																			}
																			goto IL_0b0b;
																			IL_09ad:
																			if (44 <= b)
																			{
																				goto IL_09b8;
																			}
																			goto IL_0a1f;
																			IL_09b8:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_09f8;
																			IL_09f8:
																			array2[num6 - 2] = 3;
																			goto IL_0a0c;
																			IL_0a0c:
																			num6--;
																			goto IL_1bdc;
																			IL_0a1f:
																			if (42 < b)
																			{
																				goto IL_0a2a;
																			}
																			goto IL_0a90;
																			IL_0a2a:
																			if (43 >= b)
																			{
																				goto IL_0a38;
																			}
																			goto IL_1bc9;
																			IL_0a38:
																			if (43 <= b)
																			{
																				goto IL_0a46;
																			}
																			goto IL_1bc9;
																			IL_0a46:
																			((delegate*<Color, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																			goto IL_0a6f;
																			IL_0a6f:
																			num6--;
																			goto IL_0a7d;
																			IL_0a7d:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0a90:
																			if (42 <= b)
																			{
																				num = 86;
																				goto IL_0aa7;
																			}
																			goto IL_1bc9;
																			IL_1a8b:
																			num6++;
																			goto IL_1a99;
																			IL_0aa7:
																			array3[num6 - 1] = ((delegate*<ColorOption, Color>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																			goto IL_0ae4;
																			IL_0ae4:
																			array2[num6 - 1] = 4;
																			goto IL_0af8;
																			IL_0af8:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0b0b:
																			if (45 >= b)
																			{
																				goto IL_0b16;
																			}
																			goto IL_0b40;
																			IL_0b16:
																			if (45 <= b)
																			{
																				goto IL_0b24;
																			}
																			goto IL_1bc9;
																			IL_0b24:
																			num7 = ptr2;
																			num8 = -200;
																			num5 = 1;
																			ptr2 = num7 + num8;
																			goto IL_1bdc;
																			IL_0b40:
																			if (46 >= b)
																			{
																				goto IL_0b4e;
																			}
																			goto IL_1bc9;
																			IL_0b4e:
																			if (46 <= b)
																			{
																				num = 325;
																			}
																			goto IL_1bc9;
																			IL_1a99:
																			ptr2 += 16;
																			goto IL_1bdc;
																			IL_0b6a:
																			if (35 > b)
																			{
																				goto IL_0b78;
																			}
																			num = 279;
																			goto IL_10d1;
																			IL_0b78:
																			if (29 >= b)
																			{
																				goto IL_0b86;
																			}
																			goto IL_0e10;
																			IL_0b86:
																			if (29 <= b)
																			{
																				goto IL_0b91;
																			}
																			goto IL_0bf7;
																			IL_0b91:
																			array2[num6 - 1] = 3;
																			goto IL_0ba5;
																			IL_0ba5:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_0be4;
																			IL_0be4:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0bf7:
																			if (26 >= b)
																			{
																				goto IL_0c05;
																			}
																			goto IL_0d55;
																			IL_0c05:
																			if (26 > b)
																			{
																				goto IL_0c13;
																			}
																			goto IL_0cf1;
																			IL_0c13:
																			if (24 >= b)
																			{
																				goto IL_0c1e;
																			}
																			goto IL_0c82;
																			IL_0c1e:
																			if (24 <= b)
																			{
																				goto IL_0c2c;
																			}
																			goto IL_1bc9;
																			IL_0c2c:
																			array3[num6] = ((delegate*<ColorOption[]>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
																			goto IL_0c4a;
																			IL_0c4a:
																			array2[num6] = 5;
																			goto IL_0c58;
																			IL_0c58:
																			num6++;
																			num = 188;
																			goto IL_0c6f;
																			IL_0c6f:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0c82:
																			if (25 >= b)
																			{
																				goto IL_0c90;
																			}
																			goto IL_1bc9;
																			IL_0c90:
																			if (25 <= b)
																			{
																				goto IL_0c9e;
																			}
																			goto IL_1bc9;
																			IL_0c9e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
																			goto IL_0cc2;
																			IL_0cc2:
																			array2[num6] = 0;
																			goto IL_0cd0;
																			IL_0cd0:
																			num6++;
																			goto IL_0cde;
																			IL_0cde:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0cf1:
																			array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																			goto IL_0d2e;
																			IL_0d2e:
																			array2[num6 - 2] = 4;
																			goto IL_0d42;
																			IL_0d42:
																			num6--;
																			goto IL_1bdc;
																			IL_0d55:
																			if (27 >= b)
																			{
																				goto IL_0d60;
																			}
																			goto IL_0d9a;
																			IL_0d60:
																			if (27 <= b)
																			{
																				goto IL_0d6e;
																			}
																			goto IL_1bc9;
																			IL_0d6e:
																			global::_003CModule_003E.colorOption_2 = (ColorOption)array3[num6 - 1];
																			goto IL_0d87;
																			IL_0d87:
																			num6--;
																			goto IL_1bdc;
																			IL_0d9a:
																			if (28 >= b)
																			{
																				goto IL_0da8;
																			}
																			goto IL_1bc9;
																			IL_0da8:
																			if (28 <= b)
																			{
																				goto IL_0db6;
																			}
																			goto IL_1bc9;
																			IL_0db6:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																			goto IL_0dcf;
																			IL_0dcf:
																			array2[num6] = 3;
																			goto IL_0ddd;
																			IL_0ddd:
																			num6++;
																			num = 206;
																			goto IL_0df4;
																			IL_0df4:
																			ptr2 += 16;
																			num = 294;
																			goto IL_1bdc;
																			IL_0e10:
																			if (32 >= b)
																			{
																				num = 170;
																				goto IL_0e27;
																			}
																			goto IL_0f92;
																			IL_1ab7:
																			if (21 <= b)
																			{
																				goto IL_1ac5;
																			}
																			goto IL_1bc9;
																			IL_0e27:
																			if (32 <= b)
																			{
																				goto IL_0e32;
																			}
																			goto IL_0e84;
																			IL_0e32:
																			array3[num6] = ((delegate*<ColorOption>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
																			goto IL_0e55;
																			IL_0e55:
																			array2[num6] = 4;
																			goto IL_0e63;
																			IL_0e63:
																			num6++;
																			goto IL_0e71;
																			IL_0e71:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_0e84:
																			if (30 < b)
																			{
																				goto IL_0e92;
																			}
																			num = 289;
																			goto IL_0f1d;
																			IL_0e92:
																			if (31 >= b)
																			{
																				goto IL_0ea0;
																			}
																			goto IL_1bc9;
																			IL_0ea0:
																			if (31 <= b)
																			{
																				goto IL_0eae;
																			}
																			goto IL_1bc9;
																			IL_0eae:
																			array2[num6 - 1] = 0;
																			goto IL_0ec2;
																			IL_0ec2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_0f01;
																			IL_0f01:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_1ac5:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1bdc;
																			IL_0f1d:
																			if (30 <= b)
																			{
																				goto IL_0f2b;
																			}
																			goto IL_1bc9;
																			IL_0f2b:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0f6b;
																			IL_0f6b:
																			array2[num6 - 2] = 3;
																			goto IL_0f7f;
																			IL_0f7f:
																			num6--;
																			goto IL_1bdc;
																			IL_0f92:
																			if (33 >= b)
																			{
																				goto IL_0f9d;
																			}
																			goto IL_1013;
																			IL_0f9d:
																			if (33 <= b)
																			{
																				num = 351;
																				goto IL_0fb4;
																			}
																			goto IL_1bc9;
																			IL_1add:
																			if (22 >= b)
																			{
																				goto IL_1aeb;
																			}
																			goto IL_1bc9;
																			IL_0fb4:
																			array3[num6 - 1] = ((delegate*<ColorOption, string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																			goto IL_0fec;
																			IL_0fec:
																			array2[num6 - 1] = 5;
																			goto IL_1000;
																			IL_1000:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_1013:
																			if (34 >= b)
																			{
																				num = 99;
																				goto IL_102a;
																			}
																			goto IL_1bc9;
																			IL_1aeb:
																			if (22 <= b)
																			{
																				goto IL_1af9;
																			}
																			goto IL_1bc9;
																			IL_102a:
																			if (34 <= b)
																			{
																				goto IL_1038;
																			}
																			goto IL_1bc9;
																			IL_1038:
																			array2[num6 - 2] = 0;
																			num = 190;
																			goto IL_1055;
																			IL_1055:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																			goto IL_10a7;
																			IL_10a7:
																			num6--;
																			goto IL_10b5;
																			IL_10b5:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_1aac:
																			if (21 >= b)
																			{
																				goto IL_1ab7;
																			}
																			goto IL_1add;
																			IL_10d1:
																			array2[num6 - 1] = 3;
																			goto IL_10e5;
																			IL_10e5:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_1124;
																			IL_1124:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_1137:
																			if (23 > b)
																			{
																				goto IL_1145;
																			}
																			goto IL_1b5e;
																			IL_1145:
																			if (11 >= b)
																			{
																				goto IL_1153;
																			}
																			goto IL_165b;
																			IL_1153:
																			if (11 <= b)
																			{
																				goto IL_115e;
																			}
																			goto IL_11c4;
																			IL_115e:
																			array2[num6 - 1] = 0;
																			goto IL_1172;
																			IL_1172:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_11b1;
																			IL_11b1:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_11c4:
																			if (5 < b)
																			{
																				goto IL_11d2;
																			}
																			num = 324;
																			goto IL_1421;
																			IL_11d2:
																			if (8 < b)
																			{
																				goto IL_11e0;
																			}
																			goto IL_12f4;
																			IL_11e0:
																			if (9 < b)
																			{
																				goto IL_11ee;
																			}
																			goto IL_127f;
																			IL_11ee:
																			if (10 >= b)
																			{
																				goto IL_11fc;
																			}
																			goto IL_1bc9;
																			IL_11fc:
																			if (10 <= b)
																			{
																				goto IL_120a;
																			}
																			goto IL_1bc9;
																			IL_120a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_126c;
																			IL_126c:
																			num6 -= 2;
																			goto IL_1bdc;
																			IL_127f:
																			if (9 <= b)
																			{
																				goto IL_128d;
																			}
																			goto IL_1bc9;
																			IL_128d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_12cd;
																			IL_12cd:
																			array2[num6 - 2] = 0;
																			goto IL_12e1;
																			IL_12e1:
																			num6--;
																			goto IL_1bdc;
																			IL_12f4:
																			if (8 > b)
																			{
																				goto IL_1302;
																			}
																			goto IL_1405;
																			IL_1302:
																			if (6 >= b)
																			{
																				goto IL_130d;
																			}
																			goto IL_1382;
																			IL_130d:
																			if (6 <= b)
																			{
																				goto IL_131b;
																			}
																			goto IL_1bc9;
																			IL_131b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_135b;
																			IL_135b:
																			array2[num6 - 2] = 0;
																			goto IL_136f;
																			IL_136f:
																			num6--;
																			goto IL_1bdc;
																			IL_1382:
																			if (7 >= b)
																			{
																				goto IL_1390;
																			}
																			goto IL_1bc9;
																			IL_1390:
																			if (7 <= b)
																			{
																				goto IL_139e;
																			}
																			goto IL_1bc9;
																			IL_139e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_13de;
																			IL_13de:
																			array2[num6 - 2] = 0;
																			goto IL_13f2;
																			IL_13f2:
																			num6--;
																			goto IL_1bdc;
																			IL_1405:
																			num6--;
																			goto IL_1bdc;
																			IL_1af9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																			goto IL_1b3a;
																			IL_1421:
																			if (5 <= b)
																			{
																				goto IL_142c;
																			}
																			goto IL_1493;
																			IL_142c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_146c;
																			IL_146c:
																			array2[num6 - 2] = 0;
																			goto IL_1480;
																			IL_1480:
																			num6--;
																			goto IL_1bdc;
																			IL_1493:
																			if (2 >= b)
																			{
																				goto IL_14a1;
																			}
																			goto IL_1577;
																			IL_14a1:
																			if (2 > b)
																			{
																				goto IL_14ac;
																			}
																			goto IL_1510;
																			IL_14ac:
																			if (1 >= b)
																			{
																				goto IL_14ba;
																			}
																			goto IL_1bc9;
																			IL_14ba:
																			if (1 <= b)
																			{
																				goto IL_14c8;
																			}
																			goto IL_1bc9;
																			IL_14c8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_14e1;
																			IL_14e1:
																			array2[num6] = 0;
																			goto IL_14ef;
																			IL_14ef:
																			num6++;
																			goto IL_14fd;
																			IL_14fd:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_1510:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_1550;
																			IL_1550:
																			array2[num6 - 2] = 0;
																			goto IL_1564;
																			IL_1564:
																			num6--;
																			goto IL_1bdc;
																			IL_1577:
																			if (3 >= b)
																			{
																				num = 47;
																				goto IL_158b;
																			}
																			goto IL_15e3;
																			IL_1b3a:
																			array2[num6 - 2] = 0;
																			goto IL_1b4e;
																			IL_158b:
																			if (3 <= b)
																			{
																				goto IL_1599;
																			}
																			goto IL_1bc9;
																			IL_1599:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_15c2;
																			IL_15c2:
																			ptr2 += 8;
																			goto IL_15d0;
																			IL_15d0:
																			num6--;
																			goto IL_1bdc;
																			IL_15e3:
																			if (4 >= b)
																			{
																				goto IL_15f1;
																			}
																			goto IL_1bc9;
																			IL_15f1:
																			if (4 <= b)
																			{
																				goto IL_15ff;
																			}
																			goto IL_1bc9;
																			IL_15ff:
																			array2[num6] = 0;
																			goto IL_160d;
																			IL_160d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_1630;
																			IL_1630:
																			array3[num6] = null;
																			goto IL_163a;
																			IL_163a:
																			num6++;
																			goto IL_1648;
																			IL_1648:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_165b:
																			if (17 >= b)
																			{
																				goto IL_1669;
																			}
																			goto IL_193c;
																			IL_1669:
																			if (17 <= b)
																			{
																				goto IL_1674;
																			}
																			goto IL_16bb;
																			IL_1674:
																			array2[num6] = 5;
																			goto IL_1682;
																			IL_1682:
																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																			goto IL_169a;
																			IL_169a:
																			num6++;
																			goto IL_16a8;
																			IL_16a8:
																			ptr2 += 8;
																			goto IL_1bdc;
																			IL_16bb:
																			if (14 >= b)
																			{
																				goto IL_16c9;
																			}
																			goto IL_182e;
																			IL_16c9:
																			if (14 <= b)
																			{
																				goto IL_16d4;
																			}
																			goto IL_171c;
																			IL_16d4:
																			array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																			num = 51;
																			goto IL_16fb;
																			IL_16fb:
																			ptr2 += 8;
																			goto IL_1709;
																			IL_1709:
																			num6--;
																			goto IL_1bdc;
																			IL_171c:
																			if (12 >= b)
																			{
																				goto IL_1727;
																			}
																			goto IL_173a;
																			IL_1727:
																			if (12 <= b)
																			{
																				goto IL_1bdc;
																			}
																			goto IL_1bc9;
																			IL_173a:
																			if (13 >= b)
																			{
																				goto IL_1748;
																			}
																			goto IL_1bc9;
																			IL_1748:
																			if (13 <= b)
																			{
																				goto IL_1756;
																			}
																			goto IL_1bc9;
																			IL_1756:
																			array8 = array3;
																			num9 = num6;
																			if (array == null)
																			{
																				goto IL_1765;
																			}
																			num10 = ptr2;
																			byte b2 = *num10;
																			ptr2 = num10 + 4;
																			int num11 = *(int*)(ptr2 + num3);
																			ptr2 += 8;
																			byte* ptr3 = ptr2 + num11;
																			byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																			while (ptr2 != ptr3)
																			{
																				*ptr4 = (byte)(*ptr2 ^ b2);
																				ptr2++;
																				ptr4++;
																			}
																			array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																			goto IL_180d;
																			IL_1b4e:
																			num6--;
																			goto IL_1bdc;
																			IL_1b5e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 126;
																			goto IL_1bb9;
																			IL_1bb9:
																			num6--;
																			goto IL_1bdc;
																			IL_180d:
																			array2[num6] = 5;
																			goto IL_181b;
																			IL_181b:
																			num6++;
																			goto IL_1bdc;
																			IL_182e:
																			if (15 >= b)
																			{
																				goto IL_1839;
																			}
																			goto IL_1892;
																			IL_1839:
																			if (15 <= b)
																			{
																				goto IL_1847;
																			}
																			goto IL_1bc9;
																			IL_1847:
																			array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																			num = 9;
																			goto IL_1879;
																			IL_1879:
																			array2[num6 - 1] = 5;
																			goto IL_1bdc;
																			IL_1892:
																			if (16 >= b)
																			{
																				goto IL_18a0;
																			}
																			goto IL_1bc9;
																			IL_18a0:
																			if (16 <= b)
																			{
																				goto IL_18ae;
																			}
																			goto IL_1bc9;
																			IL_18ae:
																			array2[num6] = array2[num6 - 1];
																			goto IL_18c6;
																			IL_18c6:
																			array4[num6 - 0] = array4[num6 - 1];
																			goto IL_18e4;
																			IL_18e4:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 292;
																			goto IL_1911;
																			IL_1911:
																			array3[num6] = array3[num6 - 1];
																			goto IL_1929;
																			IL_1929:
																			num6++;
																			goto IL_1bdc;
																			IL_193c:
																			if (20 >= b)
																			{
																				goto IL_194a;
																			}
																			goto IL_1aac;
																			IL_194a:
																			if (20 > b)
																			{
																				goto IL_1958;
																			}
																			goto IL_1a5b;
																			IL_1958:
																			if (18 < b)
																			{
																				goto IL_1966;
																			}
																			goto IL_19f3;
																			IL_1966:
																			if (19 >= b)
																			{
																				goto IL_1974;
																			}
																			goto IL_1bc9;
																			IL_1974:
																			if (19 <= b)
																			{
																				num = 278;
																				goto IL_198b;
																			}
																			goto IL_1bc9;
																			IL_1bc9:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1bdc;
																			IL_198b:
																			array2[num6 - 1] = 5;
																			goto IL_199f;
																			IL_199f:
																			array3[num6 - 1] = ((delegate*<string[], string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																			goto IL_19d7;
																			IL_19d7:
																			ptr2 += 8;
																			num = 228;
																			goto IL_1bdc;
																			IL_19f3:
																			if (18 <= b)
																			{
																				goto IL_1a01;
																			}
																			goto IL_1bc9;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1765:
			while (true)
			{
				IL_1765_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_180d_2:
						array2[num6] = 5;
						while (true)
						{
							IL_181b_2:
							num6++;
							while (true)
							{
								IL_1bdc_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									num = 392;
									while (true)
									{
										if (num != 392)
										{
											if (num != 1373)
											{
												goto IL_1172_2;
											}
											switch (num)
											{
											case 116:
												goto end_IL_062f;
											case 366:
												goto IL_0653_2;
											case 146:
												goto IL_0661_2;
											case 189:
												goto IL_066f_2;
											case 40:
												goto IL_067d_2;
											case 31:
												goto IL_068b_2;
											case 297:
												goto IL_0699_2;
											case 12:
												goto IL_06a7_2;
											case 149:
											case 172:
												goto IL_06b2_2;
											case 328:
												goto IL_06f2_2;
											case 237:
												goto IL_0706_2;
											case 125:
												goto IL_0719_2;
											case 302:
												goto IL_0727_2;
											case 317:
												goto IL_0735_2;
											case 43:
												goto IL_0749_2;
											case 179:
											case 344:
												goto IL_0757_2;
											case 236:
												goto IL_0781_2;
											case 28:
												goto IL_0798_2;
											case 376:
												goto IL_07ab_2;
											case 150:
												goto IL_07b9_2;
											case 17:
											case 221:
												goto IL_07c7_2;
											case 329:
												goto IL_07db_2;
											case 8:
												goto IL_081a_2;
											case 89:
											case 144:
												goto IL_082d_2;
											case 195:
												goto IL_0841_2;
											case 239:
												goto IL_088d_2;
											case 326:
												goto IL_089b_2;
											case 248:
												goto IL_08ae_2;
											case 227:
												goto IL_08bc_2;
											case 185:
												goto IL_08ca_2;
											case 220:
											case 257:
												goto IL_08d8_2;
											case 216:
												goto IL_08ec_2;
											case 247:
												goto IL_092b_2;
											case 162:
												goto IL_093e_2;
											case 48:
											case 108:
												goto IL_094c_2;
											case 367:
												goto IL_097e_2;
											case 225:
												goto IL_098c_2;
											case 316:
												goto IL_099f_2;
											case 156:
												goto IL_09ad_2;
											case 241:
											case 335:
												goto IL_09b8_2;
											case 266:
												goto IL_09f8_2;
											case 232:
												goto IL_0a0c_2;
											case 10:
												goto IL_0a1f_2;
											case 260:
												goto IL_0a2a_2;
											case 120:
												goto IL_0a38_2;
											case 263:
											case 364:
												goto IL_0a46_2;
											case 327:
												goto IL_0a6f_2;
											case 169:
												goto IL_0a7d_2;
											case 375:
												goto IL_0a90_2;
											case 86:
											case 311:
												goto IL_0aa7_2;
											case 270:
												goto IL_0ae4_2;
											case 282:
												goto IL_0af8_2;
											case 242:
												goto IL_0b0b_2;
											case 52:
												goto IL_0b16_2;
											case 37:
											case 274:
												goto IL_0b24_2;
											case 90:
												goto IL_0b40_2;
											case 385:
												goto IL_0b4e_2;
											case 78:
												goto IL_0b6a_2;
											case 283:
												goto IL_0b78_2;
											case 339:
												goto IL_0b86_2;
											case 33:
											case 374:
												goto IL_0b91_2;
											case 315:
												goto IL_0ba5_2;
											case 77:
												goto IL_0be4_2;
											case 135:
												goto IL_0bf7_2;
											case 209:
												goto IL_0c05_2;
											case 312:
												goto IL_0c13_2;
											case 193:
												goto IL_0c1e_2;
											case 275:
											case 301:
												goto IL_0c2c_2;
											case 253:
												goto IL_0c4a_2;
											case 39:
												goto IL_0c58_2;
											case 188:
												goto IL_0c6f_2;
											case 109:
												goto IL_0c82_2;
											case 378:
												goto IL_0c90_2;
											case 100:
											case 252:
												goto IL_0c9e_2;
											case 73:
												goto IL_0cc2_2;
											case 321:
												goto IL_0cd0_2;
											case 347:
												goto IL_0cde_2;
											case 178:
											case 346:
												goto IL_0cf1_2;
											case 314:
												goto IL_0d2e_2;
											case 72:
												goto IL_0d42_2;
											case 101:
												goto IL_0d55_2;
											case 98:
												goto IL_0d60_2;
											case 85:
											case 199:
												goto IL_0d6e_2;
											case 214:
												goto IL_0d87_2;
											case 192:
												goto IL_0d9a_2;
											case 267:
												goto IL_0da8_2;
											case 219:
											case 290:
												goto IL_0db6_2;
											case 57:
												goto IL_0dcf_2;
											case 238:
												goto IL_0ddd_2;
											case 206:
												goto IL_0df4_2;
											case 194:
												goto IL_0e10_2;
											case 170:
												goto IL_0e27_2;
											case 136:
											case 360:
												goto IL_0e32_2;
											case 359:
												goto IL_0e55_2;
											case 154:
												goto IL_0e63_2;
											case 240:
												goto IL_0e71_2;
											case 61:
												goto IL_0e84_2;
											case 166:
												goto IL_0e92_2;
											case 207:
												goto IL_0ea0_2;
											case 113:
											case 133:
												goto IL_0eae_2;
											case 121:
												goto IL_0ec2_2;
											case 55:
												goto IL_0f01_2;
											case 289:
												goto IL_0f1d_2;
											case 4:
											case 70:
												goto IL_0f2b_2;
											case 277:
												goto IL_0f6b_2;
											case 255:
												goto IL_0f7f_2;
											case 244:
												goto IL_0f92_2;
											case 68:
												goto IL_0f9d_2;
											case 153:
											case 351:
												goto IL_0fb4_2;
											case 107:
												goto IL_0fec_2;
											case 56:
												goto IL_1000_2;
											case 104:
												goto IL_1013_2;
											case 99:
												goto IL_102a_2;
											case 83:
											case 97:
												goto IL_1038_2;
											case 190:
												goto IL_1055_2;
											case 331:
												goto IL_10a7_2;
											case 299:
												goto IL_10b5_2;
											case 234:
											case 279:
												goto IL_10d1_2;
											case 358:
												goto IL_10e5_2;
											case 373:
												goto IL_1124_2;
											case 208:
												goto IL_1137_2;
											case 143:
												goto IL_1145_2;
											case 49:
												goto IL_1153_2;
											case 137:
											case 343:
												goto IL_115e_2;
											case 291:
												goto IL_1172_2;
											case 168:
												goto IL_11b1_2;
											case 222:
												goto IL_11c4_2;
											case 191:
												goto IL_11d2_2;
											case 167:
												goto IL_11e0_2;
											case 58:
												goto IL_11ee_2;
											case 92:
												goto IL_11fc_2;
											case 224:
											case 353:
												goto IL_120a_2;
											case 91:
												goto IL_126c_2;
											case 372:
												goto IL_127f_2;
											case 159:
											case 383:
												goto IL_128d_2;
											case 349:
												goto IL_12cd_2;
											case 32:
												goto IL_12e1_2;
											case 362:
												goto IL_12f4_2;
											case 205:
												goto IL_1302_2;
											case 300:
												goto IL_130d_2;
											case 269:
											case 305:
												goto IL_131b_2;
											case 379:
												goto IL_135b_2;
											case 35:
												goto IL_136f_2;
											case 370:
												goto IL_1382_2;
											case 75:
												goto IL_1390_2;
											case 22:
											case 231:
												goto IL_139e_2;
											case 295:
												goto IL_13de_2;
											case 65:
												goto IL_13f2_2;
											case 151:
											case 337:
												goto IL_1405_2;
											case 324:
												goto IL_1421_2;
											case 67:
											case 306:
												goto IL_142c_2;
											case 103:
												goto IL_146c_2;
											case 74:
												goto IL_1480_2;
											case 233:
												goto IL_1493_2;
											case 307:
												goto IL_14a1_2;
											case 140:
												goto IL_14ac_2;
											case 147:
												goto IL_14ba_2;
											case 26:
											case 258:
												goto IL_14c8_2;
											case 114:
												goto IL_14e1_2;
											case 62:
												goto IL_14ef_2;
											case 286:
												goto IL_14fd_2;
											case 27:
											case 142:
												goto IL_1510_2;
											case 210:
												goto IL_1550_2;
											case 93:
												goto IL_1564_2;
											case 132:
												goto IL_1577_2;
											case 47:
												goto IL_158b_2;
											case 211:
											case 338:
												goto IL_1599_2;
											case 139:
												goto IL_15c2_2;
											case 356:
												goto IL_15d0_2;
											case 340:
												goto IL_15e3_2;
											case 320:
												goto IL_15f1_2;
											case 184:
											case 281:
												goto IL_15ff_2;
											case 175:
												goto IL_160d_2;
											case 21:
												goto IL_1630_2;
											case 148:
												goto IL_163a_2;
											case 382:
												goto IL_1648_2;
											case 171:
												goto IL_165b_2;
											case 127:
												goto IL_1669_2;
											case 6:
											case 361:
												goto IL_1674_2;
											case 105:
												goto IL_1682_2;
											case 183:
												goto IL_169a_2;
											case 341:
												goto IL_16a8_2;
											case 176:
												goto IL_16bb_2;
											case 250:
												goto IL_16c9_2;
											case 217:
											case 288:
												goto IL_16d4_2;
											case 51:
												goto IL_16fb_2;
											case 322:
												goto IL_1709_2;
											case 14:
												goto IL_171c_2;
											case 0:
												goto IL_1727_2;
											case 226:
												goto IL_173a_2;
											case 50:
												goto IL_1748_2;
											case 79:
											case 332:
												goto end_IL_063f;
											case 38:
												goto IL_180d_2;
											case 271:
												goto IL_181b_2;
											case 319:
												goto IL_182e_2;
											case 115:
												goto IL_1839_2;
											case 63:
											case 313:
												goto IL_1847_2;
											case 9:
												goto IL_1879_2;
											case 5:
												goto IL_1892_2;
											case 363:
												goto IL_18a0_2;
											case 34:
											case 118:
												goto IL_18ae_2;
											case 368:
												goto IL_18c6_2;
											case 158:
												goto IL_18e4_2;
											case 292:
												goto IL_1911_2;
											case 53:
												goto IL_1929_2;
											case 229:
												goto IL_193c_2;
											case 128:
												goto IL_194a_2;
											case 354:
												goto IL_1958_2;
											case 265:
												goto IL_1966_2;
											case 303:
												goto IL_1974_2;
											case 278:
											case 296:
												goto IL_198b_2;
											case 96:
												goto IL_199f_2;
											case 197:
												goto IL_19d7_2;
											case 174:
												goto IL_19f3_2;
											case 218:
											case 355:
												goto IL_1a01_2;
											case 163:
												goto IL_1a48_2;
											case 145:
											case 308:
												goto IL_1a5b_2;
											case 204:
												goto IL_1a74_2;
											case 323:
												goto IL_1a8b_2;
											case 160:
												goto IL_1a99_2;
											case 212:
												goto IL_1aac_2;
											case 36:
												goto IL_1ab7_2;
											case 82:
											case 377:
												goto IL_1ac5_2;
											case 110:
												goto IL_1add_2;
											case 173:
												goto IL_1aeb_2;
											case 213:
											case 287:
												goto IL_1af9_2;
											case 124:
												goto IL_1b3a_2;
											case 29:
												goto IL_1b4e_2;
											case 76:
											case 141:
												goto IL_1b5e_2;
											case 126:
												goto IL_1bb9_2;
											case 1:
											case 7:
											case 11:
											case 13:
											case 24:
											case 25:
											case 30:
											case 41:
											case 44:
											case 46:
											case 59:
											case 84:
											case 87:
											case 106:
											case 111:
											case 112:
											case 122:
											case 123:
											case 130:
											case 131:
											case 134:
											case 157:
											case 161:
											case 164:
											case 177:
											case 181:
											case 186:
											case 187:
											case 196:
											case 198:
											case 201:
											case 223:
											case 235:
											case 251:
											case 256:
											case 259:
											case 262:
											case 268:
											case 273:
											case 276:
											case 284:
											case 293:
											case 298:
											case 304:
											case 310:
											case 325:
											case 357:
											case 365:
											case 371:
												goto IL_1bc9_2;
											case 3:
											case 18:
											case 19:
											case 23:
											case 42:
											case 45:
											case 54:
											case 60:
											case 80:
											case 81:
											case 94:
											case 95:
											case 102:
											case 117:
											case 129:
											case 138:
											case 152:
											case 155:
											case 180:
											case 182:
											case 200:
											case 202:
											case 203:
											case 215:
											case 228:
											case 230:
											case 243:
											case 245:
											case 246:
											case 249:
											case 254:
											case 264:
											case 280:
											case 285:
											case 294:
											case 318:
											case 330:
											case 333:
											case 334:
											case 336:
											case 342:
											case 345:
											case 348:
											case 350:
											case 352:
											case 380:
											case 381:
											case 384:
												goto IL_1bdc_2;
											case 69:
												num = 336;
												goto IL_1bdc_2;
											case 272:
												ptr2 = ptr;
												goto case 69;
											case 261:
												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClaimsNewarr.NullTypeInfoToLocalTime);
												goto case 272;
											case 165:
												array7 = new object[18];
												goto case 261;
											case 2:
												array6 = new long[4];
												goto case 165;
											case 369:
												array5 = new int[7];
												goto case 2;
											case 66:
												array4 = new int[4];
												goto case 369;
											case 20:
												array3 = new object[4];
												goto case 66;
											case 88:
												array2 = new byte[4];
												goto case 20;
											case 64:
												num4 = num2 * 8;
												goto case 88;
											case 71:
												num3 = num2 * 4;
												goto case 64;
											case 15:
												num2 = 1;
												goto case 71;
											case 16:
												goto end_IL_1773;
											case 119:
											case 309:
												return;
											}
											continue;
										}
										b = *ptr2;
										goto IL_0653_2;
										IL_1a74_2:
										array2[num6] = 1;
										num = 323;
										goto IL_1a8b_2;
										IL_1a99_2:
										ptr2 += 16;
										goto IL_1bdc_2;
										IL_1a8b_2:
										num6++;
										goto IL_1a99_2;
										IL_0653_2:
										ptr2++;
										goto IL_0661_2;
										IL_0661_2:
										if (b >= 1)
										{
											goto IL_066f_2;
										}
										goto IL_1bc9_2;
										IL_066f_2:
										if (b <= 46)
										{
											goto IL_067d_2;
										}
										goto IL_1bc9_2;
										IL_067d_2:
										if (23 < b)
										{
											goto IL_068b_2;
										}
										goto IL_1137_2;
										IL_068b_2:
										if (35 < b)
										{
											goto IL_0699_2;
										}
										goto IL_0b6a_2;
										IL_0699_2:
										if (41 >= b)
										{
											goto IL_06a7_2;
										}
										goto IL_099f_2;
										IL_06a7_2:
										if (41 <= b)
										{
											goto IL_06b2_2;
										}
										goto IL_0719_2;
										IL_06b2_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_06f2_2;
										IL_06f2_2:
										array2[num6 - 2] = 3;
										goto IL_0706_2;
										IL_0706_2:
										num6--;
										goto IL_1bdc_2;
										IL_0719_2:
										if (38 >= b)
										{
											goto IL_0727_2;
										}
										goto IL_08ae_2;
										IL_0727_2:
										if (38 > b)
										{
											goto IL_0735_2;
										}
										goto IL_082d_2;
										IL_0735_2:
										if (36 >= b)
										{
											num = 43;
											goto IL_0749_2;
										}
										goto IL_07ab_2;
										IL_1aac_2:
										if (21 >= b)
										{
											goto IL_1ab7_2;
										}
										goto IL_1add_2;
										IL_0749_2:
										if (36 <= b)
										{
											goto IL_0757_2;
										}
										goto IL_1bc9_2;
										IL_0757_2:
										((delegate*<bool, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
										goto IL_0781_2;
										IL_0781_2:
										num6--;
										num = 28;
										goto IL_0798_2;
										IL_0798_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_07ab_2:
										if (37 >= b)
										{
											goto IL_07b9_2;
										}
										goto IL_1bc9_2;
										IL_07b9_2:
										if (37 <= b)
										{
											goto IL_07c7_2;
										}
										goto IL_1bc9_2;
										IL_07c7_2:
										array2[num6 - 1] = 3;
										goto IL_07db_2;
										IL_07db_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_081a_2;
										IL_081a_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_082d_2:
										array2[num6 - 2] = 5;
										goto IL_0841_2;
										IL_0841_2:
										array3[num6 - 2] = ((delegate*<string, string, string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
										goto IL_088d_2;
										IL_088d_2:
										num6--;
										goto IL_089b_2;
										IL_089b_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_08ae_2:
										if (39 < b)
										{
											goto IL_08bc_2;
										}
										goto IL_093e_2;
										IL_08bc_2:
										if (40 >= b)
										{
											goto IL_08ca_2;
										}
										goto IL_1bc9_2;
										IL_08ca_2:
										if (40 <= b)
										{
											goto IL_08d8_2;
										}
										goto IL_1bc9_2;
										IL_08d8_2:
										array2[num6 - 1] = 3;
										goto IL_08ec_2;
										IL_08ec_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_092b_2;
										IL_092b_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_093e_2:
										if (39 <= b)
										{
											goto IL_094c_2;
										}
										goto IL_1bc9_2;
										IL_094c_2:
										((delegate*<string, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
										num = 367;
										goto IL_097e_2;
										IL_097e_2:
										num6--;
										goto IL_098c_2;
										IL_098c_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_099f_2:
										if (44 >= b)
										{
											goto IL_09ad_2;
										}
										goto IL_0b0b_2;
										IL_09ad_2:
										if (44 <= b)
										{
											goto IL_09b8_2;
										}
										goto IL_0a1f_2;
										IL_09b8_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_09f8_2;
										IL_09f8_2:
										array2[num6 - 2] = 3;
										goto IL_0a0c_2;
										IL_0a0c_2:
										num6--;
										goto IL_1bdc_2;
										IL_0a1f_2:
										if (42 < b)
										{
											goto IL_0a2a_2;
										}
										goto IL_0a90_2;
										IL_0a2a_2:
										if (43 >= b)
										{
											goto IL_0a38_2;
										}
										goto IL_1bc9_2;
										IL_0a38_2:
										if (43 <= b)
										{
											goto IL_0a46_2;
										}
										goto IL_1bc9_2;
										IL_0a46_2:
										((delegate*<Color, void>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
										goto IL_0a6f_2;
										IL_0a6f_2:
										num6--;
										goto IL_0a7d_2;
										IL_0a7d_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0a90_2:
										if (42 <= b)
										{
											num = 86;
											goto IL_0aa7_2;
										}
										goto IL_1bc9_2;
										IL_1ab7_2:
										if (21 <= b)
										{
											goto IL_1ac5_2;
										}
										goto IL_1bc9_2;
										IL_0aa7_2:
										array3[num6 - 1] = ((delegate*<ColorOption, Color>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
										goto IL_0ae4_2;
										IL_0ae4_2:
										array2[num6 - 1] = 4;
										goto IL_0af8_2;
										IL_0af8_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0b0b_2:
										if (45 >= b)
										{
											goto IL_0b16_2;
										}
										goto IL_0b40_2;
										IL_0b16_2:
										if (45 <= b)
										{
											goto IL_0b24_2;
										}
										goto IL_1bc9_2;
										IL_0b24_2:
										num7 = ptr2;
										num8 = -200;
										num5 = 1;
										ptr2 = num7 + num8;
										goto IL_1bdc_2;
										IL_0b40_2:
										if (46 >= b)
										{
											goto IL_0b4e_2;
										}
										goto IL_1bc9_2;
										IL_0b4e_2:
										if (46 <= b)
										{
											num = 325;
										}
										goto IL_1bc9_2;
										IL_1ac5_2:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_1bdc_2;
										IL_0b6a_2:
										if (35 > b)
										{
											goto IL_0b78_2;
										}
										num = 279;
										goto IL_10d1_2;
										IL_0b78_2:
										if (29 >= b)
										{
											goto IL_0b86_2;
										}
										goto IL_0e10_2;
										IL_0b86_2:
										if (29 <= b)
										{
											goto IL_0b91_2;
										}
										goto IL_0bf7_2;
										IL_0b91_2:
										array2[num6 - 1] = 3;
										goto IL_0ba5_2;
										IL_0ba5_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_0be4_2;
										IL_0be4_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0bf7_2:
										if (26 >= b)
										{
											goto IL_0c05_2;
										}
										goto IL_0d55_2;
										IL_0c05_2:
										if (26 > b)
										{
											goto IL_0c13_2;
										}
										goto IL_0cf1_2;
										IL_0c13_2:
										if (24 >= b)
										{
											goto IL_0c1e_2;
										}
										goto IL_0c82_2;
										IL_0c1e_2:
										if (24 <= b)
										{
											goto IL_0c2c_2;
										}
										goto IL_1bc9_2;
										IL_0c2c_2:
										array3[num6] = ((delegate*<ColorOption[]>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
										goto IL_0c4a_2;
										IL_0c4a_2:
										array2[num6] = 5;
										goto IL_0c58_2;
										IL_0c58_2:
										num6++;
										num = 188;
										goto IL_0c6f_2;
										IL_0c6f_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0c82_2:
										if (25 >= b)
										{
											goto IL_0c90_2;
										}
										goto IL_1bc9_2;
										IL_0c90_2:
										if (25 <= b)
										{
											goto IL_0c9e_2;
										}
										goto IL_1bc9_2;
										IL_0c9e_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
										goto IL_0cc2_2;
										IL_0cc2_2:
										array2[num6] = 0;
										goto IL_0cd0_2;
										IL_0cd0_2:
										num6++;
										goto IL_0cde_2;
										IL_0cde_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0cf1_2:
										array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
										goto IL_0d2e_2;
										IL_0d2e_2:
										array2[num6 - 2] = 4;
										goto IL_0d42_2;
										IL_0d42_2:
										num6--;
										goto IL_1bdc_2;
										IL_0d55_2:
										if (27 >= b)
										{
											goto IL_0d60_2;
										}
										goto IL_0d9a_2;
										IL_0d60_2:
										if (27 <= b)
										{
											goto IL_0d6e_2;
										}
										goto IL_1bc9_2;
										IL_0d6e_2:
										global::_003CModule_003E.colorOption_2 = (ColorOption)array3[num6 - 1];
										goto IL_0d87_2;
										IL_0d87_2:
										num6--;
										goto IL_1bdc_2;
										IL_0d9a_2:
										if (28 >= b)
										{
											goto IL_0da8_2;
										}
										goto IL_1bc9_2;
										IL_0da8_2:
										if (28 <= b)
										{
											goto IL_0db6_2;
										}
										goto IL_1bc9_2;
										IL_0db6_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
										goto IL_0dcf_2;
										IL_0dcf_2:
										array2[num6] = 3;
										goto IL_0ddd_2;
										IL_0ddd_2:
										num6++;
										num = 206;
										goto IL_0df4_2;
										IL_0df4_2:
										ptr2 += 16;
										num = 294;
										goto IL_1bdc_2;
										IL_0e10_2:
										if (32 >= b)
										{
											num = 170;
											goto IL_0e27_2;
										}
										goto IL_0f92_2;
										IL_1aeb_2:
										if (22 <= b)
										{
											goto IL_1af9_2;
										}
										goto IL_1bc9_2;
										IL_0e27_2:
										if (32 <= b)
										{
											goto IL_0e32_2;
										}
										goto IL_0e84_2;
										IL_0e32_2:
										array3[num6] = ((delegate*<ColorOption>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])();
										goto IL_0e55_2;
										IL_0e55_2:
										array2[num6] = 4;
										goto IL_0e63_2;
										IL_0e63_2:
										num6++;
										goto IL_0e71_2;
										IL_0e71_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_0e84_2:
										if (30 < b)
										{
											goto IL_0e92_2;
										}
										num = 289;
										goto IL_0f1d_2;
										IL_0e92_2:
										if (31 >= b)
										{
											goto IL_0ea0_2;
										}
										goto IL_1bc9_2;
										IL_0ea0_2:
										if (31 <= b)
										{
											goto IL_0eae_2;
										}
										goto IL_1bc9_2;
										IL_0eae_2:
										array2[num6 - 1] = 0;
										goto IL_0ec2_2;
										IL_0ec2_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_0f01_2;
										IL_0f01_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_1af9_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
										goto IL_1b3a_2;
										IL_0f1d_2:
										if (30 <= b)
										{
											goto IL_0f2b_2;
										}
										goto IL_1bc9_2;
										IL_0f2b_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_0f6b_2;
										IL_0f6b_2:
										array2[num6 - 2] = 3;
										goto IL_0f7f_2;
										IL_0f7f_2:
										num6--;
										goto IL_1bdc_2;
										IL_0f92_2:
										if (33 >= b)
										{
											goto IL_0f9d_2;
										}
										goto IL_1013_2;
										IL_0f9d_2:
										if (33 <= b)
										{
											num = 351;
											goto IL_0fb4_2;
										}
										goto IL_1bc9_2;
										IL_1b3a_2:
										array2[num6 - 2] = 0;
										goto IL_1b4e_2;
										IL_0fb4_2:
										array3[num6 - 1] = ((delegate*<ColorOption, string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
										goto IL_0fec_2;
										IL_0fec_2:
										array2[num6 - 1] = 5;
										goto IL_1000_2;
										IL_1000_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_1013_2:
										if (34 >= b)
										{
											num = 99;
											goto IL_102a_2;
										}
										goto IL_1bc9_2;
										IL_1b4e_2:
										num6--;
										goto IL_1bdc_2;
										IL_102a_2:
										if (34 <= b)
										{
											goto IL_1038_2;
										}
										goto IL_1bc9_2;
										IL_1038_2:
										array2[num6 - 2] = 0;
										num = 190;
										goto IL_1055_2;
										IL_1055_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
										goto IL_10a7_2;
										IL_10a7_2:
										num6--;
										goto IL_10b5_2;
										IL_10b5_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_1add_2:
										if (22 >= b)
										{
											goto IL_1aeb_2;
										}
										goto IL_1bc9_2;
										IL_10d1_2:
										array2[num6 - 1] = 3;
										goto IL_10e5_2;
										IL_10e5_2:
										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_1124_2;
										IL_1124_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_1137_2:
										if (23 > b)
										{
											goto IL_1145_2;
										}
										goto IL_1b5e_2;
										IL_1145_2:
										if (11 >= b)
										{
											goto IL_1153_2;
										}
										goto IL_165b_2;
										IL_1153_2:
										if (11 <= b)
										{
											goto IL_115e_2;
										}
										goto IL_11c4_2;
										IL_115e_2:
										array2[num6 - 1] = 0;
										goto IL_1172_2;
										IL_1172_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
										goto IL_11b1_2;
										IL_11b1_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_11c4_2:
										if (5 < b)
										{
											goto IL_11d2_2;
										}
										num = 324;
										goto IL_1421_2;
										IL_11d2_2:
										if (8 < b)
										{
											goto IL_11e0_2;
										}
										goto IL_12f4_2;
										IL_11e0_2:
										if (9 < b)
										{
											goto IL_11ee_2;
										}
										goto IL_127f_2;
										IL_11ee_2:
										if (10 >= b)
										{
											goto IL_11fc_2;
										}
										goto IL_1bc9_2;
										IL_11fc_2:
										if (10 <= b)
										{
											goto IL_120a_2;
										}
										goto IL_1bc9_2;
										IL_120a_2:
										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
										goto IL_126c_2;
										IL_126c_2:
										num6 -= 2;
										goto IL_1bdc_2;
										IL_127f_2:
										if (9 <= b)
										{
											goto IL_128d_2;
										}
										goto IL_1bc9_2;
										IL_128d_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_12cd_2;
										IL_12cd_2:
										array2[num6 - 2] = 0;
										goto IL_12e1_2;
										IL_12e1_2:
										num6--;
										goto IL_1bdc_2;
										IL_12f4_2:
										if (8 > b)
										{
											goto IL_1302_2;
										}
										goto IL_1405_2;
										IL_1302_2:
										if (6 >= b)
										{
											goto IL_130d_2;
										}
										goto IL_1382_2;
										IL_130d_2:
										if (6 <= b)
										{
											goto IL_131b_2;
										}
										goto IL_1bc9_2;
										IL_131b_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_135b_2;
										IL_135b_2:
										array2[num6 - 2] = 0;
										goto IL_136f_2;
										IL_136f_2:
										num6--;
										goto IL_1bdc_2;
										IL_1382_2:
										if (7 >= b)
										{
											goto IL_1390_2;
										}
										goto IL_1bc9_2;
										IL_1390_2:
										if (7 <= b)
										{
											goto IL_139e_2;
										}
										goto IL_1bc9_2;
										IL_139e_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_13de_2;
										IL_13de_2:
										array2[num6 - 2] = 0;
										goto IL_13f2_2;
										IL_13f2_2:
										num6--;
										goto IL_1bdc_2;
										IL_1405_2:
										num6--;
										goto IL_1bdc_2;
										IL_1b5e_2:
										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
										num = 126;
										goto IL_1bb9_2;
										IL_1421_2:
										if (5 <= b)
										{
											goto IL_142c_2;
										}
										goto IL_1493_2;
										IL_142c_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_146c_2;
										IL_146c_2:
										array2[num6 - 2] = 0;
										goto IL_1480_2;
										IL_1480_2:
										num6--;
										goto IL_1bdc_2;
										IL_1493_2:
										if (2 >= b)
										{
											goto IL_14a1_2;
										}
										goto IL_1577_2;
										IL_14a1_2:
										if (2 > b)
										{
											goto IL_14ac_2;
										}
										goto IL_1510_2;
										IL_14ac_2:
										if (1 >= b)
										{
											goto IL_14ba_2;
										}
										goto IL_1bc9_2;
										IL_14ba_2:
										if (1 <= b)
										{
											goto IL_14c8_2;
										}
										goto IL_1bc9_2;
										IL_14c8_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
										goto IL_14e1_2;
										IL_14e1_2:
										array2[num6] = 0;
										goto IL_14ef_2;
										IL_14ef_2:
										num6++;
										goto IL_14fd_2;
										IL_14fd_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_1510_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_1550_2;
										IL_1550_2:
										array2[num6 - 2] = 0;
										goto IL_1564_2;
										IL_1564_2:
										num6--;
										goto IL_1bdc_2;
										IL_1577_2:
										if (3 >= b)
										{
											num = 47;
											goto IL_158b_2;
										}
										goto IL_15e3_2;
										IL_1bb9_2:
										num6--;
										goto IL_1bdc_2;
										IL_158b_2:
										if (3 <= b)
										{
											goto IL_1599_2;
										}
										goto IL_1bc9_2;
										IL_1599_2:
										reference = ref array5[*(int*)(ptr2 + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										goto IL_15c2_2;
										IL_15c2_2:
										ptr2 += 8;
										goto IL_15d0_2;
										IL_15d0_2:
										num6--;
										goto IL_1bdc_2;
										IL_15e3_2:
										if (4 >= b)
										{
											goto IL_15f1_2;
										}
										goto IL_1bc9_2;
										IL_15f1_2:
										if (4 <= b)
										{
											goto IL_15ff_2;
										}
										goto IL_1bc9_2;
										IL_15ff_2:
										array2[num6] = 0;
										goto IL_160d_2;
										IL_160d_2:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
										goto IL_1630_2;
										IL_1630_2:
										array3[num6] = null;
										goto IL_163a_2;
										IL_163a_2:
										num6++;
										goto IL_1648_2;
										IL_1648_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_165b_2:
										if (17 >= b)
										{
											goto IL_1669_2;
										}
										goto IL_193c_2;
										IL_1669_2:
										if (17 <= b)
										{
											goto IL_1674_2;
										}
										goto IL_16bb_2;
										IL_1674_2:
										array2[num6] = 5;
										goto IL_1682_2;
										IL_1682_2:
										array3[num6] = array7[*(int*)(ptr2 + num3)];
										goto IL_169a_2;
										IL_169a_2:
										num6++;
										goto IL_16a8_2;
										IL_16a8_2:
										ptr2 += 8;
										goto IL_1bdc_2;
										IL_16bb_2:
										if (14 >= b)
										{
											goto IL_16c9_2;
										}
										goto IL_182e_2;
										IL_16c9_2:
										if (14 <= b)
										{
											goto IL_16d4_2;
										}
										goto IL_171c_2;
										IL_16d4_2:
										array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
										num = 51;
										goto IL_16fb_2;
										IL_16fb_2:
										ptr2 += 8;
										goto IL_1709_2;
										IL_1709_2:
										num6--;
										goto IL_1bdc_2;
										IL_171c_2:
										if (12 >= b)
										{
											goto IL_1727_2;
										}
										goto IL_173a_2;
										IL_1727_2:
										if (12 <= b)
										{
											goto IL_1bdc_2;
										}
										goto IL_1bc9_2;
										IL_173a_2:
										if (13 >= b)
										{
											goto IL_1748_2;
										}
										goto IL_1bc9_2;
										IL_1748_2:
										if (13 <= b)
										{
											goto end_IL_063f;
										}
										goto IL_1bc9_2;
										IL_182e_2:
										if (15 >= b)
										{
											goto IL_1839_2;
										}
										goto IL_1892_2;
										IL_1839_2:
										if (15 <= b)
										{
											goto IL_1847_2;
										}
										goto IL_1bc9_2;
										IL_1847_2:
										array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
										num = 9;
										goto IL_1879_2;
										IL_1879_2:
										array2[num6 - 1] = 5;
										goto IL_1bdc_2;
										IL_1892_2:
										if (16 >= b)
										{
											goto IL_18a0_2;
										}
										goto IL_1bc9_2;
										IL_18a0_2:
										if (16 <= b)
										{
											goto IL_18ae_2;
										}
										goto IL_1bc9_2;
										IL_18ae_2:
										array2[num6] = array2[num6 - 1];
										goto IL_18c6_2;
										IL_18c6_2:
										array4[num6 - 0] = array4[num6 - 1];
										goto IL_18e4_2;
										IL_18e4_2:
										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
										num = 292;
										goto IL_1911_2;
										IL_1911_2:
										array3[num6] = array3[num6 - 1];
										goto IL_1929_2;
										IL_1929_2:
										num6++;
										goto IL_1bdc_2;
										IL_193c_2:
										if (20 >= b)
										{
											goto IL_194a_2;
										}
										goto IL_1aac_2;
										IL_194a_2:
										if (20 > b)
										{
											goto IL_1958_2;
										}
										goto IL_1a5b_2;
										IL_1958_2:
										if (18 < b)
										{
											goto IL_1966_2;
										}
										goto IL_19f3_2;
										IL_1966_2:
										if (19 >= b)
										{
											goto IL_1974_2;
										}
										goto IL_1bc9_2;
										IL_1974_2:
										if (19 <= b)
										{
											num = 278;
											goto IL_198b_2;
										}
										goto IL_1bc9_2;
										IL_1bc9_2:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_1bdc_2;
										IL_198b_2:
										array2[num6 - 1] = 5;
										goto IL_199f_2;
										IL_199f_2:
										array3[num6 - 1] = ((delegate*<string[], string>)InitOnlyCancelFullGCNotification[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
										goto IL_19d7_2;
										IL_19d7_2:
										ptr2 += 8;
										num = 228;
										goto IL_1bdc_2;
										IL_19f3_2:
										if (18 <= b)
										{
											goto IL_1a01_2;
										}
										goto IL_1bc9_2;
										IL_1a01_2:
										((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
										num = 163;
										goto IL_1a48_2;
										IL_1a48_2:
										num6 -= 3;
										goto IL_1bdc_2;
										IL_1a5b_2:
										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
										goto IL_1a74_2;
										continue;
										end_IL_062f:
										break;
									}
									continue;
									end_IL_063f:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_1765_2;
					}
					continue;
					end_IL_1773:
					break;
				}
				break;
			}
		}
	}

	public unsafe static void smethod_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_061d, IL_0630, IL_0643, IL_0653, IL_0663, IL_0673, IL_0680, IL_0690, IL_06a0, IL_06b0, IL_06c4, IL_06cf, IL_06dd, IL_06eb, IL_0730, IL_073e, IL_074c, IL_0757, IL_076a, IL_0775, IL_07ba, IL_07c5, IL_07d3, IL_07e1, IL_07f4, IL_07ff, IL_0812, IL_0820, IL_0833, IL_0841, IL_084c, IL_085a, IL_086d, IL_0881, IL_0894, IL_08d7, IL_08e5, IL_08f3, IL_0906, IL_091f, IL_092d, IL_093b, IL_0958, IL_09a7, IL_09b1, IL_09de, IL_09f2, IL_0a00, IL_0a13, IL_0a21, IL_0a2f, IL_0a38, IL_0a5b, IL_0a69, IL_0a82, IL_0a90, IL_0a9e, IL_0ab1, IL_0abc, IL_0ad5, IL_0ae8, IL_0af6, IL_0b1b, IL_0b3d, IL_0b4b, IL_0b62, IL_0b7e, IL_0b91, IL_0ba4, IL_0bb2, IL_0bc5, IL_0bd3, IL_0bde, IL_0bf6, IL_0c01, IL_0c0f, IL_0c1d, IL_0c3b, IL_0c44, IL_0c57, IL_0c62, IL_0c75, IL_0c85, IL_0cce, IL_0ce2, IL_0cf5, IL_0d03, IL_0d55, IL_0d68, IL_0dba, IL_0dcd, IL_0de0, IL_0e09, IL_0e22, IL_0e30, IL_0e3e, IL_0e4c, IL_0e5a, IL_0e9a, IL_0eae, IL_0ec1, IL_0eca, IL_0ed8, IL_0f18, IL_0f2c, IL_0f3f, IL_0f5b, IL_0f69, IL_0fa6, IL_0fba, IL_0ff9, IL_1015, IL_1020, IL_102e, IL_106e, IL_1087, IL_1095, IL_10a3, IL_1105, IL_1118, IL_112b, IL_113e, IL_1152, IL_118a, IL_119d, IL_11b1, IL_11cd, IL_11db, IL_11e9, IL_1201, IL_121f, IL_124c, IL_1264, IL_1277, IL_1285, IL_1293, IL_12a1, IL_12ac, IL_12ba, IL_12f7, IL_130b, IL_1327, IL_1335, IL_1343, IL_135c, IL_136f, IL_1386, IL_1394, IL_13a7, IL_13b5, IL_13cd, IL_13db, IL_13ee, IL_140a, IL_1418, IL_142b, IL_144e, IL_145c, IL_146a, IL_147d, IL_14a6, IL_14b4, IL_14c7, IL_1508, IL_151c, IL_152f, IL_153a, IL_155e, IL_156c, IL_157a, IL_158d, IL_1598, IL_15a6, IL_15b4, IL_15d2, IL_15e0, IL_15ee, IL_1601, IL_160f, IL_1623, IL_1662, IL_1675, IL_1689, IL_16d5, IL_16e3, IL_16f6, IL_1704, IL_1712, IL_1720, IL_172e, IL_173c, IL_174a, IL_1758, IL_1798, IL_17ac, IL_17bf, IL_17c8, IL_17d6, IL_17ff, IL_180d, IL_1820, IL_185d, IL_1871, IL_1884, IL_188f, IL_189d, IL_18c6, IL_18d4, IL_18e7, IL_18f5, IL_1903, IL_1917, IL_1956, IL_1969, IL_19a9, IL_19bd, IL_19d0, IL_19de, IL_19e9, IL_19fd, IL_1a3c, IL_1a4f, IL_1a5a, IL_1a68, IL_1a92, IL_1aa0, IL_1ab3, IL_1ac1, IL_1acf, IL_1aec, IL_1b2b, IL_1b3b, IL_1b46, IL_1b51, IL_1b6a, IL_1b75, IL_1b80, IL_1b93, IL_1ba6, IL_1bb0, IL_1bbb, IL_1bcb, IL_1bdb, IL_1beb, IL_1bfb, IL_1c0b, IL_1c1b, IL_1c2b, IL_1c3b are reachable both inside and outside the pinned region starting at IL_1c50. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 291;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef52 = default(int);
			ref int reference = ref __rxRef52;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1c3b:
					num2 = 1;
					while (true)
					{
						IL_1c2b:
						num3 = num2 * 4;
						while (true)
						{
							IL_1c1b:
							num4 = num2 * 8;
							while (true)
							{
								IL_1c0b:
								array2 = new byte[4];
								while (true)
								{
									IL_1bfb:
									array3 = new object[4];
									while (true)
									{
										IL_1beb:
										array4 = new int[4];
										while (true)
										{
											IL_1bdb:
											array5 = new int[7];
											while (true)
											{
												IL_1bcb:
												array6 = new long[4];
												while (true)
												{
													IL_1bbb:
													array7 = new object[18];
													while (true)
													{
														IL_1bb0:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetStringAndReleaseTrimToSize.GetValueOrDefaultgetOwner);
														while (true)
														{
															IL_1ba6:
															ptr2 = ptr;
															while (true)
															{
																IL_1b93:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_06b0:
																	byte b = *ptr2;
																	num = 334;
																	while (true)
																	{
																		IL_06a0:
																		ptr2++;
																		while (true)
																		{
																			IL_0690:
																			if (b >= 1)
																			{
																				while (b <= 45)
																				{
																					while (true)
																					{
																						IL_0673:
																						if (23 < b)
																						{
																							while (true)
																							{
																								IL_0663:
																								if (34 < b)
																								{
																									goto IL_16f6;
																								}
																								while (true)
																								{
																									IL_0653:
																									if (34 > b)
																									{
																										while (true)
																										{
																											IL_0643:
																											if (28 < b)
																											{
																												while (true)
																												{
																													IL_0630:
																													if (31 >= b)
																													{
																														num = 384;
																														while (true)
																														{
																															if (num != 384)
																															{
																																if (num != 1365)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 291:
																																	break;
																																default:
																																	continue;
																																case 243:
																																	goto IL_0630;
																																case 363:
																																	goto IL_0643;
																																case 42:
																																	goto IL_0653;
																																case 318:
																																	goto IL_0663;
																																case 332:
																																	goto IL_0673;
																																case 248:
																																	goto IL_0680;
																																case 238:
																																	goto IL_0690;
																																case 334:
																																	goto IL_06a0;
																																case 130:
																																case 276:
																																	goto IL_06b0;
																																case 37:
																																	goto IL_06c4;
																																case 75:
																																	goto IL_06dd;
																																case 6:
																																case 124:
																																	goto IL_06eb;
																																case 224:
																																	goto IL_0730;
																																case 31:
																																	goto IL_073e;
																																case 50:
																																	goto IL_074c;
																																case 128:
																																	goto IL_0757;
																																case 29:
																																	goto IL_076a;
																																case 92:
																																case 116:
																																	goto IL_0775;
																																case 199:
																																	goto IL_07ba;
																																case 110:
																																	goto IL_07c5;
																																case 177:
																																	goto IL_07d3;
																																case 74:
																																	goto IL_07e1;
																																case 119:
																																	goto IL_07f4;
																																case 28:
																																	goto IL_07ff;
																																case 168:
																																	goto IL_0812;
																																case 197:
																																	goto IL_0820;
																																case 12:
																																	goto IL_0833;
																																case 206:
																																	goto IL_0841;
																																case 85:
																																	goto IL_084c;
																																case 208:
																																	goto IL_085a;
																																case 246:
																																	goto IL_086d;
																																case 236:
																																	goto IL_0881;
																																case 82:
																																case 274:
																																	goto IL_0894;
																																case 283:
																																	goto IL_08d7;
																																case 152:
																																	goto IL_08e5;
																																case 189:
																																	goto IL_08f3;
																																case 293:
																																	goto IL_0906;
																																case 295:
																																	goto IL_091f;
																																case 230:
																																	goto IL_092d;
																																case 14:
																																case 218:
																																	goto IL_093b;
																																case 201:
																																	goto IL_09f2;
																																case 67:
																																	goto IL_0a00;
																																case 286:
																																	goto IL_0a13;
																																case 166:
																																	goto IL_0a21;
																																case 61:
																																case 207:
																																	goto IL_0a38;
																																case 302:
																																	goto IL_0a5b;
																																case 53:
																																case 277:
																																	goto IL_0a69;
																																case 141:
																																	goto IL_0a82;
																																case 217:
																																	goto IL_0a90;
																																case 105:
																																	goto IL_0a9e;
																																case 306:
																																	goto IL_0ab1;
																																case 139:
																																case 169:
																																	goto IL_0abc;
																																case 196:
																																	goto IL_0ad5;
																																case 9:
																																case 307:
																																	goto IL_0ae8;
																																case 273:
																																	goto IL_0af6;
																																case 83:
																																case 311:
																																	goto IL_0b1b;
																																case 27:
																																	goto IL_0b3d;
																																case 126:
																																	goto IL_0b4b;
																																case 38:
																																	goto IL_0b62;
																																case 314:
																																	goto IL_0b7e;
																																case 315:
																																	goto IL_0b91;
																																case 299:
																																	goto IL_0ba4;
																																case 158:
																																	goto IL_0bb2;
																																case 322:
																																	goto IL_0bc5;
																																case 226:
																																	goto IL_0bd3;
																																case 18:
																																case 112:
																																	goto IL_0bde;
																																case 153:
																																	goto IL_0bf6;
																																case 157:
																																	goto IL_0c01;
																																case 48:
																																	goto IL_0c0f;
																																case 125:
																																case 244:
																																	goto IL_0c1d;
																																case 214:
																																	goto IL_0c44;
																																case 100:
																																	goto IL_0c57;
																																case 118:
																																	goto IL_0c62;
																																case 221:
																																	goto IL_0c75;
																																case 222:
																																case 325:
																																	goto IL_0c85;
																																case 59:
																																	goto IL_0cce;
																																case 76:
																																	goto IL_0ce2;
																																case 326:
																																	goto IL_0cf5;
																																case 134:
																																case 193:
																																	goto IL_0d03;
																																case 288:
																																	goto IL_0d55;
																																case 328:
																																	goto IL_0d68;
																																case 88:
																																	goto IL_0dba;
																																case 329:
																																	goto IL_0dcd;
																																case 120:
																																case 336:
																																	goto IL_0de0;
																																case 149:
																																	goto IL_0e09;
																																case 337:
																																	goto IL_0e22;
																																case 144:
																																	goto IL_0e30;
																																case 255:
																																	goto IL_0e3e;
																																case 52:
																																	goto IL_0e4c;
																																case 4:
																																case 47:
																																	goto IL_0e5a;
																																case 228:
																																	goto IL_0e9a;
																																case 104:
																																	goto IL_0eae;
																																case 167:
																																	goto IL_0eca;
																																case 162:
																																case 303:
																																	goto IL_0ed8;
																																case 186:
																																	goto IL_0f18;
																																case 21:
																																	goto IL_0f2c;
																																case 7:
																																case 215:
																																	goto IL_0f3f;
																																case 345:
																																	goto IL_0f5b;
																																case 90:
																																case 281:
																																	goto IL_0f69;
																																case 333:
																																case 346:
																																	goto IL_0fa6;
																																case 84:
																																	goto IL_0fba;
																																case 13:
																																	goto IL_0ff9;
																																case 347:
																																	goto IL_1015;
																																case 343:
																																	goto IL_1020;
																																case 71:
																																case 312:
																																	goto IL_102e;
																																case 198:
																																	goto IL_106e;
																																case 220:
																																	goto IL_1087;
																																case 278:
																																	goto IL_1095;
																																case 219:
																																case 316:
																																	goto IL_10a3;
																																case 57:
																																	goto IL_1105;
																																case 353:
																																	goto IL_1118;
																																case 354:
																																	goto IL_112b;
																																case 257:
																																case 359:
																																	goto IL_113e;
																																case 308:
																																	goto IL_1152;
																																case 191:
																																	goto IL_118a;
																																case 360:
																																	goto IL_119d;
																																case 122:
																																	goto IL_11b1;
																																case 364:
																																	goto IL_11cd;
																																case 147:
																																	goto IL_11db;
																																case 135:
																																case 240:
																																	goto IL_11e9;
																																case 54:
																																	goto IL_1201;
																																case 280:
																																	goto IL_121f;
																																case 19:
																																	goto IL_124c;
																																case 357:
																																	goto IL_1264;
																																case 43:
																																	goto IL_1277;
																																case 174:
																																	goto IL_1285;
																																case 365:
																																	goto IL_12a1;
																																case 143:
																																	goto IL_12ac;
																																case 25:
																																case 138:
																																	goto IL_12ba;
																																case 8:
																																	goto IL_12f7;
																																case 86:
																																	goto IL_130b;
																																case 249:
																																	goto IL_1327;
																																case 289:
																																	goto IL_1335;
																																case 180:
																																case 340:
																																	goto IL_1343;
																																case 300:
																																	goto IL_135c;
																																case 367:
																																	goto IL_136f;
																																case 356:
																																	goto IL_1386;
																																case 1:
																																	goto IL_1394;
																																case 213:
																																case 369:
																																	goto IL_13a7;
																																case 107:
																																	goto IL_13b5;
																																case 270:
																																	goto IL_13cd;
																																case 179:
																																	goto IL_13db;
																																case 371:
																																	goto IL_13ee;
																																case 372:
																																	goto IL_140a;
																																case 335:
																																	goto IL_1418;
																																case 150:
																																case 373:
																																	goto IL_142b;
																																case 292:
																																	goto IL_144e;
																																case 229:
																																	goto IL_145c;
																																case 136:
																																	goto IL_146a;
																																case 109:
																																case 374:
																																	goto IL_147d;
																																case 319:
																																	goto IL_14a6;
																																case 265:
																																	goto IL_14b4;
																																case 78:
																																case 375:
																																	goto IL_14c7;
																																case 172:
																																	goto IL_1508;
																																case 101:
																																	goto IL_151c;
																																case 70:
																																case 210:
																																	goto IL_153a;
																																case 323:
																																	goto IL_155e;
																																case 56:
																																	goto IL_156c;
																																case 252:
																																	goto IL_157a;
																																case 129:
																																	goto IL_158d;
																																case 117:
																																	goto IL_1598;
																																case 241:
																																	goto IL_15a6;
																																case 46:
																																case 99:
																																	goto IL_15b4;
																																case 331:
																																	goto IL_15d2;
																																case 192:
																																	goto IL_15e0;
																																case 304:
																																	goto IL_15ee;
																																case 344:
																																	goto IL_1601;
																																case 98:
																																case 114:
																																	goto IL_160f;
																																case 194:
																																	goto IL_1623;
																																case 185:
																																	goto IL_1662;
																																case 268:
																																case 287:
																																	goto IL_1675;
																																case 163:
																																	goto IL_1689;
																																case 87:
																																	goto IL_16d5;
																																case 45:
																																	goto IL_16e3;
																																case 362:
																																	goto IL_16f6;
																																case 161:
																																	goto end_IL_061d;
																																case 341:
																																	goto IL_1712;
																																case 102:
																																	goto IL_1720;
																																case 81:
																																	goto IL_172e;
																																case 148:
																																	goto IL_173c;
																																case 259:
																																	goto IL_174a;
																																case 175:
																																case 301:
																																	goto IL_1758;
																																case 181:
																																	goto IL_1798;
																																case 253:
																																	goto IL_17ac;
																																case 227:
																																	goto IL_17c8;
																																case 62:
																																case 251:
																																	goto IL_17d6;
																																case 212:
																																	goto IL_17ff;
																																case 355:
																																	goto IL_180d;
																																case 79:
																																case 361:
																																	goto IL_1820;
																																case 305:
																																	goto IL_185d;
																																case 159:
																																	goto IL_1871;
																																case 205:
																																	goto IL_1884;
																																case 327:
																																	goto IL_188f;
																																case 216:
																																case 264:
																																	goto IL_189d;
																																case 131:
																																	goto IL_18c6;
																																case 348:
																																	goto IL_18d4;
																																case 68:
																																	goto IL_18e7;
																																case 204:
																																	goto IL_18f5;
																																case 151:
																																case 254:
																																	goto IL_1903;
																																case 36:
																																	goto IL_1917;
																																case 262:
																																	goto IL_1956;
																																case 44:
																																case 111:
																																	goto IL_1969;
																																case 66:
																																	goto IL_19a9;
																																case 16:
																																	goto IL_19bd;
																																case 80:
																																	goto IL_19d0;
																																case 234:
																																	goto IL_19de;
																																case 173:
																																case 176:
																																	goto IL_19e9;
																																case 178:
																																	goto IL_19fd;
																																case 41:
																																	goto IL_1a3c;
																																case 285:
																																	goto IL_1a4f;
																																case 133:
																																	goto IL_1a5a;
																																case 24:
																																case 320:
																																	goto IL_1a68;
																																case 317:
																																	goto IL_1a92;
																																case 223:
																																	goto IL_1aa0;
																																case 263:
																																	goto IL_1ab3;
																																case 358:
																																	goto IL_1ac1;
																																case 231:
																																case 237:
																																	goto IL_1acf;
																																case 242:
																																	goto IL_1aec;
																																case 377:
																																	goto IL_1b2b;
																																case 342:
																																	goto IL_1b3b;
																																case 339:
																																	goto IL_1b46;
																																case 10:
																																case 297:
																																	goto IL_1b51;
																																case 310:
																																	goto IL_1b6a;
																																case 321:
																																	goto IL_1b75;
																																case 0:
																																case 3:
																																case 15:
																																case 20:
																																case 23:
																																case 26:
																																case 33:
																																case 34:
																																case 35:
																																case 51:
																																case 58:
																																case 60:
																																case 63:
																																case 65:
																																case 89:
																																case 91:
																																case 94:
																																case 96:
																																case 97:
																																case 103:
																																case 106:
																																case 115:
																																case 121:
																																case 127:
																																case 132:
																																case 137:
																																case 140:
																																case 146:
																																case 154:
																																case 156:
																																case 164:
																																case 165:
																																case 171:
																																case 195:
																																case 235:
																																case 239:
																																case 258:
																																case 269:
																																case 272:
																																case 294:
																																case 298:
																																case 309:
																																case 330:
																																case 338:
																																case 352:
																																case 366:
																																case 368:
																																case 376:
																																	goto end_IL_0680;
																																case 5:
																																case 11:
																																case 17:
																																case 22:
																																case 30:
																																case 39:
																																case 40:
																																case 49:
																																case 55:
																																case 64:
																																case 69:
																																case 72:
																																case 73:
																																case 77:
																																case 93:
																																case 95:
																																case 108:
																																case 113:
																																case 142:
																																case 145:
																																case 155:
																																case 160:
																																case 170:
																																case 183:
																																case 187:
																																case 190:
																																case 200:
																																case 202:
																																case 203:
																																case 209:
																																case 211:
																																case 232:
																																case 233:
																																case 245:
																																case 260:
																																case 266:
																																case 267:
																																case 271:
																																case 275:
																																case 279:
																																case 282:
																																case 284:
																																case 296:
																																case 313:
																																case 349:
																																case 350:
																																case 351:
																																case 370:
																																	goto IL_1b93;
																																case 225:
																																	goto IL_1ba6;
																																case 123:
																																	goto IL_1bb0;
																																case 188:
																																	goto IL_1bbb;
																																case 247:
																																	goto IL_1bcb;
																																case 256:
																																	goto IL_1bdb;
																																case 182:
																																	goto IL_1beb;
																																case 2:
																																	goto IL_1bfb;
																																case 261:
																																	goto IL_1c0b;
																																case 250:
																																	goto IL_1c1b;
																																case 184:
																																	goto IL_1c2b;
																																case 290:
																																	goto IL_1c3b;
																																case 32:
																																case 324:
																																	return;
																																}
																																goto end_IL_0663;
																															}
																															if (31 <= b)
																															{
																																goto IL_153a;
																															}
																															goto IL_158d;
																															IL_160f:
																															array2[num6 - 1] = 0;
																															goto IL_1623;
																															IL_1662:
																															ptr2 += 8;
																															goto IL_1b93;
																															IL_1623:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																															goto IL_1662;
																															IL_153a:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
																															goto IL_155e;
																															IL_155e:
																															array2[num6] = 0;
																															goto IL_156c;
																															IL_156c:
																															num6++;
																															goto IL_157a;
																															IL_157a:
																															ptr2 += 8;
																															goto IL_1b93;
																															IL_158d:
																															if (29 < b)
																															{
																																goto IL_1598;
																															}
																															goto IL_1601;
																															IL_1598:
																															if (30 < b)
																															{
																																goto end_IL_0680;
																															}
																															goto IL_15a6;
																															IL_15a6:
																															if (30 > b)
																															{
																																goto end_IL_0680;
																															}
																															goto IL_15b4;
																															IL_15b4:
																															array3[num6] = ((delegate*<ColorOption[]>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
																															goto IL_15d2;
																															IL_15d2:
																															array2[num6] = 5;
																															goto IL_15e0;
																															IL_15e0:
																															num6++;
																															goto IL_15ee;
																															IL_15ee:
																															ptr2 += 8;
																															goto IL_1b93;
																															IL_1601:
																															if (29 > b)
																															{
																																goto end_IL_0680;
																															}
																															goto IL_160f;
																															continue;
																															end_IL_061d:
																															break;
																														}
																														break;
																													}
																													goto IL_12a1;
																													IL_1343:
																													global::_003CModule_003E.colorOption_3 = (ColorOption)array3[num6 - 1];
																													goto IL_135c;
																													IL_135c:
																													num6--;
																													goto IL_1b93;
																													IL_12a1:
																													if (32 >= b)
																													{
																														goto IL_12ac;
																													}
																													goto IL_1327;
																													IL_12ac:
																													if (32 > b)
																													{
																														goto end_IL_0680;
																													}
																													goto IL_12ba;
																													IL_12ba:
																													array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													goto IL_12f7;
																													IL_12f7:
																													array2[num6 - 2] = 4;
																													goto IL_130b;
																													IL_130b:
																													num6--;
																													num = 232;
																													goto IL_1b93;
																													IL_1327:
																													if (33 < b)
																													{
																														goto end_IL_0680;
																													}
																													goto IL_1335;
																													IL_1335:
																													if (33 > b)
																													{
																														goto end_IL_0680;
																													}
																													goto IL_1343;
																												}
																												break;
																											}
																											goto IL_06dd;
																											IL_11b1:
																											ptr2 += 8;
																											num = 72;
																											goto IL_1b93;
																											IL_06dd:
																											if (28 <= b)
																											{
																												goto IL_06eb;
																											}
																											goto IL_08d7;
																											IL_06eb:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_086d;
																											IL_086d:
																											array2[num6 - 2] = 3;
																											goto IL_0881;
																											IL_0881:
																											num6--;
																											goto IL_1b93;
																											IL_08d7:
																											if (25 < b)
																											{
																												goto IL_08e5;
																											}
																											goto IL_0ab1;
																											IL_08e5:
																											if (26 < b)
																											{
																												goto IL_08f3;
																											}
																											goto IL_0a5b;
																											IL_08f3:
																											if (27 < b)
																											{
																												goto end_IL_0680;
																											}
																											goto IL_0b7e;
																											IL_0b7e:
																											if (27 > b)
																											{
																												goto end_IL_0680;
																											}
																											goto IL_0fa6;
																											IL_0fa6:
																											array2[num6 - 1] = 3;
																											goto IL_0fba;
																											IL_0fba:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0ff9;
																											IL_0ff9:
																											ptr2 += 8;
																											num = 77;
																											goto IL_1b93;
																											IL_0a5b:
																											if (26 > b)
																											{
																												goto end_IL_0680;
																											}
																											goto IL_0a69;
																											IL_0a69:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																											goto IL_0a82;
																											IL_0a82:
																											array2[num6] = 3;
																											goto IL_0a90;
																											IL_0a90:
																											num6++;
																											goto IL_0a9e;
																											IL_0a9e:
																											ptr2 += 16;
																											goto IL_1b93;
																											IL_0ab1:
																											if (25 <= b)
																											{
																												goto IL_0abc;
																											}
																											goto IL_0ad5;
																											IL_0abc:
																											array2[num6 - 2] = 0;
																											goto IL_0d68;
																											IL_0d68:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																											goto IL_0dba;
																											IL_0dba:
																											num6--;
																											goto IL_13ee;
																											IL_13ee:
																											ptr2 += 8;
																											num = 284;
																											goto IL_1b93;
																											IL_0ad5:
																											if (24 < b)
																											{
																												goto end_IL_0680;
																											}
																											goto IL_0f5b;
																											IL_0f5b:
																											if (24 > b)
																											{
																												goto end_IL_0680;
																											}
																											goto IL_0f69;
																											IL_0f69:
																											array3[num6 - 1] = ((delegate*<ColorOption, string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																											goto IL_119d;
																											IL_119d:
																											array2[num6 - 1] = 5;
																											goto IL_11b1;
																										}
																										break;
																									}
																									goto IL_1675;
																									IL_16e3:
																									ptr2 += 8;
																									goto IL_1b93;
																									IL_1675:
																									array2[num6 - 2] = 5;
																									goto IL_1689;
																									IL_1689:
																									array3[num6 - 2] = ((delegate*<string, string, string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																									goto IL_16d5;
																									IL_16d5:
																									num6--;
																									goto IL_16e3;
																								}
																								goto IL_1704;
																								IL_1b6a:
																								if (45 < b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1b75;
																								IL_16f6:
																								if (40 >= b)
																								{
																									goto IL_1704;
																								}
																								goto IL_19d0;
																								IL_1704:
																								if (40 > b)
																								{
																									goto IL_1712;
																								}
																								goto IL_1969;
																								IL_1712:
																								if (37 >= b)
																								{
																									goto IL_1720;
																								}
																								goto IL_1884;
																								IL_1720:
																								if (37 > b)
																								{
																									goto IL_172e;
																								}
																								goto IL_1820;
																								IL_172e:
																								if (35 < b)
																								{
																									goto IL_173c;
																								}
																								num = 227;
																								goto IL_17c8;
																								IL_173c:
																								if (36 < b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_174a;
																								IL_174a:
																								if (36 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1758;
																								IL_1758:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1798;
																								IL_1798:
																								array2[num6 - 2] = 3;
																								goto IL_17ac;
																								IL_17ac:
																								num6--;
																								goto IL_1b93;
																								IL_1b75:
																								if (45 <= b)
																								{
																								}
																								goto end_IL_0680;
																								IL_17c8:
																								if (35 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_17d6;
																								IL_17d6:
																								((delegate*<string, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_17ff;
																								IL_17ff:
																								num6--;
																								goto IL_180d;
																								IL_180d:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1820:
																								array3[num6 - 1] = ((delegate*<ColorOption, Color>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																								goto IL_185d;
																								IL_185d:
																								array2[num6 - 1] = 4;
																								goto IL_1871;
																								IL_1871:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1884:
																								if (38 >= b)
																								{
																									goto IL_188f;
																								}
																								goto IL_18e7;
																								IL_188f:
																								if (38 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_189d;
																								IL_189d:
																								((delegate*<Color, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																								goto IL_18c6;
																								IL_18c6:
																								num6--;
																								goto IL_18d4;
																								IL_18d4:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_18e7:
																								if (39 < b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_18f5;
																								IL_18f5:
																								if (39 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1903;
																								IL_1903:
																								array2[num6 - 1] = 3;
																								goto IL_1917;
																								IL_1917:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1956;
																								IL_1956:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1969:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_19a9;
																								IL_19a9:
																								array2[num6 - 2] = 3;
																								goto IL_19bd;
																								IL_19bd:
																								num6--;
																								goto IL_1b93;
																								IL_19d0:
																								if (43 >= b)
																								{
																									goto IL_19de;
																								}
																								goto IL_1b3b;
																								IL_19de:
																								if (43 <= b)
																								{
																									goto IL_19e9;
																								}
																								goto IL_1a4f;
																								IL_19e9:
																								array2[num6 - 1] = 3;
																								goto IL_19fd;
																								IL_19fd:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1a3c;
																								IL_1a3c:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1a4f:
																								if (41 >= b)
																								{
																									goto IL_1a5a;
																								}
																								goto IL_1ab3;
																								IL_1a5a:
																								if (41 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1a68;
																								IL_1a68:
																								((delegate*<bool, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																								goto IL_1a92;
																								IL_1a92:
																								num6--;
																								goto IL_1aa0;
																								IL_1aa0:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1ab3:
																								if (42 < b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1ac1;
																								IL_1ac1:
																								if (42 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1acf;
																								IL_1acf:
																								array2[num6 - 1] = 3;
																								num = 242;
																								goto IL_1aec;
																								IL_1aec:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1b2b;
																								IL_1b2b:
																								ptr2 += 8;
																								goto IL_1b93;
																								IL_1b3b:
																								if (44 >= b)
																								{
																									goto IL_1b46;
																								}
																								goto IL_1b6a;
																								IL_1b46:
																								if (44 > b)
																								{
																									goto end_IL_0680;
																								}
																								goto IL_1b51;
																								IL_1b51:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								goto IL_1b93;
																								continue;
																								end_IL_0663:
																								break;
																							}
																							break;
																						}
																						goto IL_06c4;
																						IL_0c57:
																						if (21 >= b)
																						{
																							goto IL_0c62;
																						}
																						goto IL_0c75;
																						IL_06c4:
																						if (23 > b)
																						{
																							goto IL_0730;
																						}
																						num = 373;
																						goto IL_142b;
																						IL_0c62:
																						if (21 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_14c7;
																						IL_142b:
																						array3[num6] = ((delegate*<ColorOption>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
																						goto IL_144e;
																						IL_144e:
																						array2[num6] = 4;
																						goto IL_145c;
																						IL_145c:
																						num6++;
																						goto IL_146a;
																						IL_146a:
																						ptr2 += 8;
																						goto IL_1b93;
																						IL_0730:
																						if (11 >= b)
																						{
																							goto IL_073e;
																						}
																						goto IL_0833;
																						IL_073e:
																						if (11 <= b)
																						{
																							goto IL_1b93;
																						}
																						goto IL_074c;
																						IL_074c:
																						if (5 < b)
																						{
																							goto IL_0757;
																						}
																						goto IL_076a;
																						IL_0757:
																						if (8 >= b)
																						{
																							goto IL_0e22;
																						}
																						goto IL_1015;
																						IL_0e22:
																						if (8 > b)
																						{
																							goto IL_0e30;
																						}
																						goto IL_0f3f;
																						IL_0e30:
																						if (6 < b)
																						{
																							goto IL_0e3e;
																						}
																						num = 167;
																						goto IL_0eca;
																						IL_0e3e:
																						if (7 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0e4c;
																						IL_0e4c:
																						if (7 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0e5a;
																						IL_0e5a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0e9a;
																						IL_0e9a:
																						array2[num6 - 2] = 0;
																						goto IL_0eae;
																						IL_0eae:
																						num6--;
																						goto IL_1b93;
																						IL_14c7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_1508;
																						IL_0eca:
																						if (6 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0ed8;
																						IL_0ed8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0f18;
																						IL_0f18:
																						array2[num6 - 2] = 0;
																						goto IL_0f2c;
																						IL_0f2c:
																						num6--;
																						goto IL_1b93;
																						IL_0f3f:
																						num6--;
																						num = 211;
																						goto IL_1b93;
																						IL_1015:
																						if (9 >= b)
																						{
																							goto IL_1020;
																						}
																						goto IL_1087;
																						IL_1020:
																						if (9 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_102e;
																						IL_102e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_106e;
																						IL_106e:
																						array2[num6 - 2] = 0;
																						goto IL_1118;
																						IL_1118:
																						num6--;
																						goto IL_1b93;
																						IL_1087:
																						if (10 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_1095;
																						IL_1095:
																						if (10 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_10a3;
																						IL_10a3:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1105;
																						IL_1105:
																						num6 -= 2;
																						goto IL_1b93;
																						IL_076a:
																						if (5 <= b)
																						{
																							goto IL_0775;
																						}
																						goto IL_07ba;
																						IL_0775:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0906;
																						IL_0906:
																						array2[num6 - 2] = 0;
																						goto IL_0dcd;
																						IL_0dcd:
																						num6--;
																						goto IL_1b93;
																						IL_07ba:
																						if (2 >= b)
																						{
																							goto IL_07c5;
																						}
																						goto IL_07f4;
																						IL_07c5:
																						if (2 > b)
																						{
																							goto IL_07d3;
																						}
																						goto IL_0c85;
																						IL_07d3:
																						if (1 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_07e1;
																						IL_07e1:
																						if (1 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0b1b;
																						IL_0b1b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						num = 27;
																						goto IL_0b3d;
																						IL_0b3d:
																						array2[num6] = 0;
																						goto IL_0b4b;
																						IL_0b4b:
																						num6++;
																						num = 38;
																						goto IL_0b62;
																						IL_0b62:
																						ptr2 += 8;
																						num = 370;
																						goto IL_1b93;
																						IL_0c85:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 59;
																						goto IL_0cce;
																						IL_0cce:
																						array2[num6 - 2] = 0;
																						goto IL_0ce2;
																						IL_0ce2:
																						num6--;
																						goto IL_1b93;
																						IL_07f4:
																						if (3 >= b)
																						{
																							goto IL_07ff;
																						}
																						goto IL_0812;
																						IL_07ff:
																						if (3 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_147d;
																						IL_147d:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_14a6;
																						IL_14a6:
																						ptr2 += 8;
																						goto IL_14b4;
																						IL_14b4:
																						num6--;
																						goto IL_1b93;
																						IL_0812:
																						if (4 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0820;
																						IL_0820:
																						if (4 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0ae8;
																						IL_0ae8:
																						array2[num6] = 0;
																						goto IL_0af6;
																						IL_0af6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0b91;
																						IL_0b91:
																						array3[num6] = null;
																						num = 299;
																						goto IL_0ba4;
																						IL_0ba4:
																						num6++;
																						goto IL_0bb2;
																						IL_0bb2:
																						ptr2 += 8;
																						goto IL_1b93;
																						IL_0833:
																						if (17 >= b)
																						{
																							goto IL_0841;
																						}
																						goto IL_0bc5;
																						IL_0841:
																						if (17 > b)
																						{
																							goto IL_084c;
																						}
																						goto IL_0894;
																						IL_084c:
																						if (14 >= b)
																						{
																							goto IL_085a;
																						}
																						goto IL_11cd;
																						IL_085a:
																						if (14 > b)
																						{
																							goto IL_091f;
																						}
																						goto IL_0de0;
																						IL_0de0:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_0e09;
																						IL_0e09:
																						array2[num6 - 1] = 5;
																						goto IL_1b93;
																						IL_091f:
																						if (12 >= b)
																						{
																							goto IL_092d;
																						}
																						goto IL_0a13;
																						IL_092d:
																						if (12 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_093b;
																						IL_093b:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_094a;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_09f2;
																						IL_1508:
																						array2[num6 - 2] = 0;
																						goto IL_151c;
																						IL_151c:
																						num6--;
																						goto IL_1b93;
																						IL_0c75:
																						if (22 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0cf5;
																						IL_09f2:
																						array2[num6] = 5;
																						goto IL_0a00;
																						IL_0a00:
																						num6++;
																						goto IL_1b93;
																						IL_0a13:
																						if (13 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0a21;
																						IL_0a21:
																						if (13 > b)
																						{
																							goto end_IL_0680;
																						}
																						num = 61;
																						goto IL_0a38;
																						IL_0cf5:
																						if (22 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0d03;
																						IL_0a38:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_140a;
																						IL_140a:
																						ptr2 += 8;
																						goto IL_1418;
																						IL_1418:
																						num6--;
																						goto IL_1b93;
																						IL_11cd:
																						if (15 >= b)
																						{
																							goto IL_11db;
																						}
																						goto IL_1277;
																						IL_11db:
																						if (15 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_11e9;
																						IL_11e9:
																						array2[num6] = array2[num6 - 1];
																						goto IL_1201;
																						IL_1201:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_121f;
																						IL_121f:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 19;
																						goto IL_124c;
																						IL_124c:
																						array3[num6] = array3[num6 - 1];
																						goto IL_1264;
																						IL_1264:
																						num6++;
																						goto IL_1b93;
																						IL_1277:
																						if (16 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_1285;
																						IL_1285:
																						if (16 > b)
																						{
																							goto end_IL_0680;
																						}
																						num = 213;
																						goto IL_13a7;
																						IL_0d03:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0d55;
																						IL_13a7:
																						array2[num6] = 5;
																						goto IL_13b5;
																						IL_13b5:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_13cd;
																						IL_13cd:
																						num6++;
																						goto IL_13db;
																						IL_13db:
																						ptr2 += 8;
																						goto IL_1b93;
																						IL_0894:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_112b;
																						IL_112b:
																						num6 -= 3;
																						goto IL_1b93;
																						IL_0bc5:
																						if (20 >= b)
																						{
																							goto IL_0bd3;
																						}
																						goto IL_0c57;
																						IL_0bd3:
																						if (20 <= b)
																						{
																							goto IL_0bde;
																						}
																						goto IL_0bf6;
																						IL_0bde:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_1b93;
																						IL_0bf6:
																						if (18 < b)
																						{
																							goto IL_0c01;
																						}
																						num = 214;
																						goto IL_0c44;
																						IL_0c01:
																						if (19 < b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0c0f;
																						IL_0c0f:
																						if (19 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_0c1d;
																						IL_0c1d:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_136f;
																						IL_136f:
																						array2[num6] = 1;
																						num = 356;
																						goto IL_1386;
																						IL_1386:
																						num6++;
																						goto IL_1394;
																						IL_1394:
																						ptr2 += 16;
																						goto IL_1b93;
																						IL_0d55:
																						num6--;
																						goto IL_1b93;
																						IL_0c44:
																						if (18 > b)
																						{
																							goto end_IL_0680;
																						}
																						goto IL_113e;
																						IL_113e:
																						array2[num6 - 1] = 5;
																						goto IL_1152;
																						IL_1152:
																						array3[num6 - 1] = ((delegate*<string[], string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_118a;
																						IL_118a:
																						ptr2 += 8;
																						goto IL_1b93;
																					}
																					goto end_IL_0690;
																					continue;
																					end_IL_0680:
																					break;
																					IL_0680:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1b93;
																			continue;
																			end_IL_0690:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_094a:
			while (true)
			{
				IL_094a_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_09f2_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0a00_2:
							num6++;
							while (true)
							{
								IL_1b93_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									num = 334;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0690_2:
											if (b >= 1)
											{
												while (b <= 45)
												{
													while (true)
													{
														if (23 < b)
														{
															while (true)
															{
																IL_0663_2:
																if (34 < b)
																{
																	goto IL_16f6_2;
																}
																while (true)
																{
																	IL_0653_2:
																	if (34 > b)
																	{
																		while (true)
																		{
																			IL_0643_2:
																			if (28 < b)
																			{
																				while (true)
																				{
																					IL_0630_2:
																					if (31 >= b)
																					{
																						num = 384;
																						while (true)
																						{
																							if (num != 384)
																							{
																								if (num != 1365)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 243:
																									goto IL_0630_2;
																								case 363:
																									goto IL_0643_2;
																								case 42:
																									goto IL_0653_2;
																								case 318:
																									goto IL_0663_2;
																								case 332:
																									goto end_IL_0663_2;
																								case 248:
																									goto end_IL_0673;
																								case 238:
																									goto IL_0690_2;
																								case 334:
																									goto end_IL_0690_2;
																								case 130:
																								case 276:
																									goto end_IL_06a0;
																								case 37:
																									goto IL_06c4_2;
																								case 75:
																									goto IL_06dd_2;
																								case 6:
																								case 124:
																									goto IL_06eb_2;
																								case 224:
																									goto IL_0730_2;
																								case 31:
																									goto IL_073e_2;
																								case 50:
																									goto IL_074c_2;
																								case 128:
																									goto IL_0757_2;
																								case 29:
																									goto IL_076a_2;
																								case 92:
																								case 116:
																									goto IL_0775_2;
																								case 199:
																									goto IL_07ba_2;
																								case 110:
																									goto IL_07c5_2;
																								case 177:
																									goto IL_07d3_2;
																								case 74:
																									goto IL_07e1_2;
																								case 119:
																									goto IL_07f4_2;
																								case 28:
																									goto IL_07ff_2;
																								case 168:
																									goto IL_0812_2;
																								case 197:
																									goto IL_0820_2;
																								case 12:
																									goto IL_0833_2;
																								case 206:
																									goto IL_0841_2;
																								case 85:
																									goto IL_084c_2;
																								case 208:
																									goto IL_085a_2;
																								case 246:
																									goto IL_086d_2;
																								case 236:
																									goto IL_0881_2;
																								case 82:
																								case 274:
																									goto IL_0894_2;
																								case 283:
																									goto IL_08d7_2;
																								case 152:
																									goto IL_08e5_2;
																								case 189:
																									goto IL_08f3_2;
																								case 293:
																									goto IL_0906_2;
																								case 295:
																									goto IL_091f_2;
																								case 230:
																									goto IL_092d_2;
																								case 14:
																								case 218:
																									goto end_IL_06b0;
																								case 201:
																									goto IL_09f2_2;
																								case 67:
																									goto IL_0a00_2;
																								case 286:
																									goto IL_0a13_2;
																								case 166:
																									goto IL_0a21_2;
																								case 61:
																								case 207:
																									goto IL_0a38_2;
																								case 302:
																									goto IL_0a5b_2;
																								case 53:
																								case 277:
																									goto IL_0a69_2;
																								case 141:
																									goto IL_0a82_2;
																								case 217:
																									goto IL_0a90_2;
																								case 105:
																									goto IL_0a9e_2;
																								case 306:
																									goto IL_0ab1_2;
																								case 139:
																								case 169:
																									goto IL_0abc_2;
																								case 196:
																									goto IL_0ad5_2;
																								case 9:
																								case 307:
																									goto IL_0ae8_2;
																								case 273:
																									goto IL_0af6_2;
																								case 83:
																								case 311:
																									goto IL_0b1b_2;
																								case 27:
																									goto IL_0b3d_2;
																								case 126:
																									goto IL_0b4b_2;
																								case 38:
																									goto IL_0b62_2;
																								case 314:
																									goto IL_0b7e_2;
																								case 315:
																									goto IL_0b91_2;
																								case 299:
																									goto IL_0ba4_2;
																								case 158:
																									goto IL_0bb2_2;
																								case 322:
																									goto IL_0bc5_2;
																								case 226:
																									goto IL_0bd3_2;
																								case 18:
																								case 112:
																									goto IL_0bde_2;
																								case 153:
																									goto IL_0bf6_2;
																								case 157:
																									goto IL_0c01_2;
																								case 48:
																									goto IL_0c0f_2;
																								case 125:
																								case 244:
																									goto IL_0c1d_2;
																								case 214:
																									goto IL_0c44_2;
																								case 100:
																									goto IL_0c57_2;
																								case 118:
																									goto IL_0c62_2;
																								case 221:
																									goto IL_0c75_2;
																								case 222:
																								case 325:
																									goto IL_0c85_2;
																								case 59:
																									goto IL_0cce_2;
																								case 76:
																									goto IL_0ce2_2;
																								case 326:
																									goto IL_0cf5_2;
																								case 134:
																								case 193:
																									goto IL_0d03_2;
																								case 288:
																									goto IL_0d55_2;
																								case 328:
																									goto IL_0d68_2;
																								case 88:
																									goto IL_0dba_2;
																								case 329:
																									goto IL_0dcd_2;
																								case 120:
																								case 336:
																									goto IL_0de0_2;
																								case 149:
																									goto IL_0e09_2;
																								case 337:
																									goto IL_0e22_2;
																								case 144:
																									goto IL_0e30_2;
																								case 255:
																									goto IL_0e3e_2;
																								case 52:
																									goto IL_0e4c_2;
																								case 4:
																								case 47:
																									goto IL_0e5a_2;
																								case 228:
																									goto IL_0e9a_2;
																								case 104:
																									goto IL_0eae_2;
																								case 167:
																									goto IL_0eca_2;
																								case 162:
																								case 303:
																									goto IL_0ed8_2;
																								case 186:
																									goto IL_0f18_2;
																								case 21:
																									goto IL_0f2c_2;
																								case 7:
																								case 215:
																									goto IL_0f3f_2;
																								case 345:
																									goto IL_0f5b_2;
																								case 90:
																								case 281:
																									goto IL_0f69_2;
																								case 333:
																								case 346:
																									goto IL_0fa6_2;
																								case 84:
																									goto IL_0fba_2;
																								case 13:
																									goto IL_0ff9_2;
																								case 347:
																									goto IL_1015_2;
																								case 343:
																									goto IL_1020_2;
																								case 71:
																								case 312:
																									goto IL_102e_2;
																								case 198:
																									goto IL_106e_2;
																								case 220:
																									goto IL_1087_2;
																								case 278:
																									goto IL_1095_2;
																								case 219:
																								case 316:
																									goto IL_10a3_2;
																								case 57:
																									goto IL_1105_2;
																								case 353:
																									goto IL_1118_2;
																								case 354:
																									goto IL_112b_2;
																								case 257:
																								case 359:
																									goto IL_113e_2;
																								case 308:
																									goto IL_1152_2;
																								case 191:
																									goto IL_118a_2;
																								case 360:
																									goto IL_119d_2;
																								case 122:
																									goto IL_11b1_2;
																								case 364:
																									goto IL_11cd_2;
																								case 147:
																									goto IL_11db_2;
																								case 135:
																								case 240:
																									goto IL_11e9_2;
																								case 54:
																									goto IL_1201_2;
																								case 280:
																									goto IL_121f_2;
																								case 19:
																									goto IL_124c_2;
																								case 357:
																									goto IL_1264_2;
																								case 43:
																									goto IL_1277_2;
																								case 174:
																									goto IL_1285_2;
																								case 365:
																									goto IL_12a1_2;
																								case 143:
																									goto IL_12ac_2;
																								case 25:
																								case 138:
																									goto IL_12ba_2;
																								case 8:
																									goto IL_12f7_2;
																								case 86:
																									goto IL_130b_2;
																								case 249:
																									goto IL_1327_2;
																								case 289:
																									goto IL_1335_2;
																								case 180:
																								case 340:
																									goto IL_1343_2;
																								case 300:
																									goto IL_135c_2;
																								case 367:
																									goto IL_136f_2;
																								case 356:
																									goto IL_1386_2;
																								case 1:
																									goto IL_1394_2;
																								case 213:
																								case 369:
																									goto IL_13a7_2;
																								case 107:
																									goto IL_13b5_2;
																								case 270:
																									goto IL_13cd_2;
																								case 179:
																									goto IL_13db_2;
																								case 371:
																									goto IL_13ee_2;
																								case 372:
																									goto IL_140a_2;
																								case 335:
																									goto IL_1418_2;
																								case 150:
																								case 373:
																									goto IL_142b_2;
																								case 292:
																									goto IL_144e_2;
																								case 229:
																									goto IL_145c_2;
																								case 136:
																									goto IL_146a_2;
																								case 109:
																								case 374:
																									goto IL_147d_2;
																								case 319:
																									goto IL_14a6_2;
																								case 265:
																									goto IL_14b4_2;
																								case 78:
																								case 375:
																									goto IL_14c7_2;
																								case 172:
																									goto IL_1508_2;
																								case 101:
																									goto IL_151c_2;
																								case 70:
																								case 210:
																									goto IL_153a_2;
																								case 323:
																									goto IL_155e_2;
																								case 56:
																									goto IL_156c_2;
																								case 252:
																									goto IL_157a_2;
																								case 129:
																									goto IL_158d_2;
																								case 117:
																									goto IL_1598_2;
																								case 241:
																									goto IL_15a6_2;
																								case 46:
																								case 99:
																									goto IL_15b4_2;
																								case 331:
																									goto IL_15d2_2;
																								case 192:
																									goto IL_15e0_2;
																								case 304:
																									goto IL_15ee_2;
																								case 344:
																									goto IL_1601_2;
																								case 98:
																								case 114:
																									goto IL_160f_2;
																								case 194:
																									goto IL_1623_2;
																								case 185:
																									goto IL_1662_2;
																								case 268:
																								case 287:
																									goto IL_1675_2;
																								case 163:
																									goto IL_1689_2;
																								case 87:
																									goto IL_16d5_2;
																								case 45:
																									goto IL_16e3_2;
																								case 362:
																									goto IL_16f6_2;
																								case 161:
																									goto end_IL_061d_2;
																								case 341:
																									goto IL_1712_2;
																								case 102:
																									goto IL_1720_2;
																								case 81:
																									goto IL_172e_2;
																								case 148:
																									goto IL_173c_2;
																								case 259:
																									goto IL_174a_2;
																								case 175:
																								case 301:
																									goto IL_1758_2;
																								case 181:
																									goto IL_1798_2;
																								case 253:
																									goto IL_17ac_2;
																								case 227:
																									goto IL_17c8_2;
																								case 62:
																								case 251:
																									goto IL_17d6_2;
																								case 212:
																									goto IL_17ff_2;
																								case 355:
																									goto IL_180d_2;
																								case 79:
																								case 361:
																									goto IL_1820_2;
																								case 305:
																									goto IL_185d_2;
																								case 159:
																									goto IL_1871_2;
																								case 205:
																									goto IL_1884_2;
																								case 327:
																									goto IL_188f_2;
																								case 216:
																								case 264:
																									goto IL_189d_2;
																								case 131:
																									goto IL_18c6_2;
																								case 348:
																									goto IL_18d4_2;
																								case 68:
																									goto IL_18e7_2;
																								case 204:
																									goto IL_18f5_2;
																								case 151:
																								case 254:
																									goto IL_1903_2;
																								case 36:
																									goto IL_1917_2;
																								case 262:
																									goto IL_1956_2;
																								case 44:
																								case 111:
																									goto IL_1969_2;
																								case 66:
																									goto IL_19a9_2;
																								case 16:
																									goto IL_19bd_2;
																								case 80:
																									goto IL_19d0_2;
																								case 234:
																									goto IL_19de_2;
																								case 173:
																								case 176:
																									goto IL_19e9_2;
																								case 178:
																									goto IL_19fd_2;
																								case 41:
																									goto IL_1a3c_2;
																								case 285:
																									goto IL_1a4f_2;
																								case 133:
																									goto IL_1a5a_2;
																								case 24:
																								case 320:
																									goto IL_1a68_2;
																								case 317:
																									goto IL_1a92_2;
																								case 223:
																									goto IL_1aa0_2;
																								case 263:
																									goto IL_1ab3_2;
																								case 358:
																									goto IL_1ac1_2;
																								case 231:
																								case 237:
																									goto IL_1acf_2;
																								case 242:
																									goto IL_1aec_2;
																								case 377:
																									goto IL_1b2b_2;
																								case 342:
																									goto IL_1b3b_2;
																								case 339:
																									goto IL_1b46_2;
																								case 10:
																								case 297:
																									goto IL_1b51_2;
																								case 310:
																									goto IL_1b6a_2;
																								case 321:
																									goto IL_1b75_2;
																								case 0:
																								case 3:
																								case 15:
																								case 20:
																								case 23:
																								case 26:
																								case 33:
																								case 34:
																								case 35:
																								case 51:
																								case 58:
																								case 60:
																								case 63:
																								case 65:
																								case 89:
																								case 91:
																								case 94:
																								case 96:
																								case 97:
																								case 103:
																								case 106:
																								case 115:
																								case 121:
																								case 127:
																								case 132:
																								case 137:
																								case 140:
																								case 146:
																								case 154:
																								case 156:
																								case 164:
																								case 165:
																								case 171:
																								case 195:
																								case 235:
																								case 239:
																								case 258:
																								case 269:
																								case 272:
																								case 294:
																								case 298:
																								case 309:
																								case 330:
																								case 338:
																								case 352:
																								case 366:
																								case 368:
																								case 376:
																									goto end_IL_0680_2;
																								case 5:
																								case 11:
																								case 17:
																								case 22:
																								case 30:
																								case 39:
																								case 40:
																								case 49:
																								case 55:
																								case 64:
																								case 69:
																								case 72:
																								case 73:
																								case 77:
																								case 93:
																								case 95:
																								case 108:
																								case 113:
																								case 142:
																								case 145:
																								case 155:
																								case 160:
																								case 170:
																								case 183:
																								case 187:
																								case 190:
																								case 200:
																								case 202:
																								case 203:
																								case 209:
																								case 211:
																								case 232:
																								case 233:
																								case 245:
																								case 260:
																								case 266:
																								case 267:
																								case 271:
																								case 275:
																								case 279:
																								case 282:
																								case 284:
																								case 296:
																								case 313:
																								case 349:
																								case 350:
																								case 351:
																								case 370:
																									goto IL_1b93_2;
																								case 225:
																									ptr2 = ptr;
																									goto IL_1b93_2;
																								case 123:
																									ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetStringAndReleaseTrimToSize.GetValueOrDefaultgetOwner);
																									goto case 225;
																								case 188:
																									array7 = new object[18];
																									goto case 123;
																								case 247:
																									array6 = new long[4];
																									goto case 188;
																								case 256:
																									array5 = new int[7];
																									goto case 247;
																								case 182:
																									array4 = new int[4];
																									goto case 256;
																								case 2:
																									array3 = new object[4];
																									goto case 182;
																								case 261:
																									array2 = new byte[4];
																									goto case 2;
																								case 250:
																									num4 = num2 * 8;
																									goto case 261;
																								case 184:
																									num3 = num2 * 4;
																									goto case 250;
																								case 290:
																									num2 = 1;
																									goto case 184;
																								case 291:
																									goto end_IL_0958;
																								case 32:
																								case 324:
																									return;
																								}
																								continue;
																							}
																							if (31 <= b)
																							{
																								goto IL_153a_2;
																							}
																							goto IL_158d_2;
																							IL_160f_2:
																							array2[num6 - 1] = 0;
																							goto IL_1623_2;
																							IL_1662_2:
																							ptr2 += 8;
																							goto IL_1b93_2;
																							IL_1623_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1662_2;
																							IL_153a_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
																							goto IL_155e_2;
																							IL_155e_2:
																							array2[num6] = 0;
																							goto IL_156c_2;
																							IL_156c_2:
																							num6++;
																							goto IL_157a_2;
																							IL_157a_2:
																							ptr2 += 8;
																							goto IL_1b93_2;
																							IL_158d_2:
																							if (29 < b)
																							{
																								goto IL_1598_2;
																							}
																							goto IL_1601_2;
																							IL_1598_2:
																							if (30 < b)
																							{
																								goto end_IL_0680_2;
																							}
																							goto IL_15a6_2;
																							IL_15a6_2:
																							if (30 > b)
																							{
																								goto end_IL_0680_2;
																							}
																							goto IL_15b4_2;
																							IL_15b4_2:
																							array3[num6] = ((delegate*<ColorOption[]>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
																							goto IL_15d2_2;
																							IL_15d2_2:
																							array2[num6] = 5;
																							goto IL_15e0_2;
																							IL_15e0_2:
																							num6++;
																							goto IL_15ee_2;
																							IL_15ee_2:
																							ptr2 += 8;
																							goto IL_1b93_2;
																							IL_1601_2:
																							if (29 > b)
																							{
																								goto end_IL_0680_2;
																							}
																							goto IL_160f_2;
																							continue;
																							end_IL_061d_2:
																							break;
																						}
																						break;
																					}
																					goto IL_12a1_2;
																					IL_1343_2:
																					global::_003CModule_003E.colorOption_3 = (ColorOption)array3[num6 - 1];
																					goto IL_135c_2;
																					IL_135c_2:
																					num6--;
																					goto IL_1b93_2;
																					IL_12a1_2:
																					if (32 >= b)
																					{
																						goto IL_12ac_2;
																					}
																					goto IL_1327_2;
																					IL_12ac_2:
																					if (32 > b)
																					{
																						goto end_IL_0680_2;
																					}
																					goto IL_12ba_2;
																					IL_12ba_2:
																					array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_12f7_2;
																					IL_12f7_2:
																					array2[num6 - 2] = 4;
																					goto IL_130b_2;
																					IL_130b_2:
																					num6--;
																					num = 232;
																					goto IL_1b93_2;
																					IL_1327_2:
																					if (33 < b)
																					{
																						goto end_IL_0680_2;
																					}
																					goto IL_1335_2;
																					IL_1335_2:
																					if (33 > b)
																					{
																						goto end_IL_0680_2;
																					}
																					goto IL_1343_2;
																				}
																				break;
																			}
																			goto IL_06dd_2;
																			IL_11b1_2:
																			ptr2 += 8;
																			num = 72;
																			goto IL_1b93_2;
																			IL_06dd_2:
																			if (28 <= b)
																			{
																				goto IL_06eb_2;
																			}
																			goto IL_08d7_2;
																			IL_06eb_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_086d_2;
																			IL_086d_2:
																			array2[num6 - 2] = 3;
																			goto IL_0881_2;
																			IL_0881_2:
																			num6--;
																			goto IL_1b93_2;
																			IL_08d7_2:
																			if (25 < b)
																			{
																				goto IL_08e5_2;
																			}
																			goto IL_0ab1_2;
																			IL_08e5_2:
																			if (26 < b)
																			{
																				goto IL_08f3_2;
																			}
																			goto IL_0a5b_2;
																			IL_08f3_2:
																			if (27 < b)
																			{
																				goto end_IL_0680_2;
																			}
																			goto IL_0b7e_2;
																			IL_0b7e_2:
																			if (27 > b)
																			{
																				goto end_IL_0680_2;
																			}
																			goto IL_0fa6_2;
																			IL_0fa6_2:
																			array2[num6 - 1] = 3;
																			goto IL_0fba_2;
																			IL_0fba_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_0ff9_2;
																			IL_0ff9_2:
																			ptr2 += 8;
																			num = 77;
																			goto IL_1b93_2;
																			IL_0a5b_2:
																			if (26 > b)
																			{
																				goto end_IL_0680_2;
																			}
																			goto IL_0a69_2;
																			IL_0a69_2:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																			goto IL_0a82_2;
																			IL_0a82_2:
																			array2[num6] = 3;
																			goto IL_0a90_2;
																			IL_0a90_2:
																			num6++;
																			goto IL_0a9e_2;
																			IL_0a9e_2:
																			ptr2 += 16;
																			goto IL_1b93_2;
																			IL_0ab1_2:
																			if (25 <= b)
																			{
																				goto IL_0abc_2;
																			}
																			goto IL_0ad5_2;
																			IL_0abc_2:
																			array2[num6 - 2] = 0;
																			goto IL_0d68_2;
																			IL_0d68_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																			goto IL_0dba_2;
																			IL_0dba_2:
																			num6--;
																			goto IL_13ee_2;
																			IL_13ee_2:
																			ptr2 += 8;
																			num = 284;
																			goto IL_1b93_2;
																			IL_0ad5_2:
																			if (24 < b)
																			{
																				goto end_IL_0680_2;
																			}
																			goto IL_0f5b_2;
																			IL_0f5b_2:
																			if (24 > b)
																			{
																				goto end_IL_0680_2;
																			}
																			goto IL_0f69_2;
																			IL_0f69_2:
																			array3[num6 - 1] = ((delegate*<ColorOption, string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																			goto IL_119d_2;
																			IL_119d_2:
																			array2[num6 - 1] = 5;
																			goto IL_11b1_2;
																		}
																		break;
																	}
																	goto IL_1675_2;
																	IL_16e3_2:
																	ptr2 += 8;
																	goto IL_1b93_2;
																	IL_1675_2:
																	array2[num6 - 2] = 5;
																	goto IL_1689_2;
																	IL_1689_2:
																	array3[num6 - 2] = ((delegate*<string, string, string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																	goto IL_16d5_2;
																	IL_16d5_2:
																	num6--;
																	goto IL_16e3_2;
																}
																goto IL_1704_2;
																IL_1b6a_2:
																if (45 < b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1b75_2;
																IL_16f6_2:
																if (40 >= b)
																{
																	goto IL_1704_2;
																}
																goto IL_19d0_2;
																IL_1704_2:
																if (40 > b)
																{
																	goto IL_1712_2;
																}
																goto IL_1969_2;
																IL_1712_2:
																if (37 >= b)
																{
																	goto IL_1720_2;
																}
																goto IL_1884_2;
																IL_1720_2:
																if (37 > b)
																{
																	goto IL_172e_2;
																}
																goto IL_1820_2;
																IL_172e_2:
																if (35 < b)
																{
																	goto IL_173c_2;
																}
																num = 227;
																goto IL_17c8_2;
																IL_173c_2:
																if (36 < b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_174a_2;
																IL_174a_2:
																if (36 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1758_2;
																IL_1758_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_1798_2;
																IL_1798_2:
																array2[num6 - 2] = 3;
																goto IL_17ac_2;
																IL_17ac_2:
																num6--;
																goto IL_1b93_2;
																IL_1b75_2:
																if (45 <= b)
																{
																}
																goto end_IL_0680_2;
																IL_17c8_2:
																if (35 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_17d6_2;
																IL_17d6_2:
																((delegate*<string, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_17ff_2;
																IL_17ff_2:
																num6--;
																goto IL_180d_2;
																IL_180d_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1820_2:
																array3[num6 - 1] = ((delegate*<ColorOption, Color>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																goto IL_185d_2;
																IL_185d_2:
																array2[num6 - 1] = 4;
																goto IL_1871_2;
																IL_1871_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1884_2:
																if (38 >= b)
																{
																	goto IL_188f_2;
																}
																goto IL_18e7_2;
																IL_188f_2:
																if (38 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_189d_2;
																IL_189d_2:
																((delegate*<Color, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																goto IL_18c6_2;
																IL_18c6_2:
																num6--;
																goto IL_18d4_2;
																IL_18d4_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_18e7_2:
																if (39 < b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_18f5_2;
																IL_18f5_2:
																if (39 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1903_2;
																IL_1903_2:
																array2[num6 - 1] = 3;
																goto IL_1917_2;
																IL_1917_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1956_2;
																IL_1956_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1969_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_19a9_2;
																IL_19a9_2:
																array2[num6 - 2] = 3;
																goto IL_19bd_2;
																IL_19bd_2:
																num6--;
																goto IL_1b93_2;
																IL_19d0_2:
																if (43 >= b)
																{
																	goto IL_19de_2;
																}
																goto IL_1b3b_2;
																IL_19de_2:
																if (43 <= b)
																{
																	goto IL_19e9_2;
																}
																goto IL_1a4f_2;
																IL_19e9_2:
																array2[num6 - 1] = 3;
																goto IL_19fd_2;
																IL_19fd_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1a3c_2;
																IL_1a3c_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1a4f_2:
																if (41 >= b)
																{
																	goto IL_1a5a_2;
																}
																goto IL_1ab3_2;
																IL_1a5a_2:
																if (41 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1a68_2;
																IL_1a68_2:
																((delegate*<bool, void>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																goto IL_1a92_2;
																IL_1a92_2:
																num6--;
																goto IL_1aa0_2;
																IL_1aa0_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1ab3_2:
																if (42 < b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1ac1_2;
																IL_1ac1_2:
																if (42 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1acf_2;
																IL_1acf_2:
																array2[num6 - 1] = 3;
																num = 242;
																goto IL_1aec_2;
																IL_1aec_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1b2b_2;
																IL_1b2b_2:
																ptr2 += 8;
																goto IL_1b93_2;
																IL_1b3b_2:
																if (44 >= b)
																{
																	goto IL_1b46_2;
																}
																goto IL_1b6a_2;
																IL_1b46_2:
																if (44 > b)
																{
																	goto end_IL_0680_2;
																}
																goto IL_1b51_2;
																IL_1b51_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																goto IL_1b93_2;
																continue;
																end_IL_0663_2:
																break;
															}
															continue;
														}
														goto IL_06c4_2;
														IL_1508_2:
														array2[num6 - 2] = 0;
														goto IL_151c_2;
														IL_06c4_2:
														if (23 > b)
														{
															goto IL_0730_2;
														}
														num = 373;
														goto IL_142b_2;
														IL_151c_2:
														num6--;
														goto IL_1b93_2;
														IL_142b_2:
														array3[num6] = ((delegate*<ColorOption>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])();
														goto IL_144e_2;
														IL_144e_2:
														array2[num6] = 4;
														goto IL_145c_2;
														IL_145c_2:
														num6++;
														goto IL_146a_2;
														IL_146a_2:
														ptr2 += 8;
														goto IL_1b93_2;
														IL_0730_2:
														if (11 >= b)
														{
															goto IL_073e_2;
														}
														goto IL_0833_2;
														IL_073e_2:
														if (11 <= b)
														{
															goto IL_1b93_2;
														}
														goto IL_074c_2;
														IL_074c_2:
														if (5 < b)
														{
															goto IL_0757_2;
														}
														goto IL_076a_2;
														IL_0757_2:
														if (8 >= b)
														{
															goto IL_0e22_2;
														}
														goto IL_1015_2;
														IL_0e22_2:
														if (8 > b)
														{
															goto IL_0e30_2;
														}
														goto IL_0f3f_2;
														IL_0e30_2:
														if (6 < b)
														{
															goto IL_0e3e_2;
														}
														num = 167;
														goto IL_0eca_2;
														IL_0e3e_2:
														if (7 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0e4c_2;
														IL_0e4c_2:
														if (7 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0e5a_2;
														IL_0e5a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0e9a_2;
														IL_0e9a_2:
														array2[num6 - 2] = 0;
														goto IL_0eae_2;
														IL_0eae_2:
														num6--;
														goto IL_1b93_2;
														IL_0c75_2:
														if (22 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0cf5_2;
														IL_0eca_2:
														if (6 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0ed8_2;
														IL_0ed8_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0f18_2;
														IL_0f18_2:
														array2[num6 - 2] = 0;
														goto IL_0f2c_2;
														IL_0f2c_2:
														num6--;
														goto IL_1b93_2;
														IL_0f3f_2:
														num6--;
														num = 211;
														goto IL_1b93_2;
														IL_1015_2:
														if (9 >= b)
														{
															goto IL_1020_2;
														}
														goto IL_1087_2;
														IL_1020_2:
														if (9 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_102e_2;
														IL_102e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_106e_2;
														IL_106e_2:
														array2[num6 - 2] = 0;
														goto IL_1118_2;
														IL_1118_2:
														num6--;
														goto IL_1b93_2;
														IL_1087_2:
														if (10 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_1095_2;
														IL_1095_2:
														if (10 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_10a3_2;
														IL_10a3_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1105_2;
														IL_1105_2:
														num6 -= 2;
														goto IL_1b93_2;
														IL_076a_2:
														if (5 <= b)
														{
															goto IL_0775_2;
														}
														goto IL_07ba_2;
														IL_0775_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0906_2;
														IL_0906_2:
														array2[num6 - 2] = 0;
														goto IL_0dcd_2;
														IL_0dcd_2:
														num6--;
														goto IL_1b93_2;
														IL_07ba_2:
														if (2 >= b)
														{
															goto IL_07c5_2;
														}
														goto IL_07f4_2;
														IL_07c5_2:
														if (2 > b)
														{
															goto IL_07d3_2;
														}
														goto IL_0c85_2;
														IL_07d3_2:
														if (1 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_07e1_2;
														IL_07e1_2:
														if (1 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0b1b_2;
														IL_0b1b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														num = 27;
														goto IL_0b3d_2;
														IL_0b3d_2:
														array2[num6] = 0;
														goto IL_0b4b_2;
														IL_0b4b_2:
														num6++;
														num = 38;
														goto IL_0b62_2;
														IL_0b62_2:
														ptr2 += 8;
														num = 370;
														goto IL_1b93_2;
														IL_0c85_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 59;
														goto IL_0cce_2;
														IL_0cce_2:
														array2[num6 - 2] = 0;
														goto IL_0ce2_2;
														IL_0ce2_2:
														num6--;
														goto IL_1b93_2;
														IL_07f4_2:
														if (3 >= b)
														{
															goto IL_07ff_2;
														}
														goto IL_0812_2;
														IL_07ff_2:
														if (3 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_147d_2;
														IL_147d_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_14a6_2;
														IL_14a6_2:
														ptr2 += 8;
														goto IL_14b4_2;
														IL_14b4_2:
														num6--;
														goto IL_1b93_2;
														IL_0812_2:
														if (4 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0820_2;
														IL_0820_2:
														if (4 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0ae8_2;
														IL_0ae8_2:
														array2[num6] = 0;
														goto IL_0af6_2;
														IL_0af6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0b91_2;
														IL_0b91_2:
														array3[num6] = null;
														num = 299;
														goto IL_0ba4_2;
														IL_0ba4_2:
														num6++;
														goto IL_0bb2_2;
														IL_0bb2_2:
														ptr2 += 8;
														goto IL_1b93_2;
														IL_0833_2:
														if (17 >= b)
														{
															goto IL_0841_2;
														}
														goto IL_0bc5_2;
														IL_0841_2:
														if (17 > b)
														{
															goto IL_084c_2;
														}
														goto IL_0894_2;
														IL_084c_2:
														if (14 >= b)
														{
															goto IL_085a_2;
														}
														goto IL_11cd_2;
														IL_085a_2:
														if (14 > b)
														{
															goto IL_091f_2;
														}
														goto IL_0de0_2;
														IL_0de0_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_0e09_2;
														IL_0e09_2:
														array2[num6 - 1] = 5;
														goto IL_1b93_2;
														IL_091f_2:
														if (12 >= b)
														{
															goto IL_092d_2;
														}
														goto IL_0a13_2;
														IL_092d_2:
														if (12 > b)
														{
															goto end_IL_0680_2;
														}
														goto end_IL_06b0;
														IL_0a13_2:
														if (13 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0a21_2;
														IL_0a21_2:
														if (13 > b)
														{
															goto end_IL_0680_2;
														}
														num = 61;
														goto IL_0a38_2;
														IL_0cf5_2:
														if (22 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0d03_2;
														IL_0a38_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_140a_2;
														IL_140a_2:
														ptr2 += 8;
														goto IL_1418_2;
														IL_1418_2:
														num6--;
														goto IL_1b93_2;
														IL_11cd_2:
														if (15 >= b)
														{
															goto IL_11db_2;
														}
														goto IL_1277_2;
														IL_11db_2:
														if (15 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_11e9_2;
														IL_11e9_2:
														array2[num6] = array2[num6 - 1];
														goto IL_1201_2;
														IL_1201_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_121f_2;
														IL_121f_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 19;
														goto IL_124c_2;
														IL_124c_2:
														array3[num6] = array3[num6 - 1];
														goto IL_1264_2;
														IL_1264_2:
														num6++;
														goto IL_1b93_2;
														IL_1277_2:
														if (16 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_1285_2;
														IL_1285_2:
														if (16 > b)
														{
															goto end_IL_0680_2;
														}
														num = 213;
														goto IL_13a7_2;
														IL_0d03_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0d55_2;
														IL_13a7_2:
														array2[num6] = 5;
														goto IL_13b5_2;
														IL_13b5_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_13cd_2;
														IL_13cd_2:
														num6++;
														goto IL_13db_2;
														IL_13db_2:
														ptr2 += 8;
														goto IL_1b93_2;
														IL_0894_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_112b_2;
														IL_112b_2:
														num6 -= 3;
														goto IL_1b93_2;
														IL_0bc5_2:
														if (20 >= b)
														{
															goto IL_0bd3_2;
														}
														goto IL_0c57_2;
														IL_0bd3_2:
														if (20 <= b)
														{
															goto IL_0bde_2;
														}
														goto IL_0bf6_2;
														IL_0bde_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1b93_2;
														IL_0bf6_2:
														if (18 < b)
														{
															goto IL_0c01_2;
														}
														num = 214;
														goto IL_0c44_2;
														IL_0c01_2:
														if (19 < b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0c0f_2;
														IL_0c0f_2:
														if (19 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_0c1d_2;
														IL_0c1d_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_136f_2;
														IL_136f_2:
														array2[num6] = 1;
														num = 356;
														goto IL_1386_2;
														IL_1386_2:
														num6++;
														goto IL_1394_2;
														IL_1394_2:
														ptr2 += 16;
														goto IL_1b93_2;
														IL_0d55_2:
														num6--;
														goto IL_1b93_2;
														IL_0c44_2:
														if (18 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_113e_2;
														IL_113e_2:
														array2[num6 - 1] = 5;
														goto IL_1152_2;
														IL_1152_2:
														array3[num6 - 1] = ((delegate*<string[], string>)GetSecondCallConvStdcall[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_118a_2;
														IL_118a_2:
														ptr2 += 8;
														goto IL_1b93_2;
														IL_0c57_2:
														if (21 >= b)
														{
															goto IL_0c62_2;
														}
														goto IL_0c75_2;
														IL_0c62_2:
														if (21 > b)
														{
															goto end_IL_0680_2;
														}
														goto IL_14c7_2;
														IL_14c7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1508_2;
														continue;
														end_IL_0673:
														break;
													}
													continue;
													end_IL_0680_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_1b93_2;
											continue;
											end_IL_0690_2:
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06b0:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_094a_2;
					}
					continue;
					end_IL_0958:
					break;
				}
				break;
			}
		}
	}

	public unsafe static string smethod_1()
	{
		int num = 162;
		int num5 = default(int);
		int num6 = default(int);
		object[] array6 = default(object[]);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LastSubNodeTypeUCOMIEnumConnectionPoints.AttributeTargetsGetArrayMethodToken);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															IL_0432:
															num = 127;
															while (true)
															{
																IL_0427:
																byte b = *ptr2;
																while (true)
																{
																	IL_0417:
																	ptr2++;
																	while (true)
																	{
																		IL_0407:
																		if (b >= 1)
																		{
																			while (b <= 21)
																			{
																				while (true)
																				{
																					IL_03e7:
																					if (11 >= b)
																					{
																						while (11 > b)
																						{
																							while (true)
																							{
																								IL_03ca:
																								if (5 >= b)
																								{
																									while (true)
																									{
																										IL_03bd:
																										if (5 <= b)
																										{
																											while (true)
																											{
																												IL_0372:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												num = 212;
																												while (true)
																												{
																													if (num != 212)
																													{
																														if (num != 1193)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 61:
																														case 158:
																															goto IL_0372;
																														case 88:
																															goto IL_03bd;
																														case 17:
																															goto IL_03ca;
																														case 110:
																															goto IL_03d7;
																														case 177:
																															goto IL_03e7;
																														case 167:
																															goto IL_03f7;
																														case 115:
																															goto IL_0407;
																														case 134:
																															goto IL_0417;
																														case 127:
																															goto IL_0427;
																														case 9:
																															goto IL_0432;
																														case 13:
																														case 78:
																															goto IL_0448;
																														case 28:
																															goto IL_0456;
																														case 42:
																														case 84:
																															goto IL_0466;
																														case 16:
																															goto IL_0474;
																														case 118:
																															goto IL_0487;
																														case 69:
																															goto IL_0492;
																														case 37:
																														case 139:
																															goto IL_04a5;
																														case 23:
																															goto IL_04b3;
																														case 12:
																														case 29:
																															goto IL_04c1;
																														case 58:
																															goto IL_0501;
																														case 92:
																															goto IL_0515;
																														case 19:
																														case 140:
																															goto IL_0528;
																														case 75:
																															goto IL_0533;
																														case 74:
																															goto IL_0546;
																														case 123:
																															goto IL_0554;
																														case 116:
																														case 147:
																															goto IL_0567;
																														case 93:
																															goto IL_057e;
																														case 70:
																														case 157:
																															goto IL_0591;
																														case 4:
																															goto IL_05da;
																														case 40:
																															goto IL_05ee;
																														case 181:
																															goto IL_0601;
																														case 122:
																															goto IL_060c;
																														case 53:
																														case 67:
																															goto IL_061a;
																														case 11:
																															goto IL_065a;
																														case 26:
																															goto IL_066e;
																														case 10:
																														case 21:
																															goto IL_0681;
																														case 141:
																															goto IL_068f;
																														case 153:
																														case 175:
																															goto IL_06a6;
																														case 120:
																														case 184:
																															goto IL_070d;
																														case 132:
																															goto IL_071b;
																														case 72:
																															goto IL_073e;
																														case 144:
																														case 187:
																															goto IL_074a;
																														case 99:
																															goto IL_0773;
																														case 54:
																															goto IL_0781;
																														case 191:
																															goto IL_0794;
																														case 96:
																															goto IL_07a2;
																														case 111:
																														case 192:
																															goto IL_07b5;
																														case 107:
																															goto IL_07fe;
																														case 173:
																															goto IL_0812;
																														case 195:
																															goto IL_0825;
																														case 188:
																														case 196:
																															goto IL_0838;
																														case 148:
																														case 198:
																															goto IL_084b;
																														case 113:
																															goto IL_0864;
																														case 6:
																															goto IL_0872;
																														case 119:
																															goto IL_0880;
																														case 156:
																															goto IL_08a7;
																														case 83:
																														case 201:
																															goto IL_08ba;
																														case 38:
																															goto IL_08c8;
																														case 59:
																														case 169:
																															goto IL_08d6;
																														case 5:
																														case 130:
																															goto IL_08e4;
																														case 109:
																														case 193:
																															goto IL_08f2;
																														case 117:
																															goto IL_0900;
																														case 76:
																														case 100:
																															goto IL_090e;
																														case 151:
																															goto IL_0960;
																														case 125:
																															goto IL_0973;
																														case 183:
																														case 199:
																															goto IL_098a;
																														case 101:
																															goto IL_09cb;
																														case 2:
																															goto IL_09df;
																														case 179:
																															goto IL_09f2;
																														case 98:
																														case 114:
																															goto IL_09fd;
																														case 8:
																															goto IL_0a14;
																														case 35:
																														case 49:
																															goto IL_0a2b;
																														case 182:
																															goto IL_0a44;
																														case 39:
																															goto IL_0a52;
																														case 46:
																															goto IL_0a60;
																														case 106:
																														case 170:
																															goto IL_0a73;
																														case 44:
																														case 128:
																															goto IL_0a8b;
																														case 64:
																															goto IL_0aa9;
																														case 22:
																															goto IL_0ab7;
																														case 133:
																															goto IL_0ac5;
																														case 36:
																															goto IL_0ad8;
																														case 52:
																															goto IL_0ae6;
																														case 108:
																														case 145:
																															goto IL_0af4;
																														case 68:
																														case 85:
																															goto IL_0b02;
																														case 66:
																															goto IL_0b10;
																														case 90:
																														case 103:
																															goto end_IL_035f;
																														case 73:
																															goto IL_0b32;
																														case 102:
																															goto IL_0b50;
																														case 121:
																															goto IL_0b7a;
																														case 77:
																															goto IL_0b93;
																														case 174:
																															goto IL_0ba1;
																														case 138:
																															goto IL_0bb4;
																														case 25:
																														case 89:
																															goto IL_0bc2;
																														case 163:
																															goto IL_0be6;
																														case 7:
																															goto IL_0bf4;
																														case 94:
																															goto IL_0c0b;
																														case 62:
																														case 146:
																															goto IL_0c27;
																														case 15:
																															goto IL_0c91;
																														case 51:
																															goto IL_0ca5;
																														case 165:
																															goto IL_0cb5;
																														case 129:
																														case 178:
																															goto IL_0cc9;
																														case 154:
																															goto IL_0cd4;
																														case 1:
																															goto IL_0cea;
																														case 55:
																														case 168:
																															goto IL_0cf5;
																														case 0:
																														case 3:
																														case 20:
																														case 24:
																														case 31:
																														case 32:
																														case 43:
																														case 45:
																														case 47:
																														case 48:
																														case 60:
																														case 80:
																														case 81:
																														case 82:
																														case 86:
																														case 95:
																														case 136:
																														case 137:
																														case 143:
																														case 149:
																														case 150:
																														case 152:
																														case 160:
																														case 164:
																														case 166:
																														case 171:
																														case 176:
																														case 185:
																														case 186:
																														case 194:
																														case 200:
																														case 202:
																														case 204:
																															goto end_IL_03f7;
																														case 14:
																														case 18:
																														case 27:
																														case 30:
																														case 33:
																														case 41:
																														case 56:
																														case 57:
																														case 63:
																														case 65:
																														case 71:
																														case 87:
																														case 91:
																														case 97:
																														case 104:
																														case 105:
																														case 112:
																														case 124:
																														case 126:
																														case 155:
																														case 159:
																														case 180:
																														case 189:
																														case 205:
																															goto end_IL_03d7;
																														case 203:
																															goto end_IL_0d2a;
																														case 79:
																															goto end_IL_0d3d;
																														case 142:
																															goto end_IL_0d47;
																														case 131:
																															goto end_IL_0d52;
																														case 197:
																															goto end_IL_0d62;
																														case 34:
																															goto end_IL_0d72;
																														case 190:
																															goto end_IL_0d82;
																														case 172:
																															goto end_IL_0d92;
																														case 161:
																															goto end_IL_0da2;
																														case 162:
																															goto end_IL_0db2;
																														case 50:
																														case 135:
																															goto IL_0dd6;
																														}
																														continue;
																													}
																													array[num6 - 2] = 0;
																													goto IL_08a7;
																													IL_08a7:
																													num6--;
																													goto end_IL_03d7;
																													continue;
																													end_IL_035f:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										num = 84;
																										goto IL_0466;
																										IL_073e:
																										array2[num6] = null;
																										goto IL_0794;
																										IL_0794:
																										num6++;
																										goto IL_07a2;
																										IL_0466:
																										if (2 >= b)
																										{
																											goto IL_0474;
																										}
																										goto IL_0528;
																										IL_0474:
																										if (2 > b)
																										{
																											goto IL_0567;
																										}
																										goto IL_0591;
																										IL_0567:
																										if (1 < b)
																										{
																											goto end_IL_03f7;
																										}
																										num = 93;
																										goto IL_057e;
																										IL_07a2:
																										ptr2 += 8;
																										goto end_IL_03d7;
																										IL_057e:
																										if (1 > b)
																										{
																											goto end_IL_03f7;
																										}
																										goto IL_084b;
																										IL_084b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																										goto IL_0864;
																										IL_0864:
																										array[num6] = 0;
																										goto IL_0872;
																										IL_0872:
																										num6++;
																										goto IL_0880;
																										IL_0880:
																										ptr2 += 8;
																										goto end_IL_03d7;
																										IL_0591:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										num = 4;
																										goto IL_05da;
																										IL_05da:
																										array[num6 - 2] = 0;
																										goto IL_05ee;
																										IL_05ee:
																										num6--;
																										goto end_IL_03d7;
																										IL_0528:
																										if (3 >= b)
																										{
																											goto IL_0533;
																										}
																										goto IL_0546;
																										IL_0533:
																										if (3 > b)
																										{
																											goto end_IL_03f7;
																										}
																										goto IL_074a;
																										IL_074a:
																										ref int reference = ref array4[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_0773;
																										IL_0773:
																										ptr2 += 8;
																										goto IL_0781;
																										IL_0781:
																										num6--;
																										goto end_IL_03d7;
																										IL_0546:
																										if (4 < b)
																										{
																											goto end_IL_03f7;
																										}
																										goto IL_0554;
																										IL_0554:
																										if (4 > b)
																										{
																											goto end_IL_03f7;
																										}
																										goto IL_070d;
																										IL_070d:
																										array[num6] = 0;
																										goto IL_071b;
																										IL_071b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																										goto IL_073e;
																									}
																									break;
																								}
																								goto IL_0448;
																								IL_06a6:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0825;
																								IL_0448:
																								if (8 >= b)
																								{
																									goto IL_0456;
																								}
																								goto IL_0601;
																								IL_0456:
																								if (8 > b)
																								{
																									goto IL_0487;
																								}
																								goto IL_0838;
																								IL_0838:
																								num6--;
																								goto end_IL_03d7;
																								IL_0487:
																								if (6 >= b)
																								{
																									goto IL_0492;
																								}
																								goto IL_04a5;
																								IL_0492:
																								if (6 > b)
																								{
																									goto end_IL_03f7;
																								}
																								goto IL_07b5;
																								IL_07b5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								num = 107;
																								goto IL_07fe;
																								IL_07fe:
																								array[num6 - 2] = 0;
																								goto IL_0812;
																								IL_0812:
																								num6--;
																								goto end_IL_03d7;
																								IL_04a5:
																								if (7 < b)
																								{
																									goto end_IL_03f7;
																								}
																								goto IL_04b3;
																								IL_04b3:
																								if (7 > b)
																								{
																									goto end_IL_03f7;
																								}
																								goto IL_04c1;
																								IL_04c1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_0501;
																								IL_0501:
																								array[num6 - 2] = 0;
																								goto IL_0515;
																								IL_0515:
																								num6--;
																								goto end_IL_03d7;
																								IL_0601:
																								if (9 >= b)
																								{
																									goto IL_060c;
																								}
																								goto IL_0681;
																								IL_060c:
																								if (9 > b)
																								{
																									goto end_IL_03f7;
																								}
																								goto IL_061a;
																								IL_061a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_065a;
																								IL_065a:
																								array[num6 - 2] = 0;
																								goto IL_066e;
																								IL_066e:
																								num6--;
																								goto end_IL_03d7;
																								IL_0681:
																								if (10 < b)
																								{
																									goto end_IL_03f7;
																								}
																								goto IL_068f;
																								IL_068f:
																								if (10 > b)
																								{
																									goto end_IL_03f7;
																								}
																								num = 153;
																								goto IL_06a6;
																								IL_0825:
																								num6 -= 2;
																								goto end_IL_03d7;
																							}
																							goto IL_0b1e;
																							continue;
																							end_IL_03d7:
																							break;
																							IL_03d7:;
																						}
																						break;
																					}
																					goto IL_08ba;
																					IL_0cea:
																					if (20 > b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0cf5;
																					IL_08ba:
																					if (16 >= b)
																					{
																						goto IL_08c8;
																					}
																					goto IL_0ad8;
																					IL_08c8:
																					if (16 > b)
																					{
																						goto IL_08d6;
																					}
																					goto IL_0a8b;
																					IL_08d6:
																					if (13 < b)
																					{
																						goto IL_08e4;
																					}
																					goto IL_09f2;
																					IL_08e4:
																					if (14 < b)
																					{
																						goto IL_08f2;
																					}
																					goto IL_0973;
																					IL_08f2:
																					if (15 < b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0900;
																					IL_0900:
																					if (15 > b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_090e;
																					IL_090e:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0960;
																					IL_0960:
																					num6--;
																					break;
																					IL_0973:
																					if (14 > b)
																					{
																						goto end_IL_03f7;
																					}
																					num = 183;
																					goto IL_098a;
																					IL_0cc9:
																					if (21 < b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0cd4;
																					IL_098a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																					goto IL_09cb;
																					IL_09cb:
																					array[num6 - 2] = 0;
																					goto IL_09df;
																					IL_09df:
																					num6--;
																					break;
																					IL_09f2:
																					if (13 > b)
																					{
																						goto IL_09fd;
																					}
																					goto IL_0a73;
																					IL_09fd:
																					if (12 < b)
																					{
																						goto end_IL_03f7;
																					}
																					num = 8;
																					goto IL_0a14;
																					IL_0cd4:
																					if (21 <= b)
																					{
																						num = 160;
																					}
																					goto end_IL_03f7;
																					IL_0a14:
																					if (12 > b)
																					{
																						goto end_IL_03f7;
																					}
																					num = 35;
																					goto IL_0a2b;
																					IL_0cf5:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					num = 97;
																					break;
																					IL_0a2b:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																					goto IL_0a44;
																					IL_0a44:
																					array[num6] = 1;
																					goto IL_0a52;
																					IL_0a52:
																					num6++;
																					goto IL_0a60;
																					IL_0a60:
																					ptr2 += 16;
																					break;
																					IL_0a73:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_0a8b:
																					array2[num6] = ((delegate*<ColorOption[]>)CookiesgetEndOfStream[*(int*)(ptr2 + num3)])();
																					goto IL_0aa9;
																					IL_0aa9:
																					array[num6] = 5;
																					goto IL_0ab7;
																					IL_0ab7:
																					num6++;
																					goto IL_0ac5;
																					IL_0ac5:
																					ptr2 += 8;
																					break;
																					IL_0ad8:
																					if (19 >= b)
																					{
																						goto IL_0ae6;
																					}
																					goto IL_0cb5;
																					IL_0ae6:
																					if (19 > b)
																					{
																						goto IL_0af4;
																					}
																					goto IL_0c27;
																					IL_0af4:
																					if (17 < b)
																					{
																						goto IL_0b02;
																					}
																					goto IL_0bb4;
																					IL_0b02:
																					if (18 < b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0b10;
																					IL_0b10:
																					if (18 > b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0b1e;
																					IL_0b1e:
																					array[num6 - 2] = 16;
																					goto IL_0b32;
																					IL_0b32:
																					array2[num6 - 2] = array2[num6 - 2];
																					goto IL_0b50;
																					IL_0b50:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0b7a;
																					IL_0b7a:
																					array3[num6 - 2] = *(int*)(ptr2 + num3);
																					goto IL_0b93;
																					IL_0b93:
																					ptr2 += 8;
																					goto IL_0ba1;
																					IL_0ba1:
																					num6--;
																					break;
																					IL_0bb4:
																					if (17 > b)
																					{
																						goto end_IL_03f7;
																					}
																					goto IL_0bc2;
																					IL_0bc2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)CookiesgetEndOfStream[*(int*)(ptr2 + num3)])();
																					goto IL_0be6;
																					IL_0be6:
																					array[num6] = 0;
																					goto IL_0bf4;
																					IL_0bf4:
																					num6++;
																					num = 94;
																					goto IL_0c0b;
																					IL_0c0b:
																					ptr2 += 8;
																					num = 41;
																					break;
																					IL_0c27:
																					array2[num6 - 1] = ((delegate*<ref ColorOption, string>)CookiesgetEndOfStream[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref ColorOption>)CookiesgetEndOfStream[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																					goto IL_0c91;
																					IL_0c91:
																					array[num6 - 1] = 5;
																					goto IL_0ca5;
																					IL_0ca5:
																					ptr2 += 8;
																					break;
																					IL_0cb5:
																					if (20 < b)
																					{
																						num = 178;
																						goto IL_0cc9;
																					}
																					goto IL_0cea;
																				}
																				goto end_IL_0407;
																				continue;
																				end_IL_03f7:
																				break;
																				IL_03f7:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0407:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 135;
													goto IL_0dd6;
													IL_0dd6:
													return (string)array2[num6 - 1];
													continue;
													end_IL_0d2a:
													break;
												}
												continue;
												end_IL_0d3d:
												break;
											}
											continue;
											end_IL_0d47:
											break;
										}
										continue;
										end_IL_0d52:
										break;
									}
									continue;
									end_IL_0d62:
									break;
								}
								continue;
								end_IL_0d72:
								break;
							}
							continue;
							end_IL_0d82:
							break;
						}
						continue;
						end_IL_0d92:
						break;
					}
					continue;
					end_IL_0da2:
					break;
				}
				continue;
				end_IL_0db2:
				break;
			}
		}
	}

	public Class135()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class135()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_044d, IL_0460, IL_0473, IL_0483, IL_0490, IL_04a0, IL_04b0, IL_04bd, IL_04cd, IL_04dd, IL_04ed, IL_04f8, IL_050b, IL_0516, IL_0523, IL_053d, IL_0550, IL_055e, IL_056c, IL_0585, IL_0593, IL_05a1, IL_05aa, IL_05b8, IL_05c6, IL_05de, IL_05ec, IL_0608, IL_0640, IL_0653, IL_0666, IL_06a4, IL_06b7, IL_06c5, IL_06d3, IL_06de, IL_06fc, IL_070a, IL_071d, IL_0728, IL_0736, IL_0744, IL_0752, IL_0767, IL_077a, IL_0788, IL_0796, IL_07b3, IL_0802, IL_080c, IL_0839, IL_085b, IL_0869, IL_0874, IL_08b4, IL_08c8, IL_08db, IL_08e9, IL_08f7, IL_0910, IL_091e, IL_092c, IL_093f, IL_094d, IL_095b, IL_0984, IL_099d, IL_09a6, IL_09b1, IL_09c6, IL_09d9, IL_09e7, IL_09f5, IL_0a00, IL_0a0b, IL_0a20, IL_0a33, IL_0a41, IL_0a4f, IL_0a5d, IL_0a6b, IL_0a74, IL_0a87, IL_0aa5, IL_0ab8, IL_0ac3, IL_0ad1, IL_0adf, IL_0af4, IL_0b07, IL_0b12, IL_0b30, IL_0b43, IL_0b51, IL_0b5f, IL_0b74, IL_0b87, IL_0b9f, IL_0bbd, IL_0be1, IL_0bf9, IL_0c0c, IL_0c21, IL_0c3d, IL_0c4b, IL_0c5e, IL_0c7c, IL_0c8f, IL_0c9d, IL_0cb7, IL_0cc5, IL_0cd3, IL_0ce6, IL_0cfa, IL_0d72, IL_0d80, IL_0d93, IL_0da1, IL_0daf, IL_0dc8, IL_0ddb, IL_0df5, IL_0e08, IL_0e16, IL_0e21, IL_0e63, IL_0e76, IL_0e84, IL_0e8f, IL_0e9d, IL_0eab, IL_0ed4, IL_0eed, IL_0f0a, IL_0f82, IL_0f90, IL_0fa3, IL_0fb1, IL_0fbf, IL_0fd3, IL_101f, IL_102d, IL_1040, IL_104b, IL_1059, IL_1067, IL_1083, IL_108c, IL_1097, IL_10a5, IL_10b3, IL_10ca, IL_10ed, IL_10fb, IL_110b, IL_1124, IL_1134, IL_1149, IL_1157, IL_116a, IL_1174, IL_1188, IL_11a1, IL_11b1, IL_11c1, IL_11da, IL_11ea, IL_11fa, IL_121b, IL_1227, IL_122e are reachable both inside and outside the pinned region starting at IL_120f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 205;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 94;
					while (true)
					{
						int num2;
						int num3;
						byte[] array2;
						object[] array3;
						int[] array4;
						long[] array5;
						object[] array6;
						byte* ptr;
						byte* num6;
						int num7;
						object[] array7;
						int num8;
						byte* num9;
						byte* ptr2;
						byte[] array = new byte[4];
						if (true)
						{
							while (true)
							{
								IL_11fa:
								num2 = 1;
								while (true)
								{
									IL_11ea:
									num3 = num2 * 4;
									while (true)
									{
										IL_11da:
										array2 = new byte[8];
										while (true)
										{
											IL_11c1:
											array3 = new object[8];
											num = 187;
											while (true)
											{
												IL_11b1:
												array4 = new int[8];
												while (true)
												{
													IL_11a1:
													array5 = new long[8];
													while (true)
													{
														IL_1188:
														array6 = new object[37];
														num = 97;
														while (true)
														{
															IL_1174:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BatchSidgetSecurityRuleSet.GetArgumentsRCCryptoServiceProvider);
															num = 211;
															while (true)
															{
																IL_116a:
																ptr2 = ptr;
																while (true)
																{
																	IL_1157:
																	if (num4 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_04ed:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_04dd:
																			ptr2++;
																			while (true)
																			{
																				IL_04cd:
																				if (b >= 1)
																				{
																					while (b <= 31)
																					{
																						while (true)
																						{
																							IL_04b0:
																							if (16 < b)
																							{
																								while (true)
																								{
																									IL_04a0:
																									if (24 >= b)
																									{
																										while (true)
																										{
																											IL_0490:
																											if (24 > b)
																											{
																												while (true)
																												{
																													IL_0483:
																													if (20 < b)
																													{
																														while (true)
																														{
																															IL_0473:
																															if (22 >= b)
																															{
																																while (true)
																																{
																																	IL_0460:
																																	if (22 <= b)
																																	{
																																		num = 268;
																																		while (true)
																																		{
																																			if (num != 268)
																																			{
																																				if (num != 1249)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 238:
																																					break;
																																				default:
																																					continue;
																																				case 184:
																																					goto IL_0460;
																																				case 188:
																																					goto IL_0473;
																																				case 260:
																																					goto IL_0483;
																																				case 170:
																																					goto IL_0490;
																																				case 55:
																																					goto IL_04a0;
																																				case 261:
																																					goto IL_04b0;
																																				case 232:
																																					goto IL_04bd;
																																				case 15:
																																					goto IL_04cd;
																																				case 96:
																																					goto IL_04dd;
																																				case 63:
																																				case 259:
																																					goto IL_04ed;
																																				case 21:
																																					goto IL_04f8;
																																				case 33:
																																					goto IL_050b;
																																				case 29:
																																					goto IL_0516;
																																				case 36:
																																				case 56:
																																					goto end_IL_044d;
																																				case 14:
																																					goto IL_053d;
																																				case 73:
																																					goto IL_0550;
																																				case 72:
																																					goto IL_055e;
																																				case 140:
																																				case 149:
																																					goto IL_056c;
																																				case 153:
																																					goto IL_0585;
																																				case 43:
																																					goto IL_0593;
																																				case 113:
																																					goto IL_05aa;
																																				case 91:
																																				case 154:
																																					goto IL_05b8;
																																				case 159:
																																					goto IL_05c6;
																																				case 0:
																																					goto IL_05de;
																																				case 7:
																																					goto IL_05ec;
																																				case 160:
																																					goto IL_0608;
																																				case 86:
																																					goto IL_0640;
																																				case 175:
																																					goto IL_0653;
																																				case 115:
																																				case 214:
																																					goto IL_0666;
																																				case 98:
																																					goto IL_06a4;
																																				case 247:
																																					goto IL_06b7;
																																				case 237:
																																					goto IL_06c5;
																																				case 24:
																																					goto IL_06d3;
																																				case 26:
																																				case 239:
																																					goto IL_06de;
																																				case 216:
																																					goto IL_06fc;
																																				case 1:
																																					goto IL_070a;
																																				case 144:
																																					goto IL_071d;
																																				case 202:
																																					goto IL_0728;
																																				case 130:
																																					goto IL_0736;
																																				case 230:
																																					goto IL_0744;
																																				case 145:
																																				case 189:
																																					goto IL_0752;
																																				case 6:
																																					goto IL_0767;
																																				case 46:
																																					goto IL_077a;
																																				case 17:
																																					goto IL_0788;
																																				case 10:
																																				case 66:
																																					goto IL_0796;
																																				case 90:
																																					goto IL_085b;
																																				case 191:
																																					goto IL_0869;
																																				case 117:
																																				case 186:
																																					goto IL_0874;
																																				case 220:
																																					goto IL_08b4;
																																				case 52:
																																					goto IL_08c8;
																																				case 176:
																																					goto IL_08db;
																																				case 100:
																																					goto IL_08e9;
																																				case 34:
																																				case 76:
																																					goto IL_08f7;
																																				case 16:
																																					goto IL_0910;
																																				case 67:
																																					goto IL_091e;
																																				case 68:
																																					goto IL_092c;
																																				case 79:
																																					goto IL_093f;
																																				case 50:
																																					goto IL_094d;
																																				case 47:
																																				case 161:
																																					goto IL_095b;
																																				case 116:
																																					goto IL_0984;
																																				case 133:
																																					goto IL_09a6;
																																				case 197:
																																				case 217:
																																					goto IL_09b1;
																																				case 212:
																																					goto IL_09c6;
																																				case 165:
																																					goto IL_09d9;
																																				case 112:
																																					goto IL_09e7;
																																				case 121:
																																					goto IL_09f5;
																																				case 123:
																																					goto IL_0a00;
																																				case 157:
																																				case 162:
																																					goto IL_0a0b;
																																				case 12:
																																					goto IL_0a20;
																																				case 35:
																																					goto IL_0a33;
																																				case 142:
																																					goto IL_0a41;
																																				case 180:
																																					goto IL_0a5d;
																																				case 156:
																																					goto IL_0a74;
																																				case 198:
																																				case 219:
																																					goto IL_0a87;
																																				case 25:
																																					goto IL_0aa5;
																																				case 105:
																																					goto IL_0ab8;
																																				case 147:
																																					goto IL_0ac3;
																																				case 134:
																																					goto IL_0ad1;
																																				case 81:
																																				case 114:
																																					goto IL_0adf;
																																				case 151:
																																					goto IL_0af4;
																																				case 4:
																																					goto IL_0b07;
																																				case 64:
																																				case 196:
																																					goto IL_0b12;
																																				case 231:
																																					goto IL_0b30;
																																				case 224:
																																					goto IL_0b43;
																																				case 95:
																																					goto IL_0b51;
																																				case 103:
																																				case 185:
																																					goto IL_0b5f;
																																				case 221:
																																					goto IL_0b74;
																																				case 206:
																																				case 249:
																																					goto IL_0b87;
																																				case 136:
																																					goto IL_0b9f;
																																				case 13:
																																					goto IL_0bbd;
																																				case 80:
																																					goto IL_0be1;
																																				case 54:
																																					goto IL_0bf9;
																																				case 104:
																																				case 253:
																																					goto IL_0c0c;
																																				case 51:
																																					goto IL_0c21;
																																				case 256:
																																					goto IL_0c3d;
																																				case 2:
																																					goto IL_0c4b;
																																				case 240:
																																				case 257:
																																					goto IL_0c5e;
																																				case 168:
																																					goto IL_0c7c;
																																				case 258:
																																					goto IL_0c8f;
																																				case 148:
																																				case 182:
																																					goto IL_0c9d;
																																				case 92:
																																					goto IL_0cb7;
																																				case 242:
																																					goto IL_0cc5;
																																				case 139:
																																					goto IL_0cd3;
																																				case 255:
																																					goto IL_0ce6;
																																				case 226:
																																					goto IL_0cfa;
																																				case 254:
																																					goto IL_0d72;
																																				case 193:
																																					goto IL_0d80;
																																				case 141:
																																					goto IL_0d93;
																																				case 49:
																																					goto IL_0da1;
																																				case 135:
																																				case 179:
																																					goto IL_0daf;
																																				case 57:
																																					goto IL_0dc8;
																																				case 32:
																																				case 40:
																																					goto IL_0ddb;
																																				case 131:
																																					goto IL_0df5;
																																				case 194:
																																					goto IL_0e08;
																																				case 119:
																																					goto IL_0e16;
																																				case 127:
																																				case 155:
																																					goto IL_0e21;
																																				case 111:
																																					goto IL_0e63;
																																				case 37:
																																					goto IL_0e76;
																																				case 44:
																																					goto IL_0e84;
																																				case 20:
																																					goto IL_0e8f;
																																				case 78:
																																					goto IL_0e9d;
																																				case 65:
																																				case 83:
																																					goto IL_0eab;
																																				case 128:
																																					goto IL_0ed4;
																																				case 218:
																																				case 222:
																																					goto IL_0eed;
																																				case 87:
																																					goto IL_0f0a;
																																				case 39:
																																					goto IL_0f82;
																																				case 190:
																																					goto IL_0f90;
																																				case 233:
																																					goto IL_0fa3;
																																				case 59:
																																					goto IL_0fb1;
																																				case 45:
																																				case 208:
																																					goto IL_0fbf;
																																				case 158:
																																					goto IL_0fd3;
																																				case 207:
																																					goto IL_101f;
																																				case 245:
																																					goto IL_102d;
																																				case 227:
																																					goto IL_1040;
																																				case 22:
																																					goto IL_104b;
																																				case 61:
																																					goto IL_1059;
																																				case 42:
																																				case 137:
																																					goto IL_1067;
																																				case 181:
																																					goto IL_108c;
																																				case 38:
																																					goto IL_1097;
																																				case 9:
																																					goto IL_10a5;
																																				case 19:
																																				case 166:
																																					goto IL_10b3;
																																				case 60:
																																					goto IL_10ca;
																																				case 109:
																																					goto IL_10ed;
																																				case 174:
																																					goto IL_10fb;
																																				case 172:
																																				case 192:
																																					goto IL_110b;
																																				case 195:
																																					goto IL_1124;
																																				case 3:
																																				case 5:
																																				case 28:
																																				case 30:
																																				case 31:
																																				case 41:
																																				case 48:
																																				case 62:
																																				case 69:
																																				case 70:
																																				case 82:
																																				case 84:
																																				case 85:
																																				case 99:
																																				case 102:
																																				case 108:
																																				case 118:
																																				case 120:
																																				case 122:
																																				case 143:
																																				case 150:
																																				case 152:
																																				case 171:
																																				case 173:
																																				case 178:
																																				case 183:
																																				case 199:
																																				case 200:
																																				case 201:
																																				case 223:
																																				case 225:
																																				case 234:
																																				case 248:
																																				case 252:
																																					goto end_IL_04bd;
																																				case 246:
																																					goto IL_1149;
																																				case 8:
																																				case 23:
																																				case 27:
																																				case 58:
																																				case 71:
																																				case 74:
																																				case 75:
																																				case 77:
																																				case 88:
																																				case 93:
																																				case 101:
																																				case 107:
																																				case 110:
																																				case 124:
																																				case 132:
																																				case 138:
																																				case 146:
																																				case 163:
																																				case 164:
																																				case 169:
																																				case 177:
																																				case 203:
																																				case 209:
																																				case 210:
																																				case 213:
																																				case 215:
																																				case 235:
																																				case 236:
																																				case 241:
																																				case 243:
																																				case 244:
																																				case 250:
																																				case 251:
																																					goto IL_1157;
																																				case 211:
																																					goto IL_116a;
																																				case 97:
																																					goto IL_1174;
																																				case 53:
																																					goto IL_1188;
																																				case 229:
																																					goto IL_11a1;
																																				case 187:
																																					goto IL_11b1;
																																				case 129:
																																					goto IL_11c1;
																																				case 106:
																																				case 167:
																																					goto IL_11da;
																																				case 18:
																																					goto IL_11ea;
																																				case 228:
																																					goto IL_11fa;
																																				case 94:
																																					break;
																																				case 125:
																																					break;
																																				case 11:
																																					num = 94;
																																					break;
																																				case 204:
																																					Class300.smethod_0();
																																					goto case 11;
																																				case 205:
																																					Class296.Aw4EYyy3h();
																																					goto case 204;
																																				case 89:
																																				case 126:
																																					return;
																																				}
																																				goto end_IL_0483;
																																			}
																																			goto IL_0ce6;
																																			IL_0d72:
																																			num5 -= 3;
																																			goto IL_0d80;
																																			IL_0d80:
																																			ptr2 += 8;
																																			goto IL_1157;
																																			IL_0ce6:
																																			array2[num5 - 4] = 5;
																																			goto IL_0cfa;
																																			IL_0cfa:
																																			array3[num5 - 4] = ((delegate*<float, float, float, float, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																																			goto IL_0d72;
																																			continue;
																																			end_IL_044d:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_0653;
																																	IL_0cc5:
																																	num5++;
																																	goto IL_0cd3;
																																	IL_0cd3:
																																	ptr2 += 8;
																																	goto IL_1157;
																																	IL_0653:
																																	if (21 < b)
																																	{
																																		goto end_IL_04bd;
																																	}
																																	goto IL_0c8f;
																																	IL_0c8f:
																																	if (21 > b)
																																	{
																																		goto end_IL_04bd;
																																	}
																																	goto IL_0c9d;
																																	IL_0c9d:
																																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																																	goto IL_0cb7;
																																	IL_0cb7:
																																	array2[num5] = 3;
																																	goto IL_0cc5;
																																}
																																break;
																															}
																															goto IL_0d93;
																															IL_0dc8:
																															num5--;
																															goto IL_1157;
																															IL_0d93:
																															if (23 < b)
																															{
																																goto end_IL_04bd;
																															}
																															goto IL_0da1;
																															IL_0da1:
																															if (23 > b)
																															{
																																goto end_IL_04bd;
																															}
																															goto IL_0daf;
																															IL_0daf:
																															color_0 = (Color)array3[num5 - 1];
																															goto IL_0dc8;
																														}
																														goto IL_0523;
																													}
																													goto IL_050b;
																													IL_0523:
																													int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																													goto IL_053d;
																													IL_050b:
																													if (20 > b)
																													{
																														goto IL_0516;
																													}
																													goto IL_0523;
																													IL_0516:
																													if (18 < b)
																													{
																														goto IL_0550;
																													}
																													goto IL_0585;
																													IL_0585:
																													if (18 > b)
																													{
																														goto IL_0593;
																													}
																													goto IL_0666;
																													IL_0593:
																													if (17 < b)
																													{
																														goto end_IL_04bd;
																													}
																													num = 113;
																													goto IL_05aa;
																													IL_053d:
																													num5--;
																													goto IL_1157;
																													IL_05aa:
																													if (17 > b)
																													{
																														goto end_IL_04bd;
																													}
																													goto IL_05b8;
																													IL_05b8:
																													array2[num5] = 5;
																													goto IL_05c6;
																													IL_05c6:
																													array3[num5] = array6[*(int*)(ptr2 + num3)];
																													goto IL_05de;
																													IL_05de:
																													num5++;
																													goto IL_05ec;
																													IL_05ec:
																													ptr2 += 8;
																													num = 27;
																													goto IL_1157;
																													IL_0666:
																													((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																													goto IL_06a4;
																													IL_06a4:
																													num5 -= 3;
																													goto IL_1157;
																													IL_0550:
																													if (19 < b)
																													{
																														goto end_IL_04bd;
																													}
																													goto IL_055e;
																													IL_055e:
																													if (19 > b)
																													{
																														goto end_IL_04bd;
																													}
																													goto IL_056c;
																													IL_056c:
																													array2[num5 - 1] = 5;
																													goto IL_0608;
																													IL_0608:
																													array3[num5 - 1] = ((delegate*<string[], string>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																													goto IL_0640;
																													IL_0640:
																													ptr2 += 8;
																													goto IL_1157;
																													continue;
																													end_IL_0483:
																													break;
																												}
																												break;
																											}
																											goto IL_0ddb;
																											IL_0df5:
																											num5--;
																											goto IL_1157;
																											IL_0ddb:
																											bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0;
																											goto IL_0df5;
																										}
																										break;
																									}
																									goto IL_0e08;
																									IL_110b:
																									colorOption_0 = (ColorOption[])array3[num5 - 1];
																									goto IL_1124;
																									IL_0e08:
																									if (28 >= b)
																									{
																										goto IL_0e16;
																									}
																									goto IL_1040;
																									IL_0e16:
																									if (28 <= b)
																									{
																										goto IL_0e21;
																									}
																									goto IL_0e76;
																									IL_0e21:
																									((ColorOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (ColorOption)array3[num5 - 1];
																									goto IL_0e63;
																									IL_0e63:
																									num5 -= 3;
																									goto IL_1157;
																									IL_0e76:
																									if (26 >= b)
																									{
																										goto IL_0e84;
																									}
																									goto IL_0fa3;
																									IL_0e84:
																									if (26 > b)
																									{
																										goto IL_0e8f;
																									}
																									goto IL_0eed;
																									IL_0e8f:
																									if (25 < b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_0e9d;
																									IL_0e9d:
																									if (25 > b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_0eab;
																									IL_0eab:
																									array3[num5 - 1] = new ColorOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																									goto IL_0ed4;
																									IL_0ed4:
																									array2[num5 - 1] = 5;
																									goto IL_1157;
																									IL_0eed:
																									array2[num5 - 4] = 5;
																									num = 87;
																									goto IL_0f0a;
																									IL_0f0a:
																									array3[num5 - 4] = ((delegate*<float, float, float, float, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																									goto IL_0f82;
																									IL_0f82:
																									num5 -= 3;
																									goto IL_0f90;
																									IL_0f90:
																									ptr2 += 8;
																									goto IL_1157;
																									IL_0fa3:
																									if (27 < b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_0fb1;
																									IL_0fb1:
																									if (27 > b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_0fbf;
																									IL_0fbf:
																									array2[num5 - 2] = 5;
																									goto IL_0fd3;
																									IL_0fd3:
																									array3[num5 - 2] = ((delegate*<string, Color, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (Color)array3[num5 - 1]);
																									goto IL_101f;
																									IL_101f:
																									num5--;
																									goto IL_102d;
																									IL_102d:
																									ptr2 += 8;
																									goto IL_1157;
																									IL_1040:
																									if (30 < b)
																									{
																										goto IL_104b;
																									}
																									num = 181;
																									goto IL_108c;
																									IL_104b:
																									if (31 < b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_1059;
																									IL_1059:
																									if (31 > b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_1067;
																									IL_1067:
																									num6 = ptr2;
																									num7 = -200;
																									num4 = 1;
																									ptr2 = num6 + num7;
																									goto IL_1157;
																									IL_1124:
																									num5--;
																									goto IL_1157;
																									IL_108c:
																									if (30 > b)
																									{
																										goto IL_1097;
																									}
																									goto IL_110b;
																									IL_1097:
																									if (29 < b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_10a5;
																									IL_10a5:
																									if (29 > b)
																									{
																										goto end_IL_04bd;
																									}
																									goto IL_10b3;
																									IL_10b3:
																									array2[num5] = 4;
																									num = 60;
																									goto IL_10ca;
																									IL_10ca:
																									array3[num5] = ((delegate*<Color>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																									goto IL_10ed;
																									IL_10ed:
																									num5++;
																									goto IL_10fb;
																									IL_10fb:
																									ptr2 += 8;
																									goto IL_1157;
																								}
																								break;
																							}
																							goto IL_04f8;
																							IL_0b07:
																							if (6 <= b)
																							{
																								goto IL_0b12;
																							}
																							goto IL_0b43;
																							IL_04f8:
																							if (16 > b)
																							{
																								goto IL_06b7;
																							}
																							goto IL_0b87;
																							IL_0b87:
																							array2[num5] = array2[num5 - 1];
																							goto IL_0b9f;
																							IL_0b9f:
																							array4[num5 - 0] = array4[num5 - 1];
																							goto IL_0bbd;
																							IL_0bbd:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																							goto IL_0be1;
																							IL_0be1:
																							array3[num5] = array3[num5 - 1];
																							goto IL_0bf9;
																							IL_0bf9:
																							num5++;
																							goto IL_1157;
																							IL_06b7:
																							if (8 < b)
																							{
																								goto IL_06c5;
																							}
																							num = 133;
																							goto IL_09a6;
																							IL_06c5:
																							if (12 >= b)
																							{
																								goto IL_06d3;
																							}
																							goto IL_085b;
																							IL_06d3:
																							if (12 <= b)
																							{
																								goto IL_06de;
																							}
																							goto IL_071d;
																							IL_06de:
																							array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																							goto IL_06fc;
																							IL_06fc:
																							ptr2 += 8;
																							goto IL_070a;
																							IL_070a:
																							num5--;
																							goto IL_1157;
																							IL_071d:
																							if (10 >= b)
																							{
																								goto IL_0728;
																							}
																							goto IL_077a;
																							IL_0728:
																							if (10 > b)
																							{
																								goto IL_0736;
																							}
																							goto IL_0c0c;
																							IL_0736:
																							if (9 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0744;
																							IL_0744:
																							if (9 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0752;
																							IL_0752:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_0767;
																							IL_0767:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0c0c:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_0c21;
																							IL_0c21:
																							ptr2 += 8;
																							num = 164;
																							goto IL_1157;
																							IL_077a:
																							if (11 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0788;
																							IL_0788:
																							if (11 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0796;
																							IL_0796:
																							array7 = array3;
																							num8 = num5;
																							if (array == null)
																							{
																								goto IL_07a5;
																							}
																							num9 = ptr2;
																							byte b2 = *num9;
																							ptr2 = num9 + 4;
																							int num10 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num10;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							num = 256;
																							goto IL_0c3d;
																							IL_0b30:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0b43:
																							if (5 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0b51;
																							IL_0b51:
																							if (5 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0b5f;
																							IL_0c3d:
																							array2[num5] = 5;
																							goto IL_0c4b;
																							IL_0c4b:
																							num5++;
																							goto IL_1157;
																							IL_085b:
																							if (14 >= b)
																							{
																								goto IL_0869;
																							}
																							goto IL_093f;
																							IL_0869:
																							if (14 <= b)
																							{
																								goto IL_0874;
																							}
																							goto IL_08db;
																							IL_0874:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																							goto IL_08b4;
																							IL_08b4:
																							array2[num5 - 2] = 0;
																							goto IL_08c8;
																							IL_08c8:
																							num5--;
																							goto IL_1157;
																							IL_08db:
																							if (13 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_08e9;
																							IL_08e9:
																							if (13 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_08f7;
																							IL_08f7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0910;
																							IL_0910:
																							array2[num5] = 0;
																							goto IL_091e;
																							IL_091e:
																							num5++;
																							goto IL_092c;
																							IL_092c:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_093f:
																							if (15 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_094d;
																							IL_094d:
																							if (15 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_095b;
																							IL_095b:
																							array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																							goto IL_0984;
																							IL_0984:
																							array2[num5 - 1] = 5;
																							goto IL_1157;
																							IL_0b12:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							num = 231;
																							goto IL_0b30;
																							IL_09a6:
																							if (8 <= b)
																							{
																								goto IL_09b1;
																							}
																							goto IL_09d9;
																							IL_09b1:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_09c6;
																							IL_09c6:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_09d9:
																							if (4 >= b)
																							{
																								goto IL_09e7;
																							}
																							goto IL_0ab8;
																							IL_09e7:
																							if (4 > b)
																							{
																								goto IL_09f5;
																							}
																							goto IL_0a87;
																							IL_09f5:
																							if (2 >= b)
																							{
																								goto IL_0a00;
																							}
																							goto IL_0a5d;
																							IL_0a00:
																							if (2 <= b)
																							{
																								goto IL_0a0b;
																							}
																							goto IL_0a33;
																							IL_0a0b:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_0a20;
																							IL_0a20:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0a33:
																							if (1 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0a41;
																							IL_0a41:
																							if (1 <= b)
																							{
																								num = 252;
																							}
																							goto end_IL_04bd;
																							IL_0b5f:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_0b74;
																							IL_0a5d:
																							if (3 < b)
																							{
																								goto end_IL_04bd;
																							}
																							num = 156;
																							goto IL_0a74;
																							IL_0b74:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0a74:
																							if (3 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0c5e;
																							IL_0c5e:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							num = 168;
																							goto IL_0c7c;
																							IL_0c7c:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0a87:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							num = 25;
																							goto IL_0aa5;
																							IL_0aa5:
																							ptr2 += 8;
																							goto IL_1157;
																							IL_0ab8:
																							if (6 < b)
																							{
																								goto IL_0ac3;
																							}
																							goto IL_0b07;
																							IL_0ac3:
																							if (7 < b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0ad1;
																							IL_0ad1:
																							if (7 > b)
																							{
																								goto end_IL_04bd;
																							}
																							goto IL_0adf;
																							IL_0adf:
																							((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																							goto IL_0af4;
																							IL_0af4:
																							ptr2 += 8;
																							goto IL_1157;
																						}
																						goto end_IL_04cd;
																						continue;
																						end_IL_04bd:
																						break;
																						IL_04bd:;
																					}
																				}
																				((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																				goto IL_1149;
																				IL_1149:
																				ptr2 += 8;
																				goto IL_1157;
																				continue;
																				end_IL_04cd:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
						}
						continue;
						IL_07a5:
						while (true)
						{
							IL_07a5_2:
							array = new byte[4];
							while (true)
							{
								IL_07b3:
								num9 = ptr2;
								byte b2 = *num9;
								ptr2 = num9 + 4;
								int num10 = *(int*)(ptr2 + num3);
								ptr2 += 8;
								byte* ptr3 = ptr2 + num10;
								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
								while (ptr2 != ptr3)
								{
									*ptr4 = (byte)(*ptr2 ^ b2);
									ptr2++;
									ptr4++;
								}
								array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
								num = 256;
								while (true)
								{
									array2[num5] = 5;
									while (true)
									{
										IL_0c4b_2:
										num5++;
										while (true)
										{
											IL_1157_2:
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_04cd_2:
														if (b >= 1)
														{
															while (b <= 31)
															{
																while (true)
																{
																	if (16 < b)
																	{
																		while (true)
																		{
																			if (24 >= b)
																			{
																				while (true)
																				{
																					if (24 > b)
																					{
																						while (true)
																						{
																							IL_0483_2:
																							if (20 < b)
																							{
																								while (true)
																								{
																									IL_0473_2:
																									if (22 >= b)
																									{
																										while (true)
																										{
																											IL_0460_2:
																											if (22 <= b)
																											{
																												num = 268;
																												while (true)
																												{
																													if (num != 268)
																													{
																														if (num != 1249)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 184:
																															goto IL_0460_2;
																														case 188:
																															goto IL_0473_2;
																														case 260:
																															goto IL_0483_2;
																														case 170:
																															goto end_IL_0483_2;
																														case 55:
																															goto end_IL_0490;
																														case 261:
																															goto end_IL_04a0;
																														case 232:
																															goto end_IL_04b0;
																														case 15:
																															goto IL_04cd_2;
																														case 96:
																															goto end_IL_04cd_2;
																														case 63:
																														case 259:
																															goto end_IL_04dd;
																														case 21:
																															goto IL_04f8_2;
																														case 33:
																															goto IL_050b_2;
																														case 29:
																															goto IL_0516_2;
																														case 36:
																														case 56:
																															goto end_IL_044d_2;
																														case 14:
																															goto IL_053d_2;
																														case 73:
																															goto IL_0550_2;
																														case 72:
																															goto IL_055e_2;
																														case 140:
																														case 149:
																															goto IL_056c_2;
																														case 153:
																															goto IL_0585_2;
																														case 43:
																															goto IL_0593_2;
																														case 113:
																															goto IL_05aa_2;
																														case 91:
																														case 154:
																															goto IL_05b8_2;
																														case 159:
																															goto IL_05c6_2;
																														case 0:
																															goto IL_05de_2;
																														case 7:
																															goto IL_05ec_2;
																														case 160:
																															goto IL_0608_2;
																														case 86:
																															goto IL_0640_2;
																														case 175:
																															goto IL_0653_2;
																														case 115:
																														case 214:
																															goto IL_0666_2;
																														case 98:
																															goto IL_06a4_2;
																														case 247:
																															goto IL_06b7_2;
																														case 237:
																															goto IL_06c5_2;
																														case 24:
																															goto IL_06d3_2;
																														case 26:
																														case 239:
																															goto IL_06de_2;
																														case 216:
																															goto IL_06fc_2;
																														case 1:
																															goto IL_070a_2;
																														case 144:
																															goto IL_071d_2;
																														case 202:
																															goto IL_0728_2;
																														case 130:
																															goto IL_0736_2;
																														case 230:
																															goto IL_0744_2;
																														case 145:
																														case 189:
																															goto IL_0752_2;
																														case 6:
																															goto IL_0767_2;
																														case 46:
																															goto IL_077a_2;
																														case 17:
																															goto IL_0788_2;
																														case 10:
																														case 66:
																															goto IL_0796_2;
																														case 90:
																															goto IL_085b_2;
																														case 191:
																															goto IL_0869_2;
																														case 117:
																														case 186:
																															goto IL_0874_2;
																														case 220:
																															goto IL_08b4_2;
																														case 52:
																															goto IL_08c8_2;
																														case 176:
																															goto IL_08db_2;
																														case 100:
																															goto IL_08e9_2;
																														case 34:
																														case 76:
																															goto IL_08f7_2;
																														case 16:
																															goto IL_0910_2;
																														case 67:
																															goto IL_091e_2;
																														case 68:
																															goto IL_092c_2;
																														case 79:
																															goto IL_093f_2;
																														case 50:
																															goto IL_094d_2;
																														case 47:
																														case 161:
																															goto IL_095b_2;
																														case 116:
																															goto IL_0984_2;
																														case 133:
																															goto IL_09a6_2;
																														case 197:
																														case 217:
																															goto IL_09b1_2;
																														case 212:
																															goto IL_09c6_2;
																														case 165:
																															goto IL_09d9_2;
																														case 112:
																															goto IL_09e7_2;
																														case 121:
																															goto IL_09f5_2;
																														case 123:
																															goto IL_0a00_2;
																														case 157:
																														case 162:
																															goto IL_0a0b_2;
																														case 12:
																															goto IL_0a20_2;
																														case 35:
																															goto IL_0a33_2;
																														case 142:
																															goto IL_0a41_2;
																														case 180:
																															goto IL_0a5d_2;
																														case 156:
																															goto IL_0a74_2;
																														case 198:
																														case 219:
																															goto IL_0a87_2;
																														case 25:
																															goto IL_0aa5_2;
																														case 105:
																															goto IL_0ab8_2;
																														case 147:
																															goto IL_0ac3_2;
																														case 134:
																															goto IL_0ad1_2;
																														case 81:
																														case 114:
																															goto IL_0adf_2;
																														case 151:
																															goto IL_0af4_2;
																														case 4:
																															goto IL_0b07_2;
																														case 64:
																														case 196:
																															goto IL_0b12_2;
																														case 231:
																															goto IL_0b30_2;
																														case 224:
																															goto IL_0b43_2;
																														case 95:
																															goto IL_0b51_2;
																														case 103:
																														case 185:
																															goto IL_0b5f_2;
																														case 221:
																															goto IL_0b74_2;
																														case 206:
																														case 249:
																															goto IL_0b87_2;
																														case 136:
																															goto IL_0b9f_2;
																														case 13:
																															goto IL_0bbd_2;
																														case 80:
																															goto IL_0be1_2;
																														case 54:
																															goto IL_0bf9_2;
																														case 104:
																														case 253:
																															goto IL_0c0c_2;
																														case 51:
																															goto IL_0c21_2;
																														case 256:
																															goto end_IL_04ed;
																														case 2:
																															goto IL_0c4b_2;
																														case 240:
																														case 257:
																															goto IL_0c5e_2;
																														case 168:
																															goto IL_0c7c_2;
																														case 258:
																															goto IL_0c8f_2;
																														case 148:
																														case 182:
																															goto IL_0c9d_2;
																														case 92:
																															goto IL_0cb7_2;
																														case 242:
																															goto IL_0cc5_2;
																														case 139:
																															goto IL_0cd3_2;
																														case 255:
																															goto IL_0ce6_2;
																														case 226:
																															goto IL_0cfa_2;
																														case 254:
																															goto IL_0d72_2;
																														case 193:
																															goto IL_0d80_2;
																														case 141:
																															goto IL_0d93_2;
																														case 49:
																															goto IL_0da1_2;
																														case 135:
																														case 179:
																															goto IL_0daf_2;
																														case 57:
																															goto IL_0dc8_2;
																														case 32:
																														case 40:
																															goto IL_0ddb_2;
																														case 131:
																															goto IL_0df5_2;
																														case 194:
																															goto IL_0e08_2;
																														case 119:
																															goto IL_0e16_2;
																														case 127:
																														case 155:
																															goto IL_0e21_2;
																														case 111:
																															goto IL_0e63_2;
																														case 37:
																															goto IL_0e76_2;
																														case 44:
																															goto IL_0e84_2;
																														case 20:
																															goto IL_0e8f_2;
																														case 78:
																															goto IL_0e9d_2;
																														case 65:
																														case 83:
																															goto IL_0eab_2;
																														case 128:
																															goto IL_0ed4_2;
																														case 218:
																														case 222:
																															goto IL_0eed_2;
																														case 87:
																															goto IL_0f0a_2;
																														case 39:
																															goto IL_0f82_2;
																														case 190:
																															goto IL_0f90_2;
																														case 233:
																															goto IL_0fa3_2;
																														case 59:
																															goto IL_0fb1_2;
																														case 45:
																														case 208:
																															goto IL_0fbf_2;
																														case 158:
																															goto IL_0fd3_2;
																														case 207:
																															goto IL_101f_2;
																														case 245:
																															goto IL_102d_2;
																														case 227:
																															goto IL_1040_2;
																														case 22:
																															goto IL_104b_2;
																														case 61:
																															goto IL_1059_2;
																														case 42:
																														case 137:
																															goto IL_1067_2;
																														case 181:
																															goto IL_108c_2;
																														case 38:
																															goto IL_1097_2;
																														case 9:
																															goto IL_10a5_2;
																														case 19:
																														case 166:
																															goto IL_10b3_2;
																														case 60:
																															goto IL_10ca_2;
																														case 109:
																															goto IL_10ed_2;
																														case 174:
																															goto IL_10fb_2;
																														case 172:
																														case 192:
																															goto IL_110b_2;
																														case 195:
																															goto IL_1124_2;
																														case 3:
																														case 5:
																														case 28:
																														case 30:
																														case 31:
																														case 41:
																														case 48:
																														case 62:
																														case 69:
																														case 70:
																														case 82:
																														case 84:
																														case 85:
																														case 99:
																														case 102:
																														case 108:
																														case 118:
																														case 120:
																														case 122:
																														case 143:
																														case 150:
																														case 152:
																														case 171:
																														case 173:
																														case 178:
																														case 183:
																														case 199:
																														case 200:
																														case 201:
																														case 223:
																														case 225:
																														case 234:
																														case 248:
																														case 252:
																															goto end_IL_04bd_2;
																														case 246:
																															goto IL_1149_2;
																														case 8:
																														case 23:
																														case 27:
																														case 58:
																														case 71:
																														case 74:
																														case 75:
																														case 77:
																														case 88:
																														case 93:
																														case 101:
																														case 107:
																														case 110:
																														case 124:
																														case 132:
																														case 138:
																														case 146:
																														case 163:
																														case 164:
																														case 169:
																														case 177:
																														case 203:
																														case 209:
																														case 210:
																														case 213:
																														case 215:
																														case 235:
																														case 236:
																														case 241:
																														case 243:
																														case 244:
																														case 250:
																														case 251:
																															goto IL_1157_2;
																														case 211:
																															ptr2 = ptr;
																															goto IL_1157_2;
																														case 97:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BatchSidgetSecurityRuleSet.GetArgumentsRCCryptoServiceProvider);
																															num = 211;
																															goto case 211;
																														case 53:
																															array6 = new object[37];
																															num = 97;
																															goto case 97;
																														case 229:
																															array5 = new long[8];
																															goto case 53;
																														case 187:
																															array4 = new int[8];
																															goto case 229;
																														case 129:
																															array3 = new object[8];
																															num = 187;
																															goto case 187;
																														case 106:
																														case 167:
																															array2 = new byte[8];
																															goto case 129;
																														case 18:
																															num3 = num2 * 4;
																															goto case 106;
																														case 228:
																															num2 = 1;
																															goto case 18;
																														case 94:
																														case 125:
																														case 238:
																															goto end_IL_0c3d;
																														case 11:
																															goto end_IL_1205;
																														case 204:
																															goto end_IL_121b;
																														case 205:
																															goto end_IL_1227;
																														case 89:
																														case 126:
																															return;
																														}
																														continue;
																													}
																													goto IL_0ce6_2;
																													IL_0d72_2:
																													num5 -= 3;
																													goto IL_0d80_2;
																													IL_0d80_2:
																													ptr2 += 8;
																													goto IL_1157_2;
																													IL_0ce6_2:
																													array2[num5 - 4] = 5;
																													goto IL_0cfa_2;
																													IL_0cfa_2:
																													array3[num5 - 4] = ((delegate*<float, float, float, float, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																													goto IL_0d72_2;
																													continue;
																													end_IL_044d_2:
																													break;
																												}
																												break;
																											}
																											goto IL_0653_2;
																											IL_0cc5_2:
																											num5++;
																											goto IL_0cd3_2;
																											IL_0cd3_2:
																											ptr2 += 8;
																											goto IL_1157_2;
																											IL_0653_2:
																											if (21 < b)
																											{
																												goto end_IL_04bd_2;
																											}
																											goto IL_0c8f_2;
																											IL_0c8f_2:
																											if (21 > b)
																											{
																												goto end_IL_04bd_2;
																											}
																											goto IL_0c9d_2;
																											IL_0c9d_2:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																											goto IL_0cb7_2;
																											IL_0cb7_2:
																											array2[num5] = 3;
																											goto IL_0cc5_2;
																										}
																										break;
																									}
																									goto IL_0d93_2;
																									IL_0dc8_2:
																									num5--;
																									goto IL_1157_2;
																									IL_0d93_2:
																									if (23 < b)
																									{
																										goto end_IL_04bd_2;
																									}
																									goto IL_0da1_2;
																									IL_0da1_2:
																									if (23 > b)
																									{
																										goto end_IL_04bd_2;
																									}
																									goto IL_0daf_2;
																									IL_0daf_2:
																									color_0 = (Color)array3[num5 - 1];
																									goto IL_0dc8_2;
																								}
																								goto IL_0523_2;
																							}
																							goto IL_050b_2;
																							IL_0523_2:
																							int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																							goto IL_053d_2;
																							IL_050b_2:
																							if (20 > b)
																							{
																								goto IL_0516_2;
																							}
																							goto IL_0523_2;
																							IL_0516_2:
																							if (18 < b)
																							{
																								goto IL_0550_2;
																							}
																							goto IL_0585_2;
																							IL_0585_2:
																							if (18 > b)
																							{
																								goto IL_0593_2;
																							}
																							goto IL_0666_2;
																							IL_0593_2:
																							if (17 < b)
																							{
																								goto end_IL_04bd_2;
																							}
																							num = 113;
																							goto IL_05aa_2;
																							IL_053d_2:
																							num5--;
																							goto IL_1157_2;
																							IL_05aa_2:
																							if (17 > b)
																							{
																								goto end_IL_04bd_2;
																							}
																							goto IL_05b8_2;
																							IL_05b8_2:
																							array2[num5] = 5;
																							goto IL_05c6_2;
																							IL_05c6_2:
																							array3[num5] = array6[*(int*)(ptr2 + num3)];
																							goto IL_05de_2;
																							IL_05de_2:
																							num5++;
																							goto IL_05ec_2;
																							IL_05ec_2:
																							ptr2 += 8;
																							num = 27;
																							goto IL_1157_2;
																							IL_0666_2:
																							((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																							goto IL_06a4_2;
																							IL_06a4_2:
																							num5 -= 3;
																							goto IL_1157_2;
																							IL_0550_2:
																							if (19 < b)
																							{
																								goto end_IL_04bd_2;
																							}
																							goto IL_055e_2;
																							IL_055e_2:
																							if (19 > b)
																							{
																								goto end_IL_04bd_2;
																							}
																							goto IL_056c_2;
																							IL_056c_2:
																							array2[num5 - 1] = 5;
																							goto IL_0608_2;
																							IL_0608_2:
																							array3[num5 - 1] = ((delegate*<string[], string>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																							goto IL_0640_2;
																							IL_0640_2:
																							ptr2 += 8;
																							goto IL_1157_2;
																							continue;
																							end_IL_0483_2:
																							break;
																						}
																						continue;
																					}
																					goto IL_0ddb_2;
																					IL_0df5_2:
																					num5--;
																					goto IL_1157_2;
																					IL_0ddb_2:
																					bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0;
																					goto IL_0df5_2;
																					continue;
																					end_IL_0490:
																					break;
																				}
																				continue;
																			}
																			goto IL_0e08_2;
																			IL_110b_2:
																			colorOption_0 = (ColorOption[])array3[num5 - 1];
																			goto IL_1124_2;
																			IL_0e08_2:
																			if (28 >= b)
																			{
																				goto IL_0e16_2;
																			}
																			goto IL_1040_2;
																			IL_0e16_2:
																			if (28 <= b)
																			{
																				goto IL_0e21_2;
																			}
																			goto IL_0e76_2;
																			IL_0e21_2:
																			((ColorOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (ColorOption)array3[num5 - 1];
																			goto IL_0e63_2;
																			IL_0e63_2:
																			num5 -= 3;
																			goto IL_1157_2;
																			IL_0e76_2:
																			if (26 >= b)
																			{
																				goto IL_0e84_2;
																			}
																			goto IL_0fa3_2;
																			IL_0e84_2:
																			if (26 > b)
																			{
																				goto IL_0e8f_2;
																			}
																			goto IL_0eed_2;
																			IL_0e8f_2:
																			if (25 < b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_0e9d_2;
																			IL_0e9d_2:
																			if (25 > b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_0eab_2;
																			IL_0eab_2:
																			array3[num5 - 1] = new ColorOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																			goto IL_0ed4_2;
																			IL_0ed4_2:
																			array2[num5 - 1] = 5;
																			goto IL_1157_2;
																			IL_0eed_2:
																			array2[num5 - 4] = 5;
																			num = 87;
																			goto IL_0f0a_2;
																			IL_0f0a_2:
																			array3[num5 - 4] = ((delegate*<float, float, float, float, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																			goto IL_0f82_2;
																			IL_0f82_2:
																			num5 -= 3;
																			goto IL_0f90_2;
																			IL_0f90_2:
																			ptr2 += 8;
																			goto IL_1157_2;
																			IL_0fa3_2:
																			if (27 < b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_0fb1_2;
																			IL_0fb1_2:
																			if (27 > b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_0fbf_2;
																			IL_0fbf_2:
																			array2[num5 - 2] = 5;
																			goto IL_0fd3_2;
																			IL_0fd3_2:
																			array3[num5 - 2] = ((delegate*<string, Color, object>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (Color)array3[num5 - 1]);
																			goto IL_101f_2;
																			IL_101f_2:
																			num5--;
																			goto IL_102d_2;
																			IL_102d_2:
																			ptr2 += 8;
																			goto IL_1157_2;
																			IL_1040_2:
																			if (30 < b)
																			{
																				goto IL_104b_2;
																			}
																			num = 181;
																			goto IL_108c_2;
																			IL_104b_2:
																			if (31 < b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_1059_2;
																			IL_1059_2:
																			if (31 > b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_1067_2;
																			IL_1067_2:
																			num6 = ptr2;
																			num7 = -200;
																			num4 = 1;
																			ptr2 = num6 + num7;
																			goto IL_1157_2;
																			IL_1124_2:
																			num5--;
																			goto IL_1157_2;
																			IL_108c_2:
																			if (30 > b)
																			{
																				goto IL_1097_2;
																			}
																			goto IL_110b_2;
																			IL_1097_2:
																			if (29 < b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_10a5_2;
																			IL_10a5_2:
																			if (29 > b)
																			{
																				goto end_IL_04bd_2;
																			}
																			goto IL_10b3_2;
																			IL_10b3_2:
																			array2[num5] = 4;
																			num = 60;
																			goto IL_10ca_2;
																			IL_10ca_2:
																			array3[num5] = ((delegate*<Color>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																			goto IL_10ed_2;
																			IL_10ed_2:
																			num5++;
																			goto IL_10fb_2;
																			IL_10fb_2:
																			ptr2 += 8;
																			goto IL_1157_2;
																			continue;
																			end_IL_04a0:
																			break;
																		}
																		continue;
																	}
																	goto IL_04f8_2;
																	IL_0b43_2:
																	if (5 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0b51_2;
																	IL_04f8_2:
																	if (16 > b)
																	{
																		goto IL_06b7_2;
																	}
																	goto IL_0b87_2;
																	IL_0b87_2:
																	array2[num5] = array2[num5 - 1];
																	goto IL_0b9f_2;
																	IL_0b9f_2:
																	array4[num5 - 0] = array4[num5 - 1];
																	goto IL_0bbd_2;
																	IL_0bbd_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_0be1_2;
																	IL_0be1_2:
																	array3[num5] = array3[num5 - 1];
																	goto IL_0bf9_2;
																	IL_0bf9_2:
																	num5++;
																	goto IL_1157_2;
																	IL_06b7_2:
																	if (8 < b)
																	{
																		goto IL_06c5_2;
																	}
																	num = 133;
																	goto IL_09a6_2;
																	IL_06c5_2:
																	if (12 >= b)
																	{
																		goto IL_06d3_2;
																	}
																	goto IL_085b_2;
																	IL_06d3_2:
																	if (12 <= b)
																	{
																		goto IL_06de_2;
																	}
																	goto IL_071d_2;
																	IL_06de_2:
																	array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_06fc_2;
																	IL_06fc_2:
																	ptr2 += 8;
																	goto IL_070a_2;
																	IL_070a_2:
																	num5--;
																	goto IL_1157_2;
																	IL_071d_2:
																	if (10 >= b)
																	{
																		goto IL_0728_2;
																	}
																	goto IL_077a_2;
																	IL_0728_2:
																	if (10 > b)
																	{
																		goto IL_0736_2;
																	}
																	goto IL_0c0c_2;
																	IL_0736_2:
																	if (9 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0744_2;
																	IL_0744_2:
																	if (9 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0752_2;
																	IL_0752_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_0767_2;
																	IL_0767_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0c0c_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_0c21_2;
																	IL_0c21_2:
																	ptr2 += 8;
																	num = 164;
																	goto IL_1157_2;
																	IL_077a_2:
																	if (11 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0788_2;
																	IL_0788_2:
																	if (11 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0796_2;
																	IL_0796_2:
																	array7 = array3;
																	num8 = num5;
																	if (array == null)
																	{
																		goto IL_07a5_2;
																	}
																	goto IL_07b3;
																	IL_085b_2:
																	if (14 >= b)
																	{
																		goto IL_0869_2;
																	}
																	goto IL_093f_2;
																	IL_0869_2:
																	if (14 <= b)
																	{
																		goto IL_0874_2;
																	}
																	goto IL_08db_2;
																	IL_0874_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_08b4_2;
																	IL_08b4_2:
																	array2[num5 - 2] = 0;
																	goto IL_08c8_2;
																	IL_08c8_2:
																	num5--;
																	goto IL_1157_2;
																	IL_08db_2:
																	if (13 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_08e9_2;
																	IL_08e9_2:
																	if (13 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_08f7_2;
																	IL_08f7_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0910_2;
																	IL_0910_2:
																	array2[num5] = 0;
																	goto IL_091e_2;
																	IL_091e_2:
																	num5++;
																	goto IL_092c_2;
																	IL_092c_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_093f_2:
																	if (15 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_094d_2;
																	IL_094d_2:
																	if (15 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_095b_2;
																	IL_095b_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																	goto IL_0984_2;
																	IL_0984_2:
																	array2[num5 - 1] = 5;
																	goto IL_1157_2;
																	IL_0b51_2:
																	if (5 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0b5f_2;
																	IL_09a6_2:
																	if (8 <= b)
																	{
																		goto IL_09b1_2;
																	}
																	goto IL_09d9_2;
																	IL_09b1_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_09c6_2;
																	IL_09c6_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_09d9_2:
																	if (4 >= b)
																	{
																		goto IL_09e7_2;
																	}
																	goto IL_0ab8_2;
																	IL_09e7_2:
																	if (4 > b)
																	{
																		goto IL_09f5_2;
																	}
																	goto IL_0a87_2;
																	IL_09f5_2:
																	if (2 >= b)
																	{
																		goto IL_0a00_2;
																	}
																	goto IL_0a5d_2;
																	IL_0a00_2:
																	if (2 <= b)
																	{
																		goto IL_0a0b_2;
																	}
																	goto IL_0a33_2;
																	IL_0a0b_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_0a20_2;
																	IL_0a20_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0a33_2:
																	if (1 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0a41_2;
																	IL_0a41_2:
																	if (1 <= b)
																	{
																		num = 252;
																	}
																	goto end_IL_04bd_2;
																	IL_0b5f_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_0b74_2;
																	IL_0a5d_2:
																	if (3 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	num = 156;
																	goto IL_0a74_2;
																	IL_0b74_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0a74_2:
																	if (3 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0c5e_2;
																	IL_0c5e_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	num = 168;
																	goto IL_0c7c_2;
																	IL_0c7c_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0a87_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	num = 25;
																	goto IL_0aa5_2;
																	IL_0aa5_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0ab8_2:
																	if (6 < b)
																	{
																		goto IL_0ac3_2;
																	}
																	goto IL_0b07_2;
																	IL_0ac3_2:
																	if (7 < b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0ad1_2;
																	IL_0ad1_2:
																	if (7 > b)
																	{
																		goto end_IL_04bd_2;
																	}
																	goto IL_0adf_2;
																	IL_0adf_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	goto IL_0af4_2;
																	IL_0af4_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	IL_0b07_2:
																	if (6 <= b)
																	{
																		goto IL_0b12_2;
																	}
																	goto IL_0b43_2;
																	IL_0b12_2:
																	((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
																	num = 231;
																	goto IL_0b30_2;
																	IL_0b30_2:
																	ptr2 += 8;
																	goto IL_1157_2;
																	continue;
																	end_IL_04b0:
																	break;
																}
																continue;
																end_IL_04bd_2:
																break;
															}
														}
														((delegate*<void>)addDomainUnloadCatchType[*(int*)(ptr2 + num3)])();
														goto IL_1149_2;
														IL_1149_2:
														ptr2 += 8;
														goto IL_1157_2;
														continue;
														end_IL_04cd_2:
														break;
													}
													continue;
													end_IL_04dd:
													break;
												}
												continue;
												end_IL_04ed:
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0c3d:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_1205:
						break;
					}
					continue;
					end_IL_121b:
					break;
				}
				continue;
				end_IL_1227:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2, int int_3)
	{
		int num = 116;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 55;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NullInputPack.FailureKindCompatibleFrameworksMetadataEntry);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 82;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03dd:
																	if (b >= 1)
																	{
																		goto IL_024b;
																	}
																	goto IL_03b5;
																	IL_03b5:
																	while (true)
																	{
																		IL_03b5_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_0232:
																			array[num5] = 0;
																			num = 132;
																			while (true)
																			{
																				if (num != 132)
																				{
																					if (num != 1113)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 105:
																						goto IL_0232;
																					case 68:
																						goto IL_024b;
																					case 18:
																						goto IL_0259;
																					case 3:
																						goto IL_0264;
																					case 30:
																					case 63:
																						goto IL_0272;
																					case 50:
																						goto IL_0280;
																					case 13:
																						goto IL_0290;
																					case 28:
																						goto IL_029b;
																					case 102:
																						goto IL_02b7;
																					case 23:
																					case 103:
																						goto IL_02c5;
																					case 36:
																						goto IL_02d0;
																					case 83:
																						goto IL_02e3;
																					case 42:
																						goto IL_02f1;
																					case 88:
																					case 104:
																						goto IL_0304;
																					case 14:
																					case 24:
																						goto IL_030f;
																					case 71:
																						goto IL_031d;
																					case 73:
																						goto IL_0330;
																					case 107:
																						goto IL_033d;
																					case 2:
																						goto IL_0348;
																					case 44:
																					case 112:
																						goto IL_0358;
																					case 11:
																						goto IL_0363;
																					case 113:
																						goto IL_0373;
																					case 96:
																						goto IL_0381;
																					case 5:
																						goto IL_038c;
																					case 21:
																					case 121:
																						goto IL_039c;
																					case 8:
																						goto IL_03a7;
																					case 6:
																					case 10:
																					case 15:
																					case 19:
																					case 22:
																					case 29:
																					case 37:
																					case 40:
																					case 41:
																					case 43:
																					case 46:
																					case 52:
																					case 57:
																					case 61:
																					case 62:
																					case 69:
																					case 77:
																					case 78:
																					case 85:
																					case 86:
																					case 87:
																					case 100:
																					case 111:
																					case 114:
																						goto IL_03b5_2;
																					case 34:
																						goto IL_03dd;
																					case 82:
																						goto end_IL_03dd;
																					case 59:
																					case 98:
																						goto end_IL_03ed;
																					case 32:
																					case 75:
																						goto IL_0411;
																					case 4:
																						goto IL_0451;
																					case 54:
																						goto IL_0465;
																					case 76:
																					case 80:
																						goto IL_0478;
																					case 9:
																						goto IL_0491;
																					case 16:
																						goto IL_049f;
																					case 51:
																						goto IL_04ad;
																					case 31:
																					case 93:
																						goto IL_04c9;
																					case 67:
																					case 74:
																						goto IL_04f7;
																					case 26:
																					case 97:
																						goto IL_0518;
																					case 94:
																						goto IL_052c;
																					case 33:
																						goto IL_0574;
																					case 25:
																					case 118:
																						goto IL_0587;
																					case 60:
																						goto IL_05f5;
																					case 92:
																					case 119:
																						goto IL_0608;
																					case 38:
																						goto IL_0648;
																					case 12:
																						goto IL_065c;
																					case 120:
																						goto IL_066f;
																					case 66:
																						goto IL_067d;
																					case 64:
																					case 70:
																						goto end_IL_021f;
																					case 45:
																					case 123:
																						goto IL_06ac;
																					case 72:
																					case 125:
																						goto IL_06bc;
																					case 124:
																						goto IL_06d3;
																					case 1:
																						goto IL_06f6;
																					case 20:
																						goto IL_0700;
																					case 106:
																						goto IL_070e;
																					case 101:
																						goto IL_072c;
																					case 7:
																					case 17:
																					case 35:
																					case 39:
																					case 47:
																					case 48:
																					case 56:
																					case 65:
																					case 79:
																					case 84:
																					case 89:
																					case 90:
																					case 95:
																					case 99:
																					case 110:
																						goto end_IL_03fd;
																					case 81:
																						goto end_IL_073a;
																					case 53:
																						goto end_IL_074d;
																					case 55:
																						goto end_IL_0757;
																					case 117:
																						goto end_IL_0762;
																					case 27:
																						goto end_IL_0777;
																					case 58:
																					case 122:
																						goto end_IL_0795;
																					case 0:
																						goto end_IL_07a5;
																					case 49:
																					case 108:
																						goto end_IL_07b5;
																					case 115:
																						goto end_IL_07c5;
																					case 116:
																						goto end_IL_07d5;
																					case 91:
																					case 109:
																						goto IL_07f0;
																					}
																					continue;
																				}
																				num5++;
																				goto IL_072c;
																				IL_072c:
																				ptr2 += 8;
																				goto end_IL_03fd;
																				continue;
																				end_IL_021f:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0690;
																	IL_024b:
																	if (b <= 12)
																	{
																		goto IL_0259;
																	}
																	goto IL_03b5;
																	IL_0259:
																	if (6 >= b)
																	{
																		goto IL_0264;
																	}
																	goto IL_0290;
																	IL_0264:
																	if (6 <= b)
																	{
																		goto end_IL_03fd;
																	}
																	goto IL_0272;
																	IL_0272:
																	if (3 >= b)
																	{
																		goto IL_0280;
																	}
																	goto IL_033d;
																	IL_0280:
																	if (3 > b)
																	{
																		goto IL_0304;
																	}
																	goto IL_0608;
																	IL_0304:
																	if (1 < b)
																	{
																		goto IL_030f;
																	}
																	goto IL_0330;
																	IL_030f:
																	if (2 >= b)
																	{
																		goto IL_031d;
																	}
																	goto IL_03b5;
																	IL_031d:
																	if (2 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_0587;
																	IL_0587:
																	ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_05f5;
																	IL_05f5:
																	num5 -= 2;
																	goto end_IL_03fd;
																	IL_0330:
																	if (1 <= b)
																	{
																	}
																	goto IL_03b5;
																	IL_0608:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0648;
																	IL_0648:
																	array[num5 - 2] = 0;
																	goto IL_065c;
																	IL_065c:
																	num5--;
																	goto end_IL_03fd;
																	IL_033d:
																	if (4 >= b)
																	{
																		goto IL_0348;
																	}
																	goto IL_0358;
																	IL_0348:
																	if (4 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_04c9;
																	IL_04c9:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_066f;
																	IL_066f:
																	ptr2 += 8;
																	goto IL_067d;
																	IL_067d:
																	num5--;
																	goto end_IL_03fd;
																	IL_0358:
																	if (5 >= b)
																	{
																		goto IL_0363;
																	}
																	goto IL_03b5;
																	IL_0363:
																	if (5 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_04f7;
																	IL_04f7:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_03fd;
																	IL_0290:
																	if (9 < b)
																	{
																		goto IL_029b;
																	}
																	goto IL_02b7;
																	IL_029b:
																	if (11 >= b)
																	{
																		goto IL_0373;
																	}
																	num = 21;
																	goto IL_039c;
																	IL_0451:
																	array[num5 - 2] = 0;
																	goto IL_0465;
																	IL_039c:
																	if (12 >= b)
																	{
																		goto IL_03a7;
																	}
																	goto IL_03b5;
																	IL_03a7:
																	if (12 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_0690;
																	IL_0690:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_03fd;
																	IL_0373:
																	if (11 > b)
																	{
																		goto IL_0381;
																	}
																	goto IL_06ac;
																	IL_0381:
																	if (10 >= b)
																	{
																		goto IL_038c;
																	}
																	goto IL_03b5;
																	IL_038c:
																	if (10 > b)
																	{
																		goto IL_03b5;
																	}
																	num = 97;
																	goto IL_0518;
																	IL_0465:
																	num5--;
																	goto end_IL_03fd;
																	IL_0518:
																	array[num5 - 1] = 0;
																	goto IL_052c;
																	IL_052c:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)Fqbnroot[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	num = 33;
																	goto IL_0574;
																	IL_0574:
																	ptr2 += 8;
																	goto end_IL_03fd;
																	IL_06ac:
																	num5--;
																	goto end_IL_03fd;
																	IL_02b7:
																	if (9 > b)
																	{
																		goto IL_02c5;
																	}
																	goto IL_0411;
																	IL_02c5:
																	if (7 >= b)
																	{
																		goto IL_02d0;
																	}
																	goto IL_02e3;
																	IL_02d0:
																	if (7 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_06bc;
																	IL_06bc:
																	array[num5] = 0;
																	num = 124;
																	goto IL_06d3;
																	IL_06d3:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06f6;
																	IL_06f6:
																	array2[num5] = null;
																	goto IL_0700;
																	IL_0700:
																	num5++;
																	goto IL_070e;
																	IL_070e:
																	ptr2 += 8;
																	goto end_IL_03fd;
																	IL_02e3:
																	if (8 >= b)
																	{
																		goto IL_02f1;
																	}
																	goto IL_03b5;
																	IL_02f1:
																	if (8 > b)
																	{
																		goto IL_03b5;
																	}
																	goto IL_0478;
																	IL_0478:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0491;
																	IL_0491:
																	array[num5] = 0;
																	goto IL_049f;
																	IL_049f:
																	num5++;
																	goto IL_04ad;
																	IL_04ad:
																	ptr2 += 8;
																	num = 7;
																	goto end_IL_03fd;
																	IL_0411:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0451;
																	continue;
																	end_IL_03dd:
																	break;
																}
																continue;
																end_IL_03ed:
																break;
															}
															continue;
															end_IL_03fd:
															break;
														}
														continue;
													}
													goto IL_07f0;
													IL_07f0:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_073a:
													break;
												}
												continue;
												end_IL_074d:
												break;
											}
											continue;
											end_IL_0757:
											break;
										}
										continue;
										end_IL_0762:
										break;
									}
									continue;
									end_IL_0777:
									break;
								}
								continue;
								end_IL_0795:
								break;
							}
							continue;
							end_IL_07a5:
							break;
						}
						continue;
						end_IL_07b5:
						break;
					}
					continue;
					end_IL_07c5:
					break;
				}
				continue;
				end_IL_07d5:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 73;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackTraceGetInteropTypeFromXmlType.StargSetImplementationFlags);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 66;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_022c:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			if (6 >= b)
																			{
																				num = 119;
																				while (true)
																				{
																					if (num != 119)
																					{
																						if (num != 1100)
																						{
																							goto IL_0586;
																						}
																						switch (num)
																						{
																						case 95:
																							goto end_IL_01f9;
																						case 77:
																							goto end_IL_020c;
																						case 61:
																							goto IL_022c;
																						case 66:
																							goto end_IL_022c;
																						case 85:
																						case 91:
																							goto end_IL_023c;
																						case 70:
																							goto IL_0260;
																						case 13:
																							goto IL_026b;
																						case 6:
																						case 52:
																							goto IL_0276;
																						case 43:
																							goto IL_0284;
																						case 100:
																							goto IL_0297;
																						case 74:
																						case 79:
																							goto IL_02a5;
																						case 105:
																							goto IL_02c1;
																						case 9:
																						case 86:
																							goto IL_02cf;
																						case 22:
																						case 54:
																							goto IL_02da;
																						case 50:
																							goto IL_02ed;
																						case 69:
																						case 87:
																							goto IL_02fb;
																						case 10:
																							goto IL_033b;
																						case 68:
																							goto IL_034f;
																						case 7:
																						case 38:
																							goto IL_036b;
																						case 102:
																							goto IL_03d6;
																						case 107:
																							goto IL_03e9;
																						case 0:
																						case 18:
																							goto IL_03f7;
																						case 65:
																							goto IL_041a;
																						case 59:
																							goto IL_0428;
																						case 1:
																							goto IL_0436;
																						case 34:
																						case 106:
																							goto IL_0454;
																						case 60:
																							goto IL_0494;
																						case 15:
																							goto IL_04a8;
																						case 37:
																							goto IL_04bb;
																						case 36:
																							goto IL_04c9;
																						case 64:
																						case 88:
																							goto IL_04d4;
																						case 51:
																							goto IL_04e2;
																						case 80:
																						case 108:
																							goto IL_04f0;
																						case 42:
																							goto IL_04fe;
																						case 8:
																							goto IL_0521;
																						case 23:
																							goto IL_052b;
																						case 98:
																							goto IL_0539;
																						case 20:
																							goto IL_054c;
																						case 82:
																							goto IL_055f;
																						case 92:
																						case 112:
																							goto IL_056d;
																						case 111:
																							goto IL_0578;
																						case 2:
																						case 81:
																							goto IL_0586;
																						case 33:
																							goto IL_059f;
																						case 25:
																							goto IL_05b6;
																						case 4:
																							goto IL_05c4;
																						case 24:
																						case 97:
																							goto IL_05d7;
																						case 3:
																							goto IL_05e2;
																						case 28:
																						case 78:
																							goto IL_05ed;
																						case 57:
																							goto IL_0616;
																						case 26:
																							goto IL_0624;
																						case 12:
																						case 40:
																							goto IL_063d;
																						case 11:
																						case 17:
																						case 30:
																						case 31:
																						case 35:
																						case 41:
																						case 49:
																						case 53:
																						case 55:
																						case 58:
																						case 76:
																						case 89:
																						case 90:
																						case 94:
																						case 99:
																						case 101:
																						case 104:
																						case 109:
																						case 110:
																							goto end_IL_021c;
																						case 5:
																						case 14:
																						case 29:
																						case 39:
																						case 46:
																						case 47:
																						case 48:
																						case 56:
																						case 63:
																						case 67:
																						case 75:
																						case 84:
																						case 96:
																						case 103:
																							goto end_IL_024c;
																						case 32:
																							goto end_IL_0665;
																						case 16:
																							goto end_IL_0678;
																						case 27:
																							goto end_IL_0682;
																						case 71:
																							goto end_IL_068d;
																						case 45:
																						case 83:
																							goto end_IL_06a2;
																						case 62:
																							goto end_IL_06b2;
																						case 21:
																						case 93:
																							goto end_IL_06c2;
																						case 72:
																							goto end_IL_06d2;
																						case 73:
																							goto end_IL_06e2;
																						case 19:
																						case 44:
																							goto IL_06fd;
																						}
																						continue;
																					}
																					if (6 <= b)
																					{
																						goto IL_0454;
																					}
																					goto IL_04bb;
																					IL_0616:
																					ptr2 += 8;
																					goto IL_0624;
																					IL_063d:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_024c;
																					IL_0624:
																					num5--;
																					num = 48;
																					goto end_IL_024c;
																					IL_0454:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0494;
																					IL_0494:
																					array[num5 - 2] = 0;
																					goto IL_04a8;
																					IL_04a8:
																					num5--;
																					goto end_IL_024c;
																					IL_04bb:
																					if (3 < b)
																					{
																						goto IL_04c9;
																					}
																					goto IL_055f;
																					IL_04c9:
																					if (4 < b)
																					{
																						goto IL_04d4;
																					}
																					goto IL_054c;
																					IL_04d4:
																					if (5 < b)
																					{
																						goto end_IL_021c;
																					}
																					goto IL_04e2;
																					IL_04e2:
																					if (5 > b)
																					{
																						goto end_IL_021c;
																					}
																					goto IL_04f0;
																					IL_04f0:
																					array[num5] = 0;
																					goto IL_04fe;
																					IL_04fe:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0521;
																					IL_0521:
																					array2[num5] = null;
																					goto IL_052b;
																					IL_052b:
																					num5++;
																					goto IL_0539;
																					IL_0539:
																					ptr2 += 8;
																					goto end_IL_024c;
																					IL_054c:
																					if (4 > b)
																					{
																						goto end_IL_021c;
																					}
																					goto end_IL_024c;
																					IL_055f:
																					if (3 > b)
																					{
																						goto IL_056d;
																					}
																					goto IL_063d;
																					IL_056d:
																					if (1 >= b)
																					{
																						goto IL_0578;
																					}
																					goto IL_05d7;
																					IL_0578:
																					if (1 > b)
																					{
																						goto end_IL_021c;
																					}
																					goto IL_0586;
																					IL_0586:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_059f;
																					IL_059f:
																					array[num5] = 0;
																					num = 25;
																					goto IL_05b6;
																					IL_05b6:
																					num5++;
																					goto IL_05c4;
																					IL_05c4:
																					ptr2 += 8;
																					goto end_IL_024c;
																					IL_05d7:
																					if (2 < b)
																					{
																						goto end_IL_021c;
																					}
																					goto IL_05e2;
																					IL_05e2:
																					if (2 > b)
																					{
																						goto end_IL_021c;
																					}
																					goto IL_05ed;
																					IL_05ed:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0616;
																					continue;
																					end_IL_01f9:
																					break;
																				}
																				continue;
																			}
																			goto IL_0260;
																			IL_036b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 102;
																			goto IL_03d6;
																			IL_03d6:
																			num5 -= 2;
																			goto end_IL_024c;
																			IL_0260:
																			if (9 < b)
																			{
																				goto IL_026b;
																			}
																			goto IL_02c1;
																			IL_026b:
																			if (10 < b)
																			{
																				goto IL_0276;
																			}
																			goto IL_0297;
																			IL_0276:
																			if (11 < b)
																			{
																				goto end_IL_021c;
																			}
																			goto IL_0284;
																			IL_0284:
																			if (11 <= b)
																			{
																			}
																			goto end_IL_021c;
																			IL_0297:
																			if (10 > b)
																			{
																				goto end_IL_021c;
																			}
																			goto IL_02a5;
																			IL_02a5:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_024c;
																			IL_02c1:
																			if (9 > b)
																			{
																				goto IL_02cf;
																			}
																			goto IL_036b;
																			IL_02cf:
																			if (7 < b)
																			{
																				goto IL_02da;
																			}
																			goto IL_02ed;
																			IL_02da:
																			if (8 < b)
																			{
																				goto end_IL_021c;
																			}
																			goto IL_03e9;
																			IL_03e9:
																			if (8 > b)
																			{
																				goto end_IL_021c;
																			}
																			goto IL_03f7;
																			IL_03f7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_041a;
																			IL_041a:
																			array[num5] = 0;
																			goto IL_0428;
																			IL_0428:
																			num5++;
																			goto IL_0436;
																			IL_0436:
																			ptr2 += 8;
																			goto end_IL_024c;
																			IL_02ed:
																			if (7 > b)
																			{
																				goto end_IL_021c;
																			}
																			goto IL_02fb;
																			IL_02fb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_033b;
																			IL_033b:
																			array[num5 - 2] = 0;
																			goto IL_034f;
																			IL_034f:
																			num5--;
																			num = 46;
																			goto end_IL_024c;
																			continue;
																			end_IL_020c:
																			break;
																		}
																		continue;
																		end_IL_021c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_024c;
																continue;
																end_IL_022c:
																break;
															}
															continue;
															end_IL_023c:
															break;
														}
														continue;
														end_IL_024c:
														break;
													}
													continue;
												}
												goto IL_06fd;
												IL_06fd:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0665:
												break;
											}
											continue;
											end_IL_0678:
											break;
										}
										continue;
										end_IL_0682:
										break;
									}
									continue;
									end_IL_068d:
									break;
								}
								continue;
								end_IL_06a2:
								break;
							}
							continue;
							end_IL_06b2:
							break;
						}
						continue;
						end_IL_06c2:
						break;
					}
					continue;
					end_IL_06d2:
					break;
				}
				continue;
				end_IL_06e2:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 37;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 87;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								num = 3;
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getKeyboardLayoutIdAccessDeniedCallback.getIsFamilyAndAssemblygetOffsetToStringData);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	num = 29;
																	while (true)
																	{
																		IL_024d:
																		if (b >= 1)
																		{
																			while (b <= 10)
																			{
																				while (true)
																				{
																					IL_0230:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0220:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0213:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_0203:
																											if (2 > b)
																											{
																												while (1 >= b)
																												{
																													num = 112;
																													while (true)
																													{
																														if (num != 112)
																														{
																															if (num != 1093)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 14:
																															case 77:
																																goto IL_01f0;
																															case 44:
																																goto IL_0203;
																															case 52:
																																goto IL_0213;
																															case 26:
																																goto IL_0220;
																															case 69:
																																goto IL_0230;
																															case 21:
																																goto IL_023d;
																															case 29:
																																goto IL_024d;
																															case 59:
																																goto end_IL_024d;
																															case 48:
																															case 93:
																																goto end_IL_025d;
																															case 10:
																															case 56:
																																goto IL_028c;
																															case 20:
																															case 83:
																																goto IL_029a;
																															case 35:
																																goto IL_02a8;
																															case 67:
																															case 85:
																																goto IL_02bb;
																															case 34:
																															case 64:
																																goto IL_02c6;
																															case 76:
																																goto IL_02d1;
																															case 33:
																															case 71:
																																goto IL_02df;
																															case 6:
																																goto IL_02f2;
																															case 61:
																																goto IL_0300;
																															case 8:
																															case 30:
																																goto IL_030e;
																															case 63:
																																goto IL_032a;
																															case 24:
																															case 25:
																																goto IL_0338;
																															case 82:
																																goto IL_0346;
																															case 65:
																																goto IL_036a;
																															case 55:
																																goto IL_0378;
																															case 95:
																																goto IL_038b;
																															case 0:
																															case 89:
																																goto IL_0399;
																															case 42:
																																goto IL_03d9;
																															case 86:
																																goto IL_03ed;
																															case 84:
																															case 98:
																																goto IL_0400;
																															case 17:
																																goto IL_0429;
																															case 12:
																																goto IL_0440;
																															case 2:
																															case 104:
																																goto IL_0453;
																															case 1:
																																goto IL_045e;
																															case 40:
																															case 105:
																																goto IL_0471;
																															case 62:
																																goto IL_047f;
																															case 41:
																															case 96:
																																goto IL_048d;
																															case 101:
																																goto IL_049b;
																															case 51:
																																goto IL_04c7;
																															case 22:
																																goto IL_04d1;
																															case 68:
																																goto IL_04df;
																															case 7:
																															case 75:
																																goto IL_0505;
																															case 53:
																																goto IL_057c;
																															case 4:
																															case 78:
																																goto IL_058c;
																															case 5:
																															case 9:
																															case 16:
																															case 19:
																															case 23:
																															case 36:
																															case 49:
																															case 57:
																															case 70:
																															case 73:
																															case 79:
																															case 88:
																															case 90:
																															case 92:
																															case 94:
																															case 99:
																															case 102:
																																goto end_IL_01dd;
																															case 27:
																																goto IL_05c4;
																															case 39:
																																goto IL_05d2;
																															case 81:
																																goto IL_05e0;
																															case 11:
																															case 15:
																															case 18:
																															case 31:
																															case 46:
																															case 50:
																															case 54:
																															case 58:
																															case 66:
																															case 72:
																															case 91:
																															case 97:
																															case 103:
																																goto end_IL_0276;
																															case 32:
																																goto end_IL_05ee;
																															case 47:
																																goto end_IL_0601;
																															case 100:
																																goto end_IL_060b;
																															case 43:
																																goto end_IL_0616;
																															case 3:
																																goto end_IL_062b;
																															case 28:
																															case 74:
																																goto end_IL_0640;
																															case 13:
																																goto end_IL_0650;
																															case 87:
																																goto end_IL_0669;
																															case 60:
																																goto end_IL_0679;
																															case 37:
																																goto end_IL_0689;
																															case 38:
																																goto end_IL_0694;
																															case 45:
																															case 80:
																																goto IL_06b8;
																															}
																															continue;
																														}
																														if (1 > b)
																														{
																														}
																														break;
																														continue;
																														end_IL_01dd:
																														break;
																													}
																													break;
																													IL_01f0:;
																												}
																												break;
																											}
																											goto IL_0505;
																											IL_057c:
																											num5 -= 2;
																											goto end_IL_0276;
																											IL_0505:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 53;
																											goto IL_057c;
																										}
																										break;
																									}
																									goto IL_028c;
																									IL_03ed:
																									num5--;
																									goto end_IL_0276;
																									IL_028c:
																									if (3 < b)
																									{
																										goto IL_029a;
																									}
																									goto IL_038b;
																									IL_029a:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_02a8;
																									IL_02a8:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_0400;
																									IL_0400:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0429;
																									IL_0429:
																									ptr2 += 8;
																									num = 12;
																									goto IL_0440;
																									IL_0440:
																									num5--;
																									goto end_IL_0276;
																									IL_038b:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0399;
																									IL_0399:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03d9;
																									IL_03d9:
																									array[num5 - 2] = 0;
																									goto IL_03ed;
																								}
																								break;
																							}
																							goto IL_058c;
																							IL_058c:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0276;
																						}
																						break;
																					}
																					num = 85;
																					goto IL_02bb;
																					IL_04d1:
																					num5++;
																					goto IL_04df;
																					IL_04df:
																					ptr2 += 8;
																					goto end_IL_0276;
																					IL_02bb:
																					if (8 < b)
																					{
																						goto IL_02c6;
																					}
																					goto IL_032a;
																					IL_02c6:
																					if (9 >= b)
																					{
																						goto IL_02d1;
																					}
																					goto IL_02f2;
																					IL_02d1:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_02df;
																					IL_02df:
																					num5--;
																					goto end_IL_0276;
																					IL_02f2:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0300;
																					IL_0300:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_030e;
																					IL_030e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0276;
																					IL_032a:
																					if (8 <= b)
																					{
																						goto IL_0338;
																					}
																					goto IL_0453;
																					IL_0338:
																					array[num5] = 0;
																					goto IL_0346;
																					IL_0346:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)RightArrowgetContainsGenericParameters[*(int*)(ptr2 + num3)])();
																					goto IL_036a;
																					IL_036a:
																					num5++;
																					goto IL_0378;
																					IL_0378:
																					ptr2 += 8;
																					goto end_IL_0276;
																					IL_0453:
																					if (6 >= b)
																					{
																						goto IL_045e;
																					}
																					goto IL_0471;
																					IL_045e:
																					if (6 <= b)
																					{
																						goto end_IL_0276;
																					}
																					break;
																					IL_0471:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_047f;
																					IL_047f:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_048d;
																					IL_048d:
																					array[num5] = 0;
																					goto IL_049b;
																					IL_049b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					num = 51;
																					goto IL_04c7;
																					IL_04c7:
																					array2[num5] = null;
																					goto IL_04d1;
																				}
																				break;
																				IL_023d:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05c4;
																		IL_05e0:
																		ptr2 += 8;
																		goto end_IL_0276;
																		IL_05d2:
																		num5++;
																		goto IL_05e0;
																		IL_05c4:
																		array[num5] = 0;
																		goto IL_05d2;
																		continue;
																		end_IL_024d:
																		break;
																	}
																	continue;
																	end_IL_025d:
																	break;
																}
																continue;
																end_IL_0276:
																break;
															}
															continue;
														}
														goto IL_06b8;
														IL_06b8:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_05ee:
														break;
													}
													continue;
													end_IL_0601:
													break;
												}
												continue;
												end_IL_060b:
												break;
											}
											continue;
											end_IL_0616:
											break;
										}
										continue;
										end_IL_062b:
										break;
									}
									continue;
									end_IL_0640:
									break;
								}
								continue;
								end_IL_0650:
								break;
							}
							continue;
							end_IL_0669:
							break;
						}
						continue;
						end_IL_0679:
						break;
					}
					continue;
					end_IL_0689:
					break;
				}
				continue;
				end_IL_0694:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 40;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NoThrowOnInvalidTimeGetManagedCategoryGuid.ChannelDataStoresetXML);
										num = 14;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_022d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					if (5 > b)
																					{
																						while (true)
																						{
																							if (2 < b)
																							{
																								num = 112;
																								while (true)
																								{
																									if (num != 112)
																									{
																										if (num != 1093)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 8:
																											goto end_IL_01dd;
																										case 105:
																											goto end_IL_01f0;
																										case 63:
																											goto end_IL_0200;
																										case 60:
																											goto end_IL_0210;
																										case 6:
																											goto IL_022d;
																										case 97:
																											goto end_IL_022d;
																										case 76:
																										case 102:
																											goto end_IL_023d;
																										case 15:
																										case 46:
																											goto IL_0258;
																										case 53:
																											goto IL_0268;
																										case 75:
																											goto IL_0278;
																										case 19:
																											goto IL_0286;
																										case 30:
																										case 78:
																											goto IL_029c;
																										case 80:
																											goto IL_02af;
																										case 17:
																										case 67:
																											goto IL_02bd;
																										case 37:
																											goto IL_02fd;
																										case 13:
																										case 84:
																											goto IL_0316;
																										case 16:
																											goto IL_0324;
																										case 21:
																										case 54:
																											goto IL_0332;
																										case 27:
																											goto IL_035e;
																										case 20:
																										case 88:
																											goto IL_0371;
																										case 90:
																											goto IL_039a;
																										case 57:
																											goto IL_03a8;
																										case 39:
																										case 91:
																											goto IL_03c4;
																										case 77:
																										case 79:
																											goto IL_03cf;
																										case 45:
																											goto IL_03dd;
																										case 31:
																											goto IL_03f0;
																										case 10:
																										case 62:
																											goto IL_03fe;
																										case 94:
																											goto IL_041a;
																										case 24:
																										case 32:
																											goto IL_0428;
																										case 68:
																											goto IL_0441;
																										case 86:
																											goto IL_044f;
																										case 44:
																											goto IL_045d;
																										case 92:
																										case 96:
																											goto IL_0470;
																										case 87:
																											goto IL_04d2;
																										case 99:
																											goto IL_04e5;
																										case 100:
																											goto IL_04f8;
																										case 73:
																											goto IL_0506;
																										case 36:
																										case 104:
																											goto IL_0519;
																										case 74:
																											goto IL_0527;
																										case 58:
																											goto IL_054a;
																										case 82:
																											goto IL_0554;
																										case 101:
																											goto IL_0562;
																										case 70:
																											goto IL_0572;
																										case 66:
																											goto IL_057d;
																										case 34:
																											goto IL_0588;
																										case 65:
																											goto IL_059e;
																										case 9:
																										case 42:
																											goto IL_05a9;
																										case 0:
																										case 4:
																										case 7:
																										case 11:
																										case 12:
																										case 22:
																										case 23:
																										case 28:
																										case 29:
																										case 35:
																										case 38:
																										case 49:
																										case 51:
																										case 56:
																										case 59:
																										case 61:
																										case 85:
																										case 89:
																										case 103:
																											goto end_IL_021d;
																										case 2:
																										case 3:
																										case 18:
																										case 41:
																										case 43:
																										case 47:
																										case 55:
																										case 64:
																										case 69:
																										case 81:
																										case 83:
																										case 95:
																										case 98:
																											goto end_IL_024d;
																										case 14:
																											goto end_IL_05d1;
																										case 5:
																											goto end_IL_05e4;
																										case 33:
																											goto end_IL_05ee;
																										case 25:
																											goto end_IL_0602;
																										case 1:
																										case 52:
																											goto end_IL_0617;
																										case 93:
																											goto end_IL_0627;
																										case 40:
																										case 50:
																											goto end_IL_0637;
																										case 71:
																											goto end_IL_0647;
																										case 72:
																											goto end_IL_0657;
																										case 26:
																										case 48:
																											goto IL_067b;
																										}
																										continue;
																									}
																									goto IL_0572;
																									IL_05a9:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_024d;
																									IL_059e:
																									if (3 > b)
																									{
																										goto end_IL_021d;
																									}
																									goto IL_05a9;
																									IL_0572:
																									if (3 < b)
																									{
																										goto IL_057d;
																									}
																									num = 65;
																									goto IL_059e;
																									IL_057d:
																									if (4 < b)
																									{
																										goto end_IL_021d;
																									}
																									goto IL_0588;
																									IL_0588:
																									if (4 > b)
																									{
																										goto end_IL_021d;
																									}
																									goto end_IL_024d;
																									continue;
																									end_IL_01dd:
																									break;
																								}
																								continue;
																							}
																							goto IL_0268;
																							IL_039a:
																							ptr2 += 8;
																							goto IL_03a8;
																							IL_03a8:
																							num5--;
																							num = 95;
																							goto end_IL_024d;
																							IL_0268:
																							if (2 > b)
																							{
																								goto IL_029c;
																							}
																							goto IL_0371;
																							IL_029c:
																							if (1 < b)
																							{
																								goto end_IL_021d;
																							}
																							goto IL_041a;
																							IL_041a:
																							if (1 > b)
																							{
																								goto end_IL_021d;
																							}
																							goto IL_0428;
																							IL_0428:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0441;
																							IL_0441:
																							array[num5] = 0;
																							goto IL_044f;
																							IL_044f:
																							num5++;
																							goto IL_045d;
																							IL_045d:
																							ptr2 += 8;
																							goto end_IL_024d;
																							IL_0371:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_039a;
																							continue;
																							end_IL_01f0:
																							break;
																						}
																						continue;
																					}
																					goto IL_0519;
																					IL_0562:
																					ptr2 += 8;
																					goto end_IL_024d;
																					IL_0519:
																					array[num5] = 0;
																					goto IL_0527;
																					IL_0527:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_054a;
																					IL_054a:
																					array2[num5] = null;
																					goto IL_0554;
																					IL_0554:
																					num5++;
																					goto IL_0562;
																					continue;
																					end_IL_0200:
																					break;
																				}
																				continue;
																			}
																			goto IL_0258;
																			IL_0470:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_04d2;
																			IL_0258:
																			if (8 >= b)
																			{
																				goto IL_0278;
																			}
																			goto IL_03c4;
																			IL_03c4:
																			if (9 < b)
																			{
																				goto IL_03cf;
																			}
																			goto IL_03f0;
																			IL_03cf:
																			if (10 < b)
																			{
																				goto end_IL_021d;
																			}
																			goto IL_03dd;
																			IL_03dd:
																			if (10 > b)
																			{
																			}
																			goto end_IL_021d;
																			IL_03f0:
																			if (9 > b)
																			{
																				goto end_IL_021d;
																			}
																			goto IL_03fe;
																			IL_03fe:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_024d;
																			IL_0278:
																			if (8 > b)
																			{
																				goto IL_0286;
																			}
																			goto IL_0470;
																			IL_0286:
																			if (6 >= b)
																			{
																				goto IL_02af;
																			}
																			num = 84;
																			goto IL_0316;
																			IL_04d2:
																			num5 -= 2;
																			goto end_IL_024d;
																			IL_0316:
																			if (7 < b)
																			{
																				goto end_IL_021d;
																			}
																			goto IL_0324;
																			IL_0324:
																			if (7 > b)
																			{
																				goto end_IL_021d;
																			}
																			goto IL_0332;
																			IL_0332:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 27;
																			goto IL_035e;
																			IL_035e:
																			array[num5] = 0;
																			goto IL_04f8;
																			IL_04f8:
																			num5++;
																			goto IL_0506;
																			IL_0506:
																			ptr2 += 8;
																			goto end_IL_024d;
																			IL_02af:
																			if (6 > b)
																			{
																				goto end_IL_021d;
																			}
																			goto IL_02bd;
																			IL_02bd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_02fd;
																			IL_02fd:
																			array[num5 - 2] = 0;
																			goto IL_04e5;
																			IL_04e5:
																			num5--;
																			goto end_IL_024d;
																			continue;
																			end_IL_0210:
																			break;
																		}
																		continue;
																		end_IL_021d:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_024d;
																continue;
																end_IL_022d:
																break;
															}
															continue;
															end_IL_023d:
															break;
														}
														continue;
														end_IL_024d:
														break;
													}
													continue;
												}
												goto IL_067b;
												IL_067b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d1:
												break;
											}
											continue;
											end_IL_05e4:
											break;
										}
										continue;
										end_IL_05ee:
										break;
									}
									continue;
									end_IL_0602:
									break;
								}
								continue;
								end_IL_0617:
								break;
							}
							continue;
							end_IL_0627:
							break;
						}
						continue;
						end_IL_0637:
						break;
					}
					continue;
					end_IL_0647:
					break;
				}
				continue;
				end_IL_0657:
				break;
			}
		}
	}

	private static int smethod_6()
	{
		int num = 25;
		int num2 = 5;
		num = 5;
		object obj = new int[5];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 50;
		num3 = 10;
		((int[])obj)[0] = 10;
		obj = obj2;
		num2 = 1;
		num3 = 245;
		num3 = 49;
		((int[])obj)[1] = 49;
		obj = obj2;
		num2 = 6;
		num3 = 3;
		num2 = 2;
		num3 = 108;
		num3 = 36;
		((int[])obj)[2] = 36;
		obj = obj2;
		num2 = 12;
		num3 = 4;
		num2 = 3;
		num3 = 33;
		num3 = 3;
		((int[])obj)[3] = 3;
		obj = obj2;
		num2 = 52;
		num3 = 13;
		num2 = 4;
		num3 = 87;
		num3 = 29;
		((int[])obj)[4] = 29;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 20;
			num3 = 4;
			num2 = 5;
			if (num >= 5)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_7(int int_2, int int_3)
	{
		int num = 19;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 30;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											num = 90;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsHideBySiggetCheckExecutionRights.getOwnerBuiltinPerformanceMonitoringUsersSid);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														IL_0620:
														if (num4 != 1)
														{
															while (true)
															{
																IL_0267:
																byte b = *ptr2;
																while (true)
																{
																	IL_0257:
																	ptr2++;
																	while (true)
																	{
																		IL_0247:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0227:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0217:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0207:
																									if (2 < b)
																									{
																										while (true)
																										{
																											IL_01f7:
																											if (3 < b)
																											{
																												while (4 >= b)
																												{
																													num = 109;
																													while (true)
																													{
																														if (num != 109)
																														{
																															if (num != 1090)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 37:
																															case 74:
																																goto IL_01e4;
																															case 47:
																															case 70:
																																goto IL_01f7;
																															case 45:
																																goto IL_0207;
																															case 94:
																																goto IL_0217;
																															case 95:
																																goto IL_0227;
																															case 39:
																																goto IL_0237;
																															case 11:
																																goto IL_0247;
																															case 38:
																																goto IL_0257;
																															case 81:
																															case 88:
																																goto IL_0267;
																															case 31:
																															case 99:
																																goto IL_0280;
																															case 63:
																																goto IL_02c0;
																															case 43:
																																goto IL_02dd;
																															case 55:
																																goto IL_02f0;
																															case 28:
																															case 56:
																																goto IL_02fe;
																															case 17:
																																goto IL_0327;
																															case 65:
																																goto IL_0335;
																															case 10:
																																goto IL_0348;
																															case 85:
																															case 100:
																																goto IL_0353;
																															case 72:
																																goto IL_0393;
																															case 5:
																																goto IL_03a7;
																															case 89:
																																goto IL_03ba;
																															case 7:
																																goto IL_03c8;
																															case 13:
																															case 98:
																																goto IL_03db;
																															case 96:
																																goto IL_03e9;
																															case 46:
																																goto IL_0415;
																															case 49:
																																goto IL_041f;
																															case 24:
																																goto IL_042d;
																															case 21:
																																goto IL_0440;
																															case 4:
																															case 97:
																																goto IL_044e;
																															case 14:
																															case 91:
																																goto IL_0459;
																															case 101:
																																goto IL_0467;
																															case 27:
																															case 78:
																																goto IL_0475;
																															case 52:
																																goto IL_0491;
																															case 42:
																															case 48:
																																goto IL_049f;
																															case 75:
																																goto IL_04df;
																															case 64:
																																goto IL_04f3;
																															case 32:
																																goto IL_0506;
																															case 59:
																															case 92:
																																goto IL_0511;
																															case 3:
																																goto IL_052a;
																															case 84:
																																goto IL_0538;
																															case 80:
																																goto IL_0546;
																															case 25:
																																goto IL_0559;
																															case 53:
																																goto IL_0564;
																															case 22:
																															case 76:
																																goto IL_056f;
																															case 77:
																																goto IL_05af;
																															case 60:
																																goto IL_05c3;
																															case 0:
																															case 6:
																															case 8:
																															case 20:
																															case 23:
																															case 26:
																															case 33:
																															case 35:
																															case 41:
																															case 54:
																															case 62:
																															case 68:
																															case 69:
																															case 79:
																															case 83:
																															case 93:
																																goto end_IL_01e4;
																															case 73:
																																goto IL_05f6;
																															case 2:
																																goto IL_0604;
																															case 66:
																																goto IL_0612;
																															case 1:
																															case 15:
																															case 16:
																															case 29:
																															case 34:
																															case 36:
																															case 40:
																															case 67:
																															case 71:
																															case 82:
																															case 102:
																																goto IL_0620;
																															case 57:
																																goto end_IL_01d1;
																															case 90:
																																goto end_IL_0633;
																															case 51:
																																goto end_IL_063d;
																															case 61:
																																goto end_IL_0648;
																															case 86:
																																goto end_IL_0666;
																															case 12:
																															case 87:
																																goto end_IL_067b;
																															case 58:
																																goto end_IL_068b;
																															case 30:
																																goto end_IL_069b;
																															case 50:
																																goto end_IL_06ab;
																															case 18:
																																goto end_IL_06bb;
																															case 19:
																																goto end_IL_06c6;
																															case 9:
																															case 44:
																																goto IL_06e1;
																															}
																															continue;
																														}
																														if (4 > b)
																														{
																															goto end_IL_01e4;
																														}
																														goto IL_0280;
																														IL_0280:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														goto IL_02c0;
																														IL_02dd:
																														num5--;
																														goto IL_0620;
																														IL_02c0:
																														array[num5 - 2] = 0;
																														num = 43;
																														goto IL_02dd;
																														continue;
																														end_IL_01d1:
																														break;
																													}
																													goto end_IL_0247;
																													continue;
																													end_IL_01e4:
																													break;
																													IL_01e4:;
																												}
																												break;
																											}
																											goto IL_02f0;
																											IL_0335:
																											num5--;
																											goto IL_0620;
																											IL_02f0:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_02fe;
																											IL_02fe:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0327;
																											IL_0327:
																											ptr2 += 8;
																											goto IL_0335;
																										}
																										break;
																									}
																									goto IL_0348;
																									IL_03c8:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_0348:
																									if (2 <= b)
																									{
																										goto IL_0353;
																									}
																									goto IL_03ba;
																									IL_0353:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0393;
																									IL_0393:
																									array[num5 - 2] = 0;
																									goto IL_03a7;
																									IL_03a7:
																									num5--;
																									goto IL_0620;
																									IL_03ba:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_03c8;
																								}
																								break;
																							}
																							goto IL_03db;
																							IL_042d:
																							ptr2 += 8;
																							goto IL_0620;
																							IL_03db:
																							array[num5] = 0;
																							goto IL_03e9;
																							IL_03e9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							num = 46;
																							goto IL_0415;
																							IL_0415:
																							array2[num5] = null;
																							goto IL_041f;
																							IL_041f:
																							num5++;
																							goto IL_042d;
																						}
																						break;
																					}
																					goto IL_0440;
																					IL_05c3:
																					num5--;
																					goto IL_0620;
																					IL_0440:
																					if (7 < b)
																					{
																						goto IL_044e;
																					}
																					goto IL_0506;
																					IL_044e:
																					if (8 < b)
																					{
																						goto IL_0459;
																					}
																					goto IL_0491;
																					IL_0459:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0467;
																					IL_0467:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0475;
																					IL_0475:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_0620;
																					IL_0491:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_049f;
																					IL_049f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04df;
																					IL_04df:
																					array[num5 - 2] = 0;
																					goto IL_04f3;
																					IL_04f3:
																					num5--;
																					goto IL_0620;
																					IL_0506:
																					if (7 <= b)
																					{
																						goto IL_0511;
																					}
																					goto IL_0559;
																					IL_0511:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_052a;
																					IL_052a:
																					array[num5] = 0;
																					goto IL_0538;
																					IL_0538:
																					num5++;
																					goto IL_0546;
																					IL_0546:
																					ptr2 += 8;
																					goto IL_0620;
																					IL_0559:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_0564;
																					IL_0564:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_056f;
																					IL_056f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05af;
																					IL_05af:
																					array[num5 - 2] = 0;
																					goto IL_05c3;
																				}
																				break;
																				IL_0237:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_05f6;
																		IL_0612:
																		ptr2 += 8;
																		goto IL_0620;
																		IL_0604:
																		num5++;
																		goto IL_0612;
																		IL_05f6:
																		array[num5] = 0;
																		goto IL_0604;
																		continue;
																		end_IL_0247:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														goto IL_06e1;
														IL_06e1:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
													continue;
													end_IL_0633:
													break;
												}
												continue;
												end_IL_063d:
												break;
											}
											continue;
											end_IL_0648:
											break;
										}
										continue;
										end_IL_0666:
										break;
									}
									continue;
									end_IL_067b:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_069b:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06c6:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 85;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										num = 54;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref QuickCacheEntryTypeStindR.ArraySubTypeChannelInfo);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													IL_05e5:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0280:
															byte b = *ptr2;
															while (true)
															{
																IL_0270:
																ptr2++;
																while (true)
																{
																	IL_0260:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0243:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0233:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0226:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0216:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_01d2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														num = 108;
																														while (true)
																														{
																															if (num != 108)
																															{
																																if (num != 1089)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 47:
																																case 97:
																																	goto IL_01d2;
																																case 98:
																																	goto IL_01f6;
																																case 51:
																																case 93:
																																	goto IL_0206;
																																case 79:
																																	goto IL_0216;
																																case 15:
																																	goto IL_0226;
																																case 46:
																																	goto IL_0233;
																																case 0:
																																	goto IL_0243;
																																case 71:
																																	goto IL_0250;
																																case 87:
																																	goto IL_0260;
																																case 24:
																																	goto IL_0270;
																																case 34:
																																case 36:
																																	goto IL_0280;
																																case 6:
																																case 18:
																																	goto IL_028b;
																																case 5:
																																	goto IL_0299;
																																case 22:
																																	goto IL_02a9;
																																case 8:
																																case 27:
																																	goto IL_02bc;
																																case 12:
																																	goto IL_0327;
																																case 38:
																																	goto IL_033a;
																																case 42:
																																	goto IL_034a;
																																case 59:
																																	goto IL_035d;
																																case 35:
																																	goto IL_036b;
																																case 44:
																																case 53:
																																	goto IL_0379;
																																case 37:
																																case 75:
																																	goto IL_0395;
																																case 80:
																																	goto IL_03ae;
																																case 89:
																																case 90:
																																	goto IL_03c1;
																																case 16:
																																	goto IL_03cf;
																																case 23:
																																case 68:
																																	goto IL_03dd;
																																case 1:
																																	goto IL_0400;
																																case 72:
																																	goto IL_040e;
																																case 2:
																																	goto IL_041c;
																																case 91:
																																	goto IL_042f;
																																case 20:
																																case 41:
																																	goto IL_043d;
																																case 52:
																																	goto IL_047d;
																																case 73:
																																case 92:
																																	goto IL_0493;
																																case 94:
																																	goto IL_04ab;
																																case 88:
																																	goto IL_04b9;
																																case 100:
																																	goto IL_04d5;
																																case 101:
																																	goto IL_04ff;
																																case 40:
																																	goto IL_050d;
																																case 48:
																																case 50:
																																	goto IL_0520;
																																case 26:
																																	goto IL_0552;
																																case 11:
																																	goto IL_0560;
																																case 49:
																																case 95:
																																	goto IL_0579;
																																case 33:
																																	goto IL_0587;
																																case 25:
																																	goto IL_05aa;
																																case 83:
																																	goto IL_05b4;
																																case 13:
																																	goto IL_05c2;
																																case 4:
																																case 10:
																																case 17:
																																case 19:
																																case 21:
																																case 28:
																																case 31:
																																case 43:
																																case 45:
																																case 60:
																																case 74:
																																case 78:
																																case 81:
																																case 82:
																																case 84:
																																case 86:
																																case 96:
																																	goto end_IL_01f6;
																																case 3:
																																case 7:
																																case 29:
																																case 32:
																																case 39:
																																case 57:
																																case 64:
																																case 65:
																																case 66:
																																case 67:
																																case 70:
																																case 76:
																																case 99:
																																	goto IL_05e5;
																																case 55:
																																	goto end_IL_05e5;
																																case 54:
																																	goto end_IL_05f8;
																																case 77:
																																	goto end_IL_0602;
																																case 14:
																																	goto end_IL_060d;
																																case 56:
																																case 63:
																																	goto end_IL_062b;
																																case 30:
																																	goto end_IL_063b;
																																case 85:
																																	goto end_IL_064b;
																																case 58:
																																	goto end_IL_065b;
																																case 61:
																																	goto end_IL_066b;
																																case 62:
																																	goto end_IL_0676;
																																case 9:
																																case 69:
																																	goto end_IL_01bf;
																																}
																																continue;
																															}
																															array[num5] = 0;
																															num = 101;
																															goto IL_04ff;
																															IL_04ff:
																															num5++;
																															goto IL_050d;
																															IL_050d:
																															ptr2 += 8;
																															goto IL_05e5;
																															continue;
																															end_IL_01bf:
																															break;
																														}
																														break;
																													}
																													goto end_IL_0260;
																													continue;
																													end_IL_01f6:
																													break;
																													IL_01f6:;
																												}
																												break;
																												IL_0206:;
																											}
																											break;
																										}
																										goto IL_0520;
																										IL_0560:
																										num5--;
																										goto IL_05e5;
																										IL_0520:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 26;
																										goto IL_0552;
																										IL_0552:
																										ptr2 += 8;
																										goto IL_0560;
																									}
																									break;
																								}
																								goto IL_02a9;
																								IL_034a:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0493;
																								IL_02a9:
																								if (3 >= b)
																								{
																									goto IL_034a;
																								}
																								goto IL_0395;
																								IL_0395:
																								if (4 < b)
																								{
																									num = 82;
																									break;
																								}
																								goto IL_03ae;
																								IL_0493:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto IL_05e5;
																								IL_03ae:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_05e5;
																							}
																							break;
																						}
																						num = 95;
																						goto IL_0579;
																						IL_05b4:
																						num5++;
																						goto IL_05c2;
																						IL_05c2:
																						ptr2 += 8;
																						goto IL_05e5;
																						IL_0579:
																						array[num5] = 0;
																						goto IL_0587;
																						IL_0587:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05aa;
																						IL_05aa:
																						array2[num5] = null;
																						goto IL_05b4;
																					}
																					break;
																				}
																				goto IL_028b;
																				IL_04b9:
																				if (10 <= b)
																				{
																					num = 28;
																				}
																				break;
																				IL_028b:
																				if (8 >= b)
																				{
																					goto IL_0299;
																				}
																				goto IL_035d;
																				IL_0299:
																				if (8 <= b)
																				{
																					goto IL_02bc;
																				}
																				goto IL_033a;
																				IL_02bc:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 12;
																				goto IL_0327;
																				IL_0327:
																				num5 -= 2;
																				goto IL_05e5;
																				IL_033a:
																				if (6 < b)
																				{
																					goto IL_03c1;
																				}
																				goto IL_042f;
																				IL_03c1:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03dd;
																				IL_03dd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0400;
																				IL_0400:
																				array[num5] = 0;
																				goto IL_040e;
																				IL_040e:
																				num5++;
																				goto IL_041c;
																				IL_041c:
																				ptr2 += 8;
																				goto IL_05e5;
																				IL_042f:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_043d;
																				IL_043d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_047d;
																				IL_047d:
																				array[num5 - 2] = 0;
																				goto IL_04d5;
																				IL_04d5:
																				num5--;
																				goto IL_05e5;
																				IL_035d:
																				if (9 >= b)
																				{
																					goto IL_036b;
																				}
																				goto IL_04ab;
																				IL_036b:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0379;
																				IL_0379:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_05e5;
																				IL_04ab:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_04b9;
																			}
																			break;
																			IL_0250:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05e5;
																	continue;
																	end_IL_0260:
																	break;
																}
																break;
															}
															break;
														}
													}
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05e5:
													break;
												}
												continue;
												end_IL_05f8:
												break;
											}
											continue;
											end_IL_0602:
											break;
										}
										continue;
										end_IL_060d:
										break;
									}
									continue;
									end_IL_062b:
									break;
								}
								continue;
								end_IL_063b:
								break;
							}
							continue;
							end_IL_064b:
							break;
						}
						continue;
						end_IL_065b:
						break;
					}
					continue;
					end_IL_066b:
					break;
				}
				continue;
				end_IL_0676:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_2, int int_3)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IncludeSectTrackResurrection.setCurrentUICulturesetAppDomainManagerAssembly);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_024a:
															byte b = *ptr2;
															num = 52;
															while (true)
															{
																IL_023a:
																ptr2++;
																while (true)
																{
																	IL_022a:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_020a:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01fd:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_01ed:
																								if (7 >= b)
																								{
																									while (true)
																									{
																										IL_01e0:
																										if (7 <= b)
																										{
																											while (true)
																											{
																												IL_01d0:
																												array[num5] = 0;
																												while (true)
																												{
																													IL_01a2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 96;
																													while (true)
																													{
																														if (num != 96)
																														{
																															if (num != 1077)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 45:
																																goto IL_01a2;
																															case 26:
																															case 80:
																																goto IL_01d0;
																															case 20:
																																goto IL_01e0;
																															case 64:
																																goto IL_01ed;
																															case 30:
																																goto IL_01fd;
																															case 47:
																																goto IL_020a;
																															case 72:
																																goto IL_021a;
																															case 29:
																																goto IL_022a;
																															case 52:
																																goto IL_023a;
																															case 44:
																															case 77:
																																goto IL_024a;
																															case 66:
																																goto IL_026c;
																															case 8:
																																goto IL_027a;
																															case 32:
																																goto IL_0288;
																															case 0:
																															case 13:
																																goto IL_0296;
																															case 39:
																															case 81:
																																goto IL_02ae;
																															case 18:
																																goto IL_02bc;
																															case 11:
																															case 89:
																																goto IL_02ca;
																															case 27:
																																goto IL_02f0;
																															case 51:
																																goto IL_02fe;
																															case 88:
																																goto IL_0311;
																															case 62:
																															case 83:
																																goto IL_0328;
																															case 50:
																															case 56:
																																goto IL_0336;
																															case 53:
																																goto IL_0344;
																															case 76:
																															case 78:
																																goto IL_0352;
																															case 49:
																																goto IL_039b;
																															case 6:
																																goto IL_03af;
																															case 28:
																																goto IL_03c2;
																															case 36:
																															case 43:
																																goto IL_03cd;
																															case 68:
																																goto IL_03db;
																															case 21:
																															case 38:
																																goto IL_03f7;
																															case 31:
																																goto IL_0465;
																															case 40:
																															case 57:
																																goto IL_0478;
																															case 10:
																																goto IL_04aa;
																															case 7:
																																goto IL_04b8;
																															case 1:
																															case 4:
																															case 12:
																															case 15:
																															case 16:
																															case 22:
																															case 23:
																															case 25:
																															case 35:
																															case 46:
																															case 48:
																															case 55:
																															case 58:
																															case 65:
																															case 73:
																															case 82:
																															case 85:
																																goto end_IL_01e0;
																															case 24:
																																goto IL_04eb;
																															case 33:
																																goto IL_04f9;
																															case 3:
																																goto IL_0507;
																															case 5:
																															case 14:
																															case 37:
																															case 59:
																															case 60:
																															case 61:
																															case 63:
																															case 71:
																															case 75:
																															case 79:
																															case 87:
																																goto end_IL_018f;
																															case 67:
																																goto end_IL_0515;
																															case 74:
																																goto end_IL_0528;
																															case 19:
																																goto end_IL_0532;
																															case 2:
																																goto end_IL_053d;
																															case 86:
																																goto end_IL_0552;
																															case 54:
																															case 84:
																																goto end_IL_0567;
																															case 9:
																																goto end_IL_0577;
																															case 17:
																															case 34:
																																goto end_IL_0587;
																															case 41:
																																goto end_IL_0597;
																															case 42:
																																goto end_IL_05a7;
																															case 69:
																															case 70:
																																goto IL_05c2;
																															}
																															continue;
																														}
																														array2[num5] = null;
																														goto IL_02f0;
																														IL_02f0:
																														num5++;
																														goto IL_02fe;
																														IL_02fe:
																														ptr2 += 8;
																														break;
																														continue;
																														end_IL_018f:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_022a;
																										}
																										num = 15;
																										break;
																										continue;
																										end_IL_01e0:
																										break;
																									}
																									break;
																								}
																								goto IL_02ae;
																								IL_02ca:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_022a;
																								IL_02ae:
																								if (8 < b)
																								{
																									break;
																								}
																								goto IL_02bc;
																								IL_02bc:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_02ca;
																							}
																							break;
																						}
																						goto IL_026c;
																						IL_0296:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_022a;
																						IL_026c:
																						if (6 <= b)
																						{
																							goto end_IL_022a;
																						}
																						goto IL_027a;
																						IL_027a:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_0288;
																						IL_0288:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0296;
																					}
																					break;
																				}
																				goto IL_0311;
																				IL_0478:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 10;
																				goto IL_04aa;
																				IL_0311:
																				if (4 > b)
																				{
																					num = 62;
																					goto IL_0328;
																				}
																				goto IL_0478;
																				IL_04aa:
																				ptr2 += 8;
																				goto IL_04b8;
																				IL_0328:
																				if (2 < b)
																				{
																					goto IL_0336;
																				}
																				goto IL_03c2;
																				IL_0336:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0344;
																				IL_0344:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0352;
																				IL_0352:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 49;
																				goto IL_039b;
																				IL_039b:
																				array[num5 - 2] = 0;
																				goto IL_03af;
																				IL_03af:
																				num5--;
																				goto end_IL_022a;
																				IL_03c2:
																				if (2 > b)
																				{
																					goto IL_03cd;
																				}
																				goto IL_03f7;
																				IL_03cd:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_03db;
																				IL_03db:
																				if (1 > b)
																				{
																					num = 23;
																				}
																				break;
																				IL_04b8:
																				num5--;
																				goto end_IL_022a;
																				IL_03f7:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0465;
																				IL_0465:
																				num5 -= 2;
																				goto end_IL_022a;
																			}
																			break;
																			IL_021a:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04eb;
																	IL_0507:
																	ptr2 += 8;
																	break;
																	IL_04f9:
																	num5++;
																	goto IL_0507;
																	IL_04eb:
																	array[num5] = 0;
																	goto IL_04f9;
																	continue;
																	end_IL_022a:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05c2;
													IL_05c2:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0515:
													break;
												}
												continue;
												end_IL_0528:
												break;
											}
											continue;
											end_IL_0532:
											break;
										}
										continue;
										end_IL_053d:
										break;
									}
									continue;
									end_IL_0552:
									break;
								}
								continue;
								end_IL_0567:
								break;
							}
							continue;
							end_IL_0577:
							break;
						}
						continue;
						end_IL_0587:
						break;
					}
					continue;
					end_IL_0597:
					break;
				}
				continue;
				end_IL_05a7:
				break;
			}
		}
	}
}
