using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 48)]
internal struct CalendarAlgorithmTypeClassType
{
	internal static CalendarAlgorithmTypeClassType IsRemotelyActivatedClientTypeLetterNumber/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 00 00 00 00 00 03 00 00 00 01 01 00 00 00 04 00 00 00 01 01 00 00 00 05 06 00 00 00 00 00 00 00 00 05 07) */;
}
