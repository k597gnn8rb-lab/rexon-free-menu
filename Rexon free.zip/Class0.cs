using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using ExitGames.Client.Photon;
using GorillaGameModes;
using GorillaNetworking;
using GorillaTagScripts;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;
using UnityEngine.Localization;

[Mod("Create Public Room", "Overpowered", "Creates a public room.", true, 6, ModType.const_1, false)]
internal class Class0 : MonoBehaviour
{
	[StructLayout(LayoutKind.Auto)]
	internal struct _003CForceCreateRoom_003Ed__3 : IAsyncStateMachine
	{
		public int int_0;

		public AsyncTaskMethodBuilder asyncTaskMethodBuilder_0;

		public string string_0;

		public RoomConfig roomConfig_0;

		private TaskAwaiter taskAwaiter_0;

		private TaskAwaiter<NetJoinResult> taskAwaiter_1;

		internal static object object_0;

		private void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			asyncTaskMethodBuilder_0.SetStateMachine(stateMachine);
		}

		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine stateMachine)
		{
			//ILSpy generated this explicit interface implementation from .override directive in SetStateMachine
			this.SetStateMachine(stateMachine);
		}

		private void MoveNext()
		{
			int num = 1;
			int num3 = default(int);
			while (true)
			{
				int num2 = int_0;
				num = 9;
				while (true)
				{
					if (num != 9)
					{
						if (num == 990)
						{
							switch (num)
							{
							case 1:
								goto end_IL_0023;
							case 0:
							case 2:
								goto IL_003d;
							}
							continue;
						}
					}
					else
					{
						num3 = num2;
					}
					goto IL_003d;
					IL_003d:
					try
					{
						int num4 = 1;
						while (true)
						{
							if (num3 != 0)
							{
								goto IL_0042;
							}
							int num5 = 1;
							goto IL_0043;
							IL_0043:
							int num6 = num5 * 4 + 2;
							while (true)
							{
								IL_0071:
								System.Runtime.CompilerServices.Unsafe.As<_003CForceCreateRoom_003Ed__3, int>(ref this) = num6;
								num4 = 9;
								while (true)
								{
									if (num4 != 9)
									{
										if (num4 != 990)
										{
											break;
										}
										switch (num4)
										{
										case 0:
											break;
										default:
											continue;
										case 2:
											goto IL_0071;
										case 1:
											goto end_IL_0069;
										}
										goto IL_0042;
									}
									return;
									continue;
									end_IL_0069:
									break;
								}
								break;
							}
							continue;
							IL_0042:
							num5 = 0;
							goto IL_0043;
						}
					}
					catch (global::System.Exception obj)
					{
						int num7 = 1;
						while (true)
						{
							Exception ex = (Exception)obj;
							while (true)
							{
								Exception exception = ex;
								num7 = 12;
								while (true)
								{
									if (num7 != 12)
									{
										if (num7 != 993)
										{
											return;
										}
										switch (num7)
										{
										case 0:
											goto end_IL_00b4;
										case 1:
											goto end_IL_00bc;
										case 2:
											goto IL_00d3;
										case 3:
										case 4:
										case 5:
											return;
										}
										continue;
									}
									int_0 = -2;
									goto IL_00d3;
									IL_00d3:
									asyncTaskMethodBuilder_0.SetException(exception);
									return;
									continue;
									end_IL_00b4:
									break;
								}
								continue;
								end_IL_00bc:
								break;
							}
						}
					}
					continue;
					end_IL_0023:
					break;
				}
			}
		}

		void IAsyncStateMachine.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			this.MoveNext();
		}

		static _003CForceCreateRoom_003Ed__3()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 9;
						while (true)
						{
							if (num != 9)
							{
								if (num != 990)
								{
									break;
								}
								switch (num)
								{
								case 2:
									goto end_IL_002d;
								case 0:
									goto end_IL_003a;
								case 1:
									goto end_IL_0046;
								}
								continue;
							}
							return;
							continue;
							end_IL_002d:
							break;
						}
						continue;
						end_IL_003a:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
			}
		}

		internal static bool smethod_1()
		{
			return object_0 == null;
		}

		internal static object smethod_2()
		{
			return object_0;
		}
	}

	internal sealed class _003CMakeRoomVisibleCoroutine_003Ed__5 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		private float float_0;

		private float float_1;

		private static IntPtr[] MicrosoftTelemetryByteEqualityComparer;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		public _003CMakeRoomVisibleCoroutine_003Ed__5(int _003C_003E1__state)
		{
			object obj = this;
			((_003CMakeRoomVisibleCoroutine_003Ed__5)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 62;
			byte[] array = default(byte[]);
			byte* ptr = default(byte*);
			int num5 = default(int);
			int num6 = default(int);
			object[] array2 = default(object[]);
			object[] array3 = default(object[]);
			long[] array4 = default(long[]);
			byte* ptr2 = default(byte*);
			byte b = default(byte);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						num = 69;
						while (true)
						{
							if (num != 69)
							{
								if (num != 1050)
								{
									goto IL_03e5;
								}
								switch (num)
								{
								case 40:
									goto end_IL_0123;
								case 61:
									goto end_IL_0133;
								case 62:
									goto end_IL_013e;
								case 19:
									goto IL_0167;
								case 30:
									goto IL_0175;
								case 48:
									goto IL_017e;
								case 27:
									goto IL_018c;
								case 55:
									goto IL_019a;
								case 41:
									goto IL_01a8;
								case 32:
									goto IL_01b1;
								case 17:
									goto IL_01b9;
								case 15:
								case 18:
								case 36:
								case 37:
								case 42:
								case 58:
									goto IL_01c2;
								case 11:
									goto IL_01d2;
								case 47:
									goto IL_01db;
								case 53:
									goto IL_01e4;
								case 46:
									goto IL_01f2;
								case 20:
									goto IL_0200;
								case 45:
									goto IL_020e;
								case 14:
									goto IL_021c;
								case 6:
								case 59:
									goto IL_0227;
								case 10:
									goto IL_0267;
								case 16:
									goto IL_027b;
								case 9:
									goto IL_028e;
								case 0:
								case 56:
									goto IL_0299;
								case 24:
									goto IL_02a7;
								case 4:
								case 38:
									goto IL_02b5;
								case 13:
									goto IL_02ce;
								case 3:
									goto IL_02e5;
								case 25:
									goto IL_02f3;
								case 12:
									goto IL_0306;
								case 21:
								case 22:
									goto IL_0319;
								case 43:
									goto IL_0324;
								case 5:
								case 39:
									goto IL_032f;
								case 50:
									goto IL_035d;
								case 26:
									goto IL_037b;
								case 31:
									goto IL_038f;
								case 1:
								case 34:
									goto IL_039a;
								case 23:
									goto IL_03b6;
								case 44:
									goto IL_03c4;
								case 60:
									goto IL_03d2;
								case 2:
								case 7:
								case 8:
								case 28:
								case 29:
								case 33:
								case 35:
								case 51:
								case 52:
								case 57:
									goto IL_03e5;
								case 49:
								case 54:
									return;
								}
								continue;
							}
							array = new byte[3];
							goto IL_0167;
							IL_039a:
							byte* num4 = ptr;
							num5 = 1;
							ptr = num4 + -200;
							goto IL_01c2;
							IL_03b6:
							array[num6] = 5;
							goto IL_03c4;
							IL_03e5:
							array2[num6] = array3[*(int*)(ptr + num3)];
							goto IL_03b6;
							IL_0167:
							array2 = new object[3];
							goto IL_0175;
							IL_0175:
							num = 48;
							goto IL_017e;
							IL_017e:
							array4 = new long[3];
							goto IL_018c;
							IL_018c:
							array3 = new object[1];
							goto IL_019a;
							IL_019a:
							array3[0] = this;
							goto IL_01a8;
							IL_01a8:
							ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getKeyAvailableDefineDefaultConstructor.BrowserFavoritesBuiltinBackupOperatorsSid);
							goto IL_01b1;
							IL_01b1:
							ptr = ptr2;
							goto IL_01b9;
							IL_01b9:
							num = 18;
							goto IL_01c2;
							IL_01c2:
							if (num5 == 1)
							{
								return;
							}
							goto IL_01d2;
							IL_01d2:
							num = 47;
							goto IL_01db;
							IL_01db:
							b = *ptr;
							goto IL_01e4;
							IL_01e4:
							ptr++;
							goto IL_01f2;
							IL_01f2:
							if (b >= 1)
							{
								goto IL_0200;
							}
							goto IL_03e5;
							IL_0200:
							if (b <= 5)
							{
								goto IL_020e;
							}
							goto IL_03e5;
							IL_020e:
							if (3 >= b)
							{
								goto IL_021c;
							}
							goto IL_0319;
							IL_021c:
							if (3 <= b)
							{
								goto IL_0227;
							}
							goto IL_028e;
							IL_0227:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
							goto IL_0267;
							IL_0267:
							array[num6 - 2] = 0;
							goto IL_027b;
							IL_027b:
							num6--;
							goto IL_01c2;
							IL_028e:
							if (1 < b)
							{
								goto IL_0299;
							}
							goto IL_0306;
							IL_0299:
							if (2 >= b)
							{
								goto IL_02a7;
							}
							goto IL_03e5;
							IL_02a7:
							if (2 <= b)
							{
								goto IL_02b5;
							}
							goto IL_03e5;
							IL_02b5:
							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr + num3);
							goto IL_02ce;
							IL_02ce:
							array[num6] = 0;
							num = 3;
							goto IL_02e5;
							IL_02e5:
							num6++;
							goto IL_02f3;
							IL_02f3:
							ptr += 8;
							goto IL_01c2;
							IL_0306:
							if (1 <= b)
							{
							}
							goto IL_03e5;
							IL_0319:
							if (4 >= b)
							{
								goto IL_0324;
							}
							goto IL_037b;
							IL_0324:
							if (4 <= b)
							{
								goto IL_032f;
							}
							num = 33;
							goto IL_03e5;
							IL_032f:
							((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num6 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
							goto IL_035d;
							IL_035d:
							num6 -= 2;
							goto IL_01c2;
							IL_03c4:
							num6++;
							goto IL_03d2;
							IL_037b:
							if (5 >= b)
							{
								num = 31;
								goto IL_038f;
							}
							goto IL_03e5;
							IL_03d2:
							ptr += 8;
							goto IL_01c2;
							IL_038f:
							if (5 <= b)
							{
								goto IL_039a;
							}
							goto IL_03e5;
							continue;
							end_IL_0123:
							break;
						}
						continue;
						end_IL_0133:
						break;
					}
					continue;
					end_IL_013e:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			int num = 70;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[1];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateInstanceFromControlFlags.DynamicPartitionerForArrayUNICODEINTPTRSTRING);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0471:
																byte b = *ptr2;
																while (true)
																{
																	IL_0461:
																	ptr2++;
																	while (true)
																	{
																		IL_0451:
																		if (b >= 1)
																		{
																			while (b <= 27)
																			{
																				while (true)
																				{
																					IL_0434:
																					if (14 < b)
																					{
																						while (true)
																						{
																							IL_0424:
																							if (21 < b)
																							{
																								while (true)
																								{
																									IL_0417:
																									if (24 < b)
																									{
																										while (true)
																										{
																											IL_0407:
																											if (26 >= b)
																											{
																												while (true)
																												{
																													IL_03f7:
																													if (26 > b)
																													{
																														while (25 >= b)
																														{
																															num = 237;
																															while (true)
																															{
																																if (num != 237)
																																{
																																	if (num != 1218)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 52:
																																		goto IL_03e4;
																																	case 155:
																																		goto IL_03f7;
																																	case 118:
																																		goto IL_0407;
																																	case 109:
																																		goto IL_0417;
																																	case 191:
																																		goto IL_0424;
																																	case 183:
																																		goto IL_0434;
																																	case 208:
																																		goto IL_0441;
																																	case 24:
																																		goto IL_0451;
																																	case 227:
																																		goto IL_0461;
																																	case 0:
																																	case 177:
																																		goto IL_0471;
																																	case 135:
																																		goto IL_047c;
																																	case 139:
																																		goto IL_048c;
																																	case 66:
																																	case 141:
																																		goto IL_049f;
																																	case 159:
																																		goto IL_04cc;
																																	case 171:
																																		goto IL_04df;
																																	case 78:
																																	case 174:
																																		goto IL_04f6;
																																	case 5:
																																		goto IL_0536;
																																	case 79:
																																		goto IL_054a;
																																	case 181:
																																		goto IL_055d;
																																	case 131:
																																		goto IL_056b;
																																	case 31:
																																	case 91:
																																		goto IL_0579;
																																	case 138:
																																		goto IL_05cb;
																																	case 184:
																																		goto IL_05de;
																																	case 46:
																																		goto IL_05ec;
																																	case 7:
																																		goto IL_05fa;
																																	case 18:
																																	case 121:
																																		goto IL_0605;
																																	case 110:
																																	case 189:
																																		goto IL_0641;
																																	case 133:
																																		goto IL_064f;
																																	case 160:
																																		goto IL_066d;
																																	case 190:
																																		goto IL_0680;
																																	case 102:
																																		goto IL_068b;
																																	case 132:
																																		goto IL_06a2;
																																	case 193:
																																		goto IL_06b5;
																																	case 13:
																																	case 111:
																																		goto IL_06c3;
																																	case 11:
																																		goto IL_06f1;
																																	case 198:
																																		goto IL_0704;
																																	case 199:
																																		goto IL_0717;
																																	case 167:
																																		goto IL_0722;
																																	case 37:
																																		goto IL_0730;
																																	case 123:
																																		goto IL_0747;
																																	case 36:
																																	case 93:
																																		goto IL_0755;
																																	case 75:
																																		goto IL_0783;
																																	case 89:
																																		goto IL_079f;
																																	case 112:
																																		goto IL_07ad;
																																	case 1:
																																	case 143:
																																		goto IL_07bb;
																																	case 179:
																																		goto IL_07cf;
																																	case 203:
																																		goto IL_080d;
																																	case 25:
																																	case 206:
																																		goto IL_081d;
																																	case 211:
																																		goto IL_0845;
																																	case 15:
																																	case 185:
																																		goto IL_0853;
																																	case 29:
																																		goto IL_0861;
																																	case 90:
																																		goto IL_0885;
																																	case 205:
																																		goto IL_0893;
																																	case 212:
																																		goto IL_08a6;
																																	case 213:
																																		goto IL_08b9;
																																	case 59:
																																	case 92:
																																		goto IL_08c4;
																																	case 65:
																																		goto IL_08e0;
																																	case 88:
																																		goto IL_08ee;
																																	case 176:
																																		goto IL_08fc;
																																	case 152:
																																		goto IL_0907;
																																	case 3:
																																	case 144:
																																		goto IL_0915;
																																	case 62:
																																		goto IL_092d;
																																	case 120:
																																		goto IL_093b;
																																	case 42:
																																		goto IL_0949;
																																	case 119:
																																		goto IL_095c;
																																	case 55:
																																		goto IL_096a;
																																	case 9:
																																	case 94:
																																		goto IL_0978;
																																	case 41:
																																	case 156:
																																		goto IL_09c4;
																																	case 122:
																																		goto IL_09ed;
																																	case 162:
																																		goto IL_0a04;
																																	case 19:
																																		goto IL_0a17;
																																	case 83:
																																		goto IL_0a25;
																																	case 6:
																																	case 10:
																																		goto IL_0a33;
																																	case 82:
																																		goto IL_0ab1;
																																	case 101:
																																		goto IL_0acd;
																																	case 40:
																																		goto IL_0adb;
																																	case 146:
																																		goto IL_0aeb;
																																	case 96:
																																	case 214:
																																		goto IL_0afb;
																																	case 161:
																																		goto IL_0b09;
																																	case 219:
																																		goto IL_0b2e;
																																	case 222:
																																		goto IL_0b41;
																																	case 105:
																																	case 126:
																																		goto IL_0b4f;
																																	case 72:
																																		goto IL_0b71;
																																	case 175:
																																		goto IL_0b7f;
																																	case 98:
																																		goto IL_0b8d;
																																	case 223:
																																		goto IL_0ba9;
																																	case 21:
																																		goto IL_0bb3;
																																	case 124:
																																		goto IL_0bca;
																																	case 27:
																																	case 226:
																																		goto IL_0bdd;
																																	case 228:
																																		goto IL_0bfe;
																																	case 81:
																																		goto IL_0c0c;
																																	case 22:
																																	case 99:
																																		goto IL_0c17;
																																	case 116:
																																		goto IL_0c25;
																																	case 136:
																																		goto IL_0c49;
																																	case 63:
																																		goto IL_0c57;
																																	case 58:
																																		goto IL_0c6a;
																																	case 108:
																																		goto IL_0c75;
																																	case 86:
																																	case 125:
																																		goto IL_0c83;
																																	case 169:
																																		goto IL_0cca;
																																	case 73:
																																		goto IL_0cde;
																																	case 164:
																																		goto IL_0cf1;
																																	case 35:
																																		goto IL_0cff;
																																	case 33:
																																	case 178:
																																		goto IL_0d0d;
																																	case 137:
																																		goto IL_0d4d;
																																	case 195:
																																		goto IL_0d61;
																																	case 48:
																																		goto IL_0d74;
																																	case 49:
																																		goto IL_0d82;
																																	case 104:
																																	case 209:
																																		goto IL_0d8d;
																																	case 148:
																																		goto IL_0dcb;
																																	case 130:
																																		goto IL_0ddf;
																																	case 134:
																																		goto IL_0df2;
																																	case 172:
																																		goto IL_0e00;
																																	case 54:
																																	case 115:
																																		goto IL_0e0e;
																																	case 202:
																																		goto IL_0e6c;
																																	case 67:
																																		goto IL_0e7f;
																																	case 165:
																																		goto IL_0e8d;
																																	case 47:
																																	case 221:
																																		goto IL_0e9b;
																																	case 30:
																																		goto IL_0efd;
																																	case 229:
																																		goto IL_0f10;
																																	case 140:
																																		goto IL_0f1e;
																																	case 128:
																																		goto IL_0f2c;
																																	case 230:
																																		goto IL_0f3f;
																																	case 200:
																																		goto IL_0f53;
																																	case 20:
																																	case 80:
																																		goto IL_0f74;
																																	case 150:
																																		goto IL_0fb2;
																																	case 153:
																																		goto IL_0fc0;
																																	case 53:
																																	case 216:
																																		goto IL_0fd3;
																																	case 154:
																																		goto IL_1011;
																																	case 103:
																																		goto IL_101f;
																																	case 147:
																																		goto IL_102f;
																																	case 2:
																																		goto IL_103a;
																																	case 8:
																																	case 14:
																																	case 16:
																																	case 23:
																																	case 28:
																																	case 39:
																																	case 56:
																																	case 60:
																																	case 61:
																																	case 71:
																																	case 76:
																																	case 77:
																																	case 84:
																																	case 85:
																																	case 113:
																																	case 117:
																																	case 127:
																																	case 129:
																																	case 145:
																																	case 157:
																																	case 158:
																																	case 170:
																																	case 187:
																																	case 188:
																																	case 192:
																																	case 196:
																																	case 201:
																																	case 215:
																																	case 217:
																																	case 220:
																																		goto end_IL_03e4;
																																	case 12:
																																	case 17:
																																	case 32:
																																	case 34:
																																	case 38:
																																	case 43:
																																	case 50:
																																	case 51:
																																	case 57:
																																	case 64:
																																	case 68:
																																	case 74:
																																	case 95:
																																	case 97:
																																	case 100:
																																	case 106:
																																	case 107:
																																	case 114:
																																	case 142:
																																	case 151:
																																	case 166:
																																	case 168:
																																	case 173:
																																	case 180:
																																	case 182:
																																	case 210:
																																	case 218:
																																	case 224:
																																	case 225:
																																		goto end_IL_03d1;
																																	case 204:
																																		goto end_IL_1058;
																																	case 186:
																																		goto end_IL_106b;
																																	case 163:
																																		goto end_IL_1075;
																																	case 26:
																																		goto end_IL_1080;
																																	case 207:
																																		goto end_IL_1090;
																																	case 149:
																																	case 197:
																																		goto end_IL_10a0;
																																	case 45:
																																		goto end_IL_10b0;
																																	case 87:
																																	case 194:
																																		goto end_IL_10c0;
																																	case 69:
																																		goto end_IL_10d0;
																																	case 70:
																																		goto end_IL_10e0;
																																	case 4:
																																	case 44:
																																		goto IL_10fb;
																																	}
																																	continue;
																																}
																																if (25 > b)
																																{
																																	goto end_IL_03e4;
																																}
																																goto IL_0f74;
																																IL_0f74:
																																((delegate*<Room, bool, void>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((Room)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																																goto IL_0fb2;
																																IL_0fc0:
																																ptr2 += 8;
																																break;
																																IL_0fb2:
																																num5 -= 2;
																																goto IL_0fc0;
																																continue;
																																end_IL_03d1:
																																break;
																															}
																															goto end_IL_0451;
																															continue;
																															end_IL_03e4:
																															break;
																															IL_03e4:;
																														}
																														break;
																													}
																													goto IL_0fd3;
																													IL_101f:
																													ptr2 += 8;
																													goto end_IL_0451;
																													IL_0fd3:
																													((delegate*<Room, bool, void>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((Room)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																													goto IL_1011;
																													IL_1011:
																													num5 -= 2;
																													goto IL_101f;
																												}
																												break;
																											}
																											goto IL_102f;
																											IL_103a:
																											if (27 <= b)
																											{
																											}
																											break;
																											IL_102f:
																											if (27 < b)
																											{
																												break;
																											}
																											goto IL_103a;
																										}
																										break;
																									}
																									goto IL_048c;
																									IL_0893:
																									ptr2 += 8;
																									goto end_IL_0451;
																									IL_048c:
																									if (24 > b)
																									{
																										goto IL_055d;
																									}
																									goto IL_0641;
																									IL_0641:
																									array[num5] = 5;
																									goto IL_064f;
																									IL_064f:
																									array2[num5] = ((delegate*<Room>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])();
																									goto IL_066d;
																									IL_066d:
																									num5++;
																									goto IL_0704;
																									IL_0704:
																									ptr2 += 8;
																									goto end_IL_0451;
																									IL_055d:
																									if (22 >= b)
																									{
																										goto IL_056b;
																									}
																									goto IL_080d;
																									IL_056b:
																									if (22 > b)
																									{
																										break;
																									}
																									goto IL_0579;
																									IL_0579:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_05cb;
																									IL_05cb:
																									num5--;
																									goto end_IL_0451;
																									IL_080d:
																									if (23 < b)
																									{
																										break;
																									}
																									goto IL_0845;
																									IL_0845:
																									if (23 > b)
																									{
																										break;
																									}
																									goto IL_0853;
																									IL_0853:
																									array[num5] = 0;
																									goto IL_0861;
																									IL_0861:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_0885;
																									IL_0885:
																									num5++;
																									goto IL_0893;
																								}
																								break;
																							}
																							goto IL_04df;
																							IL_0e9b:
																							ptr2 = ((*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0efd;
																							IL_04df:
																							if (21 <= b)
																							{
																								num = 174;
																								goto IL_04f6;
																							}
																							goto IL_0bfe;
																							IL_0efd:
																							num5 -= 2;
																							goto end_IL_0451;
																							IL_04f6:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0536;
																							IL_0536:
																							array[num5 - 2] = 0;
																							goto IL_054a;
																							IL_054a:
																							num5--;
																							goto end_IL_0451;
																							IL_0bfe:
																							if (17 >= b)
																							{
																								goto IL_0c0c;
																							}
																							goto IL_0d74;
																							IL_0c0c:
																							if (17 <= b)
																							{
																								goto IL_0c17;
																							}
																							goto IL_0c6a;
																							IL_0c17:
																							array[num5] = 0;
																							goto IL_0c25;
																							IL_0c25:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_0c49;
																							IL_0c49:
																							num5++;
																							goto IL_0c57;
																							IL_0c57:
																							ptr2 += 8;
																							goto end_IL_0451;
																							IL_0c6a:
																							if (15 >= b)
																							{
																								goto IL_0c75;
																							}
																							goto IL_0cf1;
																							IL_0c75:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0c83;
																							IL_0c83:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CMakeRoomVisibleCoroutine_003Ed__5, float>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 1]);
																							num = 169;
																							goto IL_0cca;
																							IL_0cca:
																							array[num5 - 1] = 3;
																							goto IL_0cde;
																							IL_0cde:
																							ptr2 += 8;
																							goto end_IL_0451;
																							IL_0cf1:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0cff;
																							IL_0cff:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0d0d;
																							IL_0d0d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0d4d;
																							IL_0d4d:
																							array[num5 - 2] = 3;
																							goto IL_0d61;
																							IL_0d61:
																							num5--;
																							goto end_IL_0451;
																							IL_0d74:
																							if (19 >= b)
																							{
																								goto IL_0d82;
																							}
																							goto IL_0e7f;
																							IL_0d82:
																							if (19 <= b)
																							{
																								goto IL_0d8d;
																							}
																							goto IL_0df2;
																							IL_0d8d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CMakeRoomVisibleCoroutine_003Ed__5, float>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 1]);
																							goto IL_0dcb;
																							IL_0dcb:
																							array[num5 - 1] = 3;
																							goto IL_0ddf;
																							IL_0ddf:
																							ptr2 += 8;
																							goto end_IL_0451;
																							IL_0df2:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_0e00;
																							IL_0e00:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0e0e;
																							IL_0e0e:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0e6c;
																							IL_0e6c:
																							num5--;
																							goto end_IL_0451;
																							IL_0e7f:
																							if (20 < b)
																							{
																								break;
																							}
																							goto IL_0e8d;
																							IL_0e8d:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_0e9b;
																						}
																						break;
																					}
																					goto IL_047c;
																					IL_0b8d:
																					ptr2 += 8;
																					num = 38;
																					goto end_IL_0451;
																					IL_047c:
																					if (14 <= b)
																					{
																						goto IL_049f;
																					}
																					goto IL_05de;
																					IL_05de:
																					if (7 < b)
																					{
																						goto IL_05ec;
																					}
																					goto IL_08b9;
																					IL_05ec:
																					if (10 >= b)
																					{
																						goto IL_05fa;
																					}
																					goto IL_0717;
																					IL_05fa:
																					if (10 <= b)
																					{
																						goto IL_0605;
																					}
																					goto IL_0680;
																					IL_0605:
																					((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					num = 212;
																					goto IL_08a6;
																					IL_08a6:
																					num5 -= 2;
																					goto end_IL_0451;
																					IL_0680:
																					if (8 < b)
																					{
																						goto IL_068b;
																					}
																					goto IL_06b5;
																					IL_068b:
																					if (9 < b)
																					{
																						break;
																					}
																					num = 132;
																					goto IL_06a2;
																					IL_049f:
																					((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																					goto IL_04cc;
																					IL_06a2:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_081d;
																					IL_081d:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																					num = 229;
																					goto IL_0f10;
																					IL_0f10:
																					array[num5] = 3;
																					goto IL_0f1e;
																					IL_0f1e:
																					num5++;
																					goto IL_0f2c;
																					IL_0f2c:
																					ptr2 += 8;
																					goto end_IL_0451;
																					IL_06b5:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_06c3;
																					IL_06c3:
																					((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06f1;
																					IL_06f1:
																					num5 -= 2;
																					goto end_IL_0451;
																					IL_0717:
																					if (12 >= b)
																					{
																						goto IL_0722;
																					}
																					goto IL_079f;
																					IL_0722:
																					if (12 > b)
																					{
																						goto IL_0730;
																					}
																					goto IL_0bdd;
																					IL_0730:
																					if (11 < b)
																					{
																						break;
																					}
																					num = 123;
																					goto IL_0747;
																					IL_04cc:
																					num5 -= 2;
																					goto end_IL_0451;
																					IL_0747:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0755;
																					IL_0755:
																					((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0783;
																					IL_0783:
																					num5 -= 2;
																					num = 210;
																					goto end_IL_0451;
																					IL_0bdd:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					num = 95;
																					goto end_IL_0451;
																					IL_079f:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_07ad;
																					IL_07ad:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_07bb;
																					IL_07bb:
																					array[num5 - 1] = 5;
																					goto IL_07cf;
																					IL_07cf:
																					array2[num5 - 1] = ((delegate*<float, WaitForSeconds>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_0b2e;
																					IL_0b2e:
																					ptr2 += 8;
																					goto end_IL_0451;
																					IL_08b9:
																					if (7 <= b)
																					{
																						goto IL_08c4;
																					}
																					goto IL_08e0;
																					IL_08c4:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0451;
																					IL_08e0:
																					if (3 >= b)
																					{
																						goto IL_08ee;
																					}
																					goto IL_0a17;
																					IL_08ee:
																					if (3 > b)
																					{
																						goto IL_08fc;
																					}
																					goto IL_09c4;
																					IL_08fc:
																					if (1 >= b)
																					{
																						goto IL_0907;
																					}
																					goto IL_095c;
																					IL_0907:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_0915;
																					IL_0915:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_092d;
																					IL_092d:
																					array[num5] = 5;
																					goto IL_093b;
																					IL_093b:
																					num5++;
																					goto IL_0949;
																					IL_0949:
																					ptr2 += 8;
																					goto end_IL_0451;
																					IL_095c:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_096a;
																					IL_096a:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0978;
																					IL_0978:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CMakeRoomVisibleCoroutine_003Ed__5, int>)MicrosoftTelemetryByteEqualityComparer[*(int*)(ptr2 + num3)])((_003CMakeRoomVisibleCoroutine_003Ed__5)array2[num5 - 1]);
																					num = 230;
																					goto IL_0f3f;
																					IL_0f3f:
																					array[num5 - 1] = 0;
																					goto IL_0f53;
																					IL_0f53:
																					ptr2 += 8;
																					goto end_IL_0451;
																					IL_09c4:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_09ed;
																					IL_09ed:
																					ptr2 += 8;
																					num = 162;
																					goto IL_0a04;
																					IL_0a04:
																					num5--;
																					goto end_IL_0451;
																					IL_0a17:
																					if (5 >= b)
																					{
																						goto IL_0a25;
																					}
																					goto IL_0aeb;
																					IL_0a25:
																					if (5 <= b)
																					{
																						goto IL_0a33;
																					}
																					goto IL_0acd;
																					IL_0a33:
																					ptr2 = ptr + *(int*)(ptr2 + (*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) - (*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) - *(int*)(ptr2 + num3)) * (((uint)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) > (uint)(*(int*)(ptr2 + num3) - 1)) ? 1 : 0) + 1) * 8 + num3);
																					goto IL_0ab1;
																					IL_0ab1:
																					num5--;
																					num = 173;
																					goto end_IL_0451;
																					IL_0acd:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0adb;
																					IL_0adb:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_0afb;
																					IL_0afb:
																					array[num5] = 0;
																					goto IL_0b09;
																					IL_0b09:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0ba9;
																					IL_0ba9:
																					array2[num5] = null;
																					goto IL_0bb3;
																					IL_0bb3:
																					num5++;
																					num = 124;
																					goto IL_0bca;
																					IL_0bca:
																					ptr2 += 8;
																					goto end_IL_0451;
																					IL_0aeb:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_0b41;
																					IL_0b41:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0b4f;
																					IL_0b4f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 72;
																					goto IL_0b71;
																					IL_0b71:
																					array[num5] = 0;
																					goto IL_0b7f;
																					IL_0b7f:
																					num5++;
																					goto IL_0b8d;
																				}
																				break;
																				IL_0441:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0451:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_10fb;
														IL_10fb:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														continue;
														end_IL_1058:
														break;
													}
													continue;
													end_IL_106b:
													break;
												}
												continue;
												end_IL_1075:
												break;
											}
											continue;
											end_IL_1080:
											break;
										}
										continue;
										end_IL_1090:
										break;
									}
									continue;
									end_IL_10a0:
									break;
								}
								continue;
								end_IL_10b0:
								break;
							}
							continue;
							end_IL_10c0:
							break;
						}
						continue;
						end_IL_10d0:
						break;
					}
					continue;
					end_IL_10e0:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		void IEnumerator.Reset()
		{
			NotSupportedException ex = new NotSupportedException();
			object obj = ex;
			throw (Exception)obj;
		}

		static _003CMakeRoomVisibleCoroutine_003Ed__5()
		{
			int num = 6;
			while (true)
			{
				Class296.Aw4EYyy3h();
				num = 5;
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 13;
						while (true)
						{
							if (num != 13)
							{
								if (num != 994)
								{
									break;
								}
								switch (num)
								{
								case 0:
								case 3:
									goto end_IL_003d;
								case 5:
									goto end_IL_004a;
								case 6:
									goto end_IL_0059;
								case 1:
									return;
								case 2:
									return;
								case 4:
									return;
								}
								continue;
							}
							return;
							continue;
							end_IL_003d:
							break;
						}
						continue;
						end_IL_004a:
						break;
					}
					continue;
					end_IL_0059:
					break;
				}
			}
		}
	}

	private static bool bool_0;

	private static double double_0;

	private static float float_0;

	private static float float_1;

	private static int int_0;

	private static bool bool_1;

	private static float float_2;

	private static IntPtr[] getIsFamilyOrAssemblyRegisterTrackingHandler;

	private static Vector3 AssemblyMetadataAttributegetNaNSymbol;

	private static IntPtr[] SymAddressKindEventCommand;

	private static _003CForceCreateRoom_003Ed__3 ConvertPermissionSetCORESERVER;

	private static IntPtr[] ArgRegKeyDelHiveStackCrawlMarkHandle;

	private static IntPtr[] DXNNCMSASSEMBLYDEPLOYMENTFLAGBEFOREAPPLICATIONSTARTUP;

	private static IntPtr[] IEnumSTOREDEPLOYMENTMETADATAFormKDDisallowUnassigned;

	private static GorillaComputer HaveMonthSafeCspHandle()
	{
		return GorillaComputer.instance;
	}

	private static Coroutine LastImmediateValueFormKCDisallowUnassigned(MonoBehaviour monoBehaviour_0, IEnumerator ienumerator_0)
	{
		return monoBehaviour_0.StartCoroutine(ienumerator_0);
	}

	private static double BitConverterGetNamespaces(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static string ParameterAttributesgetIsGenericParameter(PhotonNetworkController photonNetworkController_0)
	{
		return photonNetworkController_0.platformTag;
	}

	private static string DateTimeNativeSetting(string string_0, string string_1, string string_2)
	{
		return string_0.Replace(string_1, string_2);
	}

	private static string CMSSECTIONIDCLRSURROGATESECTIONsetPositiveInfinitySymbol(GorillaComputer gorillaComputer_0)
	{
		return gorillaComputer_0.currentQueue;
	}

	static Class0()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 16;
					while (true)
					{
						if (num == 16 || num != 997)
						{
							return;
						}
						switch (num)
						{
						case 0:
						case 2:
						case 4:
						case 8:
							goto end_IL_0049;
						case 5:
							goto end_IL_0056;
						case 6:
							goto end_IL_006b;
						case 1:
							return;
						case 3:
							return;
						case 7:
							return;
						case 9:
							return;
						}
						continue;
						end_IL_0049:
						break;
					}
					continue;
					end_IL_0056:
					break;
				}
				continue;
				end_IL_006b:
				break;
			}
		}
	}

	private static ExitGames.Client.Photon.Hashtable ResourceFallbackManagerElement()
	{
		return new ExitGames.Client.Photon.Hashtable();
	}

	private static string setResourcesGetManifestResourceNames()
	{
		return smethod_2();
	}

	private static bool getIsRightToLeftNumberDecimalDigits(string string_0)
	{
		return string.IsNullOrEmpty(string_0);
	}

	private static double AsymmetricSignatureFormatterIsBitOperatingSystem(double double_1)
	{
		return Math.Ceiling(double_1);
	}

	private static int WhiteClipboard(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static double XConstantsEpsilon(double double_1)
	{
		return Math.Sqrt(double_1);
	}

	private static int ReadDecimalGetApplicationComponentManifest()
	{
		return smethod_6();
	}

	public unsafe static Task smethod_1(string string_0, RoomConfig roomConfig_0)
	{
		int num = 76;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											object[] array6 = new object[3];
											while (true)
											{
												array6[0] = string_0;
												while (true)
												{
													array6[1] = roomConfig_0;
													while (true)
													{
														array6[2] = ConvertPermissionSetCORESERVER;
														while (true)
														{
															byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCspKeyContainerInfoFailureKind.tpwItemsEndBufferedArray);
															while (true)
															{
																byte* ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_05ff:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_05ef:
																				ptr2++;
																				while (true)
																				{
																					IL_05df:
																					if (b >= 1)
																					{
																						while (b <= 37)
																						{
																							while (true)
																							{
																								IL_05c2:
																								if (19 < b)
																								{
																									while (true)
																									{
																										IL_05b2:
																										if (28 >= b)
																										{
																											num = 108;
																											while (true)
																											{
																												IL_05a2:
																												if (28 <= b)
																												{
																													while (true)
																													{
																														IL_0560:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														while (true)
																														{
																															IL_0541:
																															array[num6 - 2] = 3;
																															num = 213;
																															while (true)
																															{
																																IL_0528:
																																num6--;
																																num = 318;
																																while (num != 318)
																																{
																																	if (num != 1299)
																																	{
																																		goto end_IL_05cf;
																																	}
																																	switch (num)
																																	{
																																	case 213:
																																		goto IL_0528;
																																	case 270:
																																		goto IL_0541;
																																	case 126:
																																	case 187:
																																		goto IL_0560;
																																	case 108:
																																		goto IL_05a2;
																																	case 134:
																																		goto IL_05b2;
																																	case 253:
																																		goto IL_05c2;
																																	case 1:
																																		goto IL_05cf;
																																	case 39:
																																		goto IL_05df;
																																	case 275:
																																		goto IL_05ef;
																																	case 178:
																																	case 233:
																																		goto IL_05ff;
																																	case 43:
																																		goto IL_060a;
																																	case 173:
																																		goto IL_0623;
																																	case 149:
																																		goto IL_062e;
																																	case 23:
																																	case 144:
																																		goto IL_0641;
																																	case 33:
																																		goto IL_0663;
																																	case 195:
																																		goto IL_0676;
																																	case 40:
																																	case 64:
																																		goto IL_0684;
																																	case 46:
																																		goto IL_06d3;
																																	case 56:
																																		goto IL_06e7;
																																	case 190:
																																		goto IL_0705;
																																	case 54:
																																		goto IL_0710;
																																	case 106:
																																		goto IL_072c;
																																	case 150:
																																		goto IL_073a;
																																	case 4:
																																	case 169:
																																		goto IL_0748;
																																	case 209:
																																		goto IL_07ad;
																																	case 45:
																																	case 192:
																																		goto IL_07b8;
																																	case 125:
																																		goto IL_07f8;
																																	case 124:
																																		goto IL_0811;
																																	case 140:
																																		goto IL_081f;
																																	case 10:
																																		goto IL_082d;
																																	case 168:
																																		goto IL_0838;
																																	case 160:
																																		goto IL_0846;
																																	case 36:
																																	case 89:
																																		goto IL_0854;
																																	case 47:
																																		goto IL_0882;
																																	case 84:
																																	case 107:
																																		goto IL_088d;
																																	case 8:
																																		goto IL_08cf;
																																	case 22:
																																		goto IL_08dd;
																																	case 215:
																																		goto IL_08f0;
																																	case 216:
																																		goto IL_0903;
																																	case 218:
																																		goto IL_0916;
																																	case 247:
																																		goto IL_0926;
																																	case 249:
																																		goto IL_0939;
																																	case 148:
																																		goto IL_094d;
																																	case 252:
																																		goto IL_0960;
																																	case 71:
																																		goto IL_096b;
																																	case 28:
																																		goto IL_0976;
																																	case 31:
																																		goto IL_0989;
																																	case 121:
																																		goto IL_0997;
																																	case 245:
																																		goto IL_09aa;
																																	case 5:
																																	case 138:
																																		goto IL_09b8;
																																	case 67:
																																		goto IL_09c6;
																																	case 7:
																																		goto IL_09df;
																																	case 82:
																																		goto IL_09fe;
																																	case 222:
																																		goto IL_0a0c;
																																	case 254:
																																		goto IL_0a28;
																																	case 0:
																																	case 165:
																																		goto IL_0a36;
																																	case 193:
																																		goto IL_0a4a;
																																	case 202:
																																		goto IL_0a89;
																																	case 197:
																																	case 256:
																																		goto IL_0a9c;
																																	case 2:
																																	case 259:
																																		goto IL_0b00;
																																	case 184:
																																		goto IL_0b19;
																																	case 207:
																																		goto IL_0b27;
																																	case 51:
																																		goto IL_0b35;
																																	case 262:
																																		goto IL_0b48;
																																	case 27:
																																		goto IL_0b56;
																																	case 219:
																																		goto IL_0b61;
																																	case 92:
																																		goto IL_0b6f;
																																	case 194:
																																	case 220:
																																		goto IL_0b7d;
																																	case 50:
																																		goto IL_0b96;
																																	case 133:
																																		goto IL_0ba4;
																																	case 132:
																																		goto IL_0bb2;
																																	case 114:
																																		goto IL_0bce;
																																	case 199:
																																		goto IL_0be7;
																																	case 265:
																																		goto IL_0bfa;
																																	case 87:
																																		goto IL_0c08;
																																	case 267:
																																		goto IL_0c1b;
																																	case 248:
																																		goto IL_0c29;
																																	case 129:
																																	case 196:
																																		goto IL_0c37;
																																	case 268:
																																		goto IL_0c4f;
																																	case 154:
																																		goto IL_0c5d;
																																	case 208:
																																		goto IL_0c68;
																																	case 85:
																																	case 179:
																																		goto IL_0c76;
																																	case 203:
																																		goto IL_0c92;
																																	case 119:
																																		goto IL_0ca0;
																																	case 177:
																																	case 272:
																																		goto IL_0cb3;
																																	case 151:
																																		goto IL_0cf4;
																																	case 19:
																																		goto IL_0d08;
																																	case 277:
																																		goto IL_0d24;
																																	case 180:
																																		goto IL_0d32;
																																	case 280:
																																		goto IL_0d45;
																																	case 123:
																																		goto IL_0d53;
																																	case 282:
																																		goto IL_0d66;
																																	case 96:
																																	case 136:
																																		goto IL_0d74;
																																	case 97:
																																		goto IL_0d88;
																																	case 30:
																																		goto IL_0df2;
																																	case 174:
																																		goto IL_0e05;
																																	case 153:
																																		goto IL_0e13;
																																	case 77:
																																	case 205:
																																		goto IL_0e21;
																																	case 143:
																																		goto IL_0ec2;
																																	case 274:
																																		goto IL_0ed0;
																																	case 238:
																																	case 283:
																																		goto IL_0ee3;
																																	case 162:
																																		goto IL_0efb;
																																	case 110:
																																		goto IL_0f09;
																																	case 284:
																																		goto IL_0f1c;
																																	case 59:
																																	case 287:
																																		goto IL_0f2f;
																																	case 38:
																																		goto IL_0f6f;
																																	case 66:
																																		goto IL_0f83;
																																	case 288:
																																		goto IL_0f96;
																																	case 16:
																																		goto IL_0fa4;
																																	case 112:
																																	case 185:
																																		goto IL_0fb2;
																																	case 111:
																																		goto IL_1004;
																																	case 289:
																																		goto IL_1017;
																																	case 191:
																																		goto IL_1025;
																																	case 127:
																																		goto IL_1030;
																																	case 24:
																																	case 176:
																																		goto IL_103e;
																																	case 227:
																																		goto IL_107e;
																																	case 79:
																																		goto IL_1092;
																																	case 57:
																																		goto IL_10ae;
																																	case 103:
																																		goto IL_10bc;
																																	case 17:
																																	case 251:
																																		goto IL_10ca;
																																	case 291:
																																		goto IL_10dd;
																																	case 258:
																																	case 295:
																																		goto IL_10f0;
																																	case 221:
																																		goto IL_1104;
																																	case 105:
																																		goto IL_114c;
																																	case 250:
																																	case 299:
																																		goto IL_115f;
																																	case 11:
																																		goto IL_116d;
																																	case 266:
																																		goto IL_1199;
																																	case 226:
																																		goto IL_11a3;
																																	case 145:
																																		goto IL_11b1;
																																	case 303:
																																		goto IL_11c4;
																																	case 91:
																																	case 99:
																																		goto IL_11cf;
																																	case 293:
																																		goto IL_120f;
																																	case 104:
																																		goto IL_1223;
																																	case 34:
																																		goto IL_1236;
																																	case 159:
																																		goto IL_1244;
																																	case 214:
																																	case 231:
																																		goto IL_125b;
																																	case 48:
																																		goto IL_129b;
																																	case 52:
																																		goto IL_12af;
																																	case 304:
																																		goto IL_12cb;
																																	case 139:
																																	case 242:
																																		goto IL_12d9;
																																	case 175:
																																		goto IL_133b;
																																	case 308:
																																		goto IL_134e;
																																	case 294:
																																		goto IL_1361;
																																	case 41:
																																		goto IL_136f;
																																	case 83:
																																	case 278:
																																		goto IL_137a;
																																	case 116:
																																		goto IL_1388;
																																	case 42:
																																		goto IL_13ab;
																																	case 246:
																																		goto IL_13b9;
																																	case 120:
																																		goto IL_13cc;
																																	case 230:
																																		goto IL_13da;
																																	case 94:
																																	case 198:
																																		goto IL_13e5;
																																	case 98:
																																		goto IL_1425;
																																	case 235:
																																		goto IL_1439;
																																	case 301:
																																		goto IL_144c;
																																	case 3:
																																		goto IL_145a;
																																	case 6:
																																	case 172:
																																		goto IL_1471;
																																	case 200:
																																		goto IL_1485;
																																	case 21:
																																		goto IL_14c4;
																																	case 181:
																																		goto IL_14e0;
																																	case 228:
																																		goto IL_14ee;
																																	case 74:
																																	case 261:
																																		goto IL_14fc;
																																	case 44:
																																		goto IL_1510;
																																	case 229:
																																		goto IL_1558;
																																	case 166:
																																		goto IL_156b;
																																	case 100:
																																		goto IL_1579;
																																	case 32:
																																		goto IL_1587;
																																	case 93:
																																		goto IL_1595;
																																	case 61:
																																	case 163:
																																		goto IL_15a3;
																																	case 88:
																																		goto IL_1602;
																																	case 63:
																																	case 72:
																																		goto IL_1615;
																																	case 26:
																																		goto IL_1649;
																																	case 9:
																																		goto IL_1662;
																																	case 290:
																																		goto IL_166d;
																																	case 109:
																																	case 260:
																																		goto IL_167b;
																																	case 68:
																																		goto IL_1693;
																																	case 20:
																																		goto IL_16a1;
																																	case 257:
																																		goto IL_16af;
																																	case 35:
																																		goto IL_16c2;
																																	case 188:
																																		goto IL_16cd;
																																	case 62:
																																	case 130:
																																		goto IL_16d8;
																																	case 311:
																																		goto IL_1737;
																																	case 13:
																																	case 14:
																																	case 15:
																																	case 49:
																																	case 55:
																																	case 73:
																																	case 78:
																																	case 90:
																																	case 95:
																																	case 113:
																																	case 115:
																																	case 118:
																																	case 122:
																																	case 141:
																																	case 142:
																																	case 146:
																																	case 147:
																																	case 152:
																																	case 155:
																																	case 161:
																																	case 167:
																																	case 170:
																																	case 182:
																																	case 206:
																																	case 232:
																																	case 234:
																																	case 236:
																																	case 237:
																																	case 239:
																																	case 240:
																																	case 255:
																																	case 264:
																																	case 271:
																																	case 273:
																																	case 279:
																																	case 281:
																																	case 286:
																																	case 292:
																																	case 306:
																																	case 309:
																																		goto end_IL_05cf;
																																	case 18:
																																	case 25:
																																	case 37:
																																	case 58:
																																	case 65:
																																	case 69:
																																	case 70:
																																	case 80:
																																	case 81:
																																	case 86:
																																	case 102:
																																	case 117:
																																	case 131:
																																	case 135:
																																	case 137:
																																	case 156:
																																	case 157:
																																	case 158:
																																	case 164:
																																	case 171:
																																	case 189:
																																	case 201:
																																	case 204:
																																	case 210:
																																	case 211:
																																	case 212:
																																	case 224:
																																	case 225:
																																	case 241:
																																	case 243:
																																	case 244:
																																	case 269:
																																	case 276:
																																	case 285:
																																	case 296:
																																	case 297:
																																	case 300:
																																	case 302:
																																	case 307:
																																		goto end_IL_0515;
																																	case 217:
																																		goto end_IL_175a;
																																	case 186:
																																		goto end_IL_176d;
																																	case 183:
																																		goto end_IL_1777;
																																	case 29:
																																		goto end_IL_1782;
																																	case 53:
																																		goto end_IL_1798;
																																	case 128:
																																		goto end_IL_17a8;
																																	case 223:
																																		goto end_IL_17b8;
																																	case 263:
																																		goto end_IL_17c8;
																																	case 101:
																																		goto end_IL_17d8;
																																	case 298:
																																		goto end_IL_17e8;
																																	case 310:
																																		goto end_IL_17f8;
																																	case 305:
																																		goto end_IL_1808;
																																	case 75:
																																		goto end_IL_1818;
																																	case 76:
																																		goto end_IL_1828;
																																	case 12:
																																	case 60:
																																		goto IL_1843;
																																	}
																																	continue;
																																	end_IL_0515:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_1361;
																												IL_16d8:
																												((delegate*<object, IntPtr, object[], int[], ref _003CForceCreateRoom_003Ed__3>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).string_0 = (string)array2[num6 - 1];
																												goto IL_1737;
																												IL_1361:
																												if (23 >= b)
																												{
																													goto IL_136f;
																												}
																												goto IL_156b;
																												IL_136f:
																												if (23 <= b)
																												{
																													goto IL_137a;
																												}
																												goto IL_13cc;
																												IL_137a:
																												array[num6] = 4;
																												goto IL_1388;
																												IL_1388:
																												array2[num6] = ((delegate*<AsyncTaskMethodBuilder>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])();
																												goto IL_13ab;
																												IL_13ab:
																												num6++;
																												goto IL_13b9;
																												IL_13b9:
																												ptr2 += 8;
																												break;
																												IL_13cc:
																												if (21 >= b)
																												{
																													goto IL_13da;
																												}
																												goto IL_14e0;
																												IL_13da:
																												if (21 <= b)
																												{
																													goto IL_13e5;
																												}
																												goto IL_144c;
																												IL_13e5:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												goto IL_1425;
																												IL_1425:
																												array[num6 - 2] = 3;
																												goto IL_1439;
																												IL_1439:
																												num6--;
																												break;
																												IL_144c:
																												if (20 < b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_145a;
																												IL_145a:
																												if (20 > b)
																												{
																													goto end_IL_05cf;
																												}
																												num = 172;
																												goto IL_1471;
																												IL_1737:
																												num6 -= 2;
																												break;
																												IL_1471:
																												array[num6 - 1] = 3;
																												goto IL_1485;
																												IL_1485:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																												goto IL_14c4;
																												IL_14c4:
																												ptr2 += 8;
																												num = 269;
																												break;
																												IL_14e0:
																												if (22 < b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_14ee;
																												IL_14ee:
																												if (22 > b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_14fc;
																												IL_14fc:
																												array[num6 - 1] = 0;
																												goto IL_1510;
																												IL_1510:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																												num = 229;
																												goto IL_1558;
																												IL_1558:
																												ptr2 += 8;
																												break;
																												IL_156b:
																												if (25 >= b)
																												{
																													goto IL_1579;
																												}
																												goto IL_1662;
																												IL_1579:
																												if (25 > b)
																												{
																													goto IL_1587;
																												}
																												goto IL_1615;
																												IL_1587:
																												if (24 < b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_1595;
																												IL_1595:
																												if (24 > b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_15a3;
																												IL_15a3:
																												((delegate*<object, IntPtr, object[], int[], ref _003CForceCreateRoom_003Ed__3>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).asyncTaskMethodBuilder_0 = (AsyncTaskMethodBuilder)array2[num6 - 1];
																												goto IL_1602;
																												IL_1602:
																												num6 -= 2;
																												break;
																												IL_1615:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																												num = 26;
																												goto IL_1649;
																												IL_1649:
																												array[num6 - 1] = 0;
																												break;
																												IL_1662:
																												if (26 >= b)
																												{
																													goto IL_166d;
																												}
																												goto IL_16c2;
																												IL_166d:
																												if (26 > b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_167b;
																												IL_167b:
																												array2[num6] = array6[*(int*)(ptr2 + num3)];
																												goto IL_1693;
																												IL_1693:
																												array[num6] = 5;
																												goto IL_16a1;
																												IL_16a1:
																												num6++;
																												goto IL_16af;
																												IL_16af:
																												ptr2 += 8;
																												break;
																												IL_16c2:
																												if (27 < b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_16cd;
																												IL_16cd:
																												if (27 > b)
																												{
																													goto end_IL_05cf;
																												}
																												goto IL_16d8;
																											}
																											break;
																										}
																										goto IL_060a;
																										IL_0e13:
																										if (34 > b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0e21;
																										IL_0e21:
																										((delegate*<ref AsyncTaskMethodBuilder, ref _003CForceCreateRoom_003Ed__3, void>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref AsyncTaskMethodBuilder>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4), ref ((delegate*<object, IntPtr, object[], int[], ref _003CForceCreateRoom_003Ed__3>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																										goto IL_0ec2;
																										IL_060a:
																										if (33 >= b)
																										{
																											num = 195;
																											goto IL_0676;
																										}
																										goto IL_0c4f;
																										IL_0ec2:
																										num6 -= 2;
																										goto IL_0ed0;
																										IL_0676:
																										if (33 <= b)
																										{
																											goto IL_0684;
																										}
																										goto IL_0705;
																										IL_0684:
																										array2[num6 - 1] = new IUnknownConstantAttributeRemoveOn(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array3[num6 - 1], array4);
																										goto IL_06d3;
																										IL_06d3:
																										array[num6 - 1] = 15;
																										goto IL_06e7;
																										IL_06e7:
																										array3[num6 - 1] = *(int*)(ptr2 + num3);
																										goto IL_0f1c;
																										IL_0f1c:
																										ptr2 += 8;
																										break;
																										IL_0705:
																										if (30 >= b)
																										{
																											goto IL_0710;
																										}
																										goto IL_072c;
																										IL_0710:
																										if (30 > b)
																										{
																											goto IL_0d45;
																										}
																										num = 295;
																										goto IL_10f0;
																										IL_0ed0:
																										ptr2 += 8;
																										break;
																										IL_10f0:
																										array[num6 - 1] = 0;
																										goto IL_1104;
																										IL_1104:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										num = 105;
																										goto IL_114c;
																										IL_114c:
																										ptr2 += 8;
																										break;
																										IL_0d45:
																										if (29 < b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0d53;
																										IL_0d53:
																										if (29 > b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0f2f;
																										IL_0f2f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_0f6f;
																										IL_0f6f:
																										array[num6 - 2] = 3;
																										goto IL_0f83;
																										IL_0f83:
																										num6--;
																										break;
																										IL_072c:
																										if (31 >= b)
																										{
																											goto IL_073a;
																										}
																										goto IL_0926;
																										IL_073a:
																										if (31 > b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0748;
																										IL_0748:
																										((delegate*<object, IntPtr, object[], int[], ref _003CForceCreateRoom_003Ed__3>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_0903;
																										IL_0903:
																										num6 -= 2;
																										break;
																										IL_0926:
																										if (32 < b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0a28;
																										IL_0a28:
																										if (32 > b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0a36;
																										IL_0a36:
																										array[num6 - 1] = 3;
																										goto IL_0a4a;
																										IL_0a4a:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																										goto IL_0a89;
																										IL_0a89:
																										ptr2 += 8;
																										break;
																										IL_0c4f:
																										if (35 < b)
																										{
																											goto IL_0c5d;
																										}
																										goto IL_0d66;
																										IL_0c5d:
																										if (36 >= b)
																										{
																											goto IL_0c68;
																										}
																										goto IL_0c92;
																										IL_0c68:
																										if (36 > b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0c76;
																										IL_0c76:
																										byte* num7 = ptr2;
																										num5 = 1;
																										ptr2 = num7 + -200;
																										break;
																										IL_0c92:
																										if (37 < b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0ca0;
																										IL_0ca0:
																										if (37 > b)
																										{
																										}
																										goto end_IL_05cf;
																										IL_0d66:
																										if (35 <= b)
																										{
																											goto IL_0d74;
																										}
																										goto IL_0e05;
																										IL_0d74:
																										array[num6 - 1] = 5;
																										goto IL_0d88;
																										IL_0d88:
																										array2[num6 - 1] = ((delegate*<ref AsyncTaskMethodBuilder, Task>)ArgRegKeyDelHiveStackCrawlMarkHandle[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref AsyncTaskMethodBuilder>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																										goto IL_0df2;
																										IL_0df2:
																										ptr2 += 8;
																										break;
																										IL_0e05:
																										if (34 < b)
																										{
																											goto end_IL_05cf;
																										}
																										goto IL_0e13;
																									}
																									break;
																								}
																								goto IL_0623;
																								IL_0641:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																								num = 33;
																								goto IL_0663;
																								IL_0623:
																								if (19 > b)
																								{
																									goto IL_062e;
																								}
																								goto IL_0641;
																								IL_062e:
																								if (9 >= b)
																								{
																									goto IL_07ad;
																								}
																								goto IL_0916;
																								IL_07ad:
																								if (9 <= b)
																								{
																									goto IL_07b8;
																								}
																								goto IL_0811;
																								IL_07b8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_07f8;
																								IL_07f8:
																								array[num6 - 2] = 0;
																								goto IL_08f0;
																								IL_08f0:
																								num6--;
																								break;
																								IL_0811:
																								if (4 >= b)
																								{
																									goto IL_081f;
																								}
																								goto IL_1017;
																								IL_081f:
																								if (4 > b)
																								{
																									goto IL_082d;
																								}
																								goto IL_115f;
																								IL_082d:
																								if (2 < b)
																								{
																									goto IL_0838;
																								}
																								goto IL_0882;
																								IL_0838:
																								if (3 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0846;
																								IL_0846:
																								if (3 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0854;
																								IL_0854:
																								ref int reference = ref array4[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_0bfa;
																								IL_0bfa:
																								ptr2 += 8;
																								goto IL_0c08;
																								IL_0c08:
																								num6--;
																								break;
																								IL_0882:
																								if (2 <= b)
																								{
																									goto IL_088d;
																								}
																								goto IL_08cf;
																								IL_088d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_0939;
																								IL_0939:
																								array[num6 - 2] = 0;
																								goto IL_094d;
																								IL_094d:
																								num6--;
																								break;
																								IL_08cf:
																								if (1 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_08dd;
																								IL_08dd:
																								if (1 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0b00;
																								IL_0b00:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0b19;
																								IL_0b19:
																								array[num6] = 0;
																								goto IL_0b27;
																								IL_0b27:
																								num6++;
																								goto IL_0b35;
																								IL_0b35:
																								ptr2 += 8;
																								break;
																								IL_115f:
																								array[num6] = 0;
																								goto IL_116d;
																								IL_116d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																								num = 266;
																								goto IL_1199;
																								IL_1199:
																								array2[num6] = null;
																								goto IL_11a3;
																								IL_11a3:
																								num6++;
																								goto IL_11b1;
																								IL_11b1:
																								ptr2 += 8;
																								break;
																								IL_1017:
																								if (6 < b)
																								{
																									goto IL_1025;
																								}
																								goto IL_11c4;
																								IL_1025:
																								if (7 >= b)
																								{
																									goto IL_1030;
																								}
																								goto IL_10ae;
																								IL_1030:
																								if (7 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_103e;
																								IL_103e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_107e;
																								IL_107e:
																								array[num6 - 2] = 0;
																								goto IL_1092;
																								IL_1092:
																								num6--;
																								num = 241;
																								break;
																								IL_10ae:
																								if (8 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_10bc;
																								IL_10bc:
																								if (8 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_10ca;
																								IL_10ca:
																								num6--;
																								break;
																								IL_11c4:
																								if (6 <= b)
																								{
																									goto IL_11cf;
																								}
																								goto IL_1236;
																								IL_11cf:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_120f;
																								IL_120f:
																								array[num6 - 2] = 0;
																								goto IL_1223;
																								IL_1223:
																								num6--;
																								break;
																								IL_1236:
																								if (5 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_1244;
																								IL_1244:
																								if (5 > b)
																								{
																									goto end_IL_05cf;
																								}
																								num = 231;
																								goto IL_125b;
																								IL_0663:
																								array[num6] = 3;
																								goto IL_0d24;
																								IL_125b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_129b;
																								IL_129b:
																								array[num6 - 2] = 0;
																								goto IL_12af;
																								IL_12af:
																								num6--;
																								num = 117;
																								break;
																								IL_0916:
																								if (14 < b)
																								{
																									goto IL_0960;
																								}
																								goto IL_0b48;
																								IL_0960:
																								if (16 < b)
																								{
																									goto IL_096b;
																								}
																								goto IL_09aa;
																								IL_096b:
																								if (17 >= b)
																								{
																									goto IL_0976;
																								}
																								goto IL_0989;
																								IL_0976:
																								if (17 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0ee3;
																								IL_0ee3:
																								array2[num6] = array6[*(int*)(ptr2 + num3)];
																								goto IL_0efb;
																								IL_0efb:
																								array[num6] = 5;
																								goto IL_0f09;
																								IL_0f09:
																								num6++;
																								goto IL_10dd;
																								IL_10dd:
																								ptr2 += 8;
																								break;
																								IL_0989:
																								if (18 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0997;
																								IL_0997:
																								if (18 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0a9c;
																								IL_0a9c:
																								((delegate*<object, IntPtr, object[], int[], ref _003CForceCreateRoom_003Ed__3>)ArgRegKeyDelHiveStackCrawlMarkHandle[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).roomConfig_0 = (RoomConfig)array2[num6 - 1];
																								goto IL_134e;
																								IL_134e:
																								num6 -= 2;
																								break;
																								IL_09aa:
																								if (16 <= b)
																								{
																									goto IL_09b8;
																								}
																								goto IL_0f96;
																								IL_09b8:
																								array[num6] = 13;
																								goto IL_09c6;
																								IL_09c6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																								goto IL_09df;
																								IL_09df:
																								array3[num6 - 0] = *(int*)(ptr2 + 8 + num3);
																								goto IL_09fe;
																								IL_09fe:
																								num6++;
																								goto IL_0a0c;
																								IL_0a0c:
																								ptr2 += 16;
																								num = 244;
																								break;
																								IL_0f96:
																								if (15 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0fa4;
																								IL_0fa4:
																								if (15 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0fb2;
																								IL_0fb2:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_1004;
																								IL_1004:
																								num6--;
																								break;
																								IL_0b48:
																								if (14 > b)
																								{
																									goto IL_0b56;
																								}
																								goto IL_0cb3;
																								IL_0b56:
																								if (11 < b)
																								{
																									goto IL_0b61;
																								}
																								num = 114;
																								goto IL_0bce;
																								IL_0b61:
																								if (12 >= b)
																								{
																									goto IL_0b6f;
																								}
																								goto IL_0c1b;
																								IL_0b6f:
																								if (12 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0b7d;
																								IL_0b7d:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0b96;
																								IL_0b96:
																								array[num6] = 1;
																								goto IL_0ba4;
																								IL_0ba4:
																								num6++;
																								goto IL_0bb2;
																								IL_0bb2:
																								ptr2 += 16;
																								break;
																								IL_0c1b:
																								if (13 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0c29;
																								IL_0c29:
																								if (13 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_0c37;
																								IL_0c37:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0d24:
																								num6++;
																								goto IL_0d32;
																								IL_0bce:
																								if (11 <= b)
																								{
																									num = 297;
																									break;
																								}
																								goto IL_0be7;
																								IL_0d32:
																								ptr2 += 16;
																								break;
																								IL_0be7:
																								if (10 < b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_12cb;
																								IL_12cb:
																								if (10 > b)
																								{
																									goto end_IL_05cf;
																								}
																								goto IL_12d9;
																								IL_12d9:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_133b;
																								IL_133b:
																								num6 -= 2;
																								break;
																								IL_0cb3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																								goto IL_0cf4;
																								IL_0cf4:
																								array[num6 - 2] = 0;
																								goto IL_0d08;
																								IL_0d08:
																								num6--;
																								num = 137;
																								break;
																							}
																							goto end_IL_05df;
																							continue;
																							end_IL_05cf:
																							break;
																							IL_05cf:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					continue;
																					end_IL_05df:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_1843;
																	IL_1843:
																	return (Task)array2[num6 - 1];
																	continue;
																	end_IL_175a:
																	break;
																}
																continue;
																end_IL_176d:
																break;
															}
															continue;
															end_IL_1777:
															break;
														}
														continue;
														end_IL_1782:
														break;
													}
													continue;
													end_IL_1798:
													break;
												}
												continue;
												end_IL_17a8:
												break;
											}
											continue;
											end_IL_17b8:
											break;
										}
										continue;
										end_IL_17c8:
										break;
									}
									continue;
									end_IL_17d8:
									break;
								}
								continue;
								end_IL_17e8:
								break;
							}
							continue;
							end_IL_17f8:
							break;
						}
						continue;
						end_IL_1808:
						break;
					}
					continue;
					end_IL_1818:
					break;
				}
				continue;
				end_IL_1828:
				break;
			}
		}
	}

	private static int PtrToStringAutoReadSByte()
	{
		return smethod_6();
	}

	private static Transform ArrayEnumeratorgetTrademark(GameObject gameObject_0)
	{
		return gameObject_0.transform;
	}

	private static GTZone CrossAppDomainSinkSecurity(GorillaNetworkJoinTrigger gorillaNetworkJoinTrigger_0)
	{
		return gorillaNetworkJoinTrigger_0.zone;
	}

	private static bool getUnicodeEncodedIExpando(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private unsafe static string smethod_2()
	{
		int num = 7;
		string result = default(string);
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		string text27 = default(string);
		string text28 = default(string);
		string text29 = default(string);
		string text30 = default(string);
		string text31 = default(string);
		string text32 = default(string);
		string text33 = default(string);
		string text34 = default(string);
		string text35 = default(string);
		int num11 = default(int);
		string text36 = default(string);
		int num12 = default(int);
		while (true)
		{
			int num2 = 17;
			while (true)
			{
				int num3 = 17;
				while (true)
				{
					IL_0051:
					num3 = 17;
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 1:
								goto IL_0051;
							case 6:
								goto end_IL_0041;
							case 7:
								goto end_IL_0060;
							case 5:
								goto IL_006c;
							case 4:
								goto IL_00db;
							case 3:
								goto IL_00e0;
							case 0:
							case 2:
								goto IL_00ed;
							}
							continue;
						}
						goto IL_00db;
						IL_00ed:
						return result;
						IL_006c:
						result = ((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, ref string, ref int, string>)SymAddressKindEventCommand[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, ref text27, ref text28, ref text29, ref text30, ref text31, ref text32, ref text33, ref text34, ref text35, ref num11, ref text36, ref num12);
						goto IL_00db;
						IL_00db:
						if (num3 != 0)
						{
							goto IL_006c;
						}
						goto IL_00e0;
						IL_00e0:
						num3 = 17;
						num = 2;
						goto IL_00ed;
						continue;
						end_IL_0041:
						break;
					}
					break;
				}
				continue;
				end_IL_0060:
				break;
			}
		}
	}

	private static string AllowExponentIHashElementEntry(string string_0, string string_1)
	{
		return string_0 + string_1;
	}

	private static string HelpInternalSink(string string_0)
	{
		return string_0.Trim();
	}

	private static GameModeType FORMATFLAGSCreateType(string string_0, bool bool_2)
	{
		return (GameModeType)Enum.Parse(typeof(GameModeType), string_0, bool_2);
	}

	private static GorillaNetworkJoinTrigger getWrappedObjectgetKeyData(GorillaComputer gorillaComputer_0, string string_0)
	{
		return gorillaComputer_0.GetJoinTriggerForZone(string_0);
	}

	private unsafe static int smethod_3()
	{
		int num = 122;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RequiresSetDynamicBase.TrimStartgetInherited);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_030c:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02ec:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02dc:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02cc:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02bf:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_029f:
																											array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																											while (true)
																											{
																												IL_0286:
																												ptr2 += 8;
																												num = 153;
																												while (true)
																												{
																													if (num != 153)
																													{
																														if (num != 1134)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 5:
																															goto IL_0286;
																														case 65:
																														case 146:
																															goto IL_029f;
																														case 117:
																															goto IL_02bf;
																														case 26:
																														case 99:
																															goto IL_02cc;
																														case 28:
																															goto IL_02dc;
																														case 59:
																															goto IL_02ec;
																														case 113:
																															goto IL_02fc;
																														case 43:
																															goto IL_030c;
																														case 58:
																															goto end_IL_030c;
																														case 55:
																														case 104:
																															goto end_IL_031c;
																														case 19:
																														case 25:
																															goto IL_0337;
																														case 82:
																															goto IL_0345;
																														case 69:
																															goto IL_0353;
																														case 70:
																															goto IL_036a;
																														case 34:
																														case 35:
																															goto IL_0378;
																														case 83:
																															goto IL_0391;
																														case 23:
																															goto IL_03a8;
																														case 63:
																														case 87:
																															goto IL_03bb;
																														case 48:
																															goto IL_03c9;
																														case 36:
																														case 54:
																															goto IL_03d4;
																														case 0:
																															goto IL_0413;
																														case 85:
																															goto IL_042f;
																														case 91:
																															goto IL_0448;
																														case 78:
																															goto IL_0456;
																														case 97:
																															goto IL_0469;
																														case 44:
																														case 77:
																															goto IL_0477;
																														case 64:
																															goto IL_0485;
																														case 32:
																														case 102:
																															goto IL_04a2;
																														case 22:
																															goto IL_04b0;
																														case 12:
																															goto IL_04bb;
																														case 37:
																															goto IL_04c9;
																														case 47:
																															goto IL_04d7;
																														case 2:
																														case 111:
																															goto IL_04ea;
																														case 112:
																															goto IL_052c;
																														case 79:
																															goto IL_053a;
																														case 60:
																														case 116:
																															goto IL_054d;
																														case 21:
																															goto IL_055b;
																														case 56:
																														case 68:
																															goto IL_0569;
																														case 38:
																															goto IL_0592;
																														case 118:
																															goto IL_05a2;
																														case 1:
																															goto IL_05b6;
																														case 119:
																															goto IL_05c9;
																														case 18:
																														case 125:
																															goto IL_05dc;
																														case 39:
																															goto IL_0625;
																														case 50:
																														case 130:
																															goto IL_063e;
																														case 27:
																															goto IL_0682;
																														case 67:
																															goto IL_0696;
																														case 137:
																															goto IL_06a9;
																														case 13:
																														case 128:
																															goto IL_06b4;
																														case 129:
																															goto IL_06c2;
																														case 6:
																														case 105:
																															goto IL_06d5;
																														case 135:
																															goto IL_06e3;
																														case 24:
																															goto IL_0706;
																														case 92:
																															goto IL_0710;
																														case 52:
																															goto IL_071e;
																														case 61:
																														case 138:
																															goto IL_0731;
																														case 66:
																															goto IL_075a;
																														case 139:
																															goto IL_0773;
																														case 143:
																															goto IL_0786;
																														case 134:
																														case 145:
																															goto IL_07a2;
																														case 71:
																															goto IL_07b0;
																														case 98:
																														case 106:
																															goto IL_07be;
																														case 140:
																															goto IL_07cc;
																														case 96:
																														case 132:
																															goto IL_07da;
																														case 144:
																															goto IL_0845;
																														case 75:
																														case 86:
																															goto IL_0855;
																														case 7:
																															goto IL_086e;
																														case 109:
																															goto IL_0879;
																														case 49:
																														case 89:
																															goto IL_0896;
																														case 8:
																														case 10:
																														case 11:
																														case 14:
																														case 16:
																														case 30:
																														case 40:
																														case 42:
																														case 45:
																														case 62:
																														case 72:
																														case 74:
																														case 76:
																														case 80:
																														case 81:
																														case 84:
																														case 88:
																														case 94:
																														case 100:
																														case 127:
																														case 131:
																														case 133:
																														case 136:
																														case 141:
																														case 142:
																															goto end_IL_0273;
																														case 9:
																														case 15:
																														case 33:
																														case 41:
																														case 46:
																														case 53:
																														case 57:
																														case 73:
																														case 90:
																														case 93:
																														case 95:
																														case 107:
																														case 110:
																														case 114:
																														case 115:
																														case 120:
																														case 124:
																														case 126:
																															goto end_IL_032c;
																														case 31:
																															goto end_IL_08be;
																														case 51:
																															goto end_IL_08d1;
																														case 108:
																															goto end_IL_08db;
																														case 29:
																															goto end_IL_08e6;
																														case 17:
																														case 123:
																															goto end_IL_08f6;
																														case 20:
																															goto end_IL_0906;
																														case 101:
																														case 103:
																															goto end_IL_0916;
																														case 121:
																															goto end_IL_0926;
																														case 122:
																															goto end_IL_0936;
																														case 3:
																														case 4:
																															goto IL_0951;
																														}
																														continue;
																													}
																													num5--;
																													goto end_IL_032c;
																													continue;
																													end_IL_0273:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0337;
																									IL_0731:
																									array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_075a;
																									IL_0337:
																									if (2 >= b)
																									{
																										goto IL_0345;
																									}
																									goto IL_0448;
																									IL_0345:
																									if (2 > b)
																									{
																										goto IL_0353;
																									}
																									goto IL_05dc;
																									IL_0353:
																									if (1 < b)
																									{
																										break;
																									}
																									num = 70;
																									goto IL_036a;
																									IL_075a:
																									array[num5 - 1] = 5;
																									goto end_IL_032c;
																									IL_036a:
																									if (1 > b)
																									{
																										break;
																									}
																									goto IL_0378;
																									IL_0378:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_0391;
																									IL_0391:
																									array[num5] = 0;
																									num = 23;
																									goto IL_03a8;
																									IL_03a8:
																									num5++;
																									goto IL_0786;
																									IL_0786:
																									ptr2 += 8;
																									num = 107;
																									goto end_IL_032c;
																									IL_05dc:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 39;
																									goto IL_0625;
																									IL_0625:
																									array[num5 - 2] = 0;
																									goto IL_0773;
																									IL_0773:
																									num5--;
																									goto end_IL_032c;
																									IL_0448:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_0456;
																									IL_0456:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0731;
																								}
																								break;
																							}
																							goto IL_03bb;
																							IL_0592:
																							ptr2 += 8;
																							goto IL_05c9;
																							IL_03bb:
																							if (6 >= b)
																							{
																								goto IL_03c9;
																							}
																							goto IL_054d;
																							IL_03c9:
																							if (6 <= b)
																							{
																								goto IL_03d4;
																							}
																							goto IL_042f;
																							IL_03d4:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0413;
																							IL_0413:
																							num5 -= 3;
																							num = 95;
																							goto end_IL_032c;
																							IL_042f:
																							if (5 < b)
																							{
																								break;
																							}
																							num = 97;
																							goto IL_0469;
																							IL_05c9:
																							num5--;
																							goto end_IL_032c;
																							IL_0469:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0477;
																							IL_0477:
																							array[num5] = 5;
																							goto IL_0485;
																							IL_0485:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_052c;
																							IL_052c:
																							num5++;
																							goto IL_053a;
																							IL_053a:
																							ptr2 += 8;
																							goto end_IL_032c;
																							IL_054d:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_055b;
																							IL_055b:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0569;
																							IL_0569:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0592;
																						}
																						break;
																					}
																					goto IL_0896;
																					IL_0896:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_032c;
																				}
																				break;
																			}
																			goto IL_04a2;
																			IL_0879:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_04a2:
																			if (12 >= b)
																			{
																				goto IL_04b0;
																			}
																			goto IL_07a2;
																			IL_04b0:
																			if (12 > b)
																			{
																				goto IL_04bb;
																			}
																			goto IL_04ea;
																			IL_04bb:
																			if (10 < b)
																			{
																				goto IL_04c9;
																			}
																			goto IL_06a9;
																			IL_04c9:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04d7;
																			IL_04d7:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_063e;
																			IL_063e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0682;
																			IL_0682:
																			array[num5 - 2] = 0;
																			goto IL_0696;
																			IL_0696:
																			num5--;
																			goto end_IL_032c;
																			IL_06a9:
																			if (10 > b)
																			{
																				goto IL_06b4;
																			}
																			goto IL_06d5;
																			IL_06b4:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_06c2;
																			IL_06c2:
																			if (9 <= b)
																			{
																				goto end_IL_032c;
																			}
																			break;
																			IL_06d5:
																			array[num5] = 0;
																			goto IL_06e3;
																			IL_06e3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0706;
																			IL_0706:
																			array2[num5] = null;
																			goto IL_0710;
																			IL_0710:
																			num5++;
																			goto IL_071e;
																			IL_071e:
																			ptr2 += 8;
																			goto end_IL_032c;
																			IL_04ea:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05a2;
																			IL_05a2:
																			array[num5 - 2] = 0;
																			goto IL_05b6;
																			IL_05b6:
																			num5--;
																			goto end_IL_032c;
																			IL_07a2:
																			if (14 >= b)
																			{
																				goto IL_07b0;
																			}
																			goto IL_086e;
																			IL_07b0:
																			if (14 > b)
																			{
																				goto IL_07be;
																			}
																			goto IL_0855;
																			IL_07be:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_07cc;
																			IL_07cc:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_07da;
																			IL_07da:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 144;
																			goto IL_0845;
																			IL_0845:
																			num5 -= 2;
																			goto end_IL_032c;
																			IL_0855:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_032c;
																			IL_086e:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0879;
																		}
																		break;
																		IL_02fc:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_032c;
																continue;
																end_IL_030c:
																break;
															}
															continue;
															end_IL_031c:
															break;
														}
														continue;
														end_IL_032c:
														break;
													}
													continue;
												}
												goto IL_0951;
												IL_0951:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08be:
												break;
											}
											continue;
											end_IL_08d1:
											break;
										}
										continue;
										end_IL_08db:
										break;
									}
									continue;
									end_IL_08e6:
									break;
								}
								continue;
								end_IL_08f6:
								break;
							}
							continue;
							end_IL_0906:
							break;
						}
						continue;
						end_IL_0916:
						break;
					}
					continue;
					end_IL_0926:
					break;
				}
				continue;
				end_IL_0936:
				break;
			}
		}
	}

	private static int ConstructorArgumentsChannelServicesData(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static byte StackCrawlMarkHandleCallback(GTZone gtzone_0, GameModeType gameModeType_0, bool bool_2, bool bool_3)
	{
		return global::RoomSystem.GetRoomSizeForCreate(gtzone_0, gameModeType_0, bool_2, bool_3);
	}

	private static string CodeGroupPositionMarkercbSizeInstance(object object_0)
	{
		return object_0.ToString();
	}

	private static double IetfLanguageTagCodePage(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static WatchableStringSO GetHashCodegetNext(GorillaComputer gorillaComputer_0)
	{
		return gorillaComputer_0.currentGameMode;
	}

	private static int getMinimumRequiredVersionExists(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool getPercentDecimalDigitsLdelemU()
	{
		return SubscriptionManager.IsLocalSubscribed();
	}

	private static GameObject DefineSafeArraygetLastAccessTime(string string_0)
	{
		return GameObject.Find(string_0);
	}

	private static string SiteMembershipConditiongetLocal(string string_0, int int_1, int int_2)
	{
		return string_0.Substring(int_1, int_2);
	}

	private static GorillaNetworkJoinTrigger getAsyncWaitHandleCrossAppDomainAssembly(PhotonNetworkController photonNetworkController_0)
	{
		return photonNetworkController_0.currentJoinTrigger;
	}

	private static string IsLetterOrDigitContinuationResultTaskFromResultTask(WatchableStringSO watchableStringSO_0)
	{
		return watchableStringSO_0.Value;
	}

	private static double LPWStrElementDecl(double double_1)
	{
		return Math.Cos(double_1);
	}

	private static void getSubKeyCountContractClassAttribute(NetworkSystemPUN networkSystemPUN_0, NetworkSystemPUN.InternalState internalState_0)
	{
		networkSystemPUN_0.internalState = internalState_0;
	}

	private static GorillaNetworkJoinTrigger UIPermissionWaitSleepJoin(GorillaComputer gorillaComputer_0, string string_0)
	{
		return gorillaComputer_0.GetJoinTriggerForZone(string_0);
	}

	private static string IAssemblyEnumsetDataPointer(GorillaNetworkJoinTrigger gorillaNetworkJoinTrigger_0)
	{
		return gorillaNetworkJoinTrigger_0.GetFullDesiredGameModeString();
	}

	private static Locale UCOMIPersistFileInitializeServerObject()
	{
		return LocalisationManager.CurrentLanguage;
	}

	private static double ReadOnlyCollectionBasegetClipboard(double double_1)
	{
		return Math.Floor(double_1);
	}

	private static RoomConfig SetMessageCtrlConfigurationBytesValue()
	{
		return new RoomConfig();
	}

	private unsafe void OnEnable()
	{
		int num = 100;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 17;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[6];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WebNameFixupData.getTwoLetterISORegionNamegetTotalFreeSpace);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															IL_03ae:
															byte b = *ptr2;
															while (true)
															{
																IL_039e:
																ptr2++;
																while (true)
																{
																	IL_038e:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_036e:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_035e:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0351:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_0341:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_0331:
																												if (6 > b)
																												{
																													while (5 >= b)
																													{
																														while (5 <= b)
																														{
																															while (true)
																															{
																																IL_02c6:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																num = 169;
																																while (true)
																																{
																																	if (num != 169)
																																	{
																																		if (num != 1150)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 22:
																																		case 39:
																																			goto IL_02c6;
																																		case 19:
																																			goto IL_0311;
																																		case 43:
																																		case 142:
																																			goto IL_0321;
																																		case 97:
																																			goto IL_0331;
																																		case 9:
																																		case 132:
																																			goto IL_0341;
																																		case 50:
																																		case 64:
																																			goto IL_0351;
																																		case 89:
																																			goto IL_035e;
																																		case 13:
																																			goto IL_036e;
																																		case 75:
																																			goto IL_037e;
																																		case 137:
																																			goto IL_038e;
																																		case 71:
																																			goto IL_039e;
																																		case 49:
																																		case 156:
																																			goto IL_03ae;
																																		case 44:
																																			goto IL_03b9;
																																		case 21:
																																		case 56:
																																			goto IL_03c7;
																																		case 74:
																																		case 91:
																																			goto IL_03d7;
																																		case 92:
																																			goto IL_03e5;
																																		case 96:
																																			goto IL_03f5;
																																		case 104:
																																		case 126:
																																			goto IL_0408;
																																		case 95:
																																			goto IL_0448;
																																		case 47:
																																			goto IL_045c;
																																		case 29:
																																		case 134:
																																			goto IL_046f;
																																		case 16:
																																			goto IL_047d;
																																		case 122:
																																		case 143:
																																			goto IL_04a5;
																																		case 139:
																																			goto IL_04e5;
																																		case 48:
																																			goto IL_04f9;
																																		case 149:
																																			goto IL_050c;
																																		case 41:
																																			goto IL_051a;
																																		case 5:
																																		case 90:
																																			goto IL_0528;
																																		case 107:
																																			goto IL_0551;
																																		case 62:
																																			goto IL_055f;
																																		case 30:
																																		case 157:
																																			goto IL_0572;
																																		case 81:
																																			goto IL_0580;
																																		case 159:
																																			goto IL_0593;
																																		case 28:
																																			goto IL_059d;
																																		case 102:
																																			goto IL_05ab;
																																		case 8:
																																			goto IL_05db;
																																		case 78:
																																		case 151:
																																			goto IL_05ee;
																																		case 65:
																																			goto IL_062e;
																																		case 73:
																																			goto IL_0642;
																																		case 58:
																																		case 86:
																																			goto IL_0655;
																																		case 6:
																																		case 11:
																																			goto IL_0668;
																																		case 105:
																																			goto IL_0676;
																																		case 33:
																																		case 52:
																																			goto IL_0681;
																																		case 27:
																																			goto IL_069b;
																																		case 138:
																																			goto IL_06ae;
																																		case 37:
																																		case 63:
																																			goto IL_06b9;
																																		case 31:
																																			goto IL_06c7;
																																		case 119:
																																			goto IL_06da;
																																		case 69:
																																			goto IL_06e8;
																																		case 67:
																																			goto IL_06f6;
																																		case 124:
																																		case 128:
																																			goto IL_0704;
																																		case 148:
																																			goto IL_074d;
																																		case 36:
																																			goto IL_0761;
																																		case 80:
																																		case 111:
																																			goto IL_0774;
																																		case 83:
																																			goto IL_07d6;
																																		case 93:
																																			goto IL_07f2;
																																		case 110:
																																		case 135:
																																			goto IL_0800;
																																		case 108:
																																			goto IL_080b;
																																		case 117:
																																		case 158:
																																			goto IL_0819;
																																		case 42:
																																			goto IL_0842;
																																		case 112:
																																			goto IL_0850;
																																		case 25:
																																			goto IL_0863;
																																		case 145:
																																			goto IL_0871;
																																		case 38:
																																		case 54:
																																			goto IL_087f;
																																		case 116:
																																			goto IL_089b;
																																		case 32:
																																		case 68:
																																			goto IL_08a6;
																																		case 87:
																																			goto IL_08be;
																																		case 153:
																																			goto IL_08cc;
																																		case 55:
																																			goto IL_08da;
																																		case 57:
																																		case 59:
																																			goto IL_08ea;
																																		case 70:
																																			goto IL_08f5;
																																		case 45:
																																		case 109:
																																			goto IL_0900;
																																		case 61:
																																			goto IL_0915;
																																		case 0:
																																		case 1:
																																		case 2:
																																		case 10:
																																		case 18:
																																		case 20:
																																		case 24:
																																		case 34:
																																		case 51:
																																		case 53:
																																		case 60:
																																		case 76:
																																		case 79:
																																		case 82:
																																		case 94:
																																		case 98:
																																		case 103:
																																		case 115:
																																		case 118:
																																		case 121:
																																		case 130:
																																		case 131:
																																		case 133:
																																		case 140:
																																		case 141:
																																		case 144:
																																		case 152:
																																		case 154:
																																		case 162:
																																			goto end_IL_0311;
																																		case 106:
																																			goto IL_093e;
																																		case 72:
																																			goto IL_094c;
																																		case 114:
																																			goto IL_095a;
																																		case 4:
																																		case 7:
																																		case 15:
																																		case 23:
																																		case 35:
																																		case 40:
																																		case 46:
																																		case 66:
																																		case 77:
																																		case 85:
																																		case 88:
																																		case 101:
																																		case 113:
																																		case 120:
																																		case 125:
																																		case 129:
																																		case 136:
																																		case 146:
																																		case 161:
																																			goto end_IL_02b3;
																																		case 14:
																																			goto end_IL_0968;
																																		case 150:
																																			goto end_IL_097b;
																																		case 155:
																																			goto end_IL_0985;
																																		case 123:
																																			goto end_IL_0990;
																																		case 127:
																																			goto end_IL_09a0;
																																		case 12:
																																		case 147:
																																			goto end_IL_09b0;
																																		case 160:
																																			goto end_IL_09c0;
																																		case 17:
																																			goto end_IL_09d0;
																																		case 26:
																																			goto end_IL_09e0;
																																		case 99:
																																			goto end_IL_09f0;
																																		case 100:
																																			goto end_IL_09fb;
																																		case 3:
																																		case 84:
																																			return;
																																		}
																																		continue;
																																	}
																																	array[num5 - 2] = 0;
																																	num = 8;
																																	goto IL_05db;
																																	IL_05db:
																																	num5--;
																																	break;
																																	continue;
																																	end_IL_02b3:
																																	break;
																																}
																																break;
																															}
																															goto end_IL_038e;
																															continue;
																															end_IL_0311:
																															break;
																															IL_0311:;
																														}
																														break;
																														IL_0321:;
																													}
																													break;
																												}
																												goto IL_05ee;
																												IL_0642:
																												num5--;
																												goto end_IL_038e;
																												IL_05ee:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_062e;
																												IL_062e:
																												array[num5 - 2] = 0;
																												goto IL_0642;
																											}
																											break;
																										}
																										goto IL_03d7;
																										IL_045c:
																										num5--;
																										goto end_IL_038e;
																										IL_03d7:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_03e5;
																										IL_03e5:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0408;
																										IL_0408:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0448;
																										IL_0448:
																										array[num5 - 2] = 0;
																										goto IL_045c;
																									}
																									break;
																								}
																								goto IL_03b9;
																								IL_05ab:
																								ptr2 += 8;
																								goto end_IL_038e;
																								IL_03b9:
																								if (4 > b)
																								{
																									goto IL_03c7;
																								}
																								goto IL_046f;
																								IL_03c7:
																								if (2 >= b)
																								{
																									goto IL_03f5;
																								}
																								goto IL_050c;
																								IL_03f5:
																								if (2 <= b)
																								{
																									goto IL_04a5;
																								}
																								goto IL_0572;
																								IL_0572:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0580;
																								IL_0580:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_04a5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04e5;
																								IL_04e5:
																								array[num5 - 2] = 0;
																								goto IL_04f9;
																								IL_04f9:
																								num5--;
																								goto end_IL_038e;
																								IL_050c:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_051a;
																								IL_051a:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0528;
																								IL_0528:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0551;
																								IL_0551:
																								ptr2 += 8;
																								goto IL_055f;
																								IL_055f:
																								num5--;
																								goto end_IL_038e;
																								IL_046f:
																								array[num5] = 0;
																								goto IL_047d;
																								IL_047d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0593;
																								IL_0593:
																								array2[num5] = null;
																								goto IL_059d;
																								IL_059d:
																								num5++;
																								goto IL_05ab;
																							}
																							break;
																						}
																						goto IL_0655;
																						IL_0655:
																						num5--;
																						goto end_IL_038e;
																					}
																					break;
																				}
																				goto IL_0668;
																				IL_0915:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_0668:
																				if (12 >= b)
																				{
																					goto IL_0676;
																				}
																				goto IL_07f2;
																				IL_0676:
																				if (12 <= b)
																				{
																					goto IL_0681;
																				}
																				goto IL_06ae;
																				IL_0681:
																				bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																				goto IL_069b;
																				IL_069b:
																				num5--;
																				goto end_IL_038e;
																				IL_06ae:
																				if (10 < b)
																				{
																					goto IL_06b9;
																				}
																				goto IL_06da;
																				IL_06b9:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_06c7;
																				IL_06c7:
																				if (11 <= b)
																				{
																					goto end_IL_038e;
																				}
																				break;
																				IL_06da:
																				if (10 > b)
																				{
																					goto IL_06e8;
																				}
																				goto IL_0774;
																				IL_06e8:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_06f6;
																				IL_06f6:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0704;
																				IL_0704:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 148;
																				goto IL_074d;
																				IL_074d:
																				array[num5 - 2] = 0;
																				goto IL_0761;
																				IL_0761:
																				num5--;
																				goto end_IL_038e;
																				IL_0774:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_07d6;
																				IL_07d6:
																				num5 -= 2;
																				num = 77;
																				goto end_IL_038e;
																				IL_07f2:
																				if (14 < b)
																				{
																					goto IL_0800;
																				}
																				goto IL_089b;
																				IL_0800:
																				if (15 >= b)
																				{
																					goto IL_080b;
																				}
																				goto IL_0863;
																				IL_080b:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0819;
																				IL_0819:
																				((delegate*<UnityEngine.Object, void>)getIsFamilyOrAssemblyRegisterTrackingHandler[*(int*)(ptr2 + num3)])((Class0)array2[num5 - 1]);
																				goto IL_0842;
																				IL_0842:
																				num5--;
																				goto IL_0850;
																				IL_0850:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_0863:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_0871;
																				IL_0871:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_087f;
																				IL_087f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_038e;
																				IL_089b:
																				if (14 <= b)
																				{
																					goto IL_08a6;
																				}
																				goto IL_08ea;
																				IL_08a6:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_08be;
																				IL_08be:
																				array[num5] = 5;
																				goto IL_08cc;
																				IL_08cc:
																				num5++;
																				goto IL_08da;
																				IL_08da:
																				ptr2 += 8;
																				goto end_IL_038e;
																				IL_08ea:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_08f5;
																				IL_08f5:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_0900;
																				IL_0900:
																				((delegate*<void>)getIsFamilyOrAssemblyRegisterTrackingHandler[*(int*)(ptr2 + num3)])();
																				goto IL_0915;
																			}
																			break;
																			IL_037e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_093e;
																	IL_095a:
																	ptr2 += 8;
																	break;
																	IL_094c:
																	num5++;
																	goto IL_095a;
																	IL_093e:
																	array[num5] = 0;
																	goto IL_094c;
																	continue;
																	end_IL_038e:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_0968:
														break;
													}
													continue;
													end_IL_097b:
													break;
												}
												continue;
												end_IL_0985:
												break;
											}
											continue;
											end_IL_0990:
											break;
										}
										continue;
										end_IL_09a0:
										break;
									}
									continue;
									end_IL_09b0:
									break;
								}
								continue;
								end_IL_09c0:
								break;
							}
							continue;
							end_IL_09d0:
							break;
						}
						continue;
						end_IL_09e0:
						break;
					}
					continue;
					end_IL_09f0:
					break;
				}
				continue;
				end_IL_09fb:
				break;
			}
		}
	}

	private static double NotSpecifiedgetAsDate(double double_1)
	{
		return Math.Abs(double_1);
	}

	private static Transform IdnMappingResourceManagerFoundResourceSetInCache(Component component_0)
	{
		return component_0.transform;
	}

	private static Vector3 getContainerIDShortInlineR(Transform transform_0)
	{
		return transform_0.position;
	}

	private static int ManifestFlagsWindowsRuntimeResourceManagerBase(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static string[] TotalChunksGetImplTypeFlags(string string_0, char char_0, StringSplitOptions stringSplitOptions_0)
	{
		return string_0.Split(new char[1] { char_0 }, stringSplitOptions_0);
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 41;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 28;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setPrivateBinPathProbegetPermissionType.RtFieldInfoResourceTypeManifestResourcesDependency);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0297:
															byte b = *ptr2;
															while (true)
															{
																IL_0287:
																ptr2++;
																while (true)
																{
																	IL_0277:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0257:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_024a:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_023d:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_022a:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01ae:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												num = 99;
																												while (true)
																												{
																													if (num != 99)
																													{
																														if (num != 1080)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 34:
																														case 48:
																															goto IL_01ae;
																														case 84:
																															goto IL_022a;
																														case 47:
																															goto IL_023d;
																														case 52:
																															goto IL_024a;
																														case 19:
																															goto IL_0257;
																														case 86:
																															goto IL_0267;
																														case 45:
																															goto IL_0277;
																														case 30:
																															goto IL_0287;
																														case 16:
																														case 24:
																															goto IL_0297;
																														case 7:
																														case 32:
																															goto IL_02a2;
																														case 21:
																														case 46:
																															goto IL_02b2;
																														case 35:
																														case 56:
																															goto IL_02e0;
																														case 37:
																															goto IL_02ee;
																														case 59:
																															goto IL_030a;
																														case 11:
																														case 60:
																															goto IL_0318;
																														case 53:
																														case 65:
																															goto IL_035d;
																														case 26:
																															goto IL_0368;
																														case 5:
																														case 42:
																															goto IL_0376;
																														case 25:
																															goto IL_0384;
																														case 6:
																														case 22:
																															goto IL_0392;
																														case 70:
																															goto IL_03aa;
																														case 54:
																														case 85:
																															goto IL_03bd;
																														case 17:
																														case 78:
																															goto IL_03c8;
																														case 8:
																															goto IL_03d6;
																														case 2:
																														case 18:
																															goto IL_03e4;
																														case 64:
																															goto IL_0400;
																														case 10:
																														case 33:
																															goto IL_040e;
																														case 81:
																															goto IL_0425;
																														case 74:
																															goto IL_0451;
																														case 71:
																															goto IL_045b;
																														case 80:
																															goto IL_0469;
																														case 90:
																															goto IL_047c;
																														case 91:
																															goto IL_048f;
																														case 36:
																															goto IL_04a3;
																														case 0:
																														case 3:
																														case 13:
																														case 14:
																														case 15:
																														case 31:
																														case 55:
																														case 57:
																														case 61:
																														case 63:
																														case 68:
																														case 69:
																														case 76:
																														case 77:
																														case 79:
																														case 83:
																														case 87:
																														case 92:
																															goto end_IL_0267;
																														case 72:
																															goto IL_04d6;
																														case 12:
																															goto IL_04ed;
																														case 51:
																															goto IL_04fb;
																														case 23:
																														case 27:
																														case 29:
																														case 38:
																														case 39:
																														case 44:
																														case 66:
																														case 67:
																														case 75:
																														case 82:
																														case 89:
																															goto end_IL_019b;
																														case 49:
																															goto end_IL_0519;
																														case 62:
																															goto end_IL_052c;
																														case 43:
																															goto end_IL_0536;
																														case 50:
																															goto end_IL_0541;
																														case 20:
																															goto end_IL_0556;
																														case 1:
																														case 73:
																															goto end_IL_056b;
																														case 9:
																															goto end_IL_057b;
																														case 4:
																														case 28:
																															goto end_IL_058b;
																														case 40:
																															goto end_IL_059b;
																														case 41:
																															goto end_IL_05ab;
																														case 58:
																														case 88:
																															goto IL_05cf;
																														}
																														continue;
																													}
																													num5 -= 2;
																													break;
																													continue;
																													end_IL_019b:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02e0;
																										IL_02ee:
																										if (1 > b)
																										{
																											num = 77;
																										}
																										goto end_IL_0267;
																										IL_02e0:
																										if (1 < b)
																										{
																											goto end_IL_0267;
																										}
																										goto IL_02ee;
																									}
																									break;
																								}
																								goto IL_02a2;
																								IL_04a3:
																								num5--;
																								break;
																								IL_02a2:
																								if (3 < b)
																								{
																									goto end_IL_0267;
																								}
																								goto IL_030a;
																								IL_030a:
																								if (3 > b)
																								{
																									goto end_IL_0267;
																								}
																								goto IL_0318;
																								IL_0318:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_048f;
																								IL_048f:
																								array[num5 - 2] = 0;
																								goto IL_04a3;
																							}
																							break;
																						}
																						goto IL_02b2;
																						IL_047c:
																						num5--;
																						break;
																						IL_02b2:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03aa;
																						IL_03aa:
																						ptr2 += 8;
																						goto IL_047c;
																					}
																					break;
																				}
																				goto IL_035d;
																				IL_0469:
																				ptr2 += 8;
																				break;
																				IL_035d:
																				if (6 >= b)
																				{
																					goto IL_0368;
																				}
																				goto IL_03bd;
																				IL_0368:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_0376;
																				IL_0376:
																				if (5 < b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_0384;
																				IL_0384:
																				if (5 > b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_0392;
																				IL_0392:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_03bd:
																				if (7 < b)
																				{
																					goto IL_03c8;
																				}
																				goto IL_0400;
																				IL_03c8:
																				if (8 < b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_03d6;
																				IL_03d6:
																				if (8 > b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_03e4;
																				IL_03e4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0400:
																				if (7 > b)
																				{
																					goto end_IL_0267;
																				}
																				goto IL_040e;
																				IL_040e:
																				array[num5] = 0;
																				num = 81;
																				goto IL_0425;
																				IL_0425:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 74;
																				goto IL_0451;
																				IL_0451:
																				array2[num5] = null;
																				goto IL_045b;
																				IL_045b:
																				num5++;
																				goto IL_0469;
																			}
																			goto end_IL_0277;
																			continue;
																			end_IL_0267:
																			break;
																			IL_0267:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d6;
																	IL_04fb:
																	ptr2 += 8;
																	break;
																	IL_04ed:
																	num5++;
																	goto IL_04fb;
																	IL_04d6:
																	array[num5] = 0;
																	num = 12;
																	goto IL_04ed;
																	continue;
																	end_IL_0277:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05cf;
													IL_05cf:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0519:
													break;
												}
												continue;
												end_IL_052c:
												break;
											}
											continue;
											end_IL_0536:
											break;
										}
										continue;
										end_IL_0541:
										break;
									}
									continue;
									end_IL_0556:
									break;
								}
								continue;
								end_IL_056b:
								break;
							}
							continue;
							end_IL_057b:
							break;
						}
						continue;
						end_IL_058b:
						break;
					}
					continue;
					end_IL_059b:
					break;
				}
				continue;
				end_IL_05ab:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 132;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetAuditRuleProtectionCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAGINSTALL.DebuggerTypeProxyAttributeorderablePartitionerSource);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0308:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02e8:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02d8:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02cb:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02bb:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (true)
																											{
																												IL_0298:
																												if (7 > b)
																												{
																													num = 154;
																													while (num != 154)
																													{
																														if (num != 1135)
																														{
																															goto IL_0615;
																														}
																														switch (num)
																														{
																														case 75:
																															goto IL_0298;
																														case 44:
																														case 138:
																															goto IL_02ab;
																														case 94:
																															goto IL_02bb;
																														case 24:
																														case 77:
																															goto IL_02cb;
																														case 83:
																															goto IL_02d8;
																														case 109:
																															goto IL_02e8;
																														case 71:
																															goto IL_02f8;
																														case 9:
																															goto IL_0308;
																														case 39:
																															goto end_IL_0308;
																														case 92:
																														case 123:
																															goto end_IL_0318;
																														case 6:
																															goto IL_033c;
																														case 50:
																															goto IL_034c;
																														case 55:
																															goto IL_035f;
																														case 11:
																															goto IL_036a;
																														case 3:
																															goto IL_037a;
																														case 8:
																															goto IL_0388;
																														case 56:
																														case 57:
																															goto IL_039b;
																														case 78:
																															goto IL_03db;
																														case 54:
																															goto IL_03ef;
																														case 13:
																														case 97:
																															goto IL_0402;
																														case 1:
																															goto IL_0420;
																														case 32:
																															goto IL_042e;
																														case 96:
																														case 105:
																															goto IL_0441;
																														case 19:
																														case 119:
																															goto IL_046f;
																														case 16:
																															goto IL_04ae;
																														case 120:
																															goto IL_04c1;
																														case 60:
																															goto IL_04cf;
																														case 46:
																														case 124:
																															goto IL_04df;
																														case 125:
																															goto IL_0508;
																														case 129:
																															goto IL_0521;
																														case 29:
																															goto IL_052f;
																														case 134:
																															goto IL_0542;
																														case 133:
																														case 142:
																															goto IL_0552;
																														case 10:
																															goto IL_0560;
																														case 23:
																															goto IL_0578;
																														case 36:
																															goto IL_0586;
																														case 145:
																															goto IL_0599;
																														case 66:
																														case 79:
																															goto IL_05a7;
																														case 2:
																															goto IL_05c0;
																														case 80:
																															goto IL_05ce;
																														case 126:
																															goto IL_05dc;
																														case 38:
																														case 82:
																															goto IL_05ef;
																														case 30:
																															goto IL_0607;
																														case 47:
																														case 81:
																															goto IL_0615;
																														case 59:
																															goto IL_0623;
																														case 18:
																														case 49:
																															goto IL_062e;
																														case 15:
																														case 122:
																															goto IL_064a;
																														case 91:
																															goto IL_0658;
																														case 72:
																														case 115:
																															goto IL_0666;
																														case 100:
																															goto IL_06c8;
																														case 67:
																															goto IL_06db;
																														case 40:
																															goto IL_06e9;
																														case 4:
																															goto IL_06fc;
																														case 34:
																														case 110:
																															goto IL_070a;
																														case 98:
																															goto IL_0718;
																														case 86:
																														case 89:
																															goto IL_0723;
																														case 99:
																															goto IL_0731;
																														case 20:
																															goto IL_0754;
																														case 35:
																															goto IL_075e;
																														case 87:
																															goto IL_076c;
																														case 74:
																															goto IL_077f;
																														case 25:
																															goto IL_078d;
																														case 17:
																															goto IL_07a0;
																														case 111:
																															goto IL_07ab;
																														case 114:
																														case 146:
																															goto IL_07b6;
																														case 102:
																															goto IL_07fa;
																														case 48:
																															goto IL_080e;
																														case 21:
																														case 27:
																														case 28:
																														case 33:
																														case 42:
																														case 43:
																														case 45:
																														case 53:
																														case 63:
																														case 65:
																														case 69:
																														case 84:
																														case 90:
																														case 93:
																														case 103:
																														case 107:
																														case 108:
																														case 112:
																														case 116:
																														case 117:
																														case 121:
																														case 128:
																														case 130:
																														case 135:
																														case 139:
																														case 140:
																														case 141:
																														case 143:
																															goto end_IL_0285;
																														case 61:
																														case 144:
																															goto IL_0836;
																														case 41:
																															goto IL_0876;
																														case 22:
																															goto IL_088a;
																														case 5:
																														case 7:
																														case 12:
																														case 14:
																														case 26:
																														case 31:
																														case 62:
																														case 68:
																														case 70:
																														case 73:
																														case 88:
																														case 95:
																														case 101:
																														case 118:
																														case 127:
																														case 136:
																														case 137:
																														case 147:
																															goto end_IL_0328;
																														case 106:
																															goto end_IL_08a1;
																														case 58:
																															goto end_IL_08b4;
																														case 0:
																															goto end_IL_08be;
																														case 85:
																															goto end_IL_08c9;
																														case 52:
																														case 76:
																															goto end_IL_08d9;
																														case 104:
																															goto end_IL_08e9;
																														case 37:
																														case 113:
																															goto end_IL_08f9;
																														case 131:
																															goto end_IL_0909;
																														case 132:
																															goto end_IL_0919;
																														case 51:
																														case 64:
																															goto IL_0934;
																														}
																														continue;
																														end_IL_0285:
																														break;
																													}
																													break;
																												}
																												goto IL_0441;
																												IL_0521:
																												ptr2 += 8;
																												goto IL_052f;
																												IL_052f:
																												num5--;
																												goto end_IL_0328;
																												IL_0441:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0521;
																											}
																											break;
																											IL_02ab:;
																										}
																										break;
																									}
																									goto IL_034c;
																									IL_0586:
																									ptr2 += 8;
																									goto end_IL_0328;
																									IL_034c:
																									if (6 <= b)
																									{
																										goto IL_046f;
																									}
																									goto IL_04c1;
																									IL_046f:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04ae;
																									IL_04ae:
																									num5 -= 3;
																									goto end_IL_0328;
																									IL_04c1:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_04cf;
																									IL_04cf:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0552;
																									IL_0552:
																									array[num5] = 5;
																									goto IL_0560;
																									IL_0560:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0578;
																									IL_0578:
																									num5++;
																									goto IL_0586;
																								}
																								break;
																							}
																							num = 6;
																							goto IL_033c;
																							IL_04df:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0508;
																							IL_0508:
																							array[num5 - 1] = 5;
																							goto end_IL_0328;
																							IL_033c:
																							if (4 > b)
																							{
																								goto IL_035f;
																							}
																							goto IL_0402;
																							IL_0402:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0420;
																							IL_0420:
																							ptr2 += 8;
																							goto IL_042e;
																							IL_042e:
																							num5--;
																							goto end_IL_0328;
																							IL_035f:
																							if (2 >= b)
																							{
																								goto IL_036a;
																							}
																							goto IL_037a;
																							IL_036a:
																							if (2 <= b)
																							{
																								goto IL_039b;
																							}
																							goto IL_0542;
																							IL_0542:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0599;
																							IL_0599:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_05a7;
																							IL_05a7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05c0;
																							IL_05c0:
																							array[num5] = 0;
																							goto IL_05ce;
																							IL_05ce:
																							num5++;
																							goto IL_05dc;
																							IL_05dc:
																							ptr2 += 8;
																							goto end_IL_0328;
																							IL_039b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03db;
																							IL_03db:
																							array[num5 - 2] = 0;
																							goto IL_03ef;
																							IL_03ef:
																							num5--;
																							goto end_IL_0328;
																							IL_037a:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0388;
																							IL_0388:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_04df;
																						}
																						break;
																					}
																					goto IL_05ef;
																					IL_05ef:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0328;
																				}
																				break;
																			}
																			goto IL_0607;
																			IL_088a:
																			num5--;
																			num = 127;
																			goto end_IL_0328;
																			IL_0607:
																			if (12 < b)
																			{
																				goto IL_0615;
																			}
																			goto IL_06fc;
																			IL_0615:
																			if (14 >= b)
																			{
																				goto IL_0623;
																			}
																			goto IL_06db;
																			IL_0623:
																			if (14 <= b)
																			{
																				goto IL_062e;
																			}
																			goto IL_064a;
																			IL_062e:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0328;
																			IL_064a:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0658;
																			IL_0658:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0666;
																			IL_0666:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06c8;
																			IL_06c8:
																			num5 -= 2;
																			goto end_IL_0328;
																			IL_06db:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_06e9;
																			IL_06e9:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_06fc:
																			if (12 > b)
																			{
																				goto IL_070a;
																			}
																			goto IL_0836;
																			IL_070a:
																			if (10 >= b)
																			{
																				goto IL_0718;
																			}
																			goto IL_07a0;
																			IL_0718:
																			if (10 <= b)
																			{
																				goto IL_0723;
																			}
																			goto IL_077f;
																			IL_0723:
																			array[num5] = 0;
																			goto IL_0731;
																			IL_0731:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0754;
																			IL_0754:
																			array2[num5] = null;
																			goto IL_075e;
																			IL_075e:
																			num5++;
																			goto IL_076c;
																			IL_076c:
																			ptr2 += 8;
																			goto end_IL_0328;
																			IL_077f:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_078d;
																			IL_078d:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_0328;
																			IL_07a0:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_07ab;
																			IL_07ab:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_07b6;
																			IL_07b6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_07fa;
																			IL_07fa:
																			array[num5 - 2] = 0;
																			goto IL_080e;
																			IL_080e:
																			num5--;
																			goto end_IL_0328;
																			IL_0836:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0876;
																			IL_0876:
																			array[num5 - 2] = 0;
																			goto IL_088a;
																		}
																		break;
																		IL_02f8:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0328;
																continue;
																end_IL_0308:
																break;
															}
															continue;
															end_IL_0318:
															break;
														}
														continue;
														end_IL_0328:
														break;
													}
													continue;
												}
												goto IL_0934;
												IL_0934:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a1:
												break;
											}
											continue;
											end_IL_08b4:
											break;
										}
										continue;
										end_IL_08be:
										break;
									}
									continue;
									end_IL_08c9:
									break;
								}
								continue;
								end_IL_08d9:
								break;
							}
							continue;
							end_IL_08e9:
							break;
						}
						continue;
						end_IL_08f9:
						break;
					}
					continue;
					end_IL_0909:
					break;
				}
				continue;
				end_IL_0919:
				break;
			}
		}
	}

	private static string MakeVersionSafeNameHasTrueValue(string[] string_0)
	{
		return string.Concat(string_0);
	}

	public Class0()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static string UnadviseListDirectory(string string_0)
	{
		return string_0.ToLower();
	}

	private static bool ExportableIMPALWAYSFLOW()
	{
		return SubscriptionManager.IsLocalSubscribed();
	}

	private static int smethod_7(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		int num5 = smethod_6();
		num4 = num5;
		return num;
	}

	private unsafe static void smethod_8()
	{
		RuntimeTypeHandle[] array = new RuntimeTypeHandle[1];
		Type[] array2 = new Type[1];
		array[0] = typeof(object).TypeHandle;
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref KeyPropertyDescription.getAccessControlTypeQWord);
		int num = 4;
		int num2 = 0;
		int num3 = 0;
		num3 = 0;
		int try0030_dispatch = -1;
		object[] array3 = default(object[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num24 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		object obj3 = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		string text27 = default(string);
		string text28 = default(string);
		string text29 = default(string);
		string text30 = default(string);
		string text31 = default(string);
		string text32 = default(string);
		string text33 = default(string);
		string text34 = default(string);
		string text35 = default(string);
		string text36 = default(string);
		string text37 = default(string);
		string text38 = default(string);
		string text39 = default(string);
		string text40 = default(string);
		string text41 = default(string);
		string text42 = default(string);
		string text43 = default(string);
		string text44 = default(string);
		string text45 = default(string);
		string text46 = default(string);
		string text47 = default(string);
		string text48 = default(string);
		string text49 = default(string);
		string text50 = default(string);
		string text51 = default(string);
		string text52 = default(string);
		string text53 = default(string);
		string text54 = default(string);
		string text55 = default(string);
		string text56 = default(string);
		string text57 = default(string);
		string text58 = default(string);
		string text59 = default(string);
		string text60 = default(string);
		string text61 = default(string);
		string text62 = default(string);
		string text63 = default(string);
		string text64 = default(string);
		string text65 = default(string);
		string text66 = default(string);
		float num31 = default(float);
		string text67 = default(string);
		Vector3 vector = default(Vector3);
		string[] array6 = default(string[]);
		int num32 = default(int);
		string text68 = default(string);
		GameObject gameObject = default(GameObject);
		float num33 = default(float);
		string text69 = default(string);
		ExitGames.Client.Photon.Hashtable hashtable = default(ExitGames.Client.Photon.Hashtable);
		RoomConfig roomConfig = default(RoomConfig);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0030_dispatch)
				{
				case 2115:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 168 + num8 * 40 + 32 + num);
							num10 = *(int*)(ptr + 168 + num8 * 40 + 8 + num);
							if (num5 >= num9 + num10)
							{
								num6 = num8 + 1;
								continue;
							}
							if (num9 <= num5)
							{
								break;
							}
							num7 = num8 - 1;
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 168 + num11 * 40 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array3 != null)
							{
								if ((int)array3[7] == 1)
								{
									int num15 = (int)array3[0];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + 64 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 288 + num8 * 72 + 64 + num);
											num6 = *(int*)(ptr + 288 + num8 * 72 + 24 + num);
											if (num17 >= num7 + num6)
											{
												num10 = num8 + 1;
												continue;
											}
											if (num7 <= num17)
											{
												break;
											}
											num9 = num8 - 1;
										}
										num12 = num8;
										num11 = *(int*)(ptr + 288 + num12 * 72 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array3 = (object[])array3[3];
										continue;
									}
								}
								else
								{
									int num18 = (int)array3[5];
									if (num18 != 1 && num18 != 2 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array3[0];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + 64 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 288 + num8 * 72 + 64 + num);
											num10 = *(int*)(ptr + 288 + num8 * 72 + 24 + num);
											if (num5 >= num9 + num10)
											{
												num6 = num8 + 1;
												continue;
											}
											if (num9 <= num5)
											{
												break;
											}
											num7 = num8 - 1;
										}
										num11 = num8;
										num12 = *(int*)(ptr + 288 + num11 * 72 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array3 = (object[])array3[3];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_0856;
							}
							num21 = *(int*)(ptr + num13 + 32 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 32 + num);
								if (4 != num7)
								{
									goto IL_079f;
								}
								num6 = *(int*)(ptr + num5 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 40 + num);
										continue;
									}
								}
								goto IL_08e3;
							}
							num13 = *(int*)(ptr + num13 + 80 + num);
							continue;
							IL_079f:
							if (1 != num7)
							{
								num13 = *(int*)(ptr + num13 + 80 + num);
								continue;
							}
							goto IL_088a;
						}
						object[] array4 = array3;
						num4 = *(int*)(ptr + (int)array4[0] + 40 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 32 + num);
							if (4 != num21)
							{
								goto IL_04eb;
							}
							num13 = *(int*)(ptr + num4 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[4]))
								{
									num4 = *(int*)(ptr + num4 + 40 + num);
									continue;
								}
							}
							goto IL_0a6d;
						}
						goto IL_04f3;
						IL_04f3:
						array3 = (object[])array3[3];
						ex = (Exception)array4[4];
						num22 = (int)array4[6];
						continue;
						IL_08e3:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 72 + num) + 80 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 80 + num);
									continue;
								}
								array4 = new object[8];
								array4[7] = 0;
								array4[3] = array3;
								array4[4] = ex;
								array4[6] = num14;
								array4[0] = num8;
								array4[1] = num17;
								array4[5] = 2;
								array3 = array4;
								num2 = *(int*)(ptr + num8 + 56 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[7] = 0;
							array4[3] = array3;
							array4[4] = ex;
							array4[6] = num14;
							array4[0] = num17;
							array4[5] = 1;
							array3 = array4;
							num2 = *(int*)(ptr + num17 + 56 + num);
							break;
						}
						break;
						IL_0a6d:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 72 + num) + 80 + num);
						num14 = (int)array4[6];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 80 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + 56 + num);
								array3 = (object[])array3[3];
								array5 = new object[8];
								array5[7] = 0;
								array5[3] = array3;
								array5[4] = array4[4];
								array5[6] = (int)array4[6];
								array5[0] = num18;
								array5[1] = num12;
								array5[5] = 2;
								array3 = array5;
								num2 = *(int*)(ptr + num18 + 56 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + 56 + num);
							ex2 = (Exception)array4[4];
							array3 = (object[])array3[3];
							array5 = new object[8];
							array5[7] = 0;
							array5[3] = array3;
							array5[4] = array4[4];
							array5[6] = (int)array4[6];
							array5[0] = num12;
							array5[5] = 1;
							array3 = array5;
							num2 = *(int*)(ptr + num12 + 56 + num);
							break;
						}
						break;
						IL_088a:
						ex2 = ex;
						array4 = new object[8];
						array4[7] = 0;
						array4[3] = array3;
						array4[4] = ex;
						array4[6] = num14;
						array4[0] = num5;
						array4[5] = 0;
						array3 = array4;
						num2 = *(int*)(ptr + num5 + 48 + num);
						break;
						IL_0856:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 80 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + 56 + num);
						array4 = new object[8];
						array4[7] = 0;
						array4[3] = array3;
						array4[4] = ex;
						array4[6] = num14;
						array4[0] = -1;
						array4[1] = -1;
						array4[5] = 1;
						array3 = array4;
						num2 = *(int*)(ptr + num11 + 56 + num);
						break;
						IL_04eb:
						if (1 == num21)
						{
							num5 = *(int*)(ptr + num4 + 48 + num);
							ex2 = (Exception)array4[4];
							array3 = (object[])array3[3];
							object[] array5 = new object[8];
							array5[7] = 0;
							array5[3] = array3;
							array5[4] = array4[4];
							array5[6] = (int)array4[6];
							array5[0] = num4;
							array5[5] = 0;
							array3 = array5;
							num2 = *(int*)(ptr + num4 + 48 + num);
							break;
						}
						goto IL_04f3;
					}
					break;
				}
				while (true)
				{
					switch (num3)
					{
					case 22:
					{
						num3 = 0;
						int num13 = num24;
						int num34 = num13;
						int num11 = num2;
						int num21 = num11;
						num13 = 0;
						int num4 = 2;
						int num7;
						int num6;
						int num5;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 168 + num5 * 40 + 32 + num);
							num7 = *(int*)(ptr + 168 + num5 * 40 + 8 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						int num14 = num5;
						int num18 = *(int*)(ptr + 168 + num14 * 40 + num);
						int num12 = num18;
						num7 = num34;
						num6 = 0;
						num5 = 2;
						while (true)
						{
							num4 = (num6 + num5) / 2;
							num13 = *(int*)(ptr + 168 + num4 * 40 + 32 + num);
							num21 = *(int*)(ptr + 168 + num4 * 40 + 8 + num);
							if (num7 >= num13 + num21)
							{
								num6 = num4 + 1;
								continue;
							}
							if (num13 <= num7)
							{
								break;
							}
							num5 = num4 - 1;
						}
						num14 = num4;
						int num8 = *(int*)(ptr + 168 + num14 * 40 + num);
						num18 = num8;
						num21 = num34;
						num13 = 0;
						num4 = 2;
						while (true)
						{
							num5 = (num13 + num4) / 2;
							num6 = *(int*)(ptr + 288 + num5 * 72 + 64 + num);
							num7 = *(int*)(ptr + 288 + num5 * 72 + 24 + num);
							if (num21 >= num6 + num7)
							{
								num13 = num5 + 1;
								continue;
							}
							if (num6 <= num21)
							{
								break;
							}
							num4 = num5 - 1;
						}
						num14 = num5;
						int num9 = *(int*)(ptr + 288 + num14 * 72 + num);
						num8 = num9;
						while (true)
						{
							if (array3 == null || (int)array3[7] == 1)
							{
								num21 = num18;
								while (num21 != num12)
								{
									if (num21 != -1)
									{
										num21 = *(int*)(ptr + num21 + 80 + num);
										continue;
									}
									goto IL_01f4;
								}
								num2 = num34;
								break;
							}
							int num35 = (int)array3[0];
							int num36;
							if (num12 == -1)
							{
								num36 = -1;
							}
							else
							{
								int num10 = *(int*)(ptr + num12 + 64 + num);
								num7 = 0;
								num6 = 2;
								while (true)
								{
									num5 = (num7 + num6) / 2;
									num4 = *(int*)(ptr + 288 + num5 * 72 + 64 + num);
									num13 = *(int*)(ptr + 288 + num5 * 72 + 24 + num);
									if (num10 >= num4 + num13)
									{
										num7 = num5 + 1;
										continue;
									}
									if (num4 <= num10)
									{
										break;
									}
									num6 = num5 - 1;
								}
								num9 = num5;
								num14 = *(int*)(ptr + 288 + num9 * 72 + num);
								num36 = num14;
							}
							if (num35 == num36)
							{
								num14 = num18;
								while (num14 != num12)
								{
									if (num14 != -1)
									{
										num14 = *(int*)(ptr + num14 + 80 + num);
										continue;
									}
									goto IL_02e6;
								}
								num2 = num34;
								break;
							}
							if ((int)array3[0] != num8)
							{
								array3 = (object[])array3[3];
								continue;
							}
							num2 = num34;
							break;
							IL_02e6:
							num9 = *(int*)(ptr + num12 + num);
							if (num9 == -1)
							{
								num12 = *(int*)(ptr + num12 + 80 + num);
								continue;
							}
							num21 = *(int*)(ptr + num9 + 56 + num);
							object[] array4 = new object[8];
							array4[7] = 1;
							array4[3] = array3;
							array4[2] = num34;
							array4[0] = num9;
							array4[5] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num9 + 56 + num);
							break;
							IL_01f4:
							num13 = *(int*)(ptr + num12 + num);
							if (num13 == -1)
							{
								num12 = *(int*)(ptr + num12 + 80 + num);
								continue;
							}
							num4 = *(int*)(ptr + num13 + 56 + num);
							array4 = new object[8];
							array4[7] = 1;
							array4[3] = array3;
							array4[2] = num34;
							array4[0] = num13;
							array4[5] = 2;
							array3 = array4;
							num2 = *(int*)(ptr + num13 + 56 + num);
							break;
						}
						break;
					}
					default:
						((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref float, ref string, ref Vector3, ref string[], ref int, ref string, ref GameObject, ref float, ref string, ref ExitGames.Client.Photon.Hashtable, ref RoomConfig, void>)SymAddressKindEventCommand[num2])(ref num2, ref num3, ref num24, ex2, ref num25, ref num26, ref num27, ref num28, ref num29, ref num30, ref obj3, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, ref text27, ref text28, ref text29, ref text30, ref text31, ref text32, ref text33, ref text34, ref text35, ref text36, ref text37, ref text38, ref text39, ref text40, ref text41, ref text42, ref text43, ref text44, ref text45, ref text46, ref text47, ref text48, ref text49, ref text50, ref text51, ref text52, ref text53, ref text54, ref text55, ref text56, ref text57, ref text58, ref text59, ref text60, ref text61, ref text62, ref text63, ref text64, ref text65, ref text66, ref num31, ref text67, ref vector, ref array6, ref num32, ref text68, ref gameObject, ref num33, ref text69, ref hashtable, ref roomConfig);
						break;
					case 17:
						num3 = 0;
						return;
					}
				}
			}
			catch (Exception ex3)
			{
				if (num23 == 1)
				{
					throw ex3;
				}
				ex = ex3;
				num22 = -1;
				try0030_dispatch = 2115;
			}
		}
	}

	private static IEnumerator AddOnLogMessageIsFirstRun()
	{
		return smethod_9();
	}

	private static IEnumerator smethod_9()
	{
		_003CMakeRoomVisibleCoroutine_003Ed__5 _003CMakeRoomVisibleCoroutine_003Ed__ = new _003CMakeRoomVisibleCoroutine_003Ed__5(0);
		return _003CMakeRoomVisibleCoroutine_003Ed__;
	}

	private static Vector3 RSAOAEPKeyExchangeDeformatterFrameworkEventSource(Transform transform_0)
	{
		return transform_0.position;
	}

	private unsafe static int smethod_10(int int_1, int int_2)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										num = 12;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetLengthgetSequencePointCount.LoopTimerComInterfaceType);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0288:
															byte b = *ptr2;
															while (true)
															{
																IL_0278:
																ptr2++;
																while (true)
																{
																	IL_0268:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_0258:
																			if (b <= 12)
																			{
																				while (true)
																				{
																					IL_0248:
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_0238:
																							if (6 <= b)
																							{
																								num = 130;
																								while (num != 130)
																								{
																									if (num != 1111)
																									{
																										goto IL_04e9;
																									}
																									switch (num)
																									{
																									case 110:
																										goto IL_0238;
																									case 10:
																										goto IL_0248;
																									case 32:
																										goto IL_0258;
																									case 8:
																										goto IL_0268;
																									case 83:
																										goto IL_0278;
																									case 3:
																									case 86:
																										goto IL_0288;
																									case 71:
																										goto IL_0293;
																									case 4:
																										goto IL_02a1;
																									case 28:
																										goto IL_02ac;
																									case 20:
																									case 96:
																										goto IL_02c8;
																									case 5:
																										goto IL_02d6;
																									case 23:
																									case 56:
																										goto IL_02e4;
																									case 9:
																									case 98:
																										goto IL_02fc;
																									case 76:
																										goto IL_030a;
																									case 52:
																										goto IL_0315;
																									case 41:
																									case 72:
																										goto IL_0320;
																									case 7:
																										goto IL_032e;
																									case 33:
																									case 97:
																										goto IL_033c;
																									case 16:
																										goto IL_0355;
																									case 73:
																										goto IL_0368;
																									case 21:
																									case 90:
																										goto IL_0376;
																									case 18:
																									case 43:
																										goto IL_0389;
																									case 48:
																										goto IL_03c9;
																									case 58:
																										goto IL_03dd;
																									case 104:
																										goto IL_03f0;
																									case 67:
																									case 70:
																										goto IL_03fe;
																									case 62:
																									case 66:
																										goto IL_0409;
																									case 60:
																										goto IL_0419;
																									case 109:
																										goto IL_042c;
																									case 75:
																										goto IL_043a;
																									case 111:
																										goto IL_044d;
																									case 0:
																									case 38:
																										goto IL_0458;
																									case 118:
																										goto IL_04d6;
																									case 74:
																									case 119:
																										goto IL_04e9;
																									case 45:
																										goto IL_0529;
																									case 49:
																										goto IL_053d;
																									case 120:
																										goto IL_0550;
																									case 78:
																										goto IL_0573;
																									case 68:
																										goto IL_057d;
																									case 13:
																										goto IL_058b;
																									case 121:
																										goto IL_059e;
																									case 15:
																										goto IL_05ac;
																									case 54:
																									case 114:
																										goto IL_05ba;
																									case 1:
																										goto IL_05c8;
																									case 27:
																									case 51:
																										goto IL_05d6;
																									case 53:
																										goto IL_05ea;
																									case 93:
																										goto IL_0629;
																									case 40:
																									case 92:
																										goto IL_063c;
																									case 19:
																									case 82:
																										goto IL_0658;
																									case 112:
																										goto IL_0666;
																									case 24:
																									case 107:
																										goto IL_0671;
																									case 22:
																									case 122:
																										goto IL_068d;
																									case 46:
																										goto IL_06b6;
																									case 11:
																										goto IL_06cd;
																									case 17:
																									case 26:
																									case 29:
																									case 36:
																									case 37:
																									case 44:
																									case 55:
																									case 59:
																									case 61:
																									case 69:
																									case 80:
																									case 81:
																									case 84:
																									case 88:
																									case 100:
																									case 106:
																									case 113:
																									case 115:
																									case 116:
																									case 117:
																									case 123:
																										goto IL_06e6;
																									case 95:
																										goto IL_0709;
																									case 89:
																										goto IL_0717;
																									case 35:
																										goto IL_0725;
																									case 2:
																									case 6:
																									case 14:
																									case 25:
																									case 39:
																									case 47:
																									case 50:
																									case 57:
																									case 65:
																									case 87:
																									case 91:
																									case 99:
																									case 101:
																									case 102:
																										goto end_IL_0225;
																									case 94:
																										goto end_IL_0733;
																									case 12:
																										goto end_IL_0746;
																									case 103:
																										goto end_IL_0750;
																									case 34:
																										goto end_IL_075b;
																									case 108:
																										goto end_IL_0779;
																									case 31:
																									case 79:
																										goto end_IL_078e;
																									case 30:
																										goto end_IL_079e;
																									case 42:
																									case 77:
																										goto end_IL_07ae;
																									case 63:
																										goto end_IL_07be;
																									case 64:
																										goto end_IL_07ce;
																									case 85:
																									case 105:
																										goto IL_07e9;
																									}
																									continue;
																									end_IL_0225:
																									break;
																								}
																								break;
																							}
																							goto IL_0293;
																							IL_0419:
																							if (1 > b)
																							{
																							}
																							goto IL_06e6;
																							IL_04e9:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0529;
																							IL_0293:
																							if (3 < b)
																							{
																								goto IL_02a1;
																							}
																							goto IL_03f0;
																							IL_02a1:
																							if (4 >= b)
																							{
																								goto IL_02ac;
																							}
																							num = 20;
																							goto IL_02c8;
																							IL_02ac:
																							if (4 <= b)
																							{
																								goto IL_068d;
																							}
																							goto IL_06e6;
																							IL_068d:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_06b6;
																							IL_06b6:
																							ptr2 += 8;
																							num = 11;
																							goto IL_06cd;
																							IL_06cd:
																							num5--;
																							break;
																							IL_0529:
																							array[num5 - 2] = 0;
																							goto IL_053d;
																							IL_02c8:
																							if (5 >= b)
																							{
																								goto IL_02d6;
																							}
																							goto IL_06e6;
																							IL_02d6:
																							if (5 <= b)
																							{
																								goto IL_02e4;
																							}
																							goto IL_06e6;
																							IL_02e4:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_03f0:
																							if (3 > b)
																							{
																								goto IL_03fe;
																							}
																							goto IL_04e9;
																							IL_03fe:
																							if (1 < b)
																							{
																								goto IL_0409;
																							}
																							goto IL_0419;
																							IL_0409:
																							if (2 >= b)
																							{
																								goto IL_044d;
																							}
																							goto IL_06e6;
																							IL_044d:
																							if (2 <= b)
																							{
																								goto IL_0458;
																							}
																							num = 106;
																							goto IL_06e6;
																							IL_0458:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_04d6;
																							IL_04d6:
																							num5 -= 2;
																							break;
																							IL_053d:
																							num5--;
																							break;
																						}
																						break;
																					}
																					goto IL_02fc;
																					IL_0666:
																					if (12 <= b)
																					{
																						goto IL_0671;
																					}
																					goto IL_06e6;
																					IL_02fc:
																					if (9 >= b)
																					{
																						goto IL_030a;
																					}
																					goto IL_059e;
																					IL_030a:
																					if (9 > b)
																					{
																						goto IL_0315;
																					}
																					goto IL_0389;
																					IL_0315:
																					if (7 < b)
																					{
																						goto IL_0320;
																					}
																					goto IL_0368;
																					IL_0320:
																					if (8 >= b)
																					{
																						goto IL_032e;
																					}
																					goto IL_06e6;
																					IL_032e:
																					if (8 <= b)
																					{
																						goto IL_033c;
																					}
																					goto IL_06e6;
																					IL_033c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0355;
																					IL_0355:
																					array[num5] = 0;
																					goto IL_042c;
																					IL_042c:
																					num5++;
																					goto IL_043a;
																					IL_043a:
																					ptr2 += 8;
																					break;
																					IL_0368:
																					if (7 <= b)
																					{
																						goto IL_0376;
																					}
																					goto IL_06e6;
																					IL_0376:
																					array[num5] = 0;
																					goto IL_0550;
																					IL_0550:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0573;
																					IL_0573:
																					array2[num5] = null;
																					goto IL_057d;
																					IL_057d:
																					num5++;
																					goto IL_058b;
																					IL_058b:
																					ptr2 += 8;
																					break;
																					IL_0389:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c9;
																					IL_03c9:
																					array[num5 - 2] = 0;
																					goto IL_03dd;
																					IL_03dd:
																					num5--;
																					break;
																					IL_059e:
																					if (11 >= b)
																					{
																						goto IL_05ac;
																					}
																					num = 19;
																					goto IL_0658;
																					IL_05ac:
																					if (11 > b)
																					{
																						goto IL_05ba;
																					}
																					goto IL_063c;
																					IL_05ba:
																					if (10 >= b)
																					{
																						goto IL_05c8;
																					}
																					goto IL_06e6;
																					IL_05c8:
																					if (10 <= b)
																					{
																						goto IL_05d6;
																					}
																					goto IL_06e6;
																					IL_05d6:
																					array[num5 - 1] = 0;
																					goto IL_05ea;
																					IL_05ea:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)IEnumSTOREDEPLOYMENTMETADATAFormKDDisallowUnassigned[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0629;
																					IL_0629:
																					ptr2 += 8;
																					break;
																					IL_063c:
																					num5--;
																					break;
																					IL_0671:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0658:
																					if (12 >= b)
																					{
																						goto IL_0666;
																					}
																					goto IL_06e6;
																				}
																				break;
																			}
																			num = 123;
																			goto IL_06e6;
																		}
																		break;
																	}
																	goto IL_06e6;
																	IL_0725:
																	ptr2 += 8;
																	break;
																	IL_06e6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0709;
																	IL_0709:
																	array[num5] = 0;
																	goto IL_0717;
																	IL_0717:
																	num5++;
																	goto IL_0725;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07e9;
													IL_07e9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0733:
													break;
												}
												continue;
												end_IL_0746:
												break;
											}
											continue;
											end_IL_0750:
											break;
										}
										continue;
										end_IL_075b:
										break;
									}
									continue;
									end_IL_0779:
									break;
								}
								continue;
								end_IL_078e:
								break;
							}
							continue;
							end_IL_079e:
							break;
						}
						continue;
						end_IL_07ae:
						break;
					}
					continue;
					end_IL_07be:
					break;
				}
				continue;
				end_IL_07ce:
				break;
			}
		}
	}

	private unsafe static int smethod_11()
	{
		int num = 143;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 104;
				while (true)
				{
					num = 51;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResolveEventHandlerBreak.DefineByValArrayEventName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02e8:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02c8:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02b8:
																						if (12 < b)
																						{
																							while (true)
																							{
																								IL_02ab:
																								if (14 < b)
																								{
																									while (true)
																									{
																										IL_0298:
																										if (15 < b)
																										{
																											num = 154;
																											while (num != 154)
																											{
																												if (num != 1135)
																												{
																													goto IL_0356;
																												}
																												switch (num)
																												{
																												case 5:
																													goto IL_0298;
																												case 70:
																													goto IL_02ab;
																												case 3:
																												case 83:
																													goto IL_02b8;
																												case 30:
																													goto IL_02c8;
																												case 136:
																													goto IL_02d8;
																												case 11:
																													goto IL_02e8;
																												case 140:
																													goto end_IL_02e8;
																												case 115:
																												case 131:
																													goto end_IL_02f8;
																												case 88:
																													goto IL_0313;
																												case 0:
																												case 18:
																													goto IL_031e;
																												case 97:
																												case 103:
																													goto IL_0343;
																												case 108:
																													goto IL_0356;
																												case 6:
																												case 59:
																													goto IL_0364;
																												case 73:
																													goto IL_036f;
																												case 25:
																													goto IL_037f;
																												case 27:
																													goto IL_0398;
																												case 114:
																													goto IL_03ab;
																												case 37:
																												case 117:
																													goto IL_03be;
																												case 24:
																													goto IL_03cc;
																												case 45:
																													goto IL_03ef;
																												case 90:
																													goto IL_03f9;
																												case 111:
																													goto IL_0407;
																												case 120:
																													goto IL_041a;
																												case 12:
																													goto IL_0428;
																												case 93:
																												case 122:
																													goto IL_043b;
																												case 4:
																													goto IL_047b;
																												case 126:
																													goto IL_048f;
																												case 118:
																												case 128:
																													goto IL_04a2;
																												case 36:
																													goto IL_04e6;
																												case 55:
																													goto IL_04fa;
																												case 133:
																													goto IL_050d;
																												case 2:
																												case 71:
																													goto IL_051b;
																												case 99:
																													goto IL_057d;
																												case 124:
																													goto IL_0590;
																												case 54:
																												case 94:
																													goto IL_059b;
																												case 53:
																													goto IL_05b3;
																												case 137:
																													goto IL_05c1;
																												case 87:
																												case 109:
																													goto IL_05d5;
																												case 69:
																													goto IL_05e3;
																												case 64:
																												case 106:
																													goto IL_05f1;
																												case 100:
																													goto IL_061a;
																												case 72:
																													goto IL_0628;
																												case 98:
																													goto IL_063b;
																												case 92:
																													goto IL_0646;
																												case 40:
																													goto IL_0654;
																												case 47:
																												case 50:
																													goto IL_0662;
																												case 65:
																													goto IL_0670;
																												case 130:
																													goto IL_0688;
																												case 58:
																													goto IL_0696;
																												case 23:
																												case 79:
																													goto IL_06a9;
																												case 81:
																													goto IL_06e8;
																												case 146:
																													goto IL_0704;
																												case 74:
																												case 76:
																													goto IL_0712;
																												case 20:
																												case 32:
																													goto IL_071d;
																												case 68:
																													goto IL_072b;
																												case 62:
																												case 85:
																													goto IL_0742;
																												case 80:
																													goto IL_076b;
																												case 8:
																													goto IL_0784;
																												case 15:
																												case 38:
																													goto IL_078f;
																												case 141:
																													goto IL_07cf;
																												case 78:
																													goto IL_07e3;
																												case 147:
																													goto IL_07f6;
																												case 61:
																													goto IL_0804;
																												case 1:
																												case 43:
																													goto IL_0812;
																												case 116:
																													goto IL_082b;
																												case 42:
																													goto IL_0839;
																												case 107:
																													goto IL_0847;
																												case 34:
																												case 60:
																													goto IL_0857;
																												case 63:
																													goto IL_0875;
																												case 28:
																													goto IL_0883;
																												case 7:
																												case 9:
																												case 16:
																												case 21:
																												case 22:
																												case 29:
																												case 33:
																												case 39:
																												case 44:
																												case 46:
																												case 48:
																												case 52:
																												case 56:
																												case 57:
																												case 66:
																												case 67:
																												case 77:
																												case 89:
																												case 101:
																												case 102:
																												case 110:
																												case 112:
																												case 121:
																												case 123:
																												case 127:
																												case 139:
																												case 145:
																													goto end_IL_0285;
																												case 13:
																												case 19:
																												case 26:
																												case 35:
																												case 41:
																												case 49:
																												case 75:
																												case 84:
																												case 86:
																												case 95:
																												case 96:
																												case 105:
																												case 113:
																												case 119:
																												case 129:
																												case 132:
																												case 134:
																												case 144:
																													goto end_IL_0308;
																												case 14:
																													goto end_IL_08a6;
																												case 138:
																													goto end_IL_08b9;
																												case 135:
																													goto end_IL_08c3;
																												case 31:
																													goto end_IL_08ce;
																												case 82:
																												case 91:
																													goto end_IL_08de;
																												case 125:
																													goto end_IL_08ee;
																												case 51:
																													goto end_IL_08fe;
																												case 104:
																													goto end_IL_090e;
																												case 142:
																													goto end_IL_091e;
																												case 143:
																													goto end_IL_0929;
																												case 10:
																												case 17:
																													goto IL_094d;
																												}
																												continue;
																												end_IL_0285:
																												break;
																											}
																											break;
																										}
																										goto IL_03ab;
																										IL_03ab:
																										if (15 <= b)
																										{
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0313;
																								IL_057d:
																								num5 -= 2;
																								goto end_IL_0308;
																								IL_0313:
																								if (14 <= b)
																								{
																									goto IL_031e;
																								}
																								goto IL_0343;
																								IL_031e:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								num = 132;
																								goto end_IL_0308;
																								IL_0343:
																								if (13 < b)
																								{
																									break;
																								}
																								goto IL_050d;
																								IL_050d:
																								if (13 > b)
																								{
																									break;
																								}
																								goto IL_051b;
																								IL_051b:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_057d;
																							}
																							break;
																						}
																						goto IL_0356;
																						IL_047b:
																						array[num5 - 2] = 0;
																						goto IL_048f;
																						IL_0356:
																						if (12 > b)
																						{
																							goto IL_0364;
																						}
																						goto IL_043b;
																						IL_0364:
																						if (10 >= b)
																						{
																							goto IL_036f;
																						}
																						goto IL_037f;
																						IL_036f:
																						if (10 <= b)
																						{
																							goto IL_03be;
																						}
																						goto IL_041a;
																						IL_03be:
																						array[num5] = 0;
																						goto IL_03cc;
																						IL_03cc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03ef;
																						IL_03ef:
																						array2[num5] = null;
																						goto IL_03f9;
																						IL_03f9:
																						num5++;
																						goto IL_0407;
																						IL_0407:
																						ptr2 += 8;
																						goto end_IL_0308;
																						IL_041a:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0428;
																						IL_0428:
																						if (9 <= b)
																						{
																							goto end_IL_0308;
																						}
																						break;
																						IL_037f:
																						if (11 < b)
																						{
																							num = 44;
																							break;
																						}
																						goto IL_0398;
																						IL_048f:
																						num5--;
																						goto end_IL_0308;
																						IL_0398:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_04a2;
																						IL_04a2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_04e6;
																						IL_04e6:
																						array[num5 - 2] = 0;
																						goto IL_04fa;
																						IL_04fa:
																						num5--;
																						goto end_IL_0308;
																						IL_043b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_047b;
																					}
																					break;
																				}
																				goto IL_0590;
																				IL_0847:
																				ptr2 += 8;
																				goto end_IL_0308;
																				IL_0590:
																				if (8 <= b)
																				{
																					goto IL_059b;
																				}
																				goto IL_05b3;
																				IL_059b:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0308;
																				IL_05b3:
																				if (4 < b)
																				{
																					goto IL_05c1;
																				}
																				num = 146;
																				goto IL_0704;
																				IL_05c1:
																				if (6 < b)
																				{
																					num = 109;
																					goto IL_05d5;
																				}
																				goto IL_063b;
																				IL_0875:
																				ptr2 += 8;
																				goto IL_0883;
																				IL_05d5:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_05e3;
																				IL_05e3:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05f1;
																				IL_05f1:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_061a;
																				IL_061a:
																				ptr2 += 8;
																				goto IL_0628;
																				IL_0628:
																				num5--;
																				goto end_IL_0308;
																				IL_063b:
																				if (6 > b)
																				{
																					goto IL_0646;
																				}
																				goto IL_06a9;
																				IL_0646:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0654;
																				IL_0654:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0662;
																				IL_0662:
																				array[num5] = 5;
																				goto IL_0670;
																				IL_0670:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0688;
																				IL_0688:
																				num5++;
																				goto IL_0696;
																				IL_0696:
																				ptr2 += 8;
																				goto end_IL_0308;
																				IL_06a9:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06e8;
																				IL_06e8:
																				num5 -= 3;
																				goto end_IL_0308;
																				IL_0857:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_0875;
																				IL_0704:
																				if (4 > b)
																				{
																					goto IL_0712;
																				}
																				goto IL_0857;
																				IL_0712:
																				if (2 < b)
																				{
																					goto IL_071d;
																				}
																				goto IL_0784;
																				IL_071d:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_072b;
																				IL_072b:
																				if (3 > b)
																				{
																					break;
																				}
																				num = 85;
																				goto IL_0742;
																				IL_0883:
																				num5--;
																				goto end_IL_0308;
																				IL_0742:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_076b;
																				IL_076b:
																				array[num5 - 1] = 5;
																				goto end_IL_0308;
																				IL_0784:
																				if (2 <= b)
																				{
																					goto IL_078f;
																				}
																				goto IL_07f6;
																				IL_078f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07cf;
																				IL_07cf:
																				array[num5 - 2] = 0;
																				goto IL_07e3;
																				IL_07e3:
																				num5--;
																				goto end_IL_0308;
																				IL_07f6:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0804;
																				IL_0804:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0812;
																				IL_0812:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_082b;
																				IL_082b:
																				array[num5] = 0;
																				goto IL_0839;
																				IL_0839:
																				num5++;
																				goto IL_0847;
																			}
																			break;
																			IL_02d8:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0308;
																	continue;
																	end_IL_02e8:
																	break;
																}
																continue;
																end_IL_02f8:
																break;
															}
															continue;
															end_IL_0308:
															break;
														}
														continue;
													}
													goto IL_094d;
													IL_094d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08a6:
													break;
												}
												continue;
												end_IL_08b9:
												break;
											}
											continue;
											end_IL_08c3:
											break;
										}
										continue;
										end_IL_08ce:
										break;
									}
									continue;
									end_IL_08de:
									break;
								}
								continue;
								end_IL_08ee:
								break;
							}
							continue;
							end_IL_08fe:
							break;
						}
						continue;
						end_IL_090e:
						break;
					}
					continue;
					end_IL_091e:
					break;
				}
				continue;
				end_IL_0929:
				break;
			}
		}
	}

	private unsafe static int smethod_12(int int_1)
	{
		int num = 80;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								num = 37;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetObjectParamInternalST.FullyQualifiedNameUnknownWrapper);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_032c:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			if (7 < b)
																			{
																				while (true)
																				{
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_02ef:
																							if (11 <= b)
																							{
																								while (true)
																								{
																									IL_02d9:
																									array[num5 - 2] = 0;
																									while (true)
																									{
																										IL_0283:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)DXNNCMSASSEMBLYDEPLOYMENTFLAGBEFOREAPPLICATIONSTARTUP[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																										while (true)
																										{
																											IL_026a:
																											num5--;
																											num = 146;
																											while (true)
																											{
																												if (num != 146)
																												{
																													if (num != 1127)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 133:
																														goto IL_026a;
																													case 99:
																														goto IL_0283;
																													case 31:
																													case 117:
																														goto IL_02d9;
																													case 85:
																														goto IL_02ef;
																													case 104:
																														goto end_IL_02ef;
																													case 5:
																														goto end_IL_02ff;
																													case 39:
																														goto end_IL_030f;
																													case 76:
																														goto IL_032c;
																													case 109:
																														goto end_IL_032c;
																													case 74:
																													case 116:
																														goto end_IL_033c;
																													case 36:
																														goto IL_0357;
																													case 15:
																														goto IL_0362;
																													case 16:
																													case 47:
																														goto IL_0375;
																													case 75:
																														goto IL_03b5;
																													case 83:
																														goto IL_03ce;
																													case 70:
																														goto IL_03d9;
																													case 91:
																														goto end_IL_0257;
																													case 12:
																													case 25:
																														goto IL_03f7;
																													case 18:
																														goto IL_0405;
																													case 20:
																													case 41:
																														goto IL_0413;
																													case 6:
																													case 51:
																														goto IL_043b;
																													case 3:
																														goto IL_049d;
																													case 88:
																													case 93:
																														goto IL_04b0;
																													case 30:
																														goto IL_04bb;
																													case 14:
																													case 38:
																														goto IL_04c6;
																													case 34:
																														goto IL_04e2;
																													case 98:
																														goto IL_04f5;
																													case 11:
																														goto IL_0503;
																													case 101:
																														goto IL_0516;
																													case 17:
																														goto IL_0524;
																													case 9:
																														goto IL_0532;
																													case 106:
																														goto IL_0542;
																													case 29:
																													case 113:
																														goto IL_0555;
																													case 63:
																														goto IL_056e;
																													case 96:
																													case 114:
																														goto IL_0581;
																													case 94:
																														goto IL_058f;
																													case 67:
																													case 72:
																														goto IL_059a;
																													case 58:
																														goto IL_05a8;
																													case 19:
																													case 61:
																														goto IL_05bb;
																													case 65:
																														goto IL_05c9;
																													case 50:
																														goto IL_05ec;
																													case 78:
																														goto IL_05f6;
																													case 40:
																														goto IL_0604;
																													case 118:
																														goto IL_0617;
																													case 120:
																														goto IL_062a;
																													case 60:
																													case 115:
																														goto IL_0638;
																													case 1:
																														goto IL_0678;
																													case 26:
																														goto IL_068c;
																													case 122:
																														goto IL_06a8;
																													case 107:
																														goto IL_06b6;
																													case 35:
																													case 97:
																														goto IL_06c4;
																													case 131:
																														goto IL_06f2;
																													case 68:
																														goto IL_0700;
																													case 27:
																													case 132:
																														goto IL_070e;
																													case 13:
																														goto IL_074e;
																													case 21:
																														goto IL_0762;
																													case 134:
																														goto IL_0775;
																													case 24:
																													case 135:
																														goto IL_0785;
																													case 136:
																														goto IL_079d;
																													case 105:
																														goto IL_07ab;
																													case 137:
																														goto IL_07bb;
																													case 55:
																														goto IL_07c9;
																													case 121:
																													case 138:
																														goto IL_07d9;
																													case 139:
																														goto IL_07e9;
																													case 92:
																														goto IL_0800;
																													case 2:
																													case 4:
																													case 23:
																													case 43:
																													case 54:
																													case 56:
																													case 57:
																													case 59:
																													case 62:
																													case 66:
																													case 69:
																													case 73:
																													case 77:
																													case 82:
																													case 84:
																													case 87:
																													case 89:
																													case 90:
																													case 95:
																													case 100:
																													case 103:
																													case 110:
																													case 111:
																													case 119:
																													case 123:
																													case 124:
																													case 126:
																													case 129:
																														goto end_IL_031c;
																													case 0:
																													case 7:
																													case 10:
																													case 28:
																													case 33:
																													case 42:
																													case 44:
																													case 45:
																													case 46:
																													case 49:
																													case 52:
																													case 53:
																													case 64:
																													case 81:
																													case 86:
																													case 102:
																													case 125:
																														goto end_IL_034c;
																													case 8:
																														goto end_IL_0833;
																													case 128:
																														goto end_IL_0846;
																													case 37:
																														goto end_IL_0850;
																													case 71:
																														goto end_IL_085b;
																													case 112:
																													case 130:
																														goto end_IL_0870;
																													case 108:
																														goto end_IL_0889;
																													case 32:
																													case 48:
																														goto end_IL_0899;
																													case 79:
																														goto end_IL_08a9;
																													case 80:
																														goto end_IL_08b9;
																													case 22:
																													case 127:
																														goto IL_08d4;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto end_IL_034c;
																												continue;
																												end_IL_0257:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_03ec;
																							}
																							goto IL_03ce;
																							IL_049d:
																							num5 -= 2;
																							goto end_IL_034c;
																							IL_03ce:
																							if (9 < b)
																							{
																								goto IL_03d9;
																							}
																							goto IL_03ec;
																							IL_03d9:
																							if (10 < b)
																							{
																								goto end_IL_031c;
																							}
																							goto IL_062a;
																							IL_062a:
																							if (10 > b)
																							{
																								goto end_IL_031c;
																							}
																							goto IL_0638;
																							IL_0638:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0678;
																							IL_0678:
																							array[num5 - 2] = 0;
																							goto IL_068c;
																							IL_068c:
																							num5--;
																							num = 86;
																							goto end_IL_034c;
																							IL_03ec:
																							if (9 > b)
																							{
																								goto IL_03f7;
																							}
																							goto IL_043b;
																							IL_03f7:
																							if (8 < b)
																							{
																								goto end_IL_031c;
																							}
																							goto IL_0405;
																							IL_0405:
																							if (8 > b)
																							{
																								goto end_IL_031c;
																							}
																							goto IL_0413;
																							IL_0413:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0542;
																							IL_0542:
																							array[num5] = 0;
																							goto IL_07bb;
																							IL_07bb:
																							num5++;
																							goto IL_07c9;
																							IL_07c9:
																							ptr2 += 8;
																							goto end_IL_034c;
																							IL_043b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_049d;
																							continue;
																							end_IL_02ef:
																							break;
																						}
																						continue;
																					}
																					goto IL_04b0;
																					IL_0503:
																					if (14 <= b)
																					{
																					}
																					goto end_IL_031c;
																					IL_04b0:
																					if (13 >= b)
																					{
																						goto IL_04bb;
																					}
																					goto IL_04f5;
																					IL_04bb:
																					if (13 <= b)
																					{
																						goto IL_04c6;
																					}
																					goto IL_04e2;
																					IL_04c6:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_034c;
																					IL_04e2:
																					if (12 < b)
																					{
																						goto end_IL_031c;
																					}
																					goto IL_0775;
																					IL_0775:
																					if (12 > b)
																					{
																						goto end_IL_031c;
																					}
																					goto IL_07d9;
																					IL_07d9:
																					num5--;
																					goto end_IL_034c;
																					IL_04f5:
																					if (14 < b)
																					{
																						goto end_IL_031c;
																					}
																					goto IL_0503;
																					continue;
																					end_IL_02ff:
																					break;
																				}
																				continue;
																			}
																			goto IL_0357;
																			IL_0617:
																			num5--;
																			goto end_IL_034c;
																			IL_0357:
																			if (7 > b)
																			{
																				goto IL_0362;
																			}
																			goto IL_0375;
																			IL_0362:
																			if (3 >= b)
																			{
																				goto IL_0516;
																			}
																			goto IL_0581;
																			IL_0581:
																			if (5 >= b)
																			{
																				goto IL_058f;
																			}
																			goto IL_06f2;
																			IL_058f:
																			if (5 > b)
																			{
																				goto IL_059a;
																			}
																			goto IL_05bb;
																			IL_059a:
																			if (4 < b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_05a8;
																			IL_05a8:
																			if (4 <= b)
																			{
																				goto end_IL_034c;
																			}
																			goto end_IL_031c;
																			IL_05bb:
																			array[num5] = 0;
																			goto IL_05c9;
																			IL_05c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05ec;
																			IL_05ec:
																			array2[num5] = null;
																			goto IL_05f6;
																			IL_05f6:
																			num5++;
																			goto IL_0604;
																			IL_0604:
																			ptr2 += 8;
																			goto end_IL_034c;
																			IL_06f2:
																			if (6 < b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_0700;
																			IL_0700:
																			if (6 > b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_070e;
																			IL_070e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_074e;
																			IL_074e:
																			array[num5 - 2] = 0;
																			goto IL_0762;
																			IL_0762:
																			num5--;
																			goto end_IL_034c;
																			IL_0516:
																			if (3 > b)
																			{
																				goto IL_0524;
																			}
																			goto IL_0785;
																			IL_0524:
																			if (1 >= b)
																			{
																				goto IL_0532;
																			}
																			goto IL_06a8;
																			IL_0532:
																			if (1 > b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_0555;
																			IL_0555:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_056e;
																			IL_056e:
																			array[num5] = 0;
																			goto IL_079d;
																			IL_079d:
																			num5++;
																			goto IL_07ab;
																			IL_07ab:
																			ptr2 += 8;
																			goto end_IL_034c;
																			IL_06a8:
																			if (2 < b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_06b6;
																			IL_06b6:
																			if (2 > b)
																			{
																				goto end_IL_031c;
																			}
																			goto IL_06c4;
																			IL_06c4:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07e9;
																			IL_07e9:
																			ptr2 += 8;
																			num = 92;
																			goto IL_0800;
																			IL_0800:
																			num5--;
																			goto end_IL_034c;
																			IL_0785:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_034c;
																			IL_0375:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03b5;
																			IL_03b5:
																			array[num5 - 2] = 0;
																			goto IL_0617;
																			continue;
																			end_IL_030f:
																			break;
																		}
																		continue;
																		end_IL_031c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_034c;
																continue;
																end_IL_032c:
																break;
															}
															continue;
															end_IL_033c:
															break;
														}
														continue;
														end_IL_034c:
														break;
													}
													continue;
												}
												goto IL_08d4;
												IL_08d4:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0833:
												break;
											}
											continue;
											end_IL_0846:
											break;
										}
										continue;
										end_IL_0850:
										break;
									}
									continue;
									end_IL_085b:
									break;
								}
								continue;
								end_IL_0870:
								break;
							}
							continue;
							end_IL_0889:
							break;
						}
						continue;
						end_IL_0899:
						break;
					}
					continue;
					end_IL_08a9:
					break;
				}
				continue;
				end_IL_08b9:
				break;
			}
		}
	}

	private unsafe static int smethod_13(int int_1)
	{
		int num = 74;
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsExplicitLayoutTryGetBuffer.IStoreBindingResultDeclaredProperties);
										num = 113;
										while (true)
										{
											if (num != 113)
											{
												if (num != 1094)
												{
													goto IL_037f;
												}
												switch (num)
												{
												case 88:
													goto end_IL_01d3;
												case 72:
													goto end_IL_01e6;
												case 95:
													goto end_IL_01fa;
												case 83:
												case 102:
													goto end_IL_020f;
												case 60:
													goto end_IL_021f;
												case 0:
												case 4:
													goto end_IL_022f;
												case 73:
													goto end_IL_023f;
												case 74:
													goto end_IL_024f;
												case 1:
												case 2:
												case 8:
												case 20:
												case 25:
												case 42:
												case 50:
												case 53:
												case 58:
												case 65:
												case 75:
												case 96:
												case 104:
													goto IL_027b;
												case 71:
												case 85:
													goto IL_028b;
												case 36:
													goto IL_0294;
												case 44:
													goto IL_02ab;
												case 45:
													goto IL_02c4;
												case 40:
													goto IL_02d2;
												case 41:
													goto IL_02e0;
												case 35:
													goto IL_02ee;
												case 61:
												case 82:
													goto IL_02f9;
												case 51:
												case 77:
													goto IL_0304;
												case 38:
													goto IL_0312;
												case 66:
													goto IL_0325;
												case 48:
												case 69:
													goto IL_0333;
												case 29:
													goto IL_034b;
												case 81:
												case 99:
													goto IL_0356;
												case 78:
													goto IL_037f;
												case 26:
													goto IL_038d;
												case 100:
													goto IL_03a0;
												case 68:
													goto IL_03ae;
												case 9:
												case 89:
													goto IL_03bc;
												case 17:
													goto IL_03d5;
												case 67:
													goto IL_03e3;
												case 90:
													goto IL_03fa;
												case 79:
												case 98:
													goto IL_040d;
												case 49:
													goto IL_041b;
												case 19:
													goto IL_043e;
												case 23:
													goto IL_0448;
												case 97:
													goto IL_0456;
												case 18:
												case 54:
													goto IL_0469;
												case 16:
													goto IL_0477;
												case 28:
												case 52:
													goto IL_0485;
												case 10:
													goto IL_0490;
												case 24:
													goto IL_049e;
												case 12:
												case 76:
													goto IL_04ac;
												case 57:
													goto IL_04cf;
												case 13:
													goto IL_04dd;
												case 59:
													goto IL_04eb;
												case 56:
													goto IL_04fe;
												case 14:
												case 87:
													goto IL_050c;
												case 37:
													goto IL_0555;
												case 94:
													goto IL_0569;
												case 55:
												case 103:
													goto IL_057c;
												case 105:
													goto IL_05de;
												case 93:
													goto IL_05f1;
												case 31:
													goto IL_05fc;
												case 7:
												case 80:
													goto IL_0607;
												case 106:
													goto IL_062c;
												case 70:
													goto IL_0637;
												case 3:
												case 5:
												case 6:
												case 11:
												case 15:
												case 21:
												case 22:
												case 27:
												case 30:
												case 32:
												case 33:
												case 34:
												case 39:
												case 43:
												case 46:
												case 62:
												case 63:
												case 64:
												case 84:
												case 86:
												case 92:
												case 101:
													goto IL_0642;
												case 47:
												case 91:
													goto IL_065a;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_027b;
											IL_0607:
											byte* num4 = ptr2;
											num5 = 1;
											ptr2 = num4 + -200;
											num = 25;
											goto IL_027b;
											IL_0637:
											if (10 > b)
											{
											}
											goto IL_0642;
											IL_062c:
											if (10 >= b)
											{
												goto IL_0637;
											}
											goto IL_0642;
											IL_027b:
											if (num5 != 1)
											{
												goto IL_028b;
											}
											goto IL_065a;
											IL_065a:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											IL_028b:
											b = *ptr2;
											goto IL_0294;
											IL_0294:
											ptr2++;
											num = 44;
											goto IL_02ab;
											IL_02ab:
											if (b >= 1)
											{
												goto IL_02c4;
											}
											num = 86;
											goto IL_0642;
											IL_0642:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_027b;
											IL_02c4:
											if (b <= 10)
											{
												goto IL_02d2;
											}
											goto IL_0642;
											IL_02d2:
											if (5 >= b)
											{
												goto IL_02e0;
											}
											goto IL_0469;
											IL_02e0:
											if (5 > b)
											{
												goto IL_02ee;
											}
											goto IL_040d;
											IL_02ee:
											if (2 < b)
											{
												goto IL_02f9;
											}
											goto IL_034b;
											IL_02f9:
											if (3 < b)
											{
												goto IL_0304;
											}
											goto IL_0325;
											IL_0304:
											if (4 >= b)
											{
												goto IL_0312;
											}
											goto IL_0642;
											IL_0312:
											if (4 <= b)
											{
												goto IL_027b;
											}
											goto IL_0642;
											IL_0325:
											if (3 <= b)
											{
												goto IL_0333;
											}
											goto IL_0642;
											IL_0333:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_027b;
											IL_034b:
											if (2 <= b)
											{
												goto IL_0356;
											}
											goto IL_03a0;
											IL_0356:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											goto IL_037f;
											IL_037f:
											ptr2 += 8;
											goto IL_038d;
											IL_038d:
											num6--;
											goto IL_027b;
											IL_03a0:
											if (1 >= b)
											{
												goto IL_03ae;
											}
											goto IL_0642;
											IL_03ae:
											if (1 <= b)
											{
												goto IL_03bc;
											}
											goto IL_0642;
											IL_03bc:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
											goto IL_03d5;
											IL_03d5:
											array[num6] = 0;
											goto IL_03e3;
											IL_03e3:
											num6++;
											num = 90;
											goto IL_03fa;
											IL_03fa:
											ptr2 += 8;
											goto IL_027b;
											IL_040d:
											array[num6] = 0;
											goto IL_041b;
											IL_041b:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
											goto IL_043e;
											IL_043e:
											array2[num6] = null;
											goto IL_0448;
											IL_0448:
											num6++;
											goto IL_0456;
											IL_0456:
											ptr2 += 8;
											goto IL_027b;
											IL_0469:
											if (8 >= b)
											{
												goto IL_0477;
											}
											goto IL_05f1;
											IL_0477:
											if (8 > b)
											{
												goto IL_0485;
											}
											goto IL_057c;
											IL_0485:
											if (6 < b)
											{
												goto IL_0490;
											}
											goto IL_04fe;
											IL_0490:
											if (7 >= b)
											{
												goto IL_049e;
											}
											goto IL_0642;
											IL_049e:
											if (7 <= b)
											{
												goto IL_04ac;
											}
											goto IL_0642;
											IL_04ac:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
											goto IL_04cf;
											IL_04cf:
											array[num6] = 0;
											goto IL_04dd;
											IL_04dd:
											num6++;
											goto IL_04eb;
											IL_04eb:
											ptr2 += 8;
											goto IL_027b;
											IL_04fe:
											if (6 <= b)
											{
												goto IL_050c;
											}
											goto IL_0642;
											IL_050c:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
											num = 37;
											goto IL_0555;
											IL_0555:
											array[num6 - 2] = 0;
											goto IL_0569;
											IL_0569:
											num6--;
											goto IL_027b;
											IL_057c:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_05de;
											IL_05de:
											num6 -= 2;
											goto IL_027b;
											IL_05f1:
											if (9 >= b)
											{
												goto IL_05fc;
											}
											goto IL_062c;
											IL_05fc:
											if (9 <= b)
											{
												goto IL_0607;
											}
											goto IL_0642;
											continue;
											end_IL_01d3:
											break;
										}
										continue;
										end_IL_01e6:
										break;
									}
									continue;
									end_IL_01fa:
									break;
								}
								continue;
								end_IL_020f:
								break;
							}
							continue;
							end_IL_021f:
							break;
						}
						continue;
						end_IL_022f:
						break;
					}
					continue;
					end_IL_023f:
					break;
				}
				continue;
				end_IL_024f:
				break;
			}
		}
	}

	private static Task IResourceReadergetCurrentCultureIgnoreCase(string string_0, RoomConfig roomConfig_0)
	{
		return smethod_1(string_0, roomConfig_0);
	}

	private static GorillaComputer ToByteArrayBeep()
	{
		return GorillaComputer.instance;
	}

	private static GorillaTagger ReflectionExtensionsNtlmAuthenticationSid()
	{
		return GorillaTagger.Instance;
	}

	private static float StringMakerCallerFilePathAttribute(Vector3 vector3_0, Vector3 vector3_1)
	{
		return Vector3.Distance(vector3_0, vector3_1);
	}

	private static double SpecifyKindDateTimeConstantAttribute(double double_1)
	{
		return Math.Sin(double_1);
	}

	private static NetworkSystem getConditionStringWindowsDeviceClaim()
	{
		return NetworkSystem.Instance;
	}

	private static PhotonNetworkController VolatileBoolHash()
	{
		return PhotonNetworkController.Instance;
	}

	private static int AuditRuleTypeVirtual(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static bool IsolatedStorageFileEnumeratorGetHashToMatch(GorillaComputer gorillaComputer_0, string string_0)
	{
		return gorillaComputer_0.CheckAutoBanListForName(string_0);
	}

	private static string MultiDomainSequentialLayout()
	{
		return smethod_2();
	}

	private static int VoidIActivator(int int_1, int int_2)
	{
		return UnityEngine.Random.Range(int_1, int_2);
	}

	private static double KeyDatagetContext(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private static void GetSequencePointsBadSignature(Dictionary<object, object> dictionary_0, object object_0, object object_1)
	{
		dictionary_0.Add(object_0, object_1);
	}

	private static string getModuleIsInteropXmlElement(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private static int AddDaysLazyCancellation(string string_0)
	{
		return string_0.Length;
	}

	private static GorillaTagger WasUsedSetRaiseMethod()
	{
		return GorillaTagger.Instance;
	}

	private static bool SubstringEqualsYield()
	{
		return bool_0;
	}
}
