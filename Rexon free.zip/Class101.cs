using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Monke Idol Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns monke idols.", false, 13, ModType.const_0, false)]
internal class Class101 : Class93
{
	private static float float_0;

	private static bool bool_0;

	private static float float_1;

	private static float float_2;

	private static double double_1;

	private static bool bool_1;

	private static IntPtr[] OpenPunctuationSetExceptions;

	protected override string ModId
	{
		get
		{
			object obj = "l";
			object obj2 = obj;
			obj = "M";
			object obj3 = obj;
			obj = "I";
			object obj4 = obj;
			obj = "o";
			object obj5 = obj;
			obj = "G";
			object obj6 = obj;
			obj = "d";
			object obj7 = obj;
			obj = "k";
			object obj8 = obj;
			obj = "e";
			object obj9 = obj;
			obj = "u";
			object obj10 = obj;
			obj = "n";
			object obj11 = obj;
			obj = new string[12];
			object obj12 = obj;
			object obj13 = obj3;
			((string[])obj12)[0] = (string)obj13;
			obj12 = obj;
			obj13 = obj5;
			((string[])obj12)[1] = (string)obj13;
			obj12 = obj;
			obj13 = obj11;
			((string[])obj12)[2] = (string)obj13;
			obj12 = obj;
			obj13 = obj8;
			((string[])obj12)[3] = (string)obj13;
			obj12 = obj;
			obj13 = obj9;
			((string[])obj12)[4] = (string)obj13;
			obj12 = obj;
			obj13 = obj4;
			((string[])obj12)[5] = (string)obj13;
			obj12 = obj;
			obj13 = obj7;
			((string[])obj12)[6] = (string)obj13;
			obj12 = obj;
			obj13 = obj5;
			((string[])obj12)[7] = (string)obj13;
			obj12 = obj;
			obj13 = obj2;
			((string[])obj12)[8] = (string)obj13;
			obj12 = obj;
			obj13 = obj6;
			((string[])obj12)[9] = (string)obj13;
			obj12 = obj;
			obj13 = obj10;
			((string[])obj12)[10] = (string)obj13;
			obj12 = obj;
			obj13 = obj11;
			((string[])obj12)[11] = (string)obj13;
			string text = string.Concat((string[])obj);
			obj = text;
			object obj14 = obj;
			obj = obj14;
			return (string)obj;
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_0377, IL_038a, IL_03a3, IL_03b9, IL_03fb, IL_040b, IL_0418, IL_0428, IL_0438, IL_0448, IL_0458, IL_0468, IL_0473, IL_047e, IL_048c, IL_049f, IL_04aa, IL_04bd, IL_04cb, IL_04d9, IL_04e2, IL_0544, IL_0557, IL_0565, IL_0573, IL_0581, IL_05c1, IL_05d5, IL_05f1, IL_05ff, IL_063f, IL_0653, IL_066f, IL_067d, IL_0688, IL_0696, IL_06a9, IL_06e9, IL_06fd, IL_0710, IL_071e, IL_072c, IL_073a, IL_0751, IL_0774, IL_077e, IL_078c, IL_079f, IL_07ad, IL_07d6, IL_07e4, IL_07f7, IL_0837, IL_084b, IL_085e, IL_087b, IL_08ba, IL_08cd, IL_08db, IL_08e9, IL_08f7, IL_0902, IL_090d, IL_0936, IL_094f, IL_095d, IL_096b, IL_0979, IL_0991, IL_09b8, IL_09dc, IL_09f4, IL_0a10, IL_0a1e, IL_0a29, IL_0a3c, IL_0a4a, IL_0a58, IL_0a75, IL_0ac4, IL_0ace, IL_0afb, IL_0b0f, IL_0b1d, IL_0b30, IL_0b4e, IL_0b5c, IL_0b6f, IL_0b7d, IL_0b95, IL_0ba3, IL_0bb6, IL_0bc4, IL_0bcf, IL_0be8, IL_0bf6, IL_0c04, IL_0c17, IL_0c22, IL_0c30, IL_0c3e, IL_0c52, IL_0c8a, IL_0c9d, IL_0cab, IL_0cb4, IL_0cf2, IL_0d05, IL_0d10, IL_0d1b, IL_0d26, IL_0d3f, IL_0d4a, IL_0d5f, IL_0d78, IL_0d86, IL_0d94, IL_0da2, IL_0db5, IL_0dbf, IL_0dca, IL_0dda, IL_0dea, IL_0dfa, IL_0e0a, IL_0e1a, IL_0e2a, IL_0e3a, IL_0e4a, IL_0e6e are reachable both inside and outside the pinned region starting at IL_0e68. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 180;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef5 = default(int);
				ref int reference = ref __rxRef5;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e4a:
						num2 = 1;
						num = 151;
						while (true)
						{
							IL_0e3a:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e2a:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e1a:
									array2 = new byte[4];
									while (true)
									{
										IL_0e0a:
										array3 = new object[4];
										while (true)
										{
											IL_0dfa:
											array4 = new int[4];
											while (true)
											{
												IL_0dea:
												array5 = new int[6];
												while (true)
												{
													IL_0dda:
													array6 = new long[4];
													while (true)
													{
														IL_0dca:
														array7 = new object[10];
														while (true)
														{
															IL_0dbf:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddOvfUnStoreLocation.toExclusiveLoadHint);
															while (true)
															{
																IL_0db5:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0468:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0458:
																				ptr2++;
																				while (true)
																				{
																					IL_0448:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0428:
																								if (11 >= b)
																								{
																									while (true)
																									{
																										IL_0418:
																										if (11 > b)
																										{
																											while (true)
																											{
																												IL_040b:
																												if (5 >= b)
																												{
																													while (true)
																													{
																														IL_03fb:
																														if (5 <= b)
																														{
																															while (true)
																															{
																																IL_03b9:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																while (true)
																																{
																																	IL_03a3:
																																	array2[num6 - 2] = 0;
																																	while (true)
																																	{
																																		IL_038a:
																																		num6--;
																																		num = 218;
																																		while (num != 218)
																																		{
																																			if (num != 1199)
																																			{
																																				goto IL_0a3c;
																																			}
																																			switch (num)
																																			{
																																			case 180:
																																				break;
																																			default:
																																				continue;
																																			case 140:
																																				goto IL_038a;
																																			case 188:
																																				goto IL_03a3;
																																			case 73:
																																			case 153:
																																				goto IL_03b9;
																																			case 85:
																																				goto IL_03fb;
																																			case 111:
																																				goto IL_040b;
																																			case 47:
																																				goto IL_0418;
																																			case 156:
																																				goto IL_0428;
																																			case 144:
																																				goto IL_0438;
																																			case 116:
																																				goto IL_0448;
																																			case 31:
																																				goto IL_0458;
																																			case 25:
																																			case 58:
																																				goto IL_0468;
																																			case 76:
																																			case 137:
																																				goto IL_0473;
																																			case 130:
																																				goto IL_047e;
																																			case 113:
																																			case 120:
																																				goto IL_048c;
																																			case 108:
																																			case 129:
																																				goto IL_049f;
																																			case 19:
																																				goto IL_04aa;
																																			case 83:
																																				goto IL_04bd;
																																			case 160:
																																				goto IL_04cb;
																																			case 38:
																																			case 154:
																																				goto IL_04e2;
																																			case 33:
																																				goto IL_0544;
																																			case 52:
																																			case 203:
																																				goto IL_0557;
																																			case 96:
																																			case 169:
																																				goto IL_0565;
																																			case 143:
																																				goto IL_0573;
																																			case 97:
																																			case 112:
																																				goto IL_0581;
																																			case 18:
																																				goto IL_05c1;
																																			case 46:
																																				goto IL_05d5;
																																			case 2:
																																				goto IL_05f1;
																																			case 60:
																																			case 95:
																																				goto IL_05ff;
																																			case 34:
																																				goto IL_063f;
																																			case 90:
																																				goto IL_0653;
																																			case 45:
																																			case 210:
																																				goto IL_066f;
																																			case 134:
																																				goto IL_067d;
																																			case 135:
																																			case 201:
																																				goto IL_0688;
																																			case 70:
																																				goto IL_0696;
																																			case 78:
																																			case 162:
																																				goto IL_06a9;
																																			case 5:
																																				goto IL_06e9;
																																			case 12:
																																				goto IL_06fd;
																																			case 199:
																																				goto IL_0710;
																																			case 123:
																																			case 152:
																																				goto IL_071e;
																																			case 15:
																																				goto IL_072c;
																																			case 9:
																																			case 103:
																																				goto IL_073a;
																																			case 39:
																																				goto IL_0751;
																																			case 150:
																																				goto IL_0774;
																																			case 119:
																																				goto IL_077e;
																																			case 171:
																																				goto IL_078c;
																																			case 69:
																																				goto IL_079f;
																																			case 41:
																																			case 133:
																																				goto IL_07ad;
																																			case 35:
																																				goto IL_07d6;
																																			case 208:
																																				goto IL_07e4;
																																			case 192:
																																			case 211:
																																				goto IL_07f7;
																																			case 28:
																																				goto IL_0837;
																																			case 8:
																																				goto IL_084b;
																																			case 147:
																																			case 183:
																																				goto IL_085e;
																																			case 187:
																																				goto IL_087b;
																																			case 1:
																																				goto IL_08ba;
																																			case 59:
																																				goto IL_08cd;
																																			case 200:
																																				goto IL_08db;
																																			case 190:
																																				goto IL_08e9;
																																			case 6:
																																			case 198:
																																				goto IL_08f7;
																																			case 29:
																																				goto IL_0902;
																																			case 17:
																																			case 23:
																																				goto IL_090d;
																																			case 100:
																																				goto IL_0936;
																																			case 159:
																																				goto IL_095d;
																																			case 55:
																																				goto IL_096b;
																																			case 22:
																																			case 173:
																																				goto IL_0979;
																																			case 49:
																																				goto IL_0991;
																																			case 67:
																																				goto IL_09b8;
																																			case 178:
																																				goto IL_09dc;
																																			case 3:
																																				goto IL_09f4;
																																			case 114:
																																				goto IL_0a10;
																																			case 14:
																																			case 86:
																																				goto IL_0a1e;
																																			case 195:
																																				goto IL_0a29;
																																			case 16:
																																			case 163:
																																				goto IL_0a3c;
																																			case 81:
																																				goto IL_0a4a;
																																			case 110:
																																			case 115:
																																				goto IL_0a58;
																																			case 63:
																																				goto IL_0b0f;
																																			case 132:
																																				goto IL_0b1d;
																																			case 92:
																																			case 170:
																																				goto IL_0b30;
																																			case 174:
																																				goto IL_0b4e;
																																			case 40:
																																				goto IL_0b5c;
																																			case 30:
																																			case 98:
																																				goto IL_0b6f;
																																			case 24:
																																				goto IL_0b7d;
																																			case 177:
																																				goto IL_0b95;
																																			case 0:
																																				goto IL_0ba3;
																																			case 61:
																																				goto IL_0bb6;
																																			case 75:
																																				goto IL_0bc4;
																																			case 13:
																																			case 197:
																																				goto IL_0bcf;
																																			case 50:
																																				goto IL_0be8;
																																			case 189:
																																				goto IL_0bf6;
																																			case 44:
																																				goto IL_0c04;
																																			case 68:
																																				goto IL_0c17;
																																			case 32:
																																			case 136:
																																				goto IL_0c22;
																																			case 91:
																																				goto IL_0c30;
																																			case 42:
																																			case 164:
																																				goto IL_0c3e;
																																			case 20:
																																				goto IL_0c52;
																																			case 181:
																																				goto IL_0c8a;
																																			case 80:
																																				goto IL_0c9d;
																																			case 57:
																																			case 138:
																																				goto IL_0cb4;
																																			case 141:
																																				goto IL_0cf2;
																																			case 89:
																																				goto IL_0d05;
																																			case 53:
																																			case 148:
																																				goto IL_0d10;
																																			case 191:
																																				goto IL_0d1b;
																																			case 26:
																																			case 48:
																																				goto IL_0d26;
																																			case 10:
																																				goto IL_0d3f;
																																			case 66:
																																			case 196:
																																				goto IL_0d4a;
																																			case 11:
																																			case 27:
																																			case 36:
																																			case 37:
																																			case 51:
																																			case 56:
																																			case 62:
																																			case 71:
																																			case 72:
																																			case 99:
																																			case 105:
																																			case 109:
																																			case 117:
																																			case 118:
																																			case 121:
																																			case 122:
																																			case 126:
																																			case 128:
																																			case 131:
																																			case 139:
																																			case 146:
																																			case 149:
																																			case 155:
																																			case 158:
																																			case 161:
																																			case 165:
																																			case 166:
																																			case 175:
																																			case 182:
																																			case 186:
																																			case 204:
																																			case 205:
																																			case 206:
																																				goto end_IL_0438;
																																			case 88:
																																				goto IL_0d78;
																																			case 185:
																																				goto IL_0d86;
																																			case 127:
																																				goto IL_0d94;
																																			case 4:
																																			case 21:
																																			case 43:
																																			case 54:
																																			case 65:
																																			case 74:
																																			case 77:
																																			case 93:
																																			case 101:
																																			case 102:
																																			case 104:
																																			case 106:
																																			case 107:
																																			case 124:
																																			case 145:
																																			case 157:
																																			case 167:
																																			case 168:
																																			case 172:
																																			case 176:
																																			case 184:
																																			case 193:
																																			case 194:
																																			case 207:
																																				goto end_IL_0377;
																																			case 94:
																																				goto IL_0db5;
																																			case 202:
																																				goto IL_0dbf;
																																			case 7:
																																				goto IL_0dca;
																																			case 84:
																																				goto IL_0dda;
																																			case 142:
																																				goto IL_0dea;
																																			case 125:
																																				goto IL_0dfa;
																																			case 87:
																																				goto IL_0e0a;
																																			case 209:
																																				goto IL_0e1a;
																																			case 79:
																																				goto IL_0e2a;
																																			case 151:
																																				goto IL_0e3a;
																																			case 179:
																																				goto IL_0e4a;
																																			case 64:
																																			case 82:
																																				goto IL_0e6e;
																																			}
																																			goto end_IL_0da2;
																																			continue;
																																			end_IL_0377:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_066f;
																														IL_07e4:
																														num6--;
																														break;
																														IL_066f:
																														if (2 >= b)
																														{
																															goto IL_067d;
																														}
																														goto IL_0710;
																														IL_067d:
																														if (2 > b)
																														{
																															goto IL_0688;
																														}
																														goto IL_06a9;
																														IL_0688:
																														if (1 < b)
																														{
																															goto end_IL_0438;
																														}
																														goto IL_0696;
																														IL_0696:
																														if (1 > b)
																														{
																														}
																														goto end_IL_0438;
																														IL_06a9:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_06e9;
																														IL_06e9:
																														array2[num6 - 2] = 0;
																														goto IL_06fd;
																														IL_06fd:
																														num6--;
																														break;
																														IL_0710:
																														if (3 < b)
																														{
																															goto IL_071e;
																														}
																														goto IL_079f;
																														IL_071e:
																														if (4 < b)
																														{
																															goto end_IL_0438;
																														}
																														goto IL_072c;
																														IL_072c:
																														if (4 > b)
																														{
																															goto end_IL_0438;
																														}
																														goto IL_073a;
																														IL_073a:
																														array2[num6] = 0;
																														num = 39;
																														goto IL_0751;
																														IL_0751:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																														goto IL_0774;
																														IL_0774:
																														array3[num6] = null;
																														goto IL_077e;
																														IL_077e:
																														num6++;
																														goto IL_078c;
																														IL_078c:
																														ptr2 += 8;
																														break;
																														IL_079f:
																														if (3 > b)
																														{
																															goto end_IL_0438;
																														}
																														goto IL_07ad;
																														IL_07ad:
																														reference = ref array5[*(int*)(ptr2 + num3)];
																														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_07d6;
																														IL_07d6:
																														ptr2 += 8;
																														goto IL_07e4;
																													}
																													break;
																												}
																												goto IL_0473;
																												IL_04e2:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0544;
																												IL_0473:
																												if (8 >= b)
																												{
																													goto IL_047e;
																												}
																												goto IL_049f;
																												IL_047e:
																												if (8 <= b)
																												{
																													goto IL_048c;
																												}
																												goto IL_0557;
																												IL_048c:
																												num6--;
																												break;
																												IL_0557:
																												if (6 < b)
																												{
																													goto IL_0565;
																												}
																												goto IL_05f1;
																												IL_0565:
																												if (7 < b)
																												{
																													goto end_IL_0438;
																												}
																												goto IL_0573;
																												IL_0573:
																												if (7 > b)
																												{
																													goto end_IL_0438;
																												}
																												goto IL_0581;
																												IL_0581:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_05c1;
																												IL_05c1:
																												array2[num6 - 2] = 0;
																												goto IL_05d5;
																												IL_05d5:
																												num6--;
																												num = 101;
																												break;
																												IL_05f1:
																												if (6 > b)
																												{
																													goto end_IL_0438;
																												}
																												goto IL_05ff;
																												IL_05ff:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_063f;
																												IL_063f:
																												array2[num6 - 2] = 0;
																												goto IL_0653;
																												IL_0653:
																												num6--;
																												num = 106;
																												break;
																												IL_049f:
																												if (9 >= b)
																												{
																													goto IL_04aa;
																												}
																												goto IL_04bd;
																												IL_04aa:
																												if (9 > b)
																												{
																													goto end_IL_0438;
																												}
																												goto IL_07f7;
																												IL_07f7:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0837;
																												IL_0837:
																												array2[num6 - 2] = 0;
																												goto IL_084b;
																												IL_084b:
																												num6--;
																												break;
																												IL_04bd:
																												if (10 < b)
																												{
																													goto end_IL_0438;
																												}
																												goto IL_04cb;
																												IL_04cb:
																												if (10 > b)
																												{
																													goto end_IL_0438;
																												}
																												num = 154;
																												goto IL_04e2;
																												IL_0544:
																												num6 -= 2;
																												break;
																											}
																											break;
																										}
																										goto IL_085e;
																										IL_08ba:
																										ptr2 += 8;
																										break;
																										IL_085e:
																										array2[num6 - 1] = 0;
																										num = 187;
																										goto IL_087b;
																										IL_087b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)OpenPunctuationSetExceptions[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_08ba;
																									}
																									break;
																								}
																								goto IL_08cd;
																								IL_0d05:
																								if (21 < b)
																								{
																									goto IL_0d10;
																								}
																								goto IL_0d3f;
																								IL_08cd:
																								if (17 >= b)
																								{
																									goto IL_08db;
																								}
																								goto IL_0bb6;
																								IL_08db:
																								if (17 > b)
																								{
																									goto IL_08e9;
																								}
																								goto IL_0b6f;
																								IL_08e9:
																								if (14 < b)
																								{
																									goto IL_08f7;
																								}
																								goto IL_0a10;
																								IL_08f7:
																								if (15 >= b)
																								{
																									goto IL_0902;
																								}
																								goto IL_095d;
																								IL_0902:
																								if (15 > b)
																								{
																									num = 205;
																									goto end_IL_0438;
																								}
																								goto IL_090d;
																								IL_090d:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_0936;
																								IL_0936:
																								array2[num6 - 1] = 5;
																								break;
																								IL_0d10:
																								if (22 < b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0d1b;
																								IL_095d:
																								if (16 < b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_096b;
																								IL_096b:
																								if (16 > b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0979;
																								IL_0979:
																								array2[num6] = array2[num6 - 1];
																								goto IL_0991;
																								IL_0991:
																								array4[num6 - 0] = array4[num6 - 1];
																								num = 67;
																								goto IL_09b8;
																								IL_09b8:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09dc;
																								IL_09dc:
																								array3[num6] = array3[num6 - 1];
																								goto IL_09f4;
																								IL_09f4:
																								num6++;
																								num = 54;
																								break;
																								IL_0a10:
																								if (14 > b)
																								{
																									goto IL_0a1e;
																								}
																								goto IL_0b30;
																								IL_0a1e:
																								if (12 >= b)
																								{
																									goto IL_0a29;
																								}
																								goto IL_0a3c;
																								IL_0a29:
																								if (12 > b)
																								{
																									goto end_IL_0438;
																								}
																								break;
																								IL_0a3c:
																								if (13 < b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0a4a;
																								IL_0a4a:
																								if (13 > b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0a58;
																								IL_0a58:
																								array8 = array3;
																								num7 = num6;
																								if (array == null)
																								{
																									goto IL_0a67;
																								}
																								num8 = ptr2;
																								byte b2 = *num8;
																								ptr2 = num8 + 4;
																								int num9 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num9;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_0b0f;
																								IL_0d1b:
																								if (22 > b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0d26;
																								IL_0d26:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								break;
																								IL_0d3f:
																								if (21 > b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0d4a;
																								IL_0b0f:
																								array2[num6] = 5;
																								goto IL_0b1d;
																								IL_0b1d:
																								num6++;
																								break;
																								IL_0b30:
																								array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																								goto IL_0b4e;
																								IL_0b4e:
																								ptr2 += 8;
																								goto IL_0b5c;
																								IL_0b5c:
																								num6--;
																								break;
																								IL_0b6f:
																								array2[num6] = 5;
																								goto IL_0b7d;
																								IL_0b7d:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0b95;
																								IL_0b95:
																								num6++;
																								goto IL_0ba3;
																								IL_0ba3:
																								ptr2 += 8;
																								break;
																								IL_0bb6:
																								if (20 >= b)
																								{
																									goto IL_0bc4;
																								}
																								goto IL_0d05;
																								IL_0bc4:
																								if (20 <= b)
																								{
																									goto IL_0bcf;
																								}
																								goto IL_0c17;
																								IL_0bcf:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_0be8;
																								IL_0be8:
																								array2[num6] = 1;
																								goto IL_0bf6;
																								IL_0bf6:
																								num6++;
																								goto IL_0c04;
																								IL_0c04:
																								ptr2 += 16;
																								break;
																								IL_0c17:
																								if (18 < b)
																								{
																									goto IL_0c22;
																								}
																								goto IL_0c9d;
																								IL_0c22:
																								if (19 < b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0c30;
																								IL_0c30:
																								if (19 > b)
																								{
																									goto end_IL_0438;
																								}
																								goto IL_0c3e;
																								IL_0c3e:
																								array2[num6 - 1] = 5;
																								goto IL_0c52;
																								IL_0c52:
																								array3[num6 - 1] = ((delegate*<string[], string>)OpenPunctuationSetExceptions[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0c8a;
																								IL_0c8a:
																								ptr2 += 8;
																								break;
																								IL_0c9d:
																								if (18 > b)
																								{
																									goto end_IL_0438;
																								}
																								num = 57;
																								goto IL_0cb4;
																								IL_0d4a:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								break;
																								IL_0cb4:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								goto IL_0cf2;
																								IL_0cf2:
																								num6 -= 3;
																								break;
																							}
																							goto end_IL_0448;
																							continue;
																							end_IL_0438:
																							break;
																							IL_0438:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d78;
																					IL_0d94:
																					ptr2 += 8;
																					break;
																					IL_0d86:
																					num6++;
																					goto IL_0d94;
																					IL_0d78:
																					array2[num6] = 0;
																					goto IL_0d86;
																					continue;
																					end_IL_0448:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0e6e;
																	IL_0e6e:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0da2:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0a67:
				while (true)
				{
					IL_0a67_2:
					array = new byte[4];
					while (true)
					{
						IL_0a75:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0b1d_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_0468_2:
											byte b = *ptr2;
											while (true)
											{
												IL_0458_2:
												ptr2++;
												while (true)
												{
													IL_0448_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_0428_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_0418_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_040b_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_03fb_2:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_03b9_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								while (true)
																								{
																									IL_03a3_2:
																									array2[num6 - 2] = 0;
																									while (true)
																									{
																										IL_038a_2:
																										num6--;
																										num = 218;
																										while (num != 218)
																										{
																											if (num != 1199)
																											{
																												goto IL_0a3c_2;
																											}
																											switch (num)
																											{
																											case 140:
																												goto IL_038a_2;
																											case 188:
																												goto IL_03a3_2;
																											case 73:
																											case 153:
																												goto IL_03b9_2;
																											case 85:
																												goto IL_03fb_2;
																											case 111:
																												goto IL_040b_2;
																											case 47:
																												goto IL_0418_2;
																											case 156:
																												goto IL_0428_2;
																											case 144:
																												goto IL_0438_2;
																											case 116:
																												goto IL_0448_2;
																											case 31:
																												goto IL_0458_2;
																											case 25:
																											case 58:
																												goto IL_0468_2;
																											case 76:
																											case 137:
																												goto IL_0473_2;
																											case 130:
																												goto IL_047e_2;
																											case 113:
																											case 120:
																												goto IL_048c_2;
																											case 108:
																											case 129:
																												goto IL_049f_2;
																											case 19:
																												goto IL_04aa_2;
																											case 83:
																												goto IL_04bd_2;
																											case 160:
																												goto IL_04cb_2;
																											case 38:
																											case 154:
																												goto IL_04e2_2;
																											case 33:
																												goto IL_0544_2;
																											case 52:
																											case 203:
																												goto IL_0557_2;
																											case 96:
																											case 169:
																												goto IL_0565_2;
																											case 143:
																												goto IL_0573_2;
																											case 97:
																											case 112:
																												goto IL_0581_2;
																											case 18:
																												goto IL_05c1_2;
																											case 46:
																												goto IL_05d5_2;
																											case 2:
																												goto IL_05f1_2;
																											case 60:
																											case 95:
																												goto IL_05ff_2;
																											case 34:
																												goto IL_063f_2;
																											case 90:
																												goto IL_0653_2;
																											case 45:
																											case 210:
																												goto IL_066f_2;
																											case 134:
																												goto IL_067d_2;
																											case 135:
																											case 201:
																												goto IL_0688_2;
																											case 70:
																												goto IL_0696_2;
																											case 78:
																											case 162:
																												goto IL_06a9_2;
																											case 5:
																												goto IL_06e9_2;
																											case 12:
																												goto IL_06fd_2;
																											case 199:
																												goto IL_0710_2;
																											case 123:
																											case 152:
																												goto IL_071e_2;
																											case 15:
																												goto IL_072c_2;
																											case 9:
																											case 103:
																												goto IL_073a_2;
																											case 39:
																												goto IL_0751_2;
																											case 150:
																												goto IL_0774_2;
																											case 119:
																												goto IL_077e_2;
																											case 171:
																												goto IL_078c_2;
																											case 69:
																												goto IL_079f_2;
																											case 41:
																											case 133:
																												goto IL_07ad_2;
																											case 35:
																												goto IL_07d6_2;
																											case 208:
																												goto IL_07e4_2;
																											case 192:
																											case 211:
																												goto IL_07f7_2;
																											case 28:
																												goto IL_0837_2;
																											case 8:
																												goto IL_084b_2;
																											case 147:
																											case 183:
																												goto IL_085e_2;
																											case 187:
																												goto IL_087b_2;
																											case 1:
																												goto IL_08ba_2;
																											case 59:
																												goto IL_08cd_2;
																											case 200:
																												goto IL_08db_2;
																											case 190:
																												goto IL_08e9_2;
																											case 6:
																											case 198:
																												goto IL_08f7_2;
																											case 29:
																												goto IL_0902_2;
																											case 17:
																											case 23:
																												goto IL_090d_2;
																											case 100:
																												goto IL_0936_2;
																											case 159:
																												goto IL_095d_2;
																											case 55:
																												goto IL_096b_2;
																											case 22:
																											case 173:
																												goto IL_0979_2;
																											case 49:
																												goto IL_0991_2;
																											case 67:
																												goto IL_09b8_2;
																											case 178:
																												goto IL_09dc_2;
																											case 3:
																												goto IL_09f4_2;
																											case 114:
																												goto IL_0a10_2;
																											case 14:
																											case 86:
																												goto IL_0a1e_2;
																											case 195:
																												goto IL_0a29_2;
																											case 16:
																											case 163:
																												goto IL_0a3c_2;
																											case 81:
																												goto IL_0a4a_2;
																											case 110:
																											case 115:
																												goto IL_0a58_2;
																											case 63:
																												goto end_IL_0da2_2;
																											case 132:
																												goto IL_0b1d_2;
																											case 92:
																											case 170:
																												goto IL_0b30_2;
																											case 174:
																												goto IL_0b4e_2;
																											case 40:
																												goto IL_0b5c_2;
																											case 30:
																											case 98:
																												goto IL_0b6f_2;
																											case 24:
																												goto IL_0b7d_2;
																											case 177:
																												goto IL_0b95_2;
																											case 0:
																												goto IL_0ba3_2;
																											case 61:
																												goto IL_0bb6_2;
																											case 75:
																												goto IL_0bc4_2;
																											case 13:
																											case 197:
																												goto IL_0bcf_2;
																											case 50:
																												goto IL_0be8_2;
																											case 189:
																												goto IL_0bf6_2;
																											case 44:
																												goto IL_0c04_2;
																											case 68:
																												goto IL_0c17_2;
																											case 32:
																											case 136:
																												goto IL_0c22_2;
																											case 91:
																												goto IL_0c30_2;
																											case 42:
																											case 164:
																												goto IL_0c3e_2;
																											case 20:
																												goto IL_0c52_2;
																											case 181:
																												goto IL_0c8a_2;
																											case 80:
																												goto IL_0c9d_2;
																											case 57:
																											case 138:
																												goto IL_0cb4_2;
																											case 141:
																												goto IL_0cf2_2;
																											case 89:
																												goto IL_0d05_2;
																											case 53:
																											case 148:
																												goto IL_0d10_2;
																											case 191:
																												goto IL_0d1b_2;
																											case 26:
																											case 48:
																												goto IL_0d26_2;
																											case 10:
																												goto IL_0d3f_2;
																											case 66:
																											case 196:
																												goto IL_0d4a_2;
																											case 11:
																											case 27:
																											case 36:
																											case 37:
																											case 51:
																											case 56:
																											case 62:
																											case 71:
																											case 72:
																											case 99:
																											case 105:
																											case 109:
																											case 117:
																											case 118:
																											case 121:
																											case 122:
																											case 126:
																											case 128:
																											case 131:
																											case 139:
																											case 146:
																											case 149:
																											case 155:
																											case 158:
																											case 161:
																											case 165:
																											case 166:
																											case 175:
																											case 182:
																											case 186:
																											case 204:
																											case 205:
																											case 206:
																												goto end_IL_0438_2;
																											case 88:
																												goto IL_0d78_2;
																											case 185:
																												goto IL_0d86_2;
																											case 127:
																												goto IL_0d94_2;
																											case 4:
																											case 21:
																											case 43:
																											case 54:
																											case 65:
																											case 74:
																											case 77:
																											case 93:
																											case 101:
																											case 102:
																											case 104:
																											case 106:
																											case 107:
																											case 124:
																											case 145:
																											case 157:
																											case 167:
																											case 168:
																											case 172:
																											case 176:
																											case 184:
																											case 193:
																											case 194:
																											case 207:
																												goto end_IL_0377_2;
																											case 94:
																												ptr2 = ptr;
																												goto end_IL_0377_2;
																											case 202:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddOvfUnStoreLocation.toExclusiveLoadHint);
																												goto case 94;
																											case 7:
																												array7 = new object[10];
																												goto case 202;
																											case 84:
																												array6 = new long[4];
																												goto case 7;
																											case 142:
																												array5 = new int[6];
																												goto case 84;
																											case 125:
																												array4 = new int[4];
																												goto case 142;
																											case 87:
																												array3 = new object[4];
																												goto case 125;
																											case 209:
																												array2 = new byte[4];
																												goto case 87;
																											case 79:
																												num4 = num2 * 8;
																												goto case 209;
																											case 151:
																												num3 = num2 * 4;
																												goto case 79;
																											case 179:
																												num2 = 1;
																												num = 151;
																												goto case 151;
																											case 180:
																												goto end_IL_0b0f;
																											case 64:
																											case 82:
																												goto IL_0e6e_2;
																											}
																											continue;
																											end_IL_0377_2:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_066f_2;
																						IL_07e4_2:
																						num6--;
																						break;
																						IL_066f_2:
																						if (2 >= b)
																						{
																							goto IL_067d_2;
																						}
																						goto IL_0710_2;
																						IL_067d_2:
																						if (2 > b)
																						{
																							goto IL_0688_2;
																						}
																						goto IL_06a9_2;
																						IL_0688_2:
																						if (1 < b)
																						{
																							goto end_IL_0438_2;
																						}
																						goto IL_0696_2;
																						IL_0696_2:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0438_2;
																						IL_06a9_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_06e9_2;
																						IL_06e9_2:
																						array2[num6 - 2] = 0;
																						goto IL_06fd_2;
																						IL_06fd_2:
																						num6--;
																						break;
																						IL_0710_2:
																						if (3 < b)
																						{
																							goto IL_071e_2;
																						}
																						goto IL_079f_2;
																						IL_071e_2:
																						if (4 < b)
																						{
																							goto end_IL_0438_2;
																						}
																						goto IL_072c_2;
																						IL_072c_2:
																						if (4 > b)
																						{
																							goto end_IL_0438_2;
																						}
																						goto IL_073a_2;
																						IL_073a_2:
																						array2[num6] = 0;
																						num = 39;
																						goto IL_0751_2;
																						IL_0751_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0774_2;
																						IL_0774_2:
																						array3[num6] = null;
																						goto IL_077e_2;
																						IL_077e_2:
																						num6++;
																						goto IL_078c_2;
																						IL_078c_2:
																						ptr2 += 8;
																						break;
																						IL_079f_2:
																						if (3 > b)
																						{
																							goto end_IL_0438_2;
																						}
																						goto IL_07ad_2;
																						IL_07ad_2:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_07d6_2;
																						IL_07d6_2:
																						ptr2 += 8;
																						goto IL_07e4_2;
																					}
																					break;
																				}
																				goto IL_0473_2;
																				IL_04e2_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0544_2;
																				IL_0473_2:
																				if (8 >= b)
																				{
																					goto IL_047e_2;
																				}
																				goto IL_049f_2;
																				IL_047e_2:
																				if (8 <= b)
																				{
																					goto IL_048c_2;
																				}
																				goto IL_0557_2;
																				IL_048c_2:
																				num6--;
																				break;
																				IL_0557_2:
																				if (6 < b)
																				{
																					goto IL_0565_2;
																				}
																				goto IL_05f1_2;
																				IL_0565_2:
																				if (7 < b)
																				{
																					goto end_IL_0438_2;
																				}
																				goto IL_0573_2;
																				IL_0573_2:
																				if (7 > b)
																				{
																					goto end_IL_0438_2;
																				}
																				goto IL_0581_2;
																				IL_0581_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_05c1_2;
																				IL_05c1_2:
																				array2[num6 - 2] = 0;
																				goto IL_05d5_2;
																				IL_05d5_2:
																				num6--;
																				num = 101;
																				break;
																				IL_05f1_2:
																				if (6 > b)
																				{
																					goto end_IL_0438_2;
																				}
																				goto IL_05ff_2;
																				IL_05ff_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_063f_2;
																				IL_063f_2:
																				array2[num6 - 2] = 0;
																				goto IL_0653_2;
																				IL_0653_2:
																				num6--;
																				num = 106;
																				break;
																				IL_049f_2:
																				if (9 >= b)
																				{
																					goto IL_04aa_2;
																				}
																				goto IL_04bd_2;
																				IL_04aa_2:
																				if (9 > b)
																				{
																					goto end_IL_0438_2;
																				}
																				goto IL_07f7_2;
																				IL_07f7_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0837_2;
																				IL_0837_2:
																				array2[num6 - 2] = 0;
																				goto IL_084b_2;
																				IL_084b_2:
																				num6--;
																				break;
																				IL_04bd_2:
																				if (10 < b)
																				{
																					goto end_IL_0438_2;
																				}
																				goto IL_04cb_2;
																				IL_04cb_2:
																				if (10 > b)
																				{
																					goto end_IL_0438_2;
																				}
																				num = 154;
																				goto IL_04e2_2;
																				IL_0544_2:
																				num6 -= 2;
																				break;
																			}
																			break;
																		}
																		goto IL_085e_2;
																		IL_08ba_2:
																		ptr2 += 8;
																		break;
																		IL_085e_2:
																		array2[num6 - 1] = 0;
																		num = 187;
																		goto IL_087b_2;
																		IL_087b_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)OpenPunctuationSetExceptions[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_08ba_2;
																	}
																	break;
																}
																goto IL_08cd_2;
																IL_0d26_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																break;
																IL_08cd_2:
																if (17 >= b)
																{
																	goto IL_08db_2;
																}
																goto IL_0bb6_2;
																IL_08db_2:
																if (17 > b)
																{
																	goto IL_08e9_2;
																}
																goto IL_0b6f_2;
																IL_08e9_2:
																if (14 < b)
																{
																	goto IL_08f7_2;
																}
																goto IL_0a10_2;
																IL_08f7_2:
																if (15 >= b)
																{
																	goto IL_0902_2;
																}
																goto IL_095d_2;
																IL_0902_2:
																if (15 > b)
																{
																	num = 205;
																	goto end_IL_0438_2;
																}
																goto IL_090d_2;
																IL_090d_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_0936_2;
																IL_0936_2:
																array2[num6 - 1] = 5;
																break;
																IL_0d3f_2:
																if (21 > b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0d4a_2;
																IL_095d_2:
																if (16 < b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_096b_2;
																IL_096b_2:
																if (16 > b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0979_2;
																IL_0979_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0991_2;
																IL_0991_2:
																array4[num6 - 0] = array4[num6 - 1];
																num = 67;
																goto IL_09b8_2;
																IL_09b8_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09dc_2;
																IL_09dc_2:
																array3[num6] = array3[num6 - 1];
																goto IL_09f4_2;
																IL_09f4_2:
																num6++;
																num = 54;
																break;
																IL_0a10_2:
																if (14 > b)
																{
																	goto IL_0a1e_2;
																}
																goto IL_0b30_2;
																IL_0a1e_2:
																if (12 >= b)
																{
																	goto IL_0a29_2;
																}
																goto IL_0a3c_2;
																IL_0a29_2:
																if (12 > b)
																{
																	goto end_IL_0438_2;
																}
																break;
																IL_0a3c_2:
																if (13 < b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0a4a_2;
																IL_0a4a_2:
																if (13 > b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0a58_2;
																IL_0a58_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0a67_2;
																}
																goto IL_0a75;
																IL_0b30_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																goto IL_0b4e_2;
																IL_0b4e_2:
																ptr2 += 8;
																goto IL_0b5c_2;
																IL_0b5c_2:
																num6--;
																break;
																IL_0b6f_2:
																array2[num6] = 5;
																goto IL_0b7d_2;
																IL_0b7d_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_0b95_2;
																IL_0b95_2:
																num6++;
																goto IL_0ba3_2;
																IL_0ba3_2:
																ptr2 += 8;
																break;
																IL_0bb6_2:
																if (20 >= b)
																{
																	goto IL_0bc4_2;
																}
																goto IL_0d05_2;
																IL_0bc4_2:
																if (20 <= b)
																{
																	goto IL_0bcf_2;
																}
																goto IL_0c17_2;
																IL_0bcf_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0be8_2;
																IL_0be8_2:
																array2[num6] = 1;
																goto IL_0bf6_2;
																IL_0bf6_2:
																num6++;
																goto IL_0c04_2;
																IL_0c04_2:
																ptr2 += 16;
																break;
																IL_0c17_2:
																if (18 < b)
																{
																	goto IL_0c22_2;
																}
																goto IL_0c9d_2;
																IL_0c22_2:
																if (19 < b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0c30_2;
																IL_0c30_2:
																if (19 > b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0c3e_2;
																IL_0c3e_2:
																array2[num6 - 1] = 5;
																goto IL_0c52_2;
																IL_0c52_2:
																array3[num6 - 1] = ((delegate*<string[], string>)OpenPunctuationSetExceptions[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0c8a_2;
																IL_0c8a_2:
																ptr2 += 8;
																break;
																IL_0c9d_2:
																if (18 > b)
																{
																	goto end_IL_0438_2;
																}
																num = 57;
																goto IL_0cb4_2;
																IL_0d4a_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0cb4_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0cf2_2;
																IL_0cf2_2:
																num6 -= 3;
																break;
																IL_0d05_2:
																if (21 < b)
																{
																	goto IL_0d10_2;
																}
																goto IL_0d3f_2;
																IL_0d10_2:
																if (22 < b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0d1b_2;
																IL_0d1b_2:
																if (22 > b)
																{
																	goto end_IL_0438_2;
																}
																goto IL_0d26_2;
															}
															goto end_IL_0448_2;
															continue;
															end_IL_0438_2:
															break;
															IL_0438_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d78_2;
													IL_0d94_2:
													ptr2 += 8;
													break;
													IL_0d86_2:
													num6++;
													goto IL_0d94_2;
													IL_0d78_2:
													array2[num6] = 0;
													goto IL_0d86_2;
													continue;
													end_IL_0448_2:
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0e6e_2;
									IL_0e6e_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0da2_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0b0f:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class101()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_3)
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setTaskContextInArray.StrongNameTokenFromAssemblyChangePermissions);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0266:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_0256:
																		if (b <= 10)
																		{
																			while (true)
																			{
																				IL_0246:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0239:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_0220:
																								array[num5] = 0;
																								num = 88;
																								while (true)
																								{
																									IL_01fb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									while (true)
																									{
																										IL_01e6:
																										array2[num5] = null;
																										num = 113;
																										while (true)
																										{
																											if (num != 113)
																											{
																												if (num != 1094)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 64:
																													goto IL_01e6;
																												case 88:
																													goto IL_01fb;
																												case 42:
																												case 95:
																													goto IL_0220;
																												case 21:
																													goto IL_0239;
																												case 5:
																													goto IL_0246;
																												case 60:
																													goto IL_0256;
																												case 1:
																													goto IL_0266;
																												case 46:
																													goto end_IL_0266;
																												case 20:
																												case 74:
																													goto end_IL_0276;
																												case 17:
																												case 54:
																													goto IL_0291;
																												case 11:
																													goto IL_029c;
																												case 44:
																													goto IL_02aa;
																												case 69:
																													goto IL_02bd;
																												case 47:
																													goto IL_02cb;
																												case 19:
																													goto IL_02d9;
																												case 39:
																												case 55:
																													goto IL_02e7;
																												case 52:
																													goto IL_0300;
																												case 56:
																												case 85:
																													goto IL_0313;
																												case 35:
																												case 80:
																													goto IL_031e;
																												case 70:
																													goto IL_0329;
																												case 43:
																												case 76:
																													goto IL_0337;
																												case 23:
																													goto IL_0353;
																												case 68:
																													goto IL_0361;
																												case 82:
																													goto IL_0374;
																												case 45:
																												case 65:
																													goto IL_038b;
																												case 3:
																												case 84:
																													goto IL_0396;
																												case 38:
																													goto IL_03a4;
																												case 8:
																													goto IL_03b7;
																												case 10:
																												case 33:
																													goto IL_03c5;
																												case 7:
																													goto IL_0405;
																												case 50:
																													goto IL_0419;
																												case 87:
																												case 93:
																													goto IL_042c;
																												case 62:
																													goto IL_048e;
																												case 9:
																												case 94:
																													goto IL_04a1;
																												case 83:
																													goto IL_04cd;
																												case 75:
																													goto IL_04db;
																												case 73:
																												case 96:
																													goto IL_04eb;
																												case 15:
																													goto IL_0514;
																												case 32:
																													goto IL_0522;
																												case 97:
																													goto IL_0535;
																												case 13:
																													goto IL_0543;
																												case 101:
																													goto IL_0553;
																												case 79:
																												case 102:
																													goto IL_0563;
																												case 29:
																												case 104:
																													goto IL_0570;
																												case 105:
																													goto IL_0585;
																												case 53:
																													goto IL_05a0;
																												case 4:
																												case 6:
																												case 12:
																												case 16:
																												case 18:
																												case 22:
																												case 25:
																												case 26:
																												case 34:
																												case 37:
																												case 48:
																												case 61:
																												case 66:
																												case 67:
																												case 71:
																												case 77:
																												case 81:
																												case 98:
																												case 99:
																												case 100:
																													goto end_IL_01d3;
																												case 0:
																												case 14:
																												case 24:
																												case 31:
																												case 40:
																												case 41:
																												case 57:
																												case 58:
																												case 63:
																												case 86:
																												case 89:
																												case 91:
																												case 106:
																													goto end_IL_0286;
																												case 59:
																													goto end_IL_05cc;
																												case 49:
																													goto end_IL_05df;
																												case 30:
																													goto end_IL_05e9;
																												case 78:
																													goto end_IL_05f4;
																												case 72:
																												case 103:
																													goto end_IL_0609;
																												case 92:
																													goto end_IL_0619;
																												case 36:
																												case 90:
																													goto end_IL_0629;
																												case 27:
																													goto end_IL_0639;
																												case 28:
																													goto end_IL_0649;
																												case 2:
																												case 51:
																													goto IL_0664;
																												}
																												continue;
																											}
																											num5++;
																											goto IL_05a0;
																											IL_05a0:
																											ptr2 += 8;
																											goto end_IL_0286;
																											continue;
																											end_IL_01d3:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0291;
																						IL_0522:
																						num5--;
																						goto end_IL_0286;
																						IL_0291:
																						if (2 < b)
																						{
																							goto IL_029c;
																						}
																						goto IL_02bd;
																						IL_029c:
																						if (3 >= b)
																						{
																							goto IL_02aa;
																						}
																						goto IL_0563;
																						IL_02aa:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0570;
																						IL_0570:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0286;
																						IL_0563:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0585;
																						IL_0585:
																						if (4 <= b)
																						{
																							goto end_IL_0286;
																						}
																						break;
																						IL_02bd:
																						if (2 > b)
																						{
																							goto IL_02cb;
																						}
																						goto IL_04eb;
																						IL_02cb:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_02d9;
																						IL_02d9:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_02e7;
																						IL_02e7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0300;
																						IL_0300:
																						array[num5] = 0;
																						goto IL_0535;
																						IL_0535:
																						num5++;
																						goto IL_0543;
																						IL_0543:
																						ptr2 += 8;
																						goto end_IL_0286;
																						IL_04eb:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0514;
																						IL_0514:
																						ptr2 += 8;
																						goto IL_0522;
																					}
																					break;
																				}
																				goto IL_0313;
																				IL_042c:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_048e;
																				IL_0313:
																				if (8 < b)
																				{
																					goto IL_031e;
																				}
																				goto IL_0374;
																				IL_031e:
																				if (9 >= b)
																				{
																					goto IL_0329;
																				}
																				goto IL_0353;
																				IL_0329:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0337;
																				IL_0337:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0286;
																				IL_0353:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0361;
																				IL_0361:
																				if (10 > b)
																				{
																				}
																				break;
																				IL_0374:
																				if (8 > b)
																				{
																					num = 45;
																					goto IL_038b;
																				}
																				goto IL_042c;
																				IL_048e:
																				num5 -= 2;
																				goto end_IL_0286;
																				IL_038b:
																				if (6 < b)
																				{
																					goto IL_0396;
																				}
																				goto IL_03b7;
																				IL_0396:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_03a4;
																				IL_03a4:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04a1;
																				IL_04a1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 83;
																				goto IL_04cd;
																				IL_04cd:
																				array[num5] = 0;
																				goto IL_04db;
																				IL_04db:
																				num5++;
																				goto IL_0553;
																				IL_0553:
																				ptr2 += 8;
																				goto end_IL_0286;
																				IL_03b7:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_03c5;
																				IL_03c5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0405;
																				IL_0405:
																				array[num5 - 2] = 0;
																				goto IL_0419;
																				IL_0419:
																				num5--;
																				goto end_IL_0286;
																			}
																		}
																		else
																		{
																			num = 48;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0286;
																continue;
																end_IL_0266:
																break;
															}
															continue;
															end_IL_0276:
															break;
														}
														continue;
														end_IL_0286:
														break;
													}
													continue;
												}
												goto IL_0664;
												IL_0664:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05cc:
												break;
											}
											continue;
											end_IL_05df:
											break;
										}
										continue;
										end_IL_05e9:
										break;
									}
									continue;
									end_IL_05f4:
									break;
								}
								continue;
								end_IL_0609:
								break;
							}
							continue;
							end_IL_0619:
							break;
						}
						continue;
						end_IL_0629:
						break;
					}
					continue;
					end_IL_0639:
					break;
				}
				continue;
				end_IL_0649:
				break;
			}
		}
	}

	private unsafe static int smethod_14(int int_3, int int_4)
	{
		int num = 77;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SerializationHeaderRecordSpecialFolderOption.FUiDefaultsetInitLocals);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0219:
															byte b = *ptr2;
															while (true)
															{
																IL_0209:
																ptr2++;
																while (true)
																{
																	IL_01f9:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01d9:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01cc:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (true)
																								{
																									IL_01ac:
																									if (5 < b)
																									{
																										num = 95;
																										while (num != 95)
																										{
																											if (num != 1076)
																											{
																												goto end_IL_01bc;
																											}
																											switch (num)
																											{
																											case 36:
																											case 42:
																												goto IL_01ac;
																											case 13:
																												goto IL_01bc;
																											case 33:
																											case 83:
																												goto IL_01cc;
																											case 52:
																												goto IL_01d9;
																											case 40:
																												goto IL_01e9;
																											case 34:
																												goto IL_01f9;
																											case 1:
																												goto IL_0209;
																											case 41:
																											case 75:
																												goto IL_0219;
																											case 79:
																												goto IL_0224;
																											case 59:
																											case 71:
																												goto IL_0232;
																											case 38:
																											case 85:
																												goto IL_024a;
																											case 70:
																												goto IL_0255;
																											case 4:
																											case 8:
																												goto IL_0263;
																											case 78:
																												goto IL_0271;
																											case 39:
																												goto IL_0294;
																											case 7:
																												goto IL_029e;
																											case 84:
																												goto IL_02ac;
																											case 53:
																												goto IL_02bf;
																											case 0:
																												goto IL_02ca;
																											case 23:
																											case 65:
																												goto IL_02e1;
																											case 81:
																												goto IL_030b;
																											case 25:
																												goto IL_0319;
																											case 27:
																												goto IL_0327;
																											case 14:
																												goto IL_0335;
																											case 11:
																											case 37:
																												goto IL_0343;
																											case 61:
																												goto IL_0383;
																											case 87:
																												goto IL_0397;
																											case 68:
																												goto IL_03aa;
																											case 44:
																											case 63:
																												goto IL_03b5;
																											case 5:
																												goto IL_03c3;
																											case 19:
																											case 20:
																												goto IL_03d6;
																											case 86:
																												goto IL_0444;
																											case 18:
																											case 49:
																												goto IL_0460;
																											case 9:
																												goto IL_0489;
																											case 82:
																												goto IL_0497;
																											case 2:
																											case 3:
																											case 16:
																											case 21:
																											case 22:
																											case 28:
																											case 31:
																											case 32:
																											case 47:
																											case 50:
																											case 60:
																											case 62:
																											case 73:
																											case 74:
																											case 88:
																												goto end_IL_0199;
																											case 43:
																												goto IL_04ca;
																											case 56:
																												goto IL_04d8;
																											case 58:
																												goto IL_04e6;
																											case 10:
																											case 17:
																											case 26:
																											case 29:
																											case 45:
																											case 46:
																											case 51:
																											case 66:
																											case 67:
																											case 69:
																											case 80:
																												goto end_IL_01bc;
																											case 72:
																												goto end_IL_04f4;
																											case 48:
																												goto end_IL_0507;
																											case 6:
																												goto end_IL_0511;
																											case 30:
																												goto end_IL_051c;
																											case 35:
																												goto end_IL_0531;
																											case 15:
																											case 24:
																												goto end_IL_0546;
																											case 57:
																												goto end_IL_0556;
																											case 12:
																											case 55:
																												goto end_IL_0566;
																											case 76:
																												goto end_IL_0576;
																											case 77:
																												goto end_IL_0586;
																											case 54:
																											case 64:
																												goto IL_05a1;
																											}
																											continue;
																											end_IL_0199:
																											break;
																										}
																										break;
																									}
																									goto IL_0224;
																									IL_0224:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0232;
																									IL_0232:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_01bc;
																								}
																								goto end_IL_01e9;
																								continue;
																								end_IL_01bc:
																								break;
																								IL_01bc:;
																							}
																							break;
																						}
																						goto IL_024a;
																						IL_02e1:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_024a:
																						if (7 >= b)
																						{
																							goto IL_0255;
																						}
																						goto IL_02bf;
																						IL_0255:
																						if (7 > b)
																						{
																							goto end_IL_01e9;
																						}
																						goto IL_0263;
																						IL_0263:
																						array[num6] = 0;
																						goto IL_0271;
																						IL_0271:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0294;
																						IL_0294:
																						array2[num6] = null;
																						goto IL_029e;
																						IL_029e:
																						num6++;
																						goto IL_02ac;
																						IL_02ac:
																						ptr2 += 8;
																						break;
																						IL_02bf:
																						if (8 < b)
																						{
																							num = 16;
																							goto end_IL_01e9;
																						}
																						goto IL_02ca;
																						IL_02ca:
																						if (8 > b)
																						{
																							goto end_IL_01e9;
																						}
																						num = 23;
																						goto IL_02e1;
																					}
																					break;
																				}
																				goto IL_030b;
																				IL_0489:
																				ptr2 += 8;
																				goto IL_0497;
																				IL_030b:
																				if (4 > b)
																				{
																					goto IL_0319;
																				}
																				num = 18;
																				goto IL_0460;
																				IL_0319:
																				if (2 < b)
																				{
																					goto IL_0327;
																				}
																				goto IL_03aa;
																				IL_0327:
																				if (3 < b)
																				{
																					goto end_IL_01e9;
																				}
																				goto IL_0335;
																				IL_0335:
																				if (3 > b)
																				{
																					goto end_IL_01e9;
																				}
																				goto IL_0343;
																				IL_0343:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0383;
																				IL_0383:
																				array[num6 - 2] = 0;
																				goto IL_0397;
																				IL_0397:
																				num6--;
																				break;
																				IL_03aa:
																				if (2 > b)
																				{
																					goto IL_03b5;
																				}
																				goto IL_03d6;
																				IL_03b5:
																				if (1 < b)
																				{
																					goto end_IL_01e9;
																				}
																				goto IL_03c3;
																				IL_03c3:
																				if (1 > b)
																				{
																				}
																				goto end_IL_01e9;
																				IL_03d6:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0444;
																				IL_0444:
																				num6 -= 2;
																				break;
																				IL_0497:
																				num6--;
																				break;
																				IL_0460:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0489;
																			}
																			goto end_IL_01f9;
																			continue;
																			end_IL_01e9:
																			break;
																			IL_01e9:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04ca;
																	IL_04e6:
																	ptr2 += 8;
																	break;
																	IL_04d8:
																	num6++;
																	goto IL_04e6;
																	IL_04ca:
																	array[num6] = 0;
																	goto IL_04d8;
																	continue;
																	end_IL_01f9:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a1;
													IL_05a1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04f4:
													break;
												}
												continue;
												end_IL_0507:
												break;
											}
											continue;
											end_IL_0511:
											break;
										}
										continue;
										end_IL_051c:
										break;
									}
									continue;
									end_IL_0531:
									break;
								}
								continue;
								end_IL_0546:
								break;
							}
							continue;
							end_IL_0556:
							break;
						}
						continue;
						end_IL_0566:
						break;
					}
					continue;
					end_IL_0576:
					break;
				}
				continue;
				end_IL_0586:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_3, int int_4)
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							num = 99;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref addAssemblyLoadContract.ObjectModeComImportAttribute);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0248:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0228:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0218:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_020b:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01f8:
																										if (3 < b)
																										{
																											num = 114;
																											while (true)
																											{
																												if (num != 114)
																												{
																													if (num != 1095)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 56:
																														goto IL_01f8;
																													case 11:
																													case 73:
																														goto IL_020b;
																													case 1:
																														goto IL_0218;
																													case 20:
																														goto IL_0228;
																													case 35:
																														goto IL_0238;
																													case 97:
																														goto IL_0248;
																													case 40:
																														goto end_IL_0248;
																													case 15:
																													case 95:
																														goto end_IL_0258;
																													case 17:
																														goto IL_0273;
																													case 12:
																														goto IL_027e;
																													case 39:
																														goto IL_0299;
																													case 79:
																													case 94:
																														goto IL_02ac;
																													case 60:
																														goto IL_02ec;
																													case 72:
																														goto IL_0300;
																													case 85:
																														goto IL_0313;
																													case 63:
																														goto IL_0321;
																													case 92:
																													case 105:
																														goto IL_032f;
																													case 91:
																														goto IL_036f;
																													case 106:
																														goto IL_0383;
																													case 89:
																														goto IL_0396;
																													case 14:
																													case 24:
																														goto IL_03a4;
																													case 16:
																														goto IL_03cd;
																													case 66:
																														goto IL_03db;
																													case 36:
																													case 47:
																														goto IL_03f7;
																													case 34:
																														goto IL_040e;
																													case 100:
																														goto IL_0431;
																													case 74:
																														goto IL_0444;
																													case 10:
																														goto IL_0452;
																													case 53:
																														goto IL_0465;
																													case 18:
																													case 81:
																														goto IL_0473;
																													case 7:
																													case 65:
																														goto IL_047e;
																													case 50:
																														goto IL_048c;
																													case 43:
																													case 93:
																														goto IL_049a;
																													case 76:
																														goto IL_04b6;
																													case 4:
																													case 48:
																														goto IL_04c4;
																													case 52:
																														goto IL_0504;
																													case 107:
																														goto IL_0518;
																													case 21:
																														goto IL_052b;
																													case 6:
																													case 57:
																														goto IL_0536;
																													case 26:
																														goto IL_054f;
																													case 32:
																														goto IL_055d;
																													case 13:
																														goto IL_056b;
																													case 0:
																														goto IL_057e;
																													case 71:
																														goto IL_0589;
																													case 55:
																													case 82:
																														goto IL_0594;
																													case 19:
																														goto IL_05d4;
																													case 58:
																														goto IL_05e8;
																													case 2:
																													case 9:
																													case 22:
																													case 25:
																													case 27:
																													case 28:
																													case 29:
																													case 33:
																													case 37:
																													case 38:
																													case 42:
																													case 44:
																													case 54:
																													case 67:
																													case 68:
																													case 75:
																													case 83:
																													case 86:
																													case 90:
																													case 96:
																													case 98:
																														goto end_IL_01e5;
																													case 103:
																														goto IL_0624;
																													case 23:
																														goto IL_0632;
																													case 102:
																														goto IL_0640;
																													case 3:
																													case 5:
																													case 41:
																													case 45:
																													case 46:
																													case 51:
																													case 59:
																													case 62:
																													case 64:
																													case 77:
																													case 87:
																														goto end_IL_0268;
																													case 49:
																														goto end_IL_064e;
																													case 104:
																														goto end_IL_0661;
																													case 78:
																														goto end_IL_066b;
																													case 70:
																														goto end_IL_0676;
																													case 99:
																														goto end_IL_068b;
																													case 8:
																													case 80:
																														goto end_IL_06a0;
																													case 69:
																														goto end_IL_06b0;
																													case 88:
																													case 101:
																														goto end_IL_06c9;
																													case 30:
																														goto end_IL_06d9;
																													case 31:
																														goto end_IL_06e9;
																													case 61:
																													case 84:
																														goto IL_0704;
																													}
																													continue;
																												}
																												goto IL_0313;
																												IL_036f:
																												array[num5 - 2] = 0;
																												goto IL_0383;
																												IL_0383:
																												num5--;
																												goto end_IL_0268;
																												IL_0313:
																												if (4 < b)
																												{
																													break;
																												}
																												goto IL_0321;
																												IL_0321:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_032f;
																												IL_032f:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_036f;
																												continue;
																												end_IL_01e5:
																												break;
																											}
																											break;
																										}
																										goto IL_0396;
																										IL_03cd:
																										ptr2 += 8;
																										goto IL_03db;
																										IL_03db:
																										num5--;
																										num = 64;
																										goto end_IL_0268;
																										IL_0396:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_03a4;
																										IL_03a4:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_03cd;
																									}
																									break;
																								}
																								goto IL_0273;
																								IL_02ec:
																								array[num5 - 2] = 0;
																								goto IL_0300;
																								IL_0273:
																								if (2 > b)
																								{
																									goto IL_027e;
																								}
																								num = 79;
																								goto IL_02ac;
																								IL_027e:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0299;
																								IL_0299:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0300:
																								num5--;
																								goto end_IL_0268;
																								IL_02ac:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02ec;
																							}
																							break;
																						}
																						goto IL_03f7;
																						IL_0452:
																						ptr2 += 8;
																						goto end_IL_0268;
																						IL_03f7:
																						array[num5] = 0;
																						num = 34;
																						goto IL_040e;
																						IL_040e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0431;
																						IL_0431:
																						array2[num5] = null;
																						num = 74;
																						goto IL_0444;
																						IL_0444:
																						num5++;
																						goto IL_0452;
																					}
																					break;
																				}
																				goto IL_0465;
																				IL_05e8:
																				num5--;
																				goto end_IL_0268;
																				IL_0465:
																				if (7 < b)
																				{
																					goto IL_0473;
																				}
																				goto IL_052b;
																				IL_0473:
																				if (8 < b)
																				{
																					goto IL_047e;
																				}
																				goto IL_04b6;
																				IL_047e:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_048c;
																				IL_048c:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_049a;
																				IL_049a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0268;
																				IL_04b6:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04c4;
																				IL_04c4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0504;
																				IL_0504:
																				array[num5 - 2] = 0;
																				goto IL_0518;
																				IL_0518:
																				num5--;
																				goto end_IL_0268;
																				IL_052b:
																				if (7 <= b)
																				{
																					goto IL_0536;
																				}
																				goto IL_057e;
																				IL_0536:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_054f;
																				IL_054f:
																				array[num5] = 0;
																				goto IL_055d;
																				IL_055d:
																				num5++;
																				goto IL_056b;
																				IL_056b:
																				ptr2 += 8;
																				goto end_IL_0268;
																				IL_057e:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0589;
																				IL_0589:
																				if (6 > b)
																				{
																					num = 86;
																					break;
																				}
																				goto IL_0594;
																				IL_0594:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d4;
																				IL_05d4:
																				array[num5 - 2] = 0;
																				goto IL_05e8;
																			}
																			break;
																			IL_0238:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0624;
																	IL_0640:
																	ptr2 += 8;
																	goto end_IL_0268;
																	IL_0632:
																	num5++;
																	goto IL_0640;
																	IL_0624:
																	array[num5] = 0;
																	goto IL_0632;
																	continue;
																	end_IL_0248:
																	break;
																}
																continue;
																end_IL_0258:
																break;
															}
															continue;
															end_IL_0268:
															break;
														}
														continue;
													}
													goto IL_0704;
													IL_0704:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_064e:
													break;
												}
												continue;
												end_IL_0661:
												break;
											}
											continue;
											end_IL_066b:
											break;
										}
										continue;
										end_IL_0676:
										break;
									}
									continue;
									end_IL_068b:
									break;
								}
								continue;
								end_IL_06a0:
								break;
							}
							continue;
							end_IL_06b0:
							break;
						}
						continue;
						end_IL_06c9:
						break;
					}
					continue;
					end_IL_06d9:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_3, int int_4)
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 71;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddTokenremoveAssemblyResolve.getRequestedExecutionLevelSafeArrayRankMismatchException);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	if (b >= 1)
																	{
																		num = 92;
																		while (true)
																		{
																			if (num != 92)
																			{
																				if (num != 1073)
																				{
																					goto IL_0450;
																				}
																				switch (num)
																				{
																				case 37:
																					goto end_IL_018d;
																				case 76:
																					goto end_IL_019d;
																				case 58:
																				case 70:
																					goto end_IL_01b0;
																				case 28:
																					goto IL_01d9;
																				case 32:
																					goto IL_01e7;
																				case 33:
																				case 45:
																					goto IL_01f2;
																				case 62:
																					goto IL_021b;
																				case 36:
																					goto IL_0229;
																				case 64:
																					goto IL_023c;
																				case 5:
																					goto IL_024a;
																				case 43:
																					goto IL_0255;
																				case 48:
																					goto IL_0263;
																				case 16:
																				case 81:
																					goto IL_0276;
																				case 8:
																					goto IL_02e4;
																				case 44:
																					goto IL_02f7;
																				case 30:
																					goto IL_0305;
																				case 1:
																				case 26:
																					goto IL_0313;
																				case 59:
																					goto IL_0353;
																				case 73:
																					goto IL_0367;
																				case 50:
																					goto IL_037a;
																				case 11:
																					goto IL_0388;
																				case 18:
																					goto IL_0393;
																				case 17:
																				case 85:
																					goto IL_03a1;
																				case 75:
																					goto IL_03af;
																				case 66:
																					goto IL_03d2;
																				case 78:
																					goto IL_03dc;
																				case 42:
																					goto IL_03ea;
																				case 80:
																					goto IL_03fd;
																				case 9:
																					goto IL_0408;
																				case 24:
																				case 53:
																					goto IL_0413;
																				case 77:
																					goto IL_042f;
																				case 3:
																					goto IL_043a;
																				case 46:
																					goto IL_0445;
																				case 54:
																				case 61:
																					goto IL_0450;
																				case 6:
																				case 10:
																				case 13:
																				case 14:
																				case 22:
																				case 29:
																				case 34:
																				case 39:
																				case 51:
																				case 57:
																				case 60:
																				case 63:
																				case 68:
																				case 69:
																				case 74:
																				case 82:
																				case 84:
																					goto IL_0465;
																				case 52:
																					goto IL_0488;
																				case 19:
																					goto IL_0496;
																				case 12:
																					goto IL_04a4;
																				case 0:
																				case 2:
																				case 15:
																				case 27:
																				case 38:
																				case 47:
																				case 49:
																				case 55:
																				case 65:
																				case 72:
																				case 83:
																					goto end_IL_01c0;
																				case 31:
																					goto end_IL_04b2;
																				case 23:
																					goto end_IL_04c5;
																				case 4:
																					goto end_IL_04cf;
																				case 7:
																					goto end_IL_04da;
																				case 56:
																					goto end_IL_04ef;
																				case 35:
																				case 71:
																					goto end_IL_0504;
																				case 41:
																					goto end_IL_0514;
																				case 40:
																				case 67:
																					goto end_IL_0524;
																				case 20:
																					goto end_IL_053d;
																				case 21:
																					goto end_IL_054d;
																				case 25:
																				case 79:
																					goto IL_0568;
																				}
																				continue;
																			}
																			if (b <= 8)
																			{
																				goto IL_01d9;
																			}
																			goto IL_0465;
																			IL_043a:
																			if (5 >= b)
																			{
																				goto IL_0445;
																			}
																			goto IL_0465;
																			IL_0450:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_01c0;
																			IL_0445:
																			if (5 <= b)
																			{
																				goto IL_0450;
																			}
																			goto IL_0465;
																			IL_01d9:
																			if (4 >= b)
																			{
																				goto IL_01e7;
																			}
																			goto IL_037a;
																			IL_01e7:
																			if (4 <= b)
																			{
																				goto IL_01f2;
																			}
																			goto IL_023c;
																			IL_01f2:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_021b;
																			IL_021b:
																			ptr2 += 8;
																			goto IL_0229;
																			IL_0229:
																			num5--;
																			goto end_IL_01c0;
																			IL_023c:
																			if (2 >= b)
																			{
																				goto IL_024a;
																			}
																			goto IL_02f7;
																			IL_024a:
																			if (2 > b)
																			{
																				goto IL_0255;
																			}
																			goto IL_0276;
																			IL_0255:
																			if (1 >= b)
																			{
																				goto IL_0263;
																			}
																			goto IL_0465;
																			IL_0263:
																			if (1 > b)
																			{
																			}
																			goto IL_0465;
																			IL_0276:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_02e4;
																			IL_02e4:
																			num5 -= 2;
																			goto end_IL_01c0;
																			IL_02f7:
																			if (3 >= b)
																			{
																				goto IL_0305;
																			}
																			goto IL_0465;
																			IL_0305:
																			if (3 <= b)
																			{
																				goto IL_0313;
																			}
																			goto IL_0465;
																			IL_0313:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0353;
																			IL_0353:
																			array[num5 - 2] = 0;
																			goto IL_0367;
																			IL_0367:
																			num5--;
																			goto end_IL_01c0;
																			IL_037a:
																			if (6 < b)
																			{
																				goto IL_0388;
																			}
																			goto IL_042f;
																			IL_0388:
																			if (7 >= b)
																			{
																				goto IL_0393;
																			}
																			goto IL_03fd;
																			IL_0393:
																			if (7 <= b)
																			{
																				goto IL_03a1;
																			}
																			goto IL_0465;
																			IL_03a1:
																			array[num5] = 0;
																			goto IL_03af;
																			IL_03af:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03d2;
																			IL_03d2:
																			array2[num5] = null;
																			goto IL_03dc;
																			IL_03dc:
																			num5++;
																			goto IL_03ea;
																			IL_03ea:
																			ptr2 += 8;
																			goto end_IL_01c0;
																			IL_03fd:
																			if (8 >= b)
																			{
																				goto IL_0408;
																			}
																			goto IL_0465;
																			IL_0408:
																			if (8 <= b)
																			{
																				goto IL_0413;
																			}
																			goto IL_0465;
																			IL_0413:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_01c0;
																			IL_042f:
																			if (6 <= b)
																			{
																				goto end_IL_01c0;
																			}
																			goto IL_043a;
																			continue;
																			end_IL_018d:
																			break;
																		}
																		continue;
																	}
																	goto IL_0465;
																	IL_0496:
																	num5++;
																	goto IL_04a4;
																	IL_04a4:
																	ptr2 += 8;
																	goto end_IL_01c0;
																	IL_0465:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0488;
																	IL_0488:
																	array[num5] = 0;
																	goto IL_0496;
																	continue;
																	end_IL_019d:
																	break;
																}
																continue;
																end_IL_01b0:
																break;
															}
															continue;
															end_IL_01c0:
															break;
														}
														continue;
													}
													goto IL_0568;
													IL_0568:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04b2:
													break;
												}
												continue;
												end_IL_04c5:
												break;
											}
											continue;
											end_IL_04cf:
											break;
										}
										continue;
										end_IL_04da:
										break;
									}
									continue;
									end_IL_04ef:
									break;
								}
								continue;
								end_IL_0504:
								break;
							}
							continue;
							end_IL_0514:
							break;
						}
						continue;
						end_IL_0524:
						break;
					}
					continue;
					end_IL_053d:
					break;
				}
				continue;
				end_IL_054d:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_3, int int_4)
	{
		int num = 30;
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									num = 93;
									while (true)
									{
										if (num != 93)
										{
											if (num != 1074)
											{
												goto IL_0382;
											}
											switch (num)
											{
											case 3:
												goto end_IL_0183;
											case 17:
												goto end_IL_0193;
											case 2:
											case 25:
												goto end_IL_01b1;
											case 38:
												goto end_IL_01c1;
											case 45:
											case 50:
												goto end_IL_01d1;
											case 29:
												goto end_IL_01e1;
											case 30:
												goto end_IL_01f1;
											case 40:
												goto IL_0228;
											case 12:
												goto IL_0231;
											case 0:
											case 16:
											case 46:
											case 61:
											case 62:
											case 63:
											case 64:
											case 69:
											case 82:
											case 83:
											case 84:
												goto IL_0239;
											case 44:
											case 80:
												goto IL_0249;
											case 34:
												goto IL_025b;
											case 71:
												goto IL_0269;
											case 15:
												goto IL_0277;
											case 28:
												goto IL_0285;
											case 4:
											case 13:
												goto IL_0293;
											case 79:
												goto IL_029e;
											case 66:
												goto IL_02a9;
											case 26:
												goto IL_02b7;
											case 57:
											case 67:
												goto IL_02c2;
											case 78:
												goto IL_02e8;
											case 52:
												goto IL_02f3;
											case 22:
											case 81:
												goto IL_0301;
											case 65:
												goto IL_030f;
											case 7:
												goto IL_0332;
											case 72:
												goto IL_033c;
											case 20:
												goto IL_0353;
											case 1:
												goto IL_0366;
											case 76:
												goto IL_0374;
											case 48:
											case 60:
												goto IL_0382;
											case 43:
												goto IL_039e;
											case 5:
											case 36:
												goto IL_03a9;
											case 58:
												goto IL_03db;
											case 47:
												goto IL_03e9;
											case 51:
												goto IL_03fc;
											case 59:
												goto IL_040a;
											case 74:
											case 85:
												goto IL_0418;
											case 24:
												goto IL_0486;
											case 75:
												goto IL_0499;
											case 77:
												goto IL_04a7;
											case 21:
												goto IL_04ba;
											case 42:
												goto IL_04c8;
											case 18:
											case 23:
												goto IL_04d6;
											case 10:
												goto IL_0516;
											case 53:
												goto IL_052a;
											case 86:
												goto IL_053d;
											case 55:
												goto IL_054b;
											case 35:
												goto IL_0559;
											case 6:
											case 8:
											case 11:
											case 14:
											case 19:
											case 27:
											case 31:
											case 32:
											case 33:
											case 37:
											case 39:
											case 41:
											case 54:
											case 56:
											case 68:
											case 70:
											case 73:
												goto IL_056c;
											case 9:
											case 49:
												goto IL_0591;
											}
											continue;
										}
										array3[1] = int_4;
										num = 40;
										goto IL_0228;
										IL_056c:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
										goto IL_053d;
										IL_054b:
										num4++;
										goto IL_0559;
										IL_053d:
										array[num4] = 0;
										goto IL_054b;
										IL_0228:
										ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SortIdCommonProgramFilesX.EnvironmentVariableTargetDaytimeDuration);
										goto IL_0231;
										IL_0231:
										ptr = ptr2;
										goto IL_0239;
										IL_0239:
										if (num5 != 1)
										{
											goto IL_0249;
										}
										goto IL_0591;
										IL_0591:
										return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										IL_0249:
										b = *ptr;
										num = 34;
										goto IL_025b;
										IL_025b:
										ptr++;
										goto IL_0269;
										IL_0269:
										if (b >= 1)
										{
											goto IL_0277;
										}
										goto IL_056c;
										IL_0277:
										if (b <= 8)
										{
											goto IL_0285;
										}
										goto IL_056c;
										IL_0285:
										if (4 < b)
										{
											goto IL_0293;
										}
										goto IL_039e;
										IL_0293:
										if (6 >= b)
										{
											goto IL_029e;
										}
										goto IL_02e8;
										IL_029e:
										if (6 <= b)
										{
											goto IL_0239;
										}
										goto IL_02a9;
										IL_02a9:
										if (5 >= b)
										{
											goto IL_02b7;
										}
										goto IL_056c;
										IL_02b7:
										if (5 <= b)
										{
											goto IL_02c2;
										}
										num = 54;
										goto IL_056c;
										IL_02c2:
										ptr = ptr2 + *(int*)(ptr + num3);
										goto IL_0239;
										IL_0559:
										ptr += 8;
										goto IL_0239;
										IL_02e8:
										if (7 >= b)
										{
											goto IL_02f3;
										}
										goto IL_0366;
										IL_02f3:
										if (7 <= b)
										{
											goto IL_0301;
										}
										goto IL_056c;
										IL_0301:
										array[num4] = 0;
										goto IL_030f;
										IL_030f:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
										goto IL_0332;
										IL_0332:
										array2[num4] = null;
										goto IL_033c;
										IL_033c:
										num4++;
										num = 20;
										goto IL_0353;
										IL_0353:
										ptr += 8;
										goto IL_0239;
										IL_0366:
										if (8 >= b)
										{
											goto IL_0374;
										}
										goto IL_056c;
										IL_0374:
										if (8 <= b)
										{
											goto IL_0382;
										}
										goto IL_056c;
										IL_0382:
										byte* num6 = ptr;
										num5 = 1;
										ptr = num6 + -200;
										goto IL_0239;
										IL_039e:
										if (4 <= b)
										{
											goto IL_03a9;
										}
										goto IL_03fc;
										IL_03a9:
										ref int reference = ref array3[*(int*)(ptr + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										num = 58;
										goto IL_03db;
										IL_03db:
										ptr += 8;
										goto IL_03e9;
										IL_03e9:
										num4--;
										goto IL_0239;
										IL_03fc:
										if (2 >= b)
										{
											goto IL_040a;
										}
										goto IL_04ba;
										IL_040a:
										if (2 <= b)
										{
											goto IL_0418;
										}
										goto IL_0499;
										IL_0418:
										ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
										goto IL_0486;
										IL_0486:
										num4 -= 2;
										goto IL_0239;
										IL_0499:
										if (1 >= b)
										{
											goto IL_04a7;
										}
										goto IL_056c;
										IL_04a7:
										if (1 <= b)
										{
										}
										goto IL_056c;
										IL_04ba:
										if (3 >= b)
										{
											goto IL_04c8;
										}
										goto IL_056c;
										IL_04c8:
										if (3 <= b)
										{
											goto IL_04d6;
										}
										goto IL_056c;
										IL_04d6:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_0516;
										IL_0516:
										array[num4 - 2] = 0;
										goto IL_052a;
										IL_052a:
										num4--;
										goto IL_0239;
										continue;
										end_IL_0183:
										break;
									}
									continue;
									end_IL_0193:
									break;
								}
								continue;
								end_IL_01b1:
								break;
							}
							continue;
							end_IL_01c1:
							break;
						}
						continue;
						end_IL_01d1:
						break;
					}
					continue;
					end_IL_01e1:
					break;
				}
				continue;
				end_IL_01f1:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_3, int int_4)
	{
		int num = 76;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 11;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SecurityEnabledFailFast.NumgetMayLeakOnAbort);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 34;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0282:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0265:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0255:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0245:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_01da:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 110;
																												while (true)
																												{
																													if (num != 110)
																													{
																														if (num != 1091)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 85:
																														case 91:
																															goto IL_01da;
																														case 92:
																															goto IL_0225;
																														case 28:
																															goto IL_0235;
																														case 31:
																															goto IL_0245;
																														case 101:
																															goto IL_0255;
																														case 22:
																															goto IL_0265;
																														case 54:
																															goto IL_0272;
																														case 23:
																															goto IL_0282;
																														case 34:
																															goto end_IL_0282;
																														case 33:
																														case 82:
																															goto end_IL_0292;
																														case 10:
																															goto IL_02b6;
																														case 20:
																														case 25:
																															goto IL_02c1;
																														case 24:
																															goto IL_02cf;
																														case 2:
																														case 48:
																															goto IL_02df;
																														case 66:
																															goto IL_02f6;
																														case 50:
																															goto IL_0319;
																														case 65:
																														case 67:
																															goto IL_0331;
																														case 61:
																															goto IL_037a;
																														case 46:
																															goto IL_038e;
																														case 44:
																														case 87:
																															goto IL_03aa;
																														case 68:
																															goto IL_03c3;
																														case 63:
																															goto IL_03da;
																														case 19:
																															goto IL_03e8;
																														case 94:
																															goto IL_03fb;
																														case 56:
																															goto IL_0409;
																														case 21:
																														case 98:
																															goto IL_041c;
																														case 18:
																															goto IL_0427;
																														case 69:
																														case 70:
																															goto IL_0435;
																														case 49:
																															goto IL_0463;
																														case 29:
																															goto IL_0471;
																														case 36:
																														case 37:
																															goto end_IL_01c7;
																														case 80:
																															goto IL_04bf;
																														case 3:
																															goto IL_04d3;
																														case 100:
																															goto IL_04e6;
																														case 14:
																															goto IL_04f4;
																														case 103:
																															goto IL_0510;
																														case 73:
																															goto IL_051e;
																														case 62:
																															goto IL_0545;
																														case 35:
																															goto IL_0558;
																														case 6:
																														case 74:
																															goto IL_0563;
																														case 57:
																															goto IL_0571;
																														case 78:
																														case 84:
																															goto IL_057f;
																														case 40:
																															goto IL_059b;
																														case 8:
																														case 86:
																															goto IL_05a6;
																														case 99:
																															goto IL_05e6;
																														case 17:
																															goto IL_05fa;
																														case 1:
																														case 15:
																														case 26:
																														case 27:
																														case 32:
																														case 38:
																														case 39:
																														case 45:
																														case 53:
																														case 58:
																														case 60:
																														case 71:
																														case 72:
																														case 88:
																														case 90:
																														case 93:
																														case 95:
																														case 102:
																															goto end_IL_0225;
																														case 5:
																															goto IL_062d;
																														case 51:
																															goto IL_063b;
																														case 89:
																															goto IL_0649;
																														case 0:
																														case 4:
																														case 9:
																														case 16:
																														case 42:
																														case 43:
																														case 47:
																														case 59:
																														case 81:
																														case 96:
																														case 97:
																															goto end_IL_02a2;
																														case 64:
																															goto end_IL_0657;
																														case 12:
																															goto end_IL_066a;
																														case 30:
																															goto end_IL_0674;
																														case 55:
																															goto end_IL_067f;
																														case 13:
																															goto end_IL_0694;
																														case 41:
																														case 83:
																															goto end_IL_06a9;
																														case 7:
																															goto end_IL_06b9;
																														case 11:
																														case 77:
																															goto end_IL_06c9;
																														case 75:
																															goto end_IL_06d9;
																														case 76:
																															goto end_IL_06e9;
																														case 52:
																														case 79:
																															goto IL_070d;
																														}
																														continue;
																													}
																													array[num5 - 2] = 0;
																													goto IL_0545;
																													IL_0545:
																													num5--;
																													goto end_IL_02a2;
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											goto IL_047f;
																											continue;
																											end_IL_0225:
																											break;
																											IL_0225:;
																										}
																										break;
																										IL_0235:;
																									}
																									break;
																								}
																								goto IL_03aa;
																								IL_03e8:
																								ptr2 += 8;
																								goto end_IL_02a2;
																								IL_03aa:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03c3;
																								IL_03c3:
																								array[num5] = 0;
																								num = 63;
																								goto IL_03da;
																								IL_03da:
																								num5++;
																								goto IL_03e8;
																							}
																							break;
																						}
																						goto IL_0558;
																						IL_05fa:
																						num5--;
																						goto end_IL_02a2;
																						IL_0558:
																						if (8 < b)
																						{
																							goto IL_0563;
																						}
																						goto IL_059b;
																						IL_0563:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0571;
																						IL_0571:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_057f;
																						IL_057f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02a2;
																						IL_059b:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_05a6;
																						IL_05a6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_05e6;
																						IL_05e6:
																						array[num5 - 2] = 0;
																						goto IL_05fa;
																					}
																					break;
																				}
																				goto IL_02b6;
																				IL_051e:
																				ptr2 += 8;
																				goto end_IL_02a2;
																				IL_02b6:
																				if (5 > b)
																				{
																					goto IL_02c1;
																				}
																				goto IL_02df;
																				IL_02c1:
																				if (2 >= b)
																				{
																					goto IL_02cf;
																				}
																				goto IL_041c;
																				IL_02cf:
																				if (2 <= b)
																				{
																					goto IL_0331;
																				}
																				goto IL_03fb;
																				IL_0331:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 61;
																				goto IL_037a;
																				IL_037a:
																				array[num5 - 2] = 0;
																				goto IL_038e;
																				IL_038e:
																				num5--;
																				num = 9;
																				goto end_IL_02a2;
																				IL_03fb:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0409;
																				IL_0409:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_041c:
																				if (3 >= b)
																				{
																					goto IL_0427;
																				}
																				goto IL_0463;
																				IL_0427:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0435;
																				IL_0435:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e6;
																				IL_04e6:
																				ptr2 += 8;
																				goto IL_04f4;
																				IL_04f4:
																				num5--;
																				num = 59;
																				goto end_IL_02a2;
																				IL_0463:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0471;
																				IL_0471:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_047f;
																				IL_047f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04bf;
																				IL_04bf:
																				array[num5 - 2] = 0;
																				goto IL_04d3;
																				IL_04d3:
																				num5--;
																				goto end_IL_02a2;
																				IL_02df:
																				array[num5] = 0;
																				num = 66;
																				goto IL_02f6;
																				IL_02f6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0319;
																				IL_0319:
																				array2[num5] = null;
																				num = 103;
																				goto IL_0510;
																				IL_0510:
																				num5++;
																				goto IL_051e;
																			}
																			break;
																			IL_0272:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_062d;
																	IL_0649:
																	ptr2 += 8;
																	goto end_IL_02a2;
																	IL_063b:
																	num5++;
																	goto IL_0649;
																	IL_062d:
																	array[num5] = 0;
																	goto IL_063b;
																	continue;
																	end_IL_0282:
																	break;
																}
																continue;
																end_IL_0292:
																break;
															}
															continue;
															end_IL_02a2:
															break;
														}
														continue;
													}
													goto IL_070d;
													IL_070d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0657:
													break;
												}
												continue;
												end_IL_066a:
												break;
											}
											continue;
											end_IL_0674:
											break;
										}
										continue;
										end_IL_067f:
										break;
									}
									continue;
									end_IL_0694:
									break;
								}
								continue;
								end_IL_06a9:
								break;
							}
							continue;
							end_IL_06b9:
							break;
						}
						continue;
						end_IL_06c9:
						break;
					}
					continue;
					end_IL_06d9:
					break;
				}
				continue;
				end_IL_06e9:
				break;
			}
		}
	}

	private unsafe static int smethod_19()
	{
		int num = 117;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTempFileNamesetCursorLeft.AesgetSequencePointCount);
										while (true)
										{
											IL_08aa:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0897:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0340:
														byte b = *ptr2;
														while (true)
														{
															IL_0330:
															ptr2++;
															while (true)
															{
																IL_0320:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0303:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02f6:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02e6:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02d6:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_028b:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_0272:
																														ptr2 += 8;
																														num = 148;
																														while (true)
																														{
																															if (num != 148)
																															{
																																if (num != 1129)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 55:
																																	goto IL_0272;
																																case 23:
																																case 109:
																																	goto IL_028b;
																																case 95:
																																	goto IL_02b6;
																																case 21:
																																case 44:
																																	goto IL_02c6;
																																case 9:
																																case 36:
																																	goto IL_02d6;
																																case 58:
																																	goto IL_02e6;
																																case 96:
																																	goto IL_02f6;
																																case 105:
																																	goto IL_0303;
																																case 137:
																																	goto IL_0310;
																																case 13:
																																	goto IL_0320;
																																case 130:
																																	goto IL_0330;
																																case 48:
																																case 49:
																																	goto IL_0340;
																																case 3:
																																	goto IL_034b;
																																case 51:
																																	goto IL_0356;
																																case 6:
																																case 82:
																																	goto IL_0366;
																																case 84:
																																	goto IL_037e;
																																case 26:
																																	goto IL_0389;
																																case 11:
																																	goto IL_039c;
																																case 62:
																																case 85:
																																	goto IL_03ac;
																																case 0:
																																	goto IL_03ba;
																																case 47:
																																	goto IL_03c5;
																																case 76:
																																	goto IL_03d3;
																																case 83:
																																case 86:
																																	goto IL_03e6;
																																case 28:
																																	goto IL_03f4;
																																case 2:
																																	goto IL_0417;
																																case 88:
																																	goto IL_0423;
																																case 93:
																																	goto IL_0436;
																																case 94:
																																	goto IL_0446;
																																case 80:
																																	goto IL_0454;
																																case 98:
																																	goto IL_0464;
																																case 50:
																																case 104:
																																	goto IL_0477;
																																case 10:
																																	goto IL_04b7;
																																case 38:
																																	goto IL_04cb;
																																case 67:
																																case 108:
																																	goto IL_04de;
																																case 16:
																																	goto IL_0522;
																																case 22:
																																case 115:
																																	goto IL_053b;
																																case 74:
																																case 120:
																																	goto IL_0557;
																																case 39:
																																	goto IL_0565;
																																case 31:
																																case 99:
																																	goto IL_0573;
																																case 113:
																																	goto IL_05d5;
																																case 140:
																																	goto IL_05e8;
																																case 92:
																																	goto IL_060e;
																																case 25:
																																case 69:
																																	goto IL_0619;
																																case 123:
																																	goto IL_0658;
																																case 136:
																																	goto IL_066b;
																																case 72:
																																	goto IL_0679;
																																case 61:
																																case 63:
																																	goto IL_0687;
																																case 78:
																																	goto IL_0695;
																																case 103:
																																	goto IL_06b6;
																																case 27:
																																	goto IL_06cd;
																																case 124:
																																	goto IL_06e0;
																																case 106:
																																	goto IL_06ee;
																																case 37:
																																	goto IL_06fc;
																																case 1:
																																case 56:
																																	goto IL_0707;
																																case 24:
																																	goto IL_0715;
																																case 20:
																																case 138:
																																	goto IL_0723;
																																case 141:
																																	goto IL_0745;
																																case 65:
																																	goto IL_0753;
																																case 129:
																																	goto IL_0761;
																																case 68:
																																case 70:
																																	goto IL_0774;
																																case 126:
																																	goto IL_07b4;
																																case 34:
																																	goto IL_07c8;
																																case 89:
																																	goto IL_07db;
																																case 17:
																																	goto IL_07e9;
																																case 42:
																																case 102:
																																	goto IL_07f7;
																																case 135:
																																	goto IL_0829;
																																case 114:
																																case 119:
																																	goto IL_083f;
																																case 133:
																																	goto IL_0866;
																																case 75:
																																	goto IL_0874;
																																case 4:
																																case 8:
																																case 12:
																																case 15:
																																case 30:
																																case 35:
																																case 41:
																																case 43:
																																case 45:
																																case 52:
																																case 59:
																																case 60:
																																case 66:
																																case 87:
																																case 90:
																																case 91:
																																case 101:
																																case 118:
																																case 122:
																																case 128:
																																case 131:
																																case 132:
																																case 134:
																																	goto end_IL_02b6;
																																case 5:
																																case 7:
																																case 14:
																																case 19:
																																case 40:
																																case 46:
																																case 54:
																																case 71:
																																case 73:
																																case 77:
																																case 81:
																																case 100:
																																case 107:
																																case 111:
																																case 112:
																																case 121:
																																case 125:
																																case 127:
																																	goto IL_0897;
																																case 53:
																																	goto IL_08aa;
																																case 18:
																																	goto end_IL_025f;
																																case 57:
																																	goto end_IL_08b4;
																																case 79:
																																	goto end_IL_08bf;
																																case 29:
																																case 32:
																																	goto end_IL_08cf;
																																case 33:
																																	goto end_IL_08df;
																																case 64:
																																case 110:
																																	goto end_IL_08ef;
																																case 116:
																																	goto end_IL_08ff;
																																case 117:
																																	goto end_IL_090f;
																																case 97:
																																case 139:
																																	goto IL_092a;
																																}
																																continue;
																															}
																															num5--;
																															goto IL_0897;
																															continue;
																															end_IL_025f:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_0320;
																												continue;
																												end_IL_02b6:
																												break;
																												IL_02b6:;
																											}
																											break;
																											IL_02c6:;
																										}
																										break;
																									}
																									goto IL_060e;
																									IL_06cd:
																									ptr2 += 8;
																									goto IL_0897;
																									IL_060e:
																									if (6 <= b)
																									{
																										goto IL_0619;
																									}
																									goto IL_066b;
																									IL_0619:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0658;
																									IL_0658:
																									num5 -= 3;
																									goto IL_0897;
																									IL_066b:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0679;
																									IL_0679:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_0687;
																									IL_0687:
																									array[num5] = 5;
																									goto IL_0695;
																									IL_0695:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									num = 103;
																									goto IL_06b6;
																									IL_06b6:
																									num5++;
																									num = 27;
																									goto IL_06cd;
																								}
																								break;
																							}
																							goto IL_06e0;
																							IL_0874:
																							num5--;
																							goto IL_0897;
																							IL_06e0:
																							if (4 > b)
																							{
																								goto IL_06ee;
																							}
																							goto IL_083f;
																							IL_06ee:
																							if (2 >= b)
																							{
																								goto IL_06fc;
																							}
																							goto IL_07db;
																							IL_06fc:
																							if (2 > b)
																							{
																								goto IL_0707;
																							}
																							goto IL_0774;
																							IL_0707:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0715;
																							IL_0715:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0723;
																							IL_0723:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							num = 141;
																							goto IL_0745;
																							IL_0745:
																							array[num5] = 0;
																							goto IL_0753;
																							IL_0753:
																							num5++;
																							goto IL_0761;
																							IL_0761:
																							ptr2 += 8;
																							goto IL_0897;
																							IL_0774:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07b4;
																							IL_07b4:
																							array[num5 - 2] = 0;
																							goto IL_07c8;
																							IL_07c8:
																							num5--;
																							goto IL_0897;
																							IL_07db:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_07e9;
																							IL_07e9:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_07f7;
																							IL_07f7:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							num = 135;
																							goto IL_0829;
																							IL_0829:
																							array[num5 - 1] = 5;
																							goto IL_0897;
																							IL_083f:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							num = 133;
																							goto IL_0866;
																							IL_0866:
																							ptr2 += 8;
																							goto IL_0874;
																						}
																						break;
																					}
																					goto IL_0366;
																					IL_0366:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_0897;
																				}
																				break;
																			}
																			goto IL_034b;
																			IL_0423:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_034b:
																			if (12 >= b)
																			{
																				goto IL_0356;
																			}
																			goto IL_037e;
																			IL_0356:
																			if (12 > b)
																			{
																				goto IL_03ac;
																			}
																			goto IL_0477;
																			IL_03ac:
																			if (10 >= b)
																			{
																				goto IL_03ba;
																			}
																			goto IL_0446;
																			IL_03ba:
																			if (10 > b)
																			{
																				goto IL_03c5;
																			}
																			goto IL_03e6;
																			IL_03c5:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_03d3;
																			IL_03d3:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0897;
																			IL_03e6:
																			array[num5] = 0;
																			goto IL_03f4;
																			IL_03f4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0417;
																			IL_0417:
																			array2[num5] = null;
																			goto IL_0436;
																			IL_0436:
																			num5++;
																			goto IL_0464;
																			IL_0464:
																			ptr2 += 8;
																			goto IL_0897;
																			IL_0446:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0454;
																			IL_0454:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_04de;
																			IL_04de:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0522;
																			IL_0522:
																			array[num5 - 2] = 0;
																			goto IL_05e8;
																			IL_05e8:
																			num5--;
																			goto IL_0897;
																			IL_0477:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b7;
																			IL_04b7:
																			array[num5 - 2] = 0;
																			goto IL_04cb;
																			IL_04cb:
																			num5--;
																			goto IL_0897;
																			IL_037e:
																			if (14 >= b)
																			{
																				goto IL_0389;
																			}
																			goto IL_039c;
																			IL_0389:
																			if (14 <= b)
																			{
																				goto IL_053b;
																			}
																			goto IL_0557;
																			IL_0557:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0565;
																			IL_0565:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0573;
																			IL_0573:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05d5;
																			IL_05d5:
																			num5 -= 2;
																			goto IL_0897;
																			IL_053b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_0897;
																			IL_039c:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0423;
																		}
																		break;
																		IL_0310:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_0897;
																continue;
																end_IL_0320:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_092a;
												IL_092a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										continue;
										end_IL_08b4:
										break;
									}
									continue;
									end_IL_08bf:
									break;
								}
								continue;
								end_IL_08cf:
								break;
							}
							continue;
							end_IL_08df:
							break;
						}
						continue;
						end_IL_08ef:
						break;
					}
					continue;
					end_IL_08ff:
					break;
				}
				continue;
				end_IL_090f:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_3)
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									num = 110;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MessageDictionaryNoKey.getRequiredContractIsAbstract);
										num = 29;
										while (true)
										{
											byte* ptr2 = ptr;
											num = 16;
											while (true)
											{
												num = 68;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02d3:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02b3:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_02a3:
																						if (6 > b)
																						{
																							num = 22;
																							while (true)
																							{
																								IL_0296:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0286:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_0256:
																														array[num5] = 0;
																														while (true)
																														{
																															IL_0231:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_0225:
																																array2[num5] = null;
																																while (true)
																																{
																																	IL_020c:
																																	num5++;
																																	num = 119;
																																	while (true)
																																	{
																																		if (num != 119)
																																		{
																																			if (num != 1100)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 63:
																																				goto IL_020c;
																																			case 92:
																																				goto IL_0225;
																																			case 95:
																																				goto IL_0231;
																																			case 79:
																																			case 81:
																																				goto IL_0256;
																																			case 100:
																																				goto IL_0266;
																																			case 59:
																																				goto IL_0276;
																																			case 111:
																																				goto IL_0286;
																																			case 22:
																																			case 94:
																																				goto IL_0296;
																																			case 23:
																																				goto IL_02a3;
																																			case 84:
																																				goto IL_02b3;
																																			case 52:
																																				goto IL_02c3;
																																			case 80:
																																				goto IL_02d3;
																																			case 13:
																																				goto end_IL_02d3;
																																			case 17:
																																			case 19:
																																				goto end_IL_02e3;
																																			case 18:
																																				goto IL_02fe;
																																			case 9:
																																			case 25:
																																				goto IL_030e;
																																			case 45:
																																				goto IL_0353;
																																			case 54:
																																				goto IL_0366;
																																			case 28:
																																				goto IL_0371;
																																			case 4:
																																			case 50:
																																				goto IL_0388;
																																			case 20:
																																				goto IL_03a1;
																																			case 11:
																																				goto IL_03b8;
																																			case 46:
																																				goto IL_03cb;
																																			case 33:
																																			case 56:
																																				goto IL_03de;
																																			case 44:
																																				goto IL_03ec;
																																			case 76:
																																			case 78:
																																				goto IL_03fa;
																																			case 65:
																																				goto IL_045c;
																																			case 72:
																																			case 82:
																																				goto IL_046f;
																																			case 83:
																																				goto IL_0487;
																																			case 12:
																																				goto IL_049b;
																																			case 30:
																																			case 96:
																																				goto IL_04ae;
																																			case 62:
																																				goto IL_04b9;
																																			case 37:
																																				goto IL_04cc;
																																			case 2:
																																				goto IL_04da;
																																			case 48:
																																			case 64:
																																				goto IL_04e8;
																																			case 43:
																																				goto IL_050b;
																																			case 55:
																																				goto IL_0519;
																																			case 27:
																																				goto IL_0527;
																																			case 97:
																																				goto IL_053a;
																																			case 15:
																																			case 71:
																																				goto IL_0548;
																																			case 24:
																																				goto IL_0556;
																																			case 106:
																																				goto IL_0569;
																																			case 69:
																																			case 104:
																																				goto IL_0577;
																																			case 39:
																																				goto IL_05a0;
																																			case 26:
																																				goto IL_05ae;
																																			case 34:
																																			case 107:
																																				goto end_IL_01f9;
																																			case 93:
																																				goto IL_0601;
																																			case 5:
																																				goto IL_0615;
																																			case 108:
																																				goto IL_0625;
																																			case 112:
																																				goto IL_0635;
																																			case 0:
																																			case 85:
																																				goto IL_0640;
																																			case 3:
																																			case 6:
																																			case 10:
																																			case 14:
																																			case 32:
																																			case 35:
																																			case 36:
																																			case 38:
																																			case 42:
																																			case 57:
																																			case 58:
																																			case 61:
																																			case 67:
																																			case 73:
																																			case 74:
																																			case 75:
																																			case 88:
																																			case 91:
																																			case 103:
																																			case 105:
																																			case 109:
																																				goto end_IL_0266;
																																			case 7:
																																			case 8:
																																			case 21:
																																			case 40:
																																			case 41:
																																			case 49:
																																			case 51:
																																			case 53:
																																			case 68:
																																			case 70:
																																			case 86:
																																			case 87:
																																			case 90:
																																				goto end_IL_02f3;
																																			case 16:
																																				goto end_IL_067c;
																																			case 29:
																																				goto end_IL_068f;
																																			case 110:
																																				goto end_IL_069a;
																																			case 66:
																																				goto end_IL_06ad;
																																			case 60:
																																				goto end_IL_06c1;
																																			case 1:
																																			case 89:
																																				goto end_IL_06df;
																																			case 102:
																																				goto end_IL_06ef;
																																			case 31:
																																			case 47:
																																				goto end_IL_06ff;
																																			case 98:
																																				goto end_IL_070f;
																																			case 99:
																																				goto end_IL_071f;
																																			case 77:
																																			case 101:
																																				goto IL_073a;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_02f3;
																																		continue;
																																		end_IL_01f9:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_05c1;
																													continue;
																													end_IL_0266:
																													break;
																													IL_0266:;
																												}
																												break;
																												IL_0276:;
																											}
																											break;
																										}
																										goto IL_0353;
																										IL_0353:
																										if (4 <= b)
																										{
																											goto end_IL_02f3;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02fe;
																								IL_05a0:
																								ptr2 += 8;
																								goto IL_05ae;
																								IL_02fe:
																								if (3 > b)
																								{
																									goto IL_0366;
																								}
																								goto IL_046f;
																								IL_046f:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02f3;
																								IL_0366:
																								if (1 >= b)
																								{
																									goto IL_0371;
																								}
																								goto IL_03cb;
																								IL_0371:
																								if (1 > b)
																								{
																									break;
																								}
																								num = 50;
																								goto IL_0388;
																								IL_05ae:
																								num5--;
																								goto end_IL_02f3;
																								IL_0388:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03a1;
																								IL_03a1:
																								array[num5] = 0;
																								num = 11;
																								goto IL_03b8;
																								IL_03b8:
																								num5++;
																								goto IL_0625;
																								IL_0625:
																								ptr2 += 8;
																								goto end_IL_02f3;
																								IL_03cb:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0569;
																								IL_0569:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0577;
																								IL_0577:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05a0;
																							}
																							break;
																						}
																						goto IL_030e;
																						IL_0487:
																						array[num5 - 2] = 0;
																						goto IL_049b;
																						IL_049b:
																						num5--;
																						goto end_IL_02f3;
																						IL_030e:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0487;
																					}
																					break;
																				}
																				goto IL_03de;
																				IL_0640:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02f3;
																				IL_03de:
																				if (9 >= b)
																				{
																					goto IL_03ec;
																				}
																				goto IL_053a;
																				IL_03ec:
																				if (9 <= b)
																				{
																					goto IL_03fa;
																				}
																				goto IL_04ae;
																				IL_03fa:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_045c;
																				IL_045c:
																				num5 -= 2;
																				goto end_IL_02f3;
																				IL_04ae:
																				if (7 >= b)
																				{
																					goto IL_04b9;
																				}
																				goto IL_04cc;
																				IL_04b9:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_05c1;
																				IL_05c1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0601;
																				IL_0601:
																				array[num5 - 2] = 0;
																				goto IL_0615;
																				IL_0615:
																				num5--;
																				goto end_IL_02f3;
																				IL_04cc:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_04da;
																				IL_04da:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_04e8;
																				IL_04e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_050b;
																				IL_050b:
																				array[num5] = 0;
																				goto IL_0519;
																				IL_0519:
																				num5++;
																				goto IL_0527;
																				IL_0527:
																				ptr2 += 8;
																				goto end_IL_02f3;
																				IL_053a:
																				if (10 < b)
																				{
																					goto IL_0548;
																				}
																				goto IL_0635;
																				IL_0548:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0556;
																				IL_0556:
																				if (11 > b)
																				{
																				}
																				break;
																				IL_0635:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0640;
																			}
																			break;
																			IL_02c3:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f3;
																	continue;
																	end_IL_02d3:
																	break;
																}
																continue;
																end_IL_02e3:
																break;
															}
															continue;
															end_IL_02f3:
															break;
														}
														continue;
													}
													goto IL_073a;
													IL_073a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_067c:
													break;
												}
												continue;
												end_IL_068f:
												break;
											}
											continue;
											end_IL_069a:
											break;
										}
										continue;
										end_IL_06ad:
										break;
									}
									continue;
									end_IL_06c1:
									break;
								}
								continue;
								end_IL_06df:
								break;
							}
							continue;
							end_IL_06ef:
							break;
						}
						continue;
						end_IL_06ff:
						break;
					}
					continue;
					end_IL_070f:
					break;
				}
				continue;
				end_IL_071f:
				break;
			}
		}
	}

	static Class101()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 11;
			while (true)
			{
				if (num != 11)
				{
					if (num == 992)
					{
						switch (num)
						{
						default:
							continue;
						case 4:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 3:
							return;
						}
					}
					break;
				}
				Class300.smethod_0();
				return;
			}
		}
	}
}
