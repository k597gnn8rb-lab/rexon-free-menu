using System;
using System.Runtime.CompilerServices;
using HarmonyLib;

[HarmonyPatch(typeof(GorillaTagger), "StartVibration")]
internal class Class189
{
	private static double double_0;

	private static double double_1;

	private static bool bool_0;

	private static float float_0;

	private static bool bool_1;

	private static int int_0;

	private static IntPtr[] IPermissionSetEntryReadWrite;

	private static IntPtr[] EncoderFallbackBuffergetIsProperty;

	private static IntPtr[] ShortestDayNamesCallback;

	private unsafe static bool Prefix()
	{
		int num = 12;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_0912:
						object[] array2 = new object[3];
						while (true)
						{
							IL_0902:
							int[] array3 = new int[6];
							while (true)
							{
								IL_08f2:
								long[] array4 = new long[3];
								while (true)
								{
									IL_08e7:
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getTimeOfDayPermissionTokenType.IsBrowserDisplayDataPtr);
									while (true)
									{
										IL_08dd:
										byte* ptr2 = ptr;
										while (true)
										{
											IL_08cd:
											if (num4 != 1)
											{
												while (true)
												{
													IL_02c8:
													byte b = *ptr2;
													while (true)
													{
														IL_02b8:
														ptr2++;
														while (true)
														{
															IL_02a8:
															if (b >= 1)
															{
																while (b <= 14)
																{
																	while (true)
																	{
																		IL_028b:
																		if (7 < b)
																		{
																			while (true)
																			{
																				IL_0278:
																				if (11 < b)
																				{
																					num = 146;
																					while (true)
																					{
																						if (num != 146)
																						{
																							if (num != 1127)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 30:
																								goto IL_0278;
																							case 95:
																								goto IL_028b;
																							case 24:
																								goto IL_0298;
																							case 1:
																								goto IL_02a8;
																							case 74:
																								goto IL_02b8;
																							case 14:
																							case 67:
																								goto IL_02c8;
																							case 21:
																								goto IL_02d3;
																							case 50:
																							case 111:
																								goto IL_02e7;
																							case 85:
																								goto IL_0327;
																							case 113:
																								goto IL_0344;
																							case 118:
																								goto IL_0357;
																							case 29:
																							case 82:
																								goto IL_0365;
																							case 100:
																								goto IL_037c;
																							case 49:
																								goto IL_038a;
																							case 122:
																								goto IL_0398;
																							case 37:
																							case 128:
																								goto IL_03a6;
																							case 69:
																								goto IL_03b4;
																							case 131:
																								goto IL_03d7;
																							case 62:
																								goto IL_03e1;
																							case 98:
																								goto IL_03ef;
																							case 133:
																								goto IL_0402;
																							case 47:
																								goto IL_040d;
																							case 45:
																							case 87:
																								goto IL_041b;
																							case 115:
																								goto IL_045b;
																							case 58:
																								goto IL_046f;
																							case 136:
																								goto IL_0490;
																							case 16:
																							case 27:
																								goto IL_049e;
																							case 83:
																								goto IL_04c7;
																							case 19:
																								goto IL_04de;
																							case 28:
																							case 137:
																								goto IL_04f1;
																							case 41:
																								goto IL_0531;
																							case 33:
																								goto IL_0545;
																							case 112:
																							case 138:
																								goto IL_0558;
																							case 117:
																								goto IL_0563;
																							case 53:
																							case 121:
																								goto IL_057f;
																							case 88:
																								goto IL_058d;
																							case 103:
																							case 106:
																								goto IL_059b;
																							case 70:
																								goto IL_05db;
																							case 119:
																								goto IL_05ef;
																							case 89:
																								goto IL_0602;
																							case 135:
																								goto IL_0610;
																							case 17:
																							case 108:
																								goto IL_061b;
																							case 51:
																								goto IL_0629;
																							case 79:
																							case 96:
																								goto IL_0637;
																							case 126:
																								goto IL_0645;
																							case 127:
																								goto IL_0669;
																							case 61:
																								goto IL_0677;
																							case 0:
																							case 63:
																								goto IL_0693;
																							case 6:
																								goto IL_06d4;
																							case 107:
																								goto IL_06e8;
																							case 60:
																								goto IL_06fb;
																							case 44:
																								goto IL_0709;
																							case 55:
																							case 92:
																								goto IL_0717;
																							case 134:
																								goto IL_0733;
																							case 3:
																								goto IL_0741;
																							case 129:
																								goto IL_074f;
																							case 109:
																							case 120:
																								goto IL_075a;
																							case 72:
																								goto IL_079a;
																							case 68:
																								goto IL_07ae;
																							case 43:
																								goto IL_07c1;
																							case 76:
																								goto IL_07cf;
																							case 36:
																							case 80:
																								goto IL_07dd;
																							case 22:
																								goto IL_07f0;
																							case 73:
																								goto IL_07fb;
																							case 40:
																							case 81:
																								goto IL_0806;
																							case 18:
																								goto IL_0868;
																							case 8:
																							case 10:
																							case 20:
																							case 25:
																							case 26:
																							case 31:
																							case 32:
																							case 34:
																							case 35:
																							case 38:
																							case 39:
																							case 46:
																							case 48:
																							case 56:
																							case 64:
																							case 75:
																							case 77:
																							case 86:
																							case 91:
																							case 93:
																							case 104:
																							case 105:
																							case 116:
																							case 123:
																							case 124:
																								goto end_IL_0298;
																							case 139:
																								goto IL_089a;
																							case 23:
																								goto IL_08b1;
																							case 42:
																								goto IL_08bf;
																							case 2:
																							case 4:
																							case 5:
																							case 7:
																							case 9:
																							case 15:
																							case 52:
																							case 54:
																							case 59:
																							case 65:
																							case 71:
																							case 84:
																							case 94:
																							case 99:
																							case 110:
																							case 114:
																							case 125:
																								goto IL_08cd;
																							case 97:
																								goto IL_08dd;
																							case 78:
																								goto IL_08e7;
																							case 66:
																								goto IL_08f2;
																							case 57:
																							case 101:
																								goto IL_0902;
																							case 132:
																								goto IL_0912;
																							case 13:
																							case 90:
																								goto end_IL_0265;
																							case 11:
																								goto end_IL_0922;
																							case 12:
																								goto end_IL_0932;
																							case 102:
																							case 130:
																								goto IL_094d;
																							}
																							continue;
																						}
																						goto IL_0602;
																						IL_0709:
																						if (14 > b)
																						{
																							goto end_IL_0298;
																						}
																						goto IL_0717;
																						IL_0717:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						goto IL_08cd;
																						IL_0602:
																						if (13 >= b)
																						{
																							goto IL_0610;
																						}
																						goto IL_06fb;
																						IL_0610:
																						if (13 > b)
																						{
																							goto IL_061b;
																						}
																						goto IL_0693;
																						IL_061b:
																						if (12 < b)
																						{
																							goto end_IL_0298;
																						}
																						goto IL_0629;
																						IL_0629:
																						if (12 > b)
																						{
																							goto end_IL_0298;
																						}
																						goto IL_0637;
																						IL_0637:
																						array[num6] = 0;
																						goto IL_0645;
																						IL_0645:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)IPermissionSetEntryReadWrite[*(int*)(ptr2 + num3)])() ? 1 : 0);
																						goto IL_0669;
																						IL_0669:
																						num6++;
																						goto IL_0677;
																						IL_0677:
																						ptr2 += 8;
																						num = 4;
																						goto IL_08cd;
																						IL_0693:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_06d4;
																						IL_06d4:
																						array[num6 - 2] = 0;
																						goto IL_06e8;
																						IL_06e8:
																						num6--;
																						goto IL_08cd;
																						IL_06fb:
																						if (14 < b)
																						{
																							goto end_IL_0298;
																						}
																						goto IL_0709;
																						continue;
																						end_IL_0265:
																						break;
																					}
																					break;
																				}
																				goto IL_0733;
																				IL_0806:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0868;
																				IL_0868:
																				num6 -= 2;
																				goto IL_08cd;
																				IL_0733:
																				if (11 <= b)
																				{
																					goto IL_08cd;
																				}
																				goto IL_0741;
																				IL_0741:
																				if (9 >= b)
																				{
																					goto IL_074f;
																				}
																				goto IL_07f0;
																				IL_074f:
																				if (9 <= b)
																				{
																					goto IL_075a;
																				}
																				goto IL_07c1;
																				IL_075a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_079a;
																				IL_079a:
																				array[num6 - 2] = 0;
																				goto IL_07ae;
																				IL_07ae:
																				num6--;
																				goto IL_08cd;
																				IL_07c1:
																				if (8 < b)
																				{
																					goto end_IL_0298;
																				}
																				goto IL_07cf;
																				IL_07cf:
																				if (8 > b)
																				{
																					goto end_IL_0298;
																				}
																				goto IL_07dd;
																				IL_07dd:
																				num6--;
																				goto IL_08cd;
																				IL_07f0:
																				if (10 < b)
																				{
																					num = 48;
																					goto end_IL_0298;
																				}
																				goto IL_07fb;
																				IL_07fb:
																				if (10 > b)
																				{
																					goto end_IL_0298;
																				}
																				goto IL_0806;
																			}
																			break;
																		}
																		goto IL_02d3;
																		IL_057f:
																		if (2 < b)
																		{
																			goto end_IL_0298;
																		}
																		goto IL_058d;
																		IL_02d3:
																		if (7 <= b)
																		{
																			num = 50;
																			goto IL_02e7;
																		}
																		goto IL_0357;
																		IL_058d:
																		if (2 > b)
																		{
																			goto end_IL_0298;
																		}
																		goto IL_059b;
																		IL_02e7:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0327;
																		IL_0327:
																		array[num6 - 2] = 0;
																		num = 113;
																		goto IL_0344;
																		IL_0344:
																		num6--;
																		goto IL_08cd;
																		IL_0357:
																		if (3 < b)
																		{
																			goto IL_0365;
																		}
																		goto IL_0490;
																		IL_0365:
																		if (5 >= b)
																		{
																			num = 100;
																			goto IL_037c;
																		}
																		goto IL_0402;
																		IL_059b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_05db;
																		IL_037c:
																		if (5 > b)
																		{
																			goto IL_038a;
																		}
																		goto IL_04f1;
																		IL_038a:
																		if (4 < b)
																		{
																			goto end_IL_0298;
																		}
																		goto IL_0398;
																		IL_0398:
																		if (4 > b)
																		{
																			goto end_IL_0298;
																		}
																		goto IL_03a6;
																		IL_03a6:
																		array[num6] = 0;
																		goto IL_03b4;
																		IL_03b4:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_03d7;
																		IL_03d7:
																		array2[num6] = null;
																		goto IL_03e1;
																		IL_03e1:
																		num6++;
																		goto IL_03ef;
																		IL_03ef:
																		ptr2 += 8;
																		goto IL_08cd;
																		IL_04f1:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0531;
																		IL_0531:
																		array[num6 - 2] = 0;
																		goto IL_0545;
																		IL_0545:
																		num6--;
																		goto IL_08cd;
																		IL_0402:
																		if (6 < b)
																		{
																			num = 93;
																			goto end_IL_0298;
																		}
																		goto IL_040d;
																		IL_040d:
																		if (6 > b)
																		{
																			goto end_IL_0298;
																		}
																		goto IL_041b;
																		IL_041b:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_045b;
																		IL_045b:
																		array[num6 - 2] = 0;
																		goto IL_046f;
																		IL_046f:
																		num6--;
																		goto IL_08cd;
																		IL_05db:
																		array[num6 - 2] = 0;
																		goto IL_05ef;
																		IL_0490:
																		if (3 <= b)
																		{
																			goto IL_049e;
																		}
																		goto IL_0558;
																		IL_049e:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_04c7;
																		IL_04c7:
																		ptr2 += 8;
																		num = 19;
																		goto IL_04de;
																		IL_04de:
																		num6--;
																		goto IL_08cd;
																		IL_0558:
																		if (1 >= b)
																		{
																			goto IL_0563;
																		}
																		num = 53;
																		goto IL_057f;
																		IL_0563:
																		if (1 > b)
																		{
																		}
																		goto end_IL_0298;
																		IL_05ef:
																		num6--;
																		goto IL_08cd;
																	}
																	goto end_IL_02a8;
																	continue;
																	end_IL_0298:
																	break;
																	IL_0298:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
															goto IL_089a;
															IL_08bf:
															ptr2 += 8;
															goto IL_08cd;
															IL_08b1:
															num6++;
															goto IL_08bf;
															IL_089a:
															array[num6] = 0;
															num = 23;
															goto IL_08b1;
															continue;
															end_IL_02a8:
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											goto IL_094d;
											IL_094d:
											return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_0922:
					break;
				}
				continue;
				end_IL_0932:
				break;
			}
		}
	}

	public Class189()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1, int int_2)
	{
		int num = 43;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 42;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PinningHelperThreadPoolWaitOrTimerCallback.ReadOnlyDictionaryKeyCollectionToTitleCase);
											num = 121;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 77;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0278:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_0248:
																							if (9 < b)
																							{
																								while (true)
																								{
																									IL_0238:
																									if (11 < b)
																									{
																										num = 130;
																										while (true)
																										{
																											if (num != 130)
																											{
																												if (num != 1111)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 46:
																													goto IL_0238;
																												case 102:
																												case 111:
																													goto IL_0248;
																												case 60:
																													goto end_IL_0248;
																												case 49:
																													goto end_IL_0258;
																												case 99:
																													goto IL_0278;
																												case 13:
																													goto end_IL_0278;
																												case 52:
																												case 115:
																													goto end_IL_0288;
																												case 92:
																													goto IL_02a3;
																												case 61:
																													goto IL_02ae;
																												case 83:
																													goto IL_02b9;
																												case 40:
																												case 63:
																													goto IL_02c7;
																												case 86:
																												case 96:
																													goto IL_02eb;
																												case 101:
																													goto IL_02fe;
																												case 50:
																													goto IL_0352;
																												case 78:
																													goto IL_0360;
																												case 36:
																													goto IL_037c;
																												case 67:
																													goto IL_038a;
																												case 2:
																												case 26:
																													goto IL_0398;
																												case 70:
																													goto IL_03bd;
																												case 23:
																													goto IL_03cb;
																												case 68:
																													goto IL_03d6;
																												case 15:
																												case 45:
																													goto IL_03e4;
																												case 97:
																													goto IL_03f2;
																												case 27:
																													goto IL_0415;
																												case 18:
																													goto IL_041f;
																												case 120:
																													goto IL_042d;
																												case 118:
																													goto IL_0440;
																												case 11:
																													goto IL_044e;
																												case 69:
																												case 109:
																													goto IL_045c;
																												case 66:
																													goto end_IL_0225;
																												case 88:
																													goto IL_048c;
																												case 119:
																													goto IL_049a;
																												case 35:
																												case 110:
																													goto IL_04ad;
																												case 98:
																													goto IL_04ed;
																												case 39:
																													goto IL_0501;
																												case 65:
																													goto IL_0514;
																												case 30:
																												case 58:
																													goto IL_0522;
																												case 14:
																													goto IL_0530;
																												case 34:
																												case 106:
																													goto IL_053e;
																												case 22:
																												case 48:
																													goto IL_054c;
																												case 82:
																													goto IL_055a;
																												case 33:
																												case 81:
																													goto IL_0568;
																												case 31:
																													goto IL_05d6;
																												case 64:
																													goto IL_05e9;
																												case 28:
																												case 84:
																													goto IL_05fc;
																												case 16:
																													goto IL_063c;
																												case 51:
																													goto IL_0650;
																												case 1:
																													goto IL_0663;
																												case 114:
																												case 122:
																													goto IL_066e;
																												case 53:
																													goto IL_0679;
																												case 9:
																												case 37:
																													goto IL_0684;
																												case 117:
																													goto IL_069c;
																												case 0:
																												case 72:
																													goto IL_06a7;
																												case 104:
																													goto IL_06d0;
																												case 8:
																													goto IL_06de;
																												case 4:
																												case 20:
																												case 21:
																												case 24:
																												case 44:
																												case 47:
																												case 54:
																												case 55:
																												case 57:
																												case 62:
																												case 71:
																												case 73:
																												case 74:
																												case 76:
																												case 79:
																												case 80:
																												case 87:
																												case 100:
																												case 105:
																												case 107:
																												case 113:
																													goto end_IL_0268;
																												case 95:
																													goto IL_0711;
																												case 17:
																													goto IL_071f;
																												case 12:
																													goto IL_072d;
																												case 3:
																												case 7:
																												case 10:
																												case 38:
																												case 75:
																												case 77:
																												case 89:
																												case 91:
																												case 93:
																												case 94:
																												case 103:
																												case 112:
																												case 116:
																												case 123:
																													goto end_IL_0298;
																												case 59:
																													goto end_IL_073b;
																												case 121:
																													goto end_IL_074e;
																												case 6:
																													goto end_IL_0759;
																												case 5:
																													goto end_IL_0763;
																												case 25:
																													goto end_IL_0777;
																												case 90:
																													goto end_IL_078c;
																												case 29:
																												case 32:
																													goto end_IL_07a1;
																												case 108:
																													goto end_IL_07b1;
																												case 56:
																												case 85:
																													goto end_IL_07c1;
																												case 42:
																													goto end_IL_07d1;
																												case 43:
																													goto end_IL_07e1;
																												case 19:
																												case 41:
																													goto IL_0805;
																												}
																												continue;
																											}
																											goto IL_037c;
																											IL_038a:
																											if (12 > b)
																											{
																												goto end_IL_0268;
																											}
																											goto IL_0398;
																											IL_0398:
																											byte* num5 = ptr2;
																											num4 = 1;
																											ptr2 = num5 + -200;
																											goto end_IL_0298;
																											IL_037c:
																											if (12 < b)
																											{
																												goto end_IL_0268;
																											}
																											goto IL_038a;
																											continue;
																											end_IL_0225:
																											break;
																										}
																										break;
																									}
																									goto IL_02a3;
																									IL_0360:
																									ptr2 += 8;
																									num = 75;
																									goto end_IL_0298;
																									IL_02eb:
																									num6--;
																									goto end_IL_0298;
																									IL_02a3:
																									if (11 > b)
																									{
																										goto IL_02ae;
																									}
																									goto IL_02eb;
																									IL_02ae:
																									if (10 < b)
																									{
																										num = 80;
																										goto end_IL_0268;
																									}
																									goto IL_02b9;
																									IL_02b9:
																									if (10 > b)
																									{
																										goto end_IL_0268;
																									}
																									goto IL_02c7;
																									IL_02c7:
																									array[num6 - 2] = 0;
																									goto IL_02fe;
																									IL_02fe:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)EncoderFallbackBuffergetIsProperty[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_0352;
																									IL_0352:
																									num6--;
																									goto IL_0360;
																								}
																								goto IL_0475;
																							}
																							num = 70;
																							goto IL_03bd;
																							IL_04ed:
																							array[num6 - 2] = 0;
																							goto IL_0501;
																							IL_0501:
																							num6--;
																							goto end_IL_0298;
																							IL_03bd:
																							if (9 > b)
																							{
																								goto IL_03cb;
																							}
																							goto IL_04ad;
																							IL_03cb:
																							if (7 >= b)
																							{
																								goto IL_03d6;
																							}
																							goto IL_0440;
																							IL_03d6:
																							if (7 > b)
																							{
																								goto end_IL_0268;
																							}
																							goto IL_03e4;
																							IL_03e4:
																							array[num6] = 0;
																							goto IL_03f2;
																							IL_03f2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0415;
																							IL_0415:
																							array2[num6] = null;
																							goto IL_041f;
																							IL_041f:
																							num6++;
																							goto IL_042d;
																							IL_042d:
																							ptr2 += 8;
																							goto end_IL_0298;
																							IL_0440:
																							if (8 < b)
																							{
																								goto end_IL_0268;
																							}
																							goto IL_044e;
																							IL_044e:
																							if (8 > b)
																							{
																								goto end_IL_0268;
																							}
																							goto IL_045c;
																							IL_045c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0475;
																							IL_0475:
																							array[num6] = 0;
																							num = 88;
																							goto IL_048c;
																							IL_048c:
																							num6++;
																							goto IL_049a;
																							IL_049a:
																							ptr2 += 8;
																							goto end_IL_0298;
																							IL_04ad:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_04ed;
																							continue;
																							end_IL_0248:
																							break;
																						}
																						continue;
																					}
																					goto IL_0514;
																					IL_06de:
																					num6--;
																					goto end_IL_0298;
																					IL_0514:
																					if (6 <= b)
																					{
																						goto end_IL_0298;
																					}
																					goto IL_0522;
																					IL_0522:
																					if (3 >= b)
																					{
																						goto IL_0530;
																					}
																					goto IL_0663;
																					IL_0530:
																					if (3 > b)
																					{
																						goto IL_053e;
																					}
																					goto IL_05fc;
																					IL_053e:
																					if (1 < b)
																					{
																						goto IL_054c;
																					}
																					goto IL_05e9;
																					IL_054c:
																					if (2 < b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_055a;
																					IL_055a:
																					if (2 > b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_0568;
																					IL_0568:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_05d6;
																					IL_05d6:
																					num6 -= 2;
																					goto end_IL_0298;
																					IL_05e9:
																					if (1 > b)
																					{
																					}
																					goto end_IL_0268;
																					IL_05fc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_063c;
																					IL_063c:
																					array[num6 - 2] = 0;
																					goto IL_0650;
																					IL_0650:
																					num6--;
																					goto end_IL_0298;
																					IL_0663:
																					if (4 < b)
																					{
																						goto IL_066e;
																					}
																					goto IL_069c;
																					IL_066e:
																					if (5 < b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_0679;
																					IL_0679:
																					if (5 > b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_0684;
																					IL_0684:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0298;
																					IL_069c:
																					if (4 > b)
																					{
																						goto end_IL_0268;
																					}
																					goto IL_06a7;
																					IL_06a7:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_06d0;
																					IL_06d0:
																					ptr2 += 8;
																					goto IL_06de;
																					continue;
																					end_IL_0258:
																					break;
																				}
																				continue;
																				end_IL_0268:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0711;
																		IL_072d:
																		ptr2 += 8;
																		goto end_IL_0298;
																		IL_071f:
																		num6++;
																		goto IL_072d;
																		IL_0711:
																		array[num6] = 0;
																		goto IL_071f;
																		continue;
																		end_IL_0278:
																		break;
																	}
																	continue;
																	end_IL_0288:
																	break;
																}
																continue;
																end_IL_0298:
																break;
															}
															continue;
														}
														goto IL_0805;
														IL_0805:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														continue;
														end_IL_073b:
														break;
													}
													continue;
													end_IL_074e:
													break;
												}
												continue;
												end_IL_0759:
												break;
											}
											continue;
											end_IL_0763:
											break;
										}
										continue;
										end_IL_0777:
										break;
									}
									continue;
									end_IL_078c:
									break;
								}
								continue;
								end_IL_07a1:
								break;
							}
							continue;
							end_IL_07b1:
							break;
						}
						continue;
						end_IL_07c1:
						break;
					}
					continue;
					end_IL_07d1:
					break;
				}
				continue;
				end_IL_07e1:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1, int int_2)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnsafeQueueNativeOverlappedAsyncFlowControl.IResourceGrovelerPrepareApplicationState);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_034e:
																	if (b < 1)
																	{
																		goto IL_0316;
																	}
																	goto IL_033e;
																	IL_033e:
																	if (b <= 9)
																	{
																		goto IL_0203;
																	}
																	goto IL_0316;
																	IL_0316:
																	while (true)
																	{
																		IL_0316_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01ea:
																			array[num5] = 0;
																			num = 114;
																			while (true)
																			{
																				if (num != 114)
																				{
																					if (num != 1095)
																					{
																						break;
																					}
																					switch (num)
																					{
																					case 78:
																						goto IL_01ea;
																					case 68:
																						goto IL_0203;
																					case 56:
																						goto IL_020e;
																					case 23:
																					case 67:
																						goto IL_021e;
																					case 53:
																						goto IL_0229;
																					case 44:
																					case 62:
																						goto end_IL_01d7;
																					case 5:
																						goto IL_0245;
																					case 82:
																						goto IL_0258;
																					case 58:
																					case 83:
																						goto IL_0263;
																					case 88:
																						goto IL_0273;
																					case 77:
																					case 80:
																						goto IL_0281;
																					case 38:
																						goto IL_0298;
																					case 89:
																						goto IL_02a5;
																					case 26:
																						goto IL_02b0;
																					case 48:
																						goto IL_02c9;
																					case 13:
																						goto IL_02d4;
																					case 92:
																						goto IL_02ed;
																					case 102:
																						goto IL_02fd;
																					case 49:
																						goto IL_0308;
																					case 1:
																					case 19:
																					case 21:
																					case 24:
																					case 30:
																					case 36:
																					case 40:
																					case 42:
																					case 46:
																					case 52:
																					case 55:
																					case 61:
																					case 70:
																					case 74:
																					case 76:
																					case 79:
																					case 81:
																					case 90:
																					case 93:
																					case 104:
																					case 106:
																						goto IL_0316_2;
																					case 98:
																						goto IL_033e;
																					case 50:
																						goto IL_034e;
																					case 8:
																						goto end_IL_034e;
																					case 27:
																					case 87:
																						goto end_IL_035b;
																					case 31:
																					case 51:
																						goto IL_0376;
																					case 20:
																						goto IL_0384;
																					case 41:
																						goto IL_03a7;
																					case 4:
																					case 17:
																						goto IL_03b6;
																					case 66:
																						goto IL_03cf;
																					case 34:
																						goto IL_03dd;
																					case 60:
																						goto IL_03eb;
																					case 11:
																					case 16:
																						goto IL_03fe;
																					case 25:
																						goto IL_043e;
																					case 69:
																						goto IL_0457;
																					case 37:
																					case 45:
																						goto IL_046a;
																					case 18:
																						goto IL_04aa;
																					case 14:
																						goto IL_04be;
																					case 9:
																					case 33:
																						goto IL_04d1;
																					case 84:
																						goto IL_0511;
																					case 10:
																					case 71:
																						goto IL_0527;
																					case 97:
																						goto IL_0543;
																					case 99:
																						goto IL_0556;
																					case 57:
																					case 95:
																						goto IL_0569;
																					case 43:
																						goto IL_05a9;
																					case 6:
																						goto IL_05bd;
																					case 28:
																					case 103:
																						goto IL_05cd;
																					case 100:
																						goto IL_05f6;
																					case 32:
																						goto IL_0604;
																					case 107:
																						goto IL_0614;
																					case 94:
																						goto IL_063b;
																					case 3:
																					case 39:
																					case 47:
																					case 59:
																					case 65:
																					case 72:
																					case 75:
																					case 85:
																					case 86:
																					case 91:
																					case 105:
																						goto end_IL_036b;
																					case 2:
																						goto end_IL_0649;
																					case 7:
																						goto end_IL_065c;
																					case 54:
																						goto end_IL_0666;
																					case 73:
																						goto end_IL_0671;
																					case 12:
																						goto end_IL_0686;
																					case 0:
																					case 96:
																						goto end_IL_069b;
																					case 101:
																						goto end_IL_06ab;
																					case 15:
																					case 29:
																						goto end_IL_06bb;
																					case 63:
																						goto end_IL_06cb;
																					case 64:
																						goto end_IL_06db;
																					case 22:
																					case 35:
																						goto IL_06f6;
																					}
																					continue;
																				}
																				num5++;
																				goto IL_063b;
																				IL_063b:
																				ptr2 += 8;
																				goto end_IL_036b;
																				continue;
																				end_IL_01d7:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0237;
																	IL_0203:
																	if (5 >= b)
																	{
																		goto IL_020e;
																	}
																	goto IL_021e;
																	IL_020e:
																	if (5 > b)
																	{
																		goto IL_0258;
																	}
																	goto IL_0376;
																	IL_0258:
																	if (2 < b)
																	{
																		goto IL_0263;
																	}
																	goto IL_0273;
																	IL_0263:
																	if (3 >= b)
																	{
																		goto IL_02ed;
																	}
																	goto IL_02fd;
																	IL_02ed:
																	if (3 > b)
																	{
																		goto IL_0316;
																	}
																	goto IL_05cd;
																	IL_05cd:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05f6;
																	IL_05f6:
																	ptr2 += 8;
																	goto IL_0604;
																	IL_0604:
																	num5--;
																	goto end_IL_036b;
																	IL_02fd:
																	if (4 >= b)
																	{
																		goto IL_0308;
																	}
																	goto IL_0316;
																	IL_0308:
																	if (4 > b)
																	{
																		goto IL_0316;
																	}
																	goto IL_0569;
																	IL_0569:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05a9;
																	IL_05a9:
																	array[num5 - 2] = 0;
																	goto IL_05bd;
																	IL_05bd:
																	num5--;
																	goto end_IL_036b;
																	IL_0273:
																	if (2 > b)
																	{
																		goto IL_0281;
																	}
																	goto IL_046a;
																	IL_0281:
																	if (1 >= b)
																	{
																		num = 38;
																		goto IL_0298;
																	}
																	goto IL_0316;
																	IL_02d4:
																	if (9 > b)
																	{
																		num = 52;
																		goto IL_0316;
																	}
																	goto IL_0527;
																	IL_0298:
																	if (1 > b)
																	{
																	}
																	goto IL_0316;
																	IL_046a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04aa;
																	IL_04aa:
																	array[num5 - 2] = 0;
																	goto IL_04be;
																	IL_04be:
																	num5--;
																	goto end_IL_036b;
																	IL_0376:
																	array[num5] = 0;
																	goto IL_0384;
																	IL_0384:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_03a7;
																	IL_03a7:
																	array2[num5] = null;
																	goto IL_0457;
																	IL_0457:
																	num5++;
																	goto IL_0543;
																	IL_0543:
																	ptr2 += 8;
																	goto end_IL_036b;
																	IL_021e:
																	if (7 >= b)
																	{
																		goto IL_0229;
																	}
																	goto IL_02a5;
																	IL_0229:
																	if (7 > b)
																	{
																		goto IL_0237;
																	}
																	goto IL_03b6;
																	IL_0237:
																	if (6 >= b)
																	{
																		goto IL_0245;
																	}
																	goto IL_0316;
																	IL_0245:
																	if (6 > b)
																	{
																		goto IL_0316;
																	}
																	goto IL_03fe;
																	IL_03fe:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_043e;
																	IL_043e:
																	array[num5 - 2] = 0;
																	goto IL_0614;
																	IL_0614:
																	num5--;
																	num = 91;
																	goto end_IL_036b;
																	IL_03b6:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_03cf;
																	IL_03cf:
																	array[num5] = 0;
																	goto IL_03dd;
																	IL_03dd:
																	num5++;
																	goto IL_03eb;
																	IL_03eb:
																	ptr2 += 8;
																	goto end_IL_036b;
																	IL_02a5:
																	if (8 >= b)
																	{
																		goto IL_02b0;
																	}
																	goto IL_02c9;
																	IL_02b0:
																	if (8 > b)
																	{
																		num = 36;
																		goto IL_0316;
																	}
																	goto IL_04d1;
																	IL_0527:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_036b;
																	IL_04d1:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0511;
																	IL_0511:
																	array[num5 - 2] = 0;
																	goto IL_0556;
																	IL_0556:
																	num5--;
																	goto end_IL_036b;
																	IL_02c9:
																	if (9 >= b)
																	{
																		goto IL_02d4;
																	}
																	goto IL_0316;
																	continue;
																	end_IL_034e:
																	break;
																}
																continue;
																end_IL_035b:
																break;
															}
															continue;
															end_IL_036b:
															break;
														}
														continue;
													}
													goto IL_06f6;
													IL_06f6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0649:
													break;
												}
												continue;
												end_IL_065c:
												break;
											}
											continue;
											end_IL_0666:
											break;
										}
										continue;
										end_IL_0671:
										break;
									}
									continue;
									end_IL_0686:
									break;
								}
								continue;
								end_IL_069b:
								break;
							}
							continue;
							end_IL_06ab:
							break;
						}
						continue;
						end_IL_06bb:
						break;
					}
					continue;
					end_IL_06cb:
					break;
				}
				continue;
				end_IL_06db:
				break;
			}
		}
	}

	private static int smethod_2(int int_1, int int_2)
	{
		int num = int_1;
		int num2 = int_2;
		num += num2;
		int num3 = num;
		num = int_1;
		num2 = int_2;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 1089;
		num2 = 99;
		num += 99;
		num2 = 154;
		num2 = 22;
		int num6 = smethod_7(22, 41);
		num2 = num6;
		return num;
	}

	private static int smethod_3(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentAssemblyDefineResource.FixedSafeCompressedStackHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 60;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0275:
																if (b >= 1)
																{
																	num = 92;
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0248:
																					if (5 > b)
																					{
																						goto IL_04a3;
																					}
																					while (true)
																					{
																						IL_0238:
																						array[num5] = 0;
																						while (true)
																						{
																							IL_020a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							num = 20;
																							while (true)
																							{
																								IL_01f5:
																								array2[num5] = null;
																								num = 54;
																								while (true)
																								{
																									IL_01dc:
																									num5++;
																									num = 107;
																									while (true)
																									{
																										if (num != 107)
																										{
																											if (num != 1088)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 54:
																												goto IL_01dc;
																											case 20:
																												goto IL_01f5;
																											case 31:
																												goto IL_020a;
																											case 46:
																											case 74:
																												goto IL_0238;
																											case 17:
																												goto IL_0248;
																											case 9:
																												goto end_IL_0248;
																											case 92:
																												goto end_IL_0258;
																											case 91:
																												goto IL_0275;
																											case 60:
																												goto end_IL_0275;
																											case 7:
																											case 18:
																												goto end_IL_0288;
																											case 34:
																											case 45:
																												goto IL_02ac;
																											case 25:
																												goto IL_02b7;
																											case 42:
																												goto IL_02c5;
																											case 15:
																											case 43:
																												goto IL_02d3;
																											case 95:
																												goto IL_02ef;
																											case 69:
																											case 71:
																												goto IL_02fa;
																											case 14:
																												goto IL_0361;
																											case 49:
																											case 80:
																												goto IL_036c;
																											case 37:
																												goto IL_037a;
																											case 53:
																												goto IL_038a;
																											case 84:
																											case 87:
																												goto IL_0398;
																											case 61:
																												goto IL_03d8;
																											case 33:
																												goto IL_03ec;
																											case 73:
																											case 96:
																												goto IL_03ff;
																											case 79:
																												goto IL_0422;
																											case 13:
																												goto IL_0430;
																											case 11:
																												goto IL_043e;
																											case 98:
																												goto IL_0451;
																											case 24:
																											case 100:
																												goto IL_0464;
																											case 76:
																												goto IL_046f;
																											case 26:
																												goto IL_04a3;
																											case 5:
																												goto IL_04b1;
																											case 22:
																											case 93:
																												goto IL_04bc;
																											case 94:
																												goto end_IL_01c9;
																											case 19:
																												goto IL_04f3;
																											case 1:
																												goto IL_050f;
																											case 77:
																												goto IL_051d;
																											case 29:
																											case 70:
																												goto IL_052b;
																											case 38:
																												goto IL_0544;
																											case 27:
																												goto IL_0552;
																											case 44:
																												goto IL_0560;
																											case 63:
																												goto IL_0570;
																											case 62:
																												goto IL_057b;
																											case 50:
																											case 52:
																												goto IL_0586;
																											case 35:
																												goto IL_059b;
																											case 4:
																												goto IL_05a6;
																											case 2:
																											case 8:
																											case 10:
																											case 12:
																											case 23:
																											case 30:
																											case 36:
																											case 39:
																											case 40:
																											case 47:
																											case 48:
																											case 51:
																											case 57:
																											case 59:
																											case 81:
																											case 86:
																											case 97:
																												goto end_IL_0265;
																											case 0:
																											case 6:
																											case 16:
																											case 21:
																											case 32:
																											case 41:
																											case 65:
																											case 66:
																											case 68:
																											case 72:
																											case 78:
																											case 82:
																											case 90:
																												goto end_IL_0298;
																											case 99:
																												goto end_IL_05c4;
																											case 56:
																												goto end_IL_05d7;
																											case 64:
																												goto end_IL_05e1;
																											case 3:
																												goto end_IL_05ec;
																											case 55:
																											case 58:
																												goto end_IL_0601;
																											case 83:
																												goto end_IL_0611;
																											case 75:
																											case 85:
																												goto end_IL_0621;
																											case 88:
																												goto end_IL_0631;
																											case 89:
																												goto end_IL_0641;
																											case 28:
																											case 67:
																												goto IL_065c;
																											}
																											continue;
																										}
																										ptr2 += 8;
																										goto end_IL_0298;
																										continue;
																										end_IL_01c9:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_04e5;
																					IL_05a6:
																					if (4 <= b)
																					{
																						goto end_IL_0298;
																					}
																					goto end_IL_0265;
																					IL_04a3:
																					if (2 >= b)
																					{
																						goto IL_04b1;
																					}
																					goto IL_0570;
																					IL_04b1:
																					if (2 <= b)
																					{
																						goto IL_04bc;
																					}
																					goto IL_050f;
																					IL_04bc:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04e5;
																					IL_04e5:
																					ptr2 += 8;
																					goto IL_04f3;
																					IL_04f3:
																					num5--;
																					num = 16;
																					goto end_IL_0298;
																					IL_050f:
																					if (1 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_051d;
																					IL_051d:
																					if (1 > b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_052b;
																					IL_052b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0544;
																					IL_0544:
																					array[num5] = 0;
																					goto IL_0552;
																					IL_0552:
																					num5++;
																					goto IL_0560;
																					IL_0560:
																					ptr2 += 8;
																					goto end_IL_0298;
																					IL_0570:
																					if (3 >= b)
																					{
																						goto IL_057b;
																					}
																					goto IL_059b;
																					IL_057b:
																					if (3 > b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_0586;
																					IL_0586:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0298;
																					IL_059b:
																					if (4 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_05a6;
																					continue;
																					end_IL_0248:
																					break;
																				}
																				continue;
																			}
																			goto IL_02ac;
																			IL_03d8:
																			array[num5 - 2] = 0;
																			goto IL_03ec;
																			IL_02ac:
																			if (8 < b)
																			{
																				goto IL_02b7;
																			}
																			goto IL_02ef;
																			IL_02b7:
																			if (9 >= b)
																			{
																				goto IL_02c5;
																			}
																			goto IL_0464;
																			IL_02c5:
																			if (9 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_02d3;
																			IL_02d3:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0298;
																			IL_0464:
																			if (10 < b)
																			{
																				num = 23;
																				goto end_IL_0265;
																			}
																			goto IL_046f;
																			IL_046f:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_0265;
																			IL_03ec:
																			num5--;
																			goto end_IL_0298;
																			IL_02ef:
																			if (8 <= b)
																			{
																				goto IL_02fa;
																			}
																			goto IL_0361;
																			IL_02fa:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0451;
																			IL_0451:
																			num5 -= 2;
																			goto end_IL_0298;
																			IL_0361:
																			if (6 < b)
																			{
																				goto IL_036c;
																			}
																			goto IL_038a;
																			IL_036c:
																			if (7 < b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_037a;
																			IL_037a:
																			if (7 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_03ff;
																			IL_03ff:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0422;
																			IL_0422:
																			array[num5] = 0;
																			goto IL_0430;
																			IL_0430:
																			num5++;
																			goto IL_043e;
																			IL_043e:
																			ptr2 += 8;
																			goto end_IL_0298;
																			IL_038a:
																			if (6 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_0398;
																			IL_0398:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03d8;
																			continue;
																			end_IL_0258:
																			break;
																		}
																		continue;
																		end_IL_0265:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0298;
																continue;
																end_IL_0275:
																break;
															}
															continue;
															end_IL_0288:
															break;
														}
														continue;
														end_IL_0298:
														break;
													}
													continue;
												}
												goto IL_065c;
												IL_065c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c4:
												break;
											}
											continue;
											end_IL_05d7:
											break;
										}
										continue;
										end_IL_05e1:
										break;
									}
									continue;
									end_IL_05ec:
									break;
								}
								continue;
								end_IL_0601:
								break;
							}
							continue;
							end_IL_0611:
							break;
						}
						continue;
						end_IL_0621:
						break;
					}
					continue;
					end_IL_0631:
					break;
				}
				continue;
				end_IL_0641:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FoundYearPatternFlagGenerics.AccessMaskTreatAsSafe);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0275:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0258:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0248:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0238:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_0213:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_0207:
																									array2[num5] = null;
																									while (true)
																									{
																										IL_01ee:
																										num5++;
																										num = 115;
																										while (true)
																										{
																											if (num != 115)
																											{
																												if (num != 1096)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 37:
																													goto IL_01ee;
																												case 17:
																													goto IL_0207;
																												case 26:
																													goto IL_0213;
																												case 91:
																												case 97:
																													goto IL_0238;
																												case 83:
																													goto IL_0248;
																												case 92:
																													goto IL_0258;
																												case 100:
																													goto IL_0265;
																												case 76:
																													goto IL_0275;
																												case 53:
																													goto end_IL_01db;
																												case 10:
																												case 18:
																													goto end_IL_0285;
																												case 80:
																												case 89:
																													goto IL_02a0;
																												case 54:
																													goto IL_02ae;
																												case 62:
																												case 67:
																													goto IL_02b9;
																												case 22:
																													goto IL_031b;
																												case 41:
																													goto IL_032e;
																												case 47:
																												case 70:
																													goto IL_0339;
																												case 19:
																													goto IL_0347;
																												case 38:
																												case 65:
																													goto IL_0355;
																												case 51:
																													goto IL_0378;
																												case 9:
																													goto IL_0386;
																												case 74:
																													goto IL_0394;
																												case 46:
																													goto IL_03a7;
																												case 99:
																												case 101:
																													goto IL_03b5;
																												case 21:
																													goto IL_03f5;
																												case 79:
																													goto IL_0409;
																												case 66:
																												case 108:
																													goto IL_041c;
																												case 0:
																												case 52:
																													goto IL_0427;
																												case 16:
																													goto IL_0435;
																												case 27:
																													goto IL_0451;
																												case 15:
																												case 31:
																													goto IL_045f;
																												case 60:
																													goto IL_048e;
																												case 13:
																												case 24:
																													goto IL_0499;
																												case 39:
																													goto IL_04a4;
																												case 36:
																													goto IL_04b2;
																												case 2:
																													goto IL_04c5;
																												case 8:
																												case 20:
																													goto IL_04d3;
																												case 11:
																													goto IL_04eb;
																												case 58:
																												case 59:
																													goto IL_04f6;
																												case 90:
																													goto IL_051f;
																												case 34:
																													goto IL_052d;
																												case 5:
																												case 32:
																													goto IL_053d;
																												case 86:
																													goto IL_0548;
																												case 29:
																												case 106:
																													goto IL_055c;
																												case 103:
																													goto IL_0575;
																												case 49:
																													goto IL_0583;
																												case 71:
																													goto IL_0591;
																												case 12:
																												case 14:
																												case 23:
																												case 30:
																												case 42:
																												case 43:
																												case 44:
																												case 48:
																												case 50:
																												case 55:
																												case 57:
																												case 61:
																												case 68:
																												case 73:
																												case 75:
																												case 78:
																												case 82:
																												case 84:
																												case 87:
																												case 93:
																												case 95:
																												case 102:
																													goto end_IL_0265;
																												case 3:
																												case 7:
																												case 25:
																												case 28:
																												case 33:
																												case 35:
																												case 45:
																												case 56:
																												case 77:
																												case 85:
																												case 96:
																												case 98:
																												case 104:
																													goto end_IL_0295;
																												case 72:
																													goto end_IL_05b4;
																												case 105:
																													goto end_IL_05c7;
																												case 6:
																													goto end_IL_05d1;
																												case 94:
																													goto end_IL_05dc;
																												case 40:
																												case 88:
																													goto end_IL_05f1;
																												case 4:
																													goto end_IL_0601;
																												case 1:
																												case 69:
																													goto end_IL_0611;
																												case 63:
																													goto end_IL_0621;
																												case 64:
																													goto end_IL_0631;
																												case 81:
																												case 107:
																													goto IL_0655;
																												}
																												continue;
																											}
																											ptr2 += 8;
																											goto end_IL_0295;
																											continue;
																											end_IL_01db:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_048e;
																					IL_0583:
																					num5++;
																					goto IL_0591;
																					IL_048e:
																					if (2 < b)
																					{
																						goto IL_0499;
																					}
																					goto IL_04eb;
																					IL_0499:
																					if (3 < b)
																					{
																						goto IL_04a4;
																					}
																					goto IL_04c5;
																					IL_04a4:
																					if (4 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_04b2;
																					IL_04b2:
																					if (4 <= b)
																					{
																						goto end_IL_0295;
																					}
																					goto end_IL_0265;
																					IL_04c5:
																					if (3 > b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_04d3;
																					IL_04d3:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0295;
																					IL_04eb:
																					if (2 <= b)
																					{
																						goto IL_04f6;
																					}
																					goto IL_053d;
																					IL_04f6:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_051f;
																					IL_051f:
																					ptr2 += 8;
																					goto IL_052d;
																					IL_052d:
																					num5--;
																					goto end_IL_0295;
																					IL_053d:
																					if (1 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_0548;
																					IL_0548:
																					if (1 > b)
																					{
																						goto end_IL_0265;
																					}
																					num = 106;
																					goto IL_055c;
																					IL_0591:
																					ptr2 += 8;
																					goto end_IL_0295;
																					IL_055c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0575;
																					IL_0575:
																					array[num5] = 0;
																					goto IL_0583;
																				}
																				break;
																			}
																			goto IL_02a0;
																			IL_0451:
																			if (9 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_045f;
																			IL_02a0:
																			if (8 >= b)
																			{
																				goto IL_02ae;
																			}
																			goto IL_041c;
																			IL_02ae:
																			if (8 <= b)
																			{
																				goto IL_02b9;
																			}
																			goto IL_032e;
																			IL_02b9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_031b;
																			IL_031b:
																			num5 -= 2;
																			goto end_IL_0295;
																			IL_032e:
																			if (6 < b)
																			{
																				goto IL_0339;
																			}
																			goto IL_03a7;
																			IL_0339:
																			if (7 < b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_0347;
																			IL_0347:
																			if (7 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_0355;
																			IL_0355:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0378;
																			IL_0378:
																			array[num5] = 0;
																			goto IL_0386;
																			IL_0386:
																			num5++;
																			goto IL_0394;
																			IL_0394:
																			ptr2 += 8;
																			goto end_IL_0295;
																			IL_03a7:
																			if (6 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_03b5;
																			IL_03b5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03f5;
																			IL_03f5:
																			array[num5 - 2] = 0;
																			goto IL_0409;
																			IL_0409:
																			num5--;
																			goto end_IL_0295;
																			IL_041c:
																			if (9 < b)
																			{
																				goto IL_0427;
																			}
																			goto IL_0451;
																			IL_0427:
																			if (10 < b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_0435;
																			IL_0435:
																			if (10 > b)
																			{
																				num = 12;
																			}
																			goto end_IL_0265;
																			IL_045f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0295;
																		}
																		goto end_IL_0275;
																		continue;
																		end_IL_0265:
																		break;
																		IL_0265:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0295;
																continue;
																end_IL_0275:
																break;
															}
															continue;
															end_IL_0285:
															break;
														}
														continue;
														end_IL_0295:
														break;
													}
													continue;
												}
												num = 81;
												goto IL_0655;
												IL_0655:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b4:
												break;
											}
											continue;
											end_IL_05c7:
											break;
										}
										continue;
										end_IL_05d1:
										break;
									}
									continue;
									end_IL_05dc:
									break;
								}
								continue;
								end_IL_05f1:
								break;
							}
							continue;
							end_IL_0601:
							break;
						}
						continue;
						end_IL_0611:
						break;
					}
					continue;
					end_IL_0621:
					break;
				}
				continue;
				end_IL_0631:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1, int int_2)
	{
		int num = 93;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 12;
						while (true)
						{
							num = 123;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											num = 84;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WinBuiltinTerminalServerLicenseServersSidAdapter.OpenOrCreateCategoryMembershipSection);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_02cc:
																byte b = *ptr2;
																while (true)
																{
																	IL_02bc:
																	ptr2++;
																	while (true)
																	{
																		IL_02ac:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_028f:
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_027f:
																							if (6 > b)
																							{
																								while (true)
																								{
																									IL_026f:
																									if (3 < b)
																									{
																										while (true)
																										{
																											IL_025f:
																											if (4 < b)
																											{
																												while (5 >= b)
																												{
																													while (true)
																													{
																														IL_023c:
																														if (5 > b)
																														{
																															num = 131;
																															while (num != 131)
																															{
																																if (num != 1112)
																																{
																																	goto end_IL_02ac;
																																}
																																switch (num)
																																{
																																case 54:
																																	goto IL_023c;
																																case 13:
																																case 42:
																																	goto IL_024f;
																																case 64:
																																case 83:
																																	goto IL_025f;
																																case 23:
																																case 78:
																																	goto IL_026f;
																																case 35:
																																	goto IL_027f;
																																case 41:
																																	goto IL_028f;
																																case 15:
																																	goto IL_029c;
																																case 122:
																																	goto IL_02ac;
																																case 80:
																																	goto IL_02bc;
																																case 65:
																																case 71:
																																	goto IL_02cc;
																																case 9:
																																case 69:
																																	goto IL_02d7;
																																case 17:
																																case 106:
																																	goto IL_02ea;
																																case 11:
																																case 89:
																																	goto IL_02f5;
																																case 39:
																																case 103:
																																	goto IL_0303;
																																case 52:
																																	goto IL_0316;
																																case 70:
																																case 75:
																																	goto IL_0321;
																																case 63:
																																	goto IL_032f;
																																case 8:
																																case 73:
																																	goto IL_033d;
																																case 43:
																																	goto IL_0356;
																																case 24:
																																case 44:
																																	goto IL_0366;
																																case 21:
																																	goto IL_037a;
																																case 3:
																																	goto IL_03b9;
																																case 108:
																																	goto IL_03cc;
																																case 62:
																																	goto IL_03da;
																																case 110:
																																	goto IL_03ed;
																																case 67:
																																case 74:
																																	goto IL_03fb;
																																case 114:
																																	goto IL_0417;
																																case 60:
																																	goto IL_0425;
																																case 48:
																																case 97:
																																	goto IL_0433;
																																case 36:
																																	goto IL_0473;
																																case 98:
																																	goto IL_0487;
																																case 115:
																																	goto IL_049a;
																																case 104:
																																	goto IL_04bd;
																																case 26:
																																	goto IL_04c7;
																																case 16:
																																	goto IL_04d5;
																																case 117:
																																	goto IL_04e8;
																																case 4:
																																case 20:
																																	goto IL_04f6;
																																case 51:
																																	goto IL_0512;
																																case 90:
																																case 109:
																																	goto IL_0529;
																																case 118:
																																	goto IL_0569;
																																case 120:
																																	goto IL_0586;
																																case 19:
																																	goto IL_0599;
																																case 95:
																																case 119:
																																	goto IL_05a7;
																																case 14:
																																	goto IL_05b5;
																																case 37:
																																	goto IL_05c3;
																																case 32:
																																case 102:
																																	goto IL_05d1;
																																case 1:
																																	goto IL_0611;
																																case 47:
																																	goto IL_0625;
																																case 113:
																																	goto IL_0638;
																																case 6:
																																case 10:
																																	goto IL_064b;
																																case 87:
																																	goto IL_0674;
																																case 61:
																																	goto IL_0682;
																																case 100:
																																case 116:
																																	goto IL_0695;
																																case 112:
																																	goto IL_06d5;
																																case 91:
																																	goto IL_06e9;
																																case 2:
																																case 5:
																																case 22:
																																case 28:
																																case 31:
																																case 38:
																																case 40:
																																case 45:
																																case 46:
																																case 49:
																																case 55:
																																case 56:
																																case 76:
																																case 79:
																																case 86:
																																case 88:
																																case 96:
																																case 99:
																																case 101:
																																case 111:
																																case 121:
																																	goto end_IL_0229;
																																case 85:
																																	goto IL_071c;
																																case 72:
																																	goto IL_072a;
																																case 29:
																																	goto IL_0738;
																																case 0:
																																case 25:
																																case 30:
																																case 57:
																																case 58:
																																case 59:
																																case 66:
																																case 77:
																																case 81:
																																case 82:
																																case 94:
																																case 105:
																																case 107:
																																	goto end_IL_02ac;
																																case 53:
																																	goto end_IL_0746;
																																case 84:
																																	goto end_IL_0759;
																																case 27:
																																	goto end_IL_0763;
																																case 50:
																																	goto end_IL_076e;
																																case 18:
																																	goto end_IL_078c;
																																case 123:
																																	goto end_IL_07a1;
																																case 12:
																																	goto end_IL_07b1;
																																case 7:
																																	goto end_IL_07c1;
																																case 33:
																																case 34:
																																	goto end_IL_07cc;
																																case 92:
																																	goto end_IL_07e5;
																																case 93:
																																	goto end_IL_07f5;
																																case 68:
																																case 124:
																																	goto IL_0810;
																																}
																																continue;
																																end_IL_0229:
																																break;
																															}
																															break;
																														}
																														goto IL_02d7;
																														IL_04c7:
																														num5++;
																														goto IL_04d5;
																														IL_04d5:
																														ptr2 += 8;
																														goto end_IL_02ac;
																														IL_02d7:
																														array[num5] = 0;
																														goto IL_049a;
																														IL_049a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														goto IL_04bd;
																														IL_04bd:
																														array2[num5] = null;
																														goto IL_04c7;
																													}
																													break;
																													IL_024f:;
																												}
																												break;
																											}
																											goto IL_0512;
																											IL_0569:
																											array[num5 - 2] = 0;
																											num = 120;
																											goto IL_0586;
																											IL_0512:
																											if (4 > b)
																											{
																												break;
																											}
																											num = 109;
																											goto IL_0529;
																											IL_0586:
																											num5--;
																											goto end_IL_02ac;
																											IL_0529:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0569;
																										}
																										break;
																									}
																									goto IL_0599;
																									IL_0682:
																									num5--;
																									goto end_IL_02ac;
																									IL_0599:
																									if (3 > b)
																									{
																										goto IL_05a7;
																									}
																									goto IL_064b;
																									IL_05a7:
																									if (1 < b)
																									{
																										goto IL_05b5;
																									}
																									goto IL_0638;
																									IL_05b5:
																									if (2 < b)
																									{
																										break;
																									}
																									goto IL_05c3;
																									IL_05c3:
																									if (2 > b)
																									{
																										break;
																									}
																									goto IL_05d1;
																									IL_05d1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0611;
																									IL_0611:
																									array[num5 - 2] = 0;
																									goto IL_0625;
																									IL_0625:
																									num5--;
																									goto end_IL_02ac;
																									IL_0638:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_064b:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0674;
																									IL_0674:
																									ptr2 += 8;
																									goto IL_0682;
																								}
																								break;
																							}
																							goto IL_0695;
																							IL_06e9:
																							num5--;
																							goto end_IL_02ac;
																							IL_0695:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_06d5;
																							IL_06d5:
																							array[num5 - 2] = 0;
																							goto IL_06e9;
																						}
																						break;
																					}
																					goto IL_02ea;
																					IL_03b9:
																					ptr2 += 8;
																					goto end_IL_02ac;
																					IL_02ea:
																					if (9 < b)
																					{
																						goto IL_02f5;
																					}
																					goto IL_0316;
																					IL_02f5:
																					if (10 < b)
																					{
																						goto IL_0303;
																					}
																					goto IL_04e8;
																					IL_0303:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_03ed;
																					IL_03ed:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_03fb;
																					IL_03fb:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02ac;
																					IL_04e8:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_04f6;
																					IL_04f6:
																					num5--;
																					num = 81;
																					goto end_IL_02ac;
																					IL_0316:
																					if (9 > b)
																					{
																						goto IL_0321;
																					}
																					goto IL_0366;
																					IL_0321:
																					if (7 >= b)
																					{
																						goto IL_032f;
																					}
																					goto IL_0417;
																					IL_032f:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_033d;
																					IL_033d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0356;
																					IL_0356:
																					array[num5] = 0;
																					goto IL_03cc;
																					IL_03cc:
																					num5++;
																					goto IL_03da;
																					IL_03da:
																					ptr2 += 8;
																					goto end_IL_02ac;
																					IL_0417:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0425;
																					IL_0425:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0433;
																					IL_0433:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0473;
																					IL_0473:
																					array[num5 - 2] = 0;
																					goto IL_0487;
																					IL_0487:
																					num5--;
																					goto end_IL_02ac;
																					IL_0366:
																					array[num5 - 1] = 0;
																					goto IL_037a;
																					IL_037a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)ShortestDayNamesCallback[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_03b9;
																				}
																				break;
																				IL_029c:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_071c;
																		IL_0738:
																		ptr2 += 8;
																		break;
																		IL_072a:
																		num5++;
																		goto IL_0738;
																		IL_071c:
																		array[num5] = 0;
																		goto IL_072a;
																		continue;
																		end_IL_02ac:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_0810;
														IL_0810:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0746:
														break;
													}
													continue;
													end_IL_0759:
													break;
												}
												continue;
												end_IL_0763:
												break;
											}
											continue;
											end_IL_076e:
											break;
										}
										continue;
										end_IL_078c:
										break;
									}
									continue;
									end_IL_07a1:
									break;
								}
								continue;
								end_IL_07b1:
								break;
							}
							continue;
							end_IL_07c1:
							break;
						}
						continue;
						end_IL_07cc:
						break;
					}
					continue;
					end_IL_07e5:
					break;
				}
				continue;
				end_IL_07f5:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 42;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								num = 65;
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIsNumericScalargetKeyName.HostAppDomainEvidencePrepareContractedDelegate);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_01f3:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01d3:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01c3:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01b3:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01a0:
																											if (2 <= b)
																											{
																												num = 92;
																												while (true)
																												{
																													if (num != 92)
																													{
																														if (num != 1073)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 54:
																															goto IL_01a0;
																														case 44:
																															goto IL_01b3;
																														case 12:
																															goto IL_01c3;
																														case 75:
																															goto IL_01d3;
																														case 33:
																															goto IL_01e3;
																														case 22:
																															goto IL_01f3;
																														case 24:
																															goto end_IL_01f3;
																														case 2:
																														case 76:
																															goto end_IL_0203;
																														case 8:
																															goto IL_021e;
																														case 25:
																															goto IL_028c;
																														case 77:
																															goto IL_029f;
																														case 82:
																															goto IL_02ad;
																														case 3:
																															goto IL_02c0;
																														case 71:
																															goto IL_02ce;
																														case 15:
																														case 48:
																															goto IL_02dc;
																														case 34:
																															goto IL_031c;
																														case 59:
																															goto IL_0330;
																														case 60:
																														case 64:
																															goto IL_0343;
																														case 72:
																															goto IL_036c;
																														case 0:
																															goto IL_037a;
																														case 11:
																															goto IL_038d;
																														case 51:
																															goto IL_0398;
																														case 27:
																														case 63:
																															goto IL_03a6;
																														case 79:
																															goto IL_03b4;
																														case 16:
																														case 84:
																															goto IL_03c2;
																														case 67:
																															goto IL_03da;
																														case 36:
																															goto IL_03e5;
																														case 6:
																														case 66:
																															goto IL_03f3;
																														case 10:
																															goto IL_040a;
																														case 68:
																															goto IL_042d;
																														case 45:
																															goto IL_0437;
																														case 80:
																															goto IL_0445;
																														case 70:
																															goto IL_0458;
																														case 50:
																															goto IL_0463;
																														case 13:
																														case 56:
																															goto IL_046e;
																														case 1:
																														case 4:
																														case 5:
																														case 14:
																														case 17:
																														case 19:
																														case 23:
																														case 29:
																														case 43:
																														case 47:
																														case 58:
																														case 61:
																														case 62:
																														case 73:
																														case 74:
																														case 78:
																															goto end_IL_018d;
																														case 85:
																															goto IL_04aa;
																														case 35:
																															goto IL_04b8;
																														case 52:
																															goto IL_04cf;
																														case 7:
																														case 9:
																														case 18:
																														case 20:
																														case 26:
																														case 32:
																														case 37:
																														case 40:
																														case 41:
																														case 46:
																														case 69:
																															goto end_IL_0213;
																														case 30:
																															goto end_IL_04dd;
																														case 57:
																															goto end_IL_04f0;
																														case 49:
																															goto end_IL_04fa;
																														case 28:
																															goto end_IL_0505;
																														case 65:
																															goto end_IL_051a;
																														case 21:
																														case 53:
																															goto end_IL_052f;
																														case 81:
																															goto end_IL_053f;
																														case 42:
																															goto end_IL_0558;
																														case 83:
																															goto end_IL_0568;
																														case 38:
																															goto end_IL_0578;
																														case 39:
																															goto end_IL_0583;
																														case 31:
																														case 55:
																															goto IL_05a7;
																														}
																														continue;
																													}
																													goto IL_021e;
																													IL_021e:
																													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_028c;
																													IL_028c:
																													num5 -= 2;
																													goto end_IL_0213;
																													continue;
																													end_IL_018d:
																													break;
																												}
																												break;
																											}
																											goto IL_029f;
																											IL_029f:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_02ad;
																											IL_02ad:
																											if (1 > b)
																											{
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02c0;
																									IL_0330:
																									num5--;
																									goto end_IL_0213;
																									IL_02c0:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_02ce;
																									IL_02ce:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_02dc;
																									IL_02dc:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_031c;
																									IL_031c:
																									array[num5 - 2] = 0;
																									goto IL_0330;
																								}
																								break;
																							}
																							goto IL_0343;
																							IL_037a:
																							num5--;
																							goto end_IL_0213;
																							IL_0343:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_036c;
																							IL_036c:
																							ptr2 += 8;
																							goto IL_037a;
																						}
																						break;
																					}
																					goto IL_038d;
																					IL_046e:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0213;
																					IL_038d:
																					if (6 >= b)
																					{
																						goto IL_0398;
																					}
																					goto IL_03da;
																					IL_0398:
																					if (6 <= b)
																					{
																						goto end_IL_0213;
																					}
																					goto IL_03a6;
																					IL_03a6:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_03b4;
																					IL_03b4:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_03c2;
																					IL_03c2:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0213;
																					IL_03da:
																					if (7 >= b)
																					{
																						goto IL_03e5;
																					}
																					goto IL_0458;
																					IL_03e5:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03f3;
																					IL_03f3:
																					array[num5] = 0;
																					num = 10;
																					goto IL_040a;
																					IL_040a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_042d;
																					IL_042d:
																					array2[num5] = null;
																					goto IL_0437;
																					IL_0437:
																					num5++;
																					goto IL_0445;
																					IL_0445:
																					ptr2 += 8;
																					goto end_IL_0213;
																					IL_0458:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0463;
																					IL_0463:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_046e;
																				}
																				break;
																				IL_01e3:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04aa;
																		IL_04cf:
																		ptr2 += 8;
																		goto end_IL_0213;
																		IL_04b8:
																		num5++;
																		num = 52;
																		goto IL_04cf;
																		IL_04aa:
																		array[num5] = 0;
																		goto IL_04b8;
																		continue;
																		end_IL_01f3:
																		break;
																	}
																	continue;
																	end_IL_0203:
																	break;
																}
																continue;
																end_IL_0213:
																break;
															}
															continue;
														}
														num = 31;
														goto IL_05a7;
														IL_05a7:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04dd:
														break;
													}
													continue;
													end_IL_04f0:
													break;
												}
												continue;
												end_IL_04fa:
												break;
											}
											continue;
											end_IL_0505:
											break;
										}
										continue;
										end_IL_051a:
										break;
									}
									continue;
									end_IL_052f:
									break;
								}
								continue;
								end_IL_053f:
								break;
							}
							continue;
							end_IL_0558:
							break;
						}
						continue;
						end_IL_0568:
						break;
					}
					continue;
					end_IL_0578:
					break;
				}
				continue;
				end_IL_0583:
				break;
			}
		}
	}

	static Class189()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_004a:
					num = 13;
					while (true)
					{
						if (num != 13)
						{
							if (num != 994)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 3:
							case 5:
							case 6:
								goto IL_004a;
							case 1:
								goto end_IL_003d;
							case 2:
								goto end_IL_005f;
							case 4:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_003d:
						break;
					}
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}
}
