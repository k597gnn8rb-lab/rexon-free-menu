using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Gun Color: Purple", "Settings", "Cycle gun colors", false, 4, ModType.const_1, false)]
internal class Class129 : MonoBehaviour
{
	internal readonly struct ColorOption
	{
		public readonly string string_0;

		public readonly Color color_0;

		public readonly Color color_1;

		private static IntPtr[] CodeConnectAccessFilterTypeNameIgnoreCase;

		private static object object_0;

		public unsafe ColorOption(string name, Color idle, Color shooting)
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
			int num = 0;
			int num2 = 0;
			num2 = 0;
			int num3 = default(int);
			while (num2 != 1)
			{
				((delegate*<ref int, ref int, ref int, ref ColorOption, string, Color, Color, void>)CodeConnectAccessFilterTypeNameIgnoreCase[num])(ref num, ref num2, ref num3, ref this, name, idle, shooting);
			}
			num2 = 0;
		}

		static ColorOption()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				while (true)
				{
					Class300.smethod_0();
					while (true)
					{
						num = 9;
						while (true)
						{
							if (num != 9)
							{
								if (num != 990)
								{
									break;
								}
								switch (num)
								{
								case 2:
									goto end_IL_002d;
								case 0:
									goto end_IL_003a;
								case 1:
									goto end_IL_0046;
								}
								continue;
							}
							return;
							continue;
							end_IL_002d:
							break;
						}
						continue;
						end_IL_003a:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
			}
		}

		internal static bool smethod_0()
		{
			return object_0 == null;
		}

		internal static object smethod_1()
		{
			return object_0;
		}
	}

	private static int int_0;

	private static ColorOption[] colorOption_0;

	private static float float_0;

	private static double double_0;

	private static bool bool_0;

	private static double double_1;

	private static bool bool_1;

	private static IntPtr[] GetMethodTokenMathSymbol;

	private static IntPtr[] ReadOnlyDictionaryHelpersSignalAndWait;

	private static IntPtr[] GetFieldOffsetgetCurrencyGroupSizes;

	private static IntPtr[] getAccessMaskStringToCoTaskMemUni;

	private static IntPtr[] getFieldTypeOperations;

	private static IntPtr[] TokenizerShortBlockGCInduced;

	private static IntPtr[] getScopeNameResolveROAsmEvent;

	public unsafe static int CurrentIndex
	{
		get
		{
			int num = 124;
			object[] array2 = default(object[]);
			byte* ptr = default(byte*);
			long[] array3 = default(long[]);
			int num5 = default(int);
			byte* ptr2 = default(byte*);
			byte b = default(byte);
			int[] array4 = default(int[]);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							num = 155;
							while (true)
							{
								if (num != 155)
								{
									if (num != 1136)
									{
										goto IL_06ba;
									}
									switch (num)
									{
									case 20:
										goto end_IL_027b;
									case 83:
										goto end_IL_028b;
									case 123:
										goto end_IL_02a4;
									case 124:
										goto end_IL_02b4;
									case 1:
									case 17:
										goto IL_02dd;
									case 36:
										goto IL_02eb;
									case 140:
										goto IL_02f9;
									case 121:
										goto IL_0302;
									case 4:
									case 34:
									case 41:
									case 48:
									case 53:
									case 54:
									case 56:
									case 58:
									case 64:
									case 80:
									case 86:
									case 111:
									case 114:
									case 117:
									case 127:
									case 129:
									case 131:
									case 148:
										goto IL_030a;
									case 100:
										goto IL_031a;
									case 37:
										goto IL_0323;
									case 42:
										goto IL_032c;
									case 3:
										goto IL_033a;
									case 77:
										goto IL_0348;
									case 13:
										goto IL_0356;
									case 44:
										goto IL_0364;
									case 47:
									case 63:
										goto IL_036f;
									case 116:
										goto IL_037f;
									case 74:
										goto IL_038d;
									case 94:
									case 134:
										goto IL_039b;
									case 15:
									case 22:
										goto IL_03a6;
									case 107:
										goto IL_03b4;
									case 31:
									case 91:
										goto IL_03c2;
									case 88:
										goto IL_03eb;
									case 113:
										goto IL_03f9;
									case 30:
										goto IL_040c;
									case 33:
									case 46:
										goto IL_0417;
									case 84:
										goto IL_0457;
									case 109:
										goto IL_046b;
									case 75:
										goto IL_047e;
									case 25:
										goto IL_048c;
									case 23:
									case 49:
										goto IL_04a8;
									case 92:
										goto IL_04b6;
									case 51:
										goto IL_04d9;
									case 98:
										goto IL_04e3;
									case 70:
										goto IL_04f1;
									case 16:
									case 105:
										goto IL_050d;
									case 50:
										goto IL_051b;
									case 73:
									case 143:
										goto IL_0529;
									case 119:
										goto IL_0537;
									case 67:
									case 101:
										goto IL_0545;
									case 138:
										goto IL_0585;
									case 7:
										goto IL_0599;
									case 95:
									case 141:
										goto IL_05ac;
									case 66:
										goto IL_05ec;
									case 38:
										goto IL_0600;
									case 120:
										goto IL_0613;
									case 10:
										goto IL_061e;
									case 82:
									case 122:
										goto IL_062c;
									case 85:
										goto IL_066c;
									case 136:
										goto IL_0680;
									case 78:
										goto IL_06a1;
									case 28:
									case 57:
										goto IL_06af;
									case 0:
									case 93:
										goto IL_06ba;
									case 26:
										goto IL_06c8;
									case 60:
									case 115:
										goto IL_06d6;
									case 35:
										goto IL_06f2;
									case 96:
										goto IL_06fd;
									case 29:
										goto IL_0714;
									case 8:
									case 19:
										goto IL_0722;
									case 27:
									case 106:
										goto IL_0743;
									case 2:
										goto IL_0767;
									case 139:
										goto IL_0775;
									case 62:
										goto IL_0783;
									case 65:
										goto IL_079f;
									case 21:
									case 90:
										goto IL_07aa;
									case 125:
										goto IL_07c3;
									case 135:
										goto IL_07d1;
									case 133:
										goto IL_07df;
									case 9:
									case 32:
										goto IL_07f2;
									case 97:
										goto IL_0800;
									case 11:
										goto IL_080e;
									case 40:
										goto IL_081c;
									case 18:
									case 142:
										goto IL_082a;
									case 72:
										goto IL_086a;
									case 87:
										goto IL_0887;
									case 12:
									case 126:
										goto IL_08a3;
									case 145:
										goto IL_090e;
									case 45:
										goto IL_0921;
									case 81:
										goto IL_092c;
									case 137:
										goto IL_093c;
									case 128:
										goto IL_094a;
									case 89:
										goto IL_0958;
									case 5:
									case 6:
									case 24:
									case 39:
									case 43:
									case 52:
									case 55:
									case 59:
									case 61:
									case 68:
									case 69:
									case 71:
									case 76:
									case 79:
									case 99:
									case 102:
									case 103:
									case 104:
									case 108:
									case 110:
									case 112:
									case 118:
									case 130:
									case 132:
									case 144:
									case 147:
										goto IL_096b;
									case 14:
									case 146:
										goto IL_0986;
									}
									continue;
								}
								array2 = new object[3];
								goto IL_02dd;
								IL_08a3:
								ptr = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1])) ? 1 : 0) * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								num = 145;
								goto IL_090e;
								IL_0921:
								if (11 >= b)
								{
									goto IL_092c;
								}
								goto IL_096b;
								IL_090e:
								num5 -= 2;
								goto IL_030a;
								IL_02dd:
								array4 = new int[6];
								goto IL_02eb;
								IL_02eb:
								array3 = new long[3];
								goto IL_02f9;
								IL_02f9:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref COORDDayNames.ResourceTypeIdIntSizeAssignDelegate);
								goto IL_0302;
								IL_0302:
								ptr = ptr2;
								goto IL_030a;
								IL_030a:
								if (num6 != 1)
								{
									goto IL_031a;
								}
								goto IL_0986;
								IL_0986:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								IL_031a:
								num = 37;
								goto IL_0323;
								IL_0323:
								b = *ptr;
								goto IL_032c;
								IL_032c:
								ptr++;
								goto IL_033a;
								IL_033a:
								if (b >= 1)
								{
									goto IL_0348;
								}
								goto IL_096b;
								IL_0348:
								if (b <= 15)
								{
									goto IL_0356;
								}
								goto IL_096b;
								IL_0356:
								if (8 >= b)
								{
									goto IL_0364;
								}
								goto IL_06a1;
								IL_0364:
								if (8 <= b)
								{
									goto IL_036f;
								}
								goto IL_037f;
								IL_036f:
								num5--;
								goto IL_030a;
								IL_037f:
								if (4 >= b)
								{
									goto IL_038d;
								}
								num = 16;
								goto IL_050d;
								IL_038d:
								if (4 > b)
								{
									goto IL_039b;
								}
								goto IL_04a8;
								IL_039b:
								if (2 < b)
								{
									goto IL_03a6;
								}
								goto IL_040c;
								IL_03a6:
								if (3 >= b)
								{
									goto IL_03b4;
								}
								goto IL_096b;
								IL_03b4:
								if (3 <= b)
								{
									goto IL_03c2;
								}
								goto IL_096b;
								IL_03c2:
								ref int reference = ref array4[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_03eb;
								IL_03eb:
								ptr += 8;
								goto IL_03f9;
								IL_03f9:
								num5--;
								goto IL_030a;
								IL_040c:
								if (2 <= b)
								{
									goto IL_0417;
								}
								goto IL_047e;
								IL_0417:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_0457;
								IL_0457:
								array[num5 - 2] = 0;
								goto IL_046b;
								IL_046b:
								num5--;
								goto IL_030a;
								IL_047e:
								if (1 >= b)
								{
									goto IL_048c;
								}
								goto IL_096b;
								IL_048c:
								if (1 <= b)
								{
									num = 102;
								}
								goto IL_096b;
								IL_096b:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr + num3);
								goto IL_093c;
								IL_04a8:
								array[num5] = 0;
								goto IL_04b6;
								IL_04b6:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = array4[*(int*)(ptr + num3)];
								goto IL_04d9;
								IL_04d9:
								array2[num5] = null;
								goto IL_04e3;
								IL_04e3:
								num5++;
								goto IL_04f1;
								IL_04f1:
								ptr += 8;
								goto IL_030a;
								IL_092c:
								if (11 <= b)
								{
									goto IL_030a;
								}
								goto IL_096b;
								IL_050d:
								if (6 >= b)
								{
									goto IL_051b;
								}
								goto IL_0613;
								IL_051b:
								if (6 > b)
								{
									goto IL_0529;
								}
								goto IL_05ac;
								IL_0529:
								if (5 >= b)
								{
									goto IL_0537;
								}
								goto IL_096b;
								IL_0537:
								if (5 <= b)
								{
									goto IL_0545;
								}
								goto IL_096b;
								IL_0545:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_0585;
								IL_0585:
								array[num5 - 2] = 0;
								goto IL_0599;
								IL_0599:
								num5--;
								goto IL_030a;
								IL_05ac:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_05ec;
								IL_05ec:
								array[num5 - 2] = 0;
								goto IL_0600;
								IL_0600:
								num5--;
								goto IL_030a;
								IL_0613:
								if (7 >= b)
								{
									goto IL_061e;
								}
								num = 108;
								goto IL_096b;
								IL_061e:
								if (7 <= b)
								{
									goto IL_062c;
								}
								goto IL_096b;
								IL_062c:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_066c;
								IL_066c:
								array[num5 - 2] = 0;
								goto IL_0680;
								IL_0680:
								num5--;
								goto IL_030a;
								IL_093c:
								array[num5] = 0;
								goto IL_094a;
								IL_06a1:
								if (12 < b)
								{
									goto IL_06af;
								}
								goto IL_079f;
								IL_06af:
								if (14 < b)
								{
									goto IL_06ba;
								}
								goto IL_06f2;
								IL_06ba:
								if (15 >= b)
								{
									goto IL_06c8;
								}
								goto IL_096b;
								IL_06c8:
								if (15 <= b)
								{
									goto IL_06d6;
								}
								goto IL_096b;
								IL_06d6:
								byte* num7 = ptr;
								num6 = 1;
								ptr = num7 + -200;
								goto IL_030a;
								IL_06f2:
								if (14 > b)
								{
									goto IL_06fd;
								}
								num = 106;
								goto IL_0743;
								IL_06fd:
								if (13 >= b)
								{
									num = 29;
									goto IL_0714;
								}
								goto IL_096b;
								IL_0958:
								ptr += 8;
								goto IL_030a;
								IL_0714:
								if (13 <= b)
								{
									goto IL_0722;
								}
								goto IL_096b;
								IL_0722:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_030a;
								IL_094a:
								num5++;
								goto IL_0958;
								IL_0743:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = ((delegate*<int>)GetFieldOffsetgetCurrencyGroupSizes[*(int*)(ptr + num3)])();
								goto IL_0767;
								IL_0767:
								array[num5] = 0;
								goto IL_0775;
								IL_0775:
								num5++;
								goto IL_0783;
								IL_0783:
								ptr += 8;
								num = 148;
								goto IL_030a;
								IL_079f:
								if (12 <= b)
								{
									goto IL_07aa;
								}
								goto IL_07f2;
								IL_07aa:
								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(long*)(ptr + num4);
								goto IL_07c3;
								IL_07c3:
								array[num5] = 1;
								goto IL_07d1;
								IL_07d1:
								num5++;
								goto IL_07df;
								IL_07df:
								ptr += 16;
								goto IL_030a;
								IL_07f2:
								if (10 >= b)
								{
									goto IL_0800;
								}
								goto IL_0921;
								IL_0800:
								if (10 > b)
								{
									goto IL_080e;
								}
								goto IL_08a3;
								IL_080e:
								if (9 >= b)
								{
									goto IL_081c;
								}
								goto IL_096b;
								IL_081c:
								if (9 <= b)
								{
									goto IL_082a;
								}
								goto IL_096b;
								IL_082a:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
								goto IL_086a;
								IL_086a:
								array[num5 - 2] = 0;
								num = 87;
								goto IL_0887;
								IL_0887:
								num5--;
								num = 34;
								goto IL_030a;
								continue;
								end_IL_027b:
								break;
							}
							continue;
							end_IL_028b:
							break;
						}
						continue;
						end_IL_02a4:
						break;
					}
					continue;
					end_IL_02b4:
					break;
				}
			}
		}
		set
		{
			int num = 87;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[4];
							while (true)
							{
								object[] array2 = new object[4];
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[4];
										while (true)
										{
											array3[0] = value;
											num = 16;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref indexPublicationOnly.FromCurrentSynchronizationContextIsEmpty);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0469:
																	if (b >= 1)
																	{
																		while (b <= 22)
																		{
																			while (true)
																			{
																				IL_0449:
																				if (11 >= b)
																				{
																					while (true)
																					{
																						IL_0439:
																						if (11 > b)
																						{
																							while (true)
																							{
																								IL_0429:
																								if (5 < b)
																								{
																									while (true)
																									{
																										IL_0419:
																										if (8 >= b)
																										{
																											while (true)
																											{
																												IL_0409:
																												if (8 > b)
																												{
																													while (true)
																													{
																														IL_03f9:
																														if (6 < b)
																														{
																															while (7 >= b)
																															{
																																while (7 <= b)
																																{
																																	while (true)
																																	{
																																		IL_038e:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																		num = 219;
																																		while (true)
																																		{
																																			if (num != 219)
																																			{
																																				if (num != 1200)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 99:
																																				case 109:
																																					goto IL_038e;
																																				case 158:
																																					goto IL_03d9;
																																				case 42:
																																					goto IL_03e9;
																																				case 62:
																																					goto IL_03f9;
																																				case 156:
																																					goto IL_0409;
																																				case 85:
																																					goto IL_0419;
																																				case 102:
																																					goto IL_0429;
																																				case 159:
																																					goto IL_0439;
																																				case 106:
																																					goto IL_0449;
																																				case 35:
																																					goto IL_0459;
																																				case 107:
																																					goto IL_0469;
																																				case 126:
																																					goto end_IL_0469;
																																				case 9:
																																				case 142:
																																					goto end_IL_0479;
																																				case 39:
																																					goto IL_0494;
																																				case 88:
																																				case 119:
																																					goto IL_04a2;
																																				case 139:
																																					goto IL_04e2;
																																				case 112:
																																				case 149:
																																					goto IL_04fb;
																																				case 14:
																																				case 97:
																																					goto IL_0509;
																																				case 130:
																																					goto IL_0517;
																																				case 100:
																																				case 127:
																																					goto IL_0525;
																																				case 135:
																																					goto IL_0539;
																																				case 129:
																																					goto IL_05a2;
																																				case 55:
																																					goto IL_05b0;
																																				case 81:
																																				case 94:
																																					goto IL_05cc;
																																				case 5:
																																					goto IL_05df;
																																				case 59:
																																				case 96:
																																					goto IL_05ea;
																																				case 44:
																																					goto IL_0619;
																																				case 116:
																																					goto IL_0624;
																																				case 75:
																																					goto IL_0632;
																																				case 61:
																																				case 90:
																																					goto IL_0640;
																																				case 30:
																																					goto IL_0668;
																																				case 12:
																																				case 111:
																																					goto IL_0676;
																																				case 52:
																																				case 91:
																																					goto IL_0681;
																																				case 43:
																																					goto IL_068f;
																																				case 76:
																																					goto IL_06a2;
																																				case 152:
																																					goto IL_06be;
																																				case 92:
																																				case 155:
																																					goto IL_06d7;
																																				case 165:
																																					goto IL_06e7;
																																				case 167:
																																					goto IL_06f7;
																																				case 10:
																																				case 108:
																																					goto IL_0705;
																																				case 140:
																																				case 170:
																																					goto IL_072e;
																																				case 29:
																																					goto IL_0759;
																																				case 176:
																																					goto IL_0772;
																																				case 40:
																																					goto IL_0780;
																																				case 82:
																																					goto IL_078e;
																																				case 190:
																																					goto IL_07aa;
																																				case 80:
																																					goto IL_07b8;
																																				case 56:
																																				case 66:
																																					goto IL_07c6;
																																				case 26:
																																					goto IL_0806;
																																				case 72:
																																					goto IL_0823;
																																				case 199:
																																					goto IL_0836;
																																				case 38:
																																					goto IL_0844;
																																				case 138:
																																					goto IL_0852;
																																				case 202:
																																					goto IL_0865;
																																				case 32:
																																					goto IL_0870;
																																				case 147:
																																				case 183:
																																					goto IL_087e;
																																				case 120:
																																					goto IL_0898;
																																				case 117:
																																					goto IL_08b4;
																																				case 131:
																																					goto IL_08cb;
																																				case 125:
																																				case 196:
																																					goto IL_08d9;
																																				case 21:
																																				case 206:
																																					goto IL_08f5;
																																				case 145:
																																					goto IL_0917;
																																				case 141:
																																					goto IL_0925;
																																				case 22:
																																					goto IL_0933;
																																				case 207:
																																					goto IL_094f;
																																				case 25:
																																				case 209:
																																					goto IL_0962;
																																				case 34:
																																					goto IL_098e;
																																				case 168:
																																				case 210:
																																					goto IL_09a1;
																																				case 83:
																																				case 128:
																																					goto IL_09bd;
																																				case 84:
																																					goto IL_09cb;
																																				case 146:
																																				case 154:
																																					goto IL_09d9;
																																				case 18:
																																					goto IL_0a22;
																																				case 175:
																																					goto IL_0a3f;
																																				case 192:
																																					goto IL_0a52;
																																				case 0:
																																					goto IL_0a60;
																																				case 57:
																																				case 193:
																																					goto end_IL_037b;
																																				case 93:
																																					goto IL_0ad0;
																																				case 136:
																																					goto IL_0ae3;
																																				case 6:
																																					goto IL_0af1;
																																				case 134:
																																					goto IL_0aff;
																																				case 17:
																																				case 48:
																																					goto IL_0b0a;
																																				case 8:
																																					goto IL_0b18;
																																				case 23:
																																				case 49:
																																					goto IL_0b2b;
																																				case 188:
																																					goto IL_0b6b;
																																				case 144:
																																					goto IL_0b7f;
																																				case 11:
																																					goto IL_0b92;
																																				case 184:
																																					goto IL_0b9d;
																																				case 70:
																																				case 79:
																																					goto IL_0bab;
																																				case 74:
																																					goto IL_0bd4;
																																				case 37:
																																					goto IL_0be2;
																																				case 191:
																																					goto IL_0bf5;
																																				case 198:
																																					goto IL_0c03;
																																				case 60:
																																				case 173:
																																					goto IL_0c11;
																																				case 186:
																																					goto IL_0c1f;
																																				case 65:
																																					goto IL_0c42;
																																				case 98:
																																					goto IL_0c4c;
																																				case 160:
																																					goto IL_0c5a;
																																				case 68:
																																				case 163:
																																					goto IL_0c6d;
																																				case 77:
																																					goto IL_0cad;
																																				case 33:
																																					goto IL_0cc1;
																																				case 122:
																																				case 182:
																																					goto IL_0cd4;
																																				case 157:
																																					goto IL_0ce8;
																																				case 121:
																																					goto IL_0d3c;
																																				case 151:
																																					goto IL_0d4a;
																																				case 7:
																																				case 19:
																																				case 28:
																																				case 31:
																																				case 36:
																																				case 41:
																																				case 50:
																																				case 51:
																																				case 53:
																																				case 54:
																																				case 58:
																																				case 67:
																																				case 78:
																																				case 95:
																																				case 101:
																																				case 103:
																																				case 104:
																																				case 110:
																																				case 114:
																																				case 115:
																																				case 118:
																																				case 124:
																																				case 132:
																																				case 133:
																																				case 137:
																																				case 153:
																																				case 161:
																																				case 164:
																																				case 169:
																																				case 172:
																																				case 177:
																																				case 178:
																																				case 179:
																																				case 181:
																																				case 187:
																																				case 194:
																																				case 195:
																																				case 200:
																																				case 201:
																																					goto end_IL_03d9;
																																				case 73:
																																					goto IL_0d7c;
																																				case 89:
																																					goto IL_0d8a;
																																				case 24:
																																					goto IL_0d98;
																																				case 1:
																																				case 3:
																																				case 4:
																																				case 13:
																																				case 15:
																																				case 27:
																																				case 45:
																																				case 47:
																																				case 63:
																																				case 71:
																																				case 105:
																																				case 113:
																																				case 123:
																																				case 148:
																																				case 150:
																																				case 162:
																																				case 166:
																																				case 171:
																																				case 180:
																																				case 185:
																																				case 189:
																																				case 204:
																																				case 208:
																																				case 211:
																																				case 212:
																																					goto end_IL_0489;
																																				case 20:
																																					goto end_IL_0da6;
																																				case 16:
																																					goto end_IL_0db9;
																																				case 203:
																																					goto end_IL_0dc3;
																																				case 46:
																																					goto end_IL_0dce;
																																				case 2:
																																				case 143:
																																					goto end_IL_0dec;
																																				case 197:
																																					goto end_IL_0dfc;
																																				case 69:
																																					goto end_IL_0e0c;
																																				case 174:
																																					goto end_IL_0e1c;
																																				case 86:
																																					goto end_IL_0e2c;
																																				case 87:
																																					goto end_IL_0e3c;
																																				case 64:
																																				case 205:
																																					return;
																																				}
																																				continue;
																																			}
																																			array[num6 - 2] = 0;
																																			goto IL_098e;
																																			IL_098e:
																																			num6--;
																																			goto end_IL_0489;
																																			continue;
																																			end_IL_037b:
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_0a6e;
																																	continue;
																																	end_IL_03d9:
																																	break;
																																	IL_03d9:;
																																}
																																break;
																																IL_03e9:;
																															}
																															break;
																														}
																														goto IL_0494;
																														IL_094f:
																														num6--;
																														goto end_IL_0489;
																														IL_0494:
																														if (6 > b)
																														{
																															break;
																														}
																														goto IL_04a2;
																														IL_04a2:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_04e2;
																														IL_04e2:
																														array[num6 - 2] = 0;
																														goto IL_094f;
																													}
																													break;
																												}
																												goto IL_09a1;
																												IL_09a1:
																												num6--;
																												goto end_IL_0489;
																											}
																											break;
																										}
																										num = 83;
																										goto IL_09bd;
																										IL_0a6e:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0ad0;
																										IL_0ad0:
																										num6 -= 2;
																										goto end_IL_0489;
																										IL_09bd:
																										if (9 >= b)
																										{
																											goto IL_09cb;
																										}
																										goto IL_0a52;
																										IL_09cb:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_09d9;
																										IL_09d9:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										num = 18;
																										goto IL_0a22;
																										IL_0a22:
																										array[num6 - 2] = 0;
																										num = 175;
																										goto IL_0a3f;
																										IL_0a3f:
																										num6--;
																										goto end_IL_0489;
																										IL_0a52:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_0a60;
																										IL_0a60:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_0a6e;
																									}
																									break;
																								}
																								goto IL_0ae3;
																								IL_0cc1:
																								num6--;
																								goto end_IL_0489;
																								IL_0ae3:
																								if (5 > b)
																								{
																									goto IL_0af1;
																								}
																								goto IL_0c6d;
																								IL_0af1:
																								if (2 >= b)
																								{
																									goto IL_0aff;
																								}
																								goto IL_0b92;
																								IL_0aff:
																								if (2 > b)
																								{
																									goto IL_0b0a;
																								}
																								goto IL_0b2b;
																								IL_0b0a:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0b18;
																								IL_0b18:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0b2b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0b6b;
																								IL_0b6b:
																								array[num6 - 2] = 0;
																								goto IL_0b7f;
																								IL_0b7f:
																								num6--;
																								goto end_IL_0489;
																								IL_0b92:
																								if (3 >= b)
																								{
																									goto IL_0b9d;
																								}
																								goto IL_0bf5;
																								IL_0b9d:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0bab;
																								IL_0bab:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0bd4;
																								IL_0bd4:
																								ptr2 += 8;
																								goto IL_0be2;
																								IL_0be2:
																								num6--;
																								goto end_IL_0489;
																								IL_0bf5:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0c03;
																								IL_0c03:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0c11;
																								IL_0c11:
																								array[num6] = 0;
																								goto IL_0c1f;
																								IL_0c1f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0c42;
																								IL_0c42:
																								array2[num6] = null;
																								goto IL_0c4c;
																								IL_0c4c:
																								num6++;
																								goto IL_0c5a;
																								IL_0c5a:
																								ptr2 += 8;
																								goto end_IL_0489;
																								IL_0c6d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0cad;
																								IL_0cad:
																								array[num6 - 2] = 0;
																								goto IL_0cc1;
																							}
																							break;
																						}
																						goto IL_0cd4;
																						IL_0d4a:
																						ptr2 += 8;
																						goto end_IL_0489;
																						IL_0cd4:
																						array[num6 - 2] = 0;
																						goto IL_0ce8;
																						IL_0ce8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)getAccessMaskStringToCoTaskMemUni[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0d3c;
																						IL_0d3c:
																						num6--;
																						goto IL_0d4a;
																					}
																					break;
																				}
																				goto IL_04fb;
																				IL_0933:
																				ptr2 += 16;
																				num = 150;
																				goto end_IL_0489;
																				IL_04fb:
																				if (17 < b)
																				{
																					goto IL_0509;
																				}
																				goto IL_05df;
																				IL_0509:
																				if (20 >= b)
																				{
																					goto IL_0517;
																				}
																				goto IL_0865;
																				IL_0517:
																				if (20 <= b)
																				{
																					goto IL_0525;
																				}
																				num = 81;
																				goto IL_05cc;
																				IL_0525:
																				array[num6 - 3] = 0;
																				goto IL_0539;
																				IL_0539:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]) = ((delegate*<int, int, int, int>)getAccessMaskStringToCoTaskMemUni[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_05a2;
																				IL_05a2:
																				num6 -= 2;
																				goto IL_05b0;
																				IL_05b0:
																				ptr2 += 8;
																				goto end_IL_0489;
																				IL_06a2:
																				if (12 > b)
																				{
																					break;
																				}
																				num = 4;
																				goto end_IL_0489;
																				IL_05cc:
																				if (18 >= b)
																				{
																					goto IL_06e7;
																				}
																				goto IL_07aa;
																				IL_06e7:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_072e;
																				IL_072e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0759;
																				IL_0759:
																				array[num6 - 1] = 0;
																				goto end_IL_0489;
																				IL_07aa:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_07b8;
																				IL_07b8:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_07c6;
																				IL_07c6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0806;
																				IL_0806:
																				array[num6 - 2] = 0;
																				num = 72;
																				goto IL_0823;
																				IL_0823:
																				num6--;
																				goto end_IL_0489;
																				IL_0865:
																				if (21 >= b)
																				{
																					goto IL_0870;
																				}
																				goto IL_08b4;
																				IL_0870:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_087e;
																				IL_087e:
																				int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0898;
																				IL_0898:
																				num6--;
																				num = 185;
																				goto end_IL_0489;
																				IL_08b4:
																				if (22 < b)
																				{
																					break;
																				}
																				num = 131;
																				goto IL_08cb;
																				IL_0962:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0489;
																				IL_08cb:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_08d9;
																				IL_08d9:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0489;
																				IL_05df:
																				if (17 <= b)
																				{
																					goto IL_05ea;
																				}
																				goto IL_0619;
																				IL_05ea:
																				*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((ColorOption[])array2[num6 - 1]).LongLength;
																				goto IL_06be;
																				IL_06be:
																				array[num6 - 1] = 2;
																				goto end_IL_0489;
																				IL_0619:
																				if (14 < b)
																				{
																					goto IL_0624;
																				}
																				goto IL_0668;
																				IL_0624:
																				if (15 >= b)
																				{
																					goto IL_0632;
																				}
																				goto IL_06d7;
																				IL_0632:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_0640;
																				IL_0640:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0836;
																				IL_0836:
																				array[num6] = 0;
																				goto IL_0844;
																				IL_0844:
																				num6++;
																				goto IL_0852;
																				IL_0852:
																				ptr2 += 8;
																				goto end_IL_0489;
																				IL_06d7:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_06f7;
																				IL_06f7:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_0705;
																				IL_0705:
																				array2[num6] = ((delegate*<ColorOption[]>)getAccessMaskStringToCoTaskMemUni[*(int*)(ptr2 + num3)])();
																				num = 176;
																				goto IL_0772;
																				IL_0772:
																				array[num6] = 5;
																				goto IL_0780;
																				IL_0780:
																				num6++;
																				goto IL_078e;
																				IL_078e:
																				ptr2 += 8;
																				num = 162;
																				goto end_IL_0489;
																				IL_0668:
																				if (14 > b)
																				{
																					goto IL_0676;
																				}
																				goto IL_0962;
																				IL_0676:
																				if (12 < b)
																				{
																					goto IL_0681;
																				}
																				goto IL_06a2;
																				IL_0681:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_068f;
																				IL_068f:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_08f5;
																				IL_08f5:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				num = 145;
																				goto IL_0917;
																				IL_0917:
																				array[num6] = 1;
																				goto IL_0925;
																				IL_0925:
																				num6++;
																				goto IL_0933;
																			}
																			break;
																			IL_0459:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	num = 73;
																	goto IL_0d7c;
																	IL_0d98:
																	ptr2 += 8;
																	goto end_IL_0489;
																	IL_0d8a:
																	num6++;
																	goto IL_0d98;
																	IL_0d7c:
																	array[num6] = 0;
																	goto IL_0d8a;
																	continue;
																	end_IL_0469:
																	break;
																}
																continue;
																end_IL_0479:
																break;
															}
															continue;
															end_IL_0489:
															break;
														}
														continue;
														end_IL_0da6:
														break;
													}
													continue;
													end_IL_0db9:
													break;
												}
												continue;
												end_IL_0dc3:
												break;
											}
											continue;
											end_IL_0dce:
											break;
										}
										continue;
										end_IL_0dec:
										break;
									}
									continue;
									end_IL_0dfc:
									break;
								}
								continue;
								end_IL_0e0c:
								break;
							}
							continue;
							end_IL_0e1c:
							break;
						}
						continue;
						end_IL_0e2c:
						break;
					}
					continue;
					end_IL_0e3c:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 106;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetResultGetFunctionPointer.TypeAnalysisICustomAttributeProvider);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 199;
													while (true)
													{
														if (num4 == 1)
														{
															return;
														}
														while (true)
														{
															num = 174;
															while (true)
															{
																byte b = *ptr2;
																num = 44;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_03b9:
																		if (b >= 1)
																		{
																			while (b <= 20)
																			{
																				while (true)
																				{
																					if (10 >= b)
																					{
																						num = 133;
																						while (true)
																						{
																							if (10 > b)
																							{
																								while (true)
																								{
																									IL_0376:
																									if (5 >= b)
																									{
																										goto IL_0984;
																									}
																									num = 206;
																									while (true)
																									{
																										if (num != 206)
																										{
																											if (num != 1187)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 54:
																											case 142:
																												goto IL_0376;
																											case 133:
																												goto end_IL_0376;
																											case 8:
																												goto end_IL_0389;
																											case 9:
																												goto end_IL_0399;
																											case 127:
																												goto IL_03b9;
																											case 44:
																												goto end_IL_03b9;
																											case 174:
																												goto end_IL_03c9;
																											case 84:
																												goto end_IL_03d9;
																											case 115:
																												goto IL_03f8;
																											case 38:
																											case 98:
																												goto IL_0406;
																											case 97:
																												goto IL_0411;
																											case 4:
																												goto IL_041f;
																											case 35:
																												goto IL_0433;
																											case 111:
																												goto IL_0446;
																											case 36:
																												goto IL_0454;
																											case 58:
																												goto IL_046d;
																											case 2:
																											case 51:
																												goto IL_0478;
																											case 100:
																												goto IL_048f;
																											case 80:
																												goto IL_04a2;
																											case 49:
																											case 135:
																												goto IL_04b5;
																											case 33:
																												goto IL_04cf;
																											case 146:
																												goto IL_04e2;
																											case 139:
																												goto IL_04ed;
																											case 41:
																												goto IL_04f8;
																											case 70:
																											case 92:
																												goto IL_0514;
																											case 64:
																												goto IL_051f;
																											case 6:
																												goto IL_0532;
																											case 86:
																												goto IL_0540;
																											case 43:
																											case 99:
																												goto IL_0553;
																											case 123:
																												goto IL_057e;
																											case 145:
																											case 159:
																												goto IL_0597;
																											case 128:
																												goto IL_05af;
																											case 73:
																												goto IL_05bd;
																											case 40:
																											case 162:
																												goto IL_05cd;
																											case 57:
																												goto IL_05f1;
																											case 161:
																												goto IL_05ff;
																											case 125:
																												goto IL_060d;
																											case 169:
																											case 175:
																												goto IL_0620;
																											case 184:
																												goto IL_063c;
																											case 141:
																											case 185:
																												goto IL_0658;
																											case 120:
																												goto IL_0698;
																											case 95:
																												goto IL_06ac;
																											case 116:
																											case 187:
																												goto IL_06bf;
																											case 188:
																												goto IL_06dd;
																											case 143:
																												goto IL_06f4;
																											case 14:
																												goto IL_0702;
																											case 194:
																												goto IL_0715;
																											case 153:
																												goto IL_0723;
																											case 23:
																											case 195:
																												goto IL_0736;
																											case 77:
																												goto IL_0760;
																											case 112:
																											case 197:
																												goto IL_0779;
																											case 191:
																												goto IL_07a2;
																											case 45:
																												goto IL_07b0;
																											case 59:
																												goto IL_07c3;
																											case 109:
																												goto IL_07d1;
																											case 148:
																											case 182:
																												goto IL_07df;
																											case 74:
																												goto IL_07ed;
																											case 113:
																											case 179:
																												goto IL_07fb;
																											case 65:
																												goto IL_083b;
																											case 30:
																												goto IL_084f;
																											case 87:
																											case 166:
																												goto IL_086b;
																											case 93:
																												goto IL_08ab;
																											case 157:
																												goto IL_08bf;
																											case 140:
																												goto IL_08d2;
																											case 55:
																											case 136:
																												goto IL_08e0;
																											case 163:
																												goto IL_08ee;
																											case 42:
																											case 134:
																												goto IL_08fc;
																											case 108:
																												goto IL_093c;
																											case 3:
																												goto IL_0950;
																											case 52:
																												goto IL_0963;
																											case 47:
																											case 110:
																												goto IL_0971;
																											case 173:
																												goto IL_0984;
																											case 25:
																											case 28:
																												goto IL_098f;
																											case 150:
																												goto IL_09cf;
																											case 5:
																												goto IL_09e3;
																											case 83:
																											case 198:
																												goto IL_09f6;
																											case 1:
																												goto IL_0a04;
																											case 121:
																											case 190:
																												goto IL_0a18;
																											case 71:
																												goto IL_0a58;
																											case 158:
																												goto IL_0a6c;
																											case 76:
																												goto IL_0a7f;
																											case 88:
																												goto IL_0a8d;
																											case 156:
																												goto IL_0aa0;
																											case 48:
																											case 104:
																												goto IL_0aab;
																											case 149:
																												goto IL_0ab9;
																											case 13:
																											case 186:
																												goto IL_0ac7;
																											case 168:
																												goto IL_0ad5;
																											case 94:
																												goto IL_0af8;
																											case 122:
																												goto IL_0b02;
																											case 53:
																												goto IL_0b10;
																											case 15:
																												goto IL_0b23;
																											case 50:
																											case 189:
																												goto end_IL_0363;
																											case 181:
																												goto IL_0b5a;
																											case 176:
																												goto IL_0b68;
																											case 82:
																											case 130:
																												goto IL_0b7b;
																											case 39:
																												goto IL_0be6;
																											case 0:
																											case 7:
																											case 12:
																											case 16:
																											case 18:
																											case 19:
																											case 27:
																											case 29:
																											case 31:
																											case 46:
																											case 60:
																											case 62:
																											case 67:
																											case 69:
																											case 79:
																											case 81:
																											case 91:
																											case 96:
																											case 101:
																											case 102:
																											case 103:
																											case 105:
																											case 114:
																											case 117:
																											case 118:
																											case 126:
																											case 131:
																											case 132:
																											case 137:
																											case 151:
																											case 154:
																											case 155:
																											case 165:
																											case 172:
																											case 180:
																											case 183:
																											case 192:
																											case 196:
																												goto end_IL_03a9;
																											case 26:
																												goto IL_0c18;
																											case 20:
																												goto IL_0c26;
																											case 144:
																												goto IL_0c34;
																											case 10:
																											case 11:
																											case 17:
																											case 24:
																											case 32:
																											case 34:
																											case 63:
																											case 66:
																											case 68:
																											case 72:
																											case 75:
																											case 78:
																											case 90:
																											case 124:
																											case 129:
																											case 138:
																											case 147:
																											case 152:
																											case 167:
																											case 171:
																											case 178:
																											case 199:
																												goto end_IL_03ed;
																											case 22:
																												goto end_IL_0c42;
																											case 37:
																												goto end_IL_0c55;
																											case 56:
																												goto end_IL_0c60;
																											case 61:
																												goto end_IL_0c6a;
																											case 164:
																												goto end_IL_0c75;
																											case 85:
																												goto end_IL_0c85;
																											case 170:
																											case 177:
																												goto end_IL_0c95;
																											case 193:
																												goto end_IL_0ca5;
																											case 21:
																											case 160:
																												goto end_IL_0cb5;
																											case 106:
																												goto end_IL_0cc5;
																											case 107:
																												goto end_IL_0cd5;
																											case 89:
																											case 119:
																												return;
																											}
																											continue;
																										}
																										goto IL_07c3;
																										IL_0963:
																										if (8 > b)
																										{
																											goto end_IL_03a9;
																										}
																										goto IL_0971;
																										IL_0971:
																										num5--;
																										goto end_IL_03ed;
																										IL_07c3:
																										if (7 >= b)
																										{
																											goto IL_07d1;
																										}
																										goto IL_08d2;
																										IL_07d1:
																										if (7 > b)
																										{
																											goto IL_07df;
																										}
																										goto IL_086b;
																										IL_07df:
																										if (6 < b)
																										{
																											goto end_IL_03a9;
																										}
																										goto IL_07ed;
																										IL_07ed:
																										if (6 > b)
																										{
																											goto end_IL_03a9;
																										}
																										goto IL_07fb;
																										IL_07fb:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_083b;
																										IL_083b:
																										array[num5 - 2] = 0;
																										goto IL_084f;
																										IL_084f:
																										num5--;
																										num = 147;
																										goto end_IL_03ed;
																										IL_086b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_08ab;
																										IL_08ab:
																										array[num5 - 2] = 0;
																										goto IL_08bf;
																										IL_08bf:
																										num5--;
																										goto end_IL_03ed;
																										IL_08d2:
																										if (8 < b)
																										{
																											goto IL_08e0;
																										}
																										goto IL_0963;
																										IL_08e0:
																										if (9 < b)
																										{
																											goto end_IL_03a9;
																										}
																										goto IL_08ee;
																										IL_08ee:
																										if (9 > b)
																										{
																											goto end_IL_03a9;
																										}
																										goto IL_08fc;
																										IL_08fc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_093c;
																										IL_093c:
																										array[num5 - 2] = 0;
																										goto IL_0950;
																										IL_0950:
																										num5--;
																										goto end_IL_03ed;
																										continue;
																										end_IL_0363:
																										break;
																									}
																									goto IL_0b31;
																									IL_0b31:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0b5a;
																									IL_0b5a:
																									ptr2 += 8;
																									goto IL_0b68;
																									IL_0984:
																									if (5 <= b)
																									{
																										goto IL_098f;
																									}
																									goto IL_09f6;
																									IL_098f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_09cf;
																									IL_09cf:
																									array[num5 - 2] = 0;
																									goto IL_09e3;
																									IL_09e3:
																									num5--;
																									goto end_IL_03ed;
																									IL_09f6:
																									if (2 >= b)
																									{
																										goto IL_0a04;
																									}
																									goto IL_0aa0;
																									IL_0a04:
																									if (2 <= b)
																									{
																										num = 121;
																										goto IL_0a18;
																									}
																									goto IL_0a7f;
																									IL_0b68:
																									num5--;
																									goto end_IL_03ed;
																									IL_0a18:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0a58;
																									IL_0a58:
																									array[num5 - 2] = 0;
																									goto IL_0a6c;
																									IL_0a6c:
																									num5--;
																									goto end_IL_03ed;
																									IL_0a7f:
																									if (1 < b)
																									{
																										goto end_IL_03a9;
																									}
																									goto IL_0a8d;
																									IL_0a8d:
																									if (1 <= b)
																									{
																									}
																									goto end_IL_03a9;
																									IL_0aa0:
																									if (3 < b)
																									{
																										goto IL_0aab;
																									}
																									goto IL_0b23;
																									IL_0aab:
																									if (4 < b)
																									{
																										goto end_IL_03a9;
																									}
																									goto IL_0ab9;
																									IL_0ab9:
																									if (4 > b)
																									{
																										goto end_IL_03a9;
																									}
																									goto IL_0ac7;
																									IL_0ac7:
																									array[num5] = 0;
																									goto IL_0ad5;
																									IL_0ad5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0af8;
																									IL_0af8:
																									array2[num5] = null;
																									goto IL_0b02;
																									IL_0b02:
																									num5++;
																									goto IL_0b10;
																									IL_0b10:
																									ptr2 += 8;
																									goto end_IL_03ed;
																									IL_0b23:
																									if (3 > b)
																									{
																										goto end_IL_03a9;
																									}
																									goto IL_0b31;
																									continue;
																									end_IL_0376:
																									break;
																								}
																								continue;
																							}
																							goto IL_0b7b;
																							IL_0be6:
																							num5 -= 2;
																							goto end_IL_03ed;
																							IL_0b7b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							num = 39;
																							goto IL_0be6;
																							continue;
																							end_IL_0389:
																							break;
																						}
																						continue;
																					}
																					goto IL_03f8;
																					IL_0532:
																					if (14 < b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0540;
																					IL_0540:
																					if (14 > b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0736;
																					IL_03f8:
																					if (15 < b)
																					{
																						goto IL_0406;
																					}
																					goto IL_04e2;
																					IL_0406:
																					if (18 >= b)
																					{
																						goto IL_0411;
																					}
																					goto IL_046d;
																					IL_0411:
																					if (18 > b)
																					{
																						goto IL_041f;
																					}
																					goto IL_0597;
																					IL_041f:
																					if (16 >= b)
																					{
																						num = 35;
																						goto IL_0433;
																					}
																					goto IL_0446;
																					IL_0736:
																					*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((ColorOption[])array2[num5 - 1]).LongLength;
																					goto IL_0760;
																					IL_0433:
																					if (16 > b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0658;
																					IL_0658:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0698;
																					IL_0698:
																					array[num5 - 2] = 0;
																					goto IL_06ac;
																					IL_06ac:
																					num5--;
																					goto end_IL_03ed;
																					IL_0446:
																					if (17 < b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0454;
																					IL_0454:
																					if (17 > b)
																					{
																						goto end_IL_03a9;
																					}
																					num = 135;
																					goto IL_04b5;
																					IL_0760:
																					array[num5 - 1] = 2;
																					goto end_IL_03ed;
																					IL_04b5:
																					int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04cf;
																					IL_04cf:
																					num5--;
																					goto end_IL_03ed;
																					IL_0597:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_05af;
																					IL_05af:
																					array[num5] = 5;
																					goto IL_05bd;
																					IL_05bd:
																					num5++;
																					goto IL_063c;
																					IL_063c:
																					ptr2 += 8;
																					num = 34;
																					goto end_IL_03ed;
																					IL_046d:
																					if (19 < b)
																					{
																						goto IL_0478;
																					}
																					goto IL_04a2;
																					IL_0478:
																					if (20 < b)
																					{
																						goto end_IL_03a9;
																					}
																					num = 100;
																					goto IL_048f;
																					IL_0553:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_057e;
																					IL_048f:
																					if (20 > b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0620;
																					IL_0620:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_03ed;
																					IL_04a2:
																					if (19 > b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0779;
																					IL_0779:
																					((delegate*<Class129, void>)GetMethodTokenMathSymbol[*(int*)(ptr2 + num3)])((Class129)array2[num5 - 1]);
																					goto IL_07a2;
																					IL_07a2:
																					num5--;
																					goto IL_07b0;
																					IL_07b0:
																					ptr2 += 8;
																					goto end_IL_03ed;
																					IL_04e2:
																					if (15 > b)
																					{
																						goto IL_04ed;
																					}
																					goto IL_0553;
																					IL_04ed:
																					if (12 >= b)
																					{
																						goto IL_04f8;
																					}
																					num = 70;
																					goto IL_0514;
																					IL_04f8:
																					if (12 <= b)
																					{
																						goto IL_05cd;
																					}
																					goto IL_0715;
																					IL_05cd:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)GetMethodTokenMathSymbol[*(int*)(ptr2 + num3)])();
																					goto IL_05f1;
																					IL_05f1:
																					array[num5] = 0;
																					goto IL_05ff;
																					IL_05ff:
																					num5++;
																					goto IL_060d;
																					IL_060d:
																					ptr2 += 8;
																					goto end_IL_03ed;
																					IL_0715:
																					if (11 < b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_0723;
																					IL_0723:
																					if (11 <= b)
																					{
																						goto end_IL_03ed;
																					}
																					goto end_IL_03a9;
																					IL_057e:
																					array[num5 - 1] = 0;
																					goto end_IL_03ed;
																					IL_0514:
																					if (13 >= b)
																					{
																						goto IL_051f;
																					}
																					goto IL_0532;
																					IL_051f:
																					if (13 > b)
																					{
																						goto end_IL_03a9;
																					}
																					goto IL_06bf;
																					IL_06bf:
																					array2[num5] = ((delegate*<ColorOption[]>)GetMethodTokenMathSymbol[*(int*)(ptr2 + num3)])();
																					goto IL_06dd;
																					IL_06dd:
																					array[num5] = 5;
																					num = 143;
																					goto IL_06f4;
																					IL_06f4:
																					num5++;
																					goto IL_0702;
																					IL_0702:
																					ptr2 += 8;
																					goto end_IL_03ed;
																					continue;
																					end_IL_0399:
																					break;
																				}
																				continue;
																				end_IL_03a9:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		num = 26;
																		goto IL_0c18;
																		IL_0c34:
																		ptr2 += 8;
																		goto end_IL_03ed;
																		IL_0c26:
																		num5++;
																		goto IL_0c34;
																		IL_0c18:
																		array[num5] = 0;
																		goto IL_0c26;
																		continue;
																		end_IL_03b9:
																		break;
																	}
																	continue;
																	end_IL_03c9:
																	break;
																}
																continue;
																end_IL_03d9:
																break;
															}
															continue;
															end_IL_03ed:
															break;
														}
														continue;
														end_IL_0c42:
														break;
													}
													continue;
													end_IL_0c55:
													break;
												}
												continue;
												end_IL_0c60:
												break;
											}
											continue;
											end_IL_0c6a:
											break;
										}
										continue;
										end_IL_0c75:
										break;
									}
									continue;
									end_IL_0c85:
									break;
								}
								continue;
								end_IL_0c95:
								break;
							}
							continue;
							end_IL_0ca5:
							break;
						}
						continue;
						end_IL_0cb5:
						break;
					}
					continue;
					end_IL_0cc5:
					break;
				}
				continue;
				end_IL_0cd5:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_067d, IL_0690, IL_06bf, IL_06cf, IL_06df, IL_06ef, IL_06ff, IL_070f, IL_071c, IL_072c, IL_073c, IL_074c, IL_075c, IL_0767, IL_077a, IL_0785, IL_079b, IL_07a8, IL_07ec, IL_07fa, IL_080a, IL_081d, IL_0828, IL_0833, IL_0846, IL_0854, IL_0862, IL_0876, IL_08b5, IL_08c8, IL_08e1, IL_08f4, IL_090d, IL_091d, IL_0955, IL_096e, IL_09ab, IL_09cd, IL_09e0, IL_09eb, IL_09fe, IL_0a42, IL_0a55, IL_0a68, IL_0a73, IL_0a81, IL_0a95, IL_0ad4, IL_0ae7, IL_0af5, IL_0b03, IL_0b43, IL_0b60, IL_0b73, IL_0b86, IL_0b91, IL_0ba4, IL_0bb2, IL_0bef, IL_0c03, IL_0c16, IL_0c21, IL_0c35, IL_0c79, IL_0c87, IL_0c95, IL_0ca9, IL_0cf5, IL_0d03, IL_0d16, IL_0d24, IL_0d37, IL_0d50, IL_0d5e, IL_0d6c, IL_0d7f, IL_0d8d, IL_0d98, IL_0da6, IL_0dba, IL_0df2, IL_0e05, IL_0e10, IL_0e23, IL_0e2e, IL_0e41, IL_0e4f, IL_0e5d, IL_0e7a, IL_0ec9, IL_0ed3, IL_0f00, IL_0f19, IL_0f27, IL_0f32, IL_0f72, IL_0f86, IL_0f99, IL_0fa7, IL_0fb5, IL_0fc3, IL_0fd1, IL_0fdf, IL_101f, IL_1033, IL_1046, IL_1054, IL_1072, IL_109b, IL_10a9, IL_10bc, IL_10c7, IL_10d5, IL_10e3, IL_10f1, IL_10ff, IL_1148, IL_115c, IL_116f, IL_117d, IL_118b, IL_1196, IL_11a4, IL_11e4, IL_1201, IL_1214, IL_1222, IL_1230, IL_1243, IL_124c, IL_128c, IL_12a5, IL_12b3, IL_12c1, IL_132c, IL_133f, IL_134d, IL_135b, IL_1369, IL_137d, IL_13bc, IL_13cf, IL_1410, IL_1429, IL_1437, IL_1460, IL_146e, IL_1481, IL_148f, IL_14a2, IL_14cb, IL_14e2, IL_14f5, IL_1503, IL_1526, IL_1530, IL_153e, IL_1551, IL_155f, IL_159f, IL_15b3, IL_15c6, IL_15d4, IL_15df, IL_15fb, IL_1609, IL_1617, IL_1640, IL_164e, IL_1661, IL_166f, IL_1682, IL_1695, IL_16a8, IL_16bb, IL_16ce, IL_16e1, IL_16f4, IL_16ff, IL_170d, IL_172f, IL_173d, IL_174b, IL_175e, IL_176c, IL_177a, IL_1792, IL_17a0, IL_17ae, IL_17c1, IL_17e4, IL_17f2, IL_1800, IL_1813, IL_1821, IL_184b, IL_1859, IL_186c, IL_187f, IL_188d, IL_189b, IL_18a6, IL_18b4, IL_18d2, IL_18e9, IL_18fc, IL_190a, IL_1918, IL_194a, IL_1963, IL_197b, IL_1999, IL_19bd, IL_19de, IL_19fa, IL_1a05, IL_1a13, IL_1a21, IL_1a5f, IL_1a7b, IL_1a89, IL_1a97, IL_1aaf, IL_1abd, IL_1ad0, IL_1b22, IL_1b35, IL_1b43, IL_1b51, IL_1b64, IL_1b72, IL_1b80, IL_1bbd, IL_1bd1, IL_1be4, IL_1bef, IL_1c0d, IL_1c1b, IL_1c29, IL_1c3c, IL_1c4a, IL_1c58, IL_1c6c, IL_1cbe, IL_1ccc, IL_1cdf, IL_1cea, IL_1cf5, IL_1d09, IL_1d48, IL_1d58, IL_1d6b, IL_1d7e, IL_1d88, IL_1d93, IL_1da3, IL_1db3, IL_1dc3, IL_1dd3, IL_1dec, IL_1dfc, IL_1e0c, IL_1e1c are reachable both inside and outside the pinned region starting at IL_1e31. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 398;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef41 = default(int);
			ref int reference = ref __rxRef41;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				num = 397;
				while (true)
				{
					IL_1e1c:
					num2 = 1;
					while (true)
					{
						IL_1e0c:
						num3 = num2 * 4;
						while (true)
						{
							IL_1dfc:
							num4 = num2 * 8;
							while (true)
							{
								IL_1dec:
								array2 = new byte[4];
								while (true)
								{
									IL_1dd3:
									array3 = new object[4];
									num = 271;
									while (true)
									{
										IL_1dc3:
										array4 = new int[4];
										while (true)
										{
											IL_1db3:
											array5 = new int[7];
											while (true)
											{
												IL_1da3:
												array6 = new long[4];
												while (true)
												{
													IL_1d93:
													array7 = new object[16];
													while (true)
													{
														IL_1d88:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RecordFixupVARFLAGFIMMEDIATEBIND.CausalityTracerFileOptions);
														while (true)
														{
															IL_1d7e:
															ptr2 = ptr;
															while (true)
															{
																IL_1d6b:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_075c:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_074c:
																		ptr2++;
																		while (true)
																		{
																			IL_073c:
																			if (b >= 1)
																			{
																				while (b <= 48)
																				{
																					while (true)
																					{
																						IL_071c:
																						if (24 < b)
																						{
																							while (true)
																							{
																								IL_070f:
																								if (36 < b)
																								{
																									while (true)
																									{
																										IL_06ff:
																										if (42 >= b)
																										{
																											num = 342;
																											while (true)
																											{
																												IL_06ef:
																												if (42 > b)
																												{
																													while (true)
																													{
																														IL_06df:
																														if (39 < b)
																														{
																															while (true)
																															{
																																IL_06cf:
																																if (40 >= b)
																																{
																																	while (40 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_0690:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																																			num = 408;
																																			while (true)
																																			{
																																				if (num != 408)
																																				{
																																					if (num != 1389)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 398:
																																						break;
																																					default:
																																						continue;
																																					case 17:
																																					case 336:
																																						goto IL_0690;
																																					case 136:
																																						goto IL_06bf;
																																					case 120:
																																						goto IL_06cf;
																																					case 348:
																																						goto IL_06df;
																																					case 342:
																																						goto IL_06ef;
																																					case 286:
																																						goto IL_06ff;
																																					case 14:
																																						goto IL_070f;
																																					case 268:
																																						goto IL_071c;
																																					case 118:
																																						goto IL_072c;
																																					case 171:
																																						goto IL_073c;
																																					case 267:
																																						goto IL_074c;
																																					case 151:
																																					case 231:
																																						goto IL_075c;
																																					case 63:
																																						goto IL_0767;
																																					case 96:
																																						goto IL_077a;
																																					case 67:
																																					case 80:
																																						goto IL_0785;
																																					case 45:
																																						goto IL_079b;
																																					case 169:
																																						goto IL_07a8;
																																					case 189:
																																						goto IL_07ec;
																																					case 115:
																																						goto IL_07fa;
																																					case 193:
																																						goto IL_080a;
																																					case 208:
																																						goto IL_081d;
																																					case 21:
																																						goto IL_0828;
																																					case 48:
																																						goto IL_0833;
																																					case 148:
																																						goto IL_0846;
																																					case 58:
																																					case 145:
																																						goto IL_0862;
																																					case 122:
																																						goto IL_0876;
																																					case 94:
																																						goto IL_08b5;
																																					case 41:
																																					case 216:
																																						goto IL_08c8;
																																					case 27:
																																						goto IL_08e1;
																																					case 93:
																																					case 223:
																																						goto IL_08f4;
																																					case 227:
																																						goto IL_090d;
																																					case 237:
																																					case 246:
																																						goto IL_091d;
																																					case 39:
																																						goto IL_0955;
																																					case 81:
																																					case 247:
																																						goto IL_096e;
																																					case 85:
																																						goto IL_09ab;
																																					case 253:
																																						goto IL_09cd;
																																					case 258:
																																						goto IL_09e0;
																																					case 158:
																																						goto IL_09eb;
																																					case 266:
																																						goto IL_09fe;
																																					case 277:
																																						goto IL_0a42;
																																					case 289:
																																						goto IL_0a55;
																																					case 298:
																																						goto IL_0a68;
																																					case 97:
																																						goto IL_0a73;
																																					case 3:
																																					case 64:
																																						goto IL_0a81;
																																					case 106:
																																						goto IL_0a95;
																																					case 2:
																																						goto IL_0ad4;
																																					case 146:
																																						goto IL_0ae7;
																																					case 15:
																																						goto IL_0af5;
																																					case 225:
																																					case 250:
																																						goto IL_0b03;
																																					case 20:
																																						goto IL_0b43;
																																					case 30:
																																						goto IL_0b60;
																																					case 303:
																																						goto IL_0b73;
																																					case 326:
																																						goto IL_0b86;
																																					case 292:
																																						goto IL_0b91;
																																					case 16:
																																						goto IL_0ba4;
																																					case 127:
																																					case 337:
																																						goto IL_0bb2;
																																					case 143:
																																						goto IL_0bef;
																																					case 147:
																																						goto IL_0c03;
																																					case 339:
																																						goto end_IL_067d;
																																					case 113:
																																					case 287:
																																						goto IL_0c21;
																																					case 200:
																																						goto IL_0c35;
																																					case 40:
																																						goto IL_0c79;
																																					case 282:
																																						goto IL_0c87;
																																					case 29:
																																					case 236:
																																						goto IL_0c95;
																																					case 126:
																																						goto IL_0ca9;
																																					case 73:
																																						goto IL_0cf5;
																																					case 57:
																																						goto IL_0d03;
																																					case 74:
																																						goto IL_0d16;
																																					case 285:
																																						goto IL_0d24;
																																					case 109:
																																					case 340:
																																						goto IL_0d37;
																																					case 167:
																																						goto IL_0d50;
																																					case 239:
																																						goto IL_0d5e;
																																					case 162:
																																						goto IL_0d6c;
																																					case 352:
																																						goto IL_0d7f;
																																					case 241:
																																						goto IL_0d8d;
																																					case 209:
																																						goto IL_0d98;
																																					case 42:
																																					case 256:
																																						goto IL_0da6;
																																					case 82:
																																						goto IL_0dba;
																																					case 75:
																																						goto IL_0df2;
																																					case 86:
																																						goto IL_0e05;
																																					case 10:
																																						goto IL_0e10;
																																					case 9:
																																						goto IL_0e23;
																																					case 6:
																																						goto IL_0e2e;
																																					case 226:
																																						goto IL_0e4f;
																																					case 172:
																																					case 317:
																																						goto IL_0e5d;
																																					case 104:
																																						goto IL_0f19;
																																					case 314:
																																						goto IL_0f27;
																																					case 130:
																																					case 315:
																																						goto IL_0f32;
																																					case 262:
																																						goto IL_0f72;
																																					case 252:
																																						goto IL_0f86;
																																					case 153:
																																						goto IL_0f99;
																																					case 265:
																																						goto IL_0fa7;
																																					case 90:
																																						goto IL_0fb5;
																																					case 117:
																																						goto IL_0fc3;
																																					case 274:
																																						goto IL_0fd1;
																																					case 273:
																																					case 302:
																																						goto IL_0fdf;
																																					case 138:
																																						goto IL_101f;
																																					case 257:
																																						goto IL_1033;
																																					case 214:
																																						goto IL_1046;
																																					case 36:
																																					case 279:
																																						goto IL_1054;
																																					case 161:
																																					case 244:
																																						goto IL_1072;
																																					case 198:
																																						goto IL_109b;
																																					case 338:
																																						goto IL_10a9;
																																					case 62:
																																						goto IL_10bc;
																																					case 142:
																																						goto IL_10c7;
																																					case 5:
																																						goto IL_10e3;
																																					case 350:
																																						goto IL_10f1;
																																					case 76:
																																					case 102:
																																						goto IL_10ff;
																																					case 88:
																																						goto IL_1148;
																																					case 331:
																																						goto IL_115c;
																																					case 308:
																																						goto IL_116f;
																																					case 69:
																																						goto IL_117d;
																																					case 152:
																																						goto IL_118b;
																																					case 288:
																																						goto IL_1196;
																																					case 0:
																																					case 4:
																																						goto IL_11a4;
																																					case 320:
																																						goto IL_11e4;
																																					case 111:
																																						goto IL_1201;
																																					case 243:
																																						goto IL_1214;
																																					case 149:
																																						goto IL_1222;
																																					case 92:
																																					case 349:
																																						goto IL_1230;
																																					case 89:
																																					case 276:
																																						goto IL_124c;
																																					case 296:
																																						goto IL_128c;
																																					case 107:
																																						goto IL_12a5;
																																					case 160:
																																						goto IL_12b3;
																																					case 195:
																																					case 344:
																																						goto IL_12c1;
																																					case 177:
																																						goto IL_132c;
																																					case 163:
																																						goto IL_133f;
																																					case 233:
																																						goto IL_134d;
																																					case 135:
																																					case 356:
																																						goto IL_1369;
																																					case 232:
																																						goto IL_137d;
																																					case 242:
																																						goto IL_13bc;
																																					case 51:
																																					case 360:
																																						goto IL_13cf;
																																					case 319:
																																						goto IL_1410;
																																					case 364:
																																						goto IL_1429;
																																					case 196:
																																					case 264:
																																						goto IL_1437;
																																					case 101:
																																						goto IL_1460;
																																					case 362:
																																						goto IL_146e;
																																					case 366:
																																						goto IL_1481;
																																					case 55:
																																						goto IL_148f;
																																					case 238:
																																					case 367:
																																						goto IL_14a2;
																																					case 205:
																																						goto IL_14cb;
																																					case 53:
																																						goto IL_14e2;
																																					case 203:
																																					case 369:
																																						goto IL_14f5;
																																					case 293:
																																						goto IL_1503;
																																					case 334:
																																						goto IL_1526;
																																					case 103:
																																						goto IL_1530;
																																					case 116:
																																						goto IL_153e;
																																					case 370:
																																						goto IL_1551;
																																					case 8:
																																					case 77:
																																						goto IL_155f;
																																					case 179:
																																						goto IL_159f;
																																					case 175:
																																						goto IL_15b3;
																																					case 371:
																																						goto IL_15c6;
																																					case 211:
																																						goto IL_15d4;
																																					case 144:
																																					case 304:
																																						goto IL_15df;
																																					case 330:
																																						goto IL_15fb;
																																					case 141:
																																						goto IL_1609;
																																					case 91:
																																					case 132:
																																						goto IL_1617;
																																					case 341:
																																						goto IL_1640;
																																					case 217:
																																						goto IL_164e;
																																					case 311:
																																						goto IL_1661;
																																					case 355:
																																						goto IL_166f;
																																					case 372:
																																						goto IL_1682;
																																					case 373:
																																						goto IL_1695;
																																					case 374:
																																						goto IL_16a8;
																																					case 379:
																																						goto IL_16bb;
																																					case 381:
																																						goto IL_16ce;
																																					case 384:
																																						goto IL_16e1;
																																					case 385:
																																						goto IL_16f4;
																																					case 194:
																																						goto IL_16ff;
																																					case 35:
																																					case 188:
																																						goto IL_170d;
																																					case 134:
																																						goto IL_172f;
																																					case 254:
																																						goto IL_173d;
																																					case 178:
																																						goto IL_174b;
																																					case 43:
																																						goto IL_175e;
																																					case 165:
																																						goto IL_176c;
																																					case 1:
																																					case 157:
																																						goto IL_177a;
																																					case 388:
																																						goto IL_1792;
																																					case 219:
																																						goto IL_17a0;
																																					case 191:
																																						goto IL_17ae;
																																					case 47:
																																					case 391:
																																						goto IL_17c1;
																																					case 173:
																																						goto IL_17e4;
																																					case 301:
																																						goto IL_17f2;
																																					case 368:
																																						goto IL_1800;
																																					case 393:
																																						goto IL_1813;
																																					case 7:
																																					case 129:
																																						goto IL_1821;
																																					case 66:
																																						goto IL_184b;
																																					case 249:
																																						goto IL_1859;
																																					case 395:
																																						goto IL_186c;
																																					case 400:
																																						goto IL_187f;
																																					case 28:
																																						goto IL_188d;
																																					case 13:
																																						goto IL_189b;
																																					case 313:
																																						goto IL_18a6;
																																					case 297:
																																					case 386:
																																						goto IL_18b4;
																																					case 11:
																																						goto IL_18d2;
																																					case 70:
																																						goto IL_18e9;
																																					case 65:
																																						goto IL_18fc;
																																					case 121:
																																						goto IL_190a;
																																					case 119:
																																					case 174:
																																						goto IL_1918;
																																					case 19:
																																						goto IL_194a;
																																					case 229:
																																					case 380:
																																						goto IL_1963;
																																					case 284:
																																						goto IL_197b;
																																					case 100:
																																						goto IL_1999;
																																					case 114:
																																						goto IL_19bd;
																																					case 290:
																																						goto IL_19de;
																																					case 335:
																																						goto IL_19fa;
																																					case 78:
																																						goto IL_1a05;
																																					case 322:
																																						goto IL_1a13;
																																					case 131:
																																					case 186:
																																						goto IL_1a21;
																																					case 99:
																																						goto IL_1a5f;
																																					case 316:
																																						goto IL_1a7b;
																																					case 52:
																																					case 270:
																																						goto IL_1a89;
																																					case 212:
																																						goto IL_1a97;
																																					case 399:
																																						goto IL_1aaf;
																																					case 327:
																																						goto IL_1abd;
																																					case 307:
																																					case 401:
																																						goto IL_1ad0;
																																					case 309:
																																						goto IL_1b22;
																																					case 234:
																																						goto IL_1b43;
																																					case 95:
																																						goto IL_1b51;
																																					case 187:
																																						goto IL_1b64;
																																					case 34:
																																						goto IL_1b72;
																																					case 128:
																																					case 235:
																																						goto IL_1b80;
																																					case 324:
																																						goto IL_1bbd;
																																					case 199:
																																						goto IL_1bd1;
																																					case 375:
																																						goto IL_1be4;
																																					case 125:
																																					case 260:
																																						goto IL_1bef;
																																					case 110:
																																						goto IL_1c0d;
																																					case 259:
																																						goto IL_1c1b;
																																					case 278:
																																						goto IL_1c29;
																																					case 281:
																																						goto IL_1c3c;
																																					case 376:
																																						goto IL_1c4a;
																																					case 87:
																																					case 182:
																																						goto IL_1c58;
																																					case 105:
																																						goto IL_1c6c;
																																					case 207:
																																						goto IL_1cbe;
																																					case 190:
																																						goto IL_1ccc;
																																					case 156:
																																						goto IL_1cdf;
																																					case 37:
																																						goto IL_1cea;
																																					case 312:
																																					case 325:
																																						goto IL_1cf5;
																																					case 83:
																																						goto IL_1d09;
																																					case 396:
																																						goto IL_1d48;
																																					case 22:
																																					case 23:
																																					case 24:
																																					case 25:
																																					case 26:
																																					case 31:
																																					case 32:
																																					case 44:
																																					case 46:
																																					case 49:
																																					case 50:
																																					case 54:
																																					case 60:
																																					case 68:
																																					case 71:
																																					case 112:
																																					case 124:
																																					case 133:
																																					case 140:
																																					case 150:
																																					case 170:
																																					case 181:
																																					case 197:
																																					case 210:
																																					case 213:
																																					case 218:
																																					case 220:
																																					case 222:
																																					case 224:
																																					case 245:
																																					case 248:
																																					case 255:
																																					case 261:
																																					case 263:
																																					case 272:
																																					case 280:
																																					case 283:
																																					case 291:
																																					case 300:
																																					case 306:
																																					case 318:
																																					case 321:
																																					case 329:
																																					case 332:
																																					case 357:
																																					case 358:
																																					case 365:
																																					case 382:
																																					case 387:
																																					case 389:
																																					case 394:
																																						goto end_IL_06bf;
																																					case 12:
																																					case 18:
																																					case 33:
																																					case 38:
																																					case 56:
																																					case 59:
																																					case 61:
																																					case 72:
																																					case 84:
																																					case 98:
																																					case 108:
																																					case 137:
																																					case 139:
																																					case 154:
																																					case 155:
																																					case 159:
																																					case 164:
																																					case 166:
																																					case 168:
																																					case 176:
																																					case 183:
																																					case 201:
																																					case 202:
																																					case 204:
																																					case 206:
																																					case 215:
																																					case 221:
																																					case 228:
																																					case 240:
																																					case 251:
																																					case 269:
																																					case 294:
																																					case 295:
																																					case 299:
																																					case 310:
																																					case 323:
																																					case 328:
																																					case 333:
																																					case 343:
																																					case 345:
																																					case 346:
																																					case 347:
																																					case 351:
																																					case 354:
																																					case 359:
																																					case 361:
																																					case 377:
																																					case 378:
																																					case 383:
																																					case 390:
																																					case 392:
																																						goto IL_1d6b;
																																					case 353:
																																						goto IL_1d7e;
																																					case 185:
																																						goto IL_1d88;
																																					case 184:
																																						goto IL_1d93;
																																					case 79:
																																						goto IL_1da3;
																																					case 180:
																																						goto IL_1db3;
																																					case 271:
																																						goto IL_1dc3;
																																					case 305:
																																						goto IL_1dd3;
																																					case 192:
																																						goto IL_1dec;
																																					case 275:
																																						goto IL_1dfc;
																																					case 230:
																																						goto IL_1e0c;
																																					case 397:
																																						goto IL_1e1c;
																																					case 123:
																																					case 363:
																																						return;
																																					}
																																					goto end_IL_073c;
																																				}
																																				array2[num6] = 0;
																																				goto IL_1b43;
																																				IL_1b43:
																																				num6++;
																																				goto IL_1b51;
																																				IL_1b51:
																																				ptr2 += 8;
																																				goto IL_1d6b;
																																				continue;
																																				end_IL_067d:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_0c16;
																																		continue;
																																		end_IL_06bf:
																																		break;
																																		IL_06bf:;
																																	}
																																	break;
																																}
																																goto IL_1b64;
																																IL_1bd1:
																																num6--;
																																goto IL_1d6b;
																																IL_1b64:
																																if (41 < b)
																																{
																																	break;
																																}
																																goto IL_1b72;
																																IL_1b72:
																																if (41 > b)
																																{
																																	break;
																																}
																																goto IL_1b80;
																																IL_1b80:
																																array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																goto IL_1bbd;
																																IL_1bbd:
																																array2[num6 - 2] = 4;
																																goto IL_1bd1;
																															}
																															break;
																														}
																														goto IL_1be4;
																														IL_1d48:
																														ptr2 += 8;
																														goto IL_1d6b;
																														IL_1be4:
																														if (39 <= b)
																														{
																															goto IL_1bef;
																														}
																														goto IL_1c3c;
																														IL_1bef:
																														array3[num6] = ((delegate*<ColorOption[]>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																														goto IL_1c0d;
																														IL_1c0d:
																														array2[num6] = 5;
																														goto IL_1c1b;
																														IL_1c1b:
																														num6++;
																														goto IL_1c29;
																														IL_1c29:
																														ptr2 += 8;
																														goto IL_1d6b;
																														IL_1c3c:
																														if (37 >= b)
																														{
																															goto IL_1c4a;
																														}
																														goto IL_1cdf;
																														IL_1c4a:
																														if (37 > b)
																														{
																															break;
																														}
																														goto IL_1c58;
																														IL_1c58:
																														array2[num6 - 2] = 0;
																														goto IL_1c6c;
																														IL_1c6c:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																														goto IL_1cbe;
																														IL_1cbe:
																														num6--;
																														goto IL_1ccc;
																														IL_1ccc:
																														ptr2 += 8;
																														goto IL_1d6b;
																														IL_1cdf:
																														if (38 < b)
																														{
																															break;
																														}
																														goto IL_1cea;
																														IL_1cea:
																														if (38 > b)
																														{
																															break;
																														}
																														goto IL_1cf5;
																														IL_1cf5:
																														array2[num6 - 1] = 3;
																														goto IL_1d09;
																														IL_1d09:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_1d48;
																													}
																													break;
																												}
																												goto IL_08c8;
																												IL_08e1:
																												num6--;
																												goto IL_1d6b;
																												IL_08c8:
																												global::_003CModule_003E.colorOption_0 = (ColorOption)array3[num6 - 1];
																												goto IL_08e1;
																											}
																											break;
																										}
																										goto IL_0767;
																										IL_1661:
																										if (48 < b)
																										{
																											break;
																										}
																										goto IL_166f;
																										IL_166f:
																										if (48 > b)
																										{
																										}
																										break;
																										IL_0767:
																										if (45 >= b)
																										{
																											goto IL_090d;
																										}
																										goto IL_15c6;
																										IL_090d:
																										if (45 <= b)
																										{
																											goto IL_096e;
																										}
																										goto IL_0a68;
																										IL_0a68:
																										if (43 >= b)
																										{
																											goto IL_0a73;
																										}
																										goto IL_0ae7;
																										IL_0a73:
																										if (43 > b)
																										{
																											break;
																										}
																										goto IL_0a81;
																										IL_0a81:
																										array2[num6 - 1] = 3;
																										goto IL_0a95;
																										IL_0a95:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0ad4;
																										IL_0ad4:
																										ptr2 += 8;
																										goto IL_1d6b;
																										IL_0ae7:
																										if (44 < b)
																										{
																											break;
																										}
																										goto IL_0af5;
																										IL_0af5:
																										if (44 > b)
																										{
																											break;
																										}
																										goto IL_0b03;
																										IL_0b03:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0b43;
																										IL_0b43:
																										array2[num6 - 2] = 3;
																										num = 30;
																										goto IL_0b60;
																										IL_0b60:
																										num6--;
																										goto IL_1d6b;
																										IL_096e:
																										array3[num6 - 1] = ((delegate*<ColorOption, Color>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																										goto IL_09ab;
																										IL_09ab:
																										array2[num6 - 1] = 4;
																										num = 373;
																										goto IL_1695;
																										IL_1695:
																										ptr2 += 8;
																										goto IL_1d6b;
																										IL_15c6:
																										if (47 >= b)
																										{
																											goto IL_15d4;
																										}
																										goto IL_1661;
																										IL_15d4:
																										if (47 <= b)
																										{
																											goto IL_15df;
																										}
																										goto IL_15fb;
																										IL_15df:
																										num7 = ptr2;
																										num8 = -200;
																										num5 = 1;
																										ptr2 = num7 + num8;
																										goto IL_1d6b;
																										IL_15fb:
																										if (46 < b)
																										{
																											break;
																										}
																										goto IL_1609;
																										IL_1609:
																										if (46 > b)
																										{
																											break;
																										}
																										goto IL_1617;
																										IL_1617:
																										((delegate*<Color, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																										goto IL_1640;
																										IL_1640:
																										num6--;
																										goto IL_164e;
																										IL_164e:
																										ptr2 += 8;
																										goto IL_1d6b;
																									}
																									break;
																								}
																								goto IL_077a;
																								IL_0bef:
																								array2[num6 - 1] = 4;
																								goto IL_0c03;
																								IL_077a:
																								if (36 <= b)
																								{
																									goto IL_0785;
																								}
																								goto IL_079b;
																								IL_0785:
																								array2[num6 - 1] = 3;
																								goto IL_07a8;
																								IL_07a8:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_16bb;
																								IL_16bb:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_079b:
																								if (30 >= b)
																								{
																									goto IL_07ec;
																								}
																								goto IL_080a;
																								IL_07ec:
																								if (30 > b)
																								{
																									goto IL_07fa;
																								}
																								goto IL_091d;
																								IL_07fa:
																								if (27 >= b)
																								{
																									goto IL_081d;
																								}
																								goto IL_09e0;
																								IL_09e0:
																								if (28 < b)
																								{
																									goto IL_09eb;
																								}
																								goto IL_0a42;
																								IL_09eb:
																								if (29 < b)
																								{
																									break;
																								}
																								goto IL_0b73;
																								IL_0b73:
																								if (29 > b)
																								{
																									break;
																								}
																								goto IL_17c1;
																								IL_17c1:
																								array3[num6] = ((delegate*<ColorOption>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																								goto IL_17e4;
																								IL_17e4:
																								array2[num6] = 4;
																								goto IL_17f2;
																								IL_17f2:
																								num6++;
																								goto IL_1800;
																								IL_1800:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0a42:
																								if (28 > b)
																								{
																									break;
																								}
																								goto IL_1369;
																								IL_1369:
																								array2[num6 - 1] = 3;
																								goto IL_137d;
																								IL_137d:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_13bc;
																								IL_13bc:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_081d:
																								if (27 > b)
																								{
																									goto IL_0828;
																								}
																								goto IL_0862;
																								IL_0828:
																								if (25 >= b)
																								{
																									goto IL_0833;
																								}
																								goto IL_0846;
																								IL_0833:
																								if (25 > b)
																								{
																									break;
																								}
																								goto IL_08f4;
																								IL_08f4:
																								array2[num6 - 1] = 3;
																								goto IL_09fe;
																								IL_09fe:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_16a8;
																								IL_16a8:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0846:
																								if (26 < b)
																								{
																									break;
																								}
																								num = 370;
																								goto IL_1551;
																								IL_0c03:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_1551:
																								if (26 > b)
																								{
																									break;
																								}
																								goto IL_155f;
																								IL_155f:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_159f;
																								IL_159f:
																								array2[num6 - 2] = 3;
																								goto IL_15b3;
																								IL_15b3:
																								num6--;
																								goto IL_1d6b;
																								IL_0862:
																								array2[num6 - 1] = 0;
																								goto IL_0876;
																								IL_0876:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_08b5;
																								IL_08b5:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_091d:
																								array3[num6 - 1] = ((delegate*<ColorOption, string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																								goto IL_0955;
																								IL_0955:
																								array2[num6 - 1] = 5;
																								goto IL_0a55;
																								IL_0a55:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_080a:
																								if (33 < b)
																								{
																									goto IL_0b86;
																								}
																								goto IL_0c16;
																								IL_0c16:
																								if (33 <= b)
																								{
																									goto IL_0c21;
																								}
																								goto IL_0c79;
																								IL_0c21:
																								array2[num6 - 1] = 3;
																								goto IL_0c35;
																								IL_0c35:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_16ce;
																								IL_16ce:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0c79:
																								if (31 >= b)
																								{
																									goto IL_0c87;
																								}
																								goto IL_0d16;
																								IL_0c87:
																								if (31 > b)
																								{
																									break;
																								}
																								goto IL_0c95;
																								IL_0c95:
																								array2[num6 - 2] = 5;
																								goto IL_0ca9;
																								IL_0ca9:
																								array3[num6 - 2] = ((delegate*<string, string, string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																								goto IL_0cf5;
																								IL_0cf5:
																								num6--;
																								goto IL_0d03;
																								IL_0d03:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0d16:
																								if (32 < b)
																								{
																									break;
																								}
																								goto IL_0d24;
																								IL_0d24:
																								if (32 > b)
																								{
																									break;
																								}
																								goto IL_14a2;
																								IL_14a2:
																								((delegate*<string, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_14cb;
																								IL_14cb:
																								num6--;
																								num = 53;
																								goto IL_14e2;
																								IL_14e2:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0b86:
																								if (34 < b)
																								{
																									goto IL_0b91;
																								}
																								goto IL_0ba4;
																								IL_0b91:
																								if (35 < b)
																								{
																									break;
																								}
																								goto IL_1429;
																								IL_1429:
																								if (35 > b)
																								{
																									break;
																								}
																								goto IL_1437;
																								IL_1437:
																								((delegate*<Color, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																								goto IL_1460;
																								IL_1460:
																								num6--;
																								goto IL_146e;
																								IL_146e:
																								ptr2 += 8;
																								goto IL_1d6b;
																								IL_0ba4:
																								if (34 > b)
																								{
																									break;
																								}
																								goto IL_0bb2;
																								IL_0bb2:
																								array3[num6 - 1] = ((delegate*<ColorOption, Color>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																								goto IL_0bef;
																							}
																							break;
																						}
																						goto IL_09cd;
																						IL_1682:
																						num6--;
																						goto IL_1d6b;
																						IL_09cd:
																						if (24 <= b)
																						{
																							goto IL_0d37;
																						}
																						goto IL_0d7f;
																						IL_0d37:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_0d50;
																						IL_0d50:
																						array2[num6] = 3;
																						goto IL_0d5e;
																						IL_0d5e:
																						num6++;
																						goto IL_0d6c;
																						IL_0d6c:
																						ptr2 += 16;
																						goto IL_1d6b;
																						IL_0d7f:
																						if (12 < b)
																						{
																							goto IL_0d8d;
																						}
																						goto IL_0e4f;
																						IL_0d8d:
																						if (18 >= b)
																						{
																							goto IL_0d98;
																						}
																						goto IL_0e05;
																						IL_0d98:
																						if (18 <= b)
																						{
																							goto IL_0da6;
																						}
																						goto IL_187f;
																						IL_0da6:
																						array2[num6 - 1] = 5;
																						goto IL_0dba;
																						IL_0dba:
																						array3[num6 - 1] = ((delegate*<string[], string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_0df2;
																						IL_0df2:
																						ptr2 += 8;
																						goto IL_1d6b;
																						IL_187f:
																						if (15 >= b)
																						{
																							goto IL_188d;
																						}
																						goto IL_19fa;
																						IL_188d:
																						if (15 > b)
																						{
																							goto IL_189b;
																						}
																						goto IL_1963;
																						IL_189b:
																						if (13 >= b)
																						{
																							goto IL_18a6;
																						}
																						goto IL_18fc;
																						IL_18a6:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_18b4;
																						IL_18b4:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_18d2;
																						IL_18d2:
																						ptr2 += 8;
																						num = 70;
																						goto IL_18e9;
																						IL_18e9:
																						num6--;
																						goto IL_1d6b;
																						IL_18fc:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_190a;
																						IL_190a:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_1918;
																						IL_1918:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						num = 19;
																						goto IL_194a;
																						IL_194a:
																						array2[num6 - 1] = 5;
																						goto IL_1d6b;
																						IL_1963:
																						array2[num6] = array2[num6 - 1];
																						goto IL_197b;
																						IL_197b:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_1999;
																						IL_1999:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_19bd;
																						IL_19bd:
																						array3[num6] = array3[num6 - 1];
																						num = 290;
																						goto IL_19de;
																						IL_19de:
																						num6++;
																						num = 12;
																						goto IL_1d6b;
																						IL_19fa:
																						if (16 < b)
																						{
																							goto IL_1a05;
																						}
																						goto IL_1a7b;
																						IL_1a05:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_1a13;
																						IL_1a13:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_1a21;
																						IL_1a21:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_1a5f;
																						IL_1a5f:
																						num6 -= 3;
																						num = 240;
																						goto IL_1d6b;
																						IL_1a7b:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_1a89;
																						IL_1a89:
																						array2[num6] = 5;
																						goto IL_1a97;
																						IL_1a97:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_1aaf;
																						IL_1aaf:
																						num6++;
																						goto IL_1abd;
																						IL_1abd:
																						ptr2 += 8;
																						goto IL_1d6b;
																						IL_0e05:
																						if (21 >= b)
																						{
																							goto IL_0e10;
																						}
																						goto IL_0e23;
																						IL_0e10:
																						if (21 <= b)
																						{
																							goto IL_13cf;
																						}
																						goto IL_16f4;
																						IL_13cf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_1410;
																						IL_1410:
																						array2[num6 - 2] = 0;
																						goto IL_186c;
																						IL_186c:
																						num6--;
																						goto IL_1d6b;
																						IL_16f4:
																						if (19 >= b)
																						{
																							goto IL_16ff;
																						}
																						goto IL_175e;
																						IL_16ff:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_170d;
																						IL_170d:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						num = 134;
																						goto IL_172f;
																						IL_172f:
																						array2[num6] = 1;
																						goto IL_173d;
																						IL_173d:
																						num6++;
																						goto IL_174b;
																						IL_174b:
																						ptr2 += 16;
																						goto IL_1d6b;
																						IL_175e:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_176c;
																						IL_176c:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_177a;
																						IL_177a:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_1d6b;
																						IL_0e23:
																						if (22 < b)
																						{
																							goto IL_0e2e;
																						}
																						num = 384;
																						goto IL_16e1;
																						IL_0e2e:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_1813;
																						IL_1813:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_1821;
																						IL_1821:
																						((delegate*<bool, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																						goto IL_184b;
																						IL_184b:
																						num6--;
																						goto IL_1859;
																						IL_1859:
																						ptr2 += 8;
																						goto IL_1d6b;
																						IL_12a5:
																						if (10 >= b)
																						{
																							goto IL_12b3;
																						}
																						goto IL_133f;
																						IL_16e1:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_1ad0;
																						IL_1ad0:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1b22;
																						IL_1b22:
																						num6--;
																						goto IL_1d6b;
																						IL_0e4f:
																						if (12 <= b)
																						{
																							goto IL_0e5d;
																						}
																						goto IL_0f19;
																						IL_0e5d:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_0e6c;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_1481;
																						IL_12b3:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_12c1;
																						IL_12c1:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						num = 177;
																						goto IL_132c;
																						IL_132c:
																						num6 -= 2;
																						goto IL_1d6b;
																						IL_1481:
																						array2[num6] = 5;
																						goto IL_148f;
																						IL_148f:
																						num6++;
																						goto IL_1d6b;
																						IL_0f19:
																						if (6 >= b)
																						{
																							goto IL_0f27;
																						}
																						goto IL_116f;
																						IL_0f27:
																						if (6 <= b)
																						{
																							goto IL_0f32;
																						}
																						goto IL_0f99;
																						IL_0f32:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0f72;
																						IL_0f72:
																						array2[num6 - 2] = 0;
																						goto IL_0f86;
																						IL_0f86:
																						num6--;
																						goto IL_1d6b;
																						IL_0f99:
																						if (3 >= b)
																						{
																							goto IL_0fa7;
																						}
																						goto IL_10bc;
																						IL_0fa7:
																						if (3 > b)
																						{
																							goto IL_0fb5;
																						}
																						goto IL_1072;
																						IL_0fb5:
																						if (1 < b)
																						{
																							goto IL_0fc3;
																						}
																						goto IL_1046;
																						IL_0fc3:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_0fd1;
																						IL_0fd1:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_0fdf;
																						IL_0fdf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_101f;
																						IL_101f:
																						array2[num6 - 2] = 0;
																						goto IL_1033;
																						IL_1033:
																						num6--;
																						goto IL_1d6b;
																						IL_1046:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_1054;
																						IL_1054:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_1792;
																						IL_1792:
																						array2[num6] = 0;
																						goto IL_17a0;
																						IL_17a0:
																						num6++;
																						goto IL_17ae;
																						IL_17ae:
																						ptr2 += 8;
																						goto IL_1d6b;
																						IL_1072:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_109b;
																						IL_109b:
																						ptr2 += 8;
																						goto IL_10a9;
																						IL_10a9:
																						num6--;
																						goto IL_1d6b;
																						IL_10bc:
																						if (4 >= b)
																						{
																							goto IL_10c7;
																						}
																						goto IL_10e3;
																						IL_10c7:
																						if (4 > b)
																						{
																							break;
																						}
																						num = 203;
																						goto IL_14f5;
																						IL_133f:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_134d;
																						IL_14f5:
																						array2[num6] = 0;
																						goto IL_1503;
																						IL_1503:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_1526;
																						IL_1526:
																						array3[num6] = null;
																						goto IL_1530;
																						IL_1530:
																						num6++;
																						goto IL_153e;
																						IL_153e:
																						ptr2 += 8;
																						goto IL_1d6b;
																						IL_10e3:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_10f1;
																						IL_10f1:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_10ff;
																						IL_10ff:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 88;
																						goto IL_1148;
																						IL_1148:
																						array2[num6 - 2] = 0;
																						goto IL_115c;
																						IL_115c:
																						num6--;
																						goto IL_1d6b;
																						IL_116f:
																						if (9 >= b)
																						{
																							goto IL_117d;
																						}
																						goto IL_12a5;
																						IL_117d:
																						if (9 > b)
																						{
																							goto IL_118b;
																						}
																						num = 89;
																						goto IL_124c;
																						IL_118b:
																						if (7 >= b)
																						{
																							goto IL_1196;
																						}
																						goto IL_1214;
																						IL_1196:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_11a4;
																						IL_11a4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_11e4;
																						IL_11e4:
																						array2[num6 - 2] = 0;
																						num = 111;
																						goto IL_1201;
																						IL_1201:
																						num6--;
																						goto IL_1d6b;
																						IL_1214:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_1222;
																						IL_1222:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_1230;
																						IL_1230:
																						num6--;
																						goto IL_1d6b;
																						IL_134d:
																						if (11 > b)
																						{
																							break;
																						}
																						num = 343;
																						goto IL_1d6b;
																						IL_124c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_128c;
																						IL_128c:
																						array2[num6 - 2] = 0;
																						goto IL_1682;
																					}
																					break;
																					IL_072c:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1d6b;
																			continue;
																			end_IL_073c:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0e6c:
			while (true)
			{
				IL_0e6c_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_1481_2:
						array2[num6] = 5;
						while (true)
						{
							IL_148f_2:
							num6++;
							while (true)
							{
								IL_1d6b_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_073c_2:
											if (b >= 1)
											{
												while (b <= 48)
												{
													while (true)
													{
														IL_071c_2:
														if (24 < b)
														{
															while (true)
															{
																IL_070f_2:
																if (36 < b)
																{
																	while (true)
																	{
																		IL_06ff_2:
																		if (42 >= b)
																		{
																			num = 342;
																			while (true)
																			{
																				IL_06ef_2:
																				if (42 > b)
																				{
																					while (true)
																					{
																						IL_06df_2:
																						if (39 < b)
																						{
																							while (true)
																							{
																								IL_06cf_2:
																								if (40 >= b)
																								{
																									while (40 <= b)
																									{
																										while (true)
																										{
																											IL_0690_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																											num = 408;
																											while (true)
																											{
																												if (num != 408)
																												{
																													if (num != 1389)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 17:
																													case 336:
																														goto IL_0690_2;
																													case 136:
																														goto IL_06bf_2;
																													case 120:
																														goto IL_06cf_2;
																													case 348:
																														goto IL_06df_2;
																													case 342:
																														goto IL_06ef_2;
																													case 286:
																														goto IL_06ff_2;
																													case 14:
																														goto IL_070f_2;
																													case 268:
																														goto IL_071c_2;
																													case 118:
																														goto IL_072c_2;
																													case 171:
																														goto IL_073c_2;
																													case 267:
																														goto end_IL_073c_2;
																													case 151:
																													case 231:
																														goto end_IL_074c;
																													case 63:
																														goto IL_0767_2;
																													case 96:
																														goto IL_077a_2;
																													case 67:
																													case 80:
																														goto IL_0785_2;
																													case 45:
																														goto IL_079b_2;
																													case 169:
																														goto IL_07a8_2;
																													case 189:
																														goto IL_07ec_2;
																													case 115:
																														goto IL_07fa_2;
																													case 193:
																														goto IL_080a_2;
																													case 208:
																														goto IL_081d_2;
																													case 21:
																														goto IL_0828_2;
																													case 48:
																														goto IL_0833_2;
																													case 148:
																														goto IL_0846_2;
																													case 58:
																													case 145:
																														goto IL_0862_2;
																													case 122:
																														goto IL_0876_2;
																													case 94:
																														goto IL_08b5_2;
																													case 41:
																													case 216:
																														goto IL_08c8_2;
																													case 27:
																														goto IL_08e1_2;
																													case 93:
																													case 223:
																														goto IL_08f4_2;
																													case 227:
																														goto IL_090d_2;
																													case 237:
																													case 246:
																														goto IL_091d_2;
																													case 39:
																														goto IL_0955_2;
																													case 81:
																													case 247:
																														goto IL_096e_2;
																													case 85:
																														goto IL_09ab_2;
																													case 253:
																														goto IL_09cd_2;
																													case 258:
																														goto IL_09e0_2;
																													case 158:
																														goto IL_09eb_2;
																													case 266:
																														goto IL_09fe_2;
																													case 277:
																														goto IL_0a42_2;
																													case 289:
																														goto IL_0a55_2;
																													case 298:
																														goto IL_0a68_2;
																													case 97:
																														goto IL_0a73_2;
																													case 3:
																													case 64:
																														goto IL_0a81_2;
																													case 106:
																														goto IL_0a95_2;
																													case 2:
																														goto IL_0ad4_2;
																													case 146:
																														goto IL_0ae7_2;
																													case 15:
																														goto IL_0af5_2;
																													case 225:
																													case 250:
																														goto IL_0b03_2;
																													case 20:
																														goto IL_0b43_2;
																													case 30:
																														goto IL_0b60_2;
																													case 303:
																														goto IL_0b73_2;
																													case 326:
																														goto IL_0b86_2;
																													case 292:
																														goto IL_0b91_2;
																													case 16:
																														goto IL_0ba4_2;
																													case 127:
																													case 337:
																														goto IL_0bb2_2;
																													case 143:
																														goto IL_0bef_2;
																													case 147:
																														goto IL_0c03_2;
																													case 339:
																														goto end_IL_067d_2;
																													case 113:
																													case 287:
																														goto IL_0c21_2;
																													case 200:
																														goto IL_0c35_2;
																													case 40:
																														goto IL_0c79_2;
																													case 282:
																														goto IL_0c87_2;
																													case 29:
																													case 236:
																														goto IL_0c95_2;
																													case 126:
																														goto IL_0ca9_2;
																													case 73:
																														goto IL_0cf5_2;
																													case 57:
																														goto IL_0d03_2;
																													case 74:
																														goto IL_0d16_2;
																													case 285:
																														goto IL_0d24_2;
																													case 109:
																													case 340:
																														goto IL_0d37_2;
																													case 167:
																														goto IL_0d50_2;
																													case 239:
																														goto IL_0d5e_2;
																													case 162:
																														goto IL_0d6c_2;
																													case 352:
																														goto IL_0d7f_2;
																													case 241:
																														goto IL_0d8d_2;
																													case 209:
																														goto IL_0d98_2;
																													case 42:
																													case 256:
																														goto IL_0da6_2;
																													case 82:
																														goto IL_0dba_2;
																													case 75:
																														goto IL_0df2_2;
																													case 86:
																														goto IL_0e05_2;
																													case 10:
																														goto IL_0e10_2;
																													case 9:
																														goto IL_0e23_2;
																													case 6:
																														goto IL_0e2e_2;
																													case 226:
																														goto IL_0e4f_2;
																													case 172:
																													case 317:
																														goto end_IL_075c;
																													case 104:
																														goto IL_0f19_2;
																													case 314:
																														goto IL_0f27_2;
																													case 130:
																													case 315:
																														goto IL_0f32_2;
																													case 262:
																														goto IL_0f72_2;
																													case 252:
																														goto IL_0f86_2;
																													case 153:
																														goto IL_0f99_2;
																													case 265:
																														goto IL_0fa7_2;
																													case 90:
																														goto IL_0fb5_2;
																													case 117:
																														goto IL_0fc3_2;
																													case 274:
																														goto IL_0fd1_2;
																													case 273:
																													case 302:
																														goto IL_0fdf_2;
																													case 138:
																														goto IL_101f_2;
																													case 257:
																														goto IL_1033_2;
																													case 214:
																														goto IL_1046_2;
																													case 36:
																													case 279:
																														goto IL_1054_2;
																													case 161:
																													case 244:
																														goto IL_1072_2;
																													case 198:
																														goto IL_109b_2;
																													case 338:
																														goto IL_10a9_2;
																													case 62:
																														goto IL_10bc_2;
																													case 142:
																														goto IL_10c7_2;
																													case 5:
																														goto IL_10e3_2;
																													case 350:
																														goto IL_10f1_2;
																													case 76:
																													case 102:
																														goto IL_10ff_2;
																													case 88:
																														goto IL_1148_2;
																													case 331:
																														goto IL_115c_2;
																													case 308:
																														goto IL_116f_2;
																													case 69:
																														goto IL_117d_2;
																													case 152:
																														goto IL_118b_2;
																													case 288:
																														goto IL_1196_2;
																													case 0:
																													case 4:
																														goto IL_11a4_2;
																													case 320:
																														goto IL_11e4_2;
																													case 111:
																														goto IL_1201_2;
																													case 243:
																														goto IL_1214_2;
																													case 149:
																														goto IL_1222_2;
																													case 92:
																													case 349:
																														goto IL_1230_2;
																													case 89:
																													case 276:
																														goto IL_124c_2;
																													case 296:
																														goto IL_128c_2;
																													case 107:
																														goto IL_12a5_2;
																													case 160:
																														goto IL_12b3_2;
																													case 195:
																													case 344:
																														goto IL_12c1_2;
																													case 177:
																														goto IL_132c_2;
																													case 163:
																														goto IL_133f_2;
																													case 233:
																														goto IL_134d_2;
																													case 135:
																													case 356:
																														goto IL_1369_2;
																													case 232:
																														goto IL_137d_2;
																													case 242:
																														goto IL_13bc_2;
																													case 51:
																													case 360:
																														goto IL_13cf_2;
																													case 319:
																														goto IL_1410_2;
																													case 364:
																														goto IL_1429_2;
																													case 196:
																													case 264:
																														goto IL_1437_2;
																													case 101:
																														goto IL_1460_2;
																													case 362:
																														goto IL_146e_2;
																													case 366:
																														goto IL_1481_2;
																													case 55:
																														goto IL_148f_2;
																													case 238:
																													case 367:
																														goto IL_14a2_2;
																													case 205:
																														goto IL_14cb_2;
																													case 53:
																														goto IL_14e2_2;
																													case 203:
																													case 369:
																														goto IL_14f5_2;
																													case 293:
																														goto IL_1503_2;
																													case 334:
																														goto IL_1526_2;
																													case 103:
																														goto IL_1530_2;
																													case 116:
																														goto IL_153e_2;
																													case 370:
																														goto IL_1551_2;
																													case 8:
																													case 77:
																														goto IL_155f_2;
																													case 179:
																														goto IL_159f_2;
																													case 175:
																														goto IL_15b3_2;
																													case 371:
																														goto IL_15c6_2;
																													case 211:
																														goto IL_15d4_2;
																													case 144:
																													case 304:
																														goto IL_15df_2;
																													case 330:
																														goto IL_15fb_2;
																													case 141:
																														goto IL_1609_2;
																													case 91:
																													case 132:
																														goto IL_1617_2;
																													case 341:
																														goto IL_1640_2;
																													case 217:
																														goto IL_164e_2;
																													case 311:
																														goto IL_1661_2;
																													case 355:
																														goto IL_166f_2;
																													case 372:
																														goto IL_1682_2;
																													case 373:
																														goto IL_1695_2;
																													case 374:
																														goto IL_16a8_2;
																													case 379:
																														goto IL_16bb_2;
																													case 381:
																														goto IL_16ce_2;
																													case 384:
																														goto IL_16e1_2;
																													case 385:
																														goto IL_16f4_2;
																													case 194:
																														goto IL_16ff_2;
																													case 35:
																													case 188:
																														goto IL_170d_2;
																													case 134:
																														goto IL_172f_2;
																													case 254:
																														goto IL_173d_2;
																													case 178:
																														goto IL_174b_2;
																													case 43:
																														goto IL_175e_2;
																													case 165:
																														goto IL_176c_2;
																													case 1:
																													case 157:
																														goto IL_177a_2;
																													case 388:
																														goto IL_1792_2;
																													case 219:
																														goto IL_17a0_2;
																													case 191:
																														goto IL_17ae_2;
																													case 47:
																													case 391:
																														goto IL_17c1_2;
																													case 173:
																														goto IL_17e4_2;
																													case 301:
																														goto IL_17f2_2;
																													case 368:
																														goto IL_1800_2;
																													case 393:
																														goto IL_1813_2;
																													case 7:
																													case 129:
																														goto IL_1821_2;
																													case 66:
																														goto IL_184b_2;
																													case 249:
																														goto IL_1859_2;
																													case 395:
																														goto IL_186c_2;
																													case 400:
																														goto IL_187f_2;
																													case 28:
																														goto IL_188d_2;
																													case 13:
																														goto IL_189b_2;
																													case 313:
																														goto IL_18a6_2;
																													case 297:
																													case 386:
																														goto IL_18b4_2;
																													case 11:
																														goto IL_18d2_2;
																													case 70:
																														goto IL_18e9_2;
																													case 65:
																														goto IL_18fc_2;
																													case 121:
																														goto IL_190a_2;
																													case 119:
																													case 174:
																														goto IL_1918_2;
																													case 19:
																														goto IL_194a_2;
																													case 229:
																													case 380:
																														goto IL_1963_2;
																													case 284:
																														goto IL_197b_2;
																													case 100:
																														goto IL_1999_2;
																													case 114:
																														goto IL_19bd_2;
																													case 290:
																														goto IL_19de_2;
																													case 335:
																														goto IL_19fa_2;
																													case 78:
																														goto IL_1a05_2;
																													case 322:
																														goto IL_1a13_2;
																													case 131:
																													case 186:
																														goto IL_1a21_2;
																													case 99:
																														goto IL_1a5f_2;
																													case 316:
																														goto IL_1a7b_2;
																													case 52:
																													case 270:
																														goto IL_1a89_2;
																													case 212:
																														goto IL_1a97_2;
																													case 399:
																														goto IL_1aaf_2;
																													case 327:
																														goto IL_1abd_2;
																													case 307:
																													case 401:
																														goto IL_1ad0_2;
																													case 309:
																														goto IL_1b22_2;
																													case 234:
																														goto IL_1b43_2;
																													case 95:
																														goto IL_1b51_2;
																													case 187:
																														goto IL_1b64_2;
																													case 34:
																														goto IL_1b72_2;
																													case 128:
																													case 235:
																														goto IL_1b80_2;
																													case 324:
																														goto IL_1bbd_2;
																													case 199:
																														goto IL_1bd1_2;
																													case 375:
																														goto IL_1be4_2;
																													case 125:
																													case 260:
																														goto IL_1bef_2;
																													case 110:
																														goto IL_1c0d_2;
																													case 259:
																														goto IL_1c1b_2;
																													case 278:
																														goto IL_1c29_2;
																													case 281:
																														goto IL_1c3c_2;
																													case 376:
																														goto IL_1c4a_2;
																													case 87:
																													case 182:
																														goto IL_1c58_2;
																													case 105:
																														goto IL_1c6c_2;
																													case 207:
																														goto IL_1cbe_2;
																													case 190:
																														goto IL_1ccc_2;
																													case 156:
																														goto IL_1cdf_2;
																													case 37:
																														goto IL_1cea_2;
																													case 312:
																													case 325:
																														goto IL_1cf5_2;
																													case 83:
																														goto IL_1d09_2;
																													case 396:
																														goto IL_1d48_2;
																													case 22:
																													case 23:
																													case 24:
																													case 25:
																													case 26:
																													case 31:
																													case 32:
																													case 44:
																													case 46:
																													case 49:
																													case 50:
																													case 54:
																													case 60:
																													case 68:
																													case 71:
																													case 112:
																													case 124:
																													case 133:
																													case 140:
																													case 150:
																													case 170:
																													case 181:
																													case 197:
																													case 210:
																													case 213:
																													case 218:
																													case 220:
																													case 222:
																													case 224:
																													case 245:
																													case 248:
																													case 255:
																													case 261:
																													case 263:
																													case 272:
																													case 280:
																													case 283:
																													case 291:
																													case 300:
																													case 306:
																													case 318:
																													case 321:
																													case 329:
																													case 332:
																													case 357:
																													case 358:
																													case 365:
																													case 382:
																													case 387:
																													case 389:
																													case 394:
																														goto end_IL_06bf_2;
																													case 12:
																													case 18:
																													case 33:
																													case 38:
																													case 56:
																													case 59:
																													case 61:
																													case 72:
																													case 84:
																													case 98:
																													case 108:
																													case 137:
																													case 139:
																													case 154:
																													case 155:
																													case 159:
																													case 164:
																													case 166:
																													case 168:
																													case 176:
																													case 183:
																													case 201:
																													case 202:
																													case 204:
																													case 206:
																													case 215:
																													case 221:
																													case 228:
																													case 240:
																													case 251:
																													case 269:
																													case 294:
																													case 295:
																													case 299:
																													case 310:
																													case 323:
																													case 328:
																													case 333:
																													case 343:
																													case 345:
																													case 346:
																													case 347:
																													case 351:
																													case 354:
																													case 359:
																													case 361:
																													case 377:
																													case 378:
																													case 383:
																													case 390:
																													case 392:
																														goto IL_1d6b_2;
																													case 353:
																														ptr2 = ptr;
																														goto IL_1d6b_2;
																													case 185:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RecordFixupVARFLAGFIMMEDIATEBIND.CausalityTracerFileOptions);
																														goto case 353;
																													case 184:
																														array7 = new object[16];
																														goto case 185;
																													case 79:
																														array6 = new long[4];
																														goto case 184;
																													case 180:
																														array5 = new int[7];
																														goto case 79;
																													case 271:
																														array4 = new int[4];
																														goto case 180;
																													case 305:
																														array3 = new object[4];
																														num = 271;
																														goto case 271;
																													case 192:
																														array2 = new byte[4];
																														goto case 305;
																													case 275:
																														num4 = num2 * 8;
																														goto case 192;
																													case 230:
																														num3 = num2 * 4;
																														goto case 275;
																													case 397:
																														num2 = 1;
																														goto case 230;
																													case 398:
																														goto end_IL_0e7a;
																													case 123:
																													case 363:
																														return;
																													}
																													continue;
																												}
																												array2[num6] = 0;
																												goto IL_1b43_2;
																												IL_1b43_2:
																												num6++;
																												goto IL_1b51_2;
																												IL_1b51_2:
																												ptr2 += 8;
																												goto IL_1d6b_2;
																												continue;
																												end_IL_067d_2:
																												break;
																											}
																											break;
																										}
																										goto IL_0c16_2;
																										continue;
																										end_IL_06bf_2:
																										break;
																										IL_06bf_2:;
																									}
																									break;
																								}
																								goto IL_1b64_2;
																								IL_1bd1_2:
																								num6--;
																								goto IL_1d6b_2;
																								IL_1b64_2:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_1b72_2;
																								IL_1b72_2:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_1b80_2;
																								IL_1b80_2:
																								array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_1bbd_2;
																								IL_1bbd_2:
																								array2[num6 - 2] = 4;
																								goto IL_1bd1_2;
																							}
																							break;
																						}
																						goto IL_1be4_2;
																						IL_1d48_2:
																						ptr2 += 8;
																						goto IL_1d6b_2;
																						IL_1be4_2:
																						if (39 <= b)
																						{
																							goto IL_1bef_2;
																						}
																						goto IL_1c3c_2;
																						IL_1bef_2:
																						array3[num6] = ((delegate*<ColorOption[]>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																						goto IL_1c0d_2;
																						IL_1c0d_2:
																						array2[num6] = 5;
																						goto IL_1c1b_2;
																						IL_1c1b_2:
																						num6++;
																						goto IL_1c29_2;
																						IL_1c29_2:
																						ptr2 += 8;
																						goto IL_1d6b_2;
																						IL_1c3c_2:
																						if (37 >= b)
																						{
																							goto IL_1c4a_2;
																						}
																						goto IL_1cdf_2;
																						IL_1c4a_2:
																						if (37 > b)
																						{
																							break;
																						}
																						goto IL_1c58_2;
																						IL_1c58_2:
																						array2[num6 - 2] = 0;
																						goto IL_1c6c_2;
																						IL_1c6c_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																						goto IL_1cbe_2;
																						IL_1cbe_2:
																						num6--;
																						goto IL_1ccc_2;
																						IL_1ccc_2:
																						ptr2 += 8;
																						goto IL_1d6b_2;
																						IL_1cdf_2:
																						if (38 < b)
																						{
																							break;
																						}
																						goto IL_1cea_2;
																						IL_1cea_2:
																						if (38 > b)
																						{
																							break;
																						}
																						goto IL_1cf5_2;
																						IL_1cf5_2:
																						array2[num6 - 1] = 3;
																						goto IL_1d09_2;
																						IL_1d09_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1d48_2;
																					}
																					break;
																				}
																				goto IL_08c8_2;
																				IL_08e1_2:
																				num6--;
																				goto IL_1d6b_2;
																				IL_08c8_2:
																				global::_003CModule_003E.colorOption_0 = (ColorOption)array3[num6 - 1];
																				goto IL_08e1_2;
																			}
																			break;
																		}
																		goto IL_0767_2;
																		IL_1661_2:
																		if (48 < b)
																		{
																			break;
																		}
																		goto IL_166f_2;
																		IL_166f_2:
																		if (48 > b)
																		{
																		}
																		break;
																		IL_0767_2:
																		if (45 >= b)
																		{
																			goto IL_090d_2;
																		}
																		goto IL_15c6_2;
																		IL_090d_2:
																		if (45 <= b)
																		{
																			goto IL_096e_2;
																		}
																		goto IL_0a68_2;
																		IL_0a68_2:
																		if (43 >= b)
																		{
																			goto IL_0a73_2;
																		}
																		goto IL_0ae7_2;
																		IL_0a73_2:
																		if (43 > b)
																		{
																			break;
																		}
																		goto IL_0a81_2;
																		IL_0a81_2:
																		array2[num6 - 1] = 3;
																		goto IL_0a95_2;
																		IL_0a95_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0ad4_2;
																		IL_0ad4_2:
																		ptr2 += 8;
																		goto IL_1d6b_2;
																		IL_0ae7_2:
																		if (44 < b)
																		{
																			break;
																		}
																		goto IL_0af5_2;
																		IL_0af5_2:
																		if (44 > b)
																		{
																			break;
																		}
																		goto IL_0b03_2;
																		IL_0b03_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b43_2;
																		IL_0b43_2:
																		array2[num6 - 2] = 3;
																		num = 30;
																		goto IL_0b60_2;
																		IL_0b60_2:
																		num6--;
																		goto IL_1d6b_2;
																		IL_096e_2:
																		array3[num6 - 1] = ((delegate*<ColorOption, Color>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																		goto IL_09ab_2;
																		IL_09ab_2:
																		array2[num6 - 1] = 4;
																		num = 373;
																		goto IL_1695_2;
																		IL_1695_2:
																		ptr2 += 8;
																		goto IL_1d6b_2;
																		IL_15c6_2:
																		if (47 >= b)
																		{
																			goto IL_15d4_2;
																		}
																		goto IL_1661_2;
																		IL_15d4_2:
																		if (47 <= b)
																		{
																			goto IL_15df_2;
																		}
																		goto IL_15fb_2;
																		IL_15df_2:
																		num7 = ptr2;
																		num8 = -200;
																		num5 = 1;
																		ptr2 = num7 + num8;
																		goto IL_1d6b_2;
																		IL_15fb_2:
																		if (46 < b)
																		{
																			break;
																		}
																		goto IL_1609_2;
																		IL_1609_2:
																		if (46 > b)
																		{
																			break;
																		}
																		goto IL_1617_2;
																		IL_1617_2:
																		((delegate*<Color, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																		goto IL_1640_2;
																		IL_1640_2:
																		num6--;
																		goto IL_164e_2;
																		IL_164e_2:
																		ptr2 += 8;
																		goto IL_1d6b_2;
																	}
																	break;
																}
																goto IL_077a_2;
																IL_0bef_2:
																array2[num6 - 1] = 4;
																goto IL_0c03_2;
																IL_077a_2:
																if (36 <= b)
																{
																	goto IL_0785_2;
																}
																goto IL_079b_2;
																IL_0785_2:
																array2[num6 - 1] = 3;
																goto IL_07a8_2;
																IL_07a8_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_16bb_2;
																IL_16bb_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_079b_2:
																if (30 >= b)
																{
																	goto IL_07ec_2;
																}
																goto IL_080a_2;
																IL_07ec_2:
																if (30 > b)
																{
																	goto IL_07fa_2;
																}
																goto IL_091d_2;
																IL_07fa_2:
																if (27 >= b)
																{
																	goto IL_081d_2;
																}
																goto IL_09e0_2;
																IL_09e0_2:
																if (28 < b)
																{
																	goto IL_09eb_2;
																}
																goto IL_0a42_2;
																IL_09eb_2:
																if (29 < b)
																{
																	break;
																}
																goto IL_0b73_2;
																IL_0b73_2:
																if (29 > b)
																{
																	break;
																}
																goto IL_17c1_2;
																IL_17c1_2:
																array3[num6] = ((delegate*<ColorOption>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])();
																goto IL_17e4_2;
																IL_17e4_2:
																array2[num6] = 4;
																goto IL_17f2_2;
																IL_17f2_2:
																num6++;
																goto IL_1800_2;
																IL_1800_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0a42_2:
																if (28 > b)
																{
																	break;
																}
																goto IL_1369_2;
																IL_1369_2:
																array2[num6 - 1] = 3;
																goto IL_137d_2;
																IL_137d_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_13bc_2;
																IL_13bc_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_081d_2:
																if (27 > b)
																{
																	goto IL_0828_2;
																}
																goto IL_0862_2;
																IL_0828_2:
																if (25 >= b)
																{
																	goto IL_0833_2;
																}
																goto IL_0846_2;
																IL_0833_2:
																if (25 > b)
																{
																	break;
																}
																goto IL_08f4_2;
																IL_08f4_2:
																array2[num6 - 1] = 3;
																goto IL_09fe_2;
																IL_09fe_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_16a8_2;
																IL_16a8_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0846_2:
																if (26 < b)
																{
																	break;
																}
																num = 370;
																goto IL_1551_2;
																IL_0c03_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_1551_2:
																if (26 > b)
																{
																	break;
																}
																goto IL_155f_2;
																IL_155f_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_159f_2;
																IL_159f_2:
																array2[num6 - 2] = 3;
																goto IL_15b3_2;
																IL_15b3_2:
																num6--;
																goto IL_1d6b_2;
																IL_0862_2:
																array2[num6 - 1] = 0;
																goto IL_0876_2;
																IL_0876_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_08b5_2;
																IL_08b5_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_091d_2:
																array3[num6 - 1] = ((delegate*<ColorOption, string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																goto IL_0955_2;
																IL_0955_2:
																array2[num6 - 1] = 5;
																goto IL_0a55_2;
																IL_0a55_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_080a_2:
																if (33 < b)
																{
																	goto IL_0b86_2;
																}
																goto IL_0c16_2;
																IL_0c16_2:
																if (33 <= b)
																{
																	goto IL_0c21_2;
																}
																goto IL_0c79_2;
																IL_0c21_2:
																array2[num6 - 1] = 3;
																goto IL_0c35_2;
																IL_0c35_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_16ce_2;
																IL_16ce_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0c79_2:
																if (31 >= b)
																{
																	goto IL_0c87_2;
																}
																goto IL_0d16_2;
																IL_0c87_2:
																if (31 > b)
																{
																	break;
																}
																goto IL_0c95_2;
																IL_0c95_2:
																array2[num6 - 2] = 5;
																goto IL_0ca9_2;
																IL_0ca9_2:
																array3[num6 - 2] = ((delegate*<string, string, string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																goto IL_0cf5_2;
																IL_0cf5_2:
																num6--;
																goto IL_0d03_2;
																IL_0d03_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0d16_2:
																if (32 < b)
																{
																	break;
																}
																goto IL_0d24_2;
																IL_0d24_2:
																if (32 > b)
																{
																	break;
																}
																goto IL_14a2_2;
																IL_14a2_2:
																((delegate*<string, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_14cb_2;
																IL_14cb_2:
																num6--;
																num = 53;
																goto IL_14e2_2;
																IL_14e2_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0b86_2:
																if (34 < b)
																{
																	goto IL_0b91_2;
																}
																goto IL_0ba4_2;
																IL_0b91_2:
																if (35 < b)
																{
																	break;
																}
																goto IL_1429_2;
																IL_1429_2:
																if (35 > b)
																{
																	break;
																}
																goto IL_1437_2;
																IL_1437_2:
																((delegate*<Color, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																goto IL_1460_2;
																IL_1460_2:
																num6--;
																goto IL_146e_2;
																IL_146e_2:
																ptr2 += 8;
																goto IL_1d6b_2;
																IL_0ba4_2:
																if (34 > b)
																{
																	break;
																}
																goto IL_0bb2_2;
																IL_0bb2_2:
																array3[num6 - 1] = ((delegate*<ColorOption, Color>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																goto IL_0bef_2;
															}
															break;
														}
														goto IL_09cd_2;
														IL_12c1_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														num = 177;
														goto IL_132c_2;
														IL_09cd_2:
														if (24 <= b)
														{
															goto IL_0d37_2;
														}
														goto IL_0d7f_2;
														IL_0d37_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_0d50_2;
														IL_0d50_2:
														array2[num6] = 3;
														goto IL_0d5e_2;
														IL_0d5e_2:
														num6++;
														goto IL_0d6c_2;
														IL_0d6c_2:
														ptr2 += 16;
														goto IL_1d6b_2;
														IL_0d7f_2:
														if (12 < b)
														{
															goto IL_0d8d_2;
														}
														goto IL_0e4f_2;
														IL_0d8d_2:
														if (18 >= b)
														{
															goto IL_0d98_2;
														}
														goto IL_0e05_2;
														IL_0d98_2:
														if (18 <= b)
														{
															goto IL_0da6_2;
														}
														goto IL_187f_2;
														IL_0da6_2:
														array2[num6 - 1] = 5;
														goto IL_0dba_2;
														IL_0dba_2:
														array3[num6 - 1] = ((delegate*<string[], string>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_0df2_2;
														IL_0df2_2:
														ptr2 += 8;
														goto IL_1d6b_2;
														IL_187f_2:
														if (15 >= b)
														{
															goto IL_188d_2;
														}
														goto IL_19fa_2;
														IL_188d_2:
														if (15 > b)
														{
															goto IL_189b_2;
														}
														goto IL_1963_2;
														IL_189b_2:
														if (13 >= b)
														{
															goto IL_18a6_2;
														}
														goto IL_18fc_2;
														IL_18a6_2:
														if (13 > b)
														{
															break;
														}
														goto IL_18b4_2;
														IL_18b4_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_18d2_2;
														IL_18d2_2:
														ptr2 += 8;
														num = 70;
														goto IL_18e9_2;
														IL_18e9_2:
														num6--;
														goto IL_1d6b_2;
														IL_18fc_2:
														if (14 < b)
														{
															break;
														}
														goto IL_190a_2;
														IL_190a_2:
														if (14 > b)
														{
															break;
														}
														goto IL_1918_2;
														IL_1918_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														num = 19;
														goto IL_194a_2;
														IL_194a_2:
														array2[num6 - 1] = 5;
														goto IL_1d6b_2;
														IL_1963_2:
														array2[num6] = array2[num6 - 1];
														goto IL_197b_2;
														IL_197b_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_1999_2;
														IL_1999_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_19bd_2;
														IL_19bd_2:
														array3[num6] = array3[num6 - 1];
														num = 290;
														goto IL_19de_2;
														IL_19de_2:
														num6++;
														num = 12;
														goto IL_1d6b_2;
														IL_19fa_2:
														if (16 < b)
														{
															goto IL_1a05_2;
														}
														goto IL_1a7b_2;
														IL_1a05_2:
														if (17 < b)
														{
															break;
														}
														goto IL_1a13_2;
														IL_1a13_2:
														if (17 > b)
														{
															break;
														}
														goto IL_1a21_2;
														IL_1a21_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_1a5f_2;
														IL_1a5f_2:
														num6 -= 3;
														num = 240;
														goto IL_1d6b_2;
														IL_1a7b_2:
														if (16 > b)
														{
															break;
														}
														goto IL_1a89_2;
														IL_1a89_2:
														array2[num6] = 5;
														goto IL_1a97_2;
														IL_1a97_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_1aaf_2;
														IL_1aaf_2:
														num6++;
														goto IL_1abd_2;
														IL_1abd_2:
														ptr2 += 8;
														goto IL_1d6b_2;
														IL_0e05_2:
														if (21 >= b)
														{
															goto IL_0e10_2;
														}
														goto IL_0e23_2;
														IL_0e10_2:
														if (21 <= b)
														{
															goto IL_13cf_2;
														}
														goto IL_16f4_2;
														IL_13cf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1410_2;
														IL_1410_2:
														array2[num6 - 2] = 0;
														goto IL_186c_2;
														IL_186c_2:
														num6--;
														goto IL_1d6b_2;
														IL_16f4_2:
														if (19 >= b)
														{
															goto IL_16ff_2;
														}
														goto IL_175e_2;
														IL_16ff_2:
														if (19 > b)
														{
															break;
														}
														goto IL_170d_2;
														IL_170d_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														num = 134;
														goto IL_172f_2;
														IL_172f_2:
														array2[num6] = 1;
														goto IL_173d_2;
														IL_173d_2:
														num6++;
														goto IL_174b_2;
														IL_174b_2:
														ptr2 += 16;
														goto IL_1d6b_2;
														IL_175e_2:
														if (20 < b)
														{
															break;
														}
														goto IL_176c_2;
														IL_176c_2:
														if (20 > b)
														{
															break;
														}
														goto IL_177a_2;
														IL_177a_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1d6b_2;
														IL_0e23_2:
														if (22 < b)
														{
															goto IL_0e2e_2;
														}
														num = 384;
														goto IL_16e1_2;
														IL_0e2e_2:
														if (23 < b)
														{
															break;
														}
														goto IL_1813_2;
														IL_1813_2:
														if (23 > b)
														{
															break;
														}
														goto IL_1821_2;
														IL_1821_2:
														((delegate*<bool, void>)ReadOnlyDictionaryHelpersSignalAndWait[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
														goto IL_184b_2;
														IL_184b_2:
														num6--;
														goto IL_1859_2;
														IL_1859_2:
														ptr2 += 8;
														goto IL_1d6b_2;
														IL_132c_2:
														num6 -= 2;
														goto IL_1d6b_2;
														IL_16e1_2:
														if (22 > b)
														{
															break;
														}
														goto IL_1ad0_2;
														IL_1ad0_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1b22_2;
														IL_1b22_2:
														num6--;
														goto IL_1d6b_2;
														IL_0e4f_2:
														if (12 <= b)
														{
															goto end_IL_075c;
														}
														goto IL_0f19_2;
														IL_0f19_2:
														if (6 >= b)
														{
															goto IL_0f27_2;
														}
														goto IL_116f_2;
														IL_0f27_2:
														if (6 <= b)
														{
															goto IL_0f32_2;
														}
														goto IL_0f99_2;
														IL_0f32_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0f72_2;
														IL_0f72_2:
														array2[num6 - 2] = 0;
														goto IL_0f86_2;
														IL_0f86_2:
														num6--;
														goto IL_1d6b_2;
														IL_0f99_2:
														if (3 >= b)
														{
															goto IL_0fa7_2;
														}
														goto IL_10bc_2;
														IL_0fa7_2:
														if (3 > b)
														{
															goto IL_0fb5_2;
														}
														goto IL_1072_2;
														IL_0fb5_2:
														if (1 < b)
														{
															goto IL_0fc3_2;
														}
														goto IL_1046_2;
														IL_0fc3_2:
														if (2 < b)
														{
															break;
														}
														goto IL_0fd1_2;
														IL_0fd1_2:
														if (2 > b)
														{
															break;
														}
														goto IL_0fdf_2;
														IL_0fdf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_101f_2;
														IL_101f_2:
														array2[num6 - 2] = 0;
														goto IL_1033_2;
														IL_1033_2:
														num6--;
														goto IL_1d6b_2;
														IL_1046_2:
														if (1 > b)
														{
															break;
														}
														goto IL_1054_2;
														IL_1054_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_1792_2;
														IL_1792_2:
														array2[num6] = 0;
														goto IL_17a0_2;
														IL_17a0_2:
														num6++;
														goto IL_17ae_2;
														IL_17ae_2:
														ptr2 += 8;
														goto IL_1d6b_2;
														IL_1072_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_109b_2;
														IL_109b_2:
														ptr2 += 8;
														goto IL_10a9_2;
														IL_10a9_2:
														num6--;
														goto IL_1d6b_2;
														IL_10bc_2:
														if (4 >= b)
														{
															goto IL_10c7_2;
														}
														goto IL_10e3_2;
														IL_10c7_2:
														if (4 > b)
														{
															break;
														}
														num = 203;
														goto IL_14f5_2;
														IL_133f_2:
														if (11 < b)
														{
															break;
														}
														goto IL_134d_2;
														IL_14f5_2:
														array2[num6] = 0;
														goto IL_1503_2;
														IL_1503_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_1526_2;
														IL_1526_2:
														array3[num6] = null;
														goto IL_1530_2;
														IL_1530_2:
														num6++;
														goto IL_153e_2;
														IL_153e_2:
														ptr2 += 8;
														goto IL_1d6b_2;
														IL_10e3_2:
														if (5 < b)
														{
															break;
														}
														goto IL_10f1_2;
														IL_10f1_2:
														if (5 > b)
														{
															break;
														}
														goto IL_10ff_2;
														IL_10ff_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 88;
														goto IL_1148_2;
														IL_1148_2:
														array2[num6 - 2] = 0;
														goto IL_115c_2;
														IL_115c_2:
														num6--;
														goto IL_1d6b_2;
														IL_116f_2:
														if (9 >= b)
														{
															goto IL_117d_2;
														}
														goto IL_12a5_2;
														IL_117d_2:
														if (9 > b)
														{
															goto IL_118b_2;
														}
														num = 89;
														goto IL_124c_2;
														IL_118b_2:
														if (7 >= b)
														{
															goto IL_1196_2;
														}
														goto IL_1214_2;
														IL_1196_2:
														if (7 > b)
														{
															break;
														}
														goto IL_11a4_2;
														IL_11a4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_11e4_2;
														IL_11e4_2:
														array2[num6 - 2] = 0;
														num = 111;
														goto IL_1201_2;
														IL_1201_2:
														num6--;
														goto IL_1d6b_2;
														IL_1214_2:
														if (8 < b)
														{
															break;
														}
														goto IL_1222_2;
														IL_1222_2:
														if (8 > b)
														{
															break;
														}
														goto IL_1230_2;
														IL_1230_2:
														num6--;
														goto IL_1d6b_2;
														IL_134d_2:
														if (11 > b)
														{
															break;
														}
														num = 343;
														goto IL_1d6b_2;
														IL_124c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_128c_2;
														IL_128c_2:
														array2[num6 - 2] = 0;
														goto IL_1682_2;
														IL_1682_2:
														num6--;
														goto IL_1d6b_2;
														IL_12a5_2:
														if (10 >= b)
														{
															goto IL_12b3_2;
														}
														goto IL_133f_2;
														IL_12b3_2:
														if (10 > b)
														{
															break;
														}
														goto IL_12c1_2;
													}
													break;
													IL_072c_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_1d6b_2;
											continue;
											end_IL_073c_2:
											break;
										}
										continue;
										end_IL_074c:
										break;
									}
									continue;
									end_IL_075c:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_0e6c_2;
					}
					continue;
					end_IL_0e7a:
					break;
				}
				break;
			}
		}
	}

	public unsafe static void smethod_0()
	{
		//The blocks IL_000e, IL_001e, IL_064f, IL_0662, IL_06bf, IL_06de, IL_06ee, IL_06fe, IL_070e, IL_071e, IL_072e, IL_073e, IL_074b, IL_075b, IL_076b, IL_077b, IL_078b, IL_07a4, IL_07b8, IL_07cc, IL_080b, IL_081e, IL_0832, IL_0873, IL_08b0, IL_08c4, IL_08d7, IL_08ea, IL_08f5, IL_092d, IL_0941, IL_0954, IL_0962, IL_0970, IL_098d, IL_09dc, IL_09e6, IL_0a13, IL_0a27, IL_0a35, IL_0a48, IL_0a56, IL_0a64, IL_0a6d, IL_0ab6, IL_0ad3, IL_0ae6, IL_0af4, IL_0b02, IL_0b0d, IL_0b1b, IL_0b39, IL_0b47, IL_0b55, IL_0b95, IL_0ba9, IL_0bbc, IL_0bc7, IL_0bd5, IL_0be3, IL_0c06, IL_0c15, IL_0c23, IL_0c2c, IL_0c3a, IL_0c7a, IL_0c8e, IL_0ca1, IL_0caf, IL_0cbd, IL_0ccb, IL_0d2d, IL_0d40, IL_0d4e, IL_0d61, IL_0d6c, IL_0db1, IL_0dbc, IL_0dca, IL_0e0a, IL_0e27, IL_0e3a, IL_0e48, IL_0e56, IL_0e69, IL_0e77, IL_0e8a, IL_0e98, IL_0ea6, IL_0ec2, IL_0eeb, IL_0f02, IL_0f15, IL_0f23, IL_0f31, IL_0f3c, IL_0f4a, IL_0f58, IL_0f7b, IL_0f89, IL_0f97, IL_0faa, IL_0fb8, IL_100a, IL_101d, IL_1028, IL_1069, IL_107d, IL_1090, IL_109b, IL_10a9, IL_10cb, IL_10e2, IL_10f0, IL_1103, IL_1111, IL_111f, IL_1140, IL_114e, IL_115c, IL_116a, IL_1182, IL_11a0, IL_11c4, IL_11dc, IL_11ef, IL_11fa, IL_1208, IL_1226, IL_1234, IL_1247, IL_1255, IL_125e, IL_126c, IL_1295, IL_12ae, IL_12b9, IL_12c7, IL_12d5, IL_12ed, IL_12fb, IL_130e, IL_131c, IL_1325, IL_1333, IL_1371, IL_1384, IL_1398, IL_13d9, IL_13ec, IL_1400, IL_1413, IL_1421, IL_1434, IL_1442, IL_1450, IL_1469, IL_1477, IL_1485, IL_1498, IL_14a6, IL_14b4, IL_14c2, IL_14d6, IL_1515, IL_1528, IL_1536, IL_153f, IL_157f, IL_1593, IL_15a6, IL_15b4, IL_15c2, IL_15cd, IL_15db, IL_1604, IL_1612, IL_1625, IL_1633, IL_1641, IL_1655, IL_1694, IL_16a7, IL_16d1, IL_16df, IL_16f2, IL_16fd, IL_170b, IL_171f, IL_175e, IL_1771, IL_177f, IL_178d, IL_17cd, IL_17e1, IL_17f4, IL_1802, IL_1810, IL_181b, IL_1844, IL_1852, IL_1865, IL_1870, IL_187e, IL_1887, IL_189b, IL_18da, IL_18ed, IL_18fb, IL_1909, IL_191d, IL_1969, IL_1977, IL_198a, IL_1995, IL_19a3, IL_19bf, IL_19cd, IL_19e0, IL_19e9, IL_19f4, IL_19fd, IL_1a16, IL_1a29, IL_1a37, IL_1a42, IL_1a60, IL_1a6e, IL_1a7c, IL_1a8f, IL_1a9a, IL_1aa8, IL_1ae5, IL_1af9, IL_1b0c, IL_1b1a, IL_1b28, IL_1b51, IL_1b5f, IL_1b72, IL_1b7d, IL_1b8b, IL_1baf, IL_1bbd, IL_1bcb, IL_1bde, IL_1be9, IL_1bf4, IL_1c31, IL_1c45, IL_1c55, IL_1c68, IL_1c7b, IL_1c85, IL_1c90, IL_1ca0, IL_1cb0, IL_1cc0, IL_1cd0, IL_1ce0, IL_1cf0, IL_1d00, IL_1d10 are reachable both inside and outside the pinned region starting at IL_1d25. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 196;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			object[] array8;
			int num9;
			byte* num10;
			int __rxRef42 = default(int);
			ref int reference = ref __rxRef42;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1d10:
					num2 = 1;
					while (true)
					{
						IL_1d00:
						num3 = num2 * 4;
						while (true)
						{
							IL_1cf0:
							num4 = num2 * 8;
							while (true)
							{
								IL_1ce0:
								array2 = new byte[4];
								while (true)
								{
									IL_1cd0:
									array3 = new object[4];
									while (true)
									{
										IL_1cc0:
										array4 = new int[4];
										while (true)
										{
											IL_1cb0:
											array5 = new int[7];
											while (true)
											{
												IL_1ca0:
												array6 = new long[4];
												while (true)
												{
													IL_1c90:
													array7 = new object[16];
													while (true)
													{
														IL_1c85:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getExcludeGetChannelData.AddDaysSetParent);
														while (true)
														{
															IL_1c7b:
															ptr2 = ptr;
															while (true)
															{
																IL_1c68:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_07a4:
																	byte b = *ptr2;
																	num = 207;
																	while (true)
																	{
																		IL_078b:
																		ptr2++;
																		num = 388;
																		while (true)
																		{
																			IL_077b:
																			if (b >= 1)
																			{
																				while (b <= 47)
																				{
																					while (true)
																					{
																						IL_075b:
																						if (24 < b)
																						{
																							while (true)
																							{
																								IL_074b:
																								if (36 >= b)
																								{
																									while (true)
																									{
																										IL_073e:
																										if (36 > b)
																										{
																											while (true)
																											{
																												IL_072e:
																												if (30 >= b)
																												{
																													while (true)
																													{
																														IL_071e:
																														if (30 > b)
																														{
																															while (true)
																															{
																																IL_070e:
																																if (27 >= b)
																																{
																																	while (true)
																																	{
																																		IL_06fe:
																																		if (27 > b)
																																		{
																																			while (true)
																																			{
																																				IL_06ee:
																																				if (25 >= b)
																																				{
																																					while (25 <= b)
																																					{
																																						while (true)
																																						{
																																							IL_06bf:
																																							array2[num6 - 2] = 0;
																																							num = 307;
																																							while (true)
																																							{
																																								IL_0662:
																																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																																								num = 400;
																																								while (true)
																																								{
																																									if (num != 400)
																																									{
																																										if (num != 1381)
																																										{
																																											break;
																																										}
																																										switch (num)
																																										{
																																										case 196:
																																											break;
																																										default:
																																											continue;
																																										case 307:
																																											goto IL_0662;
																																										case 330:
																																										case 359:
																																											goto IL_06bf;
																																										case 248:
																																											goto IL_06de;
																																										case 112:
																																											goto IL_06ee;
																																										case 33:
																																											goto IL_06fe;
																																										case 271:
																																											goto IL_070e;
																																										case 241:
																																											goto IL_071e;
																																										case 47:
																																											goto IL_072e;
																																										case 110:
																																											goto IL_073e;
																																										case 93:
																																											goto IL_074b;
																																										case 297:
																																											goto IL_075b;
																																										case 377:
																																											goto IL_076b;
																																										case 388:
																																											goto IL_077b;
																																										case 207:
																																											goto IL_078b;
																																										case 187:
																																										case 189:
																																											goto IL_07a4;
																																										case 130:
																																										case 157:
																																											goto IL_07b8;
																																										case 267:
																																											goto IL_07cc;
																																										case 83:
																																											goto IL_080b;
																																										case 95:
																																										case 298:
																																											goto IL_081e;
																																										case 293:
																																											goto IL_0832;
																																										case 20:
																																										case 320:
																																											goto IL_0873;
																																										case 230:
																																											goto IL_08b0;
																																										case 17:
																																											goto IL_08c4;
																																										case 347:
																																											goto IL_08d7;
																																										case 371:
																																											goto IL_08ea;
																																										case 235:
																																										case 354:
																																											goto IL_08f5;
																																										case 216:
																																											goto IL_092d;
																																										case 133:
																																											goto IL_0941;
																																										case 55:
																																											goto IL_0954;
																																										case 7:
																																											goto IL_0962;
																																										case 256:
																																										case 332:
																																											goto IL_0970;
																																										case 86:
																																											goto IL_0a27;
																																										case 291:
																																											goto IL_0a35;
																																										case 255:
																																											goto IL_0a48;
																																										case 331:
																																											goto IL_0a56;
																																										case 136:
																																										case 269:
																																											goto IL_0a6d;
																																										case 249:
																																											goto IL_0ab6;
																																										case 239:
																																											goto IL_0ad3;
																																										case 247:
																																											goto IL_0ae6;
																																										case 191:
																																											goto IL_0af4;
																																										case 105:
																																											goto IL_0b02;
																																										case 149:
																																											goto IL_0b0d;
																																										case 15:
																																										case 201:
																																											goto IL_0b1b;
																																										case 140:
																																											goto IL_0b39;
																																										case 162:
																																											goto IL_0b47;
																																										case 198:
																																										case 358:
																																											goto IL_0b55;
																																										case 219:
																																											goto IL_0b95;
																																										case 188:
																																											goto IL_0ba9;
																																										case 160:
																																											goto IL_0bbc;
																																										case 324:
																																											goto IL_0bc7;
																																										case 132:
																																										case 346:
																																											goto IL_0bd5;
																																										case 70:
																																											goto IL_0be3;
																																										case 335:
																																											goto IL_0c06;
																																										case 41:
																																											goto IL_0c15;
																																										case 238:
																																											goto IL_0c2c;
																																										case 78:
																																										case 135:
																																											goto IL_0c3a;
																																										case 155:
																																											goto IL_0c7a;
																																										case 159:
																																											goto IL_0c8e;
																																										case 91:
																																											goto IL_0ca1;
																																										case 103:
																																											goto IL_0caf;
																																										case 66:
																																											goto IL_0cbd;
																																										case 52:
																																										case 333:
																																											goto IL_0ccb;
																																										case 113:
																																											goto IL_0d2d;
																																										case 224:
																																											goto IL_0d40;
																																										case 60:
																																											goto IL_0d4e;
																																										case 163:
																																											goto IL_0d61;
																																										case 173:
																																										case 277:
																																											goto IL_0d6c;
																																										case 334:
																																											goto IL_0db1;
																																										case 97:
																																											goto IL_0dbc;
																																										case 309:
																																										case 310:
																																											goto IL_0dca;
																																										case 279:
																																											goto IL_0e0a;
																																										case 10:
																																											goto IL_0e27;
																																										case 76:
																																											goto IL_0e3a;
																																										case 338:
																																											goto IL_0e48;
																																										case 43:
																																										case 213:
																																											goto IL_0e56;
																																										case 376:
																																											goto IL_0e69;
																																										case 119:
																																											goto IL_0e77;
																																										case 385:
																																											goto IL_0e8a;
																																										case 35:
																																											goto IL_0e98;
																																										case 38:
																																											goto IL_0ea6;
																																										case 234:
																																										case 386:
																																											goto IL_0ec2;
																																										case 223:
																																											goto IL_0eeb;
																																										case 109:
																																											goto IL_0f02;
																																										case 391:
																																											goto IL_0f15;
																																										case 98:
																																											goto IL_0f23;
																																										case 128:
																																											goto IL_0f31;
																																										case 344:
																																											goto IL_0f3c;
																																										case 59:
																																											goto IL_0f4a;
																																										case 152:
																																										case 210:
																																											goto IL_0f58;
																																										case 296:
																																											goto IL_0f7b;
																																										case 23:
																																											goto IL_0f89;
																																										case 379:
																																											goto IL_0f97;
																																										case 67:
																																											goto IL_0faa;
																																										case 356:
																																										case 380:
																																											goto IL_0fb8;
																																										case 301:
																																											goto IL_100a;
																																										case 32:
																																											goto IL_101d;
																																										case 158:
																																										case 221:
																																											goto IL_1028;
																																										case 62:
																																											goto IL_1069;
																																										case 262:
																																											goto IL_107d;
																																										case 281:
																																											goto IL_1090;
																																										case 146:
																																											goto IL_109b;
																																										case 197:
																																										case 368:
																																											goto IL_10a9;
																																										case 206:
																																											goto IL_10cb;
																																										case 285:
																																											goto IL_10e2;
																																										case 258:
																																											goto IL_10f0;
																																										case 139:
																																											goto IL_1103;
																																										case 120:
																																											goto IL_1111;
																																										case 101:
																																										case 261:
																																											goto IL_111f;
																																										case 369:
																																											goto IL_1140;
																																										case 126:
																																											goto IL_114e;
																																										case 8:
																																											goto IL_115c;
																																										case 68:
																																										case 170:
																																											goto IL_116a;
																																										case 208:
																																											goto IL_1182;
																																										case 214:
																																											goto IL_11a0;
																																										case 311:
																																											goto IL_11c4;
																																										case 161:
																																											goto IL_11dc;
																																										case 102:
																																											goto IL_11ef;
																																										case 242:
																																											goto IL_11fa;
																																										case 115:
																																										case 287:
																																											goto IL_1208;
																																										case 337:
																																											goto IL_1226;
																																										case 318:
																																											goto IL_1234;
																																										case 11:
																																											goto IL_1247;
																																										case 65:
																																											goto IL_125e;
																																										case 88:
																																										case 176:
																																											goto IL_126c;
																																										case 372:
																																											goto IL_1295;
																																										case 357:
																																											goto IL_12ae;
																																										case 4:
																																											goto IL_12b9;
																																										case 177:
																																										case 350:
																																											goto IL_12c7;
																																										case 305:
																																											goto IL_12d5;
																																										case 122:
																																											goto IL_12ed;
																																										case 53:
																																											goto IL_12fb;
																																										case 185:
																																											goto IL_130e;
																																										case 81:
																																											goto IL_1325;
																																										case 171:
																																										case 275:
																																											goto IL_1333;
																																										case 184:
																																											goto IL_1371;
																																										case 142:
																																										case 295:
																																											goto IL_1384;
																																										case 18:
																																											goto IL_1398;
																																										case 317:
																																											goto IL_13d9;
																																										case 392:
																																											goto IL_13ec;
																																										case 355:
																																											goto IL_1400;
																																										case 211:
																																											goto IL_1421;
																																										case 172:
																																											goto IL_1434;
																																										case 124:
																																											goto IL_1442;
																																										case 74:
																																										case 218:
																																											goto IL_1450;
																																										case 22:
																																											goto IL_1469;
																																										case 362:
																																											goto IL_1477;
																																										case 150:
																																											goto IL_1485;
																																										case 121:
																																											goto IL_1498;
																																										case 250:
																																											goto IL_14a6;
																																										case 227:
																																											goto IL_14b4;
																																										case 282:
																																										case 375:
																																											goto IL_14c2;
																																										case 148:
																																											goto IL_14d6;
																																										case 352:
																																											goto IL_1515;
																																										case 302:
																																											goto IL_1528;
																																										case 94:
																																										case 186:
																																											goto IL_153f;
																																										case 278:
																																											goto IL_157f;
																																										case 36:
																																											goto IL_1593;
																																										case 387:
																																											goto IL_15a6;
																																										case 268:
																																											goto IL_15b4;
																																										case 156:
																																											goto IL_15c2;
																																										case 27:
																																											goto IL_15cd;
																																										case 85:
																																										case 266:
																																											goto IL_15db;
																																										case 37:
																																											goto IL_1604;
																																										case 299:
																																											goto IL_1612;
																																										case 178:
																																											goto IL_1625;
																																										case 199:
																																											goto IL_1633;
																																										case 29:
																																										case 169:
																																											goto IL_1641;
																																										case 39:
																																											goto IL_1655;
																																										case 390:
																																											goto IL_1694;
																																										case 168:
																																										case 384:
																																											goto IL_16a7;
																																										case 125:
																																											goto IL_16d1;
																																										case 263:
																																											goto IL_16df;
																																										case 251:
																																											goto IL_16f2;
																																										case 9:
																																											goto IL_16fd;
																																										case 1:
																																										case 30:
																																											goto IL_170b;
																																										case 378:
																																											goto IL_171f;
																																										case 80:
																																											goto IL_175e;
																																										case 116:
																																											goto IL_1771;
																																										case 289:
																																											goto IL_177f;
																																										case 138:
																																										case 260:
																																											goto IL_178d;
																																										case 252:
																																											goto IL_17cd;
																																										case 165:
																																											goto IL_17e1;
																																										case 365:
																																											goto IL_17f4;
																																										case 342:
																																											goto IL_1802;
																																										case 153:
																																											goto IL_1810;
																																										case 134:
																																										case 254:
																																											goto IL_181b;
																																										case 147:
																																											goto IL_1844;
																																										case 34:
																																											goto IL_1852;
																																										case 84:
																																											goto IL_1865;
																																										case 12:
																																											goto IL_1870;
																																										case 75:
																																										case 203:
																																											goto IL_1887;
																																										case 69:
																																											goto IL_189b;
																																										case 141:
																																											goto IL_18da;
																																										case 48:
																																											goto IL_18ed;
																																										case 272:
																																											goto IL_18fb;
																																										case 154:
																																										case 321:
																																											goto IL_1909;
																																										case 364:
																																											goto IL_191d;
																																										case 106:
																																											goto IL_1969;
																																										case 151:
																																											goto IL_1977;
																																										case 14:
																																											goto IL_198a;
																																										case 363:
																																											goto IL_1995;
																																										case 26:
																																										case 56:
																																											goto IL_19a3;
																																										case 351:
																																											goto IL_19bf;
																																										case 72:
																																											goto IL_19cd;
																																										case 265:
																																											goto IL_19e9;
																																										case 111:
																																										case 339:
																																											goto IL_19fd;
																																										case 253:
																																											goto IL_1a16;
																																										case 274:
																																											goto IL_1a29;
																																										case 45:
																																											goto IL_1a37;
																																										case 222:
																																										case 290:
																																											goto IL_1a42;
																																										case 205:
																																											goto IL_1a60;
																																										case 192:
																																											goto IL_1a6e;
																																										case 237:
																																											goto IL_1a7c;
																																										case 209:
																																											goto IL_1a8f;
																																										case 64:
																																											goto IL_1a9a;
																																										case 327:
																																										case 360:
																																											goto IL_1aa8;
																																										case 49:
																																											goto IL_1ae5;
																																										case 89:
																																											goto IL_1af9;
																																										case 329:
																																											goto IL_1b0c;
																																										case 193:
																																											goto IL_1b1a;
																																										case 25:
																																										case 315:
																																											goto IL_1b28;
																																										case 40:
																																											goto IL_1b51;
																																										case 314:
																																											goto IL_1b5f;
																																										case 131:
																																											goto IL_1b72;
																																										case 190:
																																											goto IL_1b7d;
																																										case 51:
																																										case 54:
																																											goto IL_1b8b;
																																										case 343:
																																											goto IL_1baf;
																																										case 194:
																																											goto IL_1bbd;
																																										case 212:
																																											goto IL_1bcb;
																																										case 366:
																																											goto IL_1bde;
																																										case 24:
																																											goto IL_1be9;
																																										case 276:
																																										case 393:
																																											goto IL_1bf4;
																																										case 63:
																																											goto IL_1c31;
																																										case 286:
																																											goto IL_1c45;
																																										case 3:
																																										case 5:
																																										case 6:
																																										case 13:
																																										case 16:
																																										case 21:
																																										case 42:
																																										case 46:
																																										case 50:
																																										case 57:
																																										case 58:
																																										case 73:
																																										case 82:
																																										case 87:
																																										case 90:
																																										case 92:
																																										case 100:
																																										case 104:
																																										case 117:
																																										case 129:
																																										case 145:
																																										case 167:
																																										case 174:
																																										case 179:
																																										case 200:
																																										case 215:
																																										case 217:
																																										case 220:
																																										case 225:
																																										case 226:
																																										case 229:
																																										case 231:
																																										case 246:
																																										case 264:
																																										case 284:
																																										case 288:
																																										case 292:
																																										case 303:
																																										case 304:
																																										case 306:
																																										case 312:
																																										case 316:
																																										case 319:
																																										case 325:
																																										case 336:
																																										case 345:
																																										case 361:
																																										case 367:
																																										case 383:
																																										case 389:
																																											goto end_IL_064f;
																																										case 2:
																																										case 28:
																																										case 31:
																																										case 44:
																																										case 61:
																																										case 71:
																																										case 77:
																																										case 79:
																																										case 96:
																																										case 99:
																																										case 107:
																																										case 108:
																																										case 114:
																																										case 118:
																																										case 123:
																																										case 127:
																																										case 137:
																																										case 143:
																																										case 144:
																																										case 164:
																																										case 166:
																																										case 175:
																																										case 180:
																																										case 181:
																																										case 182:
																																										case 183:
																																										case 202:
																																										case 228:
																																										case 232:
																																										case 233:
																																										case 236:
																																										case 243:
																																										case 244:
																																										case 257:
																																										case 259:
																																										case 273:
																																										case 283:
																																										case 300:
																																										case 313:
																																										case 323:
																																										case 326:
																																										case 328:
																																										case 340:
																																										case 341:
																																										case 349:
																																										case 353:
																																										case 373:
																																										case 374:
																																										case 381:
																																										case 382:
																																											goto IL_1c68;
																																										case 294:
																																											goto IL_1c7b;
																																										case 348:
																																											goto IL_1c85;
																																										case 19:
																																											goto IL_1c90;
																																										case 204:
																																											goto IL_1ca0;
																																										case 308:
																																											goto IL_1cb0;
																																										case 0:
																																											goto IL_1cc0;
																																										case 370:
																																											goto IL_1cd0;
																																										case 280:
																																											goto IL_1ce0;
																																										case 270:
																																											goto IL_1cf0;
																																										case 240:
																																											goto IL_1d00;
																																										case 195:
																																											goto IL_1d10;
																																										case 245:
																																										case 322:
																																											return;
																																										}
																																										goto end_IL_077b;
																																									}
																																									num6--;
																																									goto IL_1421;
																																									IL_1421:
																																									ptr2 += 8;
																																									goto IL_1c68;
																																									continue;
																																									end_IL_064f:
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																						IL_06de:;
																																					}
																																					break;
																																				}
																																				goto IL_1434;
																																				IL_1485:
																																				ptr2 += 16;
																																				goto IL_1c68;
																																				IL_1434:
																																				if (26 < b)
																																				{
																																					break;
																																				}
																																				goto IL_1442;
																																				IL_1442:
																																				if (26 > b)
																																				{
																																					break;
																																				}
																																				goto IL_1450;
																																				IL_1450:
																																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																																				goto IL_1469;
																																				IL_1469:
																																				array2[num6] = 3;
																																				goto IL_1477;
																																				IL_1477:
																																				num6++;
																																				goto IL_1485;
																																			}
																																			break;
																																		}
																																		goto IL_081e;
																																		IL_08d7:
																																		ptr2 += 8;
																																		goto IL_1c68;
																																		IL_081e:
																																		array2[num6 - 1] = 3;
																																		goto IL_0832;
																																		IL_0832:
																																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																		goto IL_08d7;
																																	}
																																	break;
																																}
																																goto IL_1498;
																																IL_157f:
																																array2[num6 - 2] = 3;
																																goto IL_1593;
																																IL_1498:
																																if (28 < b)
																																{
																																	goto IL_14a6;
																																}
																																goto IL_1528;
																																IL_14a6:
																																if (29 < b)
																																{
																																	break;
																																}
																																goto IL_14b4;
																																IL_14b4:
																																if (29 > b)
																																{
																																	break;
																																}
																																goto IL_14c2;
																																IL_14c2:
																																array2[num6 - 1] = 0;
																																goto IL_14d6;
																																IL_14d6:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																																goto IL_1515;
																																IL_1515:
																																ptr2 += 8;
																																goto IL_1c68;
																																IL_1528:
																																if (28 > b)
																																{
																																	break;
																																}
																																num = 94;
																																goto IL_153f;
																																IL_1593:
																																num6--;
																																goto IL_1c68;
																																IL_153f:
																																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_157f;
																															}
																															break;
																														}
																														goto IL_0873;
																														IL_08c4:
																														ptr2 += 8;
																														goto IL_1c68;
																														IL_0873:
																														array3[num6 - 1] = ((delegate*<ColorOption, Color>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																														goto IL_08b0;
																														IL_08b0:
																														array2[num6 - 1] = 4;
																														goto IL_08c4;
																													}
																													break;
																												}
																												goto IL_15a6;
																												IL_17e1:
																												num6--;
																												goto IL_1c68;
																												IL_15a6:
																												if (33 >= b)
																												{
																													goto IL_15b4;
																												}
																												goto IL_16f2;
																												IL_15b4:
																												if (33 > b)
																												{
																													goto IL_15c2;
																												}
																												goto IL_16a7;
																												IL_15c2:
																												if (31 >= b)
																												{
																													goto IL_15cd;
																												}
																												goto IL_1625;
																												IL_15cd:
																												if (31 > b)
																												{
																													break;
																												}
																												goto IL_15db;
																												IL_15db:
																												((delegate*<Color, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																												goto IL_1604;
																												IL_1604:
																												num6--;
																												goto IL_1612;
																												IL_1612:
																												ptr2 += 8;
																												goto IL_1c68;
																												IL_1625:
																												if (32 < b)
																												{
																													break;
																												}
																												goto IL_1633;
																												IL_1633:
																												if (32 > b)
																												{
																													break;
																												}
																												goto IL_1641;
																												IL_1641:
																												array2[num6 - 1] = 3;
																												goto IL_1655;
																												IL_1655:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_1694;
																												IL_1694:
																												ptr2 += 8;
																												goto IL_1c68;
																												IL_16a7:
																												((delegate*<bool, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																												goto IL_16d1;
																												IL_16d1:
																												num6--;
																												goto IL_16df;
																												IL_16df:
																												ptr2 += 8;
																												goto IL_1c68;
																												IL_16f2:
																												if (34 >= b)
																												{
																													goto IL_16fd;
																												}
																												goto IL_1771;
																												IL_16fd:
																												if (34 > b)
																												{
																													break;
																												}
																												goto IL_170b;
																												IL_170b:
																												array2[num6 - 1] = 3;
																												goto IL_171f;
																												IL_171f:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																												goto IL_175e;
																												IL_175e:
																												ptr2 += 8;
																												goto IL_1c68;
																												IL_1771:
																												if (35 < b)
																												{
																													break;
																												}
																												goto IL_177f;
																												IL_177f:
																												if (35 > b)
																												{
																													break;
																												}
																												goto IL_178d;
																												IL_178d:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_17cd;
																												IL_17cd:
																												array2[num6 - 2] = 3;
																												goto IL_17e1;
																											}
																											break;
																										}
																										goto IL_07b8;
																										IL_080b:
																										ptr2 += 8;
																										goto IL_1c68;
																										IL_07b8:
																										array2[num6 - 1] = 3;
																										goto IL_07cc;
																										IL_07cc:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_080b;
																									}
																									break;
																								}
																								goto IL_17f4;
																								IL_1be9:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_1bf4;
																								IL_17f4:
																								if (42 < b)
																								{
																									goto IL_1802;
																								}
																								num = 265;
																								goto IL_19e9;
																								IL_1802:
																								if (45 >= b)
																								{
																									goto IL_1810;
																								}
																								goto IL_198a;
																								IL_1810:
																								if (45 <= b)
																								{
																									goto IL_181b;
																								}
																								goto IL_1865;
																								IL_181b:
																								((delegate*<string, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_1844;
																								IL_1844:
																								num6--;
																								goto IL_1852;
																								IL_1852:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_1865:
																								if (43 >= b)
																								{
																									goto IL_1870;
																								}
																								goto IL_18ed;
																								IL_1870:
																								if (43 > b)
																								{
																									break;
																								}
																								num = 75;
																								goto IL_1887;
																								IL_1c31:
																								array2[num6 - 2] = 4;
																								goto IL_1c45;
																								IL_1887:
																								array2[num6 - 1] = 3;
																								goto IL_189b;
																								IL_189b:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_18da;
																								IL_18da:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_18ed:
																								if (44 < b)
																								{
																									break;
																								}
																								goto IL_18fb;
																								IL_18fb:
																								if (44 > b)
																								{
																									break;
																								}
																								goto IL_1909;
																								IL_1909:
																								array2[num6 - 2] = 5;
																								goto IL_191d;
																								IL_191d:
																								array3[num6 - 2] = ((delegate*<string, string, string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																								goto IL_1969;
																								IL_1969:
																								num6--;
																								goto IL_1977;
																								IL_1977:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_198a:
																								if (46 >= b)
																								{
																									goto IL_1995;
																								}
																								goto IL_19bf;
																								IL_1995:
																								if (46 > b)
																								{
																									break;
																								}
																								goto IL_19a3;
																								IL_19a3:
																								num7 = ptr2;
																								num8 = -200;
																								num5 = 1;
																								ptr2 = num7 + num8;
																								goto IL_1c68;
																								IL_19bf:
																								if (47 < b)
																								{
																									break;
																								}
																								goto IL_19cd;
																								IL_19cd:
																								if (47 > b)
																								{
																								}
																								break;
																								IL_1bf4:
																								array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_1c31;
																								IL_19e9:
																								if (42 <= b)
																								{
																									num = 339;
																									goto IL_19fd;
																								}
																								goto IL_1a29;
																								IL_1c45:
																								num6--;
																								goto IL_1c68;
																								IL_19fd:
																								global::_003CModule_003E.colorOption_1 = (ColorOption)array3[num6 - 1];
																								goto IL_1a16;
																								IL_1a16:
																								num6--;
																								goto IL_1c68;
																								IL_1a29:
																								if (39 >= b)
																								{
																									goto IL_1a37;
																								}
																								goto IL_1b72;
																								IL_1a37:
																								if (39 <= b)
																								{
																									goto IL_1a42;
																								}
																								goto IL_1a8f;
																								IL_1a42:
																								array3[num6] = ((delegate*<ColorOption[]>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
																								goto IL_1a60;
																								IL_1a60:
																								array2[num6] = 5;
																								goto IL_1a6e;
																								IL_1a6e:
																								num6++;
																								goto IL_1a7c;
																								IL_1a7c:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_1a8f:
																								if (37 >= b)
																								{
																									goto IL_1a9a;
																								}
																								goto IL_1b0c;
																								IL_1a9a:
																								if (37 > b)
																								{
																									break;
																								}
																								goto IL_1aa8;
																								IL_1aa8:
																								array3[num6 - 1] = ((delegate*<ColorOption, Color>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																								goto IL_1ae5;
																								IL_1ae5:
																								array2[num6 - 1] = 4;
																								goto IL_1af9;
																								IL_1af9:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_1b0c:
																								if (38 < b)
																								{
																									break;
																								}
																								goto IL_1b1a;
																								IL_1b1a:
																								if (38 > b)
																								{
																									break;
																								}
																								goto IL_1b28;
																								IL_1b28:
																								((delegate*<Color, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																								goto IL_1b51;
																								IL_1b51:
																								num6--;
																								goto IL_1b5f;
																								IL_1b5f:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_1b72:
																								if (40 >= b)
																								{
																									goto IL_1b7d;
																								}
																								goto IL_1bde;
																								IL_1b7d:
																								if (40 > b)
																								{
																									break;
																								}
																								goto IL_1b8b;
																								IL_1b8b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
																								goto IL_1baf;
																								IL_1baf:
																								array2[num6] = 0;
																								goto IL_1bbd;
																								IL_1bbd:
																								num6++;
																								goto IL_1bcb;
																								IL_1bcb:
																								ptr2 += 8;
																								goto IL_1c68;
																								IL_1bde:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_1be9;
																							}
																							break;
																						}
																						goto IL_08ea;
																						IL_130e:
																						if (17 < b)
																						{
																							break;
																						}
																						num = 81;
																						goto IL_1325;
																						IL_08ea:
																						if (24 <= b)
																						{
																							goto IL_08f5;
																						}
																						goto IL_0954;
																						IL_08f5:
																						array3[num6 - 1] = ((delegate*<ColorOption, string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																						goto IL_092d;
																						IL_092d:
																						array2[num6 - 1] = 5;
																						goto IL_0941;
																						IL_0941:
																						ptr2 += 8;
																						goto IL_1c68;
																						IL_0954:
																						if (12 >= b)
																						{
																							goto IL_0962;
																						}
																						goto IL_0f15;
																						IL_0962:
																						if (12 <= b)
																						{
																							goto IL_0970;
																						}
																						goto IL_0a48;
																						IL_0970:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_097f;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0a27;
																						IL_13d9:
																						ptr2 += 8;
																						goto IL_1c68;
																						IL_1325:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_1333;
																						IL_1333:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_1371;
																						IL_0a27:
																						array2[num6] = 5;
																						goto IL_0a35;
																						IL_0a35:
																						num6++;
																						goto IL_1c68;
																						IL_0a48:
																						if (6 >= b)
																						{
																							goto IL_0a56;
																						}
																						goto IL_0ca1;
																						IL_0a56:
																						if (6 <= b)
																						{
																							num = 136;
																							goto IL_0a6d;
																						}
																						goto IL_0ae6;
																						IL_1371:
																						num6 -= 3;
																						goto IL_1c68;
																						IL_0a6d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						num = 249;
																						goto IL_0ab6;
																						IL_0ab6:
																						array2[num6 - 2] = 0;
																						num = 239;
																						goto IL_0ad3;
																						IL_0ad3:
																						num6--;
																						goto IL_1c68;
																						IL_0ae6:
																						if (3 >= b)
																						{
																							goto IL_0af4;
																						}
																						goto IL_0bbc;
																						IL_0af4:
																						if (3 > b)
																						{
																							goto IL_0b02;
																						}
																						goto IL_0ec2;
																						IL_0b02:
																						if (1 >= b)
																						{
																							goto IL_0b0d;
																						}
																						goto IL_0b39;
																						IL_0b0d:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0b1b;
																						IL_0b1b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0e8a;
																						IL_0e8a:
																						array2[num6] = 0;
																						goto IL_0e98;
																						IL_0e98:
																						num6++;
																						goto IL_0ea6;
																						IL_0ea6:
																						ptr2 += 8;
																						num = 236;
																						goto IL_1c68;
																						IL_0b39:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_0b47;
																						IL_0b47:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_0b55;
																						IL_0b55:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0b95;
																						IL_0b95:
																						array2[num6 - 2] = 0;
																						goto IL_0ba9;
																						IL_0ba9:
																						num6--;
																						goto IL_1c68;
																						IL_0ec2:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0eeb;
																						IL_0eeb:
																						ptr2 += 8;
																						num = 109;
																						goto IL_0f02;
																						IL_0f02:
																						num6--;
																						goto IL_1c68;
																						IL_0bbc:
																						if (4 >= b)
																						{
																							goto IL_0bc7;
																						}
																						goto IL_0c15;
																						IL_0bc7:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0bd5;
																						IL_0bd5:
																						array2[num6] = 0;
																						goto IL_0be3;
																						IL_0be3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0c06;
																						IL_0c06:
																						array3[num6] = null;
																						goto IL_0e69;
																						IL_0e69:
																						num6++;
																						goto IL_0e77;
																						IL_0e77:
																						ptr2 += 8;
																						goto IL_1c68;
																						IL_0c15:
																						if (5 < b)
																						{
																							break;
																						}
																						num = 238;
																						goto IL_0c2c;
																						IL_1384:
																						array2[num6 - 1] = 5;
																						goto IL_1398;
																						IL_0c2c:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0c3a;
																						IL_0c3a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0c7a;
																						IL_0c7a:
																						array2[num6 - 2] = 0;
																						goto IL_0c8e;
																						IL_0c8e:
																						num6--;
																						goto IL_1c68;
																						IL_0ca1:
																						if (9 < b)
																						{
																							goto IL_0caf;
																						}
																						goto IL_0d61;
																						IL_0caf:
																						if (10 >= b)
																						{
																							goto IL_0cbd;
																						}
																						goto IL_0d40;
																						IL_0cbd:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0ccb;
																						IL_0ccb:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0d2d;
																						IL_0d2d:
																						num6 -= 2;
																						goto IL_1c68;
																						IL_0d40:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_0d4e;
																						IL_0d4e:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_1c68;
																						IL_0d61:
																						if (9 <= b)
																						{
																							goto IL_0d6c;
																						}
																						goto IL_0db1;
																						IL_0d6c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_13ec;
																						IL_13ec:
																						array2[num6 - 2] = 0;
																						goto IL_1400;
																						IL_1400:
																						num6--;
																						goto IL_1c68;
																						IL_0db1:
																						if (7 >= b)
																						{
																							goto IL_0dbc;
																						}
																						goto IL_0e3a;
																						IL_0dbc:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0dca;
																						IL_0dca:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0e0a;
																						IL_0e0a:
																						array2[num6 - 2] = 0;
																						num = 10;
																						goto IL_0e27;
																						IL_0e27:
																						num6--;
																						goto IL_1c68;
																						IL_0e3a:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_0e48;
																						IL_0e48:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0e56;
																						IL_0e56:
																						num6--;
																						goto IL_1c68;
																						IL_0f15:
																						if (18 < b)
																						{
																							goto IL_0f23;
																						}
																						goto IL_1140;
																						IL_0f23:
																						if (21 < b)
																						{
																							goto IL_0f31;
																						}
																						goto IL_101d;
																						IL_0f31:
																						if (22 < b)
																						{
																							goto IL_0f3c;
																						}
																						goto IL_0faa;
																						IL_0f3c:
																						if (23 < b)
																						{
																							break;
																						}
																						goto IL_0f4a;
																						IL_0f4a:
																						if (23 > b)
																						{
																							break;
																						}
																						goto IL_0f58;
																						IL_0f58:
																						array3[num6] = ((delegate*<ColorOption>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
																						goto IL_0f7b;
																						IL_0f7b:
																						array2[num6] = 4;
																						goto IL_0f89;
																						IL_0f89:
																						num6++;
																						goto IL_0f97;
																						IL_0f97:
																						ptr2 += 8;
																						goto IL_1c68;
																						IL_0faa:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0fb8;
																						IL_0fb8:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_100a;
																						IL_100a:
																						num6--;
																						goto IL_1c68;
																						IL_101d:
																						if (21 <= b)
																						{
																							goto IL_1028;
																						}
																						goto IL_1090;
																						IL_1028:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_1069;
																						IL_1069:
																						array2[num6 - 2] = 0;
																						goto IL_107d;
																						IL_107d:
																						num6--;
																						goto IL_1c68;
																						IL_1090:
																						if (19 >= b)
																						{
																							goto IL_109b;
																						}
																						goto IL_1103;
																						IL_109b:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_10a9;
																						IL_10a9:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						num = 206;
																						goto IL_10cb;
																						IL_10cb:
																						array2[num6] = 1;
																						num = 285;
																						goto IL_10e2;
																						IL_10e2:
																						num6++;
																						goto IL_10f0;
																						IL_10f0:
																						ptr2 += 16;
																						goto IL_1c68;
																						IL_1103:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_1111;
																						IL_1111:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_111f;
																						IL_111f:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						num = 118;
																						goto IL_1c68;
																						IL_1140:
																						if (18 > b)
																						{
																							goto IL_114e;
																						}
																						goto IL_1384;
																						IL_114e:
																						if (15 >= b)
																						{
																							goto IL_115c;
																						}
																						goto IL_12ae;
																						IL_115c:
																						if (15 <= b)
																						{
																							goto IL_116a;
																						}
																						goto IL_11ef;
																						IL_116a:
																						array2[num6] = array2[num6 - 1];
																						goto IL_1182;
																						IL_1182:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_11a0;
																						IL_11a0:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_11c4;
																						IL_11c4:
																						array3[num6] = array3[num6 - 1];
																						goto IL_11dc;
																						IL_11dc:
																						num6++;
																						goto IL_1c68;
																						IL_11ef:
																						if (13 >= b)
																						{
																							goto IL_11fa;
																						}
																						goto IL_1247;
																						IL_11fa:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_1208;
																						IL_1208:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_1226;
																						IL_1226:
																						ptr2 += 8;
																						goto IL_1234;
																						IL_1234:
																						num6--;
																						goto IL_1c68;
																						IL_1247:
																						if (14 < b)
																						{
																							break;
																						}
																						num = 65;
																						goto IL_125e;
																						IL_1398:
																						array3[num6 - 1] = ((delegate*<string[], string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						num = 317;
																						goto IL_13d9;
																						IL_125e:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_126c;
																						IL_126c:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_1295;
																						IL_1295:
																						array2[num6 - 1] = 5;
																						goto IL_1c68;
																						IL_12ae:
																						if (16 >= b)
																						{
																							goto IL_12b9;
																						}
																						goto IL_130e;
																						IL_12b9:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_12c7;
																						IL_12c7:
																						array2[num6] = 5;
																						goto IL_12d5;
																						IL_12d5:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_12ed;
																						IL_12ed:
																						num6++;
																						goto IL_12fb;
																						IL_12fb:
																						ptr2 += 8;
																						goto IL_1c68;
																					}
																					break;
																					IL_076b:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1c68;
																			continue;
																			end_IL_077b:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_097f:
			while (true)
			{
				IL_097f_2:
				array = new byte[4];
				while (true)
				{
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0a27_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0a35_2:
							num6++;
							while (true)
							{
								IL_1c68_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									num = 207;
									while (true)
									{
										ptr2++;
										num = 388;
										while (true)
										{
											IL_077b_2:
											if (b >= 1)
											{
												while (b <= 47)
												{
													while (true)
													{
														IL_075b_2:
														if (24 < b)
														{
															while (true)
															{
																IL_074b_2:
																if (36 >= b)
																{
																	while (true)
																	{
																		IL_073e_2:
																		if (36 > b)
																		{
																			while (true)
																			{
																				IL_072e_2:
																				if (30 >= b)
																				{
																					while (true)
																					{
																						IL_071e_2:
																						if (30 > b)
																						{
																							while (true)
																							{
																								IL_070e_2:
																								if (27 >= b)
																								{
																									while (true)
																									{
																										IL_06fe_2:
																										if (27 > b)
																										{
																											while (true)
																											{
																												IL_06ee_2:
																												if (25 >= b)
																												{
																													while (25 <= b)
																													{
																														while (true)
																														{
																															IL_06bf_2:
																															array2[num6 - 2] = 0;
																															num = 307;
																															while (true)
																															{
																																IL_0662_2:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																																num = 400;
																																while (true)
																																{
																																	if (num != 400)
																																	{
																																		if (num != 1381)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 307:
																																			goto IL_0662_2;
																																		case 330:
																																		case 359:
																																			goto IL_06bf_2;
																																		case 248:
																																			goto IL_06de_2;
																																		case 112:
																																			goto IL_06ee_2;
																																		case 33:
																																			goto IL_06fe_2;
																																		case 271:
																																			goto IL_070e_2;
																																		case 241:
																																			goto IL_071e_2;
																																		case 47:
																																			goto IL_072e_2;
																																		case 110:
																																			goto IL_073e_2;
																																		case 93:
																																			goto IL_074b_2;
																																		case 297:
																																			goto IL_075b_2;
																																		case 377:
																																			goto IL_076b_2;
																																		case 388:
																																			goto IL_077b_2;
																																		case 207:
																																			goto end_IL_077b_2;
																																		case 187:
																																		case 189:
																																			goto end_IL_078b;
																																		case 130:
																																		case 157:
																																			goto IL_07b8_2;
																																		case 267:
																																			goto IL_07cc_2;
																																		case 83:
																																			goto IL_080b_2;
																																		case 95:
																																		case 298:
																																			goto IL_081e_2;
																																		case 293:
																																			goto IL_0832_2;
																																		case 20:
																																		case 320:
																																			goto IL_0873_2;
																																		case 230:
																																			goto IL_08b0_2;
																																		case 17:
																																			goto IL_08c4_2;
																																		case 347:
																																			goto IL_08d7_2;
																																		case 371:
																																			goto IL_08ea_2;
																																		case 235:
																																		case 354:
																																			goto IL_08f5_2;
																																		case 216:
																																			goto IL_092d_2;
																																		case 133:
																																			goto IL_0941_2;
																																		case 55:
																																			goto IL_0954_2;
																																		case 7:
																																			goto IL_0962_2;
																																		case 256:
																																		case 332:
																																			goto end_IL_07a4;
																																		case 86:
																																			goto IL_0a27_2;
																																		case 291:
																																			goto IL_0a35_2;
																																		case 255:
																																			goto IL_0a48_2;
																																		case 331:
																																			goto IL_0a56_2;
																																		case 136:
																																		case 269:
																																			goto IL_0a6d_2;
																																		case 249:
																																			goto IL_0ab6_2;
																																		case 239:
																																			goto IL_0ad3_2;
																																		case 247:
																																			goto IL_0ae6_2;
																																		case 191:
																																			goto IL_0af4_2;
																																		case 105:
																																			goto IL_0b02_2;
																																		case 149:
																																			goto IL_0b0d_2;
																																		case 15:
																																		case 201:
																																			goto IL_0b1b_2;
																																		case 140:
																																			goto IL_0b39_2;
																																		case 162:
																																			goto IL_0b47_2;
																																		case 198:
																																		case 358:
																																			goto IL_0b55_2;
																																		case 219:
																																			goto IL_0b95_2;
																																		case 188:
																																			goto IL_0ba9_2;
																																		case 160:
																																			goto IL_0bbc_2;
																																		case 324:
																																			goto IL_0bc7_2;
																																		case 132:
																																		case 346:
																																			goto IL_0bd5_2;
																																		case 70:
																																			goto IL_0be3_2;
																																		case 335:
																																			goto IL_0c06_2;
																																		case 41:
																																			goto IL_0c15_2;
																																		case 238:
																																			goto IL_0c2c_2;
																																		case 78:
																																		case 135:
																																			goto IL_0c3a_2;
																																		case 155:
																																			goto IL_0c7a_2;
																																		case 159:
																																			goto IL_0c8e_2;
																																		case 91:
																																			goto IL_0ca1_2;
																																		case 103:
																																			goto IL_0caf_2;
																																		case 66:
																																			goto IL_0cbd_2;
																																		case 52:
																																		case 333:
																																			goto IL_0ccb_2;
																																		case 113:
																																			goto IL_0d2d_2;
																																		case 224:
																																			goto IL_0d40_2;
																																		case 60:
																																			goto IL_0d4e_2;
																																		case 163:
																																			goto IL_0d61_2;
																																		case 173:
																																		case 277:
																																			goto IL_0d6c_2;
																																		case 334:
																																			goto IL_0db1_2;
																																		case 97:
																																			goto IL_0dbc_2;
																																		case 309:
																																		case 310:
																																			goto IL_0dca_2;
																																		case 279:
																																			goto IL_0e0a_2;
																																		case 10:
																																			goto IL_0e27_2;
																																		case 76:
																																			goto IL_0e3a_2;
																																		case 338:
																																			goto IL_0e48_2;
																																		case 43:
																																		case 213:
																																			goto IL_0e56_2;
																																		case 376:
																																			goto IL_0e69_2;
																																		case 119:
																																			goto IL_0e77_2;
																																		case 385:
																																			goto IL_0e8a_2;
																																		case 35:
																																			goto IL_0e98_2;
																																		case 38:
																																			goto IL_0ea6_2;
																																		case 234:
																																		case 386:
																																			goto IL_0ec2_2;
																																		case 223:
																																			goto IL_0eeb_2;
																																		case 109:
																																			goto IL_0f02_2;
																																		case 391:
																																			goto IL_0f15_2;
																																		case 98:
																																			goto IL_0f23_2;
																																		case 128:
																																			goto IL_0f31_2;
																																		case 344:
																																			goto IL_0f3c_2;
																																		case 59:
																																			goto IL_0f4a_2;
																																		case 152:
																																		case 210:
																																			goto IL_0f58_2;
																																		case 296:
																																			goto IL_0f7b_2;
																																		case 23:
																																			goto IL_0f89_2;
																																		case 379:
																																			goto IL_0f97_2;
																																		case 67:
																																			goto IL_0faa_2;
																																		case 356:
																																		case 380:
																																			goto IL_0fb8_2;
																																		case 301:
																																			goto IL_100a_2;
																																		case 32:
																																			goto IL_101d_2;
																																		case 158:
																																		case 221:
																																			goto IL_1028_2;
																																		case 62:
																																			goto IL_1069_2;
																																		case 262:
																																			goto IL_107d_2;
																																		case 281:
																																			goto IL_1090_2;
																																		case 146:
																																			goto IL_109b_2;
																																		case 197:
																																		case 368:
																																			goto IL_10a9_2;
																																		case 206:
																																			goto IL_10cb_2;
																																		case 285:
																																			goto IL_10e2_2;
																																		case 258:
																																			goto IL_10f0_2;
																																		case 139:
																																			goto IL_1103_2;
																																		case 120:
																																			goto IL_1111_2;
																																		case 101:
																																		case 261:
																																			goto IL_111f_2;
																																		case 369:
																																			goto IL_1140_2;
																																		case 126:
																																			goto IL_114e_2;
																																		case 8:
																																			goto IL_115c_2;
																																		case 68:
																																		case 170:
																																			goto IL_116a_2;
																																		case 208:
																																			goto IL_1182_2;
																																		case 214:
																																			goto IL_11a0_2;
																																		case 311:
																																			goto IL_11c4_2;
																																		case 161:
																																			goto IL_11dc_2;
																																		case 102:
																																			goto IL_11ef_2;
																																		case 242:
																																			goto IL_11fa_2;
																																		case 115:
																																		case 287:
																																			goto IL_1208_2;
																																		case 337:
																																			goto IL_1226_2;
																																		case 318:
																																			goto IL_1234_2;
																																		case 11:
																																			goto IL_1247_2;
																																		case 65:
																																			goto IL_125e_2;
																																		case 88:
																																		case 176:
																																			goto IL_126c_2;
																																		case 372:
																																			goto IL_1295_2;
																																		case 357:
																																			goto IL_12ae_2;
																																		case 4:
																																			goto IL_12b9_2;
																																		case 177:
																																		case 350:
																																			goto IL_12c7_2;
																																		case 305:
																																			goto IL_12d5_2;
																																		case 122:
																																			goto IL_12ed_2;
																																		case 53:
																																			goto IL_12fb_2;
																																		case 185:
																																			goto IL_130e_2;
																																		case 81:
																																			goto IL_1325_2;
																																		case 171:
																																		case 275:
																																			goto IL_1333_2;
																																		case 184:
																																			goto IL_1371_2;
																																		case 142:
																																		case 295:
																																			goto IL_1384_2;
																																		case 18:
																																			goto IL_1398_2;
																																		case 317:
																																			goto IL_13d9_2;
																																		case 392:
																																			goto IL_13ec_2;
																																		case 355:
																																			goto IL_1400_2;
																																		case 211:
																																			goto IL_1421_2;
																																		case 172:
																																			goto IL_1434_2;
																																		case 124:
																																			goto IL_1442_2;
																																		case 74:
																																		case 218:
																																			goto IL_1450_2;
																																		case 22:
																																			goto IL_1469_2;
																																		case 362:
																																			goto IL_1477_2;
																																		case 150:
																																			goto IL_1485_2;
																																		case 121:
																																			goto IL_1498_2;
																																		case 250:
																																			goto IL_14a6_2;
																																		case 227:
																																			goto IL_14b4_2;
																																		case 282:
																																		case 375:
																																			goto IL_14c2_2;
																																		case 148:
																																			goto IL_14d6_2;
																																		case 352:
																																			goto IL_1515_2;
																																		case 302:
																																			goto IL_1528_2;
																																		case 94:
																																		case 186:
																																			goto IL_153f_2;
																																		case 278:
																																			goto IL_157f_2;
																																		case 36:
																																			goto IL_1593_2;
																																		case 387:
																																			goto IL_15a6_2;
																																		case 268:
																																			goto IL_15b4_2;
																																		case 156:
																																			goto IL_15c2_2;
																																		case 27:
																																			goto IL_15cd_2;
																																		case 85:
																																		case 266:
																																			goto IL_15db_2;
																																		case 37:
																																			goto IL_1604_2;
																																		case 299:
																																			goto IL_1612_2;
																																		case 178:
																																			goto IL_1625_2;
																																		case 199:
																																			goto IL_1633_2;
																																		case 29:
																																		case 169:
																																			goto IL_1641_2;
																																		case 39:
																																			goto IL_1655_2;
																																		case 390:
																																			goto IL_1694_2;
																																		case 168:
																																		case 384:
																																			goto IL_16a7_2;
																																		case 125:
																																			goto IL_16d1_2;
																																		case 263:
																																			goto IL_16df_2;
																																		case 251:
																																			goto IL_16f2_2;
																																		case 9:
																																			goto IL_16fd_2;
																																		case 1:
																																		case 30:
																																			goto IL_170b_2;
																																		case 378:
																																			goto IL_171f_2;
																																		case 80:
																																			goto IL_175e_2;
																																		case 116:
																																			goto IL_1771_2;
																																		case 289:
																																			goto IL_177f_2;
																																		case 138:
																																		case 260:
																																			goto IL_178d_2;
																																		case 252:
																																			goto IL_17cd_2;
																																		case 165:
																																			goto IL_17e1_2;
																																		case 365:
																																			goto IL_17f4_2;
																																		case 342:
																																			goto IL_1802_2;
																																		case 153:
																																			goto IL_1810_2;
																																		case 134:
																																		case 254:
																																			goto IL_181b_2;
																																		case 147:
																																			goto IL_1844_2;
																																		case 34:
																																			goto IL_1852_2;
																																		case 84:
																																			goto IL_1865_2;
																																		case 12:
																																			goto IL_1870_2;
																																		case 75:
																																		case 203:
																																			goto IL_1887_2;
																																		case 69:
																																			goto IL_189b_2;
																																		case 141:
																																			goto IL_18da_2;
																																		case 48:
																																			goto IL_18ed_2;
																																		case 272:
																																			goto IL_18fb_2;
																																		case 154:
																																		case 321:
																																			goto IL_1909_2;
																																		case 364:
																																			goto IL_191d_2;
																																		case 106:
																																			goto IL_1969_2;
																																		case 151:
																																			goto IL_1977_2;
																																		case 14:
																																			goto IL_198a_2;
																																		case 363:
																																			goto IL_1995_2;
																																		case 26:
																																		case 56:
																																			goto IL_19a3_2;
																																		case 351:
																																			goto IL_19bf_2;
																																		case 72:
																																			goto IL_19cd_2;
																																		case 265:
																																			goto IL_19e9_2;
																																		case 111:
																																		case 339:
																																			goto IL_19fd_2;
																																		case 253:
																																			goto IL_1a16_2;
																																		case 274:
																																			goto IL_1a29_2;
																																		case 45:
																																			goto IL_1a37_2;
																																		case 222:
																																		case 290:
																																			goto IL_1a42_2;
																																		case 205:
																																			goto IL_1a60_2;
																																		case 192:
																																			goto IL_1a6e_2;
																																		case 237:
																																			goto IL_1a7c_2;
																																		case 209:
																																			goto IL_1a8f_2;
																																		case 64:
																																			goto IL_1a9a_2;
																																		case 327:
																																		case 360:
																																			goto IL_1aa8_2;
																																		case 49:
																																			goto IL_1ae5_2;
																																		case 89:
																																			goto IL_1af9_2;
																																		case 329:
																																			goto IL_1b0c_2;
																																		case 193:
																																			goto IL_1b1a_2;
																																		case 25:
																																		case 315:
																																			goto IL_1b28_2;
																																		case 40:
																																			goto IL_1b51_2;
																																		case 314:
																																			goto IL_1b5f_2;
																																		case 131:
																																			goto IL_1b72_2;
																																		case 190:
																																			goto IL_1b7d_2;
																																		case 51:
																																		case 54:
																																			goto IL_1b8b_2;
																																		case 343:
																																			goto IL_1baf_2;
																																		case 194:
																																			goto IL_1bbd_2;
																																		case 212:
																																			goto IL_1bcb_2;
																																		case 366:
																																			goto IL_1bde_2;
																																		case 24:
																																			goto IL_1be9_2;
																																		case 276:
																																		case 393:
																																			goto IL_1bf4_2;
																																		case 63:
																																			goto IL_1c31_2;
																																		case 286:
																																			goto IL_1c45_2;
																																		case 3:
																																		case 5:
																																		case 6:
																																		case 13:
																																		case 16:
																																		case 21:
																																		case 42:
																																		case 46:
																																		case 50:
																																		case 57:
																																		case 58:
																																		case 73:
																																		case 82:
																																		case 87:
																																		case 90:
																																		case 92:
																																		case 100:
																																		case 104:
																																		case 117:
																																		case 129:
																																		case 145:
																																		case 167:
																																		case 174:
																																		case 179:
																																		case 200:
																																		case 215:
																																		case 217:
																																		case 220:
																																		case 225:
																																		case 226:
																																		case 229:
																																		case 231:
																																		case 246:
																																		case 264:
																																		case 284:
																																		case 288:
																																		case 292:
																																		case 303:
																																		case 304:
																																		case 306:
																																		case 312:
																																		case 316:
																																		case 319:
																																		case 325:
																																		case 336:
																																		case 345:
																																		case 361:
																																		case 367:
																																		case 383:
																																		case 389:
																																			goto end_IL_064f_2;
																																		case 2:
																																		case 28:
																																		case 31:
																																		case 44:
																																		case 61:
																																		case 71:
																																		case 77:
																																		case 79:
																																		case 96:
																																		case 99:
																																		case 107:
																																		case 108:
																																		case 114:
																																		case 118:
																																		case 123:
																																		case 127:
																																		case 137:
																																		case 143:
																																		case 144:
																																		case 164:
																																		case 166:
																																		case 175:
																																		case 180:
																																		case 181:
																																		case 182:
																																		case 183:
																																		case 202:
																																		case 228:
																																		case 232:
																																		case 233:
																																		case 236:
																																		case 243:
																																		case 244:
																																		case 257:
																																		case 259:
																																		case 273:
																																		case 283:
																																		case 300:
																																		case 313:
																																		case 323:
																																		case 326:
																																		case 328:
																																		case 340:
																																		case 341:
																																		case 349:
																																		case 353:
																																		case 373:
																																		case 374:
																																		case 381:
																																		case 382:
																																			goto IL_1c68_2;
																																		case 294:
																																			ptr2 = ptr;
																																			goto IL_1c68_2;
																																		case 348:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getExcludeGetChannelData.AddDaysSetParent);
																																			goto case 294;
																																		case 19:
																																			array7 = new object[16];
																																			goto case 348;
																																		case 204:
																																			array6 = new long[4];
																																			goto case 19;
																																		case 308:
																																			array5 = new int[7];
																																			goto case 204;
																																		case 0:
																																			array4 = new int[4];
																																			goto case 308;
																																		case 370:
																																			array3 = new object[4];
																																			goto case 0;
																																		case 280:
																																			array2 = new byte[4];
																																			goto case 370;
																																		case 270:
																																			num4 = num2 * 8;
																																			goto case 280;
																																		case 240:
																																			num3 = num2 * 4;
																																			goto case 270;
																																		case 195:
																																			num2 = 1;
																																			goto case 240;
																																		case 196:
																																			goto end_IL_098d;
																																		case 245:
																																		case 322:
																																			return;
																																		}
																																		continue;
																																	}
																																	num6--;
																																	goto IL_1421_2;
																																	IL_1421_2:
																																	ptr2 += 8;
																																	goto IL_1c68_2;
																																	continue;
																																	end_IL_064f_2:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																														IL_06de_2:;
																													}
																													break;
																												}
																												goto IL_1434_2;
																												IL_1485_2:
																												ptr2 += 16;
																												goto IL_1c68_2;
																												IL_1434_2:
																												if (26 < b)
																												{
																													break;
																												}
																												goto IL_1442_2;
																												IL_1442_2:
																												if (26 > b)
																												{
																													break;
																												}
																												goto IL_1450_2;
																												IL_1450_2:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																												goto IL_1469_2;
																												IL_1469_2:
																												array2[num6] = 3;
																												goto IL_1477_2;
																												IL_1477_2:
																												num6++;
																												goto IL_1485_2;
																											}
																											break;
																										}
																										goto IL_081e_2;
																										IL_08d7_2:
																										ptr2 += 8;
																										goto IL_1c68_2;
																										IL_081e_2:
																										array2[num6 - 1] = 3;
																										goto IL_0832_2;
																										IL_0832_2:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_08d7_2;
																									}
																									break;
																								}
																								goto IL_1498_2;
																								IL_157f_2:
																								array2[num6 - 2] = 3;
																								goto IL_1593_2;
																								IL_1498_2:
																								if (28 < b)
																								{
																									goto IL_14a6_2;
																								}
																								goto IL_1528_2;
																								IL_14a6_2:
																								if (29 < b)
																								{
																									break;
																								}
																								goto IL_14b4_2;
																								IL_14b4_2:
																								if (29 > b)
																								{
																									break;
																								}
																								goto IL_14c2_2;
																								IL_14c2_2:
																								array2[num6 - 1] = 0;
																								goto IL_14d6_2;
																								IL_14d6_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1515_2;
																								IL_1515_2:
																								ptr2 += 8;
																								goto IL_1c68_2;
																								IL_1528_2:
																								if (28 > b)
																								{
																									break;
																								}
																								num = 94;
																								goto IL_153f_2;
																								IL_1593_2:
																								num6--;
																								goto IL_1c68_2;
																								IL_153f_2:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_157f_2;
																							}
																							break;
																						}
																						goto IL_0873_2;
																						IL_08c4_2:
																						ptr2 += 8;
																						goto IL_1c68_2;
																						IL_0873_2:
																						array3[num6 - 1] = ((delegate*<ColorOption, Color>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																						goto IL_08b0_2;
																						IL_08b0_2:
																						array2[num6 - 1] = 4;
																						goto IL_08c4_2;
																					}
																					break;
																				}
																				goto IL_15a6_2;
																				IL_17e1_2:
																				num6--;
																				goto IL_1c68_2;
																				IL_15a6_2:
																				if (33 >= b)
																				{
																					goto IL_15b4_2;
																				}
																				goto IL_16f2_2;
																				IL_15b4_2:
																				if (33 > b)
																				{
																					goto IL_15c2_2;
																				}
																				goto IL_16a7_2;
																				IL_15c2_2:
																				if (31 >= b)
																				{
																					goto IL_15cd_2;
																				}
																				goto IL_1625_2;
																				IL_15cd_2:
																				if (31 > b)
																				{
																					break;
																				}
																				goto IL_15db_2;
																				IL_15db_2:
																				((delegate*<Color, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																				goto IL_1604_2;
																				IL_1604_2:
																				num6--;
																				goto IL_1612_2;
																				IL_1612_2:
																				ptr2 += 8;
																				goto IL_1c68_2;
																				IL_1625_2:
																				if (32 < b)
																				{
																					break;
																				}
																				goto IL_1633_2;
																				IL_1633_2:
																				if (32 > b)
																				{
																					break;
																				}
																				goto IL_1641_2;
																				IL_1641_2:
																				array2[num6 - 1] = 3;
																				goto IL_1655_2;
																				IL_1655_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_1694_2;
																				IL_1694_2:
																				ptr2 += 8;
																				goto IL_1c68_2;
																				IL_16a7_2:
																				((delegate*<bool, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																				goto IL_16d1_2;
																				IL_16d1_2:
																				num6--;
																				goto IL_16df_2;
																				IL_16df_2:
																				ptr2 += 8;
																				goto IL_1c68_2;
																				IL_16f2_2:
																				if (34 >= b)
																				{
																					goto IL_16fd_2;
																				}
																				goto IL_1771_2;
																				IL_16fd_2:
																				if (34 > b)
																				{
																					break;
																				}
																				goto IL_170b_2;
																				IL_170b_2:
																				array2[num6 - 1] = 3;
																				goto IL_171f_2;
																				IL_171f_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																				goto IL_175e_2;
																				IL_175e_2:
																				ptr2 += 8;
																				goto IL_1c68_2;
																				IL_1771_2:
																				if (35 < b)
																				{
																					break;
																				}
																				goto IL_177f_2;
																				IL_177f_2:
																				if (35 > b)
																				{
																					break;
																				}
																				goto IL_178d_2;
																				IL_178d_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_17cd_2;
																				IL_17cd_2:
																				array2[num6 - 2] = 3;
																				goto IL_17e1_2;
																			}
																			break;
																		}
																		goto IL_07b8_2;
																		IL_080b_2:
																		ptr2 += 8;
																		goto IL_1c68_2;
																		IL_07b8_2:
																		array2[num6 - 1] = 3;
																		goto IL_07cc_2;
																		IL_07cc_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_080b_2;
																	}
																	break;
																}
																goto IL_17f4_2;
																IL_1be9_2:
																if (41 > b)
																{
																	break;
																}
																goto IL_1bf4_2;
																IL_17f4_2:
																if (42 < b)
																{
																	goto IL_1802_2;
																}
																num = 265;
																goto IL_19e9_2;
																IL_1802_2:
																if (45 >= b)
																{
																	goto IL_1810_2;
																}
																goto IL_198a_2;
																IL_1810_2:
																if (45 <= b)
																{
																	goto IL_181b_2;
																}
																goto IL_1865_2;
																IL_181b_2:
																((delegate*<string, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_1844_2;
																IL_1844_2:
																num6--;
																goto IL_1852_2;
																IL_1852_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_1865_2:
																if (43 >= b)
																{
																	goto IL_1870_2;
																}
																goto IL_18ed_2;
																IL_1870_2:
																if (43 > b)
																{
																	break;
																}
																num = 75;
																goto IL_1887_2;
																IL_1c31_2:
																array2[num6 - 2] = 4;
																goto IL_1c45_2;
																IL_1887_2:
																array2[num6 - 1] = 3;
																goto IL_189b_2;
																IL_189b_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getFieldTypeOperations[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_18da_2;
																IL_18da_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_18ed_2:
																if (44 < b)
																{
																	break;
																}
																goto IL_18fb_2;
																IL_18fb_2:
																if (44 > b)
																{
																	break;
																}
																goto IL_1909_2;
																IL_1909_2:
																array2[num6 - 2] = 5;
																goto IL_191d_2;
																IL_191d_2:
																array3[num6 - 2] = ((delegate*<string, string, string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																goto IL_1969_2;
																IL_1969_2:
																num6--;
																goto IL_1977_2;
																IL_1977_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_198a_2:
																if (46 >= b)
																{
																	goto IL_1995_2;
																}
																goto IL_19bf_2;
																IL_1995_2:
																if (46 > b)
																{
																	break;
																}
																goto IL_19a3_2;
																IL_19a3_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																goto IL_1c68_2;
																IL_19bf_2:
																if (47 < b)
																{
																	break;
																}
																goto IL_19cd_2;
																IL_19cd_2:
																if (47 > b)
																{
																}
																break;
																IL_1bf4_2:
																array3[num6 - 2] = ((ColorOption[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_1c31_2;
																IL_19e9_2:
																if (42 <= b)
																{
																	num = 339;
																	goto IL_19fd_2;
																}
																goto IL_1a29_2;
																IL_1c45_2:
																num6--;
																goto IL_1c68_2;
																IL_19fd_2:
																global::_003CModule_003E.colorOption_1 = (ColorOption)array3[num6 - 1];
																goto IL_1a16_2;
																IL_1a16_2:
																num6--;
																goto IL_1c68_2;
																IL_1a29_2:
																if (39 >= b)
																{
																	goto IL_1a37_2;
																}
																goto IL_1b72_2;
																IL_1a37_2:
																if (39 <= b)
																{
																	goto IL_1a42_2;
																}
																goto IL_1a8f_2;
																IL_1a42_2:
																array3[num6] = ((delegate*<ColorOption[]>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
																goto IL_1a60_2;
																IL_1a60_2:
																array2[num6] = 5;
																goto IL_1a6e_2;
																IL_1a6e_2:
																num6++;
																goto IL_1a7c_2;
																IL_1a7c_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_1a8f_2:
																if (37 >= b)
																{
																	goto IL_1a9a_2;
																}
																goto IL_1b0c_2;
																IL_1a9a_2:
																if (37 > b)
																{
																	break;
																}
																goto IL_1aa8_2;
																IL_1aa8_2:
																array3[num6 - 1] = ((delegate*<ColorOption, Color>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
																goto IL_1ae5_2;
																IL_1ae5_2:
																array2[num6 - 1] = 4;
																goto IL_1af9_2;
																IL_1af9_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_1b0c_2:
																if (38 < b)
																{
																	break;
																}
																goto IL_1b1a_2;
																IL_1b1a_2:
																if (38 > b)
																{
																	break;
																}
																goto IL_1b28_2;
																IL_1b28_2:
																((delegate*<Color, void>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																goto IL_1b51_2;
																IL_1b51_2:
																num6--;
																goto IL_1b5f_2;
																IL_1b5f_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_1b72_2:
																if (40 >= b)
																{
																	goto IL_1b7d_2;
																}
																goto IL_1bde_2;
																IL_1b7d_2:
																if (40 > b)
																{
																	break;
																}
																goto IL_1b8b_2;
																IL_1b8b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
																goto IL_1baf_2;
																IL_1baf_2:
																array2[num6] = 0;
																goto IL_1bbd_2;
																IL_1bbd_2:
																num6++;
																goto IL_1bcb_2;
																IL_1bcb_2:
																ptr2 += 8;
																goto IL_1c68_2;
																IL_1bde_2:
																if (41 < b)
																{
																	break;
																}
																goto IL_1be9_2;
															}
															break;
														}
														goto IL_08ea_2;
														IL_1333_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_1371_2;
														IL_08ea_2:
														if (24 <= b)
														{
															goto IL_08f5_2;
														}
														goto IL_0954_2;
														IL_08f5_2:
														array3[num6 - 1] = ((delegate*<ColorOption, string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((ColorOption)array3[num6 - 1]);
														goto IL_092d_2;
														IL_092d_2:
														array2[num6 - 1] = 5;
														goto IL_0941_2;
														IL_0941_2:
														ptr2 += 8;
														goto IL_1c68_2;
														IL_0954_2:
														if (12 >= b)
														{
															goto IL_0962_2;
														}
														goto IL_0f15_2;
														IL_0962_2:
														if (12 <= b)
														{
															goto end_IL_07a4;
														}
														goto IL_0a48_2;
														IL_0a48_2:
														if (6 >= b)
														{
															goto IL_0a56_2;
														}
														goto IL_0ca1_2;
														IL_0a56_2:
														if (6 <= b)
														{
															num = 136;
															goto IL_0a6d_2;
														}
														goto IL_0ae6_2;
														IL_1371_2:
														num6 -= 3;
														goto IL_1c68_2;
														IL_0a6d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														num = 249;
														goto IL_0ab6_2;
														IL_0ab6_2:
														array2[num6 - 2] = 0;
														num = 239;
														goto IL_0ad3_2;
														IL_0ad3_2:
														num6--;
														goto IL_1c68_2;
														IL_0ae6_2:
														if (3 >= b)
														{
															goto IL_0af4_2;
														}
														goto IL_0bbc_2;
														IL_0af4_2:
														if (3 > b)
														{
															goto IL_0b02_2;
														}
														goto IL_0ec2_2;
														IL_0b02_2:
														if (1 >= b)
														{
															goto IL_0b0d_2;
														}
														goto IL_0b39_2;
														IL_0b0d_2:
														if (1 > b)
														{
															break;
														}
														goto IL_0b1b_2;
														IL_0b1b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_0e8a_2;
														IL_0e8a_2:
														array2[num6] = 0;
														goto IL_0e98_2;
														IL_0e98_2:
														num6++;
														goto IL_0ea6_2;
														IL_0ea6_2:
														ptr2 += 8;
														num = 236;
														goto IL_1c68_2;
														IL_0b39_2:
														if (2 < b)
														{
															break;
														}
														goto IL_0b47_2;
														IL_0b47_2:
														if (2 > b)
														{
															break;
														}
														goto IL_0b55_2;
														IL_0b55_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0b95_2;
														IL_0b95_2:
														array2[num6 - 2] = 0;
														goto IL_0ba9_2;
														IL_0ba9_2:
														num6--;
														goto IL_1c68_2;
														IL_0ec2_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0eeb_2;
														IL_0eeb_2:
														ptr2 += 8;
														num = 109;
														goto IL_0f02_2;
														IL_0f02_2:
														num6--;
														goto IL_1c68_2;
														IL_0bbc_2:
														if (4 >= b)
														{
															goto IL_0bc7_2;
														}
														goto IL_0c15_2;
														IL_0bc7_2:
														if (4 > b)
														{
															break;
														}
														goto IL_0bd5_2;
														IL_0bd5_2:
														array2[num6] = 0;
														goto IL_0be3_2;
														IL_0be3_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0c06_2;
														IL_0c06_2:
														array3[num6] = null;
														goto IL_0e69_2;
														IL_0e69_2:
														num6++;
														goto IL_0e77_2;
														IL_0e77_2:
														ptr2 += 8;
														goto IL_1c68_2;
														IL_0c15_2:
														if (5 < b)
														{
															break;
														}
														num = 238;
														goto IL_0c2c_2;
														IL_1384_2:
														array2[num6 - 1] = 5;
														goto IL_1398_2;
														IL_0c2c_2:
														if (5 > b)
														{
															break;
														}
														goto IL_0c3a_2;
														IL_0c3a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0c7a_2;
														IL_0c7a_2:
														array2[num6 - 2] = 0;
														goto IL_0c8e_2;
														IL_0c8e_2:
														num6--;
														goto IL_1c68_2;
														IL_0ca1_2:
														if (9 < b)
														{
															goto IL_0caf_2;
														}
														goto IL_0d61_2;
														IL_0caf_2:
														if (10 >= b)
														{
															goto IL_0cbd_2;
														}
														goto IL_0d40_2;
														IL_0cbd_2:
														if (10 > b)
														{
															break;
														}
														goto IL_0ccb_2;
														IL_0ccb_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0d2d_2;
														IL_0d2d_2:
														num6 -= 2;
														goto IL_1c68_2;
														IL_0d40_2:
														if (11 < b)
														{
															break;
														}
														goto IL_0d4e_2;
														IL_0d4e_2:
														if (11 > b)
														{
															break;
														}
														goto IL_1c68_2;
														IL_0d61_2:
														if (9 <= b)
														{
															goto IL_0d6c_2;
														}
														goto IL_0db1_2;
														IL_0d6c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_13ec_2;
														IL_13ec_2:
														array2[num6 - 2] = 0;
														goto IL_1400_2;
														IL_1400_2:
														num6--;
														goto IL_1c68_2;
														IL_0db1_2:
														if (7 >= b)
														{
															goto IL_0dbc_2;
														}
														goto IL_0e3a_2;
														IL_0dbc_2:
														if (7 > b)
														{
															break;
														}
														goto IL_0dca_2;
														IL_0dca_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0e0a_2;
														IL_0e0a_2:
														array2[num6 - 2] = 0;
														num = 10;
														goto IL_0e27_2;
														IL_0e27_2:
														num6--;
														goto IL_1c68_2;
														IL_0e3a_2:
														if (8 < b)
														{
															break;
														}
														goto IL_0e48_2;
														IL_0e48_2:
														if (8 > b)
														{
															break;
														}
														goto IL_0e56_2;
														IL_0e56_2:
														num6--;
														goto IL_1c68_2;
														IL_0f15_2:
														if (18 < b)
														{
															goto IL_0f23_2;
														}
														goto IL_1140_2;
														IL_0f23_2:
														if (21 < b)
														{
															goto IL_0f31_2;
														}
														goto IL_101d_2;
														IL_0f31_2:
														if (22 < b)
														{
															goto IL_0f3c_2;
														}
														goto IL_0faa_2;
														IL_0f3c_2:
														if (23 < b)
														{
															break;
														}
														goto IL_0f4a_2;
														IL_0f4a_2:
														if (23 > b)
														{
															break;
														}
														goto IL_0f58_2;
														IL_0f58_2:
														array3[num6] = ((delegate*<ColorOption>)getFieldTypeOperations[*(int*)(ptr2 + num3)])();
														goto IL_0f7b_2;
														IL_0f7b_2:
														array2[num6] = 4;
														goto IL_0f89_2;
														IL_0f89_2:
														num6++;
														goto IL_0f97_2;
														IL_0f97_2:
														ptr2 += 8;
														goto IL_1c68_2;
														IL_0faa_2:
														if (22 > b)
														{
															break;
														}
														goto IL_0fb8_2;
														IL_0fb8_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_100a_2;
														IL_100a_2:
														num6--;
														goto IL_1c68_2;
														IL_101d_2:
														if (21 <= b)
														{
															goto IL_1028_2;
														}
														goto IL_1090_2;
														IL_1028_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_1069_2;
														IL_1069_2:
														array2[num6 - 2] = 0;
														goto IL_107d_2;
														IL_107d_2:
														num6--;
														goto IL_1c68_2;
														IL_1090_2:
														if (19 >= b)
														{
															goto IL_109b_2;
														}
														goto IL_1103_2;
														IL_109b_2:
														if (19 > b)
														{
															break;
														}
														goto IL_10a9_2;
														IL_10a9_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														num = 206;
														goto IL_10cb_2;
														IL_10cb_2:
														array2[num6] = 1;
														num = 285;
														goto IL_10e2_2;
														IL_10e2_2:
														num6++;
														goto IL_10f0_2;
														IL_10f0_2:
														ptr2 += 16;
														goto IL_1c68_2;
														IL_1103_2:
														if (20 < b)
														{
															break;
														}
														goto IL_1111_2;
														IL_1111_2:
														if (20 > b)
														{
															break;
														}
														goto IL_111f_2;
														IL_111f_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														num = 118;
														goto IL_1c68_2;
														IL_1140_2:
														if (18 > b)
														{
															goto IL_114e_2;
														}
														goto IL_1384_2;
														IL_114e_2:
														if (15 >= b)
														{
															goto IL_115c_2;
														}
														goto IL_12ae_2;
														IL_115c_2:
														if (15 <= b)
														{
															goto IL_116a_2;
														}
														goto IL_11ef_2;
														IL_116a_2:
														array2[num6] = array2[num6 - 1];
														goto IL_1182_2;
														IL_1182_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_11a0_2;
														IL_11a0_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_11c4_2;
														IL_11c4_2:
														array3[num6] = array3[num6 - 1];
														goto IL_11dc_2;
														IL_11dc_2:
														num6++;
														goto IL_1c68_2;
														IL_11ef_2:
														if (13 >= b)
														{
															goto IL_11fa_2;
														}
														goto IL_1247_2;
														IL_11fa_2:
														if (13 > b)
														{
															break;
														}
														goto IL_1208_2;
														IL_1208_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_1226_2;
														IL_1226_2:
														ptr2 += 8;
														goto IL_1234_2;
														IL_1234_2:
														num6--;
														goto IL_1c68_2;
														IL_1247_2:
														if (14 < b)
														{
															break;
														}
														num = 65;
														goto IL_125e_2;
														IL_1398_2:
														array3[num6 - 1] = ((delegate*<string[], string>)getFieldTypeOperations[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														num = 317;
														goto IL_13d9_2;
														IL_125e_2:
														if (14 > b)
														{
															break;
														}
														goto IL_126c_2;
														IL_126c_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1295_2;
														IL_1295_2:
														array2[num6 - 1] = 5;
														goto IL_1c68_2;
														IL_12ae_2:
														if (16 >= b)
														{
															goto IL_12b9_2;
														}
														goto IL_130e_2;
														IL_12b9_2:
														if (16 > b)
														{
															break;
														}
														goto IL_12c7_2;
														IL_12c7_2:
														array2[num6] = 5;
														goto IL_12d5_2;
														IL_12d5_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_12ed_2;
														IL_12ed_2:
														num6++;
														goto IL_12fb_2;
														IL_12fb_2:
														ptr2 += 8;
														goto IL_1c68_2;
														IL_130e_2:
														if (17 < b)
														{
															break;
														}
														num = 81;
														goto IL_1325_2;
														IL_13d9_2:
														ptr2 += 8;
														goto IL_1c68_2;
														IL_1325_2:
														if (17 > b)
														{
															break;
														}
														goto IL_1333_2;
													}
													break;
													IL_076b_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_1c68_2;
											continue;
											end_IL_077b_2:
											break;
										}
										continue;
										end_IL_078b:
										break;
									}
									continue;
									end_IL_07a4:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num9 = num6;
					if (array == null)
					{
						goto IL_097f_2;
					}
					continue;
					end_IL_098d:
					break;
				}
				break;
			}
		}
	}

	public Class129()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class129()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_03c5, IL_03d8, IL_03f7, IL_0407, IL_0417, IL_0424, IL_0434, IL_0444, IL_0454, IL_045f, IL_046c, IL_0477, IL_0487, IL_0495, IL_04a3, IL_04b6, IL_04c4, IL_04de, IL_04ec, IL_04fa, IL_050d, IL_051b, IL_0529, IL_0537, IL_0545, IL_0553, IL_055c, IL_059c, IL_05b0, IL_05c3, IL_05db, IL_05ee, IL_0608, IL_0616, IL_0624, IL_0640, IL_0668, IL_0676, IL_067f, IL_068d, IL_06a5, IL_06c3, IL_06e7, IL_06ff, IL_0712, IL_0725, IL_0733, IL_074e, IL_0761, IL_0793, IL_07ac, IL_07ba, IL_07cd, IL_07e0, IL_07eb, IL_07fb, IL_0809, IL_0817, IL_082b, IL_0863, IL_0876, IL_08bd, IL_08d0, IL_08ec, IL_08fa, IL_0908, IL_0925, IL_0974, IL_097e, IL_09ab, IL_09bf, IL_09cd, IL_09e9, IL_09f7, IL_0a05, IL_0a23, IL_0a31, IL_0a44, IL_0a52, IL_0a5b, IL_0a69, IL_0a7d, IL_0ae0, IL_0aee, IL_0b01, IL_0b14, IL_0b22, IL_0b2d, IL_0b42, IL_0b55, IL_0b60, IL_0b73, IL_0b81, IL_0b8f, IL_0ba4, IL_0bb7, IL_0bc2, IL_0bd0, IL_0be5, IL_0bf8, IL_0c06, IL_0c14, IL_0c29, IL_0c3c, IL_0c65, IL_0c7e, IL_0ce1, IL_0cef, IL_0d02, IL_0d10, IL_0d1b, IL_0d29, IL_0d4c, IL_0d5a, IL_0d6d, IL_0d7b, IL_0d89, IL_0d9d, IL_0dfd, IL_0e14, IL_0e27, IL_0e35, IL_0e43, IL_0e85, IL_0ea1, IL_0eaf, IL_0eba, IL_0ed3, IL_0ee6, IL_0ef4, IL_0eff, IL_0f0d, IL_0f30, IL_0f3e, IL_0f4e, IL_0f59, IL_0f64, IL_0f7d, IL_0f92, IL_0fa0, IL_0fb3, IL_0fbd, IL_0fc8, IL_0fd8, IL_0fe8, IL_0ff8, IL_1008, IL_1018, IL_1031, IL_1052, IL_1059 are reachable both inside and outside the pinned region starting at IL_1046. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 116;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2;
					int num3;
					byte[] array2;
					object[] array3;
					int[] array4;
					long[] array5;
					object[] array6;
					byte* ptr;
					byte* num6;
					int num7;
					object[] array7;
					int num8;
					byte* num9;
					byte* ptr2;
					byte[] array = new byte[4];
					if (true)
					{
						while (true)
						{
							IL_1031:
							num2 = 1;
							while (true)
							{
								IL_1018:
								num3 = num2 * 4;
								num = 82;
								while (true)
								{
									IL_1008:
									array2 = new byte[8];
									while (true)
									{
										IL_0ff8:
										array3 = new object[8];
										while (true)
										{
											IL_0fe8:
											array4 = new int[8];
											while (true)
											{
												IL_0fd8:
												array5 = new long[8];
												while (true)
												{
													IL_0fc8:
													array6 = new object[35];
													while (true)
													{
														IL_0fbd:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IDLFLAGFRETVALUCOMIEnumString.CloseNumberListCodes);
														while (true)
														{
															IL_0fb3:
															ptr2 = ptr;
															while (true)
															{
																IL_0fa0:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0454:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0444:
																		ptr2++;
																		while (true)
																		{
																			IL_0434:
																			if (b >= 1)
																			{
																				while (b <= 26)
																				{
																					while (true)
																					{
																						IL_0417:
																						if (13 < b)
																						{
																							while (true)
																							{
																								IL_0407:
																								if (20 >= b)
																								{
																									while (true)
																									{
																										IL_03f7:
																										if (20 <= b)
																										{
																											num = 63;
																											while (true)
																											{
																												IL_03d8:
																												array2[num5 - 3] = 5;
																												num = 234;
																												while (true)
																												{
																													if (num != 234)
																													{
																														if (num != 1215)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 96:
																															break;
																														default:
																															continue;
																														case 63:
																														case 218:
																															goto IL_03d8;
																														case 123:
																															goto IL_03f7;
																														case 51:
																															goto IL_0407;
																														case 55:
																															goto IL_0417;
																														case 117:
																															goto IL_0424;
																														case 190:
																															goto IL_0434;
																														case 195:
																															goto IL_0444;
																														case 67:
																														case 225:
																															goto IL_0454;
																														case 87:
																															goto IL_045f;
																														case 107:
																															goto IL_046c;
																														case 89:
																															goto IL_0477;
																														case 109:
																															goto IL_0487;
																														case 33:
																														case 111:
																															goto IL_04a3;
																														case 120:
																															goto IL_04b6;
																														case 45:
																														case 68:
																															goto IL_04c4;
																														case 148:
																															goto IL_04de;
																														case 80:
																															goto IL_04ec;
																														case 131:
																															goto IL_04fa;
																														case 151:
																															goto IL_050d;
																														case 42:
																															goto IL_051b;
																														case 129:
																															goto IL_0529;
																														case 10:
																															goto IL_0537;
																														case 37:
																															goto IL_0545;
																														case 4:
																														case 124:
																															goto IL_055c;
																														case 1:
																															goto IL_059c;
																														case 17:
																															goto IL_05b0;
																														case 153:
																															goto IL_05c3;
																														case 39:
																															goto IL_05db;
																														case 25:
																														case 158:
																															goto IL_05ee;
																														case 78:
																															goto IL_0608;
																														case 126:
																															goto IL_0616;
																														case 59:
																															goto IL_0624;
																														case 52:
																														case 162:
																															goto IL_0640;
																														case 165:
																															goto IL_0668;
																														case 62:
																															goto IL_067f;
																														case 110:
																														case 122:
																															goto IL_068d;
																														case 90:
																															goto IL_06a5;
																														case 27:
																															goto IL_06c3;
																														case 164:
																															goto IL_06e7;
																														case 83:
																															goto IL_06ff;
																														case 173:
																															goto IL_0712;
																														case 175:
																															goto IL_0725;
																														case 18:
																														case 144:
																															goto IL_0733;
																														case 188:
																															goto IL_074e;
																														case 189:
																														case 197:
																															goto IL_0761;
																														case 167:
																															goto IL_0793;
																														case 199:
																															goto IL_07ac;
																														case 176:
																															goto IL_07ba;
																														case 203:
																															goto IL_07cd;
																														case 204:
																															goto IL_07e0;
																														case 193:
																															goto IL_07eb;
																														case 47:
																															goto IL_07fb;
																														case 186:
																															goto IL_0809;
																														case 99:
																														case 194:
																															goto IL_0817;
																														case 169:
																															goto end_IL_03c5;
																														case 9:
																															goto IL_0863;
																														case 145:
																														case 206:
																															goto IL_0876;
																														case 191:
																															goto IL_08bd;
																														case 210:
																															goto IL_08d0;
																														case 213:
																															goto IL_08ec;
																														case 196:
																															goto IL_08fa;
																														case 35:
																														case 121:
																															goto IL_0908;
																														case 30:
																															goto IL_09bf;
																														case 23:
																															goto IL_09cd;
																														case 102:
																															goto IL_09e9;
																														case 98:
																															goto IL_09f7;
																														case 58:
																														case 198:
																															goto IL_0a05;
																														case 178:
																															goto IL_0a23;
																														case 5:
																															goto IL_0a31;
																														case 214:
																															goto IL_0a44;
																														case 28:
																															goto IL_0a5b;
																														case 19:
																														case 127:
																															goto IL_0a69;
																														case 40:
																															goto IL_0a7d;
																														case 75:
																															goto IL_0ae0;
																														case 182:
																															goto IL_0aee;
																														case 216:
																															goto IL_0b01;
																														case 221:
																															goto IL_0b14;
																														case 92:
																															goto IL_0b22;
																														case 24:
																														case 86:
																															goto IL_0b2d;
																														case 133:
																															goto IL_0b42;
																														case 31:
																															goto IL_0b55;
																														case 174:
																															goto IL_0b60;
																														case 12:
																															goto IL_0b73;
																														case 207:
																															goto IL_0b81;
																														case 14:
																														case 141:
																															goto IL_0b8f;
																														case 91:
																															goto IL_0ba4;
																														case 183:
																															goto IL_0bb7;
																														case 29:
																															goto IL_0bc2;
																														case 21:
																														case 93:
																															goto IL_0bd0;
																														case 13:
																															goto IL_0be5;
																														case 160:
																															goto IL_0bf8;
																														case 202:
																															goto IL_0c06;
																														case 11:
																														case 180:
																															goto IL_0c14;
																														case 135:
																															goto IL_0c29;
																														case 136:
																														case 224:
																															goto IL_0c3c;
																														case 205:
																															goto IL_0c65;
																														case 166:
																															goto IL_0ce1;
																														case 38:
																															goto IL_0cef;
																														case 220:
																															goto IL_0d02;
																														case 49:
																															goto IL_0d10;
																														case 32:
																														case 172:
																															goto IL_0d1b;
																														case 16:
																															goto IL_0d29;
																														case 181:
																															goto IL_0d4c;
																														case 41:
																															goto IL_0d5a;
																														case 118:
																															goto IL_0d6d;
																														case 69:
																															goto IL_0d7b;
																														case 105:
																														case 119:
																															goto IL_0d89;
																														case 64:
																															goto IL_0d9d;
																														case 77:
																															goto IL_0dfd;
																														case 104:
																															goto IL_0e14;
																														case 112:
																															goto IL_0e27;
																														case 26:
																															goto IL_0e35;
																														case 100:
																														case 154:
																															goto IL_0e43;
																														case 157:
																															goto IL_0e85;
																														case 34:
																															goto IL_0ea1;
																														case 185:
																															goto IL_0eaf;
																														case 50:
																														case 84:
																															goto IL_0eba;
																														case 88:
																															goto IL_0ed3;
																														case 79:
																															goto IL_0ee6;
																														case 139:
																															goto IL_0ef4;
																														case 57:
																														case 101:
																															goto IL_0eff;
																														case 187:
																															goto IL_0f0d;
																														case 168:
																															goto IL_0f30;
																														case 159:
																															goto IL_0f3e;
																														case 70:
																															goto IL_0f4e;
																														case 76:
																															goto IL_0f59;
																														case 20:
																														case 156:
																															goto IL_0f64;
																														case 6:
																														case 15:
																														case 43:
																														case 53:
																														case 66:
																														case 71:
																														case 72:
																														case 74:
																														case 81:
																														case 106:
																														case 108:
																														case 113:
																														case 114:
																														case 130:
																														case 132:
																														case 134:
																														case 137:
																														case 138:
																														case 143:
																														case 149:
																														case 155:
																														case 170:
																														case 179:
																														case 184:
																														case 209:
																														case 211:
																														case 215:
																														case 219:
																														case 222:
																															goto end_IL_0424;
																														case 140:
																															goto IL_0f92;
																														case 2:
																														case 3:
																														case 8:
																														case 44:
																														case 46:
																														case 48:
																														case 54:
																														case 60:
																														case 65:
																														case 73:
																														case 85:
																														case 103:
																														case 125:
																														case 128:
																														case 146:
																														case 147:
																														case 150:
																														case 152:
																														case 163:
																														case 171:
																														case 177:
																														case 192:
																														case 201:
																														case 208:
																														case 212:
																														case 217:
																														case 223:
																														case 226:
																															goto IL_0fa0;
																														case 200:
																															goto IL_0fb3;
																														case 142:
																															goto IL_0fbd;
																														case 94:
																															goto IL_0fc8;
																														case 36:
																															goto IL_0fd8;
																														case 97:
																															goto IL_0fe8;
																														case 161:
																															goto IL_0ff8;
																														case 82:
																														case 95:
																															goto IL_1008;
																														case 56:
																															goto IL_1018;
																														case 61:
																															goto IL_1031;
																														case 0:
																															break;
																														case 7:
																															break;
																														case 115:
																															Class300.smethod_0();
																															break;
																														case 116:
																															Class296.Aw4EYyy3h();
																															goto case 115;
																														case 22:
																														case 227:
																															return;
																														}
																														goto end_IL_03f7;
																													}
																													array3[num5 - 3] = ((delegate*<float, float, float, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																													goto IL_0ce1;
																													IL_0ce1:
																													num5 -= 2;
																													goto IL_0cef;
																													IL_0cef:
																													ptr2 += 8;
																													goto IL_0fa0;
																													continue;
																													end_IL_03c5:
																													break;
																												}
																												break;
																											}
																											goto IL_082b;
																										}
																										goto IL_045f;
																										IL_0a69:
																										array2[num5 - 3] = 5;
																										goto IL_0a7d;
																										IL_0a7d:
																										array3[num5 - 3] = ((delegate*<float, float, float, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																										goto IL_0ae0;
																										IL_045f:
																										if (16 >= b)
																										{
																											goto IL_0487;
																										}
																										goto IL_04de;
																										IL_0487:
																										if (16 <= b)
																										{
																											num = 162;
																											goto IL_0640;
																										}
																										goto IL_07e0;
																										IL_0ae0:
																										num5 -= 2;
																										goto IL_0aee;
																										IL_0640:
																										int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																										num = 188;
																										goto IL_074e;
																										IL_074e:
																										num5--;
																										goto IL_0fa0;
																										IL_07e0:
																										if (14 >= b)
																										{
																											goto IL_07eb;
																										}
																										goto IL_07fb;
																										IL_07eb:
																										if (14 > b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0876;
																										IL_0876:
																										((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																										num = 191;
																										goto IL_08bd;
																										IL_08bd:
																										num5 -= 3;
																										goto IL_0fa0;
																										IL_07fb:
																										if (15 < b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0809;
																										IL_0809:
																										if (15 > b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0817;
																										IL_0817:
																										array2[num5 - 1] = 5;
																										goto IL_082b;
																										IL_082b:
																										array3[num5 - 1] = ((delegate*<string[], string>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																										goto IL_0863;
																										IL_0863:
																										ptr2 += 8;
																										goto IL_0fa0;
																										IL_04de:
																										if (18 >= b)
																										{
																											goto IL_04ec;
																										}
																										goto IL_0a44;
																										IL_04ec:
																										if (18 > b)
																										{
																											goto IL_04fa;
																										}
																										goto IL_05ee;
																										IL_04fa:
																										if (17 < b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0712;
																										IL_0712:
																										if (17 > b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0c3c;
																										IL_0c3c:
																										array3[num5 - 1] = new ColorOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																										goto IL_0c65;
																										IL_0c65:
																										array2[num5 - 1] = 5;
																										goto IL_0fa0;
																										IL_05ee:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																										goto IL_0608;
																										IL_0608:
																										array2[num5] = 3;
																										goto IL_0616;
																										IL_0616:
																										num5++;
																										goto IL_0624;
																										IL_0624:
																										ptr2 += 8;
																										num = 44;
																										goto IL_0fa0;
																										IL_0a44:
																										if (19 < b)
																										{
																											goto end_IL_0424;
																										}
																										num = 28;
																										goto IL_0a5b;
																										IL_0aee:
																										ptr2 += 8;
																										goto IL_0fa0;
																										IL_0a5b:
																										if (19 > b)
																										{
																											goto end_IL_0424;
																										}
																										goto IL_0a69;
																										continue;
																										end_IL_03f7:
																										break;
																									}
																									break;
																								}
																								goto IL_0d02;
																								IL_0f64:
																								num6 = ptr2;
																								num7 = -200;
																								num4 = 1;
																								ptr2 = num6 + num7;
																								goto IL_0fa0;
																								IL_0d02:
																								if (23 >= b)
																								{
																									goto IL_0d10;
																								}
																								goto IL_0ea1;
																								IL_0d10:
																								if (23 <= b)
																								{
																									goto IL_0d1b;
																								}
																								goto IL_0d6d;
																								IL_0d1b:
																								array2[num5] = 4;
																								goto IL_0d29;
																								IL_0d29:
																								array3[num5] = ((delegate*<Color>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																								goto IL_0d4c;
																								IL_0d4c:
																								num5++;
																								goto IL_0d5a;
																								IL_0d5a:
																								ptr2 += 8;
																								goto IL_0fa0;
																								IL_0d6d:
																								if (21 >= b)
																								{
																									goto IL_0d7b;
																								}
																								goto IL_0e27;
																								IL_0d7b:
																								if (21 > b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0d89;
																								IL_0d89:
																								array2[num5 - 3] = 5;
																								goto IL_0d9d;
																								IL_0d9d:
																								array3[num5 - 3] = ((delegate*<string, Color, Color, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((string)array3[num5 - 3], (Color)array3[num5 - 2], (Color)array3[num5 - 1]);
																								goto IL_0dfd;
																								IL_0dfd:
																								num5 -= 2;
																								num = 104;
																								goto IL_0e14;
																								IL_0e14:
																								ptr2 += 8;
																								goto IL_0fa0;
																								IL_0e27:
																								if (22 < b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0e35;
																								IL_0e35:
																								if (22 > b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0e43;
																								IL_0e43:
																								((ColorOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (ColorOption)array3[num5 - 1];
																								goto IL_0e85;
																								IL_0e85:
																								num5 -= 3;
																								num = 54;
																								goto IL_0fa0;
																								IL_0ea1:
																								if (25 >= b)
																								{
																									goto IL_0eaf;
																								}
																								goto IL_0f4e;
																								IL_0eaf:
																								if (25 <= b)
																								{
																									goto IL_0eba;
																								}
																								goto IL_0ee6;
																								IL_0eba:
																								colorOption_0 = (ColorOption[])array3[num5 - 1];
																								goto IL_0ed3;
																								IL_0ed3:
																								num5--;
																								goto IL_0fa0;
																								IL_0ee6:
																								if (24 < b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0ef4;
																								IL_0ef4:
																								if (24 > b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0eff;
																								IL_0eff:
																								array2[num5] = 4;
																								goto IL_0f0d;
																								IL_0f0d:
																								array3[num5] = ((delegate*<Color>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																								goto IL_0f30;
																								IL_0f30:
																								num5++;
																								goto IL_0f3e;
																								IL_0f3e:
																								ptr2 += 8;
																								goto IL_0fa0;
																								IL_0f4e:
																								if (26 < b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0f59;
																								IL_0f59:
																								if (26 > b)
																								{
																									goto end_IL_0424;
																								}
																								goto IL_0f64;
																							}
																							break;
																						}
																						goto IL_046c;
																						IL_0a23:
																						ptr2 += 8;
																						goto IL_0a31;
																						IL_046c:
																						if (13 > b)
																						{
																							goto IL_0477;
																						}
																						goto IL_04a3;
																						IL_0477:
																						if (6 >= b)
																						{
																							goto IL_04b6;
																						}
																						goto IL_050d;
																						IL_04b6:
																						if (6 <= b)
																						{
																							goto IL_04c4;
																						}
																						goto IL_0b14;
																						IL_04c4:
																						((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																						goto IL_0b01;
																						IL_0b01:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_0b14:
																						if (3 >= b)
																						{
																							goto IL_0b22;
																						}
																						goto IL_0bb7;
																						IL_0b22:
																						if (3 <= b)
																						{
																							goto IL_0b2d;
																						}
																						goto IL_0b55;
																						IL_0b2d:
																						((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																						goto IL_0b42;
																						IL_0b42:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_0b55:
																						if (1 >= b)
																						{
																							goto IL_0b60;
																						}
																						goto IL_0b73;
																						IL_0b60:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0424;
																						IL_0b73:
																						if (2 < b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0b81;
																						IL_0b81:
																						if (2 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0b8f;
																						IL_0b8f:
																						((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																						goto IL_0ba4;
																						IL_0ba4:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_0bb7:
																						if (4 >= b)
																						{
																							goto IL_0bc2;
																						}
																						goto IL_0bf8;
																						IL_0bc2:
																						if (4 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0bd0;
																						IL_0bd0:
																						((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																						goto IL_0be5;
																						IL_0be5:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_0bf8:
																						if (5 < b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0c06;
																						IL_0c06:
																						if (5 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0c14;
																						IL_0c14:
																						((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																						goto IL_0c29;
																						IL_0c29:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_050d:
																						if (9 < b)
																						{
																							goto IL_051b;
																						}
																						goto IL_0725;
																						IL_051b:
																						if (11 >= b)
																						{
																							goto IL_0529;
																						}
																						goto IL_0668;
																						IL_0529:
																						if (11 > b)
																						{
																							goto IL_0537;
																						}
																						goto IL_0761;
																						IL_0537:
																						if (10 < b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0545;
																						IL_0545:
																						if (10 > b)
																						{
																							goto end_IL_0424;
																						}
																						num = 4;
																						goto IL_055c;
																						IL_0a31:
																						num5--;
																						goto IL_0fa0;
																						IL_055c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																						goto IL_059c;
																						IL_059c:
																						array2[num5 - 2] = 0;
																						goto IL_05b0;
																						IL_05b0:
																						num5--;
																						goto IL_0fa0;
																						IL_0761:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																						num = 167;
																						goto IL_0793;
																						IL_0793:
																						array2[num5 - 1] = 5;
																						goto IL_0fa0;
																						IL_0668:
																						if (12 < b)
																						{
																							goto end_IL_0424;
																						}
																						num = 62;
																						goto IL_067f;
																						IL_04a3:
																						array2[num5] = 5;
																						goto IL_05c3;
																						IL_067f:
																						if (12 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_068d;
																						IL_068d:
																						array2[num5] = array2[num5 - 1];
																						goto IL_06a5;
																						IL_06a5:
																						array4[num5 - 0] = array4[num5 - 1];
																						goto IL_06c3;
																						IL_06c3:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																						goto IL_06e7;
																						IL_06e7:
																						array3[num5] = array3[num5 - 1];
																						goto IL_06ff;
																						IL_06ff:
																						num5++;
																						goto IL_0fa0;
																						IL_0725:
																						if (9 <= b)
																						{
																							goto IL_0733;
																						}
																						goto IL_08ec;
																						IL_0733:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																						goto IL_07ac;
																						IL_07ac:
																						array2[num5] = 0;
																						goto IL_07ba;
																						IL_07ba:
																						num5++;
																						goto IL_08d0;
																						IL_08d0:
																						ptr2 += 8;
																						num = 46;
																						goto IL_0fa0;
																						IL_08ec:
																						if (7 >= b)
																						{
																							goto IL_08fa;
																						}
																						goto IL_09e9;
																						IL_08fa:
																						if (7 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0908;
																						IL_0908:
																						array7 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_0917;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_09bf;
																						IL_05c3:
																						array3[num5] = array6[*(int*)(ptr2 + num3)];
																						goto IL_05db;
																						IL_05db:
																						num5++;
																						goto IL_07cd;
																						IL_07cd:
																						ptr2 += 8;
																						goto IL_0fa0;
																						IL_09bf:
																						array2[num5] = 5;
																						goto IL_09cd;
																						IL_09cd:
																						num5++;
																						num = 212;
																						goto IL_0fa0;
																						IL_09e9:
																						if (8 < b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_09f7;
																						IL_09f7:
																						if (8 > b)
																						{
																							goto end_IL_0424;
																						}
																						goto IL_0a05;
																						IL_0a05:
																						array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0a23;
																					}
																					goto end_IL_0434;
																					continue;
																					end_IL_0424:
																					break;
																					IL_0424:;
																				}
																			}
																			((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																			goto IL_0f92;
																			IL_0f92:
																			ptr2 += 8;
																			goto IL_0fa0;
																			continue;
																			end_IL_0434:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
					}
					continue;
					IL_0917:
					while (true)
					{
						IL_0917_2:
						array = new byte[4];
						while (true)
						{
							num9 = ptr2;
							byte b2 = *num9;
							ptr2 = num9 + 4;
							int num10 = *(int*)(ptr2 + num3);
							ptr2 += 8;
							byte* ptr3 = ptr2 + num10;
							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
							while (ptr2 != ptr3)
							{
								*ptr4 = (byte)(*ptr2 ^ b2);
								ptr2++;
								ptr4++;
							}
							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
							while (true)
							{
								IL_09bf_2:
								array2[num5] = 5;
								while (true)
								{
									IL_09cd_2:
									num5++;
									num = 212;
									while (true)
									{
										IL_0fa0_2:
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0434_2:
													if (b >= 1)
													{
														while (b <= 26)
														{
															while (true)
															{
																if (13 < b)
																{
																	while (true)
																	{
																		if (20 >= b)
																		{
																			while (true)
																			{
																				IL_03f7_2:
																				if (20 <= b)
																				{
																					num = 63;
																					while (true)
																					{
																						IL_03d8_2:
																						array2[num5 - 3] = 5;
																						num = 234;
																						while (true)
																						{
																							if (num != 234)
																							{
																								if (num != 1215)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 63:
																								case 218:
																									goto IL_03d8_2;
																								case 123:
																									goto IL_03f7_2;
																								case 51:
																									goto end_IL_03f7_2;
																								case 55:
																									goto end_IL_0407;
																								case 117:
																									goto end_IL_0417;
																								case 190:
																									goto IL_0434_2;
																								case 195:
																									goto end_IL_0434_2;
																								case 67:
																								case 225:
																									goto end_IL_0444;
																								case 87:
																									goto IL_045f_2;
																								case 107:
																									goto IL_046c_2;
																								case 89:
																									goto IL_0477_2;
																								case 109:
																									goto IL_0487_2;
																								case 33:
																								case 111:
																									goto IL_04a3_2;
																								case 120:
																									goto IL_04b6_2;
																								case 45:
																								case 68:
																									goto IL_04c4_2;
																								case 148:
																									goto IL_04de_2;
																								case 80:
																									goto IL_04ec_2;
																								case 131:
																									goto IL_04fa_2;
																								case 151:
																									goto IL_050d_2;
																								case 42:
																									goto IL_051b_2;
																								case 129:
																									goto IL_0529_2;
																								case 10:
																									goto IL_0537_2;
																								case 37:
																									goto IL_0545_2;
																								case 4:
																								case 124:
																									goto IL_055c_2;
																								case 1:
																									goto IL_059c_2;
																								case 17:
																									goto IL_05b0_2;
																								case 153:
																									goto IL_05c3_2;
																								case 39:
																									goto IL_05db_2;
																								case 25:
																								case 158:
																									goto IL_05ee_2;
																								case 78:
																									goto IL_0608_2;
																								case 126:
																									goto IL_0616_2;
																								case 59:
																									goto IL_0624_2;
																								case 52:
																								case 162:
																									goto IL_0640_2;
																								case 165:
																									goto IL_0668_2;
																								case 62:
																									goto IL_067f_2;
																								case 110:
																								case 122:
																									goto IL_068d_2;
																								case 90:
																									goto IL_06a5_2;
																								case 27:
																									goto IL_06c3_2;
																								case 164:
																									goto IL_06e7_2;
																								case 83:
																									goto IL_06ff_2;
																								case 173:
																									goto IL_0712_2;
																								case 175:
																									goto IL_0725_2;
																								case 18:
																								case 144:
																									goto IL_0733_2;
																								case 188:
																									goto IL_074e_2;
																								case 189:
																								case 197:
																									goto IL_0761_2;
																								case 167:
																									goto IL_0793_2;
																								case 199:
																									goto IL_07ac_2;
																								case 176:
																									goto IL_07ba_2;
																								case 203:
																									goto IL_07cd_2;
																								case 204:
																									goto IL_07e0_2;
																								case 193:
																									goto IL_07eb_2;
																								case 47:
																									goto IL_07fb_2;
																								case 186:
																									goto IL_0809_2;
																								case 99:
																								case 194:
																									goto IL_0817_2;
																								case 169:
																									goto end_IL_03c5_2;
																								case 9:
																									goto IL_0863_2;
																								case 145:
																								case 206:
																									goto IL_0876_2;
																								case 191:
																									goto IL_08bd_2;
																								case 210:
																									goto IL_08d0_2;
																								case 213:
																									goto IL_08ec_2;
																								case 196:
																									goto IL_08fa_2;
																								case 35:
																								case 121:
																									goto end_IL_0454;
																								case 30:
																									goto IL_09bf_2;
																								case 23:
																									goto IL_09cd_2;
																								case 102:
																									goto IL_09e9_2;
																								case 98:
																									goto IL_09f7_2;
																								case 58:
																								case 198:
																									goto IL_0a05_2;
																								case 178:
																									goto IL_0a23_2;
																								case 5:
																									goto IL_0a31_2;
																								case 214:
																									goto IL_0a44_2;
																								case 28:
																									goto IL_0a5b_2;
																								case 19:
																								case 127:
																									goto IL_0a69_2;
																								case 40:
																									goto IL_0a7d_2;
																								case 75:
																									goto IL_0ae0_2;
																								case 182:
																									goto IL_0aee_2;
																								case 216:
																									goto IL_0b01_2;
																								case 221:
																									goto IL_0b14_2;
																								case 92:
																									goto IL_0b22_2;
																								case 24:
																								case 86:
																									goto IL_0b2d_2;
																								case 133:
																									goto IL_0b42_2;
																								case 31:
																									goto IL_0b55_2;
																								case 174:
																									goto IL_0b60_2;
																								case 12:
																									goto IL_0b73_2;
																								case 207:
																									goto IL_0b81_2;
																								case 14:
																								case 141:
																									goto IL_0b8f_2;
																								case 91:
																									goto IL_0ba4_2;
																								case 183:
																									goto IL_0bb7_2;
																								case 29:
																									goto IL_0bc2_2;
																								case 21:
																								case 93:
																									goto IL_0bd0_2;
																								case 13:
																									goto IL_0be5_2;
																								case 160:
																									goto IL_0bf8_2;
																								case 202:
																									goto IL_0c06_2;
																								case 11:
																								case 180:
																									goto IL_0c14_2;
																								case 135:
																									goto IL_0c29_2;
																								case 136:
																								case 224:
																									goto IL_0c3c_2;
																								case 205:
																									goto IL_0c65_2;
																								case 166:
																									goto IL_0ce1_2;
																								case 38:
																									goto IL_0cef_2;
																								case 220:
																									goto IL_0d02_2;
																								case 49:
																									goto IL_0d10_2;
																								case 32:
																								case 172:
																									goto IL_0d1b_2;
																								case 16:
																									goto IL_0d29_2;
																								case 181:
																									goto IL_0d4c_2;
																								case 41:
																									goto IL_0d5a_2;
																								case 118:
																									goto IL_0d6d_2;
																								case 69:
																									goto IL_0d7b_2;
																								case 105:
																								case 119:
																									goto IL_0d89_2;
																								case 64:
																									goto IL_0d9d_2;
																								case 77:
																									goto IL_0dfd_2;
																								case 104:
																									goto IL_0e14_2;
																								case 112:
																									goto IL_0e27_2;
																								case 26:
																									goto IL_0e35_2;
																								case 100:
																								case 154:
																									goto IL_0e43_2;
																								case 157:
																									goto IL_0e85_2;
																								case 34:
																									goto IL_0ea1_2;
																								case 185:
																									goto IL_0eaf_2;
																								case 50:
																								case 84:
																									goto IL_0eba_2;
																								case 88:
																									goto IL_0ed3_2;
																								case 79:
																									goto IL_0ee6_2;
																								case 139:
																									goto IL_0ef4_2;
																								case 57:
																								case 101:
																									goto IL_0eff_2;
																								case 187:
																									goto IL_0f0d_2;
																								case 168:
																									goto IL_0f30_2;
																								case 159:
																									goto IL_0f3e_2;
																								case 70:
																									goto IL_0f4e_2;
																								case 76:
																									goto IL_0f59_2;
																								case 20:
																								case 156:
																									goto IL_0f64_2;
																								case 6:
																								case 15:
																								case 43:
																								case 53:
																								case 66:
																								case 71:
																								case 72:
																								case 74:
																								case 81:
																								case 106:
																								case 108:
																								case 113:
																								case 114:
																								case 130:
																								case 132:
																								case 134:
																								case 137:
																								case 138:
																								case 143:
																								case 149:
																								case 155:
																								case 170:
																								case 179:
																								case 184:
																								case 209:
																								case 211:
																								case 215:
																								case 219:
																								case 222:
																									goto end_IL_0424_2;
																								case 140:
																									goto IL_0f92_2;
																								case 2:
																								case 3:
																								case 8:
																								case 44:
																								case 46:
																								case 48:
																								case 54:
																								case 60:
																								case 65:
																								case 73:
																								case 85:
																								case 103:
																								case 125:
																								case 128:
																								case 146:
																								case 147:
																								case 150:
																								case 152:
																								case 163:
																								case 171:
																								case 177:
																								case 192:
																								case 201:
																								case 208:
																								case 212:
																								case 217:
																								case 223:
																								case 226:
																									goto IL_0fa0_2;
																								case 200:
																									ptr2 = ptr;
																									goto IL_0fa0_2;
																								case 142:
																									ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IDLFLAGFRETVALUCOMIEnumString.CloseNumberListCodes);
																									goto case 200;
																								case 94:
																									array6 = new object[35];
																									goto case 142;
																								case 36:
																									array5 = new long[8];
																									goto case 94;
																								case 97:
																									array4 = new int[8];
																									goto case 36;
																								case 161:
																									array3 = new object[8];
																									goto case 97;
																								case 82:
																								case 95:
																									array2 = new byte[8];
																									goto case 161;
																								case 56:
																									num3 = num2 * 4;
																									num = 82;
																									goto case 82;
																								case 61:
																									num2 = 1;
																									goto case 56;
																								case 0:
																								case 7:
																								case 96:
																									goto end_IL_0925;
																								case 115:
																									goto end_IL_103c;
																								case 116:
																									goto end_IL_1052;
																								case 22:
																								case 227:
																									return;
																								}
																								continue;
																							}
																							array3[num5 - 3] = ((delegate*<float, float, float, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																							goto IL_0ce1_2;
																							IL_0ce1_2:
																							num5 -= 2;
																							goto IL_0cef_2;
																							IL_0cef_2:
																							ptr2 += 8;
																							goto IL_0fa0_2;
																							continue;
																							end_IL_03c5_2:
																							break;
																						}
																						break;
																					}
																					goto IL_082b_2;
																				}
																				goto IL_045f_2;
																				IL_0a69_2:
																				array2[num5 - 3] = 5;
																				goto IL_0a7d_2;
																				IL_0a7d_2:
																				array3[num5 - 3] = ((delegate*<float, float, float, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])));
																				goto IL_0ae0_2;
																				IL_045f_2:
																				if (16 >= b)
																				{
																					goto IL_0487_2;
																				}
																				goto IL_04de_2;
																				IL_0487_2:
																				if (16 <= b)
																				{
																					num = 162;
																					goto IL_0640_2;
																				}
																				goto IL_07e0_2;
																				IL_0ae0_2:
																				num5 -= 2;
																				goto IL_0aee_2;
																				IL_0640_2:
																				int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																				num = 188;
																				goto IL_074e_2;
																				IL_074e_2:
																				num5--;
																				goto IL_0fa0_2;
																				IL_07e0_2:
																				if (14 >= b)
																				{
																					goto IL_07eb_2;
																				}
																				goto IL_07fb_2;
																				IL_07eb_2:
																				if (14 > b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0876_2;
																				IL_0876_2:
																				((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																				num = 191;
																				goto IL_08bd_2;
																				IL_08bd_2:
																				num5 -= 3;
																				goto IL_0fa0_2;
																				IL_07fb_2:
																				if (15 < b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0809_2;
																				IL_0809_2:
																				if (15 > b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0817_2;
																				IL_0817_2:
																				array2[num5 - 1] = 5;
																				goto IL_082b_2;
																				IL_082b_2:
																				array3[num5 - 1] = ((delegate*<string[], string>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																				goto IL_0863_2;
																				IL_0863_2:
																				ptr2 += 8;
																				goto IL_0fa0_2;
																				IL_04de_2:
																				if (18 >= b)
																				{
																					goto IL_04ec_2;
																				}
																				goto IL_0a44_2;
																				IL_04ec_2:
																				if (18 > b)
																				{
																					goto IL_04fa_2;
																				}
																				goto IL_05ee_2;
																				IL_04fa_2:
																				if (17 < b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0712_2;
																				IL_0712_2:
																				if (17 > b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0c3c_2;
																				IL_0c3c_2:
																				array3[num5 - 1] = new ColorOption[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																				goto IL_0c65_2;
																				IL_0c65_2:
																				array2[num5 - 1] = 5;
																				goto IL_0fa0_2;
																				IL_05ee_2:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(float*)(ptr2 + num3);
																				goto IL_0608_2;
																				IL_0608_2:
																				array2[num5] = 3;
																				goto IL_0616_2;
																				IL_0616_2:
																				num5++;
																				goto IL_0624_2;
																				IL_0624_2:
																				ptr2 += 8;
																				num = 44;
																				goto IL_0fa0_2;
																				IL_0a44_2:
																				if (19 < b)
																				{
																					goto end_IL_0424_2;
																				}
																				num = 28;
																				goto IL_0a5b_2;
																				IL_0aee_2:
																				ptr2 += 8;
																				goto IL_0fa0_2;
																				IL_0a5b_2:
																				if (19 > b)
																				{
																					goto end_IL_0424_2;
																				}
																				goto IL_0a69_2;
																				continue;
																				end_IL_03f7_2:
																				break;
																			}
																			continue;
																		}
																		goto IL_0d02_2;
																		IL_0f64_2:
																		num6 = ptr2;
																		num7 = -200;
																		num4 = 1;
																		ptr2 = num6 + num7;
																		goto IL_0fa0_2;
																		IL_0d02_2:
																		if (23 >= b)
																		{
																			goto IL_0d10_2;
																		}
																		goto IL_0ea1_2;
																		IL_0d10_2:
																		if (23 <= b)
																		{
																			goto IL_0d1b_2;
																		}
																		goto IL_0d6d_2;
																		IL_0d1b_2:
																		array2[num5] = 4;
																		goto IL_0d29_2;
																		IL_0d29_2:
																		array3[num5] = ((delegate*<Color>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																		goto IL_0d4c_2;
																		IL_0d4c_2:
																		num5++;
																		goto IL_0d5a_2;
																		IL_0d5a_2:
																		ptr2 += 8;
																		goto IL_0fa0_2;
																		IL_0d6d_2:
																		if (21 >= b)
																		{
																			goto IL_0d7b_2;
																		}
																		goto IL_0e27_2;
																		IL_0d7b_2:
																		if (21 > b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0d89_2;
																		IL_0d89_2:
																		array2[num5 - 3] = 5;
																		goto IL_0d9d_2;
																		IL_0d9d_2:
																		array3[num5 - 3] = ((delegate*<string, Color, Color, object>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])((string)array3[num5 - 3], (Color)array3[num5 - 2], (Color)array3[num5 - 1]);
																		goto IL_0dfd_2;
																		IL_0dfd_2:
																		num5 -= 2;
																		num = 104;
																		goto IL_0e14_2;
																		IL_0e14_2:
																		ptr2 += 8;
																		goto IL_0fa0_2;
																		IL_0e27_2:
																		if (22 < b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0e35_2;
																		IL_0e35_2:
																		if (22 > b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0e43_2;
																		IL_0e43_2:
																		((ColorOption[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (ColorOption)array3[num5 - 1];
																		goto IL_0e85_2;
																		IL_0e85_2:
																		num5 -= 3;
																		num = 54;
																		goto IL_0fa0_2;
																		IL_0ea1_2:
																		if (25 >= b)
																		{
																			goto IL_0eaf_2;
																		}
																		goto IL_0f4e_2;
																		IL_0eaf_2:
																		if (25 <= b)
																		{
																			goto IL_0eba_2;
																		}
																		goto IL_0ee6_2;
																		IL_0eba_2:
																		colorOption_0 = (ColorOption[])array3[num5 - 1];
																		goto IL_0ed3_2;
																		IL_0ed3_2:
																		num5--;
																		goto IL_0fa0_2;
																		IL_0ee6_2:
																		if (24 < b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0ef4_2;
																		IL_0ef4_2:
																		if (24 > b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0eff_2;
																		IL_0eff_2:
																		array2[num5] = 4;
																		goto IL_0f0d_2;
																		IL_0f0d_2:
																		array3[num5] = ((delegate*<Color>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																		goto IL_0f30_2;
																		IL_0f30_2:
																		num5++;
																		goto IL_0f3e_2;
																		IL_0f3e_2:
																		ptr2 += 8;
																		goto IL_0fa0_2;
																		IL_0f4e_2:
																		if (26 < b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0f59_2;
																		IL_0f59_2:
																		if (26 > b)
																		{
																			goto end_IL_0424_2;
																		}
																		goto IL_0f64_2;
																		continue;
																		end_IL_0407:
																		break;
																	}
																	continue;
																}
																goto IL_046c_2;
																IL_05c3_2:
																array3[num5] = array6[*(int*)(ptr2 + num3)];
																goto IL_05db_2;
																IL_046c_2:
																if (13 > b)
																{
																	goto IL_0477_2;
																}
																goto IL_04a3_2;
																IL_0477_2:
																if (6 >= b)
																{
																	goto IL_04b6_2;
																}
																goto IL_050d_2;
																IL_04b6_2:
																if (6 <= b)
																{
																	goto IL_04c4_2;
																}
																goto IL_0b14_2;
																IL_04c4_2:
																((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																goto IL_0b01_2;
																IL_0b01_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_0b14_2:
																if (3 >= b)
																{
																	goto IL_0b22_2;
																}
																goto IL_0bb7_2;
																IL_0b22_2:
																if (3 <= b)
																{
																	goto IL_0b2d_2;
																}
																goto IL_0b55_2;
																IL_0b2d_2:
																((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																goto IL_0b42_2;
																IL_0b42_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_0b55_2:
																if (1 >= b)
																{
																	goto IL_0b60_2;
																}
																goto IL_0b73_2;
																IL_0b60_2:
																if (1 > b)
																{
																}
																goto end_IL_0424_2;
																IL_0b73_2:
																if (2 < b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0b81_2;
																IL_0b81_2:
																if (2 > b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0b8f_2;
																IL_0b8f_2:
																((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																goto IL_0ba4_2;
																IL_0ba4_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_0bb7_2:
																if (4 >= b)
																{
																	goto IL_0bc2_2;
																}
																goto IL_0bf8_2;
																IL_0bc2_2:
																if (4 > b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0bd0_2;
																IL_0bd0_2:
																((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																goto IL_0be5_2;
																IL_0be5_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_0bf8_2:
																if (5 < b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0c06_2;
																IL_0c06_2:
																if (5 > b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0c14_2;
																IL_0c14_2:
																((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
																goto IL_0c29_2;
																IL_0c29_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_050d_2:
																if (9 < b)
																{
																	goto IL_051b_2;
																}
																goto IL_0725_2;
																IL_051b_2:
																if (11 >= b)
																{
																	goto IL_0529_2;
																}
																goto IL_0668_2;
																IL_0529_2:
																if (11 > b)
																{
																	goto IL_0537_2;
																}
																goto IL_0761_2;
																IL_0537_2:
																if (10 < b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0545_2;
																IL_0545_2:
																if (10 > b)
																{
																	goto end_IL_0424_2;
																}
																num = 4;
																goto IL_055c_2;
																IL_05db_2:
																num5++;
																goto IL_07cd_2;
																IL_055c_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																goto IL_059c_2;
																IL_059c_2:
																array2[num5 - 2] = 0;
																goto IL_05b0_2;
																IL_05b0_2:
																num5--;
																goto IL_0fa0_2;
																IL_0761_2:
																array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																num = 167;
																goto IL_0793_2;
																IL_0793_2:
																array2[num5 - 1] = 5;
																goto IL_0fa0_2;
																IL_0668_2:
																if (12 < b)
																{
																	goto end_IL_0424_2;
																}
																num = 62;
																goto IL_067f_2;
																IL_07cd_2:
																ptr2 += 8;
																goto IL_0fa0_2;
																IL_067f_2:
																if (12 > b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_068d_2;
																IL_068d_2:
																array2[num5] = array2[num5 - 1];
																goto IL_06a5_2;
																IL_06a5_2:
																array4[num5 - 0] = array4[num5 - 1];
																goto IL_06c3_2;
																IL_06c3_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																goto IL_06e7_2;
																IL_06e7_2:
																array3[num5] = array3[num5 - 1];
																goto IL_06ff_2;
																IL_06ff_2:
																num5++;
																goto IL_0fa0_2;
																IL_0725_2:
																if (9 <= b)
																{
																	goto IL_0733_2;
																}
																goto IL_08ec_2;
																IL_0733_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																goto IL_07ac_2;
																IL_07ac_2:
																array2[num5] = 0;
																goto IL_07ba_2;
																IL_07ba_2:
																num5++;
																goto IL_08d0_2;
																IL_08d0_2:
																ptr2 += 8;
																num = 46;
																goto IL_0fa0_2;
																IL_08ec_2:
																if (7 >= b)
																{
																	goto IL_08fa_2;
																}
																goto IL_09e9_2;
																IL_08fa_2:
																if (7 > b)
																{
																	goto end_IL_0424_2;
																}
																goto end_IL_0454;
																IL_09e9_2:
																if (8 < b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_09f7_2;
																IL_09f7_2:
																if (8 > b)
																{
																	goto end_IL_0424_2;
																}
																goto IL_0a05_2;
																IL_0a05_2:
																array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																goto IL_0a23_2;
																IL_0a23_2:
																ptr2 += 8;
																goto IL_0a31_2;
																IL_0a31_2:
																num5--;
																goto IL_0fa0_2;
																IL_04a3_2:
																array2[num5] = 5;
																goto IL_05c3_2;
																continue;
																end_IL_0417:
																break;
															}
															continue;
															end_IL_0424_2:
															break;
														}
													}
													((delegate*<void>)TokenizerShortBlockGCInduced[*(int*)(ptr2 + num3)])();
													goto IL_0f92_2;
													IL_0f92_2:
													ptr2 += 8;
													goto IL_0fa0_2;
													continue;
													end_IL_0434_2:
													break;
												}
												continue;
												end_IL_0444:
												break;
											}
											continue;
											end_IL_0454:
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							array7 = array3;
							num8 = num5;
							if (array == null)
							{
								goto IL_0917_2;
							}
							continue;
							end_IL_0925:
							break;
						}
						break;
					}
					continue;
					end_IL_103c:
					break;
				}
				continue;
				end_IL_1052:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DelayLoadClientChannelEntryHashElementTransformMetadata.getidFileStream);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0288:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0268:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0258:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (8 <= b)
																							{
																								while (true)
																								{
																									IL_01de:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									num = 111;
																									while (true)
																									{
																										if (num != 111)
																										{
																											if (num != 1092)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 44:
																											case 70:
																												goto IL_01de;
																											case 89:
																												goto IL_024b;
																											case 8:
																											case 83:
																												goto IL_0258;
																											case 100:
																												goto IL_0268;
																											case 90:
																												goto IL_0278;
																											case 94:
																												goto IL_0288;
																											case 6:
																												goto end_IL_0288;
																											case 87:
																											case 97:
																												goto end_IL_0298;
																											case 10:
																												goto IL_02b3;
																											case 13:
																												goto IL_02be;
																											case 2:
																											case 20:
																												goto IL_02ce;
																											case 36:
																											case 52:
																												goto IL_02de;
																											case 32:
																												goto IL_031e;
																											case 17:
																												goto IL_0332;
																											case 74:
																												goto IL_0345;
																											case 11:
																											case 84:
																												goto IL_0353;
																											case 26:
																												goto IL_0376;
																											case 9:
																												goto IL_0384;
																											case 68:
																												goto IL_039b;
																											case 92:
																											case 101:
																												goto IL_03c1;
																											case 45:
																											case 80:
																												goto IL_03cc;
																											case 25:
																												goto IL_03da;
																											case 50:
																												goto IL_03ed;
																											case 15:
																											case 66:
																												goto IL_03fb;
																											case 79:
																												goto IL_0417;
																											case 0:
																											case 48:
																												goto IL_0422;
																											case 4:
																												goto IL_0430;
																											case 59:
																												goto IL_0453;
																											case 99:
																												goto IL_045d;
																											case 104:
																												goto IL_046b;
																											case 21:
																												goto IL_047e;
																											case 29:
																											case 86:
																												goto IL_0489;
																											case 28:
																											case 65:
																												goto IL_0494;
																											case 30:
																												goto IL_04a2;
																											case 96:
																												goto IL_04b5;
																											case 33:
																											case 85:
																												goto IL_04c3;
																											case 76:
																												goto IL_04db;
																											case 71:
																											case 98:
																												goto IL_04e6;
																											case 16:
																												goto IL_04f4;
																											case 38:
																											case 51:
																												goto IL_0502;
																											case 56:
																												goto IL_051b;
																											case 3:
																												goto IL_0532;
																											case 37:
																												goto IL_0540;
																											case 1:
																											case 54:
																												goto IL_0550;
																											case 14:
																												goto IL_0582;
																											case 49:
																												goto IL_0590;
																											case 12:
																											case 18:
																											case 19:
																											case 22:
																											case 34:
																											case 39:
																											case 41:
																											case 42:
																											case 57:
																											case 58:
																											case 75:
																											case 77:
																											case 81:
																											case 88:
																											case 91:
																											case 93:
																											case 102:
																												goto end_IL_01cb;
																											case 5:
																											case 7:
																											case 24:
																											case 46:
																											case 47:
																											case 53:
																											case 62:
																											case 69:
																											case 72:
																											case 73:
																											case 78:
																											case 82:
																											case 95:
																												goto end_IL_02a8;
																											case 67:
																												goto end_IL_05b3;
																											case 27:
																												goto end_IL_05c6;
																											case 43:
																												goto end_IL_05d0;
																											case 35:
																												goto end_IL_05db;
																											case 40:
																											case 103:
																												goto end_IL_05f0;
																											case 55:
																												goto end_IL_0600;
																											case 31:
																											case 63:
																												goto end_IL_0610;
																											case 60:
																												goto end_IL_0620;
																											case 61:
																												goto end_IL_0630;
																											case 23:
																											case 64:
																												goto IL_064b;
																											}
																											continue;
																										}
																										num5 -= 2;
																										goto end_IL_02a8;
																										continue;
																										end_IL_01cb:
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02b3;
																							IL_039b:
																							ptr2 += 8;
																							goto end_IL_02a8;
																							IL_02b3:
																							if (6 >= b)
																							{
																								goto IL_02be;
																							}
																							goto IL_02ce;
																							IL_02be:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_02de;
																							IL_02de:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_031e;
																							IL_031e:
																							array[num5 - 2] = 0;
																							goto IL_0332;
																							IL_0332:
																							num5--;
																							goto end_IL_02a8;
																							IL_02ce:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0345;
																							IL_0345:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0353;
																							IL_0353:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0376;
																							IL_0376:
																							array[num5] = 0;
																							goto IL_0384;
																							IL_0384:
																							num5++;
																							num = 68;
																							goto IL_039b;
																						}
																						break;
																					}
																					goto IL_03c1;
																					IL_03fb:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02a8;
																					IL_03c1:
																					if (9 < b)
																					{
																						goto IL_03cc;
																					}
																					goto IL_03ed;
																					IL_03cc:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_03da;
																					IL_03da:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_03ed:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_03fb;
																				}
																				break;
																			}
																			goto IL_0417;
																			IL_0590:
																			num5--;
																			goto end_IL_02a8;
																			IL_0417:
																			if (5 <= b)
																			{
																				goto IL_0422;
																			}
																			goto IL_047e;
																			IL_0422:
																			array[num5] = 0;
																			goto IL_0430;
																			IL_0430:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0453;
																			IL_0453:
																			array2[num5] = null;
																			goto IL_045d;
																			IL_045d:
																			num5++;
																			goto IL_046b;
																			IL_046b:
																			ptr2 += 8;
																			goto end_IL_02a8;
																			IL_047e:
																			if (2 < b)
																			{
																				goto IL_0489;
																			}
																			goto IL_04db;
																			IL_0489:
																			if (3 < b)
																			{
																				goto IL_0494;
																			}
																			goto IL_04b5;
																			IL_0494:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_04a2;
																			IL_04a2:
																			if (4 <= b)
																			{
																				goto end_IL_02a8;
																			}
																			break;
																			IL_04b5:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_04c3;
																			IL_04c3:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02a8;
																			IL_04db:
																			if (2 > b)
																			{
																				goto IL_04e6;
																			}
																			goto IL_0550;
																			IL_04e6:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04f4;
																			IL_04f4:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0502;
																			IL_0502:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_051b;
																			IL_051b:
																			array[num5] = 0;
																			num = 3;
																			goto IL_0532;
																			IL_0532:
																			num5++;
																			goto IL_0540;
																			IL_0540:
																			ptr2 += 8;
																			goto end_IL_02a8;
																			IL_0550:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 14;
																			goto IL_0582;
																			IL_0582:
																			ptr2 += 8;
																			goto IL_0590;
																		}
																		break;
																		IL_0278:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a8;
																continue;
																end_IL_0288:
																break;
															}
															continue;
															end_IL_0298:
															break;
														}
														continue;
														end_IL_02a8:
														break;
													}
													continue;
												}
												goto IL_064b;
												IL_064b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b3:
												break;
											}
											continue;
											end_IL_05c6:
											break;
										}
										continue;
										end_IL_05d0:
										break;
									}
									continue;
									end_IL_05db:
									break;
								}
								continue;
								end_IL_05f0:
								break;
							}
							continue;
							end_IL_0600:
							break;
						}
						continue;
						end_IL_0610:
						break;
					}
					continue;
					end_IL_0620:
					break;
				}
				continue;
				end_IL_0630:
				break;
			}
		}
	}

	private static int smethod_2(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_1;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_3()
	{
		int num = 118;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 141;
					while (true)
					{
						object[] array2 = new object[4];
						num = 109;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 31;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeIdEventActivityOptions.ISTOREENUMFILESFLAGINCLUDEMISSINGFILESsetFallback);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0896:
												if (num4 == 1)
												{
													num = 159;
													while (true)
													{
														if (num != 159)
														{
															if (num == 1140)
															{
																switch (num)
																{
																case 44:
																case 66:
																	break;
																case 25:
																	goto IL_0017;
																case 27:
																	goto IL_0025;
																case 104:
																	goto IL_0033;
																case 10:
																	goto IL_0041;
																case 147:
																	goto IL_004f;
																case 14:
																case 69:
																	goto IL_005d;
																case 36:
																case 124:
																	goto IL_006b;
																case 103:
																	goto IL_0079;
																case 87:
																case 144:
																	goto IL_0084;
																case 9:
																	goto IL_0092;
																case 65:
																case 149:
																	goto IL_00a0;
																case 15:
																	goto IL_00ae;
																case 35:
																	goto IL_00c6;
																case 57:
																	goto IL_00d4;
																case 38:
																case 43:
																	goto IL_00e7;
																case 101:
																	goto IL_0126;
																case 11:
																	goto IL_0139;
																case 4:
																	goto IL_0150;
																case 54:
																case 94:
																	goto IL_015e;
																case 67:
																	goto IL_0187;
																case 99:
																	goto IL_0195;
																case 123:
																	goto IL_01a8;
																case 64:
																case 110:
																	goto IL_01b6;
																case 111:
																	goto IL_01c4;
																case 34:
																case 72:
																	goto IL_01cf;
																case 91:
																	goto IL_01dd;
																case 61:
																case 70:
																	goto IL_01eb;
																case 115:
																	goto IL_0204;
																case 92:
																	goto IL_0212;
																case 42:
																	goto IL_0220;
																case 88:
																case 125:
																	goto IL_0233;
																case 83:
																	goto IL_0273;
																case 17:
																	goto IL_0287;
																case 8:
																case 121:
																	goto IL_029a;
																case 16:
																	goto IL_02a8;
																case 74:
																case 134:
																	goto IL_02b6;
																case 75:
																	goto IL_02df;
																case 80:
																case 145:
																	goto IL_02f8;
																case 71:
																	goto IL_0316;
																case 55:
																	goto IL_0324;
																case 33:
																case 139:
																	goto IL_0337;
																case 29:
																	goto IL_034f;
																case 32:
																	goto IL_035d;
																case 30:
																case 151:
																	goto IL_036b;
																case 113:
																	goto IL_0379;
																case 26:
																case 62:
																	goto IL_0384;
																case 96:
																	goto IL_0392;
																case 20:
																case 107:
																	goto IL_03a5;
																case 68:
																	goto IL_03b3;
																case 84:
																	goto IL_03d6;
																case 63:
																	goto IL_03e0;
																case 18:
																	goto IL_03ee;
																case 53:
																	goto IL_0401;
																case 24:
																	goto IL_040f;
																case 77:
																case 95:
																	goto IL_041d;
																case 21:
																	goto IL_0461;
																case 82:
																	goto IL_0475;
																case 105:
																case 127:
																	goto IL_0491;
																case 78:
																	goto IL_04d1;
																case 0:
																	goto IL_04e5;
																case 49:
																	goto IL_04f8;
																case 7:
																	goto IL_0506;
																case 108:
																case 142:
																	goto IL_0514;
																case 102:
																	goto IL_0522;
																case 48:
																case 114:
																	goto IL_0530;
																case 140:
																	goto IL_0592;
																case 41:
																case 60:
																	goto IL_05a5;
																case 40:
																case 56:
																	goto IL_05ca;
																case 85:
																	goto IL_05d5;
																case 2:
																case 5:
																case 12:
																case 22:
																case 37:
																case 39:
																case 46:
																case 47:
																case 50:
																case 51:
																case 58:
																case 59:
																case 76:
																case 81:
																case 89:
																case 116:
																case 120:
																case 122:
																case 126:
																case 130:
																case 131:
																case 132:
																case 136:
																case 138:
																case 143:
																case 146:
																case 148:
																case 150:
																case 152:
																	goto IL_05e0;
																default:
																	continue;
																case 1:
																case 3:
																case 6:
																case 13:
																case 19:
																case 23:
																case 45:
																case 52:
																case 73:
																case 90:
																case 93:
																case 98:
																case 100:
																case 106:
																case 112:
																case 119:
																case 129:
																case 137:
																	goto IL_0896;
																case 133:
																	goto end_IL_0896;
																case 31:
																	goto end_IL_08a9;
																case 135:
																	goto end_IL_08b3;
																case 128:
																	goto end_IL_08be;
																case 86:
																case 109:
																	goto end_IL_08d7;
																case 141:
																	goto end_IL_08e7;
																case 28:
																case 97:
																	goto end_IL_08f7;
																case 117:
																	goto end_IL_0910;
																case 118:
																	goto end_IL_0929;
																case 79:
																	goto IL_0944;
																}
															}
															break;
														}
														goto IL_0944;
														IL_0944:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													}
												}
												b = *ptr2;
												goto IL_0017;
												IL_05e0:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_05ca:
												if (15 >= b)
												{
													goto IL_05d5;
												}
												goto IL_05e0;
												IL_05a5:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												goto IL_05e0;
												IL_0033:
												if (b <= 15)
												{
													goto IL_0041;
												}
												goto IL_05e0;
												IL_0041:
												if (8 >= b)
												{
													goto IL_004f;
												}
												goto IL_034f;
												IL_004f:
												if (8 > b)
												{
													goto IL_005d;
												}
												goto IL_0337;
												IL_005d:
												if (4 < b)
												{
													goto IL_006b;
												}
												goto IL_01a8;
												IL_006b:
												if (6 >= b)
												{
													goto IL_0079;
												}
												goto IL_0139;
												IL_0079:
												if (6 > b)
												{
													goto IL_0084;
												}
												goto IL_00e7;
												IL_0084:
												if (5 >= b)
												{
													goto IL_0092;
												}
												goto IL_05e0;
												IL_0092:
												if (5 <= b)
												{
													goto IL_00a0;
												}
												goto IL_05e0;
												IL_00a0:
												array[num5] = 5;
												goto IL_00ae;
												IL_00ae:
												array2[num5] = array5[*(int*)(ptr2 + num3)];
												goto IL_00c6;
												IL_00c6:
												num5++;
												goto IL_00d4;
												IL_00d4:
												ptr2 += 8;
												continue;
												IL_00e7:
												((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0126;
												IL_0126:
												num5 -= 3;
												continue;
												IL_0139:
												if (7 >= b)
												{
													num = 4;
													goto IL_0150;
												}
												goto IL_05e0;
												IL_05d5:
												if (15 <= b)
												{
												}
												goto IL_05e0;
												IL_0150:
												if (7 <= b)
												{
													goto IL_015e;
												}
												goto IL_05e0;
												IL_015e:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0187;
												IL_0187:
												ptr2 += 8;
												goto IL_0195;
												IL_0195:
												num5--;
												continue;
												IL_01a8:
												if (4 > b)
												{
													goto IL_01b6;
												}
												goto IL_02f8;
												IL_01b6:
												if (2 >= b)
												{
													goto IL_01c4;
												}
												goto IL_029a;
												IL_01c4:
												if (2 > b)
												{
													goto IL_01cf;
												}
												goto IL_0233;
												IL_01cf:
												if (1 >= b)
												{
													goto IL_01dd;
												}
												goto IL_05e0;
												IL_01dd:
												if (1 <= b)
												{
													goto IL_01eb;
												}
												goto IL_05e0;
												IL_01eb:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_0204;
												IL_0204:
												array[num5] = 0;
												goto IL_0212;
												IL_0212:
												num5++;
												goto IL_0220;
												IL_0220:
												ptr2 += 8;
												continue;
												IL_0233:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0273;
												IL_0273:
												array[num5 - 2] = 0;
												goto IL_0287;
												IL_0287:
												num5--;
												continue;
												IL_029a:
												if (3 >= b)
												{
													goto IL_02a8;
												}
												goto IL_05e0;
												IL_02a8:
												if (3 <= b)
												{
													goto IL_02b6;
												}
												goto IL_05e0;
												IL_02b6:
												array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
												goto IL_02df;
												IL_02df:
												array[num5 - 1] = 5;
												continue;
												IL_02f8:
												array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
												goto IL_0316;
												IL_0316:
												ptr2 += 8;
												goto IL_0324;
												IL_0324:
												num5--;
												continue;
												IL_0337:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_034f:
												if (12 >= b)
												{
													goto IL_035d;
												}
												goto IL_04f8;
												IL_035d:
												if (12 > b)
												{
													goto IL_036b;
												}
												goto IL_0491;
												IL_036b:
												if (10 >= b)
												{
													goto IL_0379;
												}
												goto IL_0401;
												IL_0379:
												if (10 > b)
												{
													goto IL_0384;
												}
												goto IL_03a5;
												IL_0384:
												if (9 >= b)
												{
													goto IL_0392;
												}
												goto IL_05e0;
												IL_0392:
												if (9 <= b)
												{
													continue;
												}
												goto IL_05e0;
												IL_03a5:
												array[num5] = 0;
												goto IL_03b3;
												IL_03b3:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_03d6;
												IL_03d6:
												array2[num5] = null;
												goto IL_03e0;
												IL_03e0:
												num5++;
												goto IL_03ee;
												IL_03ee:
												ptr2 += 8;
												continue;
												IL_0401:
												if (11 >= b)
												{
													goto IL_040f;
												}
												goto IL_05e0;
												IL_040f:
												if (11 <= b)
												{
													goto IL_041d;
												}
												goto IL_05e0;
												IL_041d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
												goto IL_0461;
												IL_0461:
												array[num5 - 2] = 0;
												goto IL_0475;
												IL_0475:
												num5--;
												num = 129;
												continue;
												IL_0491:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_04d1;
												IL_04d1:
												array[num5 - 2] = 0;
												goto IL_04e5;
												IL_04e5:
												num5--;
												continue;
												IL_04f8:
												if (14 >= b)
												{
													goto IL_0506;
												}
												num = 56;
												goto IL_05ca;
												IL_0506:
												if (14 > b)
												{
													goto IL_0514;
												}
												goto IL_05a5;
												IL_0514:
												if (13 >= b)
												{
													goto IL_0522;
												}
												goto IL_05e0;
												IL_0522:
												if (13 <= b)
												{
													goto IL_0530;
												}
												goto IL_05e0;
												IL_0530:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0592;
												IL_0592:
												num5 -= 2;
												continue;
												end_IL_0896:
												break;
											}
											continue;
											end_IL_08a9:
											break;
										}
										continue;
										end_IL_08b3:
										break;
									}
									continue;
									end_IL_08be:
									break;
								}
								continue;
								end_IL_08d7:
								break;
							}
							continue;
							end_IL_08e7:
							break;
						}
						continue;
						end_IL_08f7:
						break;
					}
					continue;
					end_IL_0910:
					break;
				}
				continue;
				end_IL_0929:
				break;
			}
		}
	}

	private unsafe static int smethod_4()
	{
		int num = 89;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 95;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 85;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetUnderlyingTypeInlinePhi.OSVersionISafeSerializationData);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 50;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_034d:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				if (8 < b)
																				{
																					while (true)
																					{
																						if (12 >= b)
																						{
																							while (true)
																							{
																								if (12 > b)
																								{
																									while (true)
																									{
																										if (10 >= b)
																										{
																											while (true)
																											{
																												if (10 <= b)
																												{
																													while (true)
																													{
																														array[num5] = 0;
																														while (true)
																														{
																															IL_02bb:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_02af:
																																array2[num5] = null;
																																while (true)
																																{
																																	IL_0296:
																																	num5++;
																																	num = 157;
																																	while (true)
																																	{
																																		if (num != 157)
																																		{
																																			if (num != 1138)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 36:
																																				goto IL_0296;
																																			case 39:
																																				goto IL_02af;
																																			case 146:
																																				goto IL_02bb;
																																			case 84:
																																			case 108:
																																				goto end_IL_0283;
																																			case 147:
																																				goto end_IL_02e0;
																																			case 28:
																																			case 34:
																																				goto end_IL_02f0;
																																			case 46:
																																				goto end_IL_02fd;
																																			case 64:
																																				goto end_IL_030d;
																																			case 4:
																																				goto end_IL_031d;
																																			case 23:
																																				goto end_IL_032d;
																																			case 9:
																																				goto IL_034d;
																																			case 33:
																																				goto end_IL_034d;
																																			case 24:
																																			case 123:
																																				goto end_IL_035d;
																																			case 32:
																																			case 66:
																																				goto IL_0378;
																																			case 7:
																																				goto IL_0386;
																																			case 35:
																																			case 105:
																																				goto IL_0399;
																																			case 103:
																																				goto IL_03a7;
																																			case 3:
																																			case 13:
																																				goto IL_03b5;
																																			case 138:
																																				goto IL_03fe;
																																			case 14:
																																			case 56:
																																				goto IL_040c;
																																			case 1:
																																			case 126:
																																				goto IL_041a;
																																			case 10:
																																				goto IL_0425;
																																			case 48:
																																			case 87:
																																				goto IL_0430;
																																			case 58:
																																			case 113:
																																				goto IL_0443;
																																			case 82:
																																				goto IL_048b;
																																			case 86:
																																				goto IL_049e;
																																			case 12:
																																				goto IL_04ac;
																																			case 127:
																																			case 137:
																																				goto IL_04ba;
																																			case 27:
																																				goto IL_04e3;
																																			case 47:
																																				goto IL_04f1;
																																			case 44:
																																				goto IL_0504;
																																			case 77:
																																			case 91:
																																				goto IL_0512;
																																			case 107:
																																				goto IL_0520;
																																			case 26:
																																			case 98:
																																				goto IL_052b;
																																			case 60:
																																				goto IL_0539;
																																			case 11:
																																			case 125:
																																				goto IL_0547;
																																			case 74:
																																				goto IL_0560;
																																			case 54:
																																				goto IL_056e;
																																			case 79:
																																				goto IL_057c;
																																			case 92:
																																			case 124:
																																				goto IL_058f;
																																			case 121:
																																				goto IL_05cf;
																																			case 109:
																																				goto IL_05e5;
																																			case 62:
																																				goto IL_05f3;
																																			case 16:
																																			case 71:
																																				goto IL_060a;
																																			case 93:
																																				goto IL_0633;
																																			case 141:
																																				goto IL_064c;
																																			case 142:
																																				goto IL_065f;
																																			case 100:
																																			case 135:
																																				goto IL_066d;
																																			case 112:
																																				goto IL_067b;
																																			case 29:
																																				goto IL_0693;
																																			case 111:
																																				goto IL_06a1;
																																			case 5:
																																			case 143:
																																				goto IL_06b4;
																																			case 65:
																																				goto IL_06d2;
																																			case 61:
																																				goto IL_06e0;
																																			case 144:
																																				goto IL_06f3;
																																			case 80:
																																				goto IL_0707;
																																			case 20:
																																			case 148:
																																				goto IL_071a;
																																			case 6:
																																			case 30:
																																				goto IL_0745;
																																			case 119:
																																				goto IL_0785;
																																			case 2:
																																				goto IL_0799;
																																			case 55:
																																			case 145:
																																				goto IL_07b5;
																																			case 57:
																																				goto IL_07c3;
																																			case 31:
																																				goto IL_07d1;
																																			case 22:
																																				goto IL_07df;
																																			case 53:
																																			case 122:
																																				goto IL_07ea;
																																			case 68:
																																				goto IL_084c;
																																			case 8:
																																			case 149:
																																				goto IL_0870;
																																			case 25:
																																				goto IL_0889;
																																			case 70:
																																				goto IL_0894;
																																			case 0:
																																			case 17:
																																			case 19:
																																			case 38:
																																			case 40:
																																			case 43:
																																			case 45:
																																			case 52:
																																			case 63:
																																			case 69:
																																			case 72:
																																			case 73:
																																			case 75:
																																			case 81:
																																			case 94:
																																			case 96:
																																			case 104:
																																			case 114:
																																			case 117:
																																			case 118:
																																			case 129:
																																			case 130:
																																			case 131:
																																			case 132:
																																			case 134:
																																			case 136:
																																			case 139:
																																			case 140:
																																				goto end_IL_033d;
																																			case 15:
																																			case 18:
																																			case 21:
																																			case 42:
																																			case 49:
																																			case 50:
																																			case 51:
																																			case 76:
																																			case 90:
																																			case 97:
																																			case 101:
																																			case 102:
																																			case 106:
																																			case 110:
																																			case 116:
																																			case 120:
																																			case 128:
																																				goto end_IL_036d;
																																			case 59:
																																				goto end_IL_08bb;
																																			case 37:
																																				goto end_IL_08ce;
																																			case 85:
																																				goto end_IL_08d9;
																																			case 99:
																																				goto end_IL_08e3;
																																			case 67:
																																				goto end_IL_08ee;
																																			case 78:
																																			case 83:
																																				goto end_IL_0907;
																																			case 115:
																																				goto end_IL_0917;
																																			case 41:
																																			case 95:
																																				goto end_IL_0927;
																																			case 88:
																																				goto end_IL_0937;
																																			case 89:
																																				goto end_IL_0947;
																																			case 133:
																																			case 150:
																																				goto IL_096b;
																																			}
																																			continue;
																																		}
																																		ptr2 += 8;
																																		goto end_IL_036d;
																																		continue;
																																		end_IL_0283:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														continue;
																														end_IL_02e0:
																														break;
																													}
																													continue;
																												}
																												goto IL_0378;
																												IL_0386:
																												if (9 <= b)
																												{
																													goto end_IL_036d;
																												}
																												goto end_IL_033d;
																												IL_0378:
																												if (9 < b)
																												{
																													goto end_IL_033d;
																												}
																												goto IL_0386;
																												continue;
																												end_IL_02f0:
																												break;
																											}
																											continue;
																										}
																										goto IL_0399;
																										IL_0707:
																										num5--;
																										goto end_IL_036d;
																										IL_0399:
																										if (11 < b)
																										{
																											goto end_IL_033d;
																										}
																										goto IL_03a7;
																										IL_03a7:
																										if (11 > b)
																										{
																											goto end_IL_033d;
																										}
																										goto IL_03b5;
																										IL_03b5:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_06f3;
																										IL_06f3:
																										array[num5 - 2] = 0;
																										goto IL_0707;
																										continue;
																										end_IL_02fd:
																										break;
																									}
																									continue;
																								}
																								goto IL_0745;
																								IL_0799:
																								num5--;
																								goto end_IL_036d;
																								IL_0745:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0785;
																								IL_0785:
																								array[num5 - 2] = 0;
																								goto IL_0799;
																								continue;
																								end_IL_030d:
																								break;
																							}
																							continue;
																						}
																						num = 145;
																						goto IL_07b5;
																						IL_0889:
																						if (15 < b)
																						{
																							goto end_IL_033d;
																						}
																						goto IL_0894;
																						IL_0870:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_036d;
																						IL_07b5:
																						if (14 >= b)
																						{
																							goto IL_07c3;
																						}
																						goto IL_0889;
																						IL_07c3:
																						if (14 > b)
																						{
																							goto IL_07d1;
																						}
																						num = 149;
																						goto IL_0870;
																						IL_07d1:
																						if (13 < b)
																						{
																							goto end_IL_033d;
																						}
																						goto IL_07df;
																						IL_07df:
																						if (13 > b)
																						{
																							num = 45;
																							goto end_IL_033d;
																						}
																						goto IL_07ea;
																						IL_07ea:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_084c;
																						IL_084c:
																						num5 -= 2;
																						goto end_IL_036d;
																						IL_0894:
																						if (15 > b)
																						{
																							num = 130;
																						}
																						goto end_IL_033d;
																						continue;
																						end_IL_031d:
																						break;
																					}
																					continue;
																				}
																				goto IL_03fe;
																				IL_06e0:
																				num5--;
																				goto end_IL_036d;
																				IL_03fe:
																				if (8 > b)
																				{
																					goto IL_040c;
																				}
																				goto IL_071a;
																				IL_040c:
																				if (4 < b)
																				{
																					goto IL_041a;
																				}
																				goto IL_0504;
																				IL_041a:
																				if (6 >= b)
																				{
																					goto IL_0425;
																				}
																				goto IL_049e;
																				IL_0425:
																				if (6 > b)
																				{
																					goto IL_0430;
																				}
																				goto IL_0443;
																				IL_0430:
																				if (5 < b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_065f;
																				IL_065f:
																				if (5 > b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_066d;
																				IL_066d:
																				array[num5] = 5;
																				goto IL_067b;
																				IL_067b:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0693;
																				IL_0693:
																				num5++;
																				goto IL_06a1;
																				IL_06a1:
																				ptr2 += 8;
																				goto end_IL_036d;
																				IL_0443:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 82;
																				goto IL_048b;
																				IL_048b:
																				num5 -= 3;
																				goto end_IL_036d;
																				IL_049e:
																				if (7 < b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_04ac;
																				IL_04ac:
																				if (7 > b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_04ba;
																				IL_04ba:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e3;
																				IL_04e3:
																				ptr2 += 8;
																				goto IL_04f1;
																				IL_04f1:
																				num5--;
																				goto end_IL_036d;
																				IL_0504:
																				if (4 > b)
																				{
																					goto IL_0512;
																				}
																				goto IL_06b4;
																				IL_0512:
																				if (2 >= b)
																				{
																					goto IL_0520;
																				}
																				goto IL_05e5;
																				IL_0520:
																				if (2 > b)
																				{
																					goto IL_052b;
																				}
																				goto IL_058f;
																				IL_052b:
																				if (1 < b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_0539;
																				IL_0539:
																				if (1 > b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_0547;
																				IL_0547:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0560;
																				IL_0560:
																				array[num5] = 0;
																				goto IL_056e;
																				IL_056e:
																				num5++;
																				goto IL_057c;
																				IL_057c:
																				ptr2 += 8;
																				goto end_IL_036d;
																				IL_058f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05cf;
																				IL_05cf:
																				array[num5 - 2] = 0;
																				goto IL_064c;
																				IL_064c:
																				num5--;
																				goto end_IL_036d;
																				IL_05e5:
																				if (3 < b)
																				{
																					goto end_IL_033d;
																				}
																				goto IL_05f3;
																				IL_05f3:
																				if (3 > b)
																				{
																					goto end_IL_033d;
																				}
																				num = 16;
																				goto IL_060a;
																				IL_071a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_036d;
																				IL_060a:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0633;
																				IL_0633:
																				array[num5 - 1] = 5;
																				goto end_IL_036d;
																				IL_06b4:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_06d2;
																				IL_06d2:
																				ptr2 += 8;
																				goto IL_06e0;
																				continue;
																				end_IL_032d:
																				break;
																			}
																			continue;
																			end_IL_033d:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_036d;
																	continue;
																	end_IL_034d:
																	break;
																}
																continue;
																end_IL_035d:
																break;
															}
															continue;
															end_IL_036d:
															break;
														}
														continue;
													}
													goto IL_096b;
													IL_096b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08bb:
													break;
												}
												continue;
												end_IL_08ce:
												break;
											}
											continue;
											end_IL_08d9:
											break;
										}
										continue;
										end_IL_08e3:
										break;
									}
									continue;
									end_IL_08ee:
									break;
								}
								continue;
								end_IL_0907:
								break;
							}
							continue;
							end_IL_0917:
							break;
						}
						continue;
						end_IL_0927:
						break;
					}
					continue;
					end_IL_0937:
					break;
				}
				continue;
				end_IL_0947:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EncryptionAlgorithmSynchronizationAttribute.wMinorVerNumCookie);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02dd:
															byte b = *ptr2;
															while (true)
															{
																IL_02cd:
																ptr2++;
																while (true)
																{
																	IL_02bd:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_029d:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_028d:
																						if (7 >= b)
																						{
																							num = 80;
																							while (true)
																							{
																								IL_027d:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_021b:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0205:
																													array[num5 - 2] = 0;
																													while (true)
																													{
																														IL_01ec:
																														num5--;
																														num = 111;
																														while (num != 111)
																														{
																															if (num != 1092)
																															{
																																goto IL_0488;
																															}
																															switch (num)
																															{
																															case 75:
																																goto IL_01ec;
																															case 58:
																																goto IL_0205;
																															case 1:
																															case 104:
																																goto IL_021b;
																															case 49:
																																goto IL_025d;
																															case 81:
																																goto IL_026d;
																															case 80:
																																goto IL_027d;
																															case 27:
																																goto IL_028d;
																															case 96:
																																goto IL_029d;
																															case 32:
																																goto IL_02ad;
																															case 51:
																																goto IL_02bd;
																															case 42:
																																goto IL_02cd;
																															case 40:
																															case 98:
																																goto IL_02dd;
																															case 22:
																																goto IL_02e8;
																															case 85:
																																goto IL_02f3;
																															case 6:
																															case 20:
																																goto IL_0301;
																															case 14:
																																goto IL_0341;
																															case 35:
																																goto IL_0355;
																															case 15:
																															case 86:
																																goto IL_0368;
																															case 7:
																																goto IL_0376;
																															case 44:
																															case 92:
																																goto IL_0384;
																															case 23:
																															case 103:
																																goto IL_03a0;
																															case 71:
																																goto IL_03b9;
																															case 16:
																																goto IL_03c7;
																															case 39:
																																goto IL_03d5;
																															case 57:
																																goto IL_03f1;
																															case 10:
																															case 55:
																																goto IL_03fc;
																															case 41:
																																goto IL_0413;
																															case 95:
																																goto IL_0436;
																															case 66:
																																goto IL_0440;
																															case 99:
																																goto IL_044e;
																															case 25:
																																goto IL_0461;
																															case 101:
																																goto IL_046f;
																															case 65:
																																goto IL_047a;
																															case 18:
																															case 63:
																																goto IL_0488;
																															case 48:
																																goto IL_04b1;
																															case 69:
																																goto IL_04bf;
																															case 60:
																															case 87:
																																goto IL_04d2;
																															case 21:
																																goto IL_04e0;
																															case 50:
																															case 59:
																																goto IL_04f7;
																															case 90:
																																goto IL_0540;
																															case 12:
																																goto IL_0554;
																															case 73:
																																goto IL_0567;
																															case 43:
																																goto IL_0572;
																															case 45:
																																goto IL_057d;
																															case 52:
																															case 54:
																																goto IL_058a;
																															case 9:
																																goto IL_05ca;
																															case 78:
																																goto IL_05de;
																															case 2:
																															case 3:
																															case 4:
																															case 8:
																															case 13:
																															case 17:
																															case 26:
																															case 29:
																															case 34:
																															case 37:
																															case 56:
																															case 70:
																															case 72:
																															case 79:
																															case 82:
																															case 83:
																															case 88:
																															case 89:
																															case 100:
																															case 102:
																																goto end_IL_025d;
																															case 68:
																																goto IL_061a;
																															case 0:
																																goto IL_0628;
																															case 36:
																																goto IL_0636;
																															case 5:
																															case 24:
																															case 46:
																															case 64:
																															case 67:
																															case 77:
																															case 84:
																															case 91:
																															case 93:
																															case 97:
																																goto end_IL_01d9;
																															case 74:
																																goto end_IL_0644;
																															case 61:
																																goto end_IL_0657;
																															case 11:
																																goto end_IL_0661;
																															case 33:
																																goto end_IL_066c;
																															case 19:
																																goto end_IL_0681;
																															case 47:
																															case 76:
																																goto end_IL_0696;
																															case 38:
																																goto end_IL_06a6;
																															case 62:
																															case 94:
																																goto end_IL_06b6;
																															case 30:
																																goto end_IL_06c6;
																															case 31:
																																goto end_IL_06d6;
																															case 28:
																															case 53:
																																goto IL_06f1;
																															}
																															continue;
																															end_IL_01d9:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_02bd;
																											continue;
																											end_IL_025d:
																											break;
																											IL_025d:;
																										}
																										break;
																										IL_026d:;
																									}
																									break;
																								}
																								goto IL_03a0;
																								IL_03d5:
																								ptr2 += 8;
																								num = 93;
																								goto end_IL_02bd;
																								IL_03a0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03b9;
																								IL_03b9:
																								array[num5] = 0;
																								goto IL_03c7;
																								IL_03c7:
																								num5++;
																								goto IL_03d5;
																							}
																							break;
																						}
																						goto IL_02e8;
																						IL_0376:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0384;
																						IL_0384:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02bd;
																						IL_02e8:
																						if (8 >= b)
																						{
																							goto IL_02f3;
																						}
																						goto IL_0368;
																						IL_02f3:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0301;
																						IL_0301:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0341;
																						IL_0341:
																						array[num5 - 2] = 0;
																						goto IL_0355;
																						IL_0355:
																						num5--;
																						goto end_IL_02bd;
																						IL_0368:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0376;
																					}
																					break;
																				}
																				goto IL_03f1;
																				IL_05ca:
																				array[num5 - 2] = 0;
																				goto IL_05de;
																				IL_03f1:
																				if (5 <= b)
																				{
																					goto IL_03fc;
																				}
																				goto IL_0461;
																				IL_03fc:
																				array[num5] = 0;
																				num = 41;
																				goto IL_0413;
																				IL_0413:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0436;
																				IL_0436:
																				array2[num5] = null;
																				goto IL_0440;
																				IL_0440:
																				num5++;
																				goto IL_044e;
																				IL_044e:
																				ptr2 += 8;
																				goto end_IL_02bd;
																				IL_0461:
																				if (2 < b)
																				{
																					goto IL_046f;
																				}
																				goto IL_0567;
																				IL_046f:
																				if (3 >= b)
																				{
																					goto IL_047a;
																				}
																				goto IL_04d2;
																				IL_047a:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0488;
																				IL_0488:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b1;
																				IL_04b1:
																				ptr2 += 8;
																				goto IL_04bf;
																				IL_04bf:
																				num5--;
																				goto end_IL_02bd;
																				IL_04d2:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_04e0;
																				IL_04e0:
																				if (4 > b)
																				{
																					break;
																				}
																				num = 50;
																				goto IL_04f7;
																				IL_05de:
																				num5--;
																				num = 5;
																				goto end_IL_02bd;
																				IL_04f7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 90;
																				goto IL_0540;
																				IL_0540:
																				array[num5 - 2] = 0;
																				goto IL_0554;
																				IL_0554:
																				num5--;
																				goto end_IL_02bd;
																				IL_0567:
																				if (2 > b)
																				{
																					goto IL_0572;
																				}
																				goto IL_058a;
																				IL_0572:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_057d;
																				IL_057d:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_058a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ca;
																			}
																			break;
																			IL_02ad:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_061a;
																	IL_0636:
																	ptr2 += 8;
																	break;
																	IL_0628:
																	num5++;
																	goto IL_0636;
																	IL_061a:
																	array[num5] = 0;
																	goto IL_0628;
																	continue;
																	end_IL_02bd:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06f1;
													IL_06f1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0644:
													break;
												}
												continue;
												end_IL_0657:
												break;
											}
											continue;
											end_IL_0661:
											break;
										}
										continue;
										end_IL_066c:
										break;
									}
									continue;
									end_IL_0681:
									break;
								}
								continue;
								end_IL_0696:
								break;
							}
							continue;
							end_IL_06a6:
							break;
						}
						continue;
						end_IL_06b6:
						break;
					}
					continue;
					end_IL_06c6:
					break;
				}
				continue;
				end_IL_06d6:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 46;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 21;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SoapTokengetHasProperties.setCreationTimeUtcgetRuleSet);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 33;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0271:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0251:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0241:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0231:
																								if (9 > b)
																								{
																									num = 81;
																									while (true)
																									{
																										IL_021e:
																										if (7 < b)
																										{
																											num = 120;
																											while (true)
																											{
																												if (num != 120)
																												{
																													if (num != 1101)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 60:
																													case 81:
																														goto IL_021e;
																													case 8:
																														goto IL_0231;
																													case 28:
																														goto IL_0241;
																													case 69:
																														goto IL_0251;
																													case 41:
																														goto end_IL_0251;
																													case 1:
																														goto IL_0271;
																													case 90:
																														goto end_IL_0271;
																													case 33:
																														goto end_IL_0281;
																													case 83:
																														goto end_IL_0291;
																													case 19:
																													case 39:
																														goto IL_02a7;
																													case 9:
																														goto IL_0309;
																													case 44:
																														goto IL_031c;
																													case 56:
																														goto IL_032f;
																													case 34:
																														goto IL_033d;
																													case 51:
																														goto IL_0348;
																													case 47:
																														goto IL_0356;
																													case 52:
																														goto IL_0361;
																													case 22:
																													case 23:
																														goto end_IL_020b;
																													case 18:
																														goto IL_0382;
																													case 61:
																													case 74:
																														goto IL_0395;
																													case 14:
																														goto IL_03a3;
																													case 2:
																													case 76:
																														goto IL_03b1;
																													case 73:
																														goto IL_03da;
																													case 78:
																													case 82:
																														goto IL_03ea;
																													case 55:
																														goto IL_042a;
																													case 84:
																														goto IL_0440;
																													case 16:
																													case 85:
																														goto IL_0453;
																													case 35:
																													case 75:
																														goto IL_045e;
																													case 87:
																														goto IL_0477;
																													case 89:
																														goto IL_048a;
																													case 13:
																													case 36:
																														goto IL_0498;
																													case 92:
																														goto IL_04b4;
																													case 79:
																													case 103:
																														goto IL_04c7;
																													case 43:
																													case 104:
																														goto IL_04df;
																													case 30:
																														goto IL_051f;
																													case 64:
																														goto IL_0533;
																													case 105:
																														goto IL_0546;
																													case 57:
																														goto IL_0554;
																													case 10:
																													case 68:
																														goto IL_0562;
																													case 24:
																														goto IL_0570;
																													case 108:
																														goto IL_0593;
																													case 59:
																														goto IL_059d;
																													case 25:
																														goto IL_05ab;
																													case 65:
																													case 112:
																														goto IL_05be;
																													case 3:
																														goto IL_05e0;
																													case 97:
																														goto IL_05ee;
																													case 94:
																														goto IL_05fc;
																													case 93:
																														goto IL_060f;
																													case 99:
																														goto IL_0623;
																													case 6:
																													case 20:
																														goto IL_062e;
																													case 62:
																														goto IL_0651;
																													case 96:
																														goto IL_065f;
																													case 111:
																														goto IL_066d;
																													case 5:
																													case 7:
																													case 26:
																													case 27:
																													case 31:
																													case 32:
																													case 40:
																													case 45:
																													case 49:
																													case 54:
																													case 66:
																													case 67:
																													case 86:
																													case 91:
																													case 95:
																													case 100:
																													case 102:
																													case 106:
																													case 107:
																													case 110:
																														goto end_IL_0261;
																													case 0:
																													case 4:
																													case 11:
																													case 15:
																													case 17:
																													case 29:
																													case 37:
																													case 63:
																													case 77:
																													case 80:
																													case 88:
																													case 98:
																													case 101:
																													case 109:
																														goto end_IL_029c;
																													case 58:
																														goto end_IL_0690;
																													case 48:
																														goto end_IL_06a3;
																													case 38:
																														goto end_IL_06ad;
																													case 21:
																														goto end_IL_06b8;
																													case 53:
																													case 70:
																														goto end_IL_06cd;
																													case 113:
																														goto end_IL_06dd;
																													case 46:
																													case 50:
																														goto end_IL_06f6;
																													case 71:
																														goto end_IL_0706;
																													case 72:
																														goto end_IL_0716;
																													case 12:
																													case 42:
																														goto IL_073a;
																													}
																													continue;
																												}
																												goto IL_060f;
																												IL_0651:
																												array[num5] = 0;
																												goto IL_065f;
																												IL_065f:
																												num5++;
																												goto IL_066d;
																												IL_060f:
																												if (8 < b)
																												{
																													goto end_IL_0261;
																												}
																												num = 99;
																												goto IL_0623;
																												IL_066d:
																												ptr2 += 8;
																												goto end_IL_029c;
																												IL_0623:
																												if (8 > b)
																												{
																													goto end_IL_0261;
																												}
																												goto IL_062e;
																												IL_062e:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_0651;
																												continue;
																												end_IL_020b:
																												break;
																											}
																											break;
																										}
																										goto IL_031c;
																										IL_042a:
																										array[num5 - 2] = 0;
																										goto IL_0477;
																										IL_0477:
																										num5--;
																										goto end_IL_029c;
																										IL_031c:
																										if (7 > b)
																										{
																											goto end_IL_0261;
																										}
																										goto IL_03ea;
																										IL_03ea:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_042a;
																									}
																									break;
																								}
																								goto IL_02a7;
																								IL_02a7:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0309;
																								IL_0309:
																								num5 -= 2;
																								goto end_IL_029c;
																							}
																							break;
																						}
																						goto IL_0453;
																						IL_048a:
																						if (10 > b)
																						{
																							goto end_IL_0261;
																						}
																						goto IL_0498;
																						IL_0453:
																						if (10 < b)
																						{
																							goto IL_045e;
																						}
																						goto IL_048a;
																						IL_045e:
																						if (11 < b)
																						{
																							num = 95;
																							goto end_IL_0261;
																						}
																						goto IL_04b4;
																						IL_0498:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_029c;
																						IL_04b4:
																						if (11 > b)
																						{
																						}
																						goto end_IL_0261;
																					}
																					goto IL_0374;
																				}
																				goto IL_032f;
																				IL_0533:
																				num5--;
																				goto end_IL_029c;
																				IL_032f:
																				if (6 > b)
																				{
																					goto IL_033d;
																				}
																				goto IL_04df;
																				IL_033d:
																				if (3 >= b)
																				{
																					goto IL_0348;
																				}
																				goto IL_0374;
																				IL_0348:
																				if (3 > b)
																				{
																					goto IL_0356;
																				}
																				goto IL_04c7;
																				IL_0356:
																				if (1 >= b)
																				{
																					goto IL_0361;
																				}
																				goto IL_0395;
																				IL_0361:
																				if (1 > b)
																				{
																					goto end_IL_0261;
																				}
																				goto IL_05be;
																				IL_05be:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 3;
																				goto IL_05e0;
																				IL_05e0:
																				array[num5] = 0;
																				goto IL_05ee;
																				IL_05ee:
																				num5++;
																				goto IL_05fc;
																				IL_05fc:
																				ptr2 += 8;
																				goto end_IL_029c;
																				IL_0395:
																				if (2 < b)
																				{
																					goto end_IL_0261;
																				}
																				goto IL_03a3;
																				IL_03a3:
																				if (2 > b)
																				{
																					goto end_IL_0261;
																				}
																				goto IL_03b1;
																				IL_03b1:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03da;
																				IL_03da:
																				ptr2 += 8;
																				goto IL_0440;
																				IL_0440:
																				num5--;
																				goto end_IL_029c;
																				IL_04c7:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_029c;
																				IL_0374:
																				if (4 >= b)
																				{
																					goto IL_0382;
																				}
																				goto IL_0546;
																				IL_0382:
																				if (4 > b)
																				{
																					goto end_IL_0261;
																				}
																				goto end_IL_029c;
																				IL_0546:
																				if (5 < b)
																				{
																					goto end_IL_0261;
																				}
																				goto IL_0554;
																				IL_0554:
																				if (5 > b)
																				{
																					goto end_IL_0261;
																				}
																				goto IL_0562;
																				IL_0562:
																				array[num5] = 0;
																				goto IL_0570;
																				IL_0570:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0593;
																				IL_0593:
																				array2[num5] = null;
																				goto IL_059d;
																				IL_059d:
																				num5++;
																				goto IL_05ab;
																				IL_05ab:
																				ptr2 += 8;
																				goto end_IL_029c;
																				IL_04df:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_051f;
																				IL_051f:
																				array[num5 - 2] = 0;
																				goto IL_0533;
																				continue;
																				end_IL_0251:
																				break;
																			}
																			continue;
																			end_IL_0261:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_029c;
																	continue;
																	end_IL_0271:
																	break;
																}
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
														end_IL_029c:
														break;
													}
													continue;
												}
												goto IL_073a;
												IL_073a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0690:
												break;
											}
											continue;
											end_IL_06a3:
											break;
										}
										continue;
										end_IL_06ad:
										break;
									}
									continue;
									end_IL_06b8:
									break;
								}
								continue;
								end_IL_06cd:
								break;
							}
							continue;
							end_IL_06dd:
							break;
						}
						continue;
						end_IL_06f6:
						break;
					}
					continue;
					end_IL_0706:
					break;
				}
				continue;
				end_IL_0716:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 42;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									num = 86;
									while (true)
									{
										array3[1] = int_2;
										num = 6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeRequiresRegistrationWINFILEATTRIBUTEDATA.TaskScheduledsetIgnoreCase);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 28;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0214:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_01f4:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01e7:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01d7:
																									if (2 < b)
																									{
																										while (3 >= b)
																										{
																											while (true)
																											{
																												IL_01b4:
																												if (3 > b)
																												{
																													num = 97;
																													while (num != 97)
																													{
																														if (num != 1078)
																														{
																															goto IL_0294;
																														}
																														switch (num)
																														{
																														case 19:
																															goto IL_01b4;
																														case 7:
																															goto IL_01c7;
																														case 32:
																															goto IL_01d7;
																														case 87:
																															goto IL_01e7;
																														case 44:
																															goto IL_01f4;
																														case 83:
																															goto IL_0204;
																														case 21:
																															goto IL_0214;
																														case 25:
																															goto end_IL_0214;
																														case 9:
																														case 55:
																															goto end_IL_0224;
																														case 11:
																														case 71:
																															goto IL_023f;
																														case 59:
																															goto IL_0268;
																														case 20:
																															goto IL_0276;
																														case 78:
																															goto IL_0289;
																														case 16:
																														case 39:
																															goto IL_0294;
																														case 73:
																															goto IL_02a2;
																														case 23:
																														case 82:
																															goto IL_02b5;
																														case 61:
																															goto IL_0323;
																														case 31:
																														case 43:
																															goto IL_0336;
																														case 57:
																															goto IL_0376;
																														case 68:
																															goto IL_0393;
																														case 48:
																														case 60:
																															goto IL_03a6;
																														case 84:
																															goto IL_03b1;
																														case 46:
																														case 58:
																															goto IL_03bf;
																														case 54:
																															goto IL_03d6;
																														case 8:
																														case 72:
																															goto IL_03e4;
																														case 2:
																															goto IL_03fc;
																														case 15:
																															goto IL_0407;
																														case 34:
																														case 35:
																															goto IL_0415;
																														case 12:
																															goto IL_0423;
																														case 90:
																															goto IL_0446;
																														case 77:
																															goto IL_0450;
																														case 30:
																															goto IL_0467;
																														case 33:
																														case 38:
																															goto IL_0483;
																														case 1:
																															goto IL_048e;
																														case 13:
																														case 80:
																															goto IL_0499;
																														case 3:
																														case 4:
																														case 18:
																														case 27:
																														case 37:
																														case 40:
																														case 45:
																														case 50:
																														case 56:
																														case 63:
																														case 65:
																														case 67:
																														case 76:
																														case 79:
																														case 81:
																														case 85:
																														case 89:
																															goto end_IL_01a1;
																														case 10:
																															goto IL_04d5;
																														case 36:
																															goto IL_04e3;
																														case 52:
																															goto IL_04f1;
																														case 0:
																														case 22:
																														case 26:
																														case 28:
																														case 51:
																														case 53:
																														case 69:
																														case 70:
																														case 74:
																														case 88:
																															goto end_IL_0234;
																														case 14:
																															goto end_IL_0508;
																														case 17:
																															goto end_IL_051b;
																														case 6:
																															goto end_IL_0526;
																														case 86:
																															goto end_IL_0530;
																														case 24:
																															goto end_IL_053b;
																														case 64:
																															goto end_IL_0559;
																														case 29:
																														case 75:
																															goto end_IL_0577;
																														case 47:
																															goto end_IL_0587;
																														case 5:
																														case 66:
																															goto end_IL_0597;
																														case 41:
																															goto end_IL_05a7;
																														case 42:
																															goto end_IL_05b7;
																														case 49:
																														case 62:
																															goto IL_05d2;
																														}
																														continue;
																														end_IL_01a1:
																														break;
																													}
																													break;
																												}
																												goto IL_0336;
																												IL_0376:
																												array[num5 - 2] = 0;
																												num = 68;
																												goto IL_0393;
																												IL_0393:
																												num5--;
																												goto end_IL_0234;
																												IL_0336:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0376;
																											}
																											break;
																											IL_01c7:;
																										}
																										break;
																									}
																									goto IL_0289;
																									IL_0323:
																									num5 -= 2;
																									goto end_IL_0234;
																									IL_0289:
																									if (2 > b)
																									{
																										goto IL_0294;
																									}
																									goto IL_02b5;
																									IL_0294:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_02a2;
																									IL_02a2:
																									if (1 > b)
																									{
																									}
																									break;
																									IL_02b5:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0323;
																								}
																								break;
																							}
																							goto IL_023f;
																							IL_0276:
																							num5--;
																							goto end_IL_0234;
																							IL_023f:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0268;
																							IL_0268:
																							ptr2 += 8;
																							goto IL_0276;
																						}
																						break;
																					}
																					goto IL_03a6;
																					IL_0483:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_048e;
																					IL_03a6:
																					if (6 >= b)
																					{
																						goto IL_03b1;
																					}
																					goto IL_03fc;
																					IL_03b1:
																					if (6 <= b)
																					{
																						goto end_IL_0234;
																					}
																					goto IL_03bf;
																					IL_03bf:
																					if (5 < b)
																					{
																						break;
																					}
																					num = 54;
																					goto IL_03d6;
																					IL_048e:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0499;
																					IL_03d6:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_03e4;
																					IL_03e4:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0234;
																					IL_03fc:
																					if (7 >= b)
																					{
																						goto IL_0407;
																					}
																					num = 38;
																					goto IL_0483;
																					IL_0407:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0415;
																					IL_0415:
																					array[num5] = 0;
																					goto IL_0423;
																					IL_0423:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0446;
																					IL_0446:
																					array2[num5] = null;
																					goto IL_0450;
																					IL_0450:
																					num5++;
																					num = 30;
																					goto IL_0467;
																					IL_0467:
																					ptr2 += 8;
																					goto end_IL_0234;
																					IL_0499:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0234;
																				}
																				break;
																				IL_0204:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04d5;
																		IL_04f1:
																		ptr2 += 8;
																		num = 26;
																		goto end_IL_0234;
																		IL_04e3:
																		num5++;
																		goto IL_04f1;
																		IL_04d5:
																		array[num5] = 0;
																		goto IL_04e3;
																		continue;
																		end_IL_0214:
																		break;
																	}
																	continue;
																	end_IL_0224:
																	break;
																}
																continue;
																end_IL_0234:
																break;
															}
															continue;
														}
														goto IL_05d2;
														IL_05d2:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0508:
														break;
													}
													continue;
													end_IL_051b:
													break;
												}
												continue;
												end_IL_0526:
												break;
											}
											continue;
											end_IL_0530:
											break;
										}
										continue;
										end_IL_053b:
										break;
									}
									continue;
									end_IL_0559:
									break;
								}
								continue;
								end_IL_0577:
								break;
							}
							continue;
							end_IL_0587:
							break;
						}
						continue;
						end_IL_0597:
						break;
					}
					continue;
					end_IL_05a7:
					break;
				}
				continue;
				end_IL_05b7:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_1, int int_2)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 8;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getComparerFOleAutomation.VTUSERDEFINEDStandardBias);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0321:
																byte b = *ptr2;
																while (true)
																{
																	IL_0311:
																	ptr2++;
																	while (true)
																	{
																		IL_02fe:
																		if (b >= 1)
																		{
																			num = 107;
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_02e1:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_02d1:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_02c1:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_02b1:
																											if (7 < b)
																											{
																												while (8 >= b)
																												{
																													while (8 <= b)
																													{
																														while (true)
																														{
																															IL_0276:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																															while (true)
																															{
																																IL_025d:
																																array[num5] = 0;
																																num = 6;
																																while (true)
																																{
																																	IL_024d:
																																	num5++;
																																	while (true)
																																	{
																																		IL_0234:
																																		ptr2 += 8;
																																		num = 129;
																																		while (num != 129)
																																		{
																																			if (num != 1110)
																																			{
																																				goto IL_06de;
																																			}
																																			switch (num)
																																			{
																																			case 50:
																																				goto IL_0234;
																																			case 6:
																																				goto IL_024d;
																																			case 18:
																																				goto IL_025d;
																																			case 57:
																																			case 122:
																																				goto IL_0276;
																																			case 81:
																																				goto IL_0291;
																																			case 75:
																																			case 115:
																																				goto IL_02a1;
																																			case 54:
																																			case 68:
																																				goto IL_02b1;
																																			case 67:
																																				goto IL_02c1;
																																			case 65:
																																				goto IL_02d1;
																																			case 11:
																																				goto IL_02e1;
																																			case 107:
																																				goto IL_02ee;
																																			case 22:
																																				goto IL_02fe;
																																			case 91:
																																				goto IL_0311;
																																			case 71:
																																			case 120:
																																				goto IL_0321;
																																			case 23:
																																				goto IL_032c;
																																			case 53:
																																				goto IL_033a;
																																			case 14:
																																			case 85:
																																				goto IL_0351;
																																			case 93:
																																				goto IL_0361;
																																			case 94:
																																				goto IL_0371;
																																			case 3:
																																			case 70:
																																				goto IL_037f;
																																			case 92:
																																			case 103:
																																				goto IL_03ad;
																																			case 17:
																																				goto IL_03bb;
																																			case 41:
																																				goto IL_03de;
																																			case 110:
																																				goto IL_03e8;
																																			case 58:
																																				goto IL_03f6;
																																			case 113:
																																				goto IL_0409;
																																			case 111:
																																				goto IL_0417;
																																			case 16:
																																			case 46:
																																				goto IL_0425;
																																			case 82:
																																				goto IL_0433;
																																			case 20:
																																			case 95:
																																				goto IL_0441;
																																			case 33:
																																				goto IL_04af;
																																			case 9:
																																				goto IL_04c2;
																																			case 21:
																																			case 73:
																																				goto IL_04e7;
																																			case 30:
																																				goto IL_0527;
																																			case 25:
																																			case 114:
																																				goto IL_053d;
																																			case 116:
																																				goto IL_054d;
																																			case 84:
																																				goto IL_055b;
																																			case 118:
																																				goto IL_056e;
																																			case 35:
																																			case 100:
																																				goto IL_057c;
																																			case 121:
																																				goto IL_0594;
																																			case 29:
																																			case 119:
																																				goto IL_05a7;
																																			case 78:
																																				goto IL_05e7;
																																			case 79:
																																				goto IL_05fb;
																																			case 12:
																																				goto IL_060e;
																																			case 45:
																																				goto IL_061c;
																																			case 55:
																																			case 96:
																																				goto IL_062a;
																																			case 42:
																																				goto IL_0638;
																																			case 34:
																																			case 90:
																																				goto IL_0646;
																																			case 72:
																																				goto IL_0663;
																																			case 86:
																																				goto IL_06a2;
																																			case 37:
																																			case 112:
																																				goto IL_06b5;
																																			case 77:
																																				goto IL_06c8;
																																			case 64:
																																				goto IL_06d3;
																																			case 15:
																																			case 108:
																																				goto IL_06de;
																																			case 2:
																																			case 4:
																																			case 7:
																																			case 10:
																																			case 13:
																																			case 19:
																																			case 24:
																																			case 31:
																																			case 36:
																																			case 40:
																																			case 51:
																																			case 59:
																																			case 60:
																																			case 61:
																																			case 69:
																																			case 74:
																																			case 76:
																																			case 89:
																																			case 97:
																																			case 99:
																																			case 104:
																																				goto end_IL_0291;
																																			case 101:
																																				goto IL_0723;
																																			case 49:
																																				goto IL_0731;
																																			case 80:
																																				goto IL_073f;
																																			case 26:
																																			case 27:
																																			case 28:
																																			case 38:
																																			case 44:
																																			case 47:
																																			case 52:
																																			case 62:
																																			case 63:
																																			case 83:
																																			case 88:
																																			case 98:
																																			case 106:
																																			case 109:
																																				goto end_IL_0221;
																																			case 117:
																																				goto end_IL_074d;
																																			case 32:
																																				goto end_IL_0760;
																																			case 87:
																																				goto end_IL_076a;
																																			case 39:
																																				goto end_IL_0775;
																																			case 105:
																																				goto end_IL_078a;
																																			case 8:
																																				goto end_IL_079f;
																																			case 66:
																																				goto end_IL_07af;
																																			case 43:
																																				goto end_IL_07bf;
																																			case 5:
																																			case 48:
																																				goto end_IL_07ca;
																																			case 0:
																																				goto end_IL_07da;
																																			case 1:
																																				goto end_IL_07ea;
																																			case 56:
																																			case 102:
																																				goto IL_0805;
																																			}
																																			continue;
																																			end_IL_0221:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_02fe;
																														continue;
																														end_IL_0291:
																														break;
																														IL_0291:;
																													}
																													break;
																													IL_02a1:;
																												}
																												break;
																											}
																											goto IL_0361;
																											IL_03f6:
																											ptr2 += 8;
																											goto end_IL_02fe;
																											IL_0361:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_03ad;
																											IL_03ad:
																											array[num5] = 0;
																											goto IL_03bb;
																											IL_03bb:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_03de;
																											IL_03de:
																											array2[num5] = null;
																											goto IL_03e8;
																											IL_03e8:
																											num5++;
																											goto IL_03f6;
																										}
																										break;
																									}
																									goto IL_05a7;
																									IL_05fb:
																									num5--;
																									goto end_IL_02fe;
																									IL_05a7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05e7;
																									IL_05e7:
																									array[num5 - 2] = 0;
																									goto IL_05fb;
																								}
																								break;
																							}
																							goto IL_060e;
																							IL_06de:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							num = 98;
																							goto end_IL_02fe;
																							IL_060e:
																							if (11 >= b)
																							{
																								goto IL_061c;
																							}
																							goto IL_06c8;
																							IL_061c:
																							if (11 > b)
																							{
																								goto IL_062a;
																							}
																							goto IL_06b5;
																							IL_062a:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0638;
																							IL_0638:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0646;
																							IL_0646:
																							array[num5 - 1] = 0;
																							num = 72;
																							goto IL_0663;
																							IL_0663:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getScopeNameResolveROAsmEvent[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_06a2;
																							IL_06a2:
																							ptr2 += 8;
																							goto end_IL_02fe;
																							IL_06b5:
																							num5--;
																							goto end_IL_02fe;
																							IL_06c8:
																							if (12 < b)
																							{
																								break;
																							}
																							goto IL_06d3;
																							IL_06d3:
																							if (12 > b)
																							{
																								break;
																							}
																							goto IL_06de;
																						}
																						break;
																					}
																					goto IL_032c;
																					IL_0527:
																					array[num5 - 2] = 0;
																					goto IL_0594;
																					IL_032c:
																					if (6 <= b)
																					{
																						goto end_IL_02fe;
																					}
																					goto IL_033a;
																					IL_033a:
																					if (3 < b)
																					{
																						num = 14;
																						goto IL_0351;
																					}
																					goto IL_0409;
																					IL_04e7:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0527;
																					IL_0351:
																					if (4 >= b)
																					{
																						goto IL_0371;
																					}
																					goto IL_053d;
																					IL_053d:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_056e;
																					IL_056e:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_057c;
																					IL_057c:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_02fe;
																					IL_0371:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_037f;
																					IL_037f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_054d;
																					IL_054d:
																					ptr2 += 8;
																					goto IL_055b;
																					IL_055b:
																					num5--;
																					goto end_IL_02fe;
																					IL_0409:
																					if (3 > b)
																					{
																						goto IL_0417;
																					}
																					num = 73;
																					goto IL_04e7;
																					IL_0417:
																					if (1 < b)
																					{
																						goto IL_0425;
																					}
																					goto IL_04c2;
																					IL_0425:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0433;
																					IL_0433:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0441;
																					IL_0441:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_04af;
																					IL_04af:
																					num5 -= 2;
																					goto end_IL_02fe;
																					IL_04c2:
																					if (1 > b)
																					{
																						num = 97;
																					}
																					break;
																					IL_0594:
																					num5--;
																					goto end_IL_02fe;
																				}
																				break;
																				IL_02ee:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0723;
																		IL_0731:
																		num5++;
																		goto IL_073f;
																		IL_073f:
																		ptr2 += 8;
																		break;
																		IL_0723:
																		array[num5] = 0;
																		goto IL_0731;
																		continue;
																		end_IL_02fe:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_0805;
														IL_0805:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_074d:
														break;
													}
													continue;
													end_IL_0760:
													break;
												}
												continue;
												end_IL_076a:
												break;
											}
											continue;
											end_IL_0775:
											break;
										}
										continue;
										end_IL_078a:
										break;
									}
									continue;
									end_IL_079f:
									break;
								}
								continue;
								end_IL_07af:
								break;
							}
							continue;
							end_IL_07bf:
							break;
						}
						continue;
						end_IL_07ca:
						break;
					}
					continue;
					end_IL_07da:
					break;
				}
				continue;
				end_IL_07ea:
				break;
			}
		}
	}
}
